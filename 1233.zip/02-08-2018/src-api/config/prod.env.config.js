export default {
		host: "0.0.0.0",
		port: 8000,
		secretKey: "lF7ioZHOa4iafmUfhcWwkUFRb7P7F09K"
};
