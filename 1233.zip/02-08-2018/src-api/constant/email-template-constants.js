export const CLOSE_REQUEST_TEMPLATE = `<html>
<head>

</head>

<body>
	<div align="center">
		<center>
			<table border="0" cellpadding="0" cellspacing="0" width="800">
				<tr>
					<td width="10%"><a href="http://www.theclosingexchange.com/"><img border="0" src="http://www.theclosingexchange.com/images/logo-97.jpg" width="154" height="115"></a></td>
					<td width="40%" align="center"><p><b><font size="4" face="Arial">Notary Closing Confirmation</font></b></p></td>
					<td height="18">
						<table border="1" width="100%" id="table1" bordercolorlight="#000000" cellspacing="0" cellpadding="2" bordercolordark="#000000" style="border-collapse: collapse">
							<tr>
								<td width="34%"><b><font size="1" face="Arial">Company:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[companyName]</font></td>
							</tr>
							<tr>
								<td width="34%"><b><font size="1" face="Arial">File Last Name:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[customerLastName]</font></td>
							</tr>
							<tr>
								<td width="34%"><b><font size="1" face="Arial">Loan/Reference number:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[referenceNumber]</font></td>
							</tr>
							<tr>
								<td width="34%"><b><font size="1" face="Arial">Notary Direct Order ID:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[orderId]</font></td>
							</tr>
							<!--AGENT-->
							<tr>
								<td width="34%"><b><font face="Arial" size="1">Signing Date and Time:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[aptDateTime]</font></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			
			<!--STATEMENT-->
			
			<table bgcolor="#EEEEEE" cellspacing="0" cellpadding="5" width="800">
				<tr>
					<td bgcolor="#707070">
						<font color="#FFFFFF" face="Arial" style="font-size: 9pt"><b>Closing Worksheet Completed by: [vendorName] </b></font>
					</td>
				</tr>
					
				<tr>
					<td>
						<font style="font-size: 9pt" face="Wingdings">&nbsp;x</font><font face="Arial" style="font-size: 9pt"> Appointment Confirmed<br></font>
						<font style="font-size: 9pt" face="Wingdings">&nbsp;x</font><font face="Arial" style="font-size: 9pt"> Documents Retrieved and Printed Correctly<br></font>
						<font style="font-size: 9pt" face="Wingdings">&nbsp;x</font><font face="Arial" style="font-size: 9pt"> Documents Reviewed, <b>PAGE BY PAGE</b>, for Signatures, initials, and Notarization<br></font>
					</td>
				</tr>
					
				<tr>
					<td>
						<font face="Arial" style="font-size: 9pt">&nbsp;&nbsp;&nbsp;&nbsp; Courier:&nbsp;&nbsp;<b>[courier]</b></font>
					</td>
				</tr>
					
				<tr>
					<td>
						<font face="Arial" style="font-size: 9pt">&nbsp;&nbsp;&nbsp;&nbsp; Account #:&nbsp;&nbsp;<b>[courierAccountNumber]</b></font>
					</td>
				</tr>
					
				<tr>
					<td>
						<font face="Arial" style="font-size: 9pt">&nbsp;&nbsp;&nbsp;&nbsp; Shipment Tracking Number:&nbsp;&nbsp;<b>[trackingNumber]</b></font>
					</td>
				</tr>
				
				<tr>
					<td>
						<div id="DRE" style="display:none">
						<table width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td valign="top">
									<hr>
								</td>
							</tr>
						</table>
						</div>
					</td>
				</tr>
			  
				<tr>
					<td valign="top">
						<font face="Arial" style="font-size: 9pt">&nbsp;</font><font style="font-size: 9pt" face="Wingdings">x</font><font face="Arial" style="font-size: 9pt"> <b>I</b> understand that 
						documents must be dropped off for shipping or uploaded immediately following the signing 
						appointment to ensure compensation for this signing.</font>
					</td>
				</tr>
			  
				<tr>
					<td bgcolor="#707070">
						<b><font color="#FFFFFF" face="Arial" style="font-size: 9pt">&nbsp; Questionnaire:</font></b>
					</td>
				</tr>
				
				<tr>
					<td width="90%">
						<font face="Arial" style="font-size: 9pt">
						<ol >
							<li style="padding-top: 5px;margin-top: 10px;">Were There Any Issues at the Signing Table?&nbsp;&nbsp;&nbsp;&nbsp;<b><u>[isIssues]</u></b>
								<br>- If so, what were they and who did you contact to resolve<br>
								<b>[issuesResolveText]</b>
							</li>
							
							<li style="border-top: 1px solid #000000;padding-top: 10px;margin-top: 10px;">Were there any items to be collected from the 
								borrower at the closing table?&nbsp;&nbsp;&nbsp;&nbsp; <u><b>[isCollected]</b></u>
								<br>- If so, what items were collected or missing?<br>
								<b>[collectedText]</b>
                            </li>	
                            
                            <!--SCANBACK-->
							
							<li style="border-top: 1px solid #000000;padding-top: 10px;margin-top: 10px;border-bottom: 1px solid #000000;padding-bottom: 10px;">General Comments<br>
								<b>[generalComment]</b>
							</li>

						</ol>
						</font>
				
					</td>
				</tr>
				
				<tr>
					<td>
						<font face="Arial" style="font-size: 9pt">
							<b>REVIEW:</b>
						</font>
						<ul type="square">
							<li>
								<font face="Arial" style="font-size: 9pt">It is imperative that all documents are signed/dated and notarized as they appear typed. Notary Stamp must be legible.<br>&nbsp;</font>
							</li>
							
							<li>
								<font face="Arial" style="font-size: 9pt">Package must be reviewed prior to departing borrower's home to ensure that all documents have been properly witnessed and accounted for. Prior to returning loan package, please confirm that the return address is correct.</font>
							</li>
						</ul>
						
						<p><font face="Arial" style="font-size: 9pt"><b>TERMS AND ACCEPTANCE:</b></font></p>
						<ul type="square">
							<li>
								<font face="Arial" style="font-size: 9pt">By submitting this document, I certify that the documents and any special and/or notary instructions have been fully executed to the best of my ability. I understand that I will be held accountable for any inaccurate information furnished. I do understand that during the post closing audit, if an error has been identified, I will be held responsible for immediate correction, at my own expense. I also understand that a fee reduction may be assessed in accordance to Notary Direct Nationwide Signing Agent Fee Reduction Policy.</font>
							</li>
						</ul>
					</td>
				</tr>
			  
				<tr>
					<td bgcolor="#707070">
						<b><font color="#FFFFFF" face="Arial" style="font-size: 9pt">&nbsp; Digital Signature:</font></b>
					</td>
				</tr>
				
				<tr>
					<td bgcolor="#EEEEEE">
						<font style="font-size: 9pt" face="Wingdings">x</font><font face="Arial" style="font-size: 9pt">&nbsp;&nbsp;I,<b>[vendorName],</b> certify that the above information is True and Correct</font>
					</td>
				</tr>
			</table>
			
			<table width="800" cellspacing="0" cellpadding="0">
				<tr>
					<td bgcolor="#C0C0C0">
						<font face="Arial" style="font-size: 9pt"><b>&nbsp;&nbsp; Notary Public Name:&nbsp;</b></font>
					</td>
					
					<td bgcolor="#C0C0C0"><font face="Arial" style="font-size: 9pt"><b>Customer Last Name:</b>&nbsp;</font></td>
				</tr>
			  
				<tr>
					<td bgcolor="#EEEEEE" height="30">
						<blockquote><font face="Arial" style="font-size: 9pt">[vendorName]</font></blockquote>
					</td>
				
					<td bgcolor="#EEEEEE" height="30">
						<blockquote><font face="Arial" style="font-size: 9pt">[customerLastName]</font></blockquote>
					</td>
				</tr>
			  
				<tr>
					<td bgcolor="#C0C0C0"><font face="Arial" style="font-size: 9pt"><b>&nbsp;&nbsp; Order ID #</b></font></td>
					<td bgcolor="#C0C0C0"><font face="Arial" style="font-size: 9pt"><b>Notary Rep</b></font></td>
				</tr>
				
				<tr>
					<td bgcolor="#EEEEEE" height="30">
						<blockquote>
							<font face="Arial" style="font-size: 9pt">
							[orderId]
							</font>
						</blockquote>
					</td>
					
					<td bgcolor="#EEEEEE" height="30">
						<blockquote>
							<font face="Arial" style="font-size: 9pt">
							[referenceNumber]
							</font>
						</blockquote>
					</td>
				</tr>
			</table>
		</center>
	</div>
</body>
</html>`;

export const CLOSE_REQUEST_TCE = `<tr>
                                    <td width="34%"><b><font size="1" face="Arial">Loan Agent:</font></b></td>
                                    <td width="63%"><font size="1" face="Arial">[agentName]</font></td>
                                </tr>
                                <tr>
                                    <td width="34%"><b><font size="1" face="Arial">Loan Agent Phone:</font></b></td>
                                    <td width="63%"><font size="1" face="Arial">[agentPhone]</font></td>
                                </tr>
                                <tr>
                                    <td width="34%"><b><font size="1" face="Arial">Loan Agent Email:</font></b></td>
                                    <td width="63%"><font size="1" face="Arial">[agentEmail]</font></td>
                                </tr>`;

export const SCANBACK_TEMPLATE = `<li style="border-top: 1px solid #000000;padding-top: 10px;margin-top: 10px;">
This order requires scanbacks. 
<br>When were scanbacks sent?
<br><b>[scanbacksDate][scanbacksTime]</b>
</li>`;