use tce_dev;

DELIMITER $$
CREATE PROCEDURE `alter_table_order` ()
BEGIN
	-- Suite
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order' AND 
                            COLUMN_NAME = 'Suite') THEN
	BEGIN
		ALTER TABLE `order` 
		ADD COLUMN `Suite` VARCHAR(10) NULL AFTER `Address`;
	END;
    END IF;
    
    -- StatusID - staff member
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order' AND 
                            COLUMN_NAME = 'StatusID') THEN
	BEGIN
		ALTER TABLE `order` 
		ADD COLUMN `StatusID` INT NULL,
        ADD INDEX `statusId_idx` (`StatusID` ASC);
		ALTER TABLE `order` 
		ADD CONSTRAINT `statusId_order`
		  FOREIGN KEY (`StatusID`)
		  REFERENCES `employees` (`RepId`) ON DELETE NO ACTION ON UPDATE NO ACTION;
	END;
    END IF;
    
    -- QC - staff member
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order' AND 
                            COLUMN_NAME = 'QCID') THEN
	BEGIN
		ALTER TABLE `order` 
		ADD COLUMN `QCID` INT NULL,
        ADD INDEX `qcId_idx` (`QCID` ASC);
		ALTER TABLE `order` 
		ADD CONSTRAINT `qcId_order`
		  FOREIGN KEY (`QCID`)
		  REFERENCES `employees` (`RepId`) ON DELETE NO ACTION ON UPDATE NO ACTION;
	END;
    END IF;
    
    -- change data type
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order' AND 
                            COLUMN_NAME = 'AutoProgress') THEN
	BEGIN
		ALTER TABLE `order` CHANGE COLUMN `AutoProgress` `AutoProgress` VARCHAR(1);
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_order();

DROP PROCEDURE IF EXISTS `alter_table_order`;

