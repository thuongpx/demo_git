CREATE TABLE IF NOT EXISTS `resources` (
	`Id` INT NOT NULL AUTO_INCREMENT,
	`Resource` VARCHAR(50),
	`Title` VARCHAR(50),
	`Description` VARCHAR(2000),
	`Lender` BIT DEFAULT b'0',
	`Notary` BIT DEFAULT b'0',
	`MemOnly` BIT DEFAULT b'0',
	`Views` VARCHAR(100),
	PRIMARY KEY (`Id`)
);
