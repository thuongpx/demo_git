ALTER TABLE `customers` ADD COLUMN `ReqRating` SMALLINT NULL;
ALTER TABLE `customers` ADD COLUMN `ReqExperienceNumber` SMALLINT NULL;
