DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	-- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'test_info' AND 
                            COLUMN_NAME = 'TestCategory') THEN
	BEGIN
		ALTER TABLE `test_info`
        ADD COLUMN `TestCategory` INT(11) NULL;
	END;
    END IF;      
END$$

DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;