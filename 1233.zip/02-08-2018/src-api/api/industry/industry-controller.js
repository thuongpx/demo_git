import Boom from "boom";
import Bookshelf from "../../db/database";
import Industry from "../../db/model/industry";
import { handleSingleQuote } from "../../helper/common-helper";
import IndustryTransactionFee from "../../db/model/industry_transaction_fees";

class IndustryController {
    constructor() { }

    getAllIndustry(request, reply) {
        const ralSqlGetAllIndustry = "select industryId, description, ParentId AS parentId from industry;";

        Bookshelf.knex.raw(ralSqlGetAllIndustry)
            .then(value => {
                let returnData = [];
                if (value !== null) {
                    returnData = value[0];
                }

                reply(returnData);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    deleteIndustry(request, reply) {
        const { industryId } = request.payload;
        IndustryTransactionFee.where({ industryId }).destroy().then(() => {
            Industry.where({ industryId }).destroy().then(() => {
                reply({ isSuccess: true });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
        }).catch(err => {
            reply(Boom.badRequest(err));
        });
    }

    getIndustries(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            industryName
        } = request.payload;

        const rawSql = `call GetIndustries('${handleSingleQuote(industryName)}','${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage})`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    checkExistIndustry(request, reply) {
        const { description } = request.payload;
        let { industryId } = request.payload;
        if (!industryId) {
            industryId = 0;
        }
        Industry.query((qb) => {
            qb.where("description", "=", `${description}`).andWhere("industryId", "<>", industryId);
        }).count("*").then((result) => {
            reply({ isExist: result > 0 });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    addIndustry(request, reply) {
        const { description } = request.payload;
        new Industry({ description }).save(null, { method: "insert" }).then(() => {
            reply({ isSuccess: true });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    updateIndustry(request, reply) {
        const { description, industryId } = request.payload;
        Industry.where({ industryId }).save({ description }, { method: "update" }).then(() => {
            reply({ isSuccess: true });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

}

export default new IndustryController();