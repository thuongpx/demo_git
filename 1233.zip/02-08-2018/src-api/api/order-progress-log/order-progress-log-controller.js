import Boom from "boom";
import OrderProgressLog from "../../db/model/order-progress-log";
import Bookshelf from "./../../db/database";
import Promise from "bluebird";
import {
    bufferToBoolean,
    hasValue
} from "../../helper/common-helper";
import moment from "moment";

class OrderProgressLogController {
    constructor() { }

    addProgressLog(request, reply) {
        const log = request.payload;

        log.DateLog = moment().utc().format("YYYY-MM-DD HH:mm:ss");
        if (log.dateLog) {
            delete log.DateLog;
        }
        const newLog = new OrderProgressLog();
        // add a log to db
        newLog.save(log, {
            method: "insert"
        }).then(() => {
            reply({
                isSuccess: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    addMultiProgressLog(request, reply) {
        const {
            logs
        } = request.payload;

        Bookshelf.transaction((t) => {
            return Promise.map(logs, (log) => {
                return new OrderProgressLog().save(log, {
                    method: "insert",
                    transacting: t
                });
            }).then(t.commit).catch(t.rollback);
        }).then(() => {
            reply({
                isSuccess: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    getOrderProgressLogById(request, reply) {
        const {
            orderId
        } = request.query;

        const progressLogSql = `SELECT opl.progressType, opl.usersId, opl.dateLog, opl.activity, opl.message, GetUserType(u.UsersId) AS userType, u.mappingUserId 
                            FROM \`order_progress_log\` opl
                            INNER JOIN \`users\` u ON opl.UsersId = u.UsersId
                            WHERE opl.OrderId = ${orderId} AND (opl.ProgressType <> 5 OR opl.ProgressType IS NULL) 
                            ORDER BY DateLog DESC;`;

        Bookshelf.knex.raw(progressLogSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        dataProgressLog: result[0]
                    });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }
    //get alert
    getDataAlert(request, reply) {
        const {
            page,
            itemPerPage,
            role,
            userId,
            accountId
        } = request.query;

        Bookshelf.knex.raw(`call GetAlert(${page},${itemPerPage},'${role}',${userId},${accountId})`)
            .then((result) => {
                if (result !== null) {
                    const dataAlert = result[0][0];
                    dataAlert.forEach(item => {
                        item.isRead = bufferToBoolean(item.isRead);
                        item.img = hasValue(item.img) ? item.img.toString() : "";
                        item.IsSelfService = bufferToBoolean(item.IsSelfService);
                    });
                    const data = {
                        dataAlert,
                        dataTotalRecords: result[0][1][0].TotalRecords
                    };
                    reply(data);
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
    //update Mask as read or unread
    updateMaskAsReadOrUnread(request, reply) {
        const progressLog = request.payload;
        const isReadUpdate = {
            isRead: progressLog.isRead,
            progressLogId: progressLog.progressLogId
        };

        OrderProgressLog.where({
            ProgressLogId: progressLog.progressLogId
        }).save(isReadUpdate, {
            method: "update"
        }).then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });

            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
        return;
    }

    markAsRead(request, reply) {
        const data = request.payload;
        const rawSql = `update order_progress_log set IsRead = ${data.isMarkAsRead} where ProgressLogId = ${data.ProgressLogId}`;
        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getAllDataAlert(request, reply) {
        const {
            page,
            itemPerPage,
            role,
            userId,
            accountId,
            isSelfService
        } = request.query;


        const newIsSelfService = (isSelfService || null);

        Bookshelf.knex.raw(`call GetAllAlert(${page},${itemPerPage},'${role}',${userId},${accountId},${newIsSelfService})`)
            .then((result) => {
                if (result !== null) {
                    const dataAlert = result[0][0];
                    dataAlert.forEach(item => {
                        item.isRead = bufferToBoolean(item.isRead);
                    });
                    const data = {
                        dataAlert,
                        dataTotalRecords: result[0][1][0].TotalRecords
                    };
                    reply(data);
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getPositionAlert(request, reply) {
        const {
            role,
            userId,
            alertId,
            accountId,
            isSelfService
        } = request.query;

        const newIsSelfService = (isSelfService || null);

        const rawSql = `SELECT GetAlertPosition('${role}', ${userId}, ${alertId}, ${accountId}, ${newIsSelfService}) as position;`;

        Bookshelf.knex.raw(rawSql)
            .then(data => {
                const dataAlert = {};
                const position = data[0][0].position;
                if (position % 5 === 0) {
                    dataAlert.page = position / 5;
                    dataAlert.positionOfAlert = 5;
                } else {
                    dataAlert.page = Math.floor(position / 5) + 1;
                    dataAlert.positionOfAlert = position % 5;
                }
                reply(dataAlert);
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getListUsers(request, reply) {
        const {
            OrderId
        } = request.query;

        const rawSql = `SELECT GetUserIdByIdAndRole(o.BrokerId, 'client', null) as BrokerUserId, 
        GetUserIdByIdAndRole(o.SignerId, 'vendor', null) as VendorUserId, 
        GetUserIdByIdAndRole(o.AgentId, 'client', true) as AgentUserId,
        GetUserIdByIdAndRole(o.RepId, 'staff', null) as StaffUserId
        FROM \`order\` o where o.OrderId = ${OrderId}`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    const listUsers = [];
                    const item = result[0][0];

                    Object.keys(item).forEach(element => listUsers.push(item[element]));

                    reply({
                        listUsers
                    });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

}

export default new OrderProgressLogController();