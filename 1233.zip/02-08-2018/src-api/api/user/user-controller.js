import User, {
	resetPassword
} from "../../db/model/users";
import Agent from "../../db/model/agents";
import Employees from "../../db/model/employees";
import ReturnAddress from "../../db/model/return-addr";
import Broker from "../../db/model/brokers";
import Signer from "../../db/model/signers";
import SecAnswers from "../../db/model/sec-answers";
import moment from "moment";
import Bookshelf from "../../db/database";
import {
	AUTH
} from "../../constant/common-constant";

import Boom from "boom";
import Jwt from "../../lib/jwt";
import RolePermission from "../../db/model/roles";
import UserRole from "../../db/model/user-roles";

import {
	hasStringValue,
	hasValue,
	bookshelfError,
	bufferToBoolean,
	handleSingleQuote,
	removePhoneMask
} from "../../helper/common-helper";

import ClientDetail from "../../db/model/client-detail";
import BrokerDetail from "./../../db/model/broker-detail";

// import BrokerTrainingReq from "../../db/model/broker_training_req";

import {
	encryptAes256Cbc,
	createUserValidationToken,
	gpwd
} from "../../helper/crypto-helper";

import {
	createUser,
	userTokenVerification,
	sendUserVerificationEmail,
	sendPasswordForgotEmail,
	sendClientInviteEmail,
	sendEmailHelper
} from "../../db/model/users";

import {
	SECURITY
} from "../../constant/common-constant";

import {
	savePayments
} from "../../helper/payment-helper";
import Payment from "../../db/model/payments";

class UserController {
	constructor() { }

	saveStaffProfile(request, reply) {
		const {
			profile,
			userId,
			accountId
		} = request.payload;

		if (!hasValue(profile) || !hasStringValue(userId) || !hasStringValue(accountId)) {
			reply(Boom.badRequest("Missing required values"));
			return;
		}

		const employee = {
			FirstName: profile.firstName,
			LastName: profile.lastName,
			Ext: profile.ext || null,
			// eslint-disable-next-line
			ProfilePicture: Buffer.from(profile.img, "utf8")
		};

		const updateEmployee = () => {
			Employees.where({
				RepId: userId
			}).save(employee, {
				method: "update"
			}).then(() => {
				// finish, return to client
				reply({
					isSuccess: true
				});
				return;
			}).catch(error => reply(Boom.badRequest(error)));
		};

		if (hasStringValue(profile.newPassword) || hasStringValue(profile.currentPassword) || hasStringValue(profile.confirmPassword)) {
			// check current password first
			User.where({
				UsersId: accountId
			}).fetch({
				columns: ["HashSalt", "Password"]
			})
				.then((user) => {
					if (user === null) {
						reply(Boom.badRequest(`Can not find this user`));
						return;
					}

					const {
						HashSalt,
						Password
					} = user.attributes;

					if (!Jwt.checkPassword(Password, HashSalt, profile.currentPassword)) {
						reply({
							isSuccess: false,
							validationError: [{
								field: "currentPassword",
								message: "The current password is not matched."
							}]
						});
						return;
					}

					if (Jwt.checkPassword(Password, HashSalt, profile.newPassword)) {
						reply({
							isSuccess: false,
							validationError: [{
								field: "newPassword",
								message: "The new password must be different from the current password."
							}]
						});
						return;
					}

					// current password is correct
					// then, update new password
					User.where({
						UsersId: accountId
					}).save({
						Password: Jwt.hash(profile.newPassword, HashSalt)
					}, {
							method: "update"
						}).then(() => {
							// done update password => update employee
							updateEmployee(employee);
							return;
						});
				}).catch(error => reply(Boom.badRequest(error)));
		} else {
			// update only employee
			updateEmployee(employee);
		}
	}

	getStaffInfo(request, reply) {
		const {
			accountId,
			userId
		} = request.query;

		User.where({
			UsersId: accountId
		}).fetch({
			columns: ["UsersId", "UserName"]
		})
			.then((account) => {
				if (account === null) {
					reply(Boom.badRequest(AUTH.UNAVAILABLE_USER));
					return;
				}

				const {
					UserName
				} = account.attributes;

				// get user information
				Employees.where({
					RepId: userId
				})
					.fetch({
						columns: ["Email", "FirstName", "LastName", "Ext", "ProfilePicture"]
					})
					.then((profile) => {
						if (profile === null) {
							reply(Boom.badRequest(AUTH.UNAVAILABLE_USER));
							return;
						}

						const {
							FirstName,
							LastName,
							Email,
							Ext,
							ProfilePicture
						} = profile.attributes;

						reply({
							firstName: FirstName,
							lastName: LastName,
							email: Email,
							ext: Ext,
							username: UserName,
							img: hasValue(ProfilePicture) ? ProfilePicture.toString() : ""
						});
						return;
					})
					.catch((error) => {
						reply(error);
						return;
					});
			});
	}

	checkExistUser(request, reply) {
		const {
			username
		} = request.query;
		User.where({
			username
		}).count("*").then((count) => {
			const isExist = count > 0;
			reply({
				isExist
			});
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return;
	}

	resetPassword(request, reply) {
		const {
			mappingUserId,
			roleName,
			roleType
		} = request.query;
		const rawSqlGetUsername = `select GetUserNameByIdAndRole(${mappingUserId}, '${roleType}', ${roleName === "Agent" ? true : false}) as username;`;


		Bookshelf.knex.raw(rawSqlGetUsername).then((roleResult) => {
			if (roleResult[0] && roleResult[0][0]) {
				const userName = roleResult[0][0].username;
				resetPassword(userName, 0, (identity) => {
					if (roleName === "Agent") {
						reply({
							isSuccess: true
						});

						// eslint-disable-next-line
						Agent.where({
							agentId: mappingUserId
						}).fetch({
							columns: ["email", "fullName"]
						})
							// eslint-disable-next-line
							.then((agent) => {
								const {
									email,
									fullName
								} = agent.attributes;
								const emailParams = {
									email,
									emailPurpose: "Reset Password by TCE - Agent",
									receiver: "Agent",
									needBindData: {
										AgentName: fullName,
										Username: identity.username,
										Password: identity.newPass
									}
								};
								sendEmailHelper(emailParams);
								// eslint-disable-next-line
							}).catch((error) => {
								reply(Boom.badRequest(error));
							});
					}
					if (roleName === "Client") {
						reply({
							isSuccess: true
						});
						Broker.where({
							BrokerID: mappingUserId
						}).fetch({
							columns: ["company", "email", "primaryContactFirst", "primaryContactLast"]
						})
							// eslint-disable-next-line
							.then((client) => {
								const {
									email,
									primaryContactFirst,
									primaryContactLast
								} = client.attributes;
								const emailParams = {
									email,
									emailPurpose: "Reset Password by TCE - Cient",
									receiver: "Client",
									needBindData: {
										ClientName: `${primaryContactFirst} ${primaryContactLast}`,
										Username: identity.username,
										Password: identity.newPass
									}
								};
								sendEmailHelper(emailParams);
							});
					}
				}, (err) => reply(Boom.badRequest(err)));
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	resetPasswordByUserId(request, reply) {
		const {
			param
		} = request.query;
		const sql = `select users.UsersId, users.HashSalt from users where \`users\`.UsersId = ${param};`;

		Bookshelf.knex.raw(sql).then(result => {
			const UsersId = result[0][0].UsersId;
			const HashSalt = result[0][0].HashSalt;
			const hashedPassword = Jwt.hash("SIGNING", HashSalt);
			User.where({
				UsersId
			}).save({
				Password: hashedPassword,
				LastUpdate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
			}, {
					method: "update"
				}).then(() => {
					reply({
						isSuccess: true
					});
				}).catch((error) => {
					reply(Boom.badRequest(error));
				});
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	generateDefaultLogin(request, reply) {
		const {
			userName,
			mappingUserId,
			roleName,
			type
		} = request.query;
		RolePermission.where({
			roleName,
			type
		}).fetch().then((roleResult) => {
			if (roleResult && roleResult.attributes) {
				const roleId = roleResult.attributes.RoleId;
				const salt = Jwt.generateSalt();
				const hashedPassword = Jwt.hash("SIGNING", salt);
				new User().save({
					UserName: userName,
					Password: hashedPassword,
					MappingUserId: mappingUserId,
					HashSalt: salt,
					DateCreated: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
					TenantId: 1,
					Inactive: 0
				}, {
						method: "insert"
					}).then((data) => {
						new UserRole().save({
							UsersId: data.attributes.id,
							RoleId: roleId
						}, {
								method: "insert"
							}).then(() => {
								reply({
									username: data.attributes.UserName,
									isSuccess: true
								});
								Broker.where({
									BrokerID: mappingUserId
								}).fetch({
									columns: ["company", "email"]
								})
									// eslint-disable-next-line
									.then((client) => {
										const {
									company,
											email
								} = client.attributes;
										const emailParams = {
											userName,
											password: "SIGNING",
											email,
											clientName: company
										};
										sendEmailHelper(emailParams);
									});
							}).catch((error) => {
								reply(Boom.badRequest(error));
							});
					}).catch((error) => {
						reply(Boom.badRequest(error));
					});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	addClientUser(request, reply) {
		if (!request.payload) reply(Boom.badRequest("Invalid Model"));

		const {
			accountInfoData,
			contactInformation,
			billing,
			industryId,
			url
		} = request.payload;
		const identify = {};



		//add broker
		new Broker().save({
			TenantId: 1, // default
			Company: accountInfoData.company,
			PrimaryContactFirst: accountInfoData.firstName,
			PrimaryContactLast: accountInfoData.lastName,
			Email: accountInfoData.email,
			EmailOpt: contactInformation.email,
			TextOpt: contactInformation.SMS,
			IndustryId: industryId,
			Phone: contactInformation.primaryPhone,
			City: contactInformation.city,
			Suite: contactInformation.suite,
			State: contactInformation.state,
			PrimaryContactExt: contactInformation.primaryPhoneExt,
			Address: contactInformation.streetAddress,
			Zip: contactInformation.zip,
			PrimaryContactFax: contactInformation.fax,
			Program: 2, //prime program
			IsAvailable: true,
			AssignOrdersDirectly: accountInfoData.AssignOrdersDirectly,
			TceFullFill: accountInfoData.Fulfill
		}, {
				method: "insert"
			}).then(async (newBroker) => {
				if (newBroker) {
					identify.brokerId = newBroker.id; //get new brokerId
				}

				const {
				paymentMethod,
					billingInformation
			} = billing;
				const {
				creditCard,
					paypal
			} = paymentMethod;

				// find out which credit card is default
				// then, save payments
				const payments = creditCard.payments.map(item => {
					if (item.paymentId === creditCard.defaultPayment) {
						item.isDefault = true;
					}

					return item;
				}).concat(paypal.payments);

				savePayments(identify.brokerId, payments);

				// add data to broker_detail
				new BrokerDetail()
					.save({
						BrokerId: identify.brokerId,
						AfterHoursPhone: removePhoneMask(contactInformation.afterHoursPhone.value),
						Cell: removePhoneMask(contactInformation.mobilePhone.value),
						Website: contactInformation.web,
						// billing
						APCellPhone: removePhoneMask(billingInformation.mobilePhone.value),
						APAfterHourPhone: removePhoneMask(billingInformation.afterHoursPhone.value),
						APExt: billingInformation.primaryExt.value,
						APAfterHourExt: billingInformation.afterHoursPhoneExt.value,
						AfterHoursPhoneExt: contactInformation.afterHoursPhoneExt,
						APFax: removePhoneMask(billingInformation.fax.value),
						APEmail: billingInformation.email.value,
						APInv: billingInformation.paymentMethods.value,
						APFirst: billingInformation.firstName.value,
						APLast: billingInformation.lastName.value,
						APContactPhone: removePhoneMask(billingInformation.primaryPhone.value),
						APContactFax: removePhoneMask(billingInformation.fax.value),
						APContactEmail: billingInformation.email.value,
						APTerms: billingInformation.paymentTerms.value,
						APAddress: billingInformation.address.value,
						APSuite: billingInformation.suite.value,
						APCity: billingInformation.city.value,
						APZip: billingInformation.zip.value,
						APState: billingInformation.state.value
					}, {
						method: "insert"
					})
					.then(() => { })
					.catch(err => {
						reply(Boom.badRequest(err));
						return;
					});

				//add user
				createUser({
					userName: accountInfoData.username,
					password: accountInfoData.password,
					mappingId: identify.brokerId
				},
					(success) => {
						identify.userId = success.userId;
						identify.token = success.token;

						// add answer
						new SecAnswers().save({
							UserId: identify.userId,
							ChalId1: accountInfoData.question1,
							Answer1: accountInfoData.answer1,
							ChalId2: accountInfoData.question2,
							Answer2: accountInfoData.answer2,
							ChalId3: accountInfoData.question3,
							Answer3: accountInfoData.answer3
						}, {
								method: "insert"
							})
							.then((resultAnswer) => {
								if (resultAnswer !== null) {
									new UserRole().save({
										UsersId: identify.userId,
										RoleId: 5 // Vendor RoleId
									},
										// eslint-disable-next-line
										{
											method: "insert"
										}).then((resultRole) => {
											const emailParams = {
												userId: identify.userId,
												email: accountInfoData.email,
												firstName: accountInfoData.firstName,
												lastName: accountInfoData.lastName,
												token: identify.token,
												url
											};
											sendUserVerificationEmail(emailParams);

											reply({
												isSuccess: true,
												userId: identify.userId
											});
											// eslint-disable-next-line
										}).catch((error) => {
											reply(Boom.badRequest(error));
										});
								}
							}, (error) => {
								reply(Boom.badRequest(error));
							});
					});
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	resendVerificationUserEmail(request, reply) {
		const {
			userId,
			email,
			firstName,
			lastName,
			url
		} = request.payload;
		const tokenBytes = createUserValidationToken(userId);
		const token = encryptAes256Cbc(tokenBytes);

		const emailParams = {
			userId,
			email,
			firstName,
			lastName,
			token,
			url
		};

		const userAddedToken = {
			EmailVerificationToken: token
		};

		User.where({
			UsersId: userId
		}).save(userAddedToken, {
			method: "update"
		}).then((update) => {
			if (update !== null) {
				sendUserVerificationEmail(emailParams);

				reply({
					isSuccess: true
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});


	}

	// add new vendor
	addVendor(request, reply) {
		const {
			vendor,
			url
		} = request.payload;
		const identify = {};

		// add signer
		new Signer().save({
			TenantId: 1, // default
			FirstName: vendor.firstName,
			LastName: vendor.lastName,
			Company: vendor.companyName,
			CompanyType: vendor.companyType,
			Email: vendor.email,
			TaxID: vendor.ssnTaxId,
			EmailOpt: vendor.emailOpt,
			RegistrationStep: 1,
			Rating: 6 // Hard Code -> New field
		}, {
				method: "insert"
			})
			.then((resultSigner) => {
				if (resultSigner !== null) {
					identify.signerId = resultSigner.id; // save signerId
					// add user
					const params = {
						userName: vendor.userName,
						password: vendor.password,
						mappingId: identify.signerId
					};
					createUser(params, (success) => {
						identify.userId = success.userId;
						identify.token = success.token;
						// add answer
						new SecAnswers().save({
							UserId: identify.userId,
							ChalId1: vendor.chalId1,
							Answer1: vendor.answer1,
							ChalId2: vendor.chalId2,
							Answer2: vendor.answer2,
							ChalId3: vendor.chalId3,
							Answer3: vendor.answer3
						}, {
								method: "insert"
							})
							.then((resultAnswer) => {
								if (resultAnswer !== null) {
									new UserRole().save({
										UsersId: identify.userId,
										RoleId: 8 // Vendor RoleId
									},
										// eslint-disable-next-line
										{
											method: "insert"
										}).then((resultRole) => {
											const emailParams = {
												userId: identify.userId,
												email: vendor.email,
												firstName: vendor.firstName,
												lastName: vendor.lastName,
												token: identify.token,
												url
											};
											sendUserVerificationEmail(emailParams);

											reply({
												userId: identify.userId,
												isSuccess: true
											});
											// eslint-disable-next-line
										}).catch((error) => {
											reply(Boom.badRequest(error));
										});
								}
							})
							.catch(err => {
								reply(Boom.badRequest(err));
							});
					}, (err) => {
						reply(Boom.badRequest(err));
					});
				}
			})
			.catch((error) => {
				reply(Boom.badRequest(error));
				return;
			});
	}

	// add new branch
	addBranch(request, reply) {
		const branch = request.payload;
		const identify = {};
		const salt = Jwt.generateSalt();
		const hashedPassword = Jwt.hash(branch.password, salt);

		new Broker().save({
			TenantId: 1, // default unknow
			GID: branch.GID,
			Company: branch.company,
			Phone: branch.phone,
			Address: branch.address,
			Suite: branch.suite,
			City: branch.city,
			State: branch.state,
			Zip: branch.zip,
			AdministratorFirst: branch.adminFirst,
			AdministratorLast: branch.adminLast,
			AdministratorExt: branch.adminExt,
			AdministratorEmail: branch.adminEmail,
			PrimaryContactFirst: branch.contactFirst,
			PrimaryContactLast: branch.contactLast,
			Email: branch.contactEmail,
			PrimaryContactExt: branch.contactExt,
			PrimaryContactFax: branch.contactFax,
			DefaultCourierID: branch.courierId,
			DefaultCourierAcnt: branch.courierAccount,
			IsAvailable: 1,
			Inactive: 0
		}, {
				method: "insert"
			}).then((brokerResult) => {
				if (brokerResult !== null) {
					identify.brokerId = brokerResult.id;
					new User().save({
						TenantId: 1, // default
						UserName: handleSingleQuote(branch.userName),
						Password: hashedPassword,
						HashSalt: salt,
						MappingUserId: identify.brokerId,
						DateCreated: moment().utc().format("YYYY-MM-DD HH:mm:ss")
					}, {
							method: "insert"
						}).then((userResult) => {
							// add list return address
							const listReturnAddr = branch.listReturnAddr.map((item) => {
								item.BrokerId = identify.brokerId;
								return item;
							});
							const ReturnAddressObj = Bookshelf.Collection.extend({
								model: ReturnAddress
							});
							const returnAddress = ReturnAddressObj.forge(listReturnAddr);

							returnAddress.invokeThen("save").then(() => {
								new UserRole().save({
									UsersId: userResult.id,
									RoleId: 6 // Branch RoleId
								},
									// eslint-disable-next-line
									{
										method: "insert"
									}).then((resultRole) => {

										reply({
											brokerId: identify.brokerId,
											userId: userResult.id,
											isSuccess: true
										});
										// eslint-disable-next-line
									}).catch((error) => {
										reply(Boom.badRequest(error));
									});
							}).catch(error => {
								reply(Boom.badRequest(error));
							});
						}).catch((error) => {
							reply(Boom.badRequest(error));
							return;
						});
					return;
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
				return;
			});
	}

	getBillingInformationDefault(request, reply) {
		const {
			accountId,
			userId,
			roleType
		} = request.query;

		if (!hasStringValue(accountId) || !hasStringValue(userId) || !hasStringValue(roleType)) {
			reply(Boom.badRequest(`Missing required values`));
			return;
		}

		const getClientBillingInformation = () => {
			const sql = `CALL GetClientBillingInformation(${userId});`;

			Bookshelf.knex.raw(sql)
				.then((result) => {
					const brokerDetails = result[0][0];
					const couriers = result[0][1];

					if (brokerDetails.length === 0) {
						reply(Boom.badRequest(`Broker ${userId} does not exist`));
						return;
					}

					reply({
						user: brokerDetails[0],
						couriers
					});
				}).catch(err => {
					reply(Boom.badRequest(bookshelfError(err)));
					return;
				});
		};

		switch (roleType) {
			case "Client":
				getClientBillingInformation(reply, accountId, userId);
				break;
			default:
				reply(Boom.badRequest(`Role type ${roleType} is not implemented.`));
				break;
		}
	}

	updateBillingInformation(request, reply) {
		const {
			firstName,
			lastName,
			contactPhone,
			contactFax,
			contactEmail,
			paymentTerm,
			accountPayableRepresentative,
			accountPayablePhoneNumber,
			faxNumber,
			emailAddress,
			courierMethod,
			account,
			extension,
			inv,
			paymentId
		} = request.payload;

		const {
			brokerId
		} = request.query;

		const brokerDetail = {
			APRep: accountPayableRepresentative,
			APRepPhone: accountPayablePhoneNumber,
			APExt: extension,
			APFax: faxNumber,
			APEmail: emailAddress,
			APFirst: firstName,
			APLast: lastName,
			APContactPhone: contactPhone,
			APContactFax: contactFax,
			APContactEmail: contactEmail,
			APTerms: paymentTerm,
			Inv: inv,
			PaymentMethodId: paymentId
		};

		const broker = {
			DefaultCourierID: courierMethod,
			DefaultCourierAcnt: account
		};

		const updateBrokerMore = Promise.resolve(ClientDetail.where({
			BrokerId: brokerId
		}).save(brokerDetail, {
			method: "update"
		}));
		const updateBroker = Promise.resolve(Broker.where({
			BrokerID: brokerId
		}).save(broker, {
			method: "update"
		}));

		Promise.all([updateBroker, updateBrokerMore])
			.then(() => {
				reply({
					isSuccess: true
				});
				return;
			})
			.catch((err) => {
				reply(Boom.badRequest(bookshelfError(err)));
				return;
			});
	}

	getAdditionalInformationDefault(request, reply) {
		const {
			accountId,
			userId,
			roleType
		} = request.query;

		if (!hasStringValue(accountId) || !hasStringValue(userId) || !hasStringValue(roleType)) {
			reply(Boom.badRequest(`Missing required values`));
			return;
		}

		const getClientAdditionalInformation = () => {
			const sql = `call GetClientAdditionalInformation(${userId});`;

			Bookshelf.knex.raw(sql)
				.then((result) => {
					const brokerDetails = result[0][0] || [];
					const couriers = result[0][1] || [];
					const training = result[0][2] || [];
					const vendorExp = result[0][3] ? result[0][3][0] || {} : {};
					const trainingData = result[0][4] || [];
					const listRating = result[0][5] || [];

					if (brokerDetails.length === 0) {
						reply(Boom.badRequest(`Broker ${userId} does not exist`));
						return;
					}

					const returnData = brokerDetails[0];
					returnData.SigningServiceUse = bufferToBoolean(brokerDetails[0].SigningServiceUse);
					returnData.OvernightDelivery = bufferToBoolean(brokerDetails[0].OvernightDelivery);
					returnData.SecureEmailDelivery = bufferToBoolean(brokerDetails[0].SecureEmailDelivery);
					returnData.DocLocationDelivery = bufferToBoolean(brokerDetails[0].DocLocationDelivery);
					returnData.UploadDocDelivery = bufferToBoolean(brokerDetails[0].UploadDocDelivery);
					returnData.AssignOrdersDirectly = bufferToBoolean(brokerDetails[0].AssignOrdersDirectly);
					returnData.TceFullFill = bufferToBoolean(brokerDetails[0].TceFullFill);
					returnData.SetApptTime = brokerDetails[0].SetApptTime ? Number(brokerDetails[0].SetApptTime) : null;

					reply({
						additionalInfoDefault: returnData,
						couriers,
						training,
						vendorExp,
						trainingData,
						listRating
					});
				}).catch(err => {
					reply(Boom.badRequest(err));
					return;
				});
		};

		switch (roleType) {
			case "Client":
				getClientAdditionalInformation(reply, accountId, userId);
		}
	}

	getUserBranchById(request, reply) {
		const {
			brokerId
		} = request.query;
		User.where({
			MappingUserId: brokerId
		}).fetch({
			columns: [
				"UserName"
			]
		}).then((result) => {
			reply(result);
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	updateAdditionalInformation(request, reply) {
		const {
			data,
			brokerId
		} = request.payload;
		const brokerDetailData = data;
		const courierData = brokerDetailData.DefaultCourier === 0 ? null : brokerDetailData.DefaultCourier;
		const assignOrdersDirectly = brokerDetailData.assignOrdersDirectly;
		const tceFullFill = brokerDetailData.tceFullFill;

		delete brokerDetailData.DefaultCourier;
		delete brokerDetailData.assignOrdersDirectly;
		delete brokerDetailData.tceFullFill;
		delete brokerDetailData.vendorRequired;


		const updateTableBrokerDetail = Promise.resolve(BrokerDetail.where({
			BrokerId: brokerId
		}).save(brokerDetailData, {
			method: "update"
		}));
		const updateTableBroker = Promise.resolve(Broker.where({
			BrokerID: brokerId
		}).save({
			DefaultCourierID: courierData,
			AssignOrdersDirectly: assignOrdersDirectly,
			TceFullFill: tceFullFill
		}, {
				method: "update"
			}));

		Promise.all([updateTableBroker, updateTableBrokerDetail])
			.then(() => {
				reply({
					isSuccess: true
				});
				return;
			})
			.catch((err) => {
				reply(Boom.badRequest(bookshelfError(err)));
				return;
			});

	}

	emailVerification(request, reply) {
		const {
			userId,
			token
		} = request.payload;
		const params = {
			userId,
			token
		};
		userTokenVerification(params, (success) => {
			reply({
				isValid: success.isSuccess
			});
		}, (error) => {
			reply(Boom.badRequest(error));
		});
		return;
	}

	resendEmailVerification(request, reply) {
		const params = request.payload;
		// params: userId, email, firstName, lastName, url

		// get token
		User.where({
			UsersId: params.userId
		}).fetch({
			columns: ["EmailVerificationToken"]
		})
			.then((result) => {
				const token = result.attributes.EmailVerificationToken;
				const emailParams = {
					userId: params.userId,
					email: params.email,
					firstName: params.firstName,
					lastName: params.lastName,
					token,
					url: params.url
				};
				sendUserVerificationEmail(emailParams);
			}).catch(error => reply(Boom.badRequest(error)));
	}

	checkSignerFirstLogin(request, reply) {
		const {
			signerId
		} = request.query;

		Signer.where({
			SignerId: signerId
		}).fetch({
			columns: ["RegistrationStep"]
		}).then((result) => {
			reply({
				isFirstLogin: result.attributes.RegistrationStep < 8
			});
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getClientsUserByRole(request, reply) {
		let {
			role,
			clientId
		} = request.query;

		role = handleSingleQuote(role);
		clientId = handleSingleQuote(clientId);

		Bookshelf.knex.raw(`call GetClientsUserByRole('${role}',${clientId});`)
			.then(value => {
				reply(value[0][0]);
				return reply;
			}).catch(err => {
				reply(Boom.badRequest(err));
				return reply;
			});
	}

	async updateUserStatus(request, reply) {
		const {
			usersId,
			status,
			// gid,
			role
		} = request.payload;

		if (!hasStringValue(role)) {
			reply({
				isSuccess: false
			});
			return;
		}

		// update user status
		User.where({
			UsersId: usersId
		}).save({
			Status: status
		}, {
				method: "update"
			})
			.then(() => {
				// get list of related people
				// Bookshelf.knex.raw(`call GetFollowingPeople('${role}',${usersId}, ${gid});`)
				//     .then(value => {
				//         reply({ isSuccess: true, followingPeople: value[0][0] });
				//     }).catch(err => {
				//         reply(Boom.badRequest(err));
				//     });

				reply({
					isSuccess: true
				});
			})
			.catch((err) => reply(Boom.badRequest(err)));
	}

	checkUserCreds(request, reply) {
		const {
			creds
		} = request.query;

		Bookshelf.knex.raw(`call CheckUserCreds('${creds}')`)
			.then((result) => {
				if (result !== null) {
					let userId;
					let username;
					let email;
					if (result[0][1][0].TotalRecords > 0) {
						userId = result[0][0][0].UsersId;
						username = result[0][0][0].UserName;
						email = result[0][0][0].Email;
					} else {
						userId = 0;
						username = "";
						email = "";
					}
					reply({
						total: result[0][1][0].TotalRecords,
						userId,
						username,
						email
					});
					return;
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
				return;
			});
	}

	sendForgotPasswordEmail(request, reply) {
		const securityCode = Math.floor((Math.random() * 10)).toString() + Math.floor((Math.random() * 10)).toString() + Math.floor((Math.random() * 10)).toString() + Math.floor((Math.random() * 10)).toString() + Math.floor((Math.random() * 10)).toString() + Math.floor((Math.random() * 10)).toString();
		const securityCreatedDate = moment().utc().format("YYYY-MM-DD HH:mm:ss");

		const params = request.payload;
		// params: userId, email, url

		const newUser = {
			SecurityCode: securityCode,
			SecurityCreatedDate: securityCreatedDate
		};

		const mailObj = {
			email: params.email,
			url: params.url,
			code: securityCode
		};

		sendPasswordForgotEmail(mailObj);

		User.where({
			UsersId: params.userId
		}).save(newUser, {
			method: "update"
		}).then((result) => {
			if (result !== null) {
				reply({
					isSuccess: true
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	checkForgotPasswordSecurityCode(request, reply) {
		const {
			securityCode
		} = request.query;

		User.where({
			SecurityCode: securityCode
		}).fetch({
			columns: ["UsersId", "UserName", "SecurityCreatedDate"]
		}).then((result) => {
			if (result !== null) {
				const now = new Date().getTime();
				const date = new Date(result.attributes.SecurityCreatedDate).getTime();
				if (now - date < SECURITY.SECURITY_CODE_EXPIRATION_TIME) {
					reply({
						isValid: true,
						userId: result.attributes.UsersId,
						username: result.attributes.UserName
					});
				} else {
					reply({
						isValid: false,
						isExpired: true
					});
				}
			} else {
				reply({
					isValid: false,
					isExpired: false
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	changePassword(request, reply) {
		const {
			userId,
			payload
		} = request.payload;
		const {
			oldPassword,
			newPassword
		} = payload;

		// check if the current user is matched
		User.where({
			UsersId: userId
		})
			.fetch({
				columns: ["Password", "HashSalt"]
			})
			.then((result) => {
				const {
					Password,
					HashSalt,
					Username
				} = result.attributes;

				if (Jwt.checkPassword(Password, HashSalt, oldPassword)) {
					// do save password
					const salt = Jwt.generateSalt();
					const hashedPassword = Jwt.hash(newPassword, salt);

					const newUser = {
						HashSalt: salt,
						Password: hashedPassword,
						SecurityCode: null,
						SecurityCreatedDate: null,
						NeedToResetPassword: false,
						LastUpdate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
					};

					User.where({
						UsersId: userId
					}).save(newUser, {
						method: "update"
					})
						.then((rs) => {
							if (rs !== null) {
								reply({
									isSuccess: true,
									username: Username
								});
							}
						}).catch((error) => {
							reply(Boom.badRequest(error));
						});
				} else {
					reply({
						isSuccess: false
					});
				}
			})
			.catch((error) => {
				reply(Boom.badRequest(error));
			});


	}

	changeUserPassword(request, reply) {
		const params = request.payload;
		// params: userId, password

		const salt = Jwt.generateSalt();
		const hashedPassword = Jwt.hash(params.password, salt);

		const newUser = {
			HashSalt: salt,
			Password: hashedPassword,
			SecurityCode: null,
			SecurityCreatedDate: null,
			LastUpdate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
		};

		User.where({
			UsersId: params.userId
		}).save(newUser, {
			method: "update"
		}).then((result) => {
			if (result !== null) {
				reply({
					isSuccess: true
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	checkUserFirstLogin(request, reply) {
		const {
			userId
		} = request.query;

		User.where({
			UsersId: userId,
			Logged: null,
			NeedToResetPassword: false
		}).count("*").then((count) => {
			if (count > 0) {
				const newUser = {
					Logged: 1
				};
				User.where({
					UsersId: userId
				}).save(newUser, {
					method: "update"
				}).then((result) => {
					if (result !== null) {
						reply({
							isFirstLogin: true
						});
					}
				}).catch((error) => {
					reply(Boom.badRequest(error));
				});
			} else {
				reply({
					isFirstLogin: false
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	checkUserNeedToResetPassword(request, reply) {
		const {
			userId
		} = request.query;

		User.where({
			UsersId: userId,
			NeedToResetPassword: true
		}).count("*").then((count) => {
			if (count > 0) {
				reply({
					needResetPassword: true,
					userId
				});
			} else {
				reply({
					needResetPassword: false
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	clientInviteUser(request, reply) {
		const {
			email,
			role,
			brokerId
		} = request.query;
		const newBroker = {
			Email: email,
			TenantId: 1,
			GID: role === "5" ? 0 : brokerId
		};
		const newAgent = {
			Email: email,
			TenantId: 1, // default,
			BrokerId: brokerId
		};

		if (role === "5" || role === "6") {
			new Broker().save(newBroker, {
				method: "insert"
			}).then((result) => {
				if (result !== null) {
					let password = "";
					const possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

					// generate random string
					for (let i = 0; i < 8; i++) {
						password += possible.charAt(Math.floor(Math.random() * possible.length));
					}

					const salt = Jwt.generateSalt();
					const hashedPassword = Jwt.hash(password, salt);
					const username = `${role === "5" ? "Client" : "Branch"}${result.id}`;
					const newUser = {
						TenantId: 1, // default
						UserName: username,
						Password: hashedPassword,
						HashSalt: salt,
						MappingUserId: result.id,
						DateCreated: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
						Inactive: 0,
						NeedToResetPassword: true
					};

					new User().save(newUser, {
						method: "insert"
					}).then((user) => {
						if (user !== null) {
							const roleId = role === "5" ? 5 : 6;
							new UserRole().save({
								UsersId: user.id,
								RoleId: roleId
							}, {
									method: "insert"
								}).then(() => {
									const params = {
										role: `${role === "5" ? "Sub-Admin" : "Branch/Division"}`,
										email,
										username,
										password
									};
									sendClientInviteEmail(params);
								}).catch((error) => {
									reply(Boom.badRequest(error));
									return;
								});
						} else {
							reply(null);
						}
					}).catch((error) => {
						reply(Boom.badRequest(error));
						return;
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
				return;
			});
		} else {
			new Agent().save(newAgent, {
				method: "insert"
			}).then((result) => {
				if (result !== null) {
					let password = "";
					const possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

					// generate random string
					for (let i = 0; i < 8; i++) {
						password += possible.charAt(Math.floor(Math.random() * possible.length));
					}

					const salt = Jwt.generateSalt();
					const hashedPassword = Jwt.hash(password, salt);
					const username = `Agent${result.id}`;
					const newUser = {
						TenantId: 1, // default
						UserName: username,
						Password: hashedPassword,
						HashSalt: salt,
						MappingUserId: result.id,
						DateCreated: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
						Inactive: 0,
						NeedToResetPassword: true
					};

					new User().save(newUser, {
						method: "insert"
					}).then((user) => {
						if (user !== null) {
							const roleId = 7;
							new UserRole().save({
								UsersId: user.id,
								RoleId: roleId
							}, {
									method: "insert"
								}).then(() => {
									const params = {
										role: "Agent",
										email,
										username,
										password
									};
									sendClientInviteEmail(params);
								}).catch((error) => {
									reply(Boom.badRequest(error));
									return;
								});
						} else {
							reply(null);
						}
					}).catch((error) => {
						reply(Boom.badRequest(error));
						return;
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
				return;
			});
		}
	}

	resetUserPassword(request, reply) {
		const params = request.payload;
		// params: userId, password

		const salt = Jwt.generateSalt();
		const hashedPassword = Jwt.hash(params.password, salt);

		const newUser = {
			HashSalt: salt,
			Password: hashedPassword,
			NeedToResetPassword: false
		};

		User.where({
			UsersId: params.userId
		}).save(newUser, {
			method: "update"
		}).then((result) => {
			if (result !== null) {
				reply({
					isSuccess: true
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	checkPasswordExpired(request, reply) {
		const {
			userId
		} = request.query;

		User.where({
			UsersId: userId
		}).fetch({
			columns: ["LastUpdate"]
		}).then((result) => {
			if (result !== null && result.attributes.LastUpdate !== null) {
				const days = moment().utc().diff(result.attributes.LastUpdate, "days");

				if (days > 90) {
					reply({
						isExpired: true
					});
				} else {
					reply({
						isExpired: false
					});
				}
			} else {
				reply({
					isExpired: true
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	checkResetPasswordSecurityCode(request, reply) {
		const {
			securityCode
		} = request.payload;
		User.where({
			securityCode
		}).fetch({
			columns: ["usersId", "username", "securityCreatedDate"]
		}).then(model => {
			let isValid = false;
			let usersId = 0;
			let username = "";
			if (model && model.get("usersId")) {
				usersId = model.get("usersId");
				username = model.get("username");
				const securityCodeCreatedDateAdd24Hours = moment(model.get("securityCreatedDate")).add(24, "hours");
				isValid = securityCodeCreatedDateAdd24Hours > moment();
			}

			reply({
				isValid,
				usersId,
				username
			});
		});
	}

	fetchBillingInformation(request, reply) {
		const {
			userId
		} = request.query;

		// get broker id from user
		User.where({
			userId
		}).fetch({
			columns: ["mappingUserId"]
		}).then(async user => {
			if (user && user.get("mappingUserId")) {
				const model = {};

				// get billing information from broker detail
				await BrokerDetail.where({
					brokerId: user.get("mappingUserId")
				})
					.fetch().then(() => {
						model.BrokerDetail = {
							name: "hello"
						};
					}).catch(err => reply(Boom.badRequest(err)));

				// get payment methods
				await Payment.where({
					brokerId: user.get("mappingUserId")
				})
					.fetch().then(() => {
						model.payments = {
							name: "payments"
						};
					}).catch(err => reply(Boom.badRequest(err)));

				reply(model);
			}
		}).catch(err => reply(Boom.badRequest(err)));
	}

	getProfilePicture(request, reply) {
		const {
			id
		} = request.query;
		const rawSql = `select ProfilePicture from employees where RepId = ${id};`;
		Bookshelf.knex.raw(rawSql)
			.then(value => {
				reply({
					profilePicture: hasValue(value[0][0].ProfilePicture) ? value[0][0].ProfilePicture.toString() : ""
				});
			}).catch(err => {
				reply(Boom.badRequest(err));
			});
	}

	getClientBilling(request, reply) {
		const {
			clientId
		} = request.query;

		if (!clientId) {
			reply({
				data: []
			});
		}

		const rawSql = `SELECT BrokerId, APCellPhone, AfterHoursPhone,APExt,APAfterHourExt,APFax,APEmail,APInv,APFirst,
								APLast,APContactPhone,APContactFax,APContactEmail,APTerms,APAddress,APSuite,APCity,APZip,APState
						FROM broker_detail where BrokerId = ${clientId};`;
		Bookshelf.knex.raw(rawSql)
			.then(value => {
				reply({
					data: value[0][0]
				});
			}).catch(err => {
				reply(Boom.badRequest(err));
			});
	}
}

export default new UserController();