import Bookshelf from "../../db/database";
import Boom from "boom";

import Order from "../../db/model/order";
import OrderFeeApproval from "../../db/model/order-fee-approve";
import OrderFee from "../../db/model/order-fee";
import OrderProgressLog from "../../db/model/order-progress-log";
import OrderFeeApproveReason from "../../db/model/order-fee-approve-reason";
import SignerOffer from "../../db/model/signer-offer";
import Signer from "../../db/model/signers";

import { ORDER_FEE_VENDOR_REQUEST_STATUS, OFFER_STATUS } from "./../../constant/common-constant";
import { ORDER_PROGRESS_ID } from "./../../constant/progress-constant";
import { bufferToBoolean, handleSingleQuoteRawSql, isBuffer, replaceAll, hasStringValue } from "../../helper/common-helper";
import { NOTIFICATION_TEMPLATE_PURPOSE } from "../../constant/common-constant";
import sendMailCore from "../../mail/mail-helper";
import moment from "moment";


class OrderRequestApprovalController {
    constructor() { }

    checkVendorAssignConditionsOfOrder(request, reply) {
        const { orderId, signerId } = request.query;

        //get order aptDateTime
        Order.where({ orderId }).fetch({ columns: ["aptDateTime", "isVenOrCEDefineADT", "signerId", "progressId"] }).then((order) => {
            if (order.attributes.progressId === ORDER_PROGRESS_ID.CLOSED_PENDING_CLIENT_REVIEW ||
                order.attributes.progressId === ORDER_PROGRESS_ID.CLOSED_PENDING_QC_REVIEW ||
                order.attributes.progressId === ORDER_PROGRESS_ID.CLOSED_PENDING_REVIEW_PC_RESOLUTION ||
                order.attributes.progressId === ORDER_PROGRESS_ID.CLOSING_COMPLETED ||
                order.attributes.progressId === ORDER_PROGRESS_ID.CANCELED) {
                reply({
                    case: "CLOSED_ORDER"
                });
                return;
            }

            if (!hasStringValue(signerId)) {
                reply({
                    case: "SUCCESS"
                });
                return;
            }

            //get signer's Order's aptDateTime
            Order.where({ signerId }).fetchAll({ columns: ["aptDateTime", "isVenOrCEDefineADT", "progressId", "orderId"] }).then((assignedOrders) => {
                //compare -> if duplicated -> return ADT_DUPLICATED
                if (assignedOrders !== null) {
                    for (let i = 0; i < assignedOrders.length; i++) {
                        const assignedOrder = assignedOrders.models[i];

                        if (Number(assignedOrder.attributes.orderId) === Number(orderId)) continue;

                        if (assignedOrder.attributes.aptDateTime !== null && !bufferToBoolean(assignedOrder.attributes.isVenOrCEDefineADT) &&
                            order.attributes.aptDateTime !== null && !bufferToBoolean(order.attributes.isVenOrCEDefineADT) &&
                            assignedOrder.attributes.aptDateTime.toString() === order.attributes.aptDateTime.toString() &&
                            assignedOrder.attributes.progressId !== ORDER_PROGRESS_ID.CLOSED_PENDING_QC_REVIEW &&
                            assignedOrder.attributes.progressId !== ORDER_PROGRESS_ID.CLOSED_PENDING_REVIEW_PC_RESOLUTION &&
                            assignedOrder.attributes.progressId !== ORDER_PROGRESS_ID.CLOSING_COMPLETED &&
                            assignedOrder.attributes.progressId !== ORDER_PROGRESS_ID.POST_CLOSE &&
                            assignedOrder.attributes.progressId !== ORDER_PROGRESS_ID.CANCELED
                        ) {
                            reply({
                                case: "ADT_DUPLICATED"
                            });
                            return;
                        }
                    }
                }

                //already have signer
                if (order.attributes.signerId !== null && order.attributes.signerId !== undefined && order.attributes.signerId !== "" && Number(order.attributes.signerId) !== Number(signerId)) {
                    reply({
                        case: "SIGNER_ALREADY"
                    });
                    return;
                }
                reply({
                    case: "SUCCESS"
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    async approveFeeRequest(request, reply) {
        const payload = request.payload;
        const feeApproval = {
            feeApprovalId: payload.feeApprovalId,
            orderId: payload.orderId,
            feeApprovalDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            feeApproved: payload.isApprove ? ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED : ORDER_FEE_VENDOR_REQUEST_STATUS.REJECTED,
            approvedBy: payload.usersId
        };
        const order = {
            orderId: payload.orderId,
            signerId: hasStringValue(payload.signerId) ? payload.signerId : undefined,
            progressId: ORDER_PROGRESS_ID.ASSIGNED_TO_VENDOR,
            filledDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            isSelfService: payload.isSelfService
        };
        const orderFee = {
            signerFee: payload.signerFee,
            signerId: hasStringValue(payload.signerId) ? payload.signerId : undefined,
            feeDescripId: payload.feeDescripId,
            orderId: payload.orderId
        };
        const progressLog = {
            activity: payload.activity,
            progressType: payload.progressType,
            usersId: payload.usersId,
            orderId: payload.orderId,
            dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        };
        const offer = {
            offerId: payload.offerId,
            offerStatus: payload.isApprove ? OFFER_STATUS.ACCEPTED : OFFER_STATUS.DECLINED,
            offerAmount: payload.isApprove ? payload.requestAmount : payload.originalAmount
        };

        const mailTemplates = {};

        let currentSignerId = 0;

        await new Promise(resolve => Order.where({ orderId: order.orderId }).fetch({ columns: ["signerId"] }).then((model) => {
            currentSignerId = model.get("signerId");
            resolve();
        }));

        const sendMail = (data, mailTemplate) => {
            let html = mailTemplate.Message;
            let subject = mailTemplate.Subject;

            Object.keys(data.needBindData).forEach(key => {
                html = replaceAll(html, `[${key}]`, hasStringValue(data.needBindData[key]) ? data.needBindData[key] : "");
                subject = replaceAll(subject, `[${key}]`, hasStringValue(data.needBindData[key]) ? data.needBindData[key] : "");
            });

            const mailOptions = {
                from: mailTemplate.FromEmail || "weborders@notarydirect.com",
                to: data.email,
                subject,
                html
            };

            sendMailCore(mailOptions);
        };

        const preSendMail = async (data) => {

            const templateKey = `${data.purpose}-${data.receiver}`;

            if (!mailTemplates[templateKey]) {
                const rawSqlGetTemplate = `SELECT * FROM notification_templates nt WHERE nt.Purpose = '${handleSingleQuoteRawSql(data.purpose)}' AND nt.Receiver = '${data.receiver}';`;

                const result = await Bookshelf.knex.raw(rawSqlGetTemplate);

                mailTemplates[templateKey] = result[0][0];
            }
            const mailTemplate = mailTemplates[templateKey];
            sendMail(data, mailTemplate);

        };

        const sendMailRejectToVendor = (signerId) => {

            const sendMailToVendor = new Promise(() => {
                Signer.where({ signerId })
                    .fetch({ columns: ["firstName", "lastName", "email"] }).then(signer => {
                        const signerInfo = signer ? signer.attributes : {};
                        const email = signerInfo.email;

                        const mailData = {
                            purpose: NOTIFICATION_TEMPLATE_PURPOSE.REJECTE_FEE_REQUEST_BY_VENDOR,
                            email,
                            receiver: "Vendor",
                            needBindData: {
                                VendorName: `${hasStringValue(signerInfo.firstName) ? signerInfo.firstName : ``} ${hasStringValue(signerInfo.lastName) ? signerInfo.lastName : ``}`,
                                OrderID: hasStringValue(payload.orderId) ? payload.orderId : ``,
                                description: hasStringValue(payload.reason) ? payload.reason : ``,
                                OriginalFee: hasStringValue(payload.originalAmount) ? payload.originalAmount : ``,
                                ExpectedFee: hasStringValue(payload.requestAmount) ? payload.requestAmount : ``
                            }
                        };

                        preSendMail(mailData);

                    }).catch();


            });

            Promise.all([sendMailToVendor]);
        };

        // const sendMailApproveToVendor = (signerId) => {
        //     if (!hasStringValue(payload.offerId)) {
        //         return;
        //     }
        //     const sqlGetOrderInfo = `SELECT SO.OfferAmount, L.LoanType, O.OrderId, O.AptDateTime, O.City,
        //     (69.1*SQRT(POWER(Z2.Lat-Z1.Lat, 2) + 0.6*POWER(Z2.Long - Z1.Long, 2))) AS Distance
        //     FROM \`order\` O
        //     INNER JOIN signer S ON O.OrderId=${payload.orderId} AND S.SignerId = ${signerId}
        //     LEFT JOIN loan_type L ON L.LoanTypeId = O.LoanType
        //     LEFT JOIN zip Z1 ON O.Zip = Z1.Zip
        //     LEFT JOIN zip Z2 ON S.WeekdayZip  = Z2.Zip
        //     LEFT JOIN signer_offer SO ON SO.OrderID = O.OrderId
        //     WHERE SO.OfferID = ${payload.offerId}`;

        //     Bookshelf.knex.raw(sqlGetOrderInfo).then(result => {
        //         const orderInfo = result[0][0];

        //         Signer.where({ signerId })
        //             .fetch({ columns: ["firstName", "lastName", "email"] }).then(signer => {
        //                 const signerInfo = signer ? signer.attributes : {};
        //                 const email = signerInfo.email;

        //                 const mailData = {
        //                     purpose: NOTIFICATION_TEMPLATE_PURPOSE.OFFER_ACCEPTED_VENDOR,
        //                     email,
        //                     receiver: "Vendor",
        //                     needBindData: {
        //                         vendorFirstName: hasStringValue(signerInfo.firstName) ? signerInfo.firstName : ``,
        //                         vendorLastName: hasStringValue(signerInfo.lastName) ? signerInfo.lastName : ``,
        //                         orderId: hasStringValue(orderInfo.OrderId) ? orderInfo.OrderId : ``,
        //                         type: hasStringValue(orderInfo.LoanType) ? orderInfo.LoanType : ``,
        //                         aptDateTime: hasStringValue(orderInfo.AptDateTime) ? orderInfo.AptDateTime : ``,
        //                         city: hasStringValue(orderInfo.City) ? orderInfo.City : ``,
        //                         distance: hasStringValue(orderInfo.Distance) ? orderInfo.Distance : ``,
        //                         offerAmount: hasStringValue(orderInfo.OfferAmount) ? orderInfo.OfferAmount : ``
        //                     }
        //                 };

        //                 preSendMail(mailData);

        //             }).catch();

        //     }).catch();
        // };

        const sendMailRejectToAgent = (userId, signerId) => {
            const sendMailToVendor = new Promise(() => {
                const sqlSelectAgentInfo = `SELECT a.email, a.fullName
				FROM agent a
				INNER JOIN users u ON a.AgentId = u.MappingUserId
                WHERE u.UsersId = ${userId}`;
                Bookshelf.knex.raw(sqlSelectAgentInfo).then(agentResult => {
                    const agentInfo = agentResult[0][0];

                    Signer.where({ signerId })
                        .fetch({ columns: ["firstName", "lastName", "email"] }).then(signer => {
                            const signerInfo = signer ? signer.attributes : {};
                            const email = agentInfo.email;

                            const mailData = {
                                purpose: NOTIFICATION_TEMPLATE_PURPOSE.REJECTE_FEE_REQUEST_BY_VENDOR,
                                email,
                                receiver: "Client Agent",
                                needBindData: {
                                    VendorName: `${hasStringValue(signerInfo.firstName) ? signerInfo.firstName : ``} ${hasStringValue(signerInfo.lastName) ? signerInfo.lastName : ``}`,
                                    OrderID: hasStringValue(payload.orderId) ? payload.orderId : ``,
                                    description: hasStringValue(payload.reason) ? payload.reason : ``,
                                    OriginalFee: hasStringValue(payload.originalAmount) ? payload.originalAmount : ``,
                                    ExpectedFee: hasStringValue(payload.requestAmount) ? payload.requestAmount : ``,
                                    AgentName: hasStringValue(agentInfo.fullName) ? agentInfo.fullName : ``
                                }
                            };

                            preSendMail(mailData);

                            const mailDataForVendor = Object.assign({}, mailData);
                            mailDataForVendor.needBindData = Object.assign({}, mailData.needBindData);
                            mailDataForVendor.receiver = "Vendor";
                            mailDataForVendor.email = signerInfo.email;
                            delete mailDataForVendor.needBindData.AgentName;
                            setTimeout(() => preSendMail(mailDataForVendor), 1000);

                        }).catch();
                }).catch();

            });

            Promise.all([sendMailToVendor]);
        };

        const sendMailApproveToAgent = (userId, signerId) => {
            const sendMailToVendor = new Promise(() => {
                const sqlSelectAgentInfo = `SELECT a.email, a.fullName
				FROM agent a
				INNER JOIN users u ON a.AgentId = u.MappingUserId
                WHERE u.UsersId = ${userId}`;
                Bookshelf.knex.raw(sqlSelectAgentInfo).then(agentResult => {

                    const agentInfo = agentResult[0][0];

                    Signer.where({ signerId })
                        .fetch({ columns: ["firstName", "lastName", "email"] }).then(signer => {
                            const signerInfo = signer ? signer.attributes : {};
                            const email = agentInfo.email;

                            const mailData = {
                                purpose: NOTIFICATION_TEMPLATE_PURPOSE.APPROVE_FEE_REQUEST_BY_AGENT,
                                email,
                                receiver: "Client Agent",
                                needBindData: {
                                    VendorName: `${hasStringValue(signerInfo.firstName) ? signerInfo.firstName : ``} ${hasStringValue(signerInfo.lastName) ? signerInfo.lastName : ``}`,
                                    OrderID: hasStringValue(payload.orderId) ? payload.orderId : ``,
                                    description: hasStringValue(payload.reason) ? payload.reason : ``,
                                    OriginalFee: hasStringValue(payload.originalAmount) ? payload.originalAmount : ``,
                                    ExpectedFee: hasStringValue(payload.requestAmount) ? payload.requestAmount : ``,
                                    AgentName: hasStringValue(agentInfo.fullName) ? agentInfo.fullName : ``
                                }
                            };

                            setTimeout(() => preSendMail(mailData), 1000);

                        }).catch();
                }).catch();

            });

            Promise.all([sendMailToVendor]);
        };

        const updateOthersFeeRequest = () => {
            const sqlGetOtherFeeRequest = `SELECT feeApprovalId, offerId, signerID, usersId, IsUserVendor(usersId) as requestByVendor from order_fee_approve WHERE feeApproved = '${ORDER_FEE_VENDOR_REQUEST_STATUS.PENDING}' AND orderId = ${feeApproval.orderId}`;
            Bookshelf.knex.raw(sqlGetOtherFeeRequest)
                .then((data) => {
                    const otherOrder = data[0];

                    const rejectOthersVendorFeeRequest = (feeRequest) => {
                        let result = "success";
                        const { feeApprovalId, offerId, signerID } = feeRequest;

                        OrderFeeApproval
                            .where({ feeApprovalId })
                            .save({ feeApproved: ORDER_FEE_VENDOR_REQUEST_STATUS.REJECTED }, { method: "update" })
                            .then(() => {
                                //send rejected mail here
                                if (isBuffer(feeRequest.requestedByVendor)) {
                                    feeRequest.requestedByVendor = bufferToBoolean(feeRequest.requestedByVendor);
                                }
                                if (feeRequest.requestedByVendor) {
                                    sendMailRejectToVendor(signerID);
                                } else {
                                    sendMailRejectToAgent(feeRequest.usersId, feeRequest.signerID);
                                }

                                if (offerId !== null && offerId !== undefined && offerId !== offer.offerId) {
                                    SignerOffer
                                        .where({ offerId })
                                        .save({ offerStatus: OFFER_STATUS.DECLINED }, { method: "update" })
                                        .then(() => {
                                            //send offer declined here
                                        })
                                        .catch((error) => {
                                            result = error;
                                        });
                                }
                            })
                            .catch((error) => {
                                result = error;
                            });

                        return result;
                    };

                    let error = "success";
                    for (let i = 0; i < otherOrder.length; i++) {
                        const feeRequest = otherOrder[i];

                        const result = rejectOthersVendorFeeRequest(feeRequest);

                        if (result !== "success") {
                            error = result;
                        }
                    }

                    if (error !== "success") {
                        reply(Boom.badRequest(error));
                        return;
                    } else {

                        reply({ isSuccess: true });
                        return;
                    }
                })
                .catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                });
        };

        const updateOtherInfo = (trsn) => {
            if (feeApproval.feeApproved === ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED) {
                const addProgressLog = () => {
                    new OrderProgressLog()
                        .save(progressLog, { method: "insert", transacting: trsn })
                        .then(() => {
                            trsn.commit();

                        })
                        .catch((error) => {
                            trsn.rollback(error);
                        });
                };

                const getFeeApprovalInfor = `SELECT signerId from order_fee_approve where feeApprovalId = ${feeApproval.feeApprovalId}`;
                Bookshelf.knex.raw(getFeeApprovalInfor)
                    .then((data) => {
                        const requestedByVendor = data[0][0].signerId > 0;
                        if (currentSignerId === order.signerId || !requestedByVendor) {
                            OrderFee
                                .where({ orderId: orderFee.orderId, feeDescripId: orderFee.feeDescripId })
                                .save(orderFee, { method: "update", require: true, transacting: trsn })
                                .then(() => {
                                    // Order
                                    //     .where({ OrderId: order.orderId })
                                    //     .save(order, { method: "update", require: true, transacting: trsn })
                                    //     .then(() => {
                                    addProgressLog();
                                    // })
                                    // .catch((error) => {
                                    //     trsn.rollback(error);
                                    // });
                                })
                                .catch((error) => {
                                    trsn.rollback(error);
                                });
                        } else {
                            addProgressLog();
                        }
                    });
            } else {
                new OrderProgressLog().save(progressLog, { method: "insert", transacting: trsn })
                    .then(() => {
                        trsn.commit();
                    })
                    .catch((error) => {
                        trsn.rollback(error);
                    });
            }
        };

        if (order.signerId && payload.isApprove) {
            // await logNotificationAndSendToVendor(order.orderId, order.signerId, false);
        }

        // AnNV2: UCS26
        const rejectOtherRequestsTce = async () => {
            // reject other requests
            const otherRequestsSql = `UPDATE \`order_fee_approve\` SET FeeApproved='Rejected', FeeApprovalDate=CURRENT_TIMESTAMP(), ApprovedBy=${feeApproval.approvedBy} 
                                    WHERE OrderID=${order.orderId} AND FeeApproved='Pending' AND IsClientFee=false;`;

            const toListSql = `SELECT e.FirstName, e.LastName, e.Email, GetTotalAdditionalVendorFee(ofa.OrderId, ofa.FeeDescripId) + IFNULL(FeeAmount, 0) AS ExpectedFee,
                                CONCAT_WS(' ', \`s\`.\`FirstName\`, \`s\`.\`LastName\`) AS VendorName, OfferId
                                FROM \`order_fee_approve\` ofa 
                                INNER JOIN \`users\` u on ofa.UsersId = u.UsersId
                                INNER JOIN \`employees\` e ON u.MappingUserId = e.RepId
                                LEFT JOIN \`signer\` s ON ofa.SignerId = s.SignerID
                                WHERE ofa.OrderId=${order.orderId} AND FeeApproved='Pending' AND IsClientFee=false AND GetUserType(u.UsersId) = 'Staff'`;

            const toListResult = await Bookshelf.knex.raw(toListSql);

            if (toListResult && toListResult[0]) {
                const receiverList = toListResult[0];
                let offersList = "";

                Bookshelf.knex.raw(otherRequestsSql)
                    .then(() => {
                        // send mail to tce scheduler/Status/QC
                        for (let i = 0; i < receiverList.length; i++) {
                            if (receiverList[i].OfferId) {
                                offersList = `${offersList},${receiverList[i].OfferId} `;
                            }

                            if (!hasStringValue(receiverList[i].Email)) continue;

                            const mailData = {
                                purpose: NOTIFICATION_TEMPLATE_PURPOSE.TCES_FEE_REQUEST_REJECTED,
                                email: receiverList[i].Email,
                                receiver: "TCE",
                                needBindData: {
                                    VendorName: receiverList[i].VendorName,
                                    OrderId: order.orderId,
                                    FirstName: hasStringValue(receiverList[i].FirstName) ? receiverList[i].FirstName : '',
                                    LastName: hasStringValue(receiverList[i].LastName) ? receiverList[i].LastName : '',
                                    Description: "N/A",
                                    OriginalFee: hasStringValue(payload.originalAmount) ? payload.originalAmount : ``,
                                    ExpectedFee: hasStringValue(receiverList[i].ExpectedFee) ? receiverList[i].ExpectedFee : ``
                                }
                            };

                            preSendMail(mailData);
                        }

                        // Reject all offer  
                        if (hasStringValue(offersList)) {
                            offersList = offersList.substring(1); // offersList = "2, 3, 4"

                            const declineOfferSql = `UPDATE \`signer_offer\` SET OfferStatus='${OFFER_STATUS.DECLINED}' WHERE OrderId=${order.orderId} AND OfferId in (${offersList}) AND OfferStatus='P';`;
                            Bookshelf.knex.raw(declineOfferSql)
                                .then(() => {

                                    return true;
                                })
                                .catch(() => {
                                    return false;
                                });
                        } else {

                            return true;
                        }
                    })
                    .catch((error) => {
                        return false;
                    });
            }
        }

        const sendMailToTceScheduler = (approve) => {
            const repId = payload.requestedBy;

            if (!repId) return;

            const employeeSql = `SELECT e.Email, e.FirstName, e.LastName FROM \`employees\` e 
                                INNER JOIN \`users\` u ON e.RepId = u.MappingUserId
                                WHERE u.UsersId = ${payload.requestedBy} AND GetUserType(u.UsersId) = 'Staff';`;

            Bookshelf.knex.raw(employeeSql)
                .then((result) => {
                    if (result && result[0] && result[0][0]) {
                        const employee = result[0][0];

                        const mailData = {
                            purpose: approve ? NOTIFICATION_TEMPLATE_PURPOSE.TCES_FEE_REQUEST_APPROVED : NOTIFICATION_TEMPLATE_PURPOSE.TCES_FEE_REQUEST_REJECTED,
                            email: employee.Email,
                            receiver: "TCE",
                            needBindData: {
                                VendorName: hasStringValue(payload.vendorName) ? payload.vendorName : '',
                                OrderId: order.orderId,
                                FirstName: hasStringValue(employee.FirstName) ? employee.FirstName : '',
                                LastName: hasStringValue(employee.LastName) ? employee.LastName : '',
                                Description: hasStringValue(payload.reason) ? payload.reason : '',
                                OriginalFee: hasStringValue(payload.originalAmount) ? payload.originalAmount : '',
                                ExpectedFee: hasStringValue(payload.requestAmount) ? payload.requestAmount : ''
                            }
                        }

                        preSendMail(mailData);
                    }
                })
        }

        Bookshelf.transaction((trsn) => {
            OrderFeeApproval
                .where({ feeApprovalId: feeApproval.feeApprovalId, feeApproved: ORDER_FEE_VENDOR_REQUEST_STATUS.PENDING })
                .save(feeApproval, { method: "update", require: true, transacting: trsn })
                .then(() => {

                    if (offer.offerId !== null && offer.offerId !== undefined) {
                        SignerOffer
                            .where(feeApproval.feeApproved === ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED
                                ? { offerId: offer.offerId, offerStatus: OFFER_STATUS.PENDING }
                                : { offerId: offer.offerId })
                            .save(offer, { method: "update", require: true, transacting: trsn })
                            .then(() => {
                                updateOtherInfo(trsn);
                            })
                            .catch((error) => {
                                trsn.rollback(error);
                            });
                    } else {
                        updateOtherInfo(trsn);
                    }
                }).catch((error) => {
                    trsn.rollback(error);
                });
        })
            .then(() => {
                //send approve or decline mail here mail here
                // AnNV2: update for UCS 26
                // if order is full service, only send mail to scheduler/status rep/QC who submitted the request
                if (!order.isSelfService) {
                    // if a request is approved, all other requests will be rejected
                    if (feeApproval.feeApproved === ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED) {
                        rejectOtherRequestsTce();
                    }

                    sendMailToTceScheduler(feeApproval.feeApproved === ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED);

                    reply({ isSuccess: true });
                } else { // self service
                    if (feeApproval.feeApproved === ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED) {
                        updateOthersFeeRequest();

                        // send mail approve request fee
                        // if (payload.requestedByVendor) {
                        //     sendMailApproveToVendor(payload.signerId);
                        // } else {
                        sendMailApproveToAgent(payload.requestedBy, payload.signerId);
                        //     sendMailApproveToVendor(payload.signerId);
                        // }
                    } else {

                        if (payload.requestedByVendor) {
                            sendMailRejectToVendor(payload.signerId);
                        } else {
                            sendMailRejectToAgent(payload.requestedBy, payload.signerId);
                        }

                        reply({ isSuccess: true });
                        return;
                    }
                }
            })
            .catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }


    submitFeeRequestToMgr(request, reply) {
        const payload = request.payload;
        const feeApproval = {
            feeApprovalId: payload.feeApprovalId,
            usersId: payload.usersId,
            dateStamp: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        };

        Bookshelf.transaction((trsn) => {
            OrderFeeApproval.where({ feeApprovalId: feeApproval.feeApprovalId, feeApproved: ORDER_FEE_VENDOR_REQUEST_STATUS.PENDING })
                .save(feeApproval, { method: "update", require: true, transacting: trsn })
                .then(() => {
                    trsn.commit();
                    reply({ isSuccess: true });
                    return;
                }).catch((error) => {
                    trsn.rollback(error);
                    reply(Boom.badRequest(error));
                    return;
                });
        });
    }

    getOrderFeeApprovalReasonStaff(request, reply) {
        const columns = ["ReasonCode", "ReasonDescription"];

        OrderFeeApproveReason.where({ Type: "S" }).fetchAll({ columns }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true, result });
                return;
            }
            reply({ isSuccess: false, message: "No record found!" });
            return;
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    sendMailWhenSubmitToManager(request, reply) {
        const { orderId, signerId, originalAmount, requestAmount, vendorName, reason } = request.payload;

        const managerNameSql = `SELECT CONCAT_WS(" ",B.PrimaryContactFirst, B.PrimaryContactLast) AS ManagerName, B.Email
        FROM \`order\` O INNER JOIN broker B ON O.BrokerId = B.BrokerID AND O.OrderId = ${orderId};`;

        const rawSql = `select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'submit fee request to manager sent by agent';`;

        Bookshelf.knex.raw(managerNameSql)
            .then((data) => {
                const managerName = data[0][0].ManagerName;
                const managerEmail = data[0][0].Email;

                Bookshelf.knex.raw(rawSql)
                    .then((message) => {
                        let html = message[0][0].message;

                        html = replaceAll(html, `[managerFullName]`, hasStringValue(managerName) ? managerName : "");
                        html = replaceAll(html, `[orderId]`, hasStringValue(orderId) ? orderId : "");
                        html = replaceAll(html, `[repId]`, hasStringValue(signerId) ? signerId : "");
                        html = replaceAll(html, `[originalFee]`, hasStringValue(originalAmount) ? originalAmount : "");
                        html = replaceAll(html, `[expectedFee]`, hasStringValue(requestAmount) ? requestAmount : "");
                        html = replaceAll(html, `[vendorFullName]`, hasStringValue(vendorName) ? vendorName : "");
                        html = replaceAll(html, `[Description]`, hasStringValue(reason) ? reason : "");

                        const mailVendorOptions = {
                            html,
                            from: message[0][0].fromEmail,
                            to: managerEmail,
                            subject: replaceAll(message[0][0].subject, `[orderId]`, hasStringValue(orderId) ? orderId : ""),
                            text: `Send Email`
                        };
                        sendMailCore(mailVendorOptions);

                        reply({ isSuccess: true });
                        return;
                    })
                    .catch(() => {
                        reply({ isSuccess: true });
                        return;
                    });
            })
            .catch(() => {
                reply({ isSuccess: true });
                return;
            });
    }

    // UCS 26: Approve/Reject request client fee
    async processClientFeeRequest(request, reply) {
        const payload = request.payload;

        const feeApproval = {
            feeApprovalId: payload.feeApprovalId,
            orderId: payload.orderId,
            feeApprovalDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            feeApproved: payload.isApprove ? ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED : ORDER_FEE_VENDOR_REQUEST_STATUS.REJECTED
        };

        const orderFee = {
            feeDescripId: payload.feeDescripId,
            orderId: payload.orderId,
            brokerFee: payload.brokerFee
        };

        const progressLog = {
            activity: payload.activity,
            progressType: payload.progressType,
            usersId: payload.usersId,
            orderId: payload.orderId,
            dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        };

        const mergedData = {
            userId: payload.requestedBy,
            orderId: payload.orderId || 0,
            description: payload.reason || "",
            originalFee: payload.originalAmount || 0,
            expectedFee: payload.requestAmount || 0,
            companyName: payload.clientCompanyName || ""
        }

        const sendMail = (data, mailTemplate) => {
            if (!mailTemplate) {
                console.log("__TEMPLATE_NOT_FOUND__");
                return;
            }

            let html = mailTemplate.Message;
            let subject = mailTemplate.Subject;

            Object.keys(data.needBindData).forEach(key => {
                html = replaceAll(html, `[${key}]`, hasStringValue(data.needBindData[key]) ? data.needBindData[key] : "");
                subject = replaceAll(subject, `[${key}]`, hasStringValue(data.needBindData[key]) ? data.needBindData[key] : "");
            });

            const mailOptions = {
                from: mailTemplate.FromEmail || "weborders@notarydirect.com",
                to: data.email,
                subject,
                html
            };

            sendMailCore(mailOptions);
        };

        const preSendMail = async (data) => {
            // Get email template
            const rawSqlGetTemplate = `SELECT FromEmail, Subject, Message  FROM notification_templates nt WHERE nt.Purpose = '${handleSingleQuoteRawSql(data.purpose)}' AND nt.Receiver = '${data.receiver}';`;
            const result = await Bookshelf.knex.raw(rawSqlGetTemplate);
            const mailTemplate = result[0][0];

            sendMail(data, mailTemplate);
        };

        const sendMailToScheduler = (orderId) => {
            const rawSql = `SELECT e.Email, e.FirstName, e.LastName FROM \`employees\` e LEFT JOIN \`users\` u ON e.RepId = u.MappingUserId WHERE u.UsersId = ${mergedData.userId || 0}`;

            Bookshelf.knex.raw(rawSql)
                .then(result => {
                    if (result && result[0] && result[0][0]) {
                        const purpose = feeApproval.feeApproved === ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED ? NOTIFICATION_TEMPLATE_PURPOSE.TCES_CLIENT_FEE_REQUEST_APPROVE : NOTIFICATION_TEMPLATE_PURPOSE.TCES_CLIENT_FEE_REQUEST_REJECTED;
                        const schedulerEmail = result[0][0].Email;
                        const firstName = result[0][0].FirstName;
                        const lastName = result[0][0].LastName;

                        const mailData = {
                            purpose,
                            email: schedulerEmail,
                            receiver: "TCE",
                            needBindData: {
                                OrderId: mergedData.orderId,
                                Description: mergedData.description,
                                OriginalFee: mergedData.originalFee,
                                ExpectedFee: mergedData.expectedFee,
                                CompanyName: mergedData.companyName,
                                FirstName: firstName,
                                LastName: lastName
                            }
                        };

                        preSendMail(mailData);
                    }
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                });
        };

        const addProgressLog = () => {
            new OrderProgressLog()
                .save(progressLog, { method: "insert" })
                .then(() => {
                    console.log("__APPROVE CLIENT FEE SUCCESSFULLY__");
                })
                .catch((error) => {
                    console.log(error);
                });
        }

        const updateOrderFee = (trsn) => {
            OrderFee
                .where({ orderId: orderFee.orderId, feeDescripId: orderFee.feeDescripId })
                .save(orderFee, { method: "update", require: true, transacting: trsn })
                .then(() => {
                    trsn.commit();
                })
                .catch((error) => {
                    trsn.rollback(error);
                });
        }

        Bookshelf.transaction((trsn) => {
            // #1 Change request status to Approve/Reject
            OrderFeeApproval
                .where({ feeApprovalId: feeApproval.feeApprovalId, feeApproved: ORDER_FEE_VENDOR_REQUEST_STATUS.PENDING, isClientFee: true })
                .save(feeApproval, { method: "update", require: true, transacting: trsn })
                .then(() => {
                    // #2 if the request is approved, change order client fee
                    if (feeApproval.feeApproved === ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED) {
                        updateOrderFee(trsn);
                    } else {
                        trsn.commit(); // commit
                    }
                }).catch((error) => {
                    trsn.rollback(error);
                });
        })
            .then(() => {
                // add a order log
                addProgressLog();

                // send email notification
                sendMailToScheduler(orderFee.orderId);

                reply({ isSuccess: true });
                return;
            })
            .catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    // if have a new client fee request from scheduler
    async sendEmailFeeRequestToTceManager(request, reply) {
        const sendMail = async (data, template) => {
            // get email template
            const emailRawSql = `SELECT FromEmail, Subject, Message  FROM notification_templates nt WHERE nt.Purpose = '${handleSingleQuoteRawSql(template)}' AND nt.Receiver = 'TCE';`;

            const emailResult = await Bookshelf.knex.raw(emailRawSql);

            if (!emailResult || !emailResult[0] || !emailResult[0][0]) {
                reply({
                    isSuccess: false,
                    message: "No email template found"
                });
                return;
            }

            const mailTemplate = emailResult[0][0];

            let html = mailTemplate.Message;
            let subject = mailTemplate.Subject;

            Object.keys(data.mergeFields).forEach(key => {
                html = replaceAll(html, `[${key}]`, hasStringValue(data.mergeFields[key]) ? data.mergeFields[key] : "");
                subject = replaceAll(subject, `[${key}]`, hasStringValue(data.mergeFields[key]) ? data.mergeFields[key] : "");
            });

            const mailOptions = {
                from: mailTemplate.FromEmail || "weborders@notarydirect.com",
                to: data.to,
                subject,
                html
            };

            sendMailCore(mailOptions);

            reply({
                isSuccess: true,
                message: ""
            });
        }

        /*------------------------------------*/
        const managerRawSql = `SELECT e.Email FROM \`employees\` e 
                                INNER JOIN \`users\` u ON e.RepId = u.MappingUserId 
                                INNER JOIN \`user_roles\` r ON u.UsersId = r.UsersId 
                                WHERE (r.RoleId = 2 or r.RoleId=1) AND e.Active = true AND (u.Inactive IS NULL OR u.Inactive = false);`;

        const result = await Bookshelf.knex.raw(managerRawSql);

        // no manage found
        if (!result || !result[0]) {
            reply({
                isSuccess: false,
                message: "No manager found"
            });

            return;
        }

        // no manage found
        const managerList = result[0];
        if (managerList === null) {
            reply({
                isSuccess: false,
                message: "No manager found"
            });

            return;
        }

        let toList = "";

        managerList.map((manager) => {
            if (manager.Email && !toList.includes(manager.Email)) {
                toList = `${toList},${manager.Email}`
            }
        })

        if (!toList) {
            reply({
                isSuccess: false,
                message: "No valid email found"
            });
            return;
        }


        // remove first comma
        toList = toList.substring(1);
        const { orderId, expectedFee, originalFee, companyName, reason, userId, isClientFee, vendorName } = request.payload;

        // Get scheduler's full name who requests
        let employeeName = "";
        const userRawSql = `SELECT e.FirstName, e.LastName FROM \`employees\` e INNER JOIN \`users\` u ON e.RepID = u.MappingUserId WHERE u.UsersId=${userId}`;
        const userResult = await Bookshelf.knex.raw(userRawSql);

        if (userResult && userResult[0] && userResult[0][0]) {
            employeeName = `${userResult[0][0].FirstName ? userResult[0][0].FirstName : ""} ${userResult[0][0].LastName ? userResult[0][0].LastName : ""}`;
        }

        let data = {};

        if (isClientFee) {
            data = {
                to: toList,
                mergeFields: {
                    OrderId: orderId,
                    ExpectedFee: expectedFee,
                    OriginalFee: originalFee,
                    CompanyName: companyName,
                    Description: reason,
                    RepID: employeeName
                }
            }
        } else {
            data = {
                to: toList,
                mergeFields: {
                    OrderId: orderId,
                    ExpectedFee: expectedFee,
                    OriginalFee: originalFee,
                    VendorName: vendorName,
                    Description: reason,
                    RepID: employeeName
                }
            }
        }



        const template = isClientFee ? NOTIFICATION_TEMPLATE_PURPOSE.TCES_CLIENT_FEE_REQUEST_SUBMITTED : NOTIFICATION_TEMPLATE_PURPOSE.TCES_FEE_REQUEST_SUBMITTED;

        sendMail(data, template);
    }
}

export default new OrderRequestApprovalController();