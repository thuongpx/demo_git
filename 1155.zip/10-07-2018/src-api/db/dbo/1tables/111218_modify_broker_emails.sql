ALTER TABLE `broker_emails` 
ADD COLUMN `EmailFor` VARCHAR(1) NULL AFTER `Email`;