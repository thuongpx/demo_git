DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	-- IsImportant
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'problem_types' AND 
                            COLUMN_NAME = 'IsImportant') THEN
	BEGIN
		ALTER TABLE `problem_types` ADD COLUMN `IsImportant` BIT;
	END;
    END IF;
    
    -- ParentId
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'problem_types' AND 
                            COLUMN_NAME = 'ParentId') THEN
	BEGIN
		ALTER TABLE `problem_types` ADD COLUMN `ParentId` INT;
	END;
    END IF;

END$$
DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;