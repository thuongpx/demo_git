DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
	-- Change column Name
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_detail' AND 
                            COLUMN_NAME = 'AfterHoursPhoneExt') THEN
	BEGIN
		ALTER TABLE `broker_detail` 
		ADD COLUMN `AfterHoursPhoneExt` varchar(10);
	END;
    END IF;
END$$

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;