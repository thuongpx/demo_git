-- Request from AnNV2
-- Add loan type
CREATE TABLE IF NOT EXISTS `order_fee_approve_reason` (
    `ReasonCode` INT(11) NOT NULL AUTO_INCREMENT,
    `ReasonDescription` VARCHAR(40),
	`Type` VARCHAR(1) NULL,
    PRIMARY KEY (`ReasonCode`)
);