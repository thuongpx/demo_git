CREATE TABLE IF NOT EXISTS `payments` (
  `PaymentId` int(11) NOT NULL,
  `Token` varchar(45) NOT NULL,
  `CustomerId` varchar(45) NOT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `CardType` varchar(50) DEFAULT NULL,
  `DateCreated` datetime NOT NULL,
  `DateModified` datetime NOT NULL,
  `Type` varchar(20) NOT NULL,
  PRIMARY KEY (`PaymentId`)
);
