CREATE TABLE IF NOT EXISTS `signer_docs`(
	DocId INT(11) NOT NULL AUTO_INCREMENT,
	SignerId INT NOT NULL,
	DocTypeId INT NOT NULL,
	State VARCHAR(2) NULL,
	DocName VARCHAR(150) NOT NULL,
	ExpireDate DATETIME NULL,
	UploadDate DATETIME NULL,
    IssuedDate DATETIME NULL,
	Approved BIT NULL,
	ApprovedBy VARCHAR(50) NULL,
	ApprovedDate DATETIME NULL,
	Rejected BIT NULL,
	Followup VARCHAR(50) NULL,
	RejectReason VARCHAR(800) NULL,
	SkyeDocId INT NULL,
    Number VARCHAR(30),
    PRIMARY KEY(`DocId`)
)