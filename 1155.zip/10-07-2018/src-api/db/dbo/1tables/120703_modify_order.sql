DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	-- IsSentVendorAppointmentPassed
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order' AND 
                            COLUMN_NAME = 'IsSentVendorAppointmentPassed') THEN
	BEGIN
		ALTER TABLE `order` ADD COLUMN `IsSentVendorAppointmentPassed` BIT;
	END;
    END IF;
    
    -- IsSentVendorNoDocumentUploaded 
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order' AND 
                            COLUMN_NAME = 'IsSentVendorNoDocumentUploaded') THEN
	BEGIN
		ALTER TABLE `order` ADD COLUMN `IsSentVendorNoDocumentUploaded` BIT;
	END;
    END IF;
END$$
DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;