DROP PROCEDURE IF EXISTS `alter_table_users`;

DELIMITER $$
CREATE PROCEDURE `alter_table_users` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'users' AND 
                            COLUMN_NAME = 'RefreshToken') THEN
	BEGIN
		ALTER TABLE `users` 
		ADD COLUMN `RefreshToken` VARCHAR(100) NULL;
	END;
    END IF;
    
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'users' AND 
                            COLUMN_NAME = 'RefreshTokenExpires') THEN
	BEGIN
		ALTER TABLE `users` 
		ADD COLUMN `RefreshTokenExpires` DATETIME NULL;
	END;
    END IF;
    
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'users' AND 
                            COLUMN_NAME = 'Logged') THEN
	BEGIN
		ALTER TABLE `users` 
		ADD COLUMN `Logged` BIT NULL;
	END;
    END IF;  
END$$

DELIMITER ;

call alter_table_users();

DROP PROCEDURE IF EXISTS `alter_table_users`;

