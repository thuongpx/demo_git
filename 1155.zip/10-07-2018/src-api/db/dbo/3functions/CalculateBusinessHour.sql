DROP FUNCTION IF EXISTS `CalculateBusinessHour`;

DELIMITER $$

CREATE FUNCTION `CalculateBusinessHour`(
startDateTime DATETIME, 
endDateTime DATETIME, 
timeZone INT
) RETURNS INT
BEGIN
	DECLARE startDateTimeLocal DATETIME;
    DECLARE startDateLocal DATE;
    DECLARE endDateTimeLocal DATETIME;
    DECLARE endDateLocal DATE;
    DECLARE currentDateTime DATETIME;
    DECLARE isClosed BIT;
    DECLARE isHoliday BIT;
    DECLARE dayOfWeek VARCHAR(50);
    
    DECLARE startCalculatedDateTime DATETIME;
    DECLARE endCalculatedDateTime DATETIME;
    
    DECLARE workStartTime TIME;
    DECLARE workEndTime TIME;
    
    DECLARE holidayOffStartTime TIME;
    DECLARE holidayOffEndTime TIME;
    
    DECLARE endCurrentDateTime DATETIME;
    DECLARE startCurrentDateTime DATETIME;
    
    DECLARE currentDate DATE;
    DECLARE currentTime TIME;
    
    DECLARE totalMinutes INT DEFAULT 0;
    
	SET startDateTimeLocal = DATE_ADD(startDateTime, INTERVAL timeZone HOUR);
    SET endDateTimeLocal = DATE_ADD(endDateTime, INTERVAL timeZone HOUR);
    SET endDateLocal =  DATE(endDateTimeLocal);
    SET startDateLocal = DATE(startDateTimeLocal);
    
    SET currentDateTime = startDateTimeLocal;
    SET currentDate = DATE(currentDateTime);
    SET currentTime = TIME(currentDateTime);
    
    WHILE(currentDate <= endDateLocal)
     DO
		
        SELECT TIME(bh.OpenTime),TIME(bh.CloseTime), bh.isClose
		INTO workStartTime, workEndTime, isClosed
        FROM business_hours bh WHERE bh.dayOfWeek = DAYOFWEEK(currentDateTime);
        
		SET startOfCurrentDateTime= CONVERT(CONCAT(currentDate,' ','00:00:00'), DATETIME);
        SET endOfCurrentDateTime= CONVERT(CONCAT(currentDate,' ','23:59:00'), DATETIME);
		
        SELECT bhe.CloseTime, bhe.OpenTime, (CASE WHEN COUNT(bhe.OpenTime) > 0 THEN 1 ELSE 0 END)
        INTO holidayOffEndTime, holidayOffStartTime, isHoliday FROM biz_hours_except bhe 
						WHERE currentDate BETWEEN DATE(bhe.OpenTime) AND DATE(bhe.CloseTime) LIMIT 0,1;
		
		IF(isClosed = 0 OR isClosed IS NULL) 
        THEN
			IF (currentDate <> startDateLocal AND currentDate <> endDateLocal)
				THEN SET startCalculatedDateTime = startOfCurrentDateTime;
					 SET endCalculatedDateTime = endOfCurrentDateTime;
            ELSEIF (currentDate = startDateLocal AND currentDate <> endDateLocal)
				THEN SET startCalculatedDateTime = currentDateTime;
					 SET endCalculatedDateTime = endOfCurrentDateTime;
			ELSEIF (currentDate <> startDateLocal AND currentDate = endDateLocal)
				THEN SET startCalculatedDateTime = startOfCurrentDateTime;
					 SET endCalculatedDateTime = endDateTimeLocal;
			ELSE 	 SET startCalculatedDateTime = currentDateTime;
					 SET endCalculatedDateTime = endDateTimeLocal;
			END IF;	
            
			SET totalMinutes = totalMinutes + 
			(SELECT CASE WHEN isHoliday = 1 THEN 
				CalculateBusinessHourByOffTime(TIME(startCalculatedDateTime),TIME(endCalculatedDateTime),'04:30:00','18:30:00',holidayOffStartTime,holidayOffEndTime)
					ELSE CalculateBusinessHourByWorkingTime(startCalculatedDateTime,endCalculatedDateTime,workStartTime,workEndTime) END);				
		END IF;
		  
        SET currentDateTime = DATE_ADD(currentDateTime,INTERVAL 1 DAY);
        
	END WHILE;
    
    IF(totalMinutes < 0)
		THEN SET totalMinutes = 0;
	END IF;
    
    RETURN totalMinutes;
END