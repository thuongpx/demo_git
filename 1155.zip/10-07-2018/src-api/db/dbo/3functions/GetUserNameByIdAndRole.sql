DROP FUNCTION IF EXISTS `GetUserNameByIdAndRole`;

DELIMITER $$

CREATE FUNCTION `GetUserNameByIdAndRole`(id int(11), roleType varchar(50) , isAgent boolean) RETURNS varchar(250)
BEGIN
	DECLARE userName VARCHAR(45);    
	SET userName = '';
    
	IF id IS NOT NULL and roleType IS NOT NULL and roleType <> '' THEN
    BEGIN
        SELECT u.UserName 
        INTO userName 
        FROM `users` u
		INNER JOIN user_roles ur ON u.UsersId = ur.UsersId
		INNER JOIN roles rl ON ur.RoleId = rl.RoleId
		WHERE u.MappingUserId = id AND LOWER(rl.Type) = LOWER(roleType) AND (IF(isAgent IS NOT NULL AND isAgent = TRUE, LOWER(rl.RoleName) LIKE '%agent%', LOWER(rl.RoleName) NOT LIKE '%agent%'));		
    END;
    END IF;
    
	RETURN userName;
END$$

DELIMITER ;