DROP FUNCTION IF EXISTS `GetFullNameByUserId`;

DELIMITER $$

CREATE FUNCTION `GetFullNameByUserId`(user_Id int(11)) RETURNS varchar(50)
BEGIN
	DECLARE userType VARCHAR(15);
    DECLARE fullName VARCHAR(50);
    DECLARE roleName VARCHAR(100);
	SET userType = '';
    SET fullName = '';
    
	IF user_Id IS NOT NULL THEN
    BEGIN
        SELECT r.Type, r.RoleName
        INTO userType, roleName
        FROM user_roles AS u
		INNER JOIN roles AS r ON u.RoleId = r.RoleId
		WHERE u.UsersId = user_Id
        LIMIT 1;
        
        -- if user is staff
        IF userType = 'Staff' THEN
        BEGIN
			SELECT CONCAT(e.FirstName,' ', e.LastName)
            INTO fullName
            FROM employees e
            INNER JOIN users u ON e.RepId = u.MappingUserId
            WHERE u.UsersId = user_Id;
        END;
        END IF;
        
        -- if user is client
        If userType = 'Client' THEN
        BEGIN
			-- client is agent
			IF RoleName = 'Agent' THEN 
            BEGIN
				SELECT a.FullName
				INTO fullName
				FROM agent a
				INNER JOIN users u ON a.AgentId = u.MappingUserId
				WHERE u.UsersId = user_Id;
            END;
            ELSE
            BEGIN
				-- client is broker or branch
				SELECT b.Company
				INTO fullName
				FROM broker b
				INNER JOIN users u ON b.BrokerID = u.MappingUserId
				WHERE u.UsersId = user_Id;
            END;
            END IF;
        END;
        END IF;
        
        -- if user is client
        If userType = 'Vendor' THEN
        BEGIN
			SELECT CONCAT(s.FirstName,' ', s.LastName)
            INTO fullName
            FROM signer s
            INNER JOIN users u ON s.SignerId = u.MappingUserId
            WHERE u.UsersId = user_Id;
        END;
        END IF;
    END;
    END IF;
    
	RETURN fullName;
END$$

DELIMITER ;