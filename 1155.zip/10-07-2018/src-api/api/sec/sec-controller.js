import Bookshelf from "../../db/database";
import SecAnswers from "../../db/model/sec-answers";
import Boom from "boom";
import User from "../../db/model/users";
class SecController {
    constructor() { }

    getSecQuestionsForDropdown(request, reply) {
        const rawSql = `select q.ChalID, q.Question from sec_questions q;`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply(result[0]);
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

    getSecQuestionsOfUser(request, reply) {
        const { userId } = request.query;

        const sql = `select sa.UserId, sq1.ChalId as qId1, sq1.Question as q1, sq2.ChalId as qId2, sq2.Question as q2, sq3.ChalId as qId3, sq3.Question as q3 from sec_answers sa
        left join sec_questions sq1 on sa.ChalId1 = sq1.ChalId
        left join sec_questions sq2 on sa.ChalId2 = sq2.ChalId
        left join sec_questions sq3 on sa.ChalId3 = sq3.ChalId
        where sa.userId = ${userId};`;

        Bookshelf.knex.raw(sql)
            .then(result => {
                reply(result[0][0]);
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getUserSecQuestion(request, reply) {
        const { userId } = request.query;
        SecAnswers.where({ UserId: userId }).fetch({ columns: ["ChalId1"] }).then((result) => {
            if (result !== null) {
                reply({ id: result.attributes.ChalId1 });
            } else {
                reply({ id: -1 });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    checkUserSecAnswer(request, reply) {
        const { userId, secAnswer } = request.payload;

        SecAnswers.where({ UserId: userId, Answer1: secAnswer }).count("*").then((count) => {
            if (count > 0) {
                reply({ isValid: true });
            } else {
                reply({ isValid: false });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    // add new sec_answers
    addSecAnswer(request, reply) {
        const secAnswers = request.payload;

        new SecAnswers()
            .save({
                UserId: secAnswers.mappingUserId,
                ChalId1: secAnswers.chalId1,
                Answer1: secAnswers.answer1,
                ChalId2: secAnswers.chalId2,
                Answer2: secAnswers.answer2,
                ChalId3: secAnswers.chalId3,
                Answer3: secAnswers.answer3
            }, { method: "insert" })
            .then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                    return;
                }
            })
            .catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    deleteSecAnswers(request, reply) {
        const username = request.query;
        User.where({ UserName: username.username }).fetch({ columns: ["UsersId"] }).then((data) => {
            SecAnswers.where({ UserId: data.attributes.UsersId }).destroy().then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    updateSecAnswers(request, reply) {
        const secAnswers = request.payload;

        SecAnswers.where({ UserId: secAnswers.UserId }).save(secAnswers, { method: "update" }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });

            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
        return;
    }

    async checkUserAnswer(request, reply) {
        const { userId, answerNo, answer } = request.payload;

        const sql = `select UserId, 
        ChalId1 as qId1, Answer1 as answer1, 
        ChalId2 as qId2, Answer2 as answer2, 
        ChalId3 as qId3, Answer3 as answer3 
        from sec_answers
        where userId = ${userId};`;

        try {
            const answerResult = await Bookshelf.knex.raw(sql);
            const answerSheet = answerResult[0][0];

            reply({
                isSuccess: true,
                isValidAnswer: answerSheet[`answer${answerNo}`] === answer
            });
        } catch (err) {
            reply(Boom.badRequest(err));
            return;
        }
    }
}

export default new SecController();