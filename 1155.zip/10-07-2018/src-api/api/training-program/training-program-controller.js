import Boom from "boom";
import Bookshelf from "../../db/database";
import { isBuffer, bufferToBoolean } from "../../helper/common-helper";
import TrainingPrograms from "../../db/model/training-programs";
import TrainingProgramCourses from "../../db/model/training-program-courses";
import TrainingProgramTest from "../../db/model/training-program-test";
import { handleSingleQuote, replaceAll } from "../../helper/common-helper";
import TrainingLearningPathProgram from "../../db/model/training-lp-programs";

class TrainingProgramController {

    getTrainingPrograms(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            programName,
            programStatus
        } = request.query;
        const rawSql = `call getTrainingPrograms('${sortColumn}',${sortDirection},${page}, ${itemPerPage},'${handleSingleQuote(programName)}',${programStatus})`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    const trainingPrograms = result[0][0];
                    Object.keys(trainingPrograms).forEach((keyRow) => {
                        const value = trainingPrograms[keyRow];
                        Object.keys(value).forEach((keyField) => {
                            if (isBuffer(trainingPrograms[keyRow][keyField])) {
                                trainingPrograms[keyRow][keyField] = bufferToBoolean(trainingPrograms[keyRow][keyField]);
                            }
                        });
                    });
                    reply({
                        data: trainingPrograms,
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    async getInputProgagram(request, reply) {
        const { programId } = request.query;

        let isProgramHasDefaultTest = false;
        const sqlCheckProgramHasDefaultTest = `select * from training_program_test tpt 
        left join test_info ti on tpt.testId = ti.testId
        where tpt.programId <> ${programId} and ti.defaultTest=1`;
        await new Promise(resolve => Bookshelf.knex.raw(sqlCheckProgramHasDefaultTest).then(result => {
            isProgramHasDefaultTest = result[0].length > 0;
            resolve();
        }));

        const getAllCourses = Promise.resolve(Bookshelf.knex.raw(`select CourseId as value, Title as label from training_courses where Inactive = 0 order by label;`));
        let getAllTests = null;

        if (isProgramHasDefaultTest) {
            getAllTests = Promise.resolve(Bookshelf.knex.raw(`select TestId as value, TestName as label from test_info where Active = 1 and (defaultTest is null or defaultTest=0) order by label;`));
        } else {
            getAllTests = Promise.resolve(Bookshelf.knex.raw(`select TestId as value, TestName as label from test_info where Active = 1 order by label;`));
        }
        if (programId !== 0) {
            const getCoursesById = Promise.resolve(Bookshelf.knex.raw(`select training_program_courses.CourseId as value, training_courses.Title as label from training_program_courses
                                                                       inner join training_courses on training_program_courses.CourseId = training_courses.CourseId where training_program_courses.ProgramId = ${programId};`));
            const getTestsById = Promise.resolve(Bookshelf.knex.raw(`select training_program_test.TestId as value, test_info.TestName as label from training_program_test
                                                                    inner join test_info on training_program_test.TestId = test_info.TestId  where training_program_test.ProgramId = ${programId};`));
            Promise.all([getAllCourses, getAllTests, getCoursesById, getTestsById])
                .then(values => {
                    const data = {};
                    if (values !== null) {
                        values.forEach((item, index) => {
                            if (item !== null) {
                                switch (index) {
                                    case 0:
                                        data.listCourse = item;
                                        break;
                                    case 1:
                                        data.listTest = item;
                                        break;
                                    case 2:
                                        data.courses = item;
                                        break;
                                    case 3:
                                        data.tests = item;
                                        break;
                                }
                            }
                        });
                    }
                    reply(data);
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        } else {
            Promise.all([getAllCourses, getAllTests])
                .then(values => {
                    const data = {};
                    if (values !== null) {
                        values.forEach((item, index) => {
                            if (item !== null) {
                                switch (index) {
                                    case 0:
                                        data.listCourse = item;
                                        break;
                                    case 1:
                                        data.listTest = item;
                                        break;
                                }
                            }
                        });
                    }
                    reply(data);
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        }
    }

    countCoursesTestsById(request, reply) {
        const { programId } = request.query;
        const countCoursesById = Promise.resolve(Bookshelf.knex.raw(`select count(training_program_courses.CourseId) as countCourses from training_program_courses
                                                                inner join training_courses on training_program_courses.CourseId = training_courses.CourseId where training_program_courses.ProgramId = ${programId};`));
        const countTestsById = Promise.resolve(Bookshelf.knex.raw(`select count(training_program_test.TestId) as countTests from training_program_test
                                                                inner join test_info on training_program_test.TestId = test_info.TestId  where training_program_test.ProgramId = ${programId};`));

        Promise.all([countCoursesById, countTestsById])
            .then(values => {
                const data = {};
                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.countCourses = item[0][0].countCourses;
                                    break;
                                case 1:
                                    data.countTests = item[0][0].countTests;
                                    break;
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    updateTraningProgram(request, reply) {
        const { program, courses, tests } = request.payload;
        if (program.programId === 0) {
            new TrainingPrograms().save({
                Title: program.programName,
                Description: program.description,
                ForVendor: program.forVendor,
                ForStaff: program.forStaff,
                IsPublished: program.isPublished,
                Inactive: true
            }, { method: "insert" }).then((result) => {
                if (result !== null) {
                    if (courses.length > 0) {
                        courses.map(async addr => {
                            await new Promise((resolve) => new TrainingProgramCourses().save({
                                CourseId: addr.value,
                                ProgramId: result.attributes.id
                            }, { method: "insert" }).then(() => resolve()).catch((error) => {
                                reply(Boom.badRequest(error));
                            }));
                        });
                    }

                    if (tests.length > 0) {
                        tests.map(async addr => {
                            await new Promise((resolve) => new TrainingProgramTest().save({
                                TestId: addr.value,
                                ProgramId: result.attributes.id
                            }, { method: "insert" }).then(() => resolve()).catch((error) => {
                                reply(Boom.badRequest(error));
                            }));
                        });
                    }
                }
                reply({ isSuccess: true });

            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        } else {

            TrainingPrograms.where({ ProgramId: program.programId }).save({
                Title: program.programName,
                Description: program.description,
                ForVendor: program.forVendor,
                ForStaff: program.forStaff,
                IsPublished: program.isPublished,
                Inactive: program.inactive
            }, { method: "update" }).then(async result => {
                if (result !== null) {
                    const delCoursesById = `DELETE FROM training_program_courses WHERE ProgramId=${program.programId}`;

                    await new Promise((resolve) => Bookshelf.knex.raw(delCoursesById)
                        .then(() => {
                            resolve();
                        }).catch(err => {
                            reply(Boom.badRequest(err));
                        }));

                    if (courses.length > 0) {
                        courses.map(async addr => {
                            const insertCoursesSql = `INSERT INTO training_program_courses (CourseId, ProgramId) VALUES (${addr.value}, ${program.programId});`;
                            await new Promise((resolve) => Bookshelf.knex.raw(insertCoursesSql)
                                .then(() => {
                                    resolve();
                                }).catch(err => {
                                    reply(Boom.badRequest(err));
                                }));
                        });
                    }

                    const delTestsById = `DELETE FROM training_program_test WHERE ProgramId=${program.programId}`;
                    await new Promise((resolve) => Bookshelf.knex.raw(delTestsById)
                        .then(() => {
                            resolve();
                        }).catch(err => {
                            reply(Boom.badRequest(err));
                        }));

                    if (tests.length > 0) {
                        tests.map(async addr => {
                            const insertTestsSql = `INSERT INTO training_program_test (TestId, ProgramId) VALUES (${addr.value}, ${program.programId});`;
                            await new Promise((resolve) => Bookshelf.knex.raw(insertTestsSql)
                                .then(() => {
                                    resolve();
                                }).catch(err => {
                                    reply(Boom.badRequest(err));
                                }));
                        });
                    }
                    reply({ isSuccess: true });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        }
    }

    deleteTrainingProgram(request, reply) {
        const { programId } = request.payload;
        const deleteTrainingProgramCourses = Promise.resolve(TrainingProgramCourses.where({ ProgramId: programId }).destroy());
        const deleteTrainingProgramTest = Promise.resolve(TrainingProgramTest.where({ ProgramId: programId }).destroy());
        const deleteTrainingProgram = Promise.resolve(TrainingPrograms.where({ ProgramId: programId }).destroy());
        const deleteTrainingLpProgram = Promise.resolve(TrainingLearningPathProgram.where({ ProgramId: programId }).destroy());
        const queue = [deleteTrainingProgramCourses, deleteTrainingProgramTest, deleteTrainingProgram, deleteTrainingLpProgram];

        Promise.all(queue).then(() => {
            reply({ isSuccess: true });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    publicUnPublicTrainingProgram(request, reply) {
        const { program } = request.payload;

        if (program.isPublished === true) {
            TrainingPrograms.where({ ProgramId: program.programId }).save({
                IsPublished: false
            },
                { method: "update" }).then((result) => {
                    if (result !== null) {
                        reply({ isSuccess: true });
                    }
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                });
        } else {
            const publicTraningProgram = Promise.resolve(TrainingPrograms.where({ ProgramId: program.programId }).save({
                IsPublished: true
            }, { method: "update" }));
            const queue = [publicTraningProgram];
            if (program.inactive !== false) {
                queue.push(Promise.resolve(TrainingPrograms.where({ ProgramId: program.programId }).save({
                    Inactive: false
                }, { method: "update" })));
            }

            Promise.all(queue).then(() => {
                reply({ isSuccess: true });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        }
    }

    checkProgramName(request, reply) {
        const { programName, programId } = request.query;
        const checkExistProgramName = `SELECT count(ProgramId) AS count FROM training_programs WHERE Title = '${replaceAll(programName, "'", "\\'")}' AND ProgramId <> ${programId}`;
        Bookshelf.knex.raw(checkExistProgramName)
            .then((result) => {
                reply({ isExist: result[0][0].count > 0 });

            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
}

export default new TrainingProgramController();