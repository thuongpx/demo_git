import Bookshelf from "../../db/database";
import Boom from "boom";
import Signer from "../../db/model/signers";
import State from "../../db/model/state";
import SignerChanges from "../../db/model/signer_changes";
import { bufferToBoolean, hasValue } from "../../helper/common-helper";
import moment from "moment";
class SignerProfileController {
	constructor() { }

	getUserAddress(request, reply) {
		const { signerId } = request.query;
		const { tenantId } = request.query;
		const getAllStates = Promise.resolve(State.fetchAll({ columns: ["Code", "Description"] }));
		const getUserAddress = Promise.resolve(
			Signer.where({ SignerId: signerId, TenantId: tenantId })
				.fetch({
					columns: [
						"WeekdayStreet",
						"WeekdayCity",
						"WeekdaySuite",
						"WeekdayState",
						"WeekdayZip",
						"WeekendStreet",
						"WeekendSuite",
						"WeekendCity",
						"WeekendState",
						"WeekendZip"
					]
				})
		);
		const promiseData = Promise.all([getAllStates, getUserAddress]);
		promiseData
			.then(values => {
				const data = {};
				if (values !== null) {
					values.forEach((item, index) => {
						if (item !== null) {
							switch (index) {
								case 0:
									data.listStates = item;
									break;
								case 1:
									data.userAddress = item;
									break;
							}
						}
					});
				}
				reply(data);
			}).catch(err => {
				reply(Boom.badRequest(err));
			});
		return reply;
	}

	getUserAddressPending(request, reply) {
		const { signerId } = request.query;
		SignerChanges.where({ SignerId: signerId })
			.fetch({
				columns: [
					"WeekdayStreet",
					"WeekdayCity",
					"WeekdaySuite",
					"WeekdayState",
					"WeekdayZip",
					"WeekendStreet",
					"WeekendSuite",
					"WeekendCity",
					"WeekendState",
					"WeekendZip"
				]
			})
			.then((result) => {
				if (result !== null) {
					reply(result);
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		return;
	}

	updateUserAddressPending(request, reply) {
		const userAddressPending = request.payload;
		SignerChanges.where({ SignerId: userAddressPending.SignerId }).fetch().then((existed) => {
			if (existed !== null) {
				SignerChanges.where({ SignerId: userAddressPending.SignerId }).save(
					userAddressPending
					, { method: "update" }).then((result) => {
						if (result !== null) {
							reply({ isSuccess: true });
						}
					}).catch((error) => {
						reply(Boom.badRequest(error));
					});
			} else {
				const newSignerChanges = new SignerChanges(userAddressPending);
				newSignerChanges.save(null, { method: "insert" }).then((response) => {
					if (response !== null) {
						reply({ isSuccess: true });
					}
				}).catch((error) => {
					reply(Boom.badRequest(error));
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getUserAdditionalInfo(request, reply) {
		const { signerId } = request.query;
		const { tenantId } = request.query;
		Signer.where({ SignerId: signerId, TenantId: tenantId })
			.fetch({
				columns: [
					"AdditionInfo",
					"AnivDate",
					"AnotherStamp",
					"AvailDays",
					"AvailEves",
					"AvailWkEnds",
					"CommissionNum",
					"ConductedEClosing",
					"CoverageArea",
					"ExperiencedDocs",
					"Felony",
					"FelonyReason",
					"Fulltime",
					"HaveLaserPrinter",
					"HaveMobileScanner",
					"HaveTablet",
					// ------------"MemberOf",
					"Military",
					"NonEnglishLang",
					"NotarizedDocs",
					// "NotarizedTime",
					// "NotaryExp",
					"NotaryStates",
					"OtherAssociation",
					"PickupDocs",
					"PickupDocsCharge",
					// -----------"Position",
					"IsBroker",
					"IsREA",
					"IsAttorney",
					"IsCollegeGrad",
					"IsNNA",
					"IsAVA",
					"IsNone",
					"IsOther",
					//---------------------
					"PrintLegal",
					"Snooze",
					"SnoozeFrom",
					"SnoozeTo",
					"TrainedBy",
					"TrainedByOther",
					"TrainedEClosing",
					"WifiCapability	",
					"ProfilePicture",
					"NotestoND"
				]
			})
			.then((result) => {
				if (result !== null) {
					result.attributes.AnivDate = result.attributes.AnivDate ? moment(result.attributes.AnivDate).format("MM/DD/YYYY") : "";
					// result.attributes.NotaryExp = result.attributes.NotaryExp ? moment(result.attributes.NotaryExp).format("MM/DD/YYYY") : "";
					result.attributes.SnoozeFrom = result.attributes.SnoozeFrom ? moment(result.attributes.SnoozeFrom).format("MM/DD/YYYY") : "";
					result.attributes.SnoozeTo = result.attributes.SnoozeTo ? moment(result.attributes.SnoozeTo).format("MM/DD/YYYY") : "";
					result.attributes.AnotherStamp = result.attributes.AnotherStamp ? bufferToBoolean(result.attributes.AnotherStamp) : false;
					result.attributes.AvailDays = result.attributes.AvailDays ? bufferToBoolean(result.attributes.AvailDays) : false;


					result.attributes.AvailEves = result.attributes.AvailEves ? bufferToBoolean(result.attributes.AvailEves) : false;
					result.attributes.AvailWkEnds = result.attributes.AvailWkEnds ? bufferToBoolean(result.attributes.AvailWkEnds) : false;
					result.attributes.ConductedEClosing = result.attributes.ConductedEClosing ? bufferToBoolean(result.attributes.ConductedEClosing) : false;
					result.attributes.Felony = result.attributes.Felony ? bufferToBoolean(result.attributes.Felony) : false;
					result.attributes.Fulltime = result.attributes.Fulltime ? bufferToBoolean(result.attributes.Fulltime) : false;

					result.attributes.HaveLaserPrinter = result.attributes.HaveLaserPrinter ? bufferToBoolean(result.attributes.HaveLaserPrinter) : false;
					result.attributes.HaveMobileScanner = result.attributes.HaveMobileScanner ? bufferToBoolean(result.attributes.HaveMobileScanner) : false;
					result.attributes.HaveTablet = result.attributes.HaveTablet ? bufferToBoolean(result.attributes.HaveTablet) : false;
					result.attributes.Military = result.attributes.Military ? bufferToBoolean(result.attributes.Military) : false;
					result.attributes.NotarizedDocs = result.attributes.NotarizedDocs ? bufferToBoolean(result.attributes.NotarizedDocs) : false;
					result.attributes.PickupDocs = result.attributes.PickupDocs ? bufferToBoolean(result.attributes.PickupDocs) : false;

					result.attributes.IsBroker = result.attributes.IsBroker ? bufferToBoolean(result.attributes.IsBroker) : false;
					result.attributes.IsREA = result.attributes.IsREA ? bufferToBoolean(result.attributes.IsREA) : false;
					result.attributes.IsAttorney = result.attributes.IsAttorney ? bufferToBoolean(result.attributes.IsAttorney) : false;
					result.attributes.IsCollegeGrad = result.attributes.IsCollegeGrad ? bufferToBoolean(result.attributes.IsCollegeGrad) : false;
					result.attributes.IsNNA = result.attributes.IsNNA ? bufferToBoolean(result.attributes.IsNNA) : false;
					result.attributes.IsAVA = result.attributes.IsAVA ? bufferToBoolean(result.attributes.IsAVA) : false;

					result.attributes.IsNone = result.attributes.IsNone ? bufferToBoolean(result.attributes.IsNone) : false;
					result.attributes.IsOther = result.attributes.IsOther ? bufferToBoolean(result.attributes.IsOther) : false;
					result.attributes.PrintLegal = result.attributes.PrintLegal ? bufferToBoolean(result.attributes.PrintLegal) : false;
					result.attributes.Snooze = result.attributes.Snooze ? bufferToBoolean(result.attributes.Snooze) : false;
					result.attributes.TrainedEClosing = result.attributes.TrainedEClosing ? bufferToBoolean(result.attributes.TrainedEClosing) : false;
					result.attributes.WifiCapability = result.attributes.WifiCapability ? bufferToBoolean(result.attributes.WifiCapability) : false;

					result.attributes.ProfilePicture = hasValue(result.attributes.ProfilePicture) ? result.attributes.ProfilePicture.toString() : "";

					reply(result);
				} else {
					const newSigner = new Signer({ SignerId: signerId, TenantId: tenantId });
					newSigner.save(null, { method: "insert" }).then((response) => {
						if (response !== null) {
							reply({});
						}
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		return;
	}

	updateUserAdditionalInfo(request, reply) {
		const userAdditionalInfo = request.payload;
		if (userAdditionalInfo.SnoozeFrom) {
			userAdditionalInfo.SnoozeFrom = (new Date((new Date((new Date(userAdditionalInfo.SnoozeFrom)).toISOString())).getTime() - ((new Date(userAdditionalInfo.SnoozeFrom)).getTimezoneOffset() * 60000))).toISOString().slice(0, 19).replace("T", " ");
		} else {
			userAdditionalInfo.SnoozeFrom = null;
		}
		if (userAdditionalInfo.SnoozeTo) {
			userAdditionalInfo.SnoozeTo = (new Date((new Date((new Date(userAdditionalInfo.SnoozeTo)).toISOString())).getTime() - ((new Date(userAdditionalInfo.SnoozeTo)).getTimezoneOffset() * 60000))).toISOString().slice(0, 19).replace("T", " ");
		} else {
			userAdditionalInfo.SnoozeTo = null;
		}
		if (userAdditionalInfo.AnivDate) {
			userAdditionalInfo.AnivDate = (new Date((new Date((new Date(userAdditionalInfo.AnivDate)).toISOString())).getTime() - ((new Date(userAdditionalInfo.AnivDate)).getTimezoneOffset() * 60000))).toISOString().slice(0, 19).replace("T", " ");
		} else {
			userAdditionalInfo.AnivDate = null;
		}
		Signer.where({ SignerId: userAdditionalInfo.SignerId, TenantId: userAdditionalInfo.TenantId }).save(
			userAdditionalInfo
			, { method: "update" }).then((result) => {
				if (result !== null) {
					reply({ isSuccess: true });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	getUserAdditionalInfoList(request, reply) {
		const { signerId } = request.query;
		Bookshelf.knex.raw(`CALL GetUserAdditionalInfoList(${signerId});`).then(result => {
			if (result !== null) {
				let signer = result[0][3];
				if (!Array.isArray(signer)) {
					signer = [];
				}
				reply(
					{
						isSuccess: true,
						loans: result[0][0],
						languages: result[0][1],
						states: result[0][2],
						signer
					}
				);
				return;
			}
			reply({ isSuccess: false, message: "No record found!" });
			return;
		}).catch(error => {
			reply(Boom.badRequest(error));
			return;
		});
	}
	getVendorRegisterPrograms(request, reply) {
		const { page, itemPerPage, signerId } = request.query;
		Bookshelf.knex.raw(`call GetVendorRegisterPrograms(${page},${itemPerPage},${signerId});`).then(result => {
			if (result !== null) {
				result[0][0].map((item) => {
					item.Status = bufferToBoolean(item.Status);
				});
				reply({
					data: result[0][0],
					totalRecords: result[0][1][0].TotalRecords
				});
				return;
			}
			reply({ isSuccess: false, message: "No record found!" });
			return;
		}).catch(error => {
			reply(Boom.badRequest(error));
			return;
		});
	}

	getCourseTestList(request, reply) {
		const { ProgramId, signerId } = request.query;
		const rawSql = `SELECT
							vendor_courses_result.ProgramId AS programId,
							training_courses.Title AS itemName,
								'Course' AS itemType,
								vendor_courses_result.StartDate AS startDate,
								vendor_courses_result.EndDate AS endDate,
								CASE WHEN vendor_courses_result.IsComplete = TRUE THEN TRUE ELSE FALSE END AS status
						FROM vendor_courses_result
						INNER JOIN training_courses on training_courses.CourseId = vendor_courses_result.CourseId
						WHERE vendor_courses_result.VendorId = ${signerId} and vendor_courses_result.ProgramId = ${ProgramId}
						UNION
						SELECT 
								vendor_test_result.ProgramId AS programId,
								test_info.TestName AS itemName,
								'Test' AS itemType,
								vendor_test_result.StartDate AS startDate,
								vendor_test_result.EndDate AS endDate,
								CASE WHEN vendor_test_result.Passed = 'Y' THEN TRUE
								ELSE FALSE
                                     END AS status
						FROM vendor_test_result
						INNER JOIN test_info on test_info.TestId = vendor_test_result.TestId
						WHERE vendor_test_result.VendorId = ${signerId}  and vendor_test_result.ProgramId = ${ProgramId};`;
		//console.log(rawSql);

		Bookshelf.knex.raw(rawSql).then(result => {
			if (result !== null) {
				reply({
					data: result[0]
				});
				return;
			}
			reply({ isSuccess: false, message: "No record found!" });
			return;
		}).catch(error => {
			reply(Boom.badRequest(error));
			return;
		});
	}

	getVendorNotifications(request, reply) {
		const { sortColumn, sortDirection, page, itemPerPage, signerId } = request.query;

		const rawSql = `call GetVendorNotifications('${sortColumn}', ${sortDirection},${page}, ${itemPerPage}, ${signerId})`;

		Bookshelf.knex.raw(rawSql)
			.then((result) => {
				if (result !== null) {
					reply({
						data: result[0][0],
						totalRecords: result[0][1][0].TotalRecords
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}
}
export default new SignerProfileController();