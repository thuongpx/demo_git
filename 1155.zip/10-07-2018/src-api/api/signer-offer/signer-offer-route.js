import SignerOfferController from "./signer-offer-controller";

const routes = [{
    path: "/signerOffer/getOrdersSentOffers",
    method: "GET",
    handler: SignerOfferController.getOrdersSentOffers
}];

export default routes;