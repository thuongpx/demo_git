import AuthController from "./auth-controller";

const routes = [{
    path: "/authorize",
    method: "POST",
    config: {
        auth: false
    },
    handler: AuthController.authorize
},
{
    path: "/createAccount",
    method: "POST",
    config: {
        auth: false
    },
    handler: AuthController.createAnAccount
},
{
    path: "/getProfilePicture",
    method: "GET",
    config: {
        auth: false
    },
    handler: AuthController.getProfilePicture
},
{
    path: "/auth/loginAsAnotherUser",
    method: "POST",
    handler: AuthController.loginAsAnotherUser
}];

export default routes;