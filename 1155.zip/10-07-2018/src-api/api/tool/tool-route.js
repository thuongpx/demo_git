import ToolController from "./tool-controller";
const routes = [
    {
        path: "/tool/getListLink",
        method: "POST",
        config: {
            auth: false
        },
        handler: ToolController.getListLink
    },
    {
        path: "/tool/getFaqsByQuestion",
        method: "GET",
        handler: ToolController.getFaqsByQuestion
    },
    {
        path: "/tool/getPageDisplayFromConstant",
        method: "GET",
        config: {
            auth: false
        },
        handler: ToolController.getPageDisplayFromConstant
    },
    {
        path: "/tool/addLinksToDataBase",
        method: "POST",
        config: {
            auth: false
        },
        handler: ToolController.addLinksToDataBase
    },
    {
        path: "/tool/deleteLinksById",
        method: "GET",
        config: {
            auth: false
        },
        handler: ToolController.deleteLinksById
    },
    {
        path: "/tool/editLinksById",
        method: "POST",
        config: {
            auth: false
        },
        handler: ToolController.editLinksById
    },
    {
        path: "/tool/getListFaqByViews",
        method: "POST",
        config: {
            auth: false
        },
        handler: ToolController.getListFaqByViews
    },
    {
        path: "/tool/addFaqsToDatabase",
        method: "POST",
        config: {
            auth: false
        },
        handler: ToolController.addFaqsToDatabase
    },
    {
        path: "/tool/editFaqById",
        method: "POST",
        config: {
            auth: false
        },
        handler: ToolController.editFaqById
    },
    {
        path: "/tool/deleteFaqById",
        method: "GET",
        config: {
            auth: false
        },
        handler: ToolController.deleteFaqById
    },
    {
        path: "/tool/getLinksDisplayFromConstant",
        method: "GET",
        handler: ToolController.getLinksDisplayFromConstant
    },
    {
        path: "/tool/getListResource",
        method: "POST",
        handler: ToolController.getListResource
    },
    {
        path: "/tool/addResourcesToDataBase",
        method: "POST",
        config: {
            auth: false
        },
        handler: ToolController.addResourcesToDataBase
    },
    {
        path: "/tool/deleteResourcesById",
        method: "GET",
        config: {
            auth: false
        },
        handler: ToolController.deleteResourcesById
    },
    {
        path: "/tool/editResourcesById",
        method: "POST",
        config: {
            auth: false
        },
        handler: ToolController.editResourcesById
    },
    {
        path: "/tool/deleteResourceFileById",
        method: "GET",
        config: {
            auth: false
        },
        handler: ToolController.deleteResourceFileById
    },
    {
        path: "/tool/downloadResources",
        method: "GET",
        handler: ToolController.downloadResources
    },
    {
        path: "/tool/getListResourceByViews",
        method: "GET",
        config: {
            auth: false
        },
        handler: ToolController.getListResourceByViews
    }
    //resources
];

export default routes;
