import ClientServicesConfig from "./client-services-config-controller";
const routes = [{
    path: "/client-services-config/getClientServicesConfigData",
    method: "GET",
    handler: ClientServicesConfig.getClientServicesConfigData
}, {
    path: "/client-services-config/hasPendingServicesConfig",
    method: "GET",
    handler: ClientServicesConfig.hasPendingServicesConfig
}, {
    path: "/client-services-config/addServicesConfig",
    method: "POST",
    handler: ClientServicesConfig.addServicesConfig
}, {
    path: "/client-services-config/updateServicesConfig",
    method: "POST",
    handler: ClientServicesConfig.updateServicesConfig
}, {
    path: "/client-services-config/getListServiceConfig",
    method: "GET",
    handler: ClientServicesConfig.getListServiceConfig
}, {
    path: "/client-services-config/getServiceConfigChange",
    method: "GET",
    handler: ClientServicesConfig.getServiceConfigChange
}, {
    path: "/client-services-config/approvalServiceConfig",
    method: "POST",
    handler: ClientServicesConfig.approvalServiceConfig
}
];

export default routes;