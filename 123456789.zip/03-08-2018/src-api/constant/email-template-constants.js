export const CLOSE_REQUEST_TEMPLATE = `<html>
<head>

</head>

<body>
	<div align="center">
		<center>
			<table border="0" cellpadding="0" cellspacing="0" width="800">
				<tr>
					<td width="10%"><a href="http://www.theclosingexchange.com/"><img border="0" src="http://www.theclosingexchange.com/images/logo-97.jpg" width="110" height="80"></a></td>
					<td width="40%" align="center"><p><b><font size="4" face="Arial">Notary Closing Confirmation</font></b></p></td>
					<td height="18">
						<table border="1" width="100%" id="table1" bordercolorlight="#000000" cellspacing="0" cellpadding="2" bordercolordark="#000000" style="border-collapse: collapse">
							<tr>
								<td width="34%"><b><font size="1" face="Arial">Company:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[companyName]</font></td>
							</tr>
							<tr>
								<td width="34%"><b><font size="1" face="Arial">File Last Name:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[customerLastName]</font></td>
							</tr>
							<tr>
								<td width="34%"><b><font size="1" face="Arial">Loan/Reference number:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[referenceNumber]</font></td>
							</tr>
							<tr>
								<td width="34%"><b><font size="1" face="Arial">The Closing Exchange Order ID:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[orderId]</font></td>
							</tr>
							<!--AGENT-->
							<tr>
								<td width="34%"><b><font face="Arial" size="1">Signing Date and Time:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[aptDateTime]</font></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			
			<!--STATEMENT-->
			
			<table bgcolor="#EEEEEE" cellspacing="0" cellpadding="5" width="800">
				<tr>
					<td bgcolor="#707070" colspan="2">
						<font color="#FFFFFF" face="Arial" style="font-size: 9pt"><b>Closing Worksheet Completed by: [vendorName] </b></font>
					</td>
				</tr>
					
				<tr>
					<td colspan="2">
						<font style="font-size: 9pt" face="Wingdings">&nbsp;x</font><font face="Arial" style="font-size: 9pt"> Appointment Confirmed<br></font>
						<font style="font-size: 9pt" face="Wingdings">&nbsp;x</font><font face="Arial" style="font-size: 9pt"> Documents Retrieved and Printed Correctly<br></font>
						<font style="font-size: 9pt" face="Wingdings">&nbsp;x</font><font face="Arial" style="font-size: 9pt"> Documents Reviewed, <b>PAGE BY PAGE</b>, for Signatures, initials, and Notarization<br></font>
					</td>
				</tr>
					
				<tr>
					<td colspan="2">
						<font face="Arial" style="font-size: 9pt">&nbsp;&nbsp;&nbsp;&nbsp; Courier:&nbsp;&nbsp;<b>[courier]</b></font>
					</td>
				</tr>
					
				<tr>
					<td colspan="2">
						<font face="Arial" style="font-size: 9pt">&nbsp;&nbsp;&nbsp;&nbsp; Account #:&nbsp;&nbsp;<b>[courierAccountNumber]</b></font>
					</td>
				</tr>
					
				<tr>
					<td colspan="2">
						<font face="Arial" style="font-size: 9pt">&nbsp;&nbsp;&nbsp;&nbsp; Shipment Tracking Number:&nbsp;&nbsp;<b>[trackingNumber]</b></font>
					</td>
				</tr>
				
				<tr>
					<td colspan="2">
						<div id="DRE" style="display:none">
						<table width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td valign="top">
									<hr>
								</td>
							</tr>
						</table>
						</div>
					</td>
				</tr>
			  
				<tr>
					<td valign="top" colspan="2">
						<font face="Arial" style="font-size: 9pt">&nbsp;</font><font style="font-size: 9pt" face="Wingdings">x</font><font face="Arial" style="font-size: 9pt"> <b>I</b> understand that 
						documents must be dropped off for shipping or uploaded immediately following the signing 
						appointment to ensure compensation for this signing.</font>
					</td>
				</tr>
			  
				<tr>
					<td bgcolor="#707070" colspan="2">
						<b><font color="#FFFFFF" face="Arial" style="font-size: 9pt">&nbsp; Questionnaire:</font></b>
					</td>
				</tr>
				
				<tr>
					<td width="90%" colspan="2">
						<font face="Arial" style="font-size: 9pt">
						<ol >
							<li style="padding-top: 5px;margin-top: 10px;">Were There Any Issues at the Signing Table?&nbsp;&nbsp;&nbsp;&nbsp;<b><u>[isIssues]</u></b>
								<br>- If so, what were they and who did you contact to resolve<br>
								<b>[issuesResolveText]</b>
							</li>
							
							<li style="border-top: 1px solid #000000;padding-top: 10px;margin-top: 10px;">Were there any items to be collected from the 
								borrower at the closing table?&nbsp;&nbsp;&nbsp;&nbsp; <u><b>[isCollected]</b></u>
								<br>- If so, what items were collected or missing?<br>
								<b>[collectedText]</b>
                            </li>	
                            
                            <!--SCANBACK-->
														
							<li style="border-top: 1px solid #000000;padding-top: 10px;margin-top: 10px;border-bottom: 1px solid #000000;padding-bottom: 10px;">General Comments<br>
								<b>[generalComment]</b>
							</li>

						</ol>
						</font>
				
					</td>
				</tr>
				
				<tr>
					<td colspan="2">
						<font face="Arial" style="font-size: 9pt">
							<b>REVIEW:</b>
						</font>
						<ul type="square">
							<li>
								<font face="Arial" style="font-size: 9pt">It is imperative that all documents are signed/dated and notarized as they appear typed. Notary Stamp must be legible.<br>&nbsp;</font>
							</li>
							
							<li>
								<font face="Arial" style="font-size: 9pt">Package must be reviewed prior to departing borrower's home to ensure that all documents have been properly witnessed and accounted for. Prior to returning loan package, please confirm that the return address is correct.</font>
							</li>
						</ul>
						
						<p><font face="Arial" style="font-size: 9pt"><b>TERMS AND ACCEPTANCE:</b></font></p>
						<ul type="square">
							<li>
								<font face="Arial" style="font-size: 9pt">By submitting this document, I certify that the documents and any special and/or notary instructions have been fully executed to the best of my ability. I understand that I will be held accountable for any inaccurate information furnished. I do understand that during the post closing audit, if an error has been identified, I will be held responsible for immediate correction, at my own expense. I also understand that a fee reduction may be assessed in accordance to Notary Direct Nationwide Signing Agent Fee Reduction Policy.</font>
							</li>
						</ul>
					</td>
				</tr>
				
				<!--RETURN_DOC-->
				
				<tr>
					<td bgcolor="#707070" colspan="2">
						<b><font color="#FFFFFF" face="Arial" style="font-size: 9pt">&nbsp; Digital Signature:</font></b>
					</td>
				</tr>
				
				<tr>
					<td bgcolor="#EEEEEE" colspan="2">
						<font style="font-size: 9pt" face="Wingdings">x</font><font face="Arial" style="font-size: 9pt">&nbsp;&nbsp;I,<b>[vendorName],</b> certify that the above information is True and Correct</font>
					</td>
				</tr>
			</table>
			
			<table width="800" cellspacing="0" cellpadding="0">
				<tr>
					<td bgcolor="#C0C0C0">
						<font face="Arial" style="font-size: 9pt"><b>&nbsp;&nbsp; Notary Public Name:&nbsp;</b></font>
					</td>
					
					<td bgcolor="#C0C0C0"><font face="Arial" style="font-size: 9pt"><b>Customer Last Name:</b>&nbsp;</font></td>
				</tr>
			  
				<tr>
					<td bgcolor="#EEEEEE" height="30">
						<blockquote><font face="Arial" style="font-size: 9pt">[vendorName]</font></blockquote>
					</td>
				
					<td bgcolor="#EEEEEE" height="30">
						<blockquote><font face="Arial" style="font-size: 9pt">[customerLastName]</font></blockquote>
					</td>
				</tr>
			  
				<tr>
					<td bgcolor="#C0C0C0"><font face="Arial" style="font-size: 9pt"><b>&nbsp;&nbsp; Order ID #</b></font></td>
					<td bgcolor="#C0C0C0"><font face="Arial" style="font-size: 9pt"><b>Notary Rep</b></font></td>
				</tr>
				
				<tr>
					<td bgcolor="#EEEEEE" height="30">
						<blockquote>
							<font face="Arial" style="font-size: 9pt">
							[orderId]
							</font>
						</blockquote>
					</td>
					
					<td bgcolor="#EEEEEE" height="30">
						<blockquote>
							<font face="Arial" style="font-size: 9pt">
							[referenceNumber]
							</font>
						</blockquote>
					</td>
				</tr>
			</table>
		</center>
	</div>
</body>
</html>`;

export const AGENT_INFO_TR = `<tr>
                                    <td width="34%"><b><font size="1" face="Arial">Loan Agent:</font></b></td>
                                    <td width="63%"><font size="1" face="Arial">[agentName]</font></td>
                                </tr>
                                <tr>
                                    <td width="34%"><b><font size="1" face="Arial">Loan Agent Phone:</font></b></td>
                                    <td width="63%"><font size="1" face="Arial">[agentPhone]</font></td>
                                </tr>
                                <tr>
                                    <td width="34%"><b><font size="1" face="Arial">Loan Agent Email:</font></b></td>
                                    <td width="63%"><font size="1" face="Arial">[agentEmail]</font></td>
                                </tr>`;

export const SCANBACK_TEMPLATE = `<li style="border-top: 1px solid #000000;padding-top: 10px;margin-top: 10px;">
This order requires scanbacks. 
<br>When were scanbacks sent?
<br><b>[scanbacksDateTime]</b>
</li>`;

export const UNSUCCESSFUL_SIGNING_TEMPLATE = `<html>
<head>

</head>
<body>

	<div align="center">
		<center>

			<table border="0" cellpadding="0" cellspacing="0" width="800">
				<tr>
					<td width="10%"><a href="http://www.theclosingexchange.com/"><img border="0" src="http://www.theclosingexchange.com/images/logo-97.jpg" width="110" height="80"></a></td>
					<td width="40%" align="center">
						<p><b><font face="Arial" size="4">Unsuccessful Signing</font></b></p>
					</td>
					<td height="18">
						<table border="1" width="100%" id="table1" bordercolorlight="#000000" cellspacing="0" cellpadding="2" bordercolordark="#000000" style="border-collapse: collapse">
							<tr>
								<td width="34%"><b><font size="1" face="Arial">Company:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[companyName]</font></td>
							</tr>
							<tr>
								<td width="34%"><b><font size="1" face="Arial">File Last Name:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[customerLastName]</font></td>
							</tr>
							<tr>
								<td width="34%"><b><font size="1" face="Arial">Loan/Reference number:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[referenceNumber]</font></td>
							</tr>
							<tr>
								<td width="34%"><b><font size="1" face="Arial">The Closing Exchange Order ID:</font></b></td>
								<td width="63%"><font size="1" face="Arial">[orderId]</font></td>
							</tr>
							<!--AGENT-->
							
						</table>
					</td>
				</tr>
			</table>
			
			<!--STATEMENT-->
			
			<table bgcolor="#EEEEEE" cellspacing="0" cellpadding="5" width="800">
				<tr>
					<td bgcolor="#707070">
						<b><font face="Arial" style="font-size: 9pt" color="#FFFFFF">Questionnaire </font></b>
						<font color="#FFFFFF" face="Arial" style="font-size: 9pt"><b>Completed by: [vendorName]</b></font>
					</td>
				</tr>
		  
				<tr>
					<td width="90%">
						<font face="Arial" style="font-size: 9pt">
							<ol >
								<li>What specific issues did the borrower(s) have that affected the outcome of the closing?&nbsp;&nbsp;&nbsp;&nbsp;<br>
									<b>[specificIssues]</b>
								</li>
								
								<li style="border-top: 1px solid #000000;padding-top: 10px;margin-top: 10px;">Who did you attempt to reach?<br>
									<!--PRODUCT_REP-->
									
									<!--CLIENT_AGENT-->
									
									<!--TCE-->
								</li>
								
								<li style="border-top: 1px solid #000000;padding-top: 10px;margin-top: 10px;">
									Did you advise the borrower of their 3-day &quot;Right to Cancel&quot; (if applicable)?&nbsp;&nbsp;&nbsp;&nbsp; 
									<u><b>[rightToCancelOption]</b></u>
										<br>- Comments:<br>
										<b>[rightToCancelComment]</b>
								</li>
								
								<li style="border-top: 1px solid #000000;padding-top: 10px;margin-top: 10px;border-bottom: 1px solid #000000;padding-bottom: 10px;">General Comments<br>
									<b>[generalComment]</b>
								</li>

							</ol>
						</font>
			
					</td>
				</tr>
				
				<tr>
					<td>
						<font face="Arial" style="font-size: 9pt"><b>REVIEW:</b></font>
						<ul type="square">
							<li>
								<font face="Arial" style="font-size: 9pt">Package must be reviewed&nbsp; and contact must be successful with at least one party before assigning this as unsuccessful.</font>	
							</li>
						</ul>
						
						<p><font face="Arial" style="font-size: 9pt"><b>TERMS AND ACCEPTANCE:</b></font></p>
						<ul type="square">
							<li>
								<font face="Arial" style="font-size: 9pt">By submitting this document, I certify that every possible attempt has been made to insure that this signing was closed successfully.</font>
							</li>
						</ul>
				</tr>
		 
				<tr>
					<td bgcolor="#707070">
						<b><font color="#FFFFFF" face="Arial" style="font-size: 9pt">&nbsp; Digital Signature:</font></b>
					</td>
				</tr>
				
				<tr>
					<td bgcolor="#EEEEEE">
						<font style="font-size: 9pt" face="Wingdings">x</font><font face="Arial" style="font-size: 9pt">&nbsp;&nbsp;I,<b> [vendorName],</b> certify that the above information is True and Correct</font>
					</td>
				</tr>
			</table>
		  
			<table width="800" cellspacing="0" cellpadding="0">
				<tr>
					<td bgcolor="#C0C0C0"><font face="Arial" style="font-size: 9pt"><b>&nbsp;&nbsp; Notary Public Name:&nbsp;</b></font></td>
					<td bgcolor="#C0C0C0"><font face="Arial" style="font-size: 9pt"><b>Customer Last Name:</b>&nbsp;</font></td>
				</tr>
				
				<tr>
					<td bgcolor="#EEEEEE" height="30">
						<blockquote><font face="Arial" style="font-size: 9pt">[vendorName]</font></blockquote>
					</td>
					
					<td bgcolor="#EEEEEE" height="30">
						<blockquote><font face="Arial" style="font-size: 9pt"></font>[customerLastName]</blockquote>
					</td>
				</tr>
				
				<tr>
					<td bgcolor="#C0C0C0"><font face="Arial" style="font-size: 9pt"><b>&nbsp;&nbsp; Order ID #</b></font></td>
					<td bgcolor="#C0C0C0"><font face="Arial" style="font-size: 9pt"><b>Notary Rep</b></font></td>
				</tr>
				
				<tr>
					<td bgcolor="#EEEEEE" height="30">
						<blockquote><font face="Arial" style="font-size: 9pt">[orderId]</font></blockquote>
					</td>
					
					<td bgcolor="#EEEEEE" height="30">
						<blockquote><font face="Arial" style="font-size: 9pt">[referenceNumber]</font></blockquote>
					</td>
				</tr>
			</table>
		</center>
	</div>
</body>
</html>`;

export const UNSUCESSFUL_PRODUCT_REP_ITEM = `<br><font style="font-size: 9pt" face="Wingdings">x</font><font style="font-size: 9pt"> 
Product Representative - Where you Successful? <u><b>[contactedProductRepresentativeOption]</b></u></font><br>
If so, who did you contact and what where you advised to do?<br>
<b>[contactedProductRepresentativeComment]</b><br>`;

export const UNSUCESSFUL_CLIENT_AGENT_ITEM = `<br><font style="font-size: 9pt" face="Wingdings">x</font><font style="font-size: 9pt"> 
Client Agent - Where you Successful? <u><b>[contactedClientAgentOption]</b></u></font><br>
If so, who did you contact and what where you advised to do?<br>
<b>[contactedClientAgentComment]</b><br>`;

export const UNSUCESSFUL_TCE_ITEM = `<br><font style="font-size: 9pt" face="Wingdings">x</font><font style="font-size: 9pt"> 
TCE - Where you Successful? <u><b>[contactedTceOption]</b></u></font><br>
If so, who did you contact and what where you advised to do?<br>
<b>[contactedTceComment]</b><br>`;

export const SCANBACK_DOC_TEMPLATE = `<tr>
<td>
	<p>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font style="font-size: 9pt" face="Wingdings">[documentReturnedOption]</font>
		<font face="Arial" style="font-size: 9pt">Documents Return to the address provided</font>
	</p>
</td>
<td>
	<font face="Arial" style="font-size: 9pt">Docs Dropped for Shipping: <b>[docDroppedDateTime]</b></font>
</td>
</tr>`;