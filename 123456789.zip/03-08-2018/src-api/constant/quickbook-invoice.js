export const VENDOR_EXPORT_HEADER = `!TRNS	TRNSID	TRNSTYPE	DATE	ACCNT	NAME	CLASS	AMOUNT	DOCNUM	MEMO	CLEAR	TOPRINT	NAMEISTAXABLE	ADDR1	ADDR2	ADDR3	TERMS	SHIPVIA	SHIPDATE	PONUM\r\n!SPL	SPLID	TRNSTYPE	DATE	ACCNT	NAME	CLASS	AMOUNT	DOCNUM	MEMO	CLEAR	QNTY	PRICE	REIMBEXP	TAXABLE	OTHER2	YEARTODATE	WAGEBASE\r\n!ENDTRNS`;

export const VENDOR_BILL_HEADER = `Vendor	Transaction Date	RefNumber	Bill Due	Terms	Memo	Address Line1	Address Line2	Address Line3	Address Line4	Address City	Address State	Address PostalCode	Address Country	Vendor Acct No	Expenses Account	Expenses Amount	Expenses Memo	Expenses Class	Expenses Customer	Expenses Billable	Items Item	Items Qty	Items Description	Items Cost	Items Class	Items Customer	Items Billable	AP Account`;

export const CLIENT_EXPORT_HEADER = `!TRNS	TRNSID	TRNSTYPE	DATE	ACCNT	NAME	CLASS	AMOUNT	DOCNUM	MEMO	CLEAR	TOPRINT	NAMEISTAXABLE	ADDR1	ADDR2	ADDR3	TERMS	SHIPVIA	SHIPDATE	PONUM	DUEDATE\r\n!SPL	SPLID	TRNSTYPE	DATE	ACCNT	NAME	CLASS	AMOUNT	DOCNUM	MEMO	CLEAR	QNTY	PRICE	INVITEM	TAXABLE	OTHER2	YEARTODATE	WAGEBASE\r\n!ENDTRNS`;

export const CLIENT_INVOICE_HEADER = `Customer	Transaction Date	RefNumber	PO Number	Terms	Class	Template Name	To Be Printed	Ship Date	BillTo Line1	BillTo Line2	BillTo Line3	BillTo Line4	BillTo City	BillTo State	BillTo PostalCode	BillTo Country	ShipTo Line1	ShipTo Line2	ShipTo Line3	ShipTo Line4	ShipTo City	ShipTo State	ShipTo PostalCode	ShipTo Country	Phone	Fax	Email	Contact Name	First Name	Last Name	Rep	Due Date	Ship Method	Customer Message	Memo	Item	Quantity	Description	Price	Is Pending	Item Line Class	Service Date	FOB	Customer Acct No	Sales Tax Item	To Be E-Mailed	Other	Other1	Other2	AR Account	Sales Tax Code`;

export const INVOICE_REPORT_TEMPLATE = `<div align="center">
<table border="0" width="750" cellspacing="0" cellpadding="0" id="table1">
	<tbody><tr>
		<td width="486">&nbsp;</td>
		<td width="162" align="right"><font face="Arial">Invoice No:&nbsp;&nbsp;&nbsp;&nbsp; 
		</font> </td>
		<td width="102"><font face="Arial">[Orderid]</font></td>
	</tr>
	<tr>
		<td width="486">&nbsp;</td>
		<td width="162" align="right"><font face="Arial">Invoice Date:&nbsp;&nbsp;&nbsp;&nbsp; 
		</font> </td>
		<td width="102"><font face="Arial">[Now]</font></td>
	</tr>
	<tr>
		<td colspan="3">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="3"><hr noshade="" color="#000000" size="1"></td>
	</tr>
	<tr>
		<td colspan="3">
		<p align="center"><b><font style="FONT-SIZE:20pt" face="Arial" color="#000000">The Closing Exchange - Invoice</font></b></p></td>
	</tr>
	<tr>
		<td colspan="3"><hr noshade="" color="#000000" size="1"></td>
	</tr>
</tbody></table>
<table border="0" cellspacing="0" cellpadding="0" width="750">
<tbody><tr height="20">
<td width="411" align="LEFT" colspan="2"> &nbsp;</td><td width="107" align="LEFT">&nbsp;</td>
<td width="289" align="LEFT">&nbsp;</td>
</tr>
<tr height="20">
<td width="411" align="LEFT" colspan="2"> <font face="Arial"> <b>To:</b></font></td><td width="107" align="LEFT"><b>
<font style="FONT-SIZE:12pt" color="#000000" face="Arial">Questions?</font></b></td>
<td width="289" align="LEFT">&nbsp;</td>
</tr>
<tr height="20">
<td width="17" align="LEFT"> &nbsp;</td>
<td width="396" align="LEFT"> <font face="Arial">[Company]</font></td><td width="107" align="LEFT">
<font face="Arial">&nbsp;&nbsp;&nbsp; Contact:</font></td>
<td width="289" align="LEFT"><font face="Arial">Andi Passaro</font></td>
</tr>
<tr height="20">
<td width="17" align="LEFT"> &nbsp;</td>
<td width="396" align="LEFT"> <font face="Arial">[Agent]</font></td><td width="107" align="LEFT">
<font face="Arial">&nbsp;&nbsp;&nbsp; Phone:</font></td>
<td width="289" align="LEFT"><font face="Arial">(888) 228-7705 x 104</font></td>
</tr>
<tr height="20">
<td width="17" align="LEFT"> &nbsp;</td>
<td width="396" align="LEFT"> <font face="Arial">[Address]</font></td><td width="107" align="LEFT">
<font face="Arial">&nbsp;&nbsp;&nbsp; Fax:</font></td>
<td width="289" align="LEFT"><font face="Arial">(714) 677-1540</font></td>
</tr>
<tr height="20">
<td width="17" align="LEFT"> &nbsp;</td>
<td width="396" align="LEFT"> <font face="Arial">[Csz]</font></td><td width="107" align="LEFT">
<font face="Arial">&nbsp;&nbsp;&nbsp;
Email:</font></td>
<td width="289" align="LEFT"><font face="Arial">apassaro@theclosingexchange.com</font></td>
</tr>
<tr height="20">
<td width="17" align="LEFT"> &nbsp;</td>
<td width="396" align="LEFT"> <font face="Arial">[Fax]</font></td><td width="107" align="LEFT">
<font face="Arial">&nbsp;&nbsp;&nbsp; Internet:</font></td>
<td width="289" align="LEFT"><font face="Arial">www.theclosingexchange.com</font></td>
</tr>
<tr height="20">
<td width="17" align="LEFT"> &nbsp;</td>
<td width="396" align="LEFT"> &nbsp;</td><td width="107" align="LEFT">&nbsp;</td>
<td width="289" align="LEFT">&nbsp;</td>
</tr>
<tr height="20">
<td width="877" align="LEFT" colspan="4"> <hr noshade="" color="#000000" size="1"></td>
</tr>
<tr height="20">
<td width="877" align="LEFT" colspan="4"> <i><font face="Arial" color="#000000">
Thank you for placing your order with The Closing Exchange. The referenced file has been completed. Upon receipt 
of completed documents, please review the following fees that have been incurred. To avoid additional costs, please remit your payment to:<br>
<b><br>
The Closing Exchange, 15061 Springdale St., Suite 112, Huntington Beach, CA 92649</b></font></i></td>
</tr>
<tr height="20">
<td width="877" align="LEFT" colspan="4"> <hr noshade="" color="#000000" size="1"></td>
</tr>
</tbody></table>
<table border="0" width="750" cellspacing="0" cellpadding="0" id="table2">
	<tbody><tr>
		<td align="right" width="35%"><b><font size="4" face="Arial">Reference #:&nbsp;&nbsp;&nbsp;&nbsp;
		</font>
		</b></td>
		<td><font face="Arial">[Brokeridnum]</font></td>
	</tr>
	<tr>
		<td align="right"><b><font size="4" face="Arial">Client:&nbsp;&nbsp;&nbsp;&nbsp; 
		</font> </b></td>
		<td><font face="Arial">[Borrower]</font></td>
	</tr>
	<tr>
		<td align="right"><b><font size="4" face="Arial">Address:&nbsp;&nbsp;&nbsp;&nbsp; 
		</font> </b></td>
		<td><font face="Arial">[Signadd]</font></td>
	</tr>
	<tr>
		<td align="right"><b><font size="4" face="Arial">Date and Time of Signing:&nbsp;&nbsp;&nbsp;&nbsp;
		</font>
		</b></td>
		<td><font face="Arial">[Aptdatetime]</font></td>
	</tr>
	<tr>
		<td align="right"><b><font size="4" face="Arial">Courier:&nbsp;&nbsp;&nbsp;&nbsp; 
		</font> </b></td>
		<td><font face="Arial">[Courier]</font></td>
	</tr>
	<tr>
		<td align="right"><b><font size="4" face="Arial">Tracking Number:&nbsp;&nbsp;&nbsp;&nbsp; 
		</font> </b></td>
		<td><font face="Arial">[Trackingnumber]</font></td>
	</tr>
	<tr>
		<td colspan="2"> <hr noshade="" color="#000000" size="1"></td>
	</tr>
</tbody></table>
<table border="0" width="750" cellspacing="0" cellpadding="0" id="table3">
	<tbody><tr>
		<td colspan="3">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="3"><b><font size="4" face="Arial">Fees:&nbsp; </font> </b></td>
	</tr>
	<tr>
		<td width="81">&nbsp;</td>
		<td width="554">&nbsp;</td>
		<td width="115" align="right">&nbsp;</td>
	</tr>
<!--FEES-->

	<tr>
		<td colspan="2">
		&nbsp;</td>
		<td width="115" align="right"><hr noshade="" color="#000000" size="1"></td>
	</tr>
	<tr>
		<td colspan="2">
		<p align="right"><b><font size="4" face="Arial">Total:&nbsp;&nbsp;&nbsp;&nbsp; </font> </b></p></td>
		<td width="115" align="right"><font size="4" face="Arial"><b>[Total]</b></font></td>
	</tr>
	<tr>
		<td colspan="3">&nbsp;</td>
	</tr>
</tbody></table>
 
<table border="1" width="750" bordercolorlight="#000000" cellspacing="0" cellpadding="5" bordercolordark="#000000" style="border-collapse: collapse" id="table4">
	<tbody><tr>
		<td>
		
<table border="0" cellspacing="0" cellpadding="0" width="100%" id="table6">
<tbody><tr height="17">
<td width="790" align="LEFT" colspan="3">
<b><font face="Arial" color="#000000" size="4">Remittance Advice</font></b></td>
</tr>
<tr height="17">
<td width="799" align="LEFT" colspan="3" height="25">
&nbsp;</td>
</tr>
<tr height="17">
<td width="480" align="LEFT" colspan="2" height="50">
<font face="Arial" color="#000000">To ensure proper credit, please return this portion<br>
&nbsp;with your payment 
to The Closing Exchange.</font></td>
<td width="319" align="LEFT" height="50">

<table border="1" cellpadding="0" width="95%" id="table7" style="border-collapse: collapse" bordercolorlight="#000000" bordercolordark="#000000">
<tbody><tr height="17">
<td width="139" align="center" height="25"><font face="Arial"><b><font color="#000000">Invoice </font>#</b></font></td>
<td width="180" align="center" height="25"><b><font color="#000000" face="Arial">Amount Due</font></b></td>
</tr>
<tr height="17">
<td width="139" align="center" height="25"><font face="Arial">[Orderid]</font></td>
<td width="180" align="center" height="25"><font face="Arial">[Total]</font></td>
</tr>
</tbody></table>
</td>
</tr>
<tr height="17">
<td width="480" align="LEFT" colspan="2" height="25">&nbsp;</td>
<td width="320" align="LEFT" height="25">&nbsp;</td>
</tr>
<tr height="17">
<td width="480" align="LEFT" colspan="2" height="25"><b>
<font face="Arial" color="#000000">Your Payment is due upon reciept</font></b></td>
<td width="320" align="LEFT" height="25"><font face="Arial"><b>Send payment to:</b></font></td>
</tr>
<tr height="17">
<td width="14" align="LEFT" height="25">&nbsp;</td>
<td width="466" align="LEFT" height="25"><font face="Arial">[Company]</font></td>
<td width="320" align="LEFT" height="25"><font face="Arial">&nbsp;&nbsp;&nbsp; The Closing Exchange</font></td>
</tr>
<tr height="17">
<td width="14" align="LEFT" height="25">&nbsp;</td>
<td width="466" align="LEFT" height="25"><font face="Arial">[Address]</font></td>
<td width="320" align="LEFT" height="25"><font face="Arial">&nbsp;&nbsp;&nbsp; 15061 Springdale St., Suite 112</font></td>
</tr>
<tr height="17">
<td width="14" align="LEFT" height="25">&nbsp;</td>
<td width="466" align="LEFT" height="25"><font face="Arial">[Csz]</font></td>
<td width="320" align="LEFT" height="25"><font face="Arial">&nbsp;&nbsp;&nbsp; Huntington Beach, CA 92649</font></td>
</tr>
<tr height="17">
<td width="14" align="LEFT" height="25">&nbsp;</td>
<td width="466" align="LEFT" height="25">&nbsp;</td>
<td width="320" align="LEFT" height="25">&nbsp;</td>
</tr>
</tbody></table>
 	
	
		</td>
	</tr>
</tbody></table>
</br></br></div>`;

export const SPREADSHEET_INVOICE_TEMPLATE = `<div style="position:relative;width: 100%;height: 100%;" align="center">
</br>
<table border="0" width="750" cellspacing="0" cellpadding="0" id="table1">
	<tbody>
	<tr>
		<td colspan="3">
		<p align="center"><b><font style="FONT-SIZE:14pt" face="" color="#000000">Broker Billing Summary Report For [FromDate] - [ToDate]</b></p></td>
	</tr>
</tbody></table>
</br>
<table border="0" width="750" cellspacing="0" cellpadding="2" id="table1">
	<tbody>
	<tr>
		<td width="450">
		  <a href="http://www.theclosingexchange.com/" target="_blank">
				<img width="80%" height="130%" style="margin-bottom:50px" src="http://www.theclosingexchange.com/images/logo-97.jpg">
			</a>
		</td>
		<td width="300">
			<table style="FONT-SIZE:11pt" border="0" cellspacing="0" cellpadding="2" id="">
				<tr style="FONT-SIZE:13pt">
					<td width="300" align="left"><b>Questions?</b></td>		
				</tr>
				<tr>
					<td width="300" align="left">Contact: Andi Passaro</b></td>		
				</tr>
				<tr>
					<td width="300" align="left">Phone: (888) 228-7705 x 104</b></td>		
				</tr>
				<tr>
					<td width="300" align="left">Fax: (714) 677-1540</b></td>		
				</tr>
				<tr>
					<td width="300" align="left">Email: apassaro@theclosingexchange.com</b></td>		
				</tr>
				<tr>
					<td width="300" align="left">Address: 15061 Springdale St., Suite 112, Huntington Beach, CA 92649</b></td>		
				</tr>
			</table>
		</td>
	</tr>

</tbody></table>
<br/>
<table border="0" width="750" cellspacing="0" cellpadding="0" id="table1">
	<tbody>
	<tr align="left" style="FONT-SIZE:9pt">
		<th>Borrower Last</th>
		<th>Closed Date</th>
		<th>Order Date</th>
		<th>Turn</th>
		<th>Order ID</th>
		<th>Loan/Escrow #</th>
		<th>City</th>
		<th>State</th>
		<th style="width:80px">Fee</th>	
	</tr>
	<tr>
		<td colspan="10"><hr style="margin:0" noshade="" color="#000000" size="1"></td>
	</tr>
	<!-- FeeDetails -->
	<tr>
		<td style="padding-top:10px" colspan="10" align="right"><font style="FONT-SIZE:11pt" face=""><b style="margin-right:28px"><!-- TotalFees --></b></td>
	</tr>
</tbody></table>

<div style="FONT-SIZE:9pt;position: absolute;bottom: 10px;width:100%">
<div>
<b>Page [PageIndex] of [Pages]</b>
</div>
</div>

</br></br></div>`;