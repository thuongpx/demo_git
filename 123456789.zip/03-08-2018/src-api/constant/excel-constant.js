export const EXCEL_DATA_STYLE = {
    titleStyle: {
        font: {
            color: "#FF0800",
            size: 20,
            bold: true
        },
        alignment: {
            wrapText: false,
            horizontal: "center"
        }
    },
    defaultStyle: {
        font: {
            size: 12
        }
    },
    columnHeaderStyle: {
        font: {
            size: 16,
            bold: true
        },
        alignment: {
            wrapText: false,
            horizontal: "center"
        }
    },
    moneyStyle: {
        font: {
            size: 12
        },
        numberFormat: "$#,##0.00; -$#,##0.00; -"
    }
};