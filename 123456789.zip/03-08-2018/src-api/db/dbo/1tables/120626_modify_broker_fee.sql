DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	DROP TABLE IF EXISTS `broker_selfservice_fee`;
    
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_fee' AND 
                            COLUMN_NAME = 'SelfServiceVendorFee') THEN
	BEGIN
		ALTER TABLE `broker_fee` 
		ADD COLUMN `SelfServiceVendorFee` DECIMAL(19, 4) NULL ;
	END;
    END IF;
    
    UPDATE `broker_fee` bf    
    INNER JOIN `industry_transaction_fees` i ON bf.SystemFee = i.FeeId
		SET SelfServiceVendorFee = i.VendorFee
    WHERE SelfServiceVendorFee IS NULL AND bf.FeeId <> 0;
END$$

DELIMITER ;
CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;