DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	-- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'business_hours' AND 
                            COLUMN_NAME = 'DayOfWeek') THEN
	BEGIN
		ALTER TABLE `business_hours` ADD COLUMN `DayOfWeek` INT;
	END;
    END IF;
    
    UPDATE business_hours
    SET DayOfWeek = CASE Day WHEN 'SUN' THEN 1
								WHEN 'MON' THEN 2
                                WHEN 'TUE' THEN 3
                                WHEN 'WED' THEN 4
                                WHEN 'THU' THEN 5
                                WHEN 'FRI' THEN 6
                                WHEN 'SAT' THEN 7
                                ELSE NULL END
	WHERE DayOfWeek IS NULL AND BussinessHoursId <> 0;
END$$

DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;