DROP PROCEDURE IF EXISTS `alter_table_order_fee_approve`;

DELIMITER $$
CREATE PROCEDURE `alter_table_order_fee_approve` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order_fee_approve' AND 
                            COLUMN_NAME = 'OfferID') THEN
	BEGIN
		ALTER TABLE `order_fee_approve` 
		ADD COLUMN `OfferID` INT NULL;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_order_fee_approve();

DROP PROCEDURE IF EXISTS `alter_table_order_fee_approve`;