DROP PROCEDURE IF EXISTS `alter_table_progress`;

DELIMITER $$
CREATE PROCEDURE `alter_table_progress` ()
BEGIN
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'progress' AND 
                            COLUMN_NAME = 'ProgressDescription') THEN
	BEGIN
		ALTER TABLE `progress` 
		MODIFY COLUMN `ProgressDescription` VARCHAR(100) NULL;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_progress();

DROP PROCEDURE IF EXISTS `alter_table_progress`;
