-- drop order_collect
ALTER TABLE `order` 
DROP FOREIGN KEY `CollectId`;

ALTER TABLE `order` 
DROP COLUMN `CollectId`,
DROP INDEX `CollectId_idx`;

DROP TABLE order_collect;