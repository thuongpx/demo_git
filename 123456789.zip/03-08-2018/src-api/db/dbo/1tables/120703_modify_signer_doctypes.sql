DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN    
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'signer_doctypes' AND 
                            COLUMN_NAME = 'IsRequiredDoc') THEN
	BEGIN
		ALTER TABLE `signer_doctypes` ADD COLUMN `IsRequiredDoc` BIT;
	END;
    END IF;
END$$
DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;