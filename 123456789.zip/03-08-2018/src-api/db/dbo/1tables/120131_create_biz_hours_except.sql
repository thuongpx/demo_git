CREATE TABLE IF NOT EXISTS `biz_hours_except` (
	ExceptID INT(11) NOT NULL,
	Description VARCHAR(100) NULL,
	ExceptDate DATE NULL,
	OpenTime DATETIME NULL,
	CloseTime DATETIME NULL,
	Closed BIT NULL,
    PRIMARY KEY (`ExceptID`)
);