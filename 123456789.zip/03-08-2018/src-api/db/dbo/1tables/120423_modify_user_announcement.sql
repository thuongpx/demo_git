DROP PROCEDURE IF EXISTS `alter_table_user_announcement`;

DELIMITER $$
CREATE PROCEDURE `alter_table_user_announcement` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'user_announcement' AND 
                            COLUMN_NAME = 'InActive') THEN
	BEGIN
		ALTER TABLE `user_announcement` 
		ADD COLUMN `InActive` BIT NULL;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_user_announcement();

DROP PROCEDURE IF EXISTS `alter_table_user_announcement`;

