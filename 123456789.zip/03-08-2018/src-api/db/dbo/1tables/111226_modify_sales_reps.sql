ALTER TABLE `sales_reps` ADD COLUMN `CommissionPercent` FLOAT NULL AFTER `LastName`;
ALTER TABLE `sales_reps` ADD COLUMN `CommissionAmount` DECIMAL(19,4) NULL AFTER `CommissionPercent`;
