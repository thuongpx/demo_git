ALTER TABLE `test_info` 
ADD COLUMN `ExpiredAfter` SMALLINT NULL;
