DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	-- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'training_programs' AND 
                            COLUMN_NAME = 'AdditionalProgram') THEN
	BEGIN
		ALTER TABLE `training_programs`
        ADD COLUMN `AdditionalProgram` BIT;
	END;
    END IF;      
END$$

DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;