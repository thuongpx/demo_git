ALTER TABLE `users` 
CHANGE COLUMN `IsActive` `IsActive` BIT(1) NULL DEFAULT b'1' ;