import NotaryTraning from "./vendor-notary-training-controller";

const routes = [{
    path: "/notarytraning/getListRegisteredPrograms",
    method: "GET",
    handler: NotaryTraning.getListRegisteredPrograms
},
{
    path: "/vendor-notary-training-controller/getListLearningPath",
    method: "GET",
    handler: NotaryTraning.getListLearningPath
},
{
    path: "/vendor-notary-training-controller/getListPopularProgram",
    method: "GET",
    handler: NotaryTraning.getListPopularProgram
},
{
    path: "/notarytraning/getListAllPrograms",
    method: "GET",
    handler: NotaryTraning.getListAllPrograms
},
{
    path: "/vendor-notary-training-controller/registerPopularProgram",
    method: "POST",
    handler: NotaryTraning.registerPopularProgram
},
{
    path: "/notarytraning/getCurrentRegisteredPrograms",
    method: "GET",
    handler: NotaryTraning.getCurrentRegisteredProgram
},
{
    path: "/notarytraning/getCourseAndTestByProgramId",
    method: "GET",
    handler: NotaryTraning.getCourseAndTestByProgramId
},
{
    path: "/notarytraning/getListCourseandTestbyProgramId",
    method: "GET",
    handler: NotaryTraning.getListCourseandTestbyProgramId
},
{
    path: "/vendor-notary-training-controller/getListRecentCourses",
    method: "GET",
    handler: NotaryTraning.getListRecentCourses
},
{
    path: "/vendor-training-controller/getCourseOfCurrentProgram",
    method: "GET",
    handler: NotaryTraning.getCourseOfCurrentProgram
},
{
    path: "/vendor-training-controller/downloadDoc",
    method: "GET",
    config: {
        auth: false
    },
    handler: NotaryTraning.downloadDoc
},
{
    path: "/vendor-training-controller/addVendorCoursesResult",
    method: "POST",
    handler: NotaryTraning.addVendorCoursesResult
}, {
    path: "/video/getCourseVideo",
    method: "GET",
    config: { auth: false },
    handler: NotaryTraning.getCourseVideo
}, {
    path: "/vendor-training-controller/updateCourse",
    method: "POST",
    handler: NotaryTraning.updateCourse
}, {
    path: "/document/getCourseDocument",
    method: "GET",
    config: { auth: false },
    handler: NotaryTraning.getCourseDocument
}
];

export default routes;