import Bookshelf from "../../db/database";
import Boom from "boom";
import {
    handleSingleQuote,
    bufferToBoolean,
    isBuffer
} from "../../helper/common-helper";
import moment from "moment";
import fs from "fs";
import VendorCoursesResult from "../../db/model/vendor_courses_result";
import appConfig from "../../config/config";

class NotaryTraning {
    getListRegisteredPrograms(request, reply) {
        const {
            searchValue,
            userId
        } = request.query;
        const newSearchValue = (searchValue === "" || searchValue === undefined) ? "" : handleSingleQuote(searchValue);
        const rawSql = `SELECT VRP.ProgramId, TP.Title, TP.Description,
                            (SELECT group_concat(TPC1.CourseId) FROM training_program_courses TPC1 WHERE TPC1.ProgramId = VRP.ProgramId) AS Course,
                            (SELECT group_concat(VCR.CourseId) FROM vendor_courses_result VCR WHERE VCR.ProgramId = VRP.ProgramId AND VCR.VendorId = ${userId} AND VCR.IsComplete = 1) as CourseComPleted,
                            (SELECT group_concat(TPT.TestId) FROM training_program_test TPT WHERE TPT.ProgramId = VRP.ProgramId) AS Test,
                            (SELECT group_concat(VTR.TestId) FROM vendor_test_result VTR WHERE VTR.ProgramId = VRP.ProgramId AND VTR.VendorId = ${userId} AND VTR.Passed = 'Y') AS TestCompleted,
                            (SELECT VC.EndDate FROM vendor_courses_result VC WHERE VC.ProgramId = VRP.ProgramId AND VC.VendorId = 4 AND VC.IsComplete = 1 ORDER BY VC.EndDate DESC LIMIT 1) AS CourseCompletedDate,
                            (SELECT VT.EndDate FROM vendor_test_result VT WHERE VT.ProgramId = VRP.ProgramId AND VT.VendorId = 4 AND VT.Passed = 'Y' ORDER BY VT.EndDate DESC LIMIT 1) AS TestCompletedDate
                        FROM vendor_registered_programs VRP 
                            INNER JOIN training_programs TP ON TP.ProgramId = VRP.ProgramId
                        where tp.ForVendor = 1 AND tp.Inactive = 0 AND vrp.VendorId = ${userId} and 
                            (tp.Title LIKE '%${newSearchValue}%' or tp.Description LIKE '%${newSearchValue}%')
                        group by VRP.ProgramId order by tp.Title;`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    const data = result[0];

                    data.map(item => {
                        const courseArr = item.Course ? item.Course.split(",").sort() : [];
                        const courseUnCompletedArr = item.CourseComPleted ? item.CourseComPleted.split(",").sort() : [];
                        const testArr = item.Test ? item.Test.split(",").sort() : [];
                        const testUnCompletedArr = item.TestCompleted ? item.TestCompleted.split(",").sort() : [];

                        if (JSON.stringify(courseArr) === JSON.stringify(courseUnCompletedArr) && JSON.stringify(testArr) === JSON.stringify(testUnCompletedArr)) {
                            item.IsComplete = true;
                        }

                        item.completedDate = (item.CourseCompletedDate >= item.TestCompletedDate) ? item.CourseCompletedDate : item.TestCompletedDate;
                    });

                    reply({
                        listRegisteredProgram: data
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getListAllPrograms(request, reply) {
        const {
            searchValue,
            userId
        } = request.query;
        const newSearchValue = (searchValue === "" || searchValue === undefined) ? "" : handleSingleQuote(searchValue);
        const rawSql = `SELECT DISTINCT tp.ProgramId, tp.Title, tp.Description FROM training_programs tp 
                            LEFT JOIN training_program_courses tpc ON tpc.ProgramId = tp.ProgramId
                            LEFT JOIN training_courses tc ON tc.CourseId = tpc.CourseId
                        WHERE tp.Inactive = 0 AND tp.IsPublished = 1 AND tp.ForVendor = 1 AND tp.ProgramId NOT IN (SELECT vr.ProgramId FROM  vendor_registered_programs vr WHERE vr.VendorId = ${userId})
                            AND (tp.Title LIKE '%${newSearchValue}%' or tp.Description LIKE '%${newSearchValue}%' or tc.Title LIKE '%${newSearchValue}%')
                        GROUP BY tp.ProgramId ORDER BY tp.Title`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result[0] !== null) {
                    reply({
                        listAllProgram: result[0]
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getListCourseandTestbyProgramId(request, reply) {
        const {
            programId
        } = request.query;
        const rawSql = `SELECT distinct tc.CourseId, ti.TestId, vcr.StartDate as courcestartdate, vcr.EndDate as courseenddate, vcr.IsComplete as coursestatus,
        vtr.StartDate as teststartdate, vtr.EndDate as testenddate, vtr.Passed as teststatus
        FROM vendor_registered_programs vr
        INNER JOIN training_program_courses tpc on vr.ProgramId = tpc.ProgramId
        INNER JOIN training_program_test tpt on vr.ProgramId = tpt.ProgramId
        INNER JOIN training_courses tc on tc.CourseId = tpc.CourseId
        INNER JOIN vendor_courses_result vcr on vcr.CourseId = tc.CourseId
        INNER JOIN vendor_test_result vtr on vtr.TestId = tpt.TestId
        INNER JOIN test_info ti on ti.TestId = tpt.TestId
        WHERE vr.ProgramId = ${programId}`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                reply({
                    listCourseandTestinProgram: result[0]
                });
            }).catch((error) => {
                reply(`"Not found record: " + ${error}`);
            });
    }

    getListRecentCourses(request, reply) {
        const {
            signerId
        } = request.query;
        const rawSql = `select c.CourseId, c.Title, cr.StartDate, cr.EndDate, cr.LastViewedDate, cr.IsComplete, c.Description 
                        from training_courses c
                        inner join vendor_courses_result cr on c.CourseId = cr.CourseId
                        where cr.VendorId = ${signerId} and c.Inactive = 0
                        ORDER BY cr.LastViewedDate desc
                        limit 10;`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                const data = result[0];

                data.map((item) => {
                    Object.keys(item).forEach(key => {
                        const value = item[key];

                        if (isBuffer(value)) {
                            item[key] = bufferToBoolean(value);
                        }
                    });
                });

                reply({
                    isSuccess: true,
                    isNotFound: false,
                    listRecentCourses: data
                });
            }
        }).catch((error) => {
            reply(`"Not found record : " + ${error}`);
        });
    }

    getListLearningPath(request, reply) {
        const rawSql = `SELECT lp.LPID learningPathId, lp.LPName learningPathName, p.Title, p.ForVendor, p.Inactive, p.IsPublished FROM training_learning_path lp 
                            inner join training_lp_programs lpp on lp.LPID = lpp.LPID
                            inner join training_programs p on lpp.ProgramId = p.ProgramId
                        where p.ForVendor = 1 and p.Inactive = 0 and p.IsPublished = 1;`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                const data = result[0];

                data.map((item) => {
                    item.ForVendor = bufferToBoolean(item.ForVendor);
                    item.Inactive = bufferToBoolean(item.Inactive);
                    item.IsPublished = bufferToBoolean(item.IsPublished);
                });

                reply({
                    isSuccess: true,
                    isNotFound: false,
                    listLearningPath: result[0]
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getListPopularProgram(request, reply) {
        const { signerId } = request.query;
        const rawSql = `SELECT * FROM vendor_registered_programs v 
                        LEFT JOIN training_programs tp ON v.ProgramId = tp.ProgramId	
                        WHERE tp.Inactive = 0 AND v.VendorId = ${signerId}
                        GROUP BY v.ProgramId 
                        ORDER BY COUNT(v.ProgramId) DESC
                        LIMIT 10;`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                reply({
                    listPopularProgram: result[0]
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    registerPopularProgram(request, reply) {
        const {
            signerId,
            programId
        } = request.payload;
        const rawSql = `INSERT INTO vendor_registered_programs
                        ( VendorId, ProgramId, IsComplete, RegisteredDate)
                        VALUES ( ${signerId}, ${programId}, 0, NOW());`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });

            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
    getCurrentRegisteredProgram(request, reply) {
        const {
            program,
            userId
        } = request.query;
        const rawSql = `SELECT tp.Title as title, tp.Description as description, vrp.VendorId as vendorId,
            (SELECT COUNT(*) FROM (SELECT TPC.CourseId FROM training_program_courses TPC where TPC.ProgramId = ${program} group by TPC.CourseId) B 
            WHERE B.CourseId NOT IN (SELECT VCR.CourseId FROM vendor_courses_result VCR WHERE VCR.ProgramId = ${program} AND VCR.IsComplete = 1 AND VCR.VendorId = ${userId})) AS totalCourseUnCompleted,
            (SELECT COUNT(*) FROM (SELECT TPT.TestId FROM training_program_test TPT where TPT.ProgramId = ${program} group by TPT.TestId) B1 
            WHERE B1.TestId NOT IN (SELECT VTR.TestId FROM vendor_test_result VTR WHERE VTR.ProgramId = ${program} AND VTR.Passed = 'Y' AND VTR.VendorId = ${userId})) AS totalTestUnCompleted
        FROM  training_programs TP 
            LEFT JOIN vendor_registered_programs VRP ON TP.ProgramId = VRP.ProgramId AND VRP.VendorId = ${userId} AND VRP.ProgramId = ${program}
            LEFT JOIN training_program_courses TPC ON TPC.ProgramId = VRP.ProgramId
        where TP.ProgramId = ${program} group by TP.ProgramId;`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result[0][0] !== null && result[0][0] !== undefined) {
                    const data = result[0][0];

                    data.iscomplete = !(data.totalCourseUnCompleted + data.totalTestUnCompleted > 0);

                    if (data) {
                        reply({
                            currentRegisteredProgram: data
                        });
                    }
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getCourseAndTestByProgramId(request, reply) {
        const {
            programId,
            signerId
        } = request.query;

        const getCourses = Promise.resolve(Bookshelf.knex.raw(`SELECT DISTINCT tc.CourseId, tpc.ProgramId, tc.Title, vcr.IsComplete, vcr.StartDate, vcr.EndDate, tc.ViewsCount, tc.Description
                                                                FROM training_courses tc
                                                                    INNER JOIN training_program_courses tpc ON tpc.CourseId = tc.CourseId
                                                                    LEFT JOIN vendor_courses_result vcr ON vcr.CourseId = tpc.CourseId AND vcr.VendorId = ${signerId} AND vcr.ProgramId = ${programId}
                                                                WHERE tpc.ProgramId = ${programId} AND tc.Inactive = 0 
                                                                    GROUP BY CourseId;`));

        const getTests = Promise.resolve(Bookshelf.knex.raw(`SELECT distinct tpt.ProgramId, ti.TestId, ti.TestName, vtr.Passed, vtr.StartDate, vtr.EndDate, vtr.TestedNum, vtr.LastTesting, ti.MaxAttempts, ti.Lockdays, ti.TestDesc
                                                            FROM training_program_test as tpt
                                                                Inner join  test_info as ti on ti.TestId = tpt.TestId
                                                                LEFT join vendor_test_result as vtr on vtr.TestId =  ti.TestId and vtr.VendorId = ${signerId} and vtr.ProgramId = ${programId}
                                                            WHERE tpt.ProgramId = ${programId} AND ti.Active = 1
                                                                group by tpt.TestId;`));

        Promise.all([getCourses, getTests]).then(values => {
            const dataresult = {};
            if (values !== null) {
                values.forEach((item, index) => {
                    if (item !== null) {
                        switch (index) {
                            case 0:
                                dataresult.courses = item[0];
                                break;
                            case 1:
                                item[0].forEach(item1 => {
                                    const nowDate = moment().utc();
                                    const lastTestingDate = moment(item1.LastTesting).utc();
                                    const daysDiff = nowDate.diff(lastTestingDate, "days");

                                    if (item1.TestedNum === item1.MaxAttempts && daysDiff < item1.Lockdays) {
                                        item1.isMaxAttempts = true;
                                        item1.numDayRetake = item1.Lockdays - daysDiff;
                                    } else {
                                        item1.isMaxAttempts = false;
                                    }
                                });
                                dataresult.tests = item[0];
                                break;
                        }
                    }

                });
                dataresult.courses.map(item => {
                    item.IsComplete = bufferToBoolean(item.IsComplete);
                });
                dataresult.isSuccess = true;
                reply(dataresult);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getCourseOfCurrentProgram(request, reply) {
        const {
            ProgramId,
            CourseId,
            signerId
        } = request.query;
        const newProgramId = (ProgramId === "" || ProgramId === undefined) ? "" : handleSingleQuote(ProgramId);
        const newCourseId = (CourseId === "" || CourseId === undefined) ? "" : handleSingleQuote(CourseId);
        const rawSql = `select distinct tc.CourseId, tc.Title, tc.Description, tc.VideoFile, tc.Document, tc.Duration, tc.CreatedDate, tc.ViewsCount, tc.PosterFile, tc.Downloaded, vr.IsComplete, vc.StartDate, vc.EndDate, vc.LastViewedDate
                        from training_courses tc 
                            left join training_program_courses tp on tc.CourseId = tp.CourseId
                            left join vendor_registered_programs vr on tp.ProgramId = vr.ProgramId
                            left join vendor_courses_result vc on vc.CourseId = tc.CourseId AND vc.ProgramId = vr.ProgramId
                        where tp.ProgramId = ${newProgramId} and tc.CourseId = ${newCourseId} and vr.VendorId = ${signerId}; `;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                const data = result[0];

                if (data.length !== 0) {
                    const courseOfCurrentProgram = data[0];

                    Object.keys(courseOfCurrentProgram).forEach(key => {
                        const value = courseOfCurrentProgram[key];

                        if (isBuffer(value)) {
                            courseOfCurrentProgram[key] = bufferToBoolean(value);
                        }
                    });

                    if (courseOfCurrentProgram) {
                        reply({
                            isSuccess: true,
                            courseOfCurrentProgram
                        });
                    }
                }
            }).catch((error) => {
                reply(`"Not found record : " + ${error} `);
            });
    }

    downloadDoc(request, reply) {
        const input = request.query;
        const rawSql = `Update training_courses set Downloaded = ${input.Downloaded} WHERE CourseId = ${input.CourseId} `;
        const path = `${appConfig.file.serverPath}/upload/training-course-temp/${input.CourseId}-${input.Document}`;

        if (fs.existsSync(path)) {
            Bookshelf.knex.raw(rawSql).then(() => {
                // serve file
                reply.file(path);
            });
        } else {
            reply(Boom.badRequest(`File ${input.Document} is not exists.`));
        }
    }

    addVendorCoursesResult(request, reply) {
        const courses = request.payload;
        const deleteSql = `DELETE FROM vendor_courses_result WHERE CourseId = ${courses.CourseId} AND VendorId = ${courses.VendorId} AND ProgramId = ${courses.ProgramId} AND ResultId <> 0`;

        delete courses.Title;
        delete courses.ViewsCount;
        delete courses.Description;

        Object.keys(courses).forEach(key => {
            const value = courses[key];

            if (value === "Invalid date") {
                courses[key] = null;
            }
        });

        Bookshelf.knex.raw(deleteSql).then(() => {
            new VendorCoursesResult().save(courses, {
                method: "insert"
            }).then(() => {
                reply({
                    isSuccess: true
                });
            }).catch(error => reply(Boom.badRequest(error)));
        });
    }

    getCourseVideo(request, reply) {
        const { CourseId, VideoFile } = request.query;
        const path = `${appConfig.file.serverPath}/upload/training-course-temp/${CourseId}-${VideoFile}`;

        fs.readFile(path, (err, data) => {
            if (err) throw err;
            reply(data);
        });
    }

    getCourseDocument(request, reply) {
        const { CourseId, Document } = request.query;
        const path = `${appConfig.file.serverPath}/upload/training-course-temp/${CourseId}-${Document}`;

        if (fs.existsSync(path)) {
            reply.file(path);
        } else {
            reply(Boom.badRequest(`File is not exists.`));
        }
    }

    updateCourse(request, reply) {
        const { CourseId, ViewsCount } = request.payload;
        const rawSql = `Update training_courses set ViewsCount = ${ViewsCount}  WHERE CourseId = ${CourseId}`;

        Bookshelf.knex.raw(rawSql).then(() => {
            reply({
                isSuccess: true
            });
        }).catch(error => reply(Boom.badRequest(error)));
    }

}

export default new NotaryTraning();