import ClientController from "./client-controller";

const routes = [
    {
        path: "/client/getClients",
        method: "POST",
        handler: ClientController.getClients
    },
    {
        path: "/client/getClientManagementData",
        method: "POST",
        handler: ClientController.getClientManagementData
    },
    {
        path: "/client/addClient",
        method: "POST",
        config: { auth: false },
        handler: ClientController.addClient
    },
    {
        path: "/client/updateClient",
        method: "POST",
        handler: ClientController.updateClient
    },
    {
        path: "/client/getClientById",
        method: "GET",
        handler: ClientController.getClientById
    },
    {
        path: "/client/changeStatusClient",
        method: "GET",
        handler: ClientController.changeStatusClient
    },
    {
        path: "/client/getClientContactByClientId",
        method: "GET",
        handler: ClientController.getClientContactByClientId
    },
    {
        path: "/client/getClientOrderByClientId",
        method: "GET",
        handler: ClientController.getClientOrderByClientId
    },
    {
        path: "/client/getAllClientForDropDown",
        method: "GET",
        handler: ClientController.getAllClientForDropDown
    },
    {
        path: "/client/updateClientContact",
        method: "POST",
        handler: ClientController.updateClientContact
    },
    {
        path: "/client/getBranchesByBrokerId",
        method: "GET",
        handler: ClientController.getBranchesByBrokerId
    },
    {
        path: "/client/getClientStatusReport",
        method: "GET",
        handler: ClientController.getClientStatusReport
    },
    {
        path: "/client/updateClientIsAvailable",
        method: "POST",
        handler: ClientController.updateClientIsAvailable
    },
    {
        path: "/client/getSpecialInstrucionOfClient",
        method: "GET",
        handler: ClientController.getSpecialInstrucionOfClient
    },
    {
        path: "/client/getClientBranchDropDown",
        method: "GET",
        handler: ClientController.getClientBranchDropDown
    },
    {
        path: "/client/getHybridQuestionData",
        method: "GET",
        handler: ClientController.getHybridQuestionData
    },
    {
        path: "/client/sendMailUpdateInfoClient",
        method: "POST",
        handler: ClientController.sendMailUpdateInfoClient
    },
    {
        path: "/client/uploadLendorSpecifics",
        method: "POST",
        config: {
            auth: "jwt",
            payload: {
                output: "stream",
                maxBytes: 1024 * 1024 * 20, // max: 20 MB
                allow: "multipart/form-data"
            }
        },
        handler: ClientController.uploadLendorSpecifics
    },
    {
        path: "/client/deleteLendorSpecifics",
        method: "POST",
        handler: ClientController.deleteLendorSpecifics
    },
    {
        path: "/client/Lenderspecifics",
        method: "GET",
        config: { auth: false },
        handler: ClientController.getLenderDocument
    }
];

export default routes;