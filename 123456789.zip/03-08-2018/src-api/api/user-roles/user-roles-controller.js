import Bookshelf from "../../db/database";
import Boom from "boom";

import UserRoles from "../../db/model/user-roles";

class UserRolesController {

    addUserRole(request, reply) {
        const { data } = request.payload;
        const dataAdd = [];
        const dataDelete = [];

        let isAddSuccess = false;
        let isDeleteSuccess = false;

        data.forEach((item) => {
            if (item.isAdd && item.isDelete === undefined) {
                dataAdd.push({
                    UsersId: item.UsersId,
                    RoleId: item.RoleId
                });
            }

            if (item.isDelete && item.isAdd === undefined) {
                dataDelete.push({
                    UsersId: item.UsersId,
                    RoleId: item.RoleId
                });
            }
        });

        const CustomUserRoles = Bookshelf.Collection.extend({
            model: UserRoles
        });
        const userRolesAdd = CustomUserRoles.forge(dataAdd);

        userRolesAdd.invokeThen("save").then((result) => {
            if (result !== null) {
                isAddSuccess = true;
            }
        }).catch(error => {
            reply(Boom.badRequest(`${error.code}: ${error.sqlMessage}`));
        });

        dataDelete.forEach(item => {
            UserRoles.where({ UsersId: item.UsersId, RoleId: item.RoleId }).destroy().then((result) => {
                if (result !== null) {
                    isDeleteSuccess = true;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        });

        reply({
            isAddSuccess,
            isDeleteSuccess
        });
    }
}

export default new UserRolesController();