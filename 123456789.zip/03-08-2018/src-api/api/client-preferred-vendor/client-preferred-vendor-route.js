import clientPreferredVendorController from "./client-preferred-vendor-controller";


const routes = [
    {
        path: "/client-preferred-vendor/addClientPreferredVendor",
        method: "POST",
        handler: clientPreferredVendorController.addClientPreferredVendor
    },
    {
        path: "/client-preferred-vendor/addClientPreferredVendorOutsideTCE",
        method: "POST",
        handler: clientPreferredVendorController.addClientPreferredVendorOutsideTCE
    },
    {
        path: "/client-preferred-vendor/deletePreferredVendor",
        method: "GET",
        handler: clientPreferredVendorController.deletePreferredVendor
    },
    {
        path: "/client-preferred-vendor/deleteAllClientPreferredVendor",
        method: "GET",
        handler: clientPreferredVendorController.deleteAllClientPreferredVendor
    },
    {
        path: "/client-preferred-vendor/isExistsClientPreferred",
        method: "POST",
        handler: clientPreferredVendorController.isExistsClientPreferred
    }
];

export default routes;