import Boom from "boom";
import Bookshelf from "./../../db/database";
import ClientMTDConfig from "../../db/model/client-mtd-config";
import moment from "moment";

class ClientMTDConfigController {
    getClientMTDConfigByUserId(request, reply) {
        const { userId } = request.query;
        const rawSql = `Select Id AS id, Period AS period, FromDate AS fromDate, ToDate AS toDate, UserId AS userId FROM client_mtd_config WHERE UserId = ${userId}`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result[0][0] !== null && result[0][0] !== undefined) {
                reply({
                    clientConfig: result[0][0]
                });
            } else {
                const clientConfig = {
                    Period: "MTD",
                    FromDate: null,
                    ToDate: null,
                    UserId: userId
                };
                new ClientMTDConfig().save(clientConfig, {
                    method: "insert"
                }).then(() => {
                    if (result !== null) {
                        const data = result.attributes;
                        const id = data.id;
                        reply({
                            period: "MTD",
                            fromDate: null,
                            toDate: null,
                            userId,
                            id
                        });
                    }
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                });
            }
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    addClientMTDConfig(request, reply) {
        const inputs = request.payload;
        const rawSql = `DELETE FROM client_mtd_config WHERE UserId = ${inputs.userId} AND Id <> 0`;

        Bookshelf.knex.raw(rawSql).then(() => {
            new ClientMTDConfig().save({
                Period: inputs.period,
                FromDate: inputs.fromDate ? moment(inputs.fromDate).format("YYYY-MM-DD") : null,
                ToDate: inputs.toDate ? moment(inputs.toDate).format("YYYY-MM-DD") : null,
                UserId: inputs.userId
            }, {
                    method: "insert"
                }).then((result) => {
                    if (result !== null) {
                        reply({
                            isSuccess: true
                        });
                    }
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }
}

export default new ClientMTDConfigController();