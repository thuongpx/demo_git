import { AUTH } from "../../constant/common-constant";
import Jwt from "../../lib/jwt";
import moment from "moment";
import Bookshelf from "../../db/database";

import { isBuffer, bufferToBoolean, bookshelfError, hasStringValue, getNextDayUtc } from "../../helper/common-helper";

import User from "../../db/model/users";
import Employees from "../../db/model/employees";
import Broker from "../../db/model/brokers";
import Signer from "../../db/model/signers";
import Agent from "../../db/model/agents";
import SecAnswers from "../../db/model/sec-answers";

import { guid, hashSha256 } from "../../helper/crypto-helper";

import { tawkTo } from "../../config/config";

const _validateUser = async (user) => {
    let isNeedToResetPassword = false;
    let isExpiredPassword = false;
    let isNeedToSetChallengeQuestion = false;
    let isValid = true;

    // in the case if the supervisor want to log in to the another user
    // we will ignore all validation
    if (!hasStringValue(user.supervisorId)) {
        const secAnswers = await SecAnswers.where({ UserId: user.UsersId }).count("*");

        // need to change password instantly
        if (user.NeedToResetPassword) {
            isNeedToResetPassword = true;
            isValid = false;
        }

        if (user.LastUpdate !== null) {
            // your password has been expired
            const days = moment().utc().diff(user.LastUpdate, "days");

            if (days > 90) {
                isExpiredPassword = true;
                isValid = false;
            }
        }

        if (secAnswers === 0) {
            isNeedToSetChallengeQuestion = true;
            isValid = false;
        }
    }

    const temporaryToken = guid();

    // save to database to use later
    User.where({ UsersId: user.UsersId }).save({ TemporaryToken: temporaryToken }, { method: "update" });

    return {
        isNeedToResetPassword,
        isNeedToSetChallengeQuestion,
        isExpiredPassword,
        usersId: user.UsersId,
        isValid,
        tempToken: temporaryToken
    };
};

const _signToken = (data) => {
    return new Promise((resolve, reject) => {
        const { userId, username, scope, currentRefreshToken, isFirstLogin, tempToken, supervisor, isShowAttentions, isSignerFirstLogin, allowVendorLogin, signerId } = data;
        let rft = currentRefreshToken;
        const rftExpires = getNextDayUtc(7); // get expires time

        if (!hasStringValue(rft)) {
            // generate a new one
            rft = Jwt.generateRefershToken();
        }

        // save to database with expires time
        User
            .where({ UsersId: userId })
            .save({
                RefreshToken: rft,
                RefreshTokenExpires: moment(rftExpires).utc().format("YYYY-MM-DD HH:mm:ss")
            }, { method: "update" })
            .then(() => {
                // get token
                const token = Jwt.signIn(username, scope);

                // to be enable secure mode api of TawkTo,
                // you need to have a hash
                let tawkToHash = "";
                if (hasStringValue(scope.profile.email)) {
                    tawkToHash = hashSha256(tawkTo.apiKey, scope.profile.email);
                }

                resolve({
                    isSuccess: true,
                    accessToken: token,
                    refreshToken: rft,
                    isFirstLogin,
                    tempToken,
                    tawkToHash,
                    supervisor,
                    isShowAttentions,
                    isSignerFirstLogin,
                    allowVendorLogin,
                    signerId
                });
            })
            .catch(() => {
                reject("Authorize Failed");
            });
    });
};

const _checkUserFirstLogin = (user) => {
    return new Promise((resolve, reject) => {
        if (!user.needToResetPassword && !user.logged) {
            const newUser = {
                Logged: 1
            };

            User
                .where({ UsersId: user.userId })
                .save(newUser, { method: "update" })
                .catch((error) => {
                    reject(error);
                });

            return resolve(true);
        }

        return resolve(false);
    });
};

const _checkSignerFirstLogin = (user) => {
    return user.RegistrationStep < 8;
};

const _getUserRoleById = (userId) => {
    return new Promise((resolve, reject) => {
        const rolesSql = `CALL GetUserRolePermissions(${userId});`;

        const findPermission = (userRole, permission) => {
            return userRole.permissions.find((el) => {
                return el === permission;
            });
        };

        Bookshelf.knex.raw(rolesSql)
            .then((result) => {
                if (result === null) {
                    return reject(`Unable to get role and permissions of user ${userId}`);
                }

                const rolePermissions = result[0][0];
                const userRole = {
                    roleNames: [],
                    permissions: [],
                    roleType: ""
                };

                // get role type
                if (rolePermissions && rolePermissions.length > 0) {
                    userRole.roleType = rolePermissions[0].Type;

                    rolePermissions.forEach((role) => {
                        const existingRole = userRole.roleNames.find((e) => {
                            return e === role.RoleName;
                        });

                        if (!existingRole) {
                            // get role name
                            userRole.roleNames.push(role.RoleName);

                            // get permissions
                            Object.keys(role).forEach((permission) => {
                                const value = role[permission];
                                if (permission !== "RoleId" && permission !== "RoleName" && permission !== "Type" && permission !== "Description" && value !== 0) {
                                    const existingPermission = findPermission(userRole, permission);

                                    if (!existingPermission) {
                                        userRole.permissions.push(permission);
                                    }
                                }
                            });
                        }
                    });

                    return resolve(userRole);
                }

                return reject(`Unable to get role and permissions of user ${userId}`);
            }, (err) => {
                return reject(`Unable to get role and permissions of user ${userId}: ${JSON.stringify(err)}`);
            });
    });
};

const _checkSignerAllowLogin = (signerId) => {
    return new Promise((resolve, reject) => {
        const rawSql = `SELECT
        (CASE WHEN 
                (SELECT COUNT(o.SignerId) FROM `
            + "`order`" +
            ` o WHERE o.SignerId = ${signerId} AND o.ProgressId <> 8) > 0
				OR (COUNT(vtr.ResultId) > 0) 
                OR ((SELECT ss.InActive FROM signer ss WHERE ss.SignerId = ${signerId}) = 0) THEN 1 
            ELSE 0 END) AS allowVendorLogin 
        FROM vendor_test_result vtr
        WHERE vtr.VendorId IN (SELECT s.signerId FROM signer s WHERE s.InActive = 1) 
        AND vtr.TestId IN (SELECT ti.TestId FROM test_info ti WHERE ti.DefaultTest = 1)
        AND vtr.Passed = 'Y' AND vtr.VendorId = ${signerId};`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result === null) {
                reject("error");
            }
            resolve((result[0][0].allowVendorLogin));
        }, err => {
            reject(err);
        });
    });
};

const _checkSignerAttention = (signerId) => {
    return new Promise((resolve, reject) => {
        const signerDocSql = `SELECT (CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END) AS isShowAttentions
        FROM signer_doctypes sd 
            LEFT JOIN signer_docs s on sd.DocTypeID = s.DocTypeId and s.SignerId = ${signerId}
        WHERE sd.DocTypeID IN (1, 5, 6, 7, 8, 9, 10 ) AND (s.ExpireDate < adddate(now(), INTERVAL 7 day) OR s.DocTypeId IS NULL); `;


        Bookshelf.knex.raw(signerDocSql).then(result => {
            if (result === null) {
                reject("error");
            }
            resolve((result[0][0].isShowAttentions));
        }, err => {
            reject(err);
        });
    });
};

const _getStaffDetail = (data, role, resolve, reject) => {
    const { userId, tenantId, mappingUserId, userName, refreshToken, tempToken, supervisor } = data;

    Employees.where({
        tenantId,
        RepId: mappingUserId
    })
        .fetch({ columns: ["RepId", "FirstName", "LastName", "Email"] })
        .then(async (profile) => {
            if (profile === null) {
                reject(AUTH.UNAVAILABLE_USER);
                return;
            }

            const { FirstName, LastName, RepId, Email } = profile.attributes;
            const tokenResult = await _signToken(
                {
                    userId, userName,
                    scope: {
                        id: userId,
                        role,
                        tenantId,
                        profile: {
                            id: RepId,
                            firstName: FirstName,
                            lastName: LastName,
                            userName,
                            userId,
                            subRoleType: "",
                            email: Email
                        }
                    },
                    currentRefreshToken: refreshToken,
                    isFirstLogin: false,
                    tempToken,
                    supervisor
                });

            resolve(tokenResult);
        }).catch((err) => {
            reject(bookshelfError(err));
            return;
        });
};

const _getClientDetail = async (data, role, resolve, reject) => {
    const { userId, tenantId, mappingUserId, userName, logged, needToResetPassword, refreshToken, tempToken, supervisor } = data;

    const isUserFirstLogin = await _checkUserFirstLogin({ logged, needToResetPassword, userId });

    if (role.roleNames[0] === "Agent") {
        Agent
            .where({
                tenantId,
                AgentId: mappingUserId
            })
            .fetch({ columns: ["AgentId", "FullName", "inActive", "BrokerId", "Email"] })
            .then(async profile => {
                if (profile === null) {
                    reject(AUTH.UNAVAILABLE_USER);
                    return;
                }

                const inActive = profile.attributes.inActive;
                if (isBuffer(inActive) && bufferToBoolean(inActive)) {
                    reject(AUTH.UNAVAILABLE_USER);
                    return;
                }

                const { FullName, AgentId, BrokerId, Email } = profile.attributes;
                const tokenResult = await _signToken(
                    {
                        userId, userName,
                        scope: {
                            id: userId,
                            role,
                            tenantId,
                            profile: {
                                id: AgentId,
                                firstName: FullName,
                                lastName: "",
                                userName,
                                userId,
                                subRoleType: "AGENT",
                                brokerId: BrokerId,
                                email: Email
                            }
                        },
                        currentRefreshToken: refreshToken,
                        isFirstLogin: isUserFirstLogin,
                        tempToken,
                        supervisor
                    });

                resolve(tokenResult);
            })
            .catch((err) => {
                reject(bookshelfError(err));
                return;
            });
    } else {
        Broker
            .where({
                tenantId,
                BrokerID: mappingUserId
            })
            .fetch({ columns: ["BrokerID", "Company", "IndustryId", "GID", "Email"] })
            .then(async (profile) => {
                if (profile === null) {
                    reject(AUTH.UNAVAILABLE_USER);
                    return;
                }

                const { Company, BrokerID, GID, IndustryId, Email } = profile.attributes;

                const tokenResult = await _signToken(
                    {
                        userId, userName,
                        scope: {
                            id: userId,
                            role,
                            tenantId,
                            profile: {
                                id: BrokerID,
                                firstName: Company,
                                lastName: "",
                                userName,
                                userId,
                                subRoleType: GID !== null && GID > 0 ? "BRANCH" : "CLIENT",
                                GID,
                                industryId: IndustryId,
                                email: Email
                            }
                        },
                        currentRefreshToken: refreshToken,
                        isFirstLogin: isUserFirstLogin,
                        tempToken,
                        supervisor
                    });

                resolve(tokenResult);
            });
    }
};

const _getSignerDetail = (data, role, resolve, reject) => {
    const { userId, tenantId, mappingUserId, userName, refreshToken, tempToken, supervisor } = data;

    Signer.where({
        tenantId,
        SignerId: mappingUserId
    })
        .fetch({ columns: ["SignerId", "FirstName", "LastName", "RegistrationStep", "Email"] })
        .then(async (profile) => {
            if (profile === null) {
                reject(AUTH.UNAVAILABLE_USER);
                return;
            }

            const { FirstName, LastName, SignerId, RegistrationStep, Email } = profile.attributes;

            const isShowAttentions = await _checkSignerAttention(mappingUserId).catch(err => reject(err));
            const allowVendorLogin = await _checkSignerAllowLogin(mappingUserId).catch(err => reject(err));
            const isSignerFirstLogin = _checkSignerFirstLogin({ RegistrationStep });

            const tokenReq = {
                userId, userName,
                scope: {
                    id: userId,
                    role,
                    tenantId,
                    profile: {
                        id: SignerId,
                        firstName: FirstName,
                        lastName: LastName,
                        userName,
                        userId,
                        subRoleType: "",
                        email: Email
                    }
                },
                currentRefreshToken: refreshToken,
                tempToken,
                supervisor,
                isShowAttentions,
                isSignerFirstLogin,
                allowVendorLogin,
                signerId: SignerId
            };

            const tokenResult = await _signToken(tokenReq);
            resolve(tokenResult);
            return;
        })
        .catch((err) => {
            reject(bookshelfError(err));
            return;
        });
};

const _getUserDetailByRoleType = async (data) => {
    return new Promise(async (resolve, reject) => {
        const userRole = await _getUserRoleById(data.userId).catch(err => reject(err));

        // get the user detail based on role type
        switch (userRole.roleType) {
            case "Staff":
                _getStaffDetail(data, userRole, resolve, reject);
                break;
            case "Client":
                _getClientDetail(data, userRole, resolve, reject);
                break;
            case "Vendor":
                _getSignerDetail(data, userRole, resolve, reject);
                break;
        }
    });
};

const _checkSignerOfferGuid = async (signerId, uniqueGuid) => {
    const sql = `select count(*) as Num from signer_offer
    where SignerId = '${signerId}' and GUID = '${uniqueGuid}' and GuidExpiredTime >= '${moment().format("YYYY-MM-DD HH:mm:ss")}'`;

    const matched = await Bookshelf.knex.raw(sql);

    return matched[0][0].Num > 0;
};

export const authorizePassword = (data) => {
    return new Promise(async (resolve, reject) => {
        const {
            userId,
            username,
            password,
            GUID,
            tempToken,
            supervisor,
            isLoginAsAnotherUser
        } = data;

        let user = null;

        if (!hasStringValue(username) && !hasStringValue(userId)) {
            reject("Invalid Username");
            return;
        }

        try {
            // there are 2 ways to login
            // - by username/password
            // - by userId/tempToken
            if (hasStringValue(username)) {
                // log in with username/password
                user = await User
                    .query({ where: { UserName: username } })
                    .fetch({
                        columns: [
                            "UsersId", "Password", "HashSalt",
                            "MappingUserId", "TenantId", "Inactive",
                            "UserName", "NeedToResetPassword", "LastUpdate",
                            "Logged", "TemporaryToken"
                        ]
                    });
            } else {
                // log in with userid/tempToken
                user = await User
                    .query({ where: { UsersId: userId } })
                    .fetch({
                        columns: [
                            "UsersId", "Password", "HashSalt",
                            "MappingUserId", "TenantId", "Inactive",
                            "UserName", "NeedToResetPassword", "LastUpdate",
                            "Logged", "TemporaryToken"
                        ]
                    });
            }

            // user is not found
            if (user === null) {
                reject(AUTH.UNAVAILABLE_USER);
                return;
            }

            const {
                Password, HashSalt, MappingUserId,
                TenantId, UsersId, Inactive,
                UserName, LastUpdate, NeedToResetPassword,
                Logged, TemporaryToken
            } = user.attributes;

            const isUserInactive = isLoginAsAnotherUser ? false : bufferToBoolean(Inactive);
            let isUserExisting = false;

            // the first stage of validation
            if (hasStringValue(GUID)) {
                // check if signer offer guid is correct
                isUserExisting = await _checkSignerOfferGuid(MappingUserId, GUID);
            } else if (hasStringValue(tempToken) && hasStringValue(userId)) {
                // check if temp token is correct
                isUserExisting = TemporaryToken === tempToken;
            } else {
                // check if password is correct
                isUserExisting = Jwt.checkPassword(Password, HashSalt, password);
            }

            // user is existing and active
            if (isUserExisting && !isUserInactive) {
                // remove the temporary token
                if (hasStringValue(tempToken) && hasStringValue(userId)) {
                    User.where({ UsersId }).save({ TemporaryToken: null }, { method: "update" });
                }

                const validateUserReq = {
                    LastUpdate,
                    NeedToResetPassword: bufferToBoolean(NeedToResetPassword),
                    UsersId,
                    UserName,
                    supervisorId: supervisor.id
                };

                const validationResult = await _validateUser(validateUserReq);

                if (validationResult && validationResult.isValid) {
                    const userDetailReq = {
                        userId: UsersId, tenantId: TenantId, mappingUserId: MappingUserId, userName: UserName,
                        refreshToken: null, logged: Logged, needToResetPassword: bufferToBoolean(NeedToResetPassword),
                        tempToken: validationResult.tempToken,
                        supervisor
                    };

                    const userDetail = await _getUserDetailByRoleType(userDetailReq).catch(err => reject(err));

                    // double check if this user still has problems
                    if (!userDetail.isInvalid) {
                        resolve(userDetail);
                        return;
                    }

                    // signer
                    validationResult.allowVendorLogin = userDetail.allowVendorLogin;
                    validationResult.isSignerFirstLogin = userDetail.isSignerFirstLogin;
                    validationResult.signerId = userDetail.signerId;
                }

                // user has problems (need to reset password, need to answer challenge question, password expires...)
                resolve(validationResult);
                return;
            }

            // incorrect password
            reject(AUTH.UNAVAILABLE_USER);
            return;
        } catch (err) {
            // unexpected error
            reject(AUTH.UNEXPECTED_ERROR);
            return;
        }
    });
};

// const authorizeRefreshToken = (data, success, reject) => {
        //     const {
        //         userId,
        //         refreshToken
        //     } = data;

        //     if (!hasStringValue(userId)) {
        //         reject(Boom.badRequest("Invalid User Id"));
        //         return;
        //     }

        //     // validate refresh token with user id
        //     User.where({ UsersId: userId, RefreshToken: refreshToken })
        //         .fetch({ columns: ["UsersId", "Password", "HashSalt", "MappingUserId", "TenantId", "Inactive", "UserName", "RefreshTokenExpires"] })
        //         .then(rs => {
        //             if (rs === null) {
        //                 reject(Boom.unauthorized(AUTH.UNAVAILABLE_USER));
        //                 return;
        //             }

        //             const { RefreshTokenExpires, UsersId, TenantId, MappingUserId, UserName } = rs.attributes;

        //             const isExpired = isAfter(RefreshTokenExpires);

        //             if (!isExpired) {
        //                 // refresh token is valid
        //                 getUserInformation(UsersId, TenantId, MappingUserId, UserName, refreshToken);
        //             } else {
        //                 // refresh token is invalid, announce user to re-login
        //                 reject(Boom.unauthorized(`Expired refresh token`));
        //             }
        //         })
        //         .catch((err) => {
        //             reject(Boom.badRequest(`Unable to connect to database: ${JSON.stringify(err)}`));
        //             return;
        //         });
        // };