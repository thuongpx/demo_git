import SignerDocController from "./signer-doc-controller";
import config from "../../config/config";

const routes = [{
    path: "/signerDoc/uploadSignerDocument",
    method: "POST",
    config: {
        auth: false,
        payload: {
            output: "stream",
            maxBytes: config.file.maxBytesSignerDoc, // max: 10 MB
            allow: "multipart/form-data"
        }
    },
    handler: SignerDocController.uploadSignerDocument
}, {
    path: "/signerDoc/getSignerDocBySignerId",
    method: "GET",
    config: {
        auth: false
    },
    handler: SignerDocController.getSignerDocBySignerId
}, {
    path: "/signerDoc/downloadSignerDocument",
    method: "GET",
    handler: SignerDocController.downloadSignerDocument
}, {
    path: "/signerDoc/checkSignerDocExisting",
    method: "GET",
    config: {
        auth: false
    },
    handler: SignerDocController.checkSignerDocExisting
}, {
    path: "/signerDoc/getSignerDocsStatus",
    method: "GET",
    handler: SignerDocController.getSignerDocsStatus
},
{
    path: "/signerDoc/getVendorDocsStatusById",
    method: "GET",
    handler: SignerDocController.getVendorDocsStatusById
},
{
    path: "/signerDoc/aprroveVendorDoc",
    method: "POST",
    handler: SignerDocController.aprroveVendorDoc
},
{
    path: "/signerDoc/rejectVendorDoc",
    method: "POST",
    handler: SignerDocController.rejectVendorDoc
},
{
    path: "/signerDoc/archiveVendorDoc",
    method: "POST",
    handler: SignerDocController.archiveVendorDoc
},
{
    path: "/signerDoc/getVendorDocsArchiveById",
    method: "GET",
    handler: SignerDocController.getVendorDocsArchiveById
},
{
    path: "/signerDoc/archiveVendorDocArchive",
    method: "POST",
    handler: SignerDocController.deleteVendorDoc
}, {
    path: "/signerDoc/downloadSignerDocumentArchive",
    method: "GET",
    handler: SignerDocController.downloadSignerDocumentArchive
}, {
    path: "/signerDoc/getSignerDocsForTceValidation",
    method: "POST",
    handler: SignerDocController.getSignerDocsForTceValidation
}
];


export default routes;