import Boom from "boom";
import Bookshelf from "../../db/database";
import Industry from "../../db/model/industry";
import LoanType from "../../db/model/loan-type";
import IndustryTransactionFees from "../../db/model/industry_transaction_fees";
import BrokerFee from "../../db/model/broker-fee";
class FeeConfiguration {
    constructor() { }

    getInitDataForMatrix(request, reply) {
        const { actor, actorId } = request.query;
        const getIndustryList = Promise.resolve(Industry.forge().orderBy("Description").fetchAll());
        const apiGetProductList = Promise.resolve(LoanType.forge().orderBy("LoanType").fetchAll());

        const apiGetFeeDescriptionList = actor === "Admin" ?
            Promise.resolve(Bookshelf.knex.raw(`select distinct itf.FeeDescription from industry_transaction_fees itf where itf.IsAdditionalFee = 1 order by itf.FeeDescription`)) :
            Promise.resolve(Bookshelf.knex.raw(`select distinct itf.FeeDescription from broker_fee itf where brokerId = ${actorId} and itf.IsAdditionalFee = 1 order by itf.FeeDescription`));

        const apiGetFeeTransactionList = actor === "Admin" ?
            Promise.resolve(Bookshelf.knex.raw(`Select itf.FeeDescription,itf.ClientFee,itf.VendorFee,itf.DefaultClientFee,itf.DefaultVendorFee, itf.Feeid,itf.LoanTypeId,itf.IndustryId,
                (case when itf.IsAdditionalFee = 0 then 0 else 1 end) as IsAdditionalFee
                from industry_transaction_fees itf
                order by itf.FeeDescription;`)) :
            Promise.resolve(Bookshelf.knex.raw(`Select itf.FeeDescription,itf.SelfServiceVendorFee as VendorFee, itf.DefaultSelfServiceVendorFee as DefaultVendorFee, itf.Feeid,itf.LoanTypeId,itf.IndustryId,
                (case when itf.IsAdditionalFee = 0 then 0 else 1 end) as IsAdditionalFee
                from broker_fee itf
                where brokerId = ${actorId}
                order by itf.FeeDescription`));

        Promise.all([apiGetFeeTransactionList, apiGetFeeDescriptionList, apiGetProductList, getIndustryList])
            .then(value => {
                const data = {};
                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.feeTransactions = item[0];
                                    break;
                                case 1:
                                    data.feeDescriptions = item[0];
                                    break;
                                case 2:
                                    data.products = item;
                                    break;
                                case 3:
                                    data.industries = item;
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
        return reply;
    }

    async saveFee(request, reply) {
        const { industryId, remove, save, actor, actorId } = request.payload;
        //save by Admin
        const tasksSaveByAdmin = async () => {
            const subTaskSaveByAdmin = async (s) => {
                if (!remove.includes(s.LoanTypeId)) {
                    if (s.Feeid === null) {
                        await new Promise(resolve => new IndustryTransactionFees().save({
                            IndustryId: industryId,
                            LoanTypeId: s.LoanTypeId,
                            FeeDescription: s.FeeDescription,
                            // Client/Vendor Fee
                            ClientFee: s.ClientFee,
                            VendorFee: s.VendorFee,
                            DefaultClientFee: null,
                            DefaultVendorFee: null,
                            IsAdditionalFee: s.IsAdditionalFee
                        }, {
                                method: "insert"
                            }).then(() => {
                                resolve();
                            }).catch((error) => {
                                return error;
                            }));
                    } else {
                        await new Promise(resolve => IndustryTransactionFees.where({
                            FeeId: s.Feeid
                        }).save({
                            ClientFee: s.ClientFee,
                            VendorFee: s.VendorFee
                        }, {
                                method: "update"
                            }).then(() => {
                                resolve();
                            }).catch((error) => {
                                reply(Boom.badRequest(error));
                            }));
                    }
                }
            };

            for (const s in save) {
                await subTaskSaveByAdmin(save[s]);
            }
            return true;
        };
        //save by Client
        const tasksSaveByClient = async () => {
            const subTaskSaveByClient = async (s) => {
                if (!remove.includes(s.LoanTypeId)) {
                    if (s.Feeid === null) {
                        await new Promise(resolve => new BrokerFee().save({
                            IndustryId: industryId,
                            LoanTypeId: s.LoanTypeId,
                            FeeDescription: s.FeeDescription,
                            // SelfServiceVendorFee
                            SelfServiceVendorFee: s.VendorFee,
                            DefaultSelfServiceVendorFee: null,
                            IsAdditionalFee: s.IsAdditionalFee,
                            BrokerId: actorId
                        }, {
                                method: "insert"
                            }).then(() => {
                                resolve();
                            }).catch((error) => {
                                return error;
                            }));
                    } else {
                        await new Promise(resolve => BrokerFee.where({
                            FeeId: s.Feeid
                        }).save({
                            SelfServiceVendorFee: s.VendorFee
                        }, {
                                method: "update"
                            }).then(() => {
                                resolve();
                            }).catch((error) => {
                                reply(Boom.badRequest(error));
                            }));
                    }
                }
            };

            for (const s in save) {
                await subTaskSaveByClient(save[s]);
            }
            return true;
        };
        //remove by Admin
        const taskRemoveByAdmin = async () => {
            const subTaskRemoveByAdmin = async (r) => {
                await new Promise(resolve =>
                    IndustryTransactionFees.where({
                        LoanTypeId: r
                    }).save({
                        ClientFee: null,
                        VendorFee: null
                    }, {
                            method: "update"
                        }).then(() => {
                            resolve();
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        }));
            };
            for (const r in remove) {
                await subTaskRemoveByAdmin(remove[r]);
            }
            return true;
        };
        //promiseall
        let taskSave = false;
        let taskRemove = false;
        if (actor === "Admin") {
            taskSave = await tasksSaveByAdmin();
            taskRemove = await taskRemoveByAdmin();
        } else {
            taskSave = await tasksSaveByClient();
            taskRemove = true;
        }
        //response
        reply({
            isSuccess: (taskSave && taskRemove)
        });
    }

    getRefreshData(request, reply) {
        const { actor, actorId, industryId } = request.query;
        const rawSql = actor === "Admin" ?
            `
            UPDATE industry_transaction_fees 
            SET ClientFee = DefaultClientFee, VendorFee = DefaultVendorFee where IndustryId = ${industryId} 
        ` :
            `
            UPDATE broker_fee 
            SET SelfServiceVendorFee = DefaultSelfServiceVendorFee where brokerId = ${actorId} and IndustryId = ${industryId} 
        `;
        Bookshelf.knex.raw(rawSql)
            .then(() => {
                reply({
                    isSuccess: true
                });
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }
}

export default new FeeConfiguration();