import Bookshelf from "../../db/database";
import Boom from "boom";
import pdf from "html-pdf";
import fs from "fs";
import Broker from "../../db/model/brokers";
import Comment from "../../db/model/comment";
import OrderProgressLog from "../../db/model/order-progress-log";
import NotificationManagement from "../../db/model/notification-management";
import sendMailCore from "../../mail/mail-helper";
import moment from "moment";
import { mergeDataField, convertRowDataPackage, handleBreakLine } from "../../helper/common-helper";
import { getMergeFieldMapping } from "../../merge-engine/reports/order-detail";
import { getMergeFieldMappingOrderConfirmation } from "../../merge-engine/reports/order-confirmation";
import {
    getMergeFieldMappingOrderClosed
} from "../../merge-engine/reports/order-closed";
import {
    getMergeFieldMappingOrderScheduled
} from "../../merge-engine/reports/order-scheduled";

import {
    getMergeFieldMappingOrderInvoice
} from "../../merge-engine/reports/order-invoice";
import {
    replaceAll
} from "../../helper/common-helper";
import { URL_REPORT } from "../../constant/common-constant";

class ReportController {
    constructor() { }

    sendFaxcover(request, reply) {
        const { orderID, selectSendMailOption } = request.query;
        const rawSqlSumFees = `SELECT SUM(SignerFee) AS signerFee
                                FROM order_fee
                                WHERE OrderID = ${orderID};`;

        Bookshelf.knex.raw(rawSqlSumFees)
            .then(feesResult => {
                if (feesResult[0][0] !== undefined && feesResult[0][0] !== null && convertRowDataPackage(feesResult[0][0]).signerFee !== null) {
                    const signerFee = convertRowDataPackage(feesResult[0][0]);
                    const rawSqlSignerInfo = `SELECT u.UserName AS signerUsername, s.Email AS signerEmail, s.Fax AS signerFax, concat(s.FirstName, " ", s.LastName) AS signerFullName          
                    FROM signer as s
                    LEFT JOIN \`order\` as o ON o.SignerId = s.SignerId
                    LEFT JOIN users as u ON u.MappingUserId = s.SignerId
                    LEFT JOIN user_roles ur ON u.UsersId = ur.UsersId
                    LEFT JOIN roles r ON ur.RoleId = r.RoleId AND ur.RoleId = 8                                    
                    WHERE r.Type = 'Vendor' AND o.OrderId = ${orderID};`;

                    Bookshelf.knex.raw(rawSqlSignerInfo)
                        .then(async signerResult => {
                            if (signerResult[0][0] !== undefined && signerResult[0][0] !== null) {
                                const signerInfo = convertRowDataPackage(signerResult[0][0]);
                                if (signerInfo.signerEmail !== null) {
                                    let fromEmail = "";
                                    let subject = "";
                                    let message = "";

                                    await new Promise(resolve => NotificationManagement.where({ Purpose: "Send Faxcover" }).fetch({ columns: ["FromEmail", "Subject", "Message"] }).then((model) => {
                                        fromEmail = model.get("FromEmail");
                                        subject = model.get("Subject");
                                        message = model.get("Message");
                                        resolve();

                                    }));

                                    Bookshelf.knex.raw(`call GetDataForOrderDetailsReport(${orderID})`)
                                        .then(async result => {
                                            const attachments = [];
                                            const attachmentNames = [];
                                            const tempData = convertRowDataPackage(result[0][0][0]);
                                            if (tempData.importantCompanyInstruction !== null) {
                                                tempData.importantCompanyInstruction = handleBreakLine(tempData.importantCompanyInstruction);
                                            }

                                            const dataToSendReport = Object.assign({}, signerFee, signerInfo, tempData, { orderID });
                                            const reportHtml = mergeDataField(message, getMergeFieldMapping(dataToSendReport));

                                            if (fs.existsSync(`${URL_REPORT}${tempData.brokerId}/Lenderspecifics.pdf`)) {
                                                if (tempData.brokerId.length > 0 && tempData.brokerId !== null || tempData.brokerId !== "") {
                                                    attachments.push({ path: `${URL_REPORT}${tempData.brokerId}/Lenderspecifics.pdf` });
                                                    attachmentNames.push("Lenderspecifics.pdf");
                                                    attachments.push({ path: `${URL_REPORT}NotaryAttachments.pdf` });
                                                } else {
                                                    attachments.push({ path: `${URL_REPORT}NotaryAttachments.pdf` });
                                                }
                                            } else {
                                                attachments.push({ path: `${URL_REPORT}NotaryAttachments.pdf` });
                                            }
                                            attachmentNames.push("NotaryAttachments.pdf");
                                            if (tempData.agentName === "WFAF") {
                                                attachments.push({ path: `${URL_REPORT}WFAF_Special_Instruction.pdf` });
                                                attachmentNames.push("WFAF_Special_Instruction.pdf");
                                            }

                                            if (selectSendMailOption === "1") {
                                                const newFileName = `TheClosingExchange-Confirmation_OrderId-${orderID}.pdf`;
                                                const options = {
                                                    "height": "10.5in",
                                                    "width": "8in",
                                                    "format": "A4",
                                                    "orientation": "portrait"
                                                };

                                                await new Promise((resolve) => pdf.create(reportHtml, options).toFile(`${URL_REPORT}${newFileName}`, (error) => {
                                                    if (error) {
                                                        reply(Boom.badRequest(error));
                                                    } else {
                                                        attachments.push({ path: `${URL_REPORT}${newFileName}` });
                                                        attachmentNames.push(newFileName);
                                                    }
                                                    resolve();
                                                }));
                                            }
                                            const mailOptions = {
                                                from: fromEmail,
                                                to: signerInfo.signerEmail,
                                                subject: replaceAll(subject, "[orderID]", dataToSendReport.orderID),
                                                html: reportHtml,
                                                attachments,
                                                attachmentNames,
                                                orderId: dataToSendReport.orderID
                                            };
                                            reply(mailOptions);

                                        }).catch((error) => {
                                            reply(Boom.badRequest(error));
                                        });
                                } else {
                                    reply(Boom.badRequest("Unable to Send, Missing or Invalid Signer Email Address"));
                                }
                            } else {
                                reply(Boom.badRequest("Unable to Send, Missing or Invalid Signer Email Address"));
                            }
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                } else {
                    reply(Boom.badRequest("This order does not have Fees, enter fees before sending reports"));
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    sendConfirmation(request, reply) {
        const { orderID, selectSendMailOption } = request.query;

        const rawSqlSignerEmail = `select a.Email as email
                                from \`order\` as o
                                left join agent as a on o.AgentId = a.AgentId
                                where o.orderID = ${orderID};`;
        const rawSQListFee = `SELECT of.BrokerFee
                            , bf.FeeDescription as Description
                            from \`order\` as o
                            inner join order_fee as of on o.OrderID = of.OrderID
                            inner join broker_fee as bf on of.FeeDescripID = bf.FeeId
                            where of.OrderID = ${orderID}
                            union
                            SELECT sum(BrokerFee), "Total"
                            from order_fee
                            where OrderID = ${orderID};`;
        const rawGetInfoOrder = `select o.orderId as orderId,
                                        concat(o.FirstName, " ", o.LastName) as clientName,
                                        o.LastName as orderLastName,
                                        o.BrokerIdNum as referenceId, 
                                        o.AptDateTime as requestApptDate,
                                        o.AptUTC as aptUTC,
                                        a.FullName as fullName,
                                        b.Company as branchName, 
                                        b.Address as branchAddr, 
                                        b.City as branchCity, 
                                        b.State as branchState, 
                                        b.Zip as branchZip,
                                        a.fax as fax, 
                                        a.Direct as phone,
                                        b.BrokerId as brokerId,
                                        u.UserName as username,
                                        concat(s.FirstName, " ", s.LastName) as vendorName,
                                        s.Mobile as vendorCell,
                                        s.WorkPhone as vendorWork,
                                        s.HomePhone as vendorHome,
                                        s.WeekdayStreet as vendorAddr,
                                        s.WeekdayCity as vendorCity,
                                        s.WeekdayState as vendorState,
                                        s.WeekdayZip as vendorZip,
                                        s.Email as vendorEmail
                                from \`order\` as o
                                left join agent as a on o.AgentId = a.AgentId
                                left join broker as b on o.BrokerId = b.BrokerID
                                left join users as u on b.BrokerID = u.MappingUserId
                                left join user_roles ur on u.UsersId = ur.UsersId and ur.RoleId = 7
                                left join signer as s on o.SignerId = s.SignerId
                                where o.orderId = ${orderID};`;

        Bookshelf.knex.raw(rawSqlSignerEmail)
            .then(async emailResult => {
                let fromEmail = "";
                let subject = "";
                let message = "";
                let alwaysCC = "";
                let ccEmail = [];
                if (emailResult[0][0] !== undefined && emailResult[0][0] !== null) {
                    const emailAgent = convertRowDataPackage(emailResult[0][0]);

                    if (emailAgent.email !== null && emailAgent.email !== "") {
                        Bookshelf.knex.raw(rawGetInfoOrder)
                            .then(result => {
                                const attachments = [];
                                const attachmentNames = [];
                                Bookshelf.knex.raw(rawSQListFee).then(async feeResult => {
                                    const feeData = convertRowDataPackage(feeResult[0]);
                                    const tempData = convertRowDataPackage(result[0][0]);
                                    if (tempData.brokerId === 3165) {
                                        await new Promise(resolve => NotificationManagement.where({ Purpose: "Send Confirmation2" }).fetch({ columns: ["FromEmail", "Subject", "Message"] }).then((model) => {
                                            fromEmail = model.get("FromEmail");
                                            subject = model.get("Subject");
                                            message = model.get("Message");
                                            resolve();

                                        }));
                                    } else {
                                        await new Promise(resolve => NotificationManagement.where({ Purpose: "Send Confirmation" }).fetch({ columns: ["FromEmail", "Subject", "Message"] }).then((model) => {
                                            fromEmail = model.get("FromEmail");
                                            subject = model.get("Subject");
                                            message = model.get("Message");
                                            resolve();

                                        }));
                                    }
                                    await new Promise(resolve => Broker.where({ BrokerID: tempData.brokerId }).fetch({ columns: ["Ccemail"] }).then((model) => {
                                        alwaysCC = model.get("Ccemail");
                                        resolve();

                                    }));
                                    await new Promise(resolve => Bookshelf.knex.raw(`select Email from broker_emails where BrokerID = ${tempData.brokerId} and EmailFor = 'S'; `).then(email => {
                                        if (convertRowDataPackage(email[0]).length > 0) {
                                            ccEmail = convertRowDataPackage(email[0]).map((obj) => {
                                                return obj.Email;
                                            });
                                        }
                                        resolve();
                                    }));

                                    if (alwaysCC !== null && alwaysCC !== "") {
                                        ccEmail.push(alwaysCC);
                                    }
                                    const dataToSendReport = Object.assign({}, tempData, { orderID }, { feeData });
                                    const reportHtml = mergeDataField(message, getMergeFieldMappingOrderConfirmation(dataToSendReport));
                                    if (selectSendMailOption === "3") {
                                        const newFileName = `TheClosingExchange-Confirmation_OrderId-${orderID}.pdf`;
                                        const options = {
                                            "height": "10.5in",
                                            "width": "8in",
                                            "format": "A4",
                                            "orientation": "portrait"
                                        };

                                        await new Promise((resolve) => pdf.create(reportHtml, options).toFile(`${URL_REPORT}${newFileName}`, (error) => {
                                            if (error) {
                                                reply(Boom.badRequest(error));
                                            } else {
                                                attachments.push({ path: `${URL_REPORT}${newFileName}` });
                                                attachmentNames.push(newFileName);
                                            }
                                            resolve();
                                        }));
                                    }
                                    subject = replaceAll(subject, "[brokerId]", dataToSendReport.referenceId);
                                    subject = replaceAll(subject, "[orderLastName]", dataToSendReport.orderLastName);
                                    subject = replaceAll(subject, "[orderId]", dataToSendReport.orderID);
                                    const mailOptions = {
                                        from: fromEmail,
                                        to: emailAgent.email,
                                        cc: ccEmail,
                                        subject,
                                        html: selectSendMailOption === "3" ? null : reportHtml,
                                        attachments,
                                        attachmentNames,
                                        orderId: dataToSendReport.orderID
                                    };
                                    reply(mailOptions);
                                });

                            }).catch((err) => {
                                reply(Boom.badRequest(err));
                            });
                    } else {
                        reply("Unable to Send, Missing or Invalid Agent Email Address");
                    }
                } else {
                    reply("Unable to Send, Missing or Invalid Agent Email Address");
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }

    sendAptScheduled(request, reply) {
        const { orderID, selectSendMailOption } = request.query;

        const rawSqlSignerEmail = `select a.Email as email
                                from \`order\` as o
                                inner join agent as a on o.AgentId = a.AgentId
                                where o.orderID = ${orderID};`;
        const rawGetInfoOrder = `select a.FullName as fullName,
                                        a.fax as fax,
                                        b.Company as company,
                                        o.orderId as orderId,
                                        o.BrokerIdNum as brokerIdNum,
                                        o.SignerId as signerId,
                                        o.LastName as orderLastName,
                                        o.AptDateTime as aptDateTime,
                                        o.AptUTC as aptUTC,
                                        o.BrokerId as brokerId,
                                        b.Address AS companyAddress,
                                        CONCAT_WS(', ', b.City, b.State, b.Zip) as companyCityStateZip
                                from \`order\` as o
                                left join agent as a on o.AgentId = a.AgentId
                                left join broker as b on o.BrokerId = b.BrokerID
                                where o.orderId = ${orderID};`;
        const rawSQListFee = `SELECT sum(BrokerFee) as brokerFees
        from order_fee
        where OrderID = ${orderID};`;

        Bookshelf.knex.raw(rawSqlSignerEmail)
            .then(emailResult => {
                let fromEmail = "";
                let subject = "";
                let message = "";
                let alwaysCC = "";
                let ccEmail = [];
                if (emailResult[0][0] !== undefined && emailResult[0][0] !== null) {
                    const emailAgent = convertRowDataPackage(emailResult[0][0]);
                    if (emailAgent.email !== null && emailAgent.email !== "") {
                        Bookshelf.knex.raw(rawGetInfoOrder)
                            .then(result => {
                                Bookshelf.knex.raw(rawSQListFee).then(async feeResult => {
                                    const brokerFees = convertRowDataPackage(feeResult[0][0]);
                                    const tempData = convertRowDataPackage(result[0][0]);
                                    if (tempData.brokerId !== 2165 && tempData.brokerId !== 3174) {
                                        await new Promise(resolve => NotificationManagement.where({ Purpose: "Send Apt Schedule" }).fetch({ columns: ["FromEmail", "Subject", "Message"] }).then((model) => {
                                            fromEmail = model.get("FromEmail");
                                            subject = model.get("Subject");
                                            message = model.get("Message");
                                            resolve();

                                        }));
                                        await new Promise(resolve => Broker.where({ BrokerID: tempData.brokerId }).fetch({ columns: ["Ccemail"] }).then((model) => {
                                            alwaysCC = model.get("Ccemail");
                                            resolve();

                                        }));
                                        await new Promise(resolve => Bookshelf.knex.raw(`select Email from broker_emails where BrokerID = ${tempData.brokerId} and EmailFor = 'S'; `).then(email => {
                                            if (convertRowDataPackage(email[0]).length > 0) {
                                                ccEmail = convertRowDataPackage(email[0]).map((obj) => {
                                                    return obj.Email;
                                                });
                                            }
                                            resolve();
                                        }));

                                        if (alwaysCC !== null && alwaysCC !== "") {
                                            ccEmail.push(alwaysCC);
                                        }
                                        const dataToSendReport = Object.assign({}, tempData, brokerFees);
                                        const reportHtml = mergeDataField(message, getMergeFieldMappingOrderScheduled(dataToSendReport));

                                        subject = replaceAll(subject, "[brokerId]", dataToSendReport.brokerIdNum);
                                        subject = replaceAll(subject, "[orderLastName]", dataToSendReport.orderLastName);
                                        subject = replaceAll(subject, "[orderId]", dataToSendReport.orderId);

                                        const mailOptions = {
                                            from: fromEmail,
                                            to: emailAgent.email,
                                            cc: ccEmail,
                                            subject,
                                            html: selectSendMailOption === "3" ? null : reportHtml,
                                            orderId: dataToSendReport.orderId
                                        };
                                        reply(mailOptions);
                                    } else {
                                        reply("Broker does not require this Report.  No Action Taken");
                                    }
                                });

                            }).catch((err) => {
                                reply(Boom.badRequest(err));
                            });
                    } else {
                        reply("Unable to Send, Missing or Invalid Agent Email Address");
                    }
                } else {
                    reply("Unable to Send, Missing or Invalid Agent Email Address");
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }

    sendClosing(request, reply) {
        const { orderID, selectSendMailOption } = request.query;

        const rawSqlSignerEmail = `select a.Email as email
                                from \`order\` as o
                                inner join agent as a on o.AgentId = a.AgentId
                                where o.orderID = ${orderID};`;
        const rawGetInfoOrder = `select a.FullName as fullName,
                                        a.fax as fax,
                                        b.Company as company,
                                        o.orderId as orderId,
                                        o.BrokerIdNum as brokerIdNum,
                                        o.SignerId as signerId,
                                        o.LastName as orderLastName,
                                        o.BrokerId as brokerId,
                                        b.Address AS companyAddress,
                                        o.TrackingNumber as trackingNumber,
                                        CONCAT_WS(', ', b.City, b.State, b.Zip) as companyCityStateZip,
                                        c.Courier as courier
                                from \`order\` as o
                                left join agent as a on o.AgentId = a.AgentId
                                left join broker as b on o.BrokerId = b.BrokerID
                                left join courier as c on o.CourierID = c.CourierID
                                where o.orderId = ${orderID};`;
        const rawSQListFee = `SELECT sum(BrokerFee) as brokerFees
        from order_fee
        where OrderID = ${orderID};`;

        Bookshelf.knex.raw(rawSqlSignerEmail)
            .then(emailResult => {
                let fromEmail = "";
                let subject = "";
                let message = "";
                let alwaysCC = "";
                let ccEmail = [];
                if (emailResult[0][0] !== undefined && emailResult[0][0] !== null) {
                    const emailAgent = convertRowDataPackage(emailResult[0][0]);
                    if (emailAgent.email !== null && emailAgent.email !== "") {
                        Bookshelf.knex.raw(rawGetInfoOrder)
                            .then(result => {
                                Bookshelf.knex.raw(rawSQListFee).then(async feeResult => {
                                    const brokerFees = convertRowDataPackage(feeResult[0][0]);
                                    const tempData = convertRowDataPackage(result[0][0]);
                                    await new Promise(resolve => NotificationManagement.where({ Purpose: "Send Closing" }).fetch({ columns: ["FromEmail", "Subject", "Message"] }).then((model) => {
                                        fromEmail = model.get("FromEmail");
                                        subject = model.get("Subject");
                                        message = model.get("Message");
                                        resolve();

                                    }));
                                    await new Promise(resolve => Broker.where({ BrokerID: tempData.brokerId }).fetch({ columns: ["Ccemail"] }).then((model) => {
                                        alwaysCC = model.get("Ccemail");
                                        resolve();

                                    }));
                                    await new Promise(resolve => Bookshelf.knex.raw(`select Email from broker_emails where BrokerID = ${tempData.brokerId} and EmailFor = 'S'; `).then(email => {
                                        if (convertRowDataPackage(email[0]).length > 0) {
                                            ccEmail = convertRowDataPackage(email[0]).map((obj) => {
                                                return obj.Email;
                                            });
                                        }
                                        resolve();
                                    }));

                                    if (alwaysCC !== null && alwaysCC !== "") {
                                        ccEmail.push(alwaysCC);
                                    }
                                    const dataToSendReport = Object.assign({}, tempData, brokerFees);
                                    const reportHtml = mergeDataField(message, getMergeFieldMappingOrderClosed(dataToSendReport));

                                    subject = replaceAll(subject, "[brokerId]", dataToSendReport.brokerIdNum);
                                    subject = replaceAll(subject, "[orderLastName]", dataToSendReport.orderLastName);
                                    subject = replaceAll(subject, "[orderId]", dataToSendReport.orderId);

                                    const mailOptions = {
                                        from: fromEmail,
                                        to: emailAgent.email,
                                        cc: ccEmail,
                                        subject,
                                        html: selectSendMailOption === "3" ? null : reportHtml,
                                        orderId: dataToSendReport.orderId
                                    };
                                    reply(mailOptions);
                                });

                            }).catch((err) => {
                                reply(Boom.badRequest(err));
                            });
                    } else {
                        reply("Unable to Send, Missing or Invalid Agent Email Address");
                    }
                } else {
                    reply("Unable to Send, Missing or Invalid Agent Email Address");
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }

    sendInvoice(request, reply) {
        const { orderID, selectSendMailOption } = request.query;

        const rawSqlInvoiceEmail = `select b.InvoiceOnly as email
                                from \`order\` as o
                                inner join broker as b on o.BrokerId = b.BrokerId
                                where o.orderID = ${orderID};`;
        const rawSQListFee = `SELECT of.BrokerFee
                            , bf.FeeDescription as Description
                            from \`order\` as o
                            inner join order_fee as of on o.OrderID = of.OrderID
                            inner join broker_fee as bf on of.FeeDescripID = bf.FeeId
                            where of.OrderID = ${orderID}
                            union
                            SELECT sum(BrokerFee), "Total"
                            from order_fee
                            where OrderID = ${orderID};`;
        const rawGetInfoOrder = `select o.orderId as orderId,
                                o.ClosedDate as closedDate,
                                o.FirstName as firstName,
                                o.LastName as lastName,
                                o.BrokerIdNum as brokerIdNum,
                                o.TrackingNumber as trackingNumber, 
                                o.Address as oAddress,
                                o.City as oCity,
                                o.State as oState,
                                o.Zip as oZip,
                                o.AptDateTime as aptDateTime,
                                o.AptUTC as aptUTC,
                                a.FullName as fullName,
                                b.Company as company, 
                                b.Address as bAddress,
                                b.City as bCity, 
                                b.State as bState, 
                                b.Zip as bZip,
                                b.CcEmail as ccEmail,
                                a.Fax as aFax,
                                b.BrokerId as brokerId,
                                c.Courier as courier
                        from \`order\` as o
                        left join agent as a on o.AgentId = a.AgentId
                        left join broker as b on o.BrokerId = b.BrokerID
                        left join courier as c on o.CourierID = c.CourierID
                        where o.orderId = ${orderID};`;

        Bookshelf.knex.raw(rawSqlInvoiceEmail)
            .then(async emailResult => {
                let fromEmail = "";
                let subject = "";
                let message = "";
                let alwaysCC = "";
                let ccEmail = [];
                if (emailResult[0][0] !== undefined && emailResult[0][0] !== null) {
                    const emailAgent = convertRowDataPackage(emailResult[0][0]);

                    Bookshelf.knex.raw(rawGetInfoOrder)
                        .then(result => {
                            const attachments = [];
                            const attachmentNames = [];
                            Bookshelf.knex.raw(rawSQListFee).then(async feeResult => {
                                const feeData = convertRowDataPackage(feeResult[0]);
                                const tempData = convertRowDataPackage(result[0][0]);

                                if (tempData.brokerId === 4122) {
                                    emailAgent.email = "NLSEFunding@title365.com";
                                }

                                if (emailAgent.email !== null && emailAgent.email !== "") {
                                    await new Promise(resolve => NotificationManagement.where({ Purpose: "Send Invoice" }).fetch({ columns: ["FromEmail", "Subject", "Message"] }).then((model) => {
                                        fromEmail = model.get("FromEmail");
                                        subject = model.get("Subject");
                                        message = model.get("Message");
                                        resolve();

                                    }));
                                    await new Promise(resolve => Broker.where({ BrokerID: tempData.brokerId }).fetch({ columns: ["Ccemail"] }).then((model) => {
                                        alwaysCC = model.get("Ccemail");
                                        resolve();

                                    }));
                                    await new Promise(resolve => Bookshelf.knex.raw(`select Email from broker_emails where BrokerID = ${tempData.brokerId} and EmailFor = 'S'; `).then(email => {
                                        if (convertRowDataPackage(email[0]).length > 0) {
                                            ccEmail = convertRowDataPackage(email[0]).map((obj) => {
                                                return obj.Email;
                                            });
                                        }
                                        resolve();
                                    }));

                                    if (alwaysCC !== null && alwaysCC !== "") {
                                        ccEmail.push(alwaysCC);
                                    }
                                    const dataToSendReport = Object.assign({}, tempData, { orderID }, { feeData });
                                    const reportHtml = mergeDataField(message, getMergeFieldMappingOrderInvoice(dataToSendReport));
                                    if (selectSendMailOption === "7") {
                                        const newFileName = `TheClosingExchange-Confirmation_OrderId-${orderID}.pdf`;
                                        const options = {
                                            "height": "10.5in",
                                            "width": "8in",
                                            "format": "A4",
                                            "orientation": "portrait"
                                        };

                                        await new Promise((resolve) => pdf.create(reportHtml, options).toFile(`${URL_REPORT}${newFileName}`, (error) => {
                                            if (error) {
                                                reply(Boom.badRequest(error));
                                            } else {
                                                attachments.push({ path: `${URL_REPORT}${newFileName}` });
                                                attachmentNames.push(newFileName);
                                            }
                                            resolve();
                                        }));
                                    }
                                    subject = replaceAll(subject, "[brokerId]", dataToSendReport.brokerIdNum);
                                    subject = replaceAll(subject, "[orderLastName]", dataToSendReport.lastName);
                                    subject = replaceAll(subject, "[orderId]", dataToSendReport.orderID);
                                    const mailOptions = {
                                        from: fromEmail,
                                        to: emailAgent.email,
                                        cc: ccEmail,
                                        subject,
                                        html: selectSendMailOption === "7" ? null : reportHtml,
                                        attachments,
                                        attachmentNames,
                                        orderId: dataToSendReport.orderID
                                    };
                                    reply(mailOptions);
                                } else {
                                    reply("Unable to Send, Missing or Invalid Agent Email Address");
                                }
                            });

                        }).catch((err) => {
                            reply(Boom.badRequest(err));
                        });
                } else {
                    reply("Unable to Send, Missing or Invalid Agent Email Address");
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }

    sendMailReport(request, reply) {
        const mailOptions = request.payload;
        let isSuccess = true;
        let description = "";
        sendMailCore(mailOptions, (async result => {
            if (result.error === null) {
                switch (mailOptions.selectSendMailOption) {
                    case "0": {
                        description = `Sent an Order Form To ${mailOptions.to}`;
                        break;
                    }
                    case "1":
                        description = `Sent an Order Form To ${mailOptions.to}`;
                        break;
                    case "2":
                        description = `Sent an Order Confirmation To ${mailOptions.to}`;
                        break;
                    case "3":
                        description = `Sent an Order Confirmation To ${mailOptions.to}`;
                        break;
                    case "4":
                        description = `Sent an Order Confirmation To ${mailOptions.to}`;
                        break;
                    case "5":
                        description = `Sent an Order Confirmation To ${mailOptions.to}`;
                        break;
                    case "6":
                        description = `Sent an Order Confirmation To ${mailOptions.to}`;
                        break;
                    case "7":
                        description = `Sent an Order Confirmation To ${mailOptions.to}`;
                        break;
                }

                await new Promise((resolve) => new Comment().save({
                    Description: description,
                    CreatedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                    CreatedBy: mailOptions.userId,
                    TypeID: 1,
                    OwnerID: mailOptions.orderId,
                    IsPrivate: 0
                }, {
                        method: "insert"
                    }).then(() => resolve()).catch(() => {
                    }));

                await new Promise((resolve) => new OrderProgressLog().save({
                    OrderId: mailOptions.orderId,
                    UsersId: mailOptions.userId,
                    Activity: `${mailOptions.userName} added a note.`,
                    DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                    IsPrivate: 0,
                    ProgressType: 1
                }, {
                        method: "insert"
                    }).then(() => resolve()).catch(() => {
                    }));
            } else {
                isSuccess = false;
            }
        }));
        reply({ isSuccess });
    }

}

export default new ReportController();