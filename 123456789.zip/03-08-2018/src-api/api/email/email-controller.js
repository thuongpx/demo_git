import sendMailCore from "../../mail/mail-helper";
import Boom from "boom";
import config from "../../config/config";
import User from "../../db/model/users";
import Signer from "../../db/model/signers";
import {
    replaceAll,
    sendSigningResultEmail
} from "./../../helper/common-helper";
import Bookshelf from "./../../db/database";
import { sendSms } from "./../../helper/sms-helper";
import {
    NOTIFICATION_TEMPLATE_PURPOSE
} from "../../constant/common-constant";
//
import Agent from "../../db/model/agents";
import Broker from "../../db/model/brokers";
import { ORDER_PROGRESS_ID } from "../../constant/progress-constant";
import {
    CLOSE_REQUEST_TEMPLATE,
    AGENT_INFO_TR,
    SCANBACK_TEMPLATE,
    SCANBACK_DOC_TEMPLATE,
    UNSUCCESSFUL_SIGNING_TEMPLATE,
    UNSUCESSFUL_PRODUCT_REP_ITEM,
    UNSUCESSFUL_CLIENT_AGENT_ITEM,
    UNSUCESSFUL_TCE_ITEM
} from "../../constant/email-template-constants";

class EmailController {
    constructor() { }

    sendMail(request, reply) {
        const options = request.payload;

        const mailOptions = {
            from: options.from || "pavaso01@adb.com",
            to: options.to,
            subject: options.subject,
            text: options.text || "",
            html: options.html
        };

        sendMailCore(mailOptions, (result) => {
            if (result.error) {
                return reply(Boom.badRequest(result.error));
            }
            return reply(result);
        });
    }

    async mobileVendorSendEmailToUs(request, reply) {
        const { message, subject, usersId } = request.payload;
        let signerId = 0;
        let signerEmail = "";

        await new Promise((resolve) => User.where({ usersId }).fetch({ columns: ["mappingUserId"] }).then((model) => {
            signerId = model.get("mappingUserId");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Signer.where({ signerId }).fetch({ columns: ["email"] }).then((model) => {
            signerEmail = model.get("email");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        const mailOptions = {
            from: signerEmail,
            to: config.mail.receiver,
            subject,
            html: `${replaceAll(message, "\n", "<br/>")}`
        };

        sendMailCore(mailOptions);
        reply({ isSuccess: true });
    }

    async mobileSendEmailToTCE(request, reply) {
        const { message, usersId, orderId } = request.payload;
        let signerId = 0;
        let signerEmail = "";
        let receiveEmail = "";

        const rawSql = `Select o.OrderId, o.RepId, e.Email From \`order\` AS o
        INNER JOIN employees AS e ON o.RepId = e.RepId and OrderId= ${orderId} `;

        await new Promise((resolve) => User.where({ usersId }).fetch({ columns: ["mappingUserId"] }).then((model) => {
            signerId = model.get("mappingUserId");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Signer.where({ signerId }).fetch({ columns: ["email"] }).then((model) => {
            signerEmail = model.get("email");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    receiveEmail = result[0][0].Email;
                    const mailOptions = {
                        from: signerEmail,
                        to: receiveEmail,
                        subject: `OrderID #${orderId} - Vendor Communication`,
                        html: `${replaceAll(message, "\n", "<br/>")}`
                    };

                    sendMailCore(mailOptions);
                    reply({ isSuccess: true });
                }
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

    }

    mobileArrivedAtAppt(request, reply) {
        const { orderId } = request.payload;
        const rawSql = `SELECT o.HomePhone, o.AgentId, a.FullName, a.Email FROM \`order\` AS o INNER JOIN agent AS a ON o.AgentId = a.AgentId AND OrderId = ${orderId}`;
        const rawSqlGetTemplate = `SELECT fromEmail, subject, message FROM notification_templates nt where nt.Purpose='${NOTIFICATION_TEMPLATE_PURPOSE.ARRIVED_AT_APPOINTMENT_AGENT}'`;
        let agentEmail = "";

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    const homePhone = result[0][0].HomePhone;
                    const message = `Please informed that the Vendor of Order – ${orderId} has arrived at appointment.`;
                    agentEmail = result[0][0].Email;

                    sendSms(message, homePhone);

                    Bookshelf.knex.raw(rawSqlGetTemplate)
                        .then(mailResult => {
                            if (mailResult[0][0]) {
                                const templateMail = mailResult[0][0];
                                templateMail.message = replaceAll(templateMail.message, "[OrderID]", orderId);
                                const mailOptions = {
                                    from: templateMail.fromEmail,
                                    to: agentEmail,
                                    subject: replaceAll(templateMail.subject, "[OrderID]", orderId),
                                    html: templateMail.message
                                };

                                sendMailCore(mailOptions, (rs) => {
                                    reply(rs.error ? { error: rs.error } : { isSuccess: true });
                                });
                            }
                        }).catch(err => {
                            reply(Boom.badRequest(err));
                        });
                }
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    // send mail to vendor communication
    async sendEmailToVendorCommunication(request, reply) {
        const { message, usersId, orderId } = request.payload;
        let agentId = 0;
        let agentEmail = "";
        let receiveEmail = "";

        const rawSql = `Select o.OrderId, o.SignerId, s.Email From \`order\` AS o
        INNER JOIN signer AS s ON o.SignerId = s.SignerId and OrderId= ${orderId} `;

        await new Promise((resolve) => User.where({ usersId }).fetch({ columns: ["mappingUserId"] }).then((model) => {
            agentId = model.get("mappingUserId");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Agent.where({ agentId }).fetch({ columns: ["email"] }).then((model) => {
            agentEmail = model.get("email");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    receiveEmail = result[0][0].Email;
                    const mailOptions = {
                        from: agentEmail,
                        to: receiveEmail,
                        subject: `The Closing Exchange – Message from Client #${orderId}.`,
                        html: `${replaceAll(message, "\n", "<br/>")}`
                    };

                    sendMailCore(mailOptions);
                    reply({ isSuccess: true });
                }
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
    // send sms to vendor communication
    sendSmsToVendorCommunication(request, reply) {
        const { orderId, message } = request.payload;
        const rawSql = `SELECT o.HomePhone, o.SignerId, a.Email FROM \`order\` AS o INNER JOIN agent AS a ON o.AgentId = a.AgentId AND OrderId = ${orderId}`;

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    const homePhone = result[0][0].HomePhone;
                    const content = `OrderID #${orderId} ${message}`;

                    sendSms(content, homePhone);
                }
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
    // send mail to TCE communication
    async sendEmailToTCECommunication(request, reply) {
        const { message, usersId, orderId } = request.payload;
        let signerId = 0;
        let signerEmail = "";
        let receiveEmail = "";

        const rawSql = `Select o.OrderId, o.RepId, e.Email, e.FirstName From \`order\` AS o
        INNER JOIN employees AS e ON o.RepId = e.RepId and OrderId= ${orderId} `;

        await new Promise((resolve) => User.where({ usersId }).fetch({ columns: ["mappingUserId"] }).then((model) => {
            signerId = model.get("mappingUserId");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Signer.where({ signerId }).fetch({ columns: ["email"] }).then((model) => {
            signerEmail = model.get("email");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    receiveEmail = result[0][0].Email;
                    const mailOptions = {
                        from: signerEmail,
                        to: receiveEmail,
                        subject: `The Closing Exchange – Message from Client – Order #${orderId}`,
                        html: `${replaceAll(message, "\n", "<br/>")}`
                    };

                    sendMailCore(mailOptions);
                    reply({ isSuccess: true });
                }
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    // send mail to TCE communication
    async sendEmailToClientCommunication(request, reply) {
        const { message, usersId, orderId } = request.payload;
        let brokerId = 0;
        let brokerEmail = "";
        let receiveEmail = "";

        const rawSql = `Select o.OrderId, b.BrokerId, b.Email From \`order\` AS o
        INNER JOIN broker AS b ON o.BrokerId = b.BrokerId and OrderId= ${orderId} `;

        await new Promise((resolve) => User.where({ usersId }).fetch({ columns: ["mappingUserId"] }).then((model) => {
            brokerId = model.get("mappingUserId");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Broker.where({ brokerId }).fetch({ columns: ["email"] }).then((model) => {
            brokerEmail = model.get("email");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    receiveEmail = result[0][0].Email;
                    const mailOptions = {
                        from: brokerEmail,
                        to: receiveEmail,
                        subject: `The Closing Exchange – Message to Client – Order #${orderId}`,
                        html: `${replaceAll(message, "\n", "<br/>")}`
                    };

                    sendMailCore(mailOptions);
                    reply({ isSuccess: true });
                } else {
                    reply({ isSuccess: false });
                }
            } else {
                reply({ isSuccess: false });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    // send mail to Vendor Close Request, TCE Scheduler
    async sendSendCloseSuccessfully(request, reply) {
        const {
            orderId,
            courier,
            companyName,
            aptDateTime,
            courierAccountNumber,
            referenceNumber,
            trackingNumber,
            isIssues,
            issuesResolveText,
            isCollected,
            collectedText,
            isRequiredScanbacks,
            generalComment,
            vendorName,
            vendorEmail,
            agentEmail,
            agentPhone,
            agentName,
            tceEmail,
            customerLastName,
            isSelfService,
            documentReturnedOption,
            docDroppedDateTime,
            scanbacksDateTime,
            nextStatus,
        } = request.payload;

        const data = {
            mergeFields: {
                orderId,
                courier,
                companyName,
                aptDateTime,
                courierAccountNumber,
                referenceNumber,
                trackingNumber,
                isIssues,
                issuesResolveText,
                isCollected,
                collectedText,
                isRequiredScanbacks,
                generalComment,
                vendorName,
                agentEmail,
                agentName,
                agentPhone,
                customerLastName,
                orderStatus: nextStatus === ORDER_PROGRESS_ID.CLOSED_PENDING_REVIEW_PC_RESOLUTION ? "Closed Pending Review/PC Resolution" : "Closed Pending QC Review",
                documentReturnedOption,
                docDroppedDateTime,
                scanbacksDateTime
            }
        };

        if (nextStatus !== ORDER_PROGRESS_ID.CLOSED_PENDING_REVIEW_PC_RESOLUTION && nextStatus !== ORDER_PROGRESS_ID.CLOSED_PENDING_QC_REVIEW) {
            reply({ isSuccess: false });
            return;
        }

        let defaultTemplate = CLOSE_REQUEST_TEMPLATE;

        if (isRequiredScanbacks === "Yes") {
            defaultTemplate = defaultTemplate.replace("<!--SCANBACK-->", SCANBACK_TEMPLATE)
        } else {
            defaultTemplate = defaultTemplate.replace("<!--RETURN_DOC-->", SCANBACK_DOC_TEMPLATE);
        }

        // vendor template
        const vendorTemplateSql = `SELECT fromEmail, subject, message FROM \`notification_templates\` nt WHERE nt.Purpose='${NOTIFICATION_TEMPLATE_PURPOSE.CLOSE_REQUEST_VENDOR}'`;

        // Email template for agent
        const agentTemplateSql = `SELECT fromEmail, subject, message FROM \`notification_templates\` nt WHERE nt.Purpose='${NOTIFICATION_TEMPLATE_PURPOSE.CLOSE_REQUEST_AGENT}'`;

        // Email template for tce scheduler
        const tceTemplate = defaultTemplate.replace("<!--AGENT-->", AGENT_INFO_TR);

        // mail to Vendor
        if (vendorEmail) {
            const vendorTemplate = await Bookshelf.knex.raw(vendorTemplateSql);

            if (vendorTemplate && vendorTemplate[0] && vendorTemplate[0][0]) {
                data.template = defaultTemplate.replace("<!--STATEMENT-->", vendorTemplate[0][0].message);
                data.subject = vendorTemplate[0][0].subject;
                data.to = vendorEmail;
                sendSigningResultEmail(data);
            } else {
                console.log("COULD NOT SEND EMAIL TO VENDOR");
            }
        }

        // mail to Agent if any
        if (agentEmail) {
            const agentTemplate = await Bookshelf.knex.raw(agentTemplateSql);

            if (agentTemplate && agentTemplate[0] && agentTemplate[0][0]) {
                data.template = defaultTemplate.replace("<!--STATEMENT-->", agentTemplate[0][0].message);
                data.subject = agentTemplate[0][0].subject
                data.to = agentEmail;

                sendSigningResultEmail(data);
            } else {
                console.log("COULD NOT SEND EMAIL TO AGENT");
            }
        }

        // mail to TCE - only when order is self service
        if (tceEmail && tceTemplate && !isSelfService) {
            data.template = tceTemplate;
            data.subject = `The Closing Exchange Order #[orderId], LoanID #[referenceNumber] has been closed`;
            data.to = `${tceEmail}, btrantham@theclosingexchange.com`;

            sendSigningResultEmail(data);
        }

        reply({ isSuccess: true });
    }

    async sendSendCloseUnsuccessfully(request, reply) {
        const {
            orderId,
            referenceNumber,
            specificIssues,
            contactedProductRepresentative,
            contactedProductRepresentativeOption,
            contactedProductRepresentativeComment,
            contactedClientAgent,
            contactedClientAgentOption,
            contactedClientAgentComment,
            contactedTce,
            contactedTceOption,
            contactedTceComment,
            rightToCancelComment,
            rightToCancelOption,
            generalComment,
            vendorName,
            vendorEmail,
            agentEmail,
            agentName,
            agentPhone,
            tceEmail,
            customerFirstName,
            customerLastName,
            isSelfService,
            companyName
        } = request.payload;

        const emailData = {
            mergeFields: {
                orderId,
                referenceNumber,
                specificIssues,
                contactedProductRepresentativeOption: contactedProductRepresentativeOption ? "Yes" : "No",
                contactedProductRepresentativeComment,
                contactedClientAgentOption: contactedClientAgentOption ? "Yes" : "No",
                contactedClientAgentComment,
                contactedTceOption: contactedTceOption ? "Yes" : "No",
                contactedTceComment,
                rightToCancelComment,
                rightToCancelOption: rightToCancelOption ? "Yes" : "No",
                generalComment,
                vendorName,
                agentEmail,
                agentName,
                agentPhone,
                customerName: `${customerFirstName} ${customerLastName}`,
                customerLastName,
                companyName
            }
        };

        let generalTemplate = UNSUCCESSFUL_SIGNING_TEMPLATE;

        if (contactedProductRepresentative) {
            generalTemplate = replaceAll(generalTemplate, "<!--PRODUCT_REP-->", UNSUCESSFUL_PRODUCT_REP_ITEM);
        }

        if (contactedClientAgent) {
            generalTemplate = replaceAll(generalTemplate, "<!--CLIENT_AGENT-->", UNSUCESSFUL_CLIENT_AGENT_ITEM);
        }

        if (contactedTce) {
            generalTemplate = replaceAll(generalTemplate, "<!--TCE-->", UNSUCESSFUL_TCE_ITEM);
        }

        // vendor template
        const vendorTemplateSql = `SELECT fromEmail, subject, message FROM \`notification_templates\` nt WHERE nt.Purpose='${NOTIFICATION_TEMPLATE_PURPOSE.UNSUCCESSFUL_SIGNING_VENDOR}'`;

        // Email template for agent
        const agentTemplateSql = `SELECT fromEmail, subject, message FROM \`notification_templates\` nt WHERE nt.Purpose='${NOTIFICATION_TEMPLATE_PURPOSE.UNSUCCESSFUL_SIGNING_AGENT}'`;

        // Email template for tce scheduler
        const tceTemplate = generalTemplate.replace("<!--AGENT-->", AGENT_INFO_TR);

        // mail to Vendor
        if (vendorEmail) {
            const vendorTemplate = await Bookshelf.knex.raw(vendorTemplateSql);

            if (vendorTemplate && vendorTemplate[0] && vendorTemplate[0][0]) {
                emailData.template = generalTemplate.replace("<!--STATEMENT-->", vendorTemplate[0][0].message);
                emailData.subject = vendorTemplate[0][0].subject;
                emailData.to = vendorEmail;
                sendSigningResultEmail(emailData);
            } else {
                console.log("COULD NOT SEND EMAIL TO VENDOR");
            }
        }

        // mail to Agent if any
        if (agentEmail) {
            const agentTemplate = await Bookshelf.knex.raw(agentTemplateSql);

            if (agentTemplate && agentTemplate[0] && agentTemplate[0][0]) {
                emailData.template = generalTemplate.replace("<!--STATEMENT-->", agentTemplate[0][0].message);
                emailData.subject = agentTemplate[0][0].subject
                emailData.to = agentEmail;

                sendSigningResultEmail(emailData);
            } else {
                console.log("COULD NOT SEND EMAIL TO AGENT");
            }
        }

        // mail to TCE - only when order is self service
        if (tceEmail && tceTemplate && !isSelfService) {
            emailData.template = tceTemplate;
            emailData.subject = `Unsuccessful Signing - The Closing Exchange Order #[orderId], LoanID #[referenceNumber]`;
            emailData.to = `${tceEmail}, btrantham@theclosingexchange.com`;

            sendSigningResultEmail(emailData);
        }

        reply({ isSuccess: true });
    }
}

export default new EmailController();