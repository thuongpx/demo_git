import Bookshelf from "../../db/database";
import Boom from "boom";
import {
    buildSqlQuery,
    buildSqlCountQuery
} from "./canned-report";
import { replaceAll, distinctSingleValueArray, handleSingleQuoteRawSql, hasStringValue } from "../../helper/common-helper";
import { exportExcelFile } from "../../helper/excel-helper";

class EconomicReportController {
    constructor() { }

    fetchEconomicChartData(request, reply) {
        const sqlResult = buildSqlQuery("economic_chart_v", request.payload);
        const fetchStatus = request.payload.searchObject.status;
        const {
            sqlStr
        } = sqlResult;

        const execSql = `SELECT ofar.ReasonDescription, sum(ev.Approved + ev.Rejected + ev.Pending) as \`All\`,
        sum(ev.Approved) as Approved, sum(ev.Rejected) as Rejected, sum(ev.Pending) as Pending
        FROM \`order_fee_approve_reason\` \`ofar\` LEFT JOIN (${sqlStr}) ev on ofar.ReasonDescription = ev.ReasonDescription
        GROUP BY ofar.ReasonDescription;`;

        Bookshelf.knex.raw(execSql)
            .then(rs => {
                const rawData = rs[0];
                const labels = [];
                const listDataSets = {
                    All: {
                        label: "All Request",
                        data: []
                    },
                    Approved: {
                        label: "Approved",
                        data: []
                    },
                    Rejected: {
                        label: "Rejected",
                        data: []
                    },
                    Pending: {
                        label: "Pending",
                        data: []
                    }
                };

                rawData.map(item => {
                    labels.push(item.ReasonDescription);
                    listDataSets.All.data.push((item.Approved || 0) + (item.Rejected || 0) + (item.Pending || 0));
                    listDataSets.Approved.data.push((item.Approved || 0));
                    listDataSets.Rejected.data.push((item.Rejected || 0));
                    listDataSets.Pending.data.push((item.Pending || 0));
                });

                let datasets = [];

                if (Object.keys(fetchStatus).length === 0) {
                    datasets = [listDataSets.Approved, listDataSets.Rejected, listDataSets.Pending];
                } else {
                    Object.keys(fetchStatus).forEach(item => {
                        if (fetchStatus[item]) datasets.push(listDataSets[item]);
                    });
                }

                return reply({
                    labels,
                    datasets
                });
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countEconomicGridData(request, reply) {
        request.payload.searchObject.isGetDataForEconomicDrillDown = true;
        const sqlResult = buildSqlCountQuery("economic_drilldown_v", request.payload);

        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchEconomicGridData(request, reply) {
        request.payload.searchObject.isGetDataForEconomicDrillDown = true;
        const sqlResult = buildSqlQuery("economic_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];
                reply({
                    data
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    exportEconomicRequestFeeGridData(request, reply) {
        const inputs = request.payload;
        inputs.options = {
            sortColumn: "orderDate"
        };
        inputs.searchObject.isGetDataForEconomicDrillDown = true;
        const sqlResult = buildSqlQuery("economic_drilldown_v", inputs);
        const {
            sqlStr
        } = sqlResult;
        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];
                const columns = [
                    { label: "Open Date", value: "orderDate", type: "date" },
                    { label: "Order Number", value: "orderId" },
                    { label: "Original Fee", value: "originalAmount", type: "money" },
                    { label: "Proposed Fee ", value: "feeAmount", type: "money" },
                    { label: "Agent", value: "agent" },
                    { label: "Approved", value: "approved" }
                ];

                exportExcelFile(data, columns, "Fee Increase Request/ Approval List")
                    .then(async file => {
                        const { isSuccess, error, fileInfo } = file;
                        if (isSuccess) {
                            await reply.file(fileInfo.path);
                        } else {
                            reply(Boom.badRequest(error));
                        }
                    }).catch(err => reply(Boom.badRequest(err)));
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    getDefaultEconomicAgent(request, reply) {
        const rawSql = `SELECT DISTINCT Agent as name, AgentId as id, count(agentId) as numOfRequest 
						FROM economic_drilldown_v GROUP BY agent, agentId 
						ORDER BY \`numOfRequest\` DESC;`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const defaultAgent = rs[0];
                const topTen = [];
                const replyData = [];
                let count = 0;

                defaultAgent.map(i => {
                    const data = { value: i.id, label: hasStringValue(i.name) ? i.name : "" };
                    replyData.push(data);
                    if (count < 10) {
                        topTen.push(data);
                        count++;
                    }
                });

                reply({
                    listAgent: replyData,
                    listToptenAgent: topTen
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    async fetchEconomicProfitTrendDailyChartData(request, reply) {
        const listFetchColumn = ["Date(ClosedDate) as closeDate", "sum(ClientFee) as totalClientFee", "sum(SignerFee) as totalSignerFee"];
        const { month, assignType } = request.payload.searchObject;
        const sqlResultAutoAssign = buildSqlQuery("economic_profit_trend_daily_chart_v", { searchObject: { isAutoAssign: true }, options: { groupBy: "closeDate" } }, listFetchColumn);
        const sqlResultManualAssign = buildSqlQuery("economic_profit_trend_daily_chart_v", { searchObject: { isAutoAssign: false }, options: { groupBy: "closeDate" } }, listFetchColumn);
        const {
            sqlStr
        } = sqlResultAutoAssign;
        const sqlStrManual = sqlResultManualAssign.sqlStr;

        const execSql = `select day(d.date) as \`day\`, if (v.totalClientFee,v.totalClientFee, 0) - If(v.totalSignerFee, v.totalSignerFee, 0) as totalProfitDaily from 
        (select adddate('1970-01-01',t4.i*10000 + t3.i*1000 + t2.i*100 + t1.i*10 + t0.i) date from
        (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t0,
        (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t1,
        (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t2,
        (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t3,
        (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t4) d
        left join ([sqlStr]) v on d.date = v.closeDate
        where d.date between '2018-${month}-01' and IF('2018-${month}-31' > DATE(NOW()), DATE(NOW()), '2018-${month}-31')
        group by d.date
        order by d.date;`;

        const execSqlAuto = replaceAll(execSql, "[sqlStr]", sqlStr);
        const execSqlManual = replaceAll(execSql, "[sqlStr]", sqlStrManual);
        const labels = [];
        const listDataSets = {
            AutoAssign: {
                label: "Auto",
                data: []
            },
            ManualAssign: {
                label: "Manual",
                data: []
            }
        };
        let datasets = [];
        let autoAssignData = [];
        let manualAssignData = [];

        await new Promise(resolve => {
            Bookshelf.knex.raw(execSqlAuto)
                .then(rs => {
                    autoAssignData = rs[0];
                    resolve();
                }).catch(err => {
                    reply(Boom.badRequest(err));
                    resolve();
                });
        });

        await new Promise(resolve => {
            Bookshelf.knex.raw(execSqlManual)
                .then(rs => {
                    manualAssignData = rs[0];
                    resolve();
                }).catch(err => {
                    reply(Boom.badRequest(err));
                    resolve();
                });
        });

        autoAssignData.forEach((it, ix) => {
            labels.push(`Day ${it.day}`);
            listDataSets.AutoAssign.data.push(it.totalProfitDaily);
            listDataSets.ManualAssign.data.push(manualAssignData[ix].totalProfitDaily);
        });

        if (Number(assignType) === 2) {
            datasets = [listDataSets.AutoAssign];
        } else if (Number(assignType) === 1) {
            datasets = [listDataSets.ManualAssign];
        } else {
            datasets = [listDataSets.AutoAssign, listDataSets.ManualAssign];
        }

        return reply({
            labels,
            datasets
        });
    }
    fetchEconomicProfitTrendMonthlyChartData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            monthEconomic,
            assignType
        } = searchObject;

        const sqlResult = buildSqlQuery("economic_profit_trend_monthly_chart_v", request.payload);
        const {
            sqlStr,
            isShowAll
        } = sqlResult;
        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                const sortedMonth = monthEconomic.sort((a, b) => {
                    return parseInt(a.value) - parseInt(b.value);
                });
                const labels = distinctSingleValueArray(sortedMonth.map(item => item.label));
                const labelValue = distinctSingleValueArray(sortedMonth.map(item => item.value));
                let labelAssignType = [];
                if (assignType === "0") {
                    labelAssignType = ["Auto", "Manual"];
                } else if (assignType === "1") {
                    labelAssignType = ["Manual"];
                } else {
                    labelAssignType = ["Auto"];
                }
                const datasets = [];
                if (isShowAll) {
                    const tData = {
                        label: "All Data",
                        data: []
                    };
                    for (let i = 0; i < labelValue.length; i++) {
                        const f = rawData.filter(rd => (rd.CloseMonth === parseInt(labelValue[i])));

                        tData.data.push(f.length);
                    }
                    datasets.push(tData);
                } else {
                    for (let o = 0; o < labelAssignType.length; o++) {
                        const tData = {
                            label: labelAssignType[o],
                            data: []
                        };
                        for (let i = 0; i < labelValue.length; i++) {
                            const f = rawData.filter(r => (r.TypeAssign === labelAssignType[o] && r.CloseMonth === parseInt(labelValue[i])));
                            tData.data.push(f ? f.length : 0);
                        }

                        datasets.push(tData);
                    }
                }
                return reply({
                    labels,
                    datasets
                });
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchEconomicMixChartData(request, reply) {
        const listFetchColumn = ["count(OrderId) as numOfOrder", "sum(BrokerFee)/count(OrderId) as avgIncome", "sum(GrossProfit)/count(OrderId) as avgGrossProfit", "LoanType"];
        const { listLoanType } = request.payload.searchObject;
        request.payload.options = {
            groupBy: "LoanType"
        };

        const sqlResult = buildSqlQuery("economic_closed_order_chart_v", request.payload, listFetchColumn);
        const {
            sqlStr
        } = sqlResult;

        const _buildWhereLoanType = () => {
            if (!listLoanType || !Array.isArray(listLoanType) || listLoanType.length === 0) {
                return "";
            }

            let returnStr = " where l.LoanType in (";

            for (let i = 0; i < listLoanType.length; i++) {
                const data = listLoanType[i];
                returnStr += `'${handleSingleQuoteRawSql(data)}'`;
                if (i < listLoanType.length - 1) {
                    returnStr += `,`;
                } else {
                    returnStr += `) `;
                }
            }

            return returnStr;
        };

        const execQuery = `select l.LoanType, IFNULL(t1.numOfOrder, 0) as numOfOrder, IFNULL(t1.avgIncome, 0) as avgIncome, IFNULL(t1.avgGrossProfit, 0) as avgGrossProfit from loan_type l
        left join (${sqlStr}) t1 on t1.LoanType = l.LoanType ${_buildWhereLoanType()} order by avgIncome desc, LoanType asc;`;

        Bookshelf.knex.raw(execQuery)
            .then(rs => {
                const rawData = rs[0];
                const labels = [];
                const listDataSets = {
                    avgIncome: {
                        label: "Avg Income",
                        type: "bar",
                        yAxisID: "y-axis-1",
                        data: []
                    },
                    avgGrossProfit: {
                        label: "Avg Gross Profit",
                        type: "bar",
                        yAxisID: "y-axis-1",
                        data: []
                    },
                    orderCount: {
                        label: "Order Count",
                        type: "line",
                        yAxisID: "y-axis-2",
                        data: []
                    }
                };

                if (rawData) {
                    rawData.forEach(item => {
                        labels.push(item.LoanType);
                        listDataSets.avgIncome.data.push(item.avgIncome);
                        listDataSets.avgGrossProfit.data.push(item.avgGrossProfit);
                        listDataSets.orderCount.data.push(item.numOfOrder);
                    });
                }

                const datasets = [listDataSets.orderCount, listDataSets.avgIncome, listDataSets.avgGrossProfit];

                return reply({
                    labels,
                    datasets
                });
            }).catch(err => reply(Boom.badRequest(err)));
    }

    getListLoanTypeForMixChart(request, reply) {
        const rawSql = `select l.LoanType, IFNULL(t1.avgIncome, 0) as avgIncome from loan_type l
                        left join (
                            select count(OrderId) as numOfOrder, sum(BrokerFee)/count(OrderId) as avgIncome, sum(GrossProfit)/count(OrderId) as avgGrossProfit, LoanType from economic_closed_order_chart_v group by LoanType
                        ) t1 on t1.LoanType = l.LoanType
                        order by avgIncome desc, LoanType asc;`;
        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                const rawData = rs[0];
                const returnData = {
                    listLoanType: [],
                    listDefaultLoanType: []
                };

                rawData.forEach((item, index) => {
                    const data = { label: item.LoanType, value: item.LoanType };
                    returnData.listLoanType.push(data);
                    if (index < 5) returnData.listDefaultLoanType.push(data);
                });

                reply(returnData);
            }).catch(err => reply(Boom.badRequest(err)));
    }

    fetchEconomicClosedOrderDrilldownData(request, reply) {
        request.payload.searchObject.isGetDataForEconomicClosedOrder = true;
        const sqlResult = buildSqlQuery("economic_closed_order_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];
                reply({
                    data
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countEconomicClosedOrderDrilldownData(request, reply) {
        request.payload.searchObject.isGetDataForEconomicClosedOrder = true;
        const sqlResult = buildSqlCountQuery("economic_closed_order_drilldown_v", request.payload);

        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    testExportExcelFile(request, reply) {
        const columns = [
            { value: "stringData", label: "String Data Data Data Data Data Data Data Data" },
            { value: "numberData", label: "Number Data" },
            { value: "dateData", label: "Date Data" }
        ];
        const testData = [
            { stringData: "string1", numberData: 100, dateData: "03/29/2018" },
            { stringData: "string2", numberData: 200, dateData: "03/30/2018" },
            { stringData: "string3", numberData: 300, dateData: "03/31/2018" }
        ];

        exportExcelFile(testData, columns, "Test Export Header")
            .then(rs => {
                const { isSuccess, error, fileInfo } = rs;
                if (isSuccess) {
                    reply({
                        fileInfo
                    });
                } else {
                    reply(Boom.badRequest(error));
                }
            }).catch(err => reply(Boom.badRequest(err)));
    }
}

export default new EconomicReportController();