const fs = require("fs");

import Boom from "boom";

import {
	distinctSingleValueArray,
	bufferToBoolean
} from "../../helper/common-helper";
import {
	getOrderTypes,
	getAgents,
	getScheduler,
	buildSqlQuery
} from "./canned-report";
//
import ManualReportTemplate from "../../db/model/manual-report-templates";
import moment from "moment";
import Bookshelf from "../../db/database";
import { exportExcelFile } from "../../helper/excel-helper";

class CannedReportController {
	constructor() { }

	async getInitDataForCannedReport(request, reply) {
		// get order types list
		const orderTypes = await getOrderTypes();
		const agents = await getAgents();
		const schedulers = await getScheduler();

		reply({
			orderTypes: distinctSingleValueArray(orderTypes.map(i => i.LoanType)),
			agents: distinctSingleValueArray(agents.map(item => ({
				value: item.AgentId,
				label: item.Agents
			}))),
			schedulers: distinctSingleValueArray(schedulers.map(item => ({
				value: item.RepId,
				label: item.Scheduler
			})))
		});
	}

	addTemplateReport(request, reply) {
		const {
			reportName,
			searchBy,
			fromDate,
			toDate,
			searchAll,
			vendorStatus,
			columns,
			reportType
		} = request.payload;

		const reportObj = {
			ReportName: reportName,
			SearchBy: searchBy,
			FromDate: moment(fromDate).format("YYYY/MM/DD"),
			ToDate: moment(toDate).format("YYYY/MM/DD"),
			SearchAll: searchAll,
			VendorStatus: vendorStatus,
			Columns: columns,
			ReportType: reportType
		};
		new ManualReportTemplate().save(
			reportObj, {
				method: "insert"
			}).then((result) => {
				if (result !== null) {
					const data = result.attributes;
					const reportId = data.id;
					reply({
						reportId,
						isSuccess: true
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	deleteTemplateReport(request, reply) {
		const {
			reportId
		} = request.payload;

		ManualReportTemplate.where({
			reportId
		}).destroy().then((result) => {
			if (result !== null) {
				reply({
					isSuccess: true
				});

			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getTemplateReport(request, reply) {
		const rawSql = "Select ReportName From manual_report_templates";

		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null && result[0] !== null) {
					const listReport = result[0];
					reply({
						listReport
					});
				}
				return;
			}).catch(error => {
				reply(Boom.badRequest(error));
			});
	}

	getMetricGrossProfit(request, reply) {
		const firstDayOfCurrentMonth = moment().startOf("month").format("YYYY-MM-DD");
		const sqlQuery = `SELECT sum(GETORDERSIGNERFEEBYID(o.OrderId)) AS SignerFee, sum(GETORDERBROKERFEEBYID(o.OrderId)) AS BrokerFee, sum(GETORDERBROKERFEEBYID(o.OrderId)) - sum(GETORDERSIGNERFEEBYID(o.OrderId)) AS GrossProfit FROM \`order\` o`;

		const getGrossProfitToday = Promise.resolve(Bookshelf.knex.raw(`${sqlQuery} WHERE DATE(o.ClosedDate) = CURRENT_DATE();`));

		const getGrossProfitMtd = Promise.resolve(Bookshelf.knex.raw(`${sqlQuery}  WHERE ${firstDayOfCurrentMonth} <= o.ClosedDate AND o.ClosedDate  <= current_date();`));

		const promiseData = Promise.all([getGrossProfitToday, getGrossProfitMtd]);

		promiseData.then(values => {
			const data = {};
			if (values !== null) {
				values.forEach((item, index) => {
					if (item !== null) {
						switch (index) {
							case 0:
								data.today = item[0][0].GrossProfit ? item[0][0].GrossProfit : 0;
								break;
							case 1:
								data.mtd = item[0][0].GrossProfit ? item[0][0].GrossProfit : 0;
								break;
						}
					}
				});

				reply(data);
			}
		}).catch(err => {
			reply(Boom.badRequest(err));
		});
		return reply;
	}

	getMetricOpenedVolume(request, reply) {
		const startDayOfMonth = moment().startOf("month").format("YYYY-MM-DD");

		const rawSql = `select 
		COUNT((CASE WHEN date_format(OrderDate, '%Y-%m-%d') >= '${startDayOfMonth}' and date_format(OrderDate, '%Y-%m-%d') <= current_date() THEN OrderId ELSE NULL END)) AS mtd, 
		COUNT((CASE WHEN Date(OrderDate) = current_date() THEN OrderId ELSE NULL END)) AS today 
		from \`order\``;
		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null && result[0] !== null) {
					const data = result[0][0];
					reply({
						today: data.today,
						mtd: data.mtd
					});
				}
				return;
			}).catch(error => {
				reply(Boom.badRequest(error));
			});
	}

	getMetricRevenue(request, reply) {
		const firstDayOfCurrentMonth = moment().startOf("month").format("YYYY-MM-DD");
		const sqlQuery = "Select sum(GETORDERBROKERFEEBYID(o.OrderId)) AS TotalBrokerFee FROM \`order`\ o";
		const getAmountOfRevenueFromMTD = Promise.resolve(Bookshelf.knex.raw(`${sqlQuery} where  ${firstDayOfCurrentMonth} <= o.ClosedDate and o.ClosedDate  <= current_date()`));

		const getAmountOfRevenueInCurrentDay = Promise.resolve(Bookshelf.knex.raw(`${sqlQuery}  where Date(ClosedDate) =  current_date()`));

		const promiseData = Promise.all([getAmountOfRevenueInCurrentDay, getAmountOfRevenueFromMTD]);

		promiseData
			.then(values => {
				const data = {};
				if (values !== null) {
					values.forEach((item, index) => {
						if (item !== null) {
							switch (index) {
								case 0:
									data.today = item[0][0].TotalBrokerFee ? item[0][0].TotalBrokerFee : 0;
									break;
								case 1:
									data.mtd = item[0][0].TotalBrokerFee ? item[0][0].TotalBrokerFee : 0;
									break;

							}
						}
					});
				}


				reply(data);
			}).catch(err => {
				reply(Boom.badRequest(err));
			});
		return reply;
	}

	getMetricClosedVolume(request, reply) {
		const firstDayofMonth = moment().startOf("month").format("YYYY-MM-DD");
		const rawSql = `select 
						count(case when (date(ClosedDate) = curdate()) then OrderId else null end) as closedVolumeToday,
						count(case when (date(ClosedDate) >= ${firstDayofMonth} and date(ClosedDate) <= curdate()) then OrderId else null end) as closedVolumeMtd
						FROM  \`order\``;
		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null && result[0] !== null) {
					const data = result[0][0];
					reply({
						closedVolumeToday: data.closedVolumeToday,
						closedVolumeMtd: data.closedVolumeMtd
					});
				}
				return;
			}).catch(error => {
				reply(Boom.badRequest(error));
			});
	}

	// export manual report
	exportManualReportOrder(request, reply) {
		const inputs = JSON.parse(request.payload.toString());
		const { searchObject } = inputs;
		const itemExport = searchObject.join().replace(/\s/g, "");
		const sqlStr = `Select ${itemExport} From manual_order_report_v`;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs) {
					reply(Boom.badRequest("Empty response"));
					return;
				}
				const data = rs[0];
				let columns = [];
				const tempColumns = [];

				for (let i = 0; i < searchObject.length; i++) {
					const columnField = { label: searchObject[i].replace(/\s/g, ""), value: searchObject[i].replace(/\s/g, ""), type: searchObject[i].replace(/\s/g, "") === "AppointmentDateTime" || "OrderDate" ? "date" : "" };

					tempColumns.push(columnField);
				}
				columns = tempColumns;
				exportExcelFile(data, columns, "Manual Report Order")
					.then(async file => {
						const { isSuccess, error, fileInfo } = file;
						if (isSuccess) {
							await reply.file(fileInfo.path);
						} else {
							reply(Boom.badRequest(error));
						}
					}).catch(err => reply(Boom.badRequest(err)));
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	exportManualReportVendor(request, reply) {
		const inputs = JSON.parse(request.payload.toString());
		const { searchObject } = inputs;
		const itemExport = searchObject.join().replace(/\s/g, "");
		const sqlStr = `Select ${itemExport} From manual_vendor_report_v`;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs) {
					reply(Boom.badRequest("Empty response"));
					return;
				}
				const data = rs[0];
				let columns = [];
				const tempColumns = [];
				for (let i = 0; i < searchObject.length; i++) {
					const columnField = { label: searchObject[i].replace(/\s/g, ""), value: searchObject[i].replace(/\s/g, ""), type: searchObject[i].replace(/\s/g, "") === "CommissionExpiration" || "TitleProducersLicenseExpiration" ? "date" : "" };

					tempColumns.push(columnField);
				}
				columns = tempColumns;

				exportExcelFile(data, columns, "Manual Report Vendor")
					.then(async file => {
						const { isSuccess, error, fileInfo } = file;
						if (isSuccess) {
							await reply.file(fileInfo.path);
						} else {
							reply(Boom.badRequest(error));
						}
					}).catch(err => reply(Boom.badRequest(err)));
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	// get template by name
	getTemplateReportByName(request, reply) {
		const { reportName } = request.query;
		const rawSql = `Select ReportId, Columns From manual_report_templates Where ReportName='${reportName}'`;

		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null && result[0] !== null) {
					const data = result[0][0];
					const reportId = data.ReportId;
					let dataObject = {};
					const obj = data.Columns.split(",");
					const listColumnsByReportName = [];

					for (let i = 0; i < obj.length; i++) {
						dataObject = { value: obj[i], label: obj[i] };
						listColumnsByReportName.push(dataObject);
					}
					reply({
						listColumnsByReportName,
						reportId
					});
				}
			}).catch(error => {
				reply(Boom.badRequest(error));
			});
	}
}
export default new CannedReportController();