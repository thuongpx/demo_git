import CannedReportController from "./canned-report-controller";
import CustomerReportController from "./customer-report-controller";
import StaffReportController from "./staff-report-controller";
import EconomicReportController from "./economic-report-controller";
import DailyReportController from "./daily-report-controller";

const routes = [{
    path: "/cannedReport/fetchOrderByStatusChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.fetchOrderByStatusChartData
},
{
    path: "/cannedReport/getInitDataForCannedReport",
    method: "GET",
    config: {
        auth: false
    },
    handler: CannedReportController.getInitDataForCannedReport
},
{
    path: "/cannedReport/fetchOrderByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.fetchOrderByStatusGridData
},
{
    path: "/cannedReport/countOrderByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.countOrderByStatusGridData
},
{
    path: "/cannedReport/fetchOrderComparisonByBussinessChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.fetchOrderComparisonByBussinessChartData
},
{
    path: "/cannedReport/fetchClosedOrdersByCustomersChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchClosedOrdersByCustomersChartData
},
{
    path: "/cannedReport/fetchOpenOrderTrendByCustomersChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchOpenOrderTrendByCustomersChartData
},
{
    path: "/cannedReport/fetchAssignedOrderByAgentsChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: StaffReportController.fetchAssignedOrderByAgentsChartData
},
{
    path: "/cannedReport/fetchMilestonesChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchMilestonesChartData
},
{
    path: "/cannedReport/fetchMilestonesGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchMilestonesGridData
},
{
    path: "/cannedReport/countMilestonesGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countMilestonesGridData
},
{
    path: "/cannedReport/fetchDailyAutoAssignOrdersByStatusChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.fetchDailyAutoAssignOrdersByStatusChartData
},
{
    path: "/cannedReport/fetchDailyAutoAssignOrdersByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.fetchDailyAutoAssignOrdersByStatusGridData
},
{
    path: "/cannedReport/countDailyAutoAssignOrdersByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.countDailyAutoAssignOrdersByStatusGridData
},
{
    path: "/cannedReport/fetchDailyManualAssignOrdersByStatusChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.fetchDailyManualAssignOrdersByStatusChartData
},
{
    path: "/cannedReport/fetchDailyManualAssignOrdersByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.fetchDailyManualAssignOrdersByStatusGridData
},
{
    path: "/cannedReport/countDailyManualAssignOrdersByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.countDailyManualAssignOrdersByStatusGridData
},
{
    path: "/cannedReport/fetchOpenOrderTrendByCustomersGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchOpenOrderTrendByCustomersGridData
},
{
    path: "/cannedReport/fetchEconomicChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.fetchEconomicChartData
},
{
    path: "/cannedReport/countAssignedOrderBySchedulerGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: StaffReportController.countAssignedOrderBySchedulerGridData
},
{
    path: "/cannedReport/countOpenOrderTrendByCustomersGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countOpenOrderTrendByCustomersGridData
},
{
    path: "/cannedReport/fetchAssignedOrderBySchedulerGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: StaffReportController.fetchAssignedOrderBySchedulerGridData
},
{
    path: "/cannedReport/countEconomicGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.countEconomicGridData
},
{
    path: "/cannedReport/fetchClosedOrdersByCustomersGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchClosedOrdersByCustomersGridData
},
{
    path: "/cannedReport/fetchEconomicGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.fetchEconomicGridData
},
{
    path: "/cannedReport/getDefaultEconomicAgent",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.getDefaultEconomicAgent
},
{
    path: "/cannedReport/countClosedOrdersByCustomersGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countClosedOrdersByCustomersGridData
},
//{
//     path: "/cannedReport/fetchOrderByClientsAndStatus",
//     method: "POST",
//     config: {
//         auth: false
//     },
//     handler: CustomerReportController.fetchOrderByClientsAndStatus
// },

{
    path: "/cannedReport/fetchOrderByCustomerAndStatusChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchOrderByCustomerAndStatusChartData
},
{
    path: "/cannedReport/fetchOrderByCustomerAndStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchOrderByCustomerAndStatusGridData
},
{
    path: "/cannedReport/countOrderByCustomerAndStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countOrderByCustomerAndStatusGridData
},
{
    path: "/cannedReport/addTemplateReport",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.addTemplateReport

},
{
    path: "/cannedReport/fetchOpenOrderTrendForStaffChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchOpenOrderTrendForStaffChartData

},
{
    path: "/cannedReport/fetchOpenOrderTrendForStaffGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchOpenOrderTrendForStaffGridData

},
{
    path: "/cannedReport/countOpenOrderTrendForStaffGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countOpenOrderTrendForStaffGridData
},
{
    path: "/cannedReport/deleteTemplateReport",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.deleteTemplateReport
},
{
    path: "/cannedReport/getTemplateReport",
    method: "GET",
    config: {
        auth: false
    },
    handler: CannedReportController.getTemplateReport
},
{
    path: "/cannedReport/fetchAssignedOrderBySchedulerForStaffGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: StaffReportController.fetchAssignedOrderBySchedulerForStaffGridData
},
{
    path: "/cannedReport/fetchMilestonesForStaffChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchMilestonesForStaffChartData
},
{
    path: "/cannedReport/fetchMilestonesForStaffGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchMilestonesForStaffGridData
},
{
    path: "/cannedReport/countMilestonesForStaffGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countMilestonesForStaffGridData
},
{
    path: "/cannedReport/fetchEconomicProfitTrendDailyChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.fetchEconomicProfitTrendDailyChartData
},
{
    path: "/cannedReport/fetchClosedOrdersByClientForStaffChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchClosedOrdersByClientForStaffChartData

},
{
    path: "/cannedReport/fetchClosedOrdersByClientForStaffGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchClosedOrdersByClientForStaffGridData

},
{
    path: "/cannedReport/countClosedOrdersByClientForStaffGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countClosedOrdersByClientForStaffGridData
},
{
    path: "/cannedReport/fetchAssignedOrderBySchedulerForStaffChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: StaffReportController.fetchAssignedOrderBySchedulerForStaffChartData
},
{
    path: "/cannedReport/fetchOrderByCustomerAndStatusForStaffChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchOrderByCustomerAndStatusForStaffChartData
},
{
    path: "/cannedReport/fetchOrderByCustomerAndStatusForStaffGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchOrderByCustomerAndStatusForStaffGridData
},
{
    path: "/cannedReport/countOrderByCustomerAndStatusForStaffGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countOrderByCustomerAndStatusForStaffGridData
},
{
    path: "/cannedReport/getMetricRevenue",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.getMetricRevenue
},
{
    path: "/cannedReport/getMetricClosedVolume",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.getMetricClosedVolume
},
// {
//     path: "/cannedReport/downloadExcel",
//     method: "GET",
//     config: {
//         auth: false
//     },
//     handler: CannedReportController.downloadExcel
// }
{
    path: "/cannedReport/getMetricOpenedVolume",
    method: "GET",
    config: {
        auth: false
    },
    handler: CannedReportController.getMetricOpenedVolume
},
{
    path: "/cannedReport/getMetricGrossProfit",
    method: "GET",
    config: {
        auth: false
    },
    handler: CannedReportController.getMetricGrossProfit
},
{
    path: "/cannedReport/fetchEconomicProfitTrendMonthlyChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.fetchEconomicProfitTrendMonthlyChartData
},
{
    path: "/cannedReport/countAssignedOrderBySchedulerForStaffGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: StaffReportController.countAssignedOrderBySchedulerForStaffGridData
},
{
    path: "/cannedReport/fetchEconomicMixChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.fetchEconomicMixChartData
},
{
    path: "/cannedReport/getListLoanTypeForMixChart",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.getListLoanTypeForMixChart
},
{
    path: "/cannedReport/fetchEconomicClosedOrderDrilldownData",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.fetchEconomicClosedOrderDrilldownData
},
{
    path: "/cannedReport/countEconomicClosedOrderDrilldownData",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.countEconomicClosedOrderDrilldownData
},
{
    path: "/cannedReport/testExportExcelFile",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.testExportExcelFile
},
{
    path: "/cannedReport/exportEconomicRequestFeeGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.exportEconomicRequestFeeGridData
},
{
    path: "/cannedReport/exportComparisonByBusinessDayGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.exportComparisonByBusinessDayGridData
},
{
    path: "/cannedReport/exportOrderByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.exportOrderByStatusGridData
},
{
    path: "/cannedReport/exportDailyAutoAssignedOrdersByStatusGrid",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.exportDailyAutoAssignedOrdersByStatusGrid
},
{
    path: "/cannedReport/exportDailyManualAssignedOrdersByStatusGrid",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.exportDailyManualAssignedOrdersByStatusGrid
},
// export manual report
{
    path: "/cannedReport/exportManualReportOrder",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.exportManualReportOrder
},
{
    path: "/cannedReport/exportManualReportVendor",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.exportManualReportVendor
},
{
    path: "/cannedReport/exportAssignedOrderBySchedulerGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: StaffReportController.exportAssignedOrderBySchedulerGridData
},
{
    path: "/cannedReport/exportDailyAssignedOrdersByStatusGrid",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.exportDailyAssignedOrdersByStatusGrid
},
{
    path: "/cannedReport/exportComparisonByBusinessDayGridDataForStaff",
    method: "POST",
    config: {
        auth: false
    },
    handler: DailyReportController.exportComparisonByBusinessDayGridDataForStaff
},
{
    path: "/cannedReport/exportMilestoneGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.exportMilestoneGridData
},
{
    path: "/cannedReport/exportOpenOrdersTrendByCustomer",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.exportOpenOrdersTrendByCustomer
},
{
    path: "/cannedReport/exportClosedOrdersByCustomersGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.exportClosedOrdersByCustomersGridData
},
{
    path: "/cannedReport/exportOrderByCustomerAndStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.exportOrderByCustomerAndStatusGridData
},
{
    path: "/cannedReport/getTemplateReportByName",
    method: "GET",
    config: {
        auth: false
    },
    handler: CannedReportController.getTemplateReportByName
}
];

export default routes;