import Bookshelf from "../../db/database";
import Boom from "boom";

import {
    distinctSingleValueArray,
    hasStringValue,
    replaceAll
} from "../../helper/common-helper";
import {
    buildSqlQuery,
    buildSqlCountQuery
} from "./canned-report";
import { exportExcelFile } from "../../helper/excel-helper";

class CustomerReportController {
    constructor() { }

    // Open order trend by customer
    fetchOpenOrderTrendByCustomersChartData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            month,
            customer
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_trend_chart_v", request.payload);

        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                const sortedMonth = month.sort((a, b) => {
                    return parseInt(a.value) - parseInt(b.value);
                });
                // console.log(sortedMonth, "month");
                // const monthData = distinctSingleValueArray(rawData.map(i => i.OrderMonth)); // build month
                const labelMonth = distinctSingleValueArray(sortedMonth.map(item => item.label));
                const labelValue = distinctSingleValueArray(sortedMonth.map(item => item.value));
                let labels = distinctSingleValueArray(rawData.map(i => i.customerName)); // build labels
                const datasets = [];

                if (customer === "All" || !customer) {

                    labels = ["All Customer"];
                    for (let i = 0; i < labelMonth.length; i++) {
                        const tData = {
                            label: labelMonth[i],
                            data: []
                        };
                        const f = rawData.filter(r => r.OrderMonth === parseInt(labelValue[i]));
                        tData.data.push(f ? f.length : 0);
                        datasets.push(tData);
                    }

                } else {
                    for (let a = 0; a < labelMonth.length; a++) {
                        const tData = {
                            label: labelMonth[a],
                            data: []
                        };
                        for (let j = 0; j < labels.length; j++) {
                            const labelValueInt = parseInt(labelValue[a]);
                            // eslint-disable-next-line
                            const f = rawData.filter(r => r.customerName === labels[j] && r.OrderMonth === labelValueInt);
                            tData.data.push(f ? f.length : 0);
                        }
                        datasets.push(tData);
                    }
                }

                // prepare temporary datasets to count total
                const totalDatasets = datasets[0].data.map(i => {
                    return {
                        value: i,
                        label: ""
                    };
                });

                // count total
                for (let i = 0; i < datasets.length; i++) {
                    for (let j = 0; j < totalDatasets.length; j++) {
                        if (i === 0) {
                            totalDatasets[j].label = labels[j];
                        } else {
                            totalDatasets[j].value += datasets[i].data[j];
                        }
                    }
                }

                // do sort
                totalDatasets.sort((a, b) => {
                    if (a.value > b.value) {
                        return -1;
                    }

                    if (a.value < b.value) {
                        return 1;
                    }

                    return 0;
                });

                const sortedLabels = totalDatasets.map(i => i.label);
                // sort data of datasets
                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < sortedLabels.length; j++) {
                        const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                        newData.push(oldData[oldIndex]);
                    }
                    datasets[i].data = newData;
                }

                // get top of customers
                let topNo = 0;


                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    default:
                        topNo = labels.length;
                        break;
                }
                const OtherNum = labels.length;

                labels = sortedLabels.filter((i, index) => index < topNo);

                if (hasStringValue(customer) && customer !== "All" && OtherNum > topNo) {
                    labels.push("Others");
                }

                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < labels.length; j++) {
                        if (labels[j] === "Others") {
                            // count other data
                            let otherData = 0;
                            for (let k = labels.length - 1; k < sortedLabels.length; k++) {
                                otherData += oldData[k];
                            }

                            newData.push(otherData);
                        } else {
                            newData.push(oldData[j]);
                        }
                    }
                    datasets[i].data = newData;
                }

                return reply({
                    labels,
                    datasets
                });
            }).catch(error => reply(Boom.badRequest(error)));
    }

    fetchOpenOrderTrendByCustomersGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            customer
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_customer_v", request.payload, null, true);
        const {
            sqlStr,
            sortByStr,
            pagingStr
        } = sqlResult;
        const rawSql = `SELECT c.Name as Customer
        , COUNT(OrderId) AS TotalOrder
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS Closed
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Pending') = 1 THEN 1 END) AS Pending    
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) AS Canceled   
        , CONCAT(ROUND(Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) / COUNT(OrderId) * 100, 2), " %") AS CancellationPercentage 
        FROM customers c 
        LEFT JOIN 
        (${sqlStr}) tbl ON c.CustomerId = tbl.CustomerId
        GROUP BY c.Name
        HAVING COUNT(OrderId) > 0
        ${sortByStr}
        ${pagingStr}`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                let flag = false;
                const topData = [];
                let topNo = 0;
                let totalOrder = 0;
                let closed = 0;
                let pending = 0;
                let canceled = 0;
                let cancellationPercentage = 0;

                const data = rs[0];

                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = data.length;
                        break;
                    default:
                        topNo = data.length;
                        break;
                }

                if (topNo > data.length) {
                    topNo = data.length;
                    flag = true;
                }

                // push data top10 || top 20 || All -- follow topNo
                for (let i = 0; i < topNo; i++) {
                    topData.push(data[i]);
                }

                // push data into Other colum
                for (let i = topNo; i < data.length; i++) {
                    totalOrder += parseInt(data[i].TotalOrder);
                    closed += parseInt(data[i].Closed);
                    pending += parseInt(data[i].Pending);
                    canceled += parseInt(data[i].Canceled);
                    if (data[i].CancellationPercentage) {
                        cancellationPercentage += replaceAll(data[i].CancellationPercentage, " %", "") * 100;
                    }
                }
                const OtherNum = data.length;
                if (hasStringValue(customer) && customer !== "All" && !flag && OtherNum > topNo) {
                    topData.push({
                        Customer: "Others",
                        TotalOrder: totalOrder,
                        Closed: closed,
                        Pending: pending,
                        Canceled: canceled,
                        CancellationPercentage: `${(cancellationPercentage / 100).toFixed(2)} %`
                    });
                }

                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                reply({
                    data: topData
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countOpenOrderTrendByCustomersGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            customer
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_customer_v", request.payload, null, true);
        const {
            sqlStr
        } = sqlResult;

        const rawSql = `SELECT COUNT(*) AS Num FROM(
            SELECT c.Name as Customer, COUNT(OrderId) AS TotalOrder
            FROM customers c 
            LEFT JOIN (${sqlStr}) tbl ON c.CustomerId = tbl.CustomerId            
            GROUP BY c.Name
            HAVING COUNT(OrderId) > 0) a`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }
                let data = 0;
                let topNo = 0;
                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = rs[0][0].Num;
                        break;
                    default:
                        topNo = rs[0][0].Num;
                        break;
                }

                if (topNo > rs[0][0].Num) {
                    topNo = rs[0][0].Num;
                } else if (topNo < rs[0][0].Num) {
                    topNo += 1;
                }
                data = topNo;
                reply(data);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    exportOpenOrdersTrendByCustomer(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            customer
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_customer_v", request.payload, null, true);
        const {
            sqlStr,
            sortByStr
        } = sqlResult;
        const rawSql = `SELECT c.Name as Customer
        , COUNT(OrderId) AS TotalOrder
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS Closed
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Pending') = 1 THEN 1 END) AS Pending    
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) AS Canceled   
        , CONCAT(ROUND(Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) / COUNT(OrderId) * 100, 2), " %") AS CancellationPercentage 
        FROM customers c 
        LEFT JOIN 
        (${sqlStr}) tbl ON c.CustomerId = tbl.CustomerId
        GROUP BY c.Name
        HAVING COUNT(OrderId) > 0
        ${sortByStr}`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                let flag = false;
                const topData = [];
                let topNo = 0;
                let totalOrder = 0;
                let closed = 0;
                let pending = 0;
                let canceled = 0;
                let cancellationPercentage = 0;

                const data = rs[0];

                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = data.length;
                        break;
                    default:
                        topNo = data.length;
                        break;
                }

                if (topNo > data.length) {
                    topNo = data.length;
                    flag = true;
                }

                // push data top10 || top 20 || All -- follow topNo
                for (let i = 0; i < topNo; i++) {
                    topData.push(data[i]);
                }

                // push data into Other colum
                for (let i = topNo; i < data.length; i++) {
                    totalOrder += parseInt(data[i].TotalOrder);
                    closed += parseInt(data[i].Closed);
                    pending += parseInt(data[i].Pending);
                    canceled += parseInt(data[i].Canceled);
                    if (data[i].CancellationPercentage) {
                        cancellationPercentage += replaceAll(data[i].CancellationPercentage, " %", "") * 100;
                    }
                }
                const OtherNum = data.length;
                if (hasStringValue(customer) && customer !== "All" && !flag && OtherNum > topNo) {
                    topData.push({
                        Customer: "Others",
                        TotalOrder: totalOrder,
                        Closed: closed,
                        Pending: pending,
                        Canceled: canceled,
                        CancellationPercentage: `${(cancellationPercentage / 100).toFixed(2)} %`
                    });
                }

                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const columns = [
                    { label: "Customer", value: "Customer" },
                    { label: "Open Orders", value: "TotalOrder" },
                    { label: "Closed", value: "Closed" },
                    { label: "Pending", value: "Pending" },
                    { label: "Canceled", value: "Canceled" },
                    { label: "Cancellation Percentage", value: "CancellationPercentage" }
                ];

                exportExcelFile(topData, columns, "Open Orders List by Clients and Status")
                    .then(async file => {
                        const { isSuccess, error, fileInfo } = file;
                        if (isSuccess) {
                            await reply.file(fileInfo.path);
                        } else {
                            reply(Boom.badRequest(error));
                        }
                    }).catch(err => reply(Boom.badRequest(err)));
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    // Milestones
    fetchMilestonesChartData(request, reply) {
        const sqlResult = buildSqlQuery("milestones_chart_v", request.payload, null, true);
        const {
            sqlStr
        } = sqlResult;
        const tData = {
            label: "All Data",
            data: []
        };

        const rawSql = `SELECT s.Name, Sum(s.TotalClosedOrders) AS TotalClosedOrders FROM (${sqlStr}) s 
        GROUP BY s.CustomerID
        ORDER BY TotalClosedOrders DESC;`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                const rawData = rs[0];
                const labels = [1, 25, 50, 100, 250, 500];
                const datasets = [];

                for (let i = 0; i < labels.length; i++) {
                    const start = labels[i];
                    const end = (i === labels.length - 1) ? -1 : (labels[i + 1]);
                    const f = rawData.filter(r => r.TotalClosedOrders >= start && (end === 0 || r.TotalClosedOrders < end));

                    tData.data.push(f.length);
                }

                datasets.push(tData);

                return reply({
                    labels,
                    datasets
                });

            }).catch(error => reply(Boom.badRequest(error)));
    }

    fetchMilestonesGridData(request, reply) {
        const sqlResult = buildSqlQuery("milestones_drilldown_v", request.payload, null, true);
        const {
            sqlStr,
            sortByStr,
            pagingStr
        } = sqlResult;

        const rawSql = `SELECT s.Company, s.CustomerID, s.BrokerID, Sum(s.TotalOrders) AS TotalOrders, Sum(s.TotalClosedOrders) AS TotalClosedOrders FROM (${sqlStr}) s 
        GROUP BY s.CustomerID
        ${sortByStr}
        ${pagingStr};`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];

                reply({
                    data
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countMilestonesGridData(request, reply) {
        const sqlResult = buildSqlQuery("milestones_drilldown_v", request.payload, null, true);
        const {
            sqlStr
        } = sqlResult;

        const rawSql = `SELECT Count(*) AS Num FROM (SELECT * FROM (${sqlStr}) s GROUP BY s.CustomerID) a;`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    exportMilestoneGridData(request, reply) {
        request.payload.options = {
            sortColumn: "TotalClosedOrders"
        };
        const sqlResult = buildSqlQuery("milestones_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];

                const columns = [
                    { label: "Company", value: "Company" },
                    { label: "Total Orders", value: "TotalOrders" },
                    { label: "Total Closed Orders", value: "TotalClosedOrders" }
                ];

                exportExcelFile(data, columns, "Customer Milestones")
                    .then(async file => {
                        const { isSuccess, error, fileInfo } = file;
                        if (isSuccess) {
                            await reply.file(fileInfo.path);
                        } else {
                            reply(Boom.badRequest(error));
                        }
                    }).catch(err => reply(Boom.badRequest(err)));
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    // Closed order by customer
    fetchClosedOrdersByCustomersChartData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            month
        } = searchObject;
        let {
            customer
        } = searchObject;

        const sqlResult = buildSqlQuery("closed_order_by_customer_chart_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                const sortedMonth = month.sort((a, b) => {
                    return parseInt(a.value) - parseInt(b.value);
                });
                const monthLabel = distinctSingleValueArray(sortedMonth.map(item => item.label));
                const monthValue = distinctSingleValueArray(sortedMonth.map(item => item.value));
                let labels = distinctSingleValueArray(rawData.map(i => i.Name));
                const datasets = [];

                // get datasets
                if (customer === "All") {

                    for (let i = 0; i < monthLabel.length; i++) {
                        const tData = {
                            label: monthLabel[i],
                            data: []
                        };

                        const f = rawData.filter(r => (r.OrderMonth === parseInt(monthValue[i])));
                        tData.data.push(f ? f.length : 0);

                        datasets.push(tData);
                    }

                    labels = ["All Customers"];
                    // tData.data.push(orderId.length);
                    // datasets.push(tData);

                } else {
                    for (let i = 0; i < monthLabel.length; i++) {
                        const tData = {
                            label: monthLabel[i],
                            data: []
                        };
                        for (let j = 0; j < labels.length; j++) {
                            // eslint-disable-next-line
                            const f = rawData.filter(r => (r.Name === labels[j] && r.OrderMonth === parseInt(monthValue[i])));
                            tData.data.push(f ? f.length : 0);
                        }
                        datasets.push(tData);
                    }
                }

                // prepare temporary datasets to count total
                const totalDatasets = datasets[0].data.map(i => {
                    return {
                        value: i,
                        label: ""
                    };
                });

                // count total
                for (let i = 0; i < datasets.length; i++) {
                    for (let j = 0; j < totalDatasets.length; j++) {
                        if (i === 0) {
                            totalDatasets[j].label = labels[j];
                        } else {
                            totalDatasets[j].value += datasets[i].data[j];
                        }
                    }
                }

                // do sort
                totalDatasets.sort((a, b) => {
                    if (a.value > b.value) {
                        return -1;
                    }

                    if (a.value < b.value) {
                        return 1;
                    }

                    return 0;
                });

                const sortedLabels = totalDatasets.map(i => i.label);

                // sort data of datasets

                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];

                    for (let j = 0; j < sortedLabels.length; j++) {
                        const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                        newData.push(oldData[oldIndex]);
                    }
                    datasets[i].data = newData;
                }

                // get top of customers
                if (customer === "Top 10 And Others") {
                    customer = "Top10AndOthers";
                } else if (customer === "Top 20 And Others") {
                    customer = "Top20AndOthers";
                }
                let topNo = 0;

                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    default:
                        topNo = labels.length;
                        break;
                }

                labels = sortedLabels.filter((i, index) => index < topNo);

                if (customer !== "All" && hasStringValue(customer)) {
                    labels.push("Others");
                }

                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < labels.length; j++) {
                        if (labels[j] === "Others") {
                            // count other data
                            let otherData = 0;
                            for (let k = labels.length - 1; k < sortedLabels.length; k++) {
                                otherData += oldData[k];
                            }

                            newData.push(otherData);
                        } else {
                            newData.push(oldData[j]);
                        }
                    }
                    datasets[i].data = newData;
                }

                return reply({
                    labels,
                    datasets
                });
            }).catch(error => reply(Boom.badRequest(error)));
    }

    fetchClosedOrdersByCustomersGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        let {
            customer
        } = searchObject;

        const sqlResult = buildSqlQuery("open_order_by_customer_v", request.payload, null, true);
        const {
            sqlStr,
            sortByStr,
            pagingStr
        } = sqlResult;

        const rawSql = `SELECT c.Name as Customer
                        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS Closed
                        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) AS Canceled
                        , Count(OrderId) AS TotalOrder
        FROM customers c 
        LEFT JOIN 
        (${sqlStr}) tbl ON c.CustomerId = tbl.CustomerId
        GROUP BY c.Name
        HAVING COUNT(OrderId) > 0
        ${sortByStr}
        ${pagingStr}`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                let flag = false;
                const topData = [];
                let topNo = 0;

                let closed = 0;
                let canceled = 0;

                if (customer === "Top 10 And Others") {
                    customer = "Top10AndOthers";
                } else if (customer === "Top 20 And Others") {
                    customer = "Top20AndOthers";
                }
                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = rs[0].length;
                        break;
                    default:
                        topNo = rs[0].length;
                        break;
                }
                if (topNo > rs[0].length) {
                    topNo = rs[0].length;
                    flag = true;
                }
                for (let i = 0; i < topNo; i++) {
                    topData.push(rs[0][i]);
                }
                for (let i = topNo; i < rs[0].length; i++) {

                    closed += parseInt(rs[0][i].Closed);
                    canceled += parseInt(rs[0][i].Canceled);
                }
                if (hasStringValue(customer) && customer !== "All" && !flag) {
                    topData.push({
                        Customer: "Others",
                        Closed: closed,
                        Canceled: canceled
                    });
                }

                const data = rs[0];
                let totalClosed = 0;
                let totalCanceled = 0;
                const closedOrders = data.map(i => i.Closed);
                const canceledOrders = data.map(i => i.Canceled);

                for (let i = 0; i < closedOrders.length; i++) {

                    totalClosed += closedOrders[i];
                }

                for (let i = 0; i < canceledOrders.length; i++) {

                    totalCanceled += canceledOrders[i];
                }

                topData.push({
                    Customer: `Total`,
                    Closed: totalClosed,
                    Canceled: totalCanceled
                });

                reply({
                    data: topData
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countClosedOrdersByCustomersGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        let {
            customer
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_customer_v", request.payload, null, true);
        const {
            sqlStr
        } = sqlResult;

        const rawSql = `SELECT c.Name as Customer
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS Closed
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) AS Canceled
        , Count(OrderId) AS TotalOrder
        FROM customers c 
        LEFT JOIN 
        (${sqlStr}) tbl ON c.CustomerId = tbl.CustomerId
        GROUP BY c.Name
        HAVING COUNT(OrderId) > 0`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                let flag = false;
                const topData = [];
                let topNo = 0;
                let closed = 0;
                let canceled = 0;

                if (customer === "Top 10 And Others") {
                    customer = "Top10AndOthers";
                } else if (customer === "Top 20 And Others") {
                    customer = "Top20AndOthers";
                }

                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = rs[0].length;
                        break;
                    default:
                        topNo = rs[0].length;
                        break;
                }

                if (topNo > rs[0].length) {
                    topNo = rs[0].length;
                    flag = true;
                }

                for (let i = 0; i < topNo; i++) {
                    topData.push(rs[0][i]);
                }

                for (let i = topNo; i < rs[0].length; i++) {
                    closed += parseInt(rs[0][i].Closed);
                    canceled += parseInt(rs[0][i].Canceled);
                }

                if (hasStringValue(customer) && customer !== "All" && !flag) {
                    topData.push({
                        Customer: "Others",
                        Closed: closed,
                        Canceled: canceled
                    });
                }

                reply(
                    topData.length
                );
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    exportClosedOrdersByCustomersGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        let {
            customer
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_customer_v", request.payload, null, true);
        const {
            sqlStr,
            sortByStr,
            pagingStr
        } = sqlResult;

        const rawSql = `SELECT c.Name as Customer
                        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS Closed
                        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) AS Canceled
                        , Count(OrderId) AS TotalOrder
        FROM customers c 
        LEFT JOIN 
        (${sqlStr}) tbl ON c.CustomerId = tbl.CustomerId
        GROUP BY c.Name
        HAVING COUNT(OrderId) > 0
        ${sortByStr}
        ${pagingStr}`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                let flag = false;
                const topData = [];
                let topNo = 0;

                let closed = 0;
                let canceled = 0;

                if (customer === "Top 10 And Others") {
                    customer = "Top10AndOthers";
                } else if (customer === "Top 20 And Others") {
                    customer = "Top20AndOthers";
                }
                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = rs[0].length;
                        break;
                    default:
                        topNo = rs[0].length;
                        break;
                }
                if (topNo > rs[0].length) {
                    topNo = rs[0].length;
                    flag = true;
                }
                for (let i = 0; i < topNo; i++) {
                    topData.push(rs[0][i]);
                }
                for (let i = topNo; i < rs[0].length; i++) {

                    closed += parseInt(rs[0][i].Closed);
                    canceled += parseInt(rs[0][i].Canceled);
                }
                if (hasStringValue(customer) && customer !== "All" && !flag) {
                    topData.push({
                        Customer: "Others",
                        Closed: closed,
                        Canceled: canceled
                    });
                }

                const data = rs[0];
                let totalClosed = 0;
                let totalCanceled = 0;
                const closedOrders = data.map(i => i.Closed);
                const canceledOrders = data.map(i => i.Canceled);

                for (let i = 0; i < closedOrders.length; i++) {

                    totalClosed += closedOrders[i];
                }

                for (let i = 0; i < canceledOrders.length; i++) {

                    totalCanceled += canceledOrders[i];
                }

                topData.push({
                    Customer: `Total`,
                    Closed: totalClosed,
                    Canceled: totalCanceled
                });

                const columns = [
                    { label: "Customer", value: "Customer" },
                    { label: "Closed Orders", value: "Closed" },
                    { label: "Cancelled Orders", value: "Canceled" }
                ];

                exportExcelFile(topData, columns, "Closed Orders By Customers")
                    .then(async file => {
                        const { isSuccess, error, fileInfo } = file;
                        if (isSuccess) {
                            await reply.file(fileInfo.path);
                        } else {
                            reply(Boom.badRequest(error));
                        }
                    }).catch(err => reply(Boom.badRequest(err)));
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchOrderByCustomerAndStatusChartData(request, reply) {
        const sqlResult = buildSqlQuery("open_order_by_customer_and_status_chart_v", request.payload);
        const {
            sqlStr
        } = sqlResult;
        const {
            searchObject
        } = request.payload;
        const {
            orderStatus,
            customer
        } = searchObject;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                const datasets = [];
                const rawData = rs[0];
                let labels = distinctSingleValueArray(rawData.map(i => i.CustomerName));
                let labelOrderStatus;
                if (orderStatus.length > 0) {
                    labelOrderStatus = distinctSingleValueArray(orderStatus.map(item => item.label));
                } else {
                    labelOrderStatus = distinctSingleValueArray(rawData.map(item => item.OrderStatus));
                }
                let tData = {
                    label: "All Data",
                    data: []
                };

                if (customer === "All" || !customer) {

                    labels = ["All Customer"];
                    for (let i = 0; i < labelOrderStatus.length; i++) {
                        tData = {
                            label: labelOrderStatus[i],
                            data: []
                        };
                        const f = rawData.filter(r => r.OrderStatus === labelOrderStatus[i]);
                        tData.data.push(f ? f.length : 0);
                        datasets.push(tData);
                    }
                } else {
                    for (let i = 0; i < labelOrderStatus.length; i++) {
                        tData = {
                            label: labelOrderStatus[i],
                            data: []
                        };
                        for (let j = 0; j < labels.length; j++) {
                            // eslint-disable-next-line
                            const f = rawData.filter(r => ((r.CustomerName === labels[j]) && (r.OrderStatus === labelOrderStatus[i])));
                            tData.data.push(f ? f.length : 0);
                        }
                        datasets.push(tData);
                    }
                }
                if (datasets.length > 0) {
                    // prepare temporary datasets to count total
                    const totalDatasets = datasets[0].data.map(i => {
                        return {
                            value: i,
                            label: ""
                        };
                    });

                    // count total
                    for (let i = 0; i < datasets.length; i++) {
                        for (let j = 0; j < totalDatasets.length; j++) {
                            if (i === 0) {
                                totalDatasets[j].label = labels[j];
                            } else {
                                totalDatasets[j].value += datasets[i].data[j];
                            }
                        }
                    }

                    // do sort
                    totalDatasets.sort((a, b) => {
                        if (a.value > b.value) {
                            return -1;
                        }

                        if (a.value < b.value) {
                            return 1;
                        }

                        return 0;
                    });

                    const sortedLabels = totalDatasets.map(i => i.label);
                    // sort data of datasets
                    for (let i = 0; i < datasets.length; i++) {
                        const oldData = datasets[i].data;
                        const newData = [];
                        for (let j = 0; j < sortedLabels.length; j++) {
                            const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                            newData.push(oldData[oldIndex]);
                        }
                        datasets[i].data = newData;
                    }

                    // get top of customers
                    let topNo = 0;

                    switch (customer) {
                        case "Top10AndOthers":
                            topNo = 10;
                            break;
                        case "Top20AndOthers":
                            topNo = 20;
                            break;
                        default:
                            topNo = labels.length;
                            break;
                    }

                    labels = sortedLabels.filter((i, index) => index < topNo);

                    if (hasStringValue(customer) && customer !== "All" && labels.length > topNo) {
                        labels.push("Others");
                    }

                    for (let i = 0; i < datasets.length; i++) {
                        const oldData = datasets[i].data;
                        const newData = [];
                        for (let j = 0; j < labels.length; j++) {
                            if (labels[j] === "Others") {
                                // count other data
                                let otherData = 0;
                                // eslint-disable-next-line
                                for (let k = labels.length - 1; k < sortedLabels.length; k++) {
                                    otherData += oldData[k];
                                }

                                newData.push(otherData);
                            } else {
                                newData.push(oldData[j]);
                            }
                        }
                        datasets[i].data = newData;
                    }
                } else if (hasStringValue(customer) && customer !== "All") {
                    labels.push("Others");
                }
                reply({
                    labels,
                    datasets
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchOrderByCustomerAndStatusGridData(request, reply) {
        const sqlResult = buildSqlQuery("open_order_by_customer_and_status_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                const dataMedium = rs[0];
                const data = [];
                const labels = distinctSingleValueArray(dataMedium.map(i => i.Customer));
                for (let i = 0; i < labels.length; i++) {
                    let countOpen = 0;
                    let countClose = 0;
                    let countCancel = 0;
                    let countPending = 0;
                    let cancellationPercentage = 0;
                    const f = dataMedium.filter(rd => rd.Customer === labels[i]);
                    for (let j = 0; j < f.length; j++) {
                        if (f[j].OrderStatus === "Open") {
                            countOpen += f[j].Count;
                        } else if (f[j].OrderStatus === "Closing Completed") {
                            countClose += f[j].Count;
                        } else if (f[j].OrderStatus === "Canceled") {
                            countCancel += f[j].Count;
                        } else {
                            countPending += f[j].Count;
                        }
                    }

                    if (countOpen === 0) {
                        cancellationPercentage = countCancel * 100;
                    } else {
                        cancellationPercentage = countCancel / countOpen;
                    }

                    data.push({
                        Customer: labels[i],
                        TotalOrder: countOpen,
                        Closed: countClose,
                        Pending: countPending,
                        Canceled: countCancel,
                        CancellationPercentage: cancellationPercentage
                    });
                }
                reply({
                    data
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countOrderByCustomerAndStatusGridData(request, reply) {
        const sqlResult = buildSqlCountQuery("open_order_by_customer_and_status_drilldown_v", request.payload);

        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    exportOrderByCustomerAndStatusGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            customer
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_customer_v", request.payload, null, true);
        const {
            sqlStr,
            sortByStr
        } = sqlResult;
        const rawSql = `SELECT c.Name as Customer
        , COUNT(OrderId) AS TotalOrder
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS Closed
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Pending') = 1 THEN 1 END) AS Pending    
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) AS Canceled   
        , CONCAT(ROUND(Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) / COUNT(OrderId) * 100, 2), " %") AS CancellationPercentage 
        FROM customers c 
        LEFT JOIN 
        (${sqlStr}) tbl ON c.CustomerId = tbl.CustomerId
        GROUP BY c.Name
        HAVING COUNT(OrderId) > 0
        ${sortByStr}`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                let flag = false;
                const topData = [];
                let topNo = 0;
                let totalOrder = 0;
                let closed = 0;
                let pending = 0;
                let canceled = 0;
                let cancellationPercentage = 0;

                const data = rs[0];

                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = data.length;
                        break;
                    default:
                        topNo = data.length;
                        break;
                }

                if (topNo > data.length) {
                    topNo = data.length;
                    flag = true;
                }

                // push data top10 || top 20 || All -- follow topNo
                for (let i = 0; i < topNo; i++) {
                    topData.push(data[i]);
                }

                // push data into Other colum
                for (let i = topNo; i < data.length; i++) {
                    totalOrder += parseInt(data[i].TotalOrder);
                    closed += parseInt(data[i].Closed);
                    pending += parseInt(data[i].Pending);
                    canceled += parseInt(data[i].Canceled);
                    if (data[i].CancellationPercentage) {
                        cancellationPercentage += replaceAll(data[i].CancellationPercentage, " %", "") * 100;
                    }
                }
                const OtherNum = data.length;
                if (hasStringValue(customer) && customer !== "All" && !flag && OtherNum > topNo) {
                    topData.push({
                        Customer: "Others",
                        TotalOrder: totalOrder,
                        Closed: closed,
                        Pending: pending,
                        Canceled: canceled,
                        CancellationPercentage: `${(cancellationPercentage / 100).toFixed(2)} %`
                    });
                }

                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const columns = [
                    { label: "Customer", value: "Customer" },
                    { label: "Open Orders", value: "TotalOrder" },
                    { label: "Closed", value: "Closed" },
                    { label: "Pending", value: "Pending" },
                    { label: "Canceled", value: "Canceled" },
                    { label: "Cancellation Percentage", value: "CancellationPercentage" }
                ];

                exportExcelFile(topData, columns, "Open Orders List by Clients and Status")
                    .then(async file => {
                        const { isSuccess, error, fileInfo } = file;
                        if (isSuccess) {
                            await reply.file(fileInfo.path);
                        } else {
                            reply(Boom.badRequest(error));
                        }
                    }).catch(err => reply(Boom.badRequest(err)));
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    // Milestones For Staff
    fetchMilestonesForStaffChartData(request, reply) {
        const sqlResult = buildSqlQuery("milestones_for_staff_chart_v", request.payload);
        const {
            sqlStr
        } = sqlResult;
        const tData = {
            label: "All Data",
            data: []
        };

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                const labels = [1, 25, 50, 100, 250, 500];
                const datasets = [];

                for (let i = 0; i < labels.length; i++) {
                    const start = labels[i];
                    const end = (i === labels.length - 1) ? -1 : (labels[i + 1]);
                    const f = rawData.filter(r => r.TotalClosedOrders >= start && (end === 0 || r.TotalClosedOrders < end));

                    tData.data.push(f.length);
                }

                datasets.push(tData);

                return reply({
                    labels,
                    datasets
                });

            }).catch(error => reply(Boom.badRequest(error)));
    }

    fetchMilestonesForStaffGridData(request, reply) {
        const sqlResult = buildSqlQuery("milestones_for_staff_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];

                reply({
                    data
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countMilestonesForStaffGridData(request, reply) {
        const sqlResult = buildSqlCountQuery("milestones_for_staff_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchOpenOrderTrendForStaffChartData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            month,
            agent
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_trend_for_staff_chart_v", request.payload);

        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                const sortedMonth = month.sort((a, b) => {
                    return parseInt(a.value) - parseInt(b.value);
                });
                // console.log(sortedMonth, "month");
                // const monthData = distinctSingleValueArray(rawData.map(i => i.OrderMonth)); // build month
                const labelMonth = distinctSingleValueArray(sortedMonth.map(item => item.label));
                const labelValue = distinctSingleValueArray(sortedMonth.map(item => item.value));
                let labels = distinctSingleValueArray(rawData.map(i => i.agentName)); // build labels
                const datasets = [];

                if (agent === "All" || !agent) {

                    labels = ["All Customer"];
                    for (let i = 0; i < labelMonth.length; i++) {
                        const tData = {
                            label: labelMonth[i],
                            data: []
                        };
                        const f = rawData.filter(r => r.OrderMonth === parseInt(labelValue[i]));
                        tData.data.push(f ? f.length : 0);
                        datasets.push(tData);
                    }

                } else {
                    for (let a = 0; a < labelMonth.length; a++) {
                        const tData = {
                            label: labelMonth[a],
                            data: []
                        };
                        for (let j = 0; j < labels.length; j++) {
                            // eslint-disable-next-line
                            const f = rawData.filter(r => (r.agentName === labels[j] && r.OrderMonth === parseInt(labelValue[a])));
                            tData.data.push(f ? f.length : 0);
                        }
                        datasets.push(tData);
                    }
                }

                // prepare temporary datasets to count total
                const totalDatasets = datasets[0].data.map(i => {
                    return {
                        value: i,
                        label: ""
                    };
                });

                // count total
                for (let i = 0; i < datasets.length; i++) {
                    for (let j = 0; j < totalDatasets.length; j++) {
                        if (i === 0) {
                            totalDatasets[j].label = labels[j];
                        } else {
                            totalDatasets[j].value += datasets[i].data[j];
                        }
                    }
                }

                // do sort
                totalDatasets.sort((a, b) => {
                    if (a.value > b.value) {
                        return -1;
                    }

                    if (a.value < b.value) {
                        return 1;
                    }

                    return 0;
                });

                const sortedLabels = totalDatasets.map(i => i.label);
                // sort data of datasets
                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < sortedLabels.length; j++) {
                        const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                        newData.push(oldData[oldIndex]);
                    }
                    datasets[i].data = newData;
                }

                // get top of customers
                let topNo = 0;


                switch (agent) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    default:
                        topNo = labels.length;
                        break;
                }

                labels = sortedLabels.filter((i, index) => index < topNo);

                if (hasStringValue(agent) && agent !== "All") {
                    labels.push("Others");
                }

                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < labels.length; j++) {
                        if (labels[j] === "Others") {
                            // count other data
                            let otherData = 0;
                            for (let k = labels.length - 1; k < sortedLabels.length; k++) {
                                otherData += oldData[k];
                            }

                            newData.push(otherData);
                        } else {
                            newData.push(oldData[j]);
                        }
                    }
                    datasets[i].data = newData;
                }

                return reply({
                    labels,
                    datasets
                });
            }).catch(error => reply(Boom.badRequest(error)));
    }

    fetchOpenOrderTrendForStaffGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            agent
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_client_for_staff_v", request.payload);
        const {
            sqlStr,
            sortByStr,
            pagingStr
        } = sqlResult;
        const rawSql = `SELECT tbl.Agents as Agents
        , COUNT(OrderId) AS TotalOrder
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS Closed
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Pending') = 1 THEN 1 END) AS Pending    
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) AS Canceled   
        , CONCAT(ROUND(Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) / COUNT(OrderId) * 100, 2), " %") AS CancellationPercentage 
        FROM agent c 
        LEFT JOIN 
        (${sqlStr}) tbl ON c.AgentId = tbl.AgentId
        GROUP BY tbl.Agents
        ${sortByStr}
        ${pagingStr};`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                let flag = false;
                const topData = [];
                let topNo = 0;
                let totalOrder = 0;
                let closed = 0;
                let pending = 0;
                let canceled = 0;
                let cancellationPercentage = 0;
                switch (agent) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = rs[0].length;
                        break;
                    default:
                        topNo = rs[0].length;
                        break;
                }
                if (topNo > rs[0].length) {
                    topNo = rs[0].length;
                    flag = true;
                }
                // push data top10 || top 20 || All -- follow topNo
                for (let i = 0; i < topNo; i++) {
                    topData.push(rs[0][i]);
                }
                // push data into Other colum
                for (let i = topNo; i < rs[0].length; i++) {
                    totalOrder += parseInt(rs[0][i].TotalOrder);
                    closed += parseInt(rs[0][i].Closed);
                    pending += parseInt(rs[0][i].Pending);
                    canceled += parseInt(rs[0][i].Canceled);
                    if (rs[0][i].CancellationPercentage) {
                        cancellationPercentage += replaceAll(rs[0][i].CancellationPercentage, " %", "") * 100;
                    }
                }

                if (hasStringValue(agent) && agent !== "All" && !flag) {
                    topData.push({
                        Customer: "Others",
                        TotalOrder: totalOrder,
                        Closed: closed,
                        Pending: pending,
                        Canceled: canceled,
                        CancellationPercentage: `${(cancellationPercentage / 100).toFixed(2)} %`
                    });
                }
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                reply({
                    data: topData
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countOpenOrderTrendForStaffGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            agent
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_client_for_staff_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        const rawSql = `SELECT COUNT(*) AS Num FROM(SELECT tbl.Agents as Customer   
            FROM agent c 
            LEFT JOIN (${ sqlStr}) tbl ON c.AgentId = tbl.AgentId
            GROUP BY tbl.Agents) a`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }
                let data = 0;
                let topNo = 0;
                switch (agent) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = rs[0][0].Num;
                        break;
                    default:
                        topNo = rs[0][0].Num;
                        break;
                }
                if (topNo > rs[0][0].Num) {
                    topNo = rs[0][0].Num;
                }
                data = topNo;
                reply(data);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchClosedOrdersByClientForStaffChartData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            month
        } = searchObject;
        let {
            agent
        } = searchObject;

        const sqlResult = buildSqlQuery("closed_order_by_customer_for_staff_chart_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                const sortedMonth = month.sort((a, b) => {
                    return parseInt(a.value) - parseInt(b.value);
                });
                const monthLabel = distinctSingleValueArray(sortedMonth.map(item => item.label));
                const monthValue = distinctSingleValueArray(sortedMonth.map(item => item.value));
                let labels = distinctSingleValueArray(rawData.map(i => i.Agents));
                const datasets = [];

                // get datasets
                if (agent === "All") {

                    for (let i = 0; i < monthLabel.length; i++) {
                        const tData = {
                            label: monthLabel[i],
                            data: []
                        };

                        const f = rawData.filter(r => (r.OrderMonth === parseInt(monthValue[i])));
                        tData.data.push(f ? f.length : 0);

                        datasets.push(tData);
                    }

                    labels = ["All Customers"];
                    // tData.data.push(orderId.length);
                    // datasets.push(tData);

                } else {
                    for (let i = 0; i < monthLabel.length; i++) {
                        const tData = {
                            label: monthLabel[i],
                            data: []
                        };
                        for (let j = 0; j < labels.length; j++) {
                            // eslint-disable-next-line
                            const f = rawData.filter(r => (r.Agents === labels[j] && r.OrderMonth === parseInt(monthValue[i])));
                            tData.data.push(f ? f.length : 0);
                        }
                        datasets.push(tData);
                    }
                }

                // prepare temporary datasets to count total
                const totalDatasets = datasets[0].data.map(i => {
                    return {
                        value: i,
                        label: ""
                    };
                });

                // count total
                for (let i = 0; i < datasets.length; i++) {
                    for (let j = 0; j < totalDatasets.length; j++) {
                        if (i === 0) {
                            totalDatasets[j].label = labels[j];
                        } else {
                            totalDatasets[j].value += datasets[i].data[j];
                        }
                    }
                }

                // do sort
                totalDatasets.sort((a, b) => {
                    if (a.value > b.value) {
                        return -1;
                    }

                    if (a.value < b.value) {
                        return 1;
                    }

                    return 0;
                });

                const sortedLabels = totalDatasets.map(i => i.label);

                // sort data of datasets

                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];

                    for (let j = 0; j < sortedLabels.length; j++) {
                        const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                        newData.push(oldData[oldIndex]);
                    }
                    datasets[i].data = newData;
                }

                // get top of customers
                if (agent === "Top 10 And Others") {
                    agent = "Top10AndOthers";
                } else if (agent === "Top 20 And Others") {
                    agent = "Top20AndOthers";
                }
                let topNo = 0;

                switch (agent) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    default:
                        topNo = labels.length;
                        break;
                }

                labels = sortedLabels.filter((i, index) => index < topNo);

                if (agent !== "All" && hasStringValue(agent)) {
                    labels.push("Others");
                }

                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < labels.length; j++) {
                        if (labels[j] === "Others") {
                            // count other data
                            let otherData = 0;
                            for (let k = labels.length - 1; k < sortedLabels.length; k++) {
                                otherData += oldData[k];
                            }

                            newData.push(otherData);
                        } else {
                            newData.push(oldData[j]);
                        }
                    }
                    datasets[i].data = newData;
                }

                return reply({
                    labels,
                    datasets
                });

            }).catch(error => reply(Boom.badRequest(error)));
    }

    fetchClosedOrdersByClientForStaffGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        let {
            agent
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_client_for_staff_v", request.payload, null, true);
        const {
            sqlStr,
            sortByStr,
            pagingStr
        } = sqlResult;

        const rawSql = `SELECT tbl.Agents as Agents
        ,Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS Closed
        ,Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) AS Canceled		
        ,Sum(CASE WHen tbl.OrderStatus = 'Closing Completed' then BrokerFee else 0 end) AS Income
        ,Sum( CASE WHen tbl.OrderStatus = 'Closing Completed' then SignerFee else 0 end) AS CostOfSales
        ,Sum(CASE WHen tbl.OrderStatus = 'Closing Completed' then BrokerFee else 0 end) - Sum( CASE WHen tbl.OrderStatus = 'Closing Completed' then SignerFee else 0 end) AS NetRevenue
        ,Sum(CASE WHen tbl.OrderStatus = 'Closing Completed' then BrokerFee else 0 end) / Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS AvgIncome
        ,Sum( CASE WHen tbl.OrderStatus = 'Closing Completed' then SignerFee else 0 end) / Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS AvgCOS
        ,(Sum(CASE WHen tbl.OrderStatus = 'Closing Completed' then BrokerFee else 0 end) - Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END))/Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS AvgNetRevenue 
        FROM agent a 
        JOIN (${sqlStr}) tbl ON a.AgentId = tbl.AgentId
        GROUP BY tbl.AgentId
        ${sortByStr}
        ${pagingStr};`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                let flag = false;
                const topData = [];
                let topNo = 0;

                let closed = 0;
                let canceled = 0;
                let income = 0;
                let costOfSales = 0;
                let netRevenue = 0;
                let avgIncome = 0;
                let avgCOS = 0;
                let avgNetRevenue = 0;

                if (agent === "Top 10 And Others") {
                    agent = "Top10AndOthers";
                } else if (agent === "Top 20 And Others") {
                    agent = "Top20AndOthers";
                }
                switch (agent) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = rs[0].length;
                        break;
                    default:
                        topNo = rs[0].length;
                        break;
                }
                if (topNo > rs[0].length) {
                    topNo = rs[0].length;
                    flag = true;
                }
                for (let i = 0; i < topNo; i++) {
                    topData.push(rs[0][i]);
                }
                for (let i = topNo; i < rs[0].length; i++) {

                    closed += parseInt(rs[0][i].Closed);
                    canceled += parseInt(rs[0][i].Canceled);
                    income += parseInt(rs[0][i].Income);
                    costOfSales += parseInt(rs[0][i].CostOfSales);
                    netRevenue += parseInt(rs[0][i].NetRevenue);
                    avgIncome += parseInt(rs[0][i].AvgIncome);
                    avgCOS += parseInt(rs[0][i].AvgCOS);
                    avgNetRevenue += parseInt(rs[0][i].AvgNetRevenue);
                }
                if (hasStringValue(agent) && agent !== "All" && !flag && topNo) {
                    topData.push({
                        Agents: "Others",
                        Closed: closed,
                        Canceled: canceled,
                        Income: income,
                        CostOfSales: costOfSales,
                        NetRevenue: netRevenue,
                        AvgIncome: avgIncome,
                        AvgCOS: avgCOS,
                        AvgNetRevenue: avgNetRevenue
                    });
                }

                const data = rs[0];

                let totalClosed = 0;
                let totalCanceled = 0;
                let totalIncome = 0;
                let totalCostOfSales = 0;
                let totalNetRevenue = 0;
                let totalAvgIncome = 0;
                let totalAvgCOS = 0;
                let totalAvgNetRevenue = 0;

                const closedOrders = data.map(i => i.Closed);
                const canceledOrders = data.map(i => i.Canceled);
                const incomeOrders = data.map(i => i.Income);
                const costOfSalesOrders = data.map(i => i.CostOfSales);
                const netRevenueOrders = data.map(i => i.NetRevenue);
                const avgIncomeOrders = data.map(i => i.AvgIncome);
                const avgCOSOrders = data.map(i => i.AvgCOS);
                const avgNetRevenueOrders = data.map(i => i.AvgNetRevenue);


                for (let i = 0; i < closedOrders.length; i++) {

                    totalClosed += closedOrders[i];
                }

                for (let i = 0; i < canceledOrders.length; i++) {

                    totalCanceled += canceledOrders[i];
                }
                for (let i = 0; i < incomeOrders.length; i++) {

                    totalIncome += incomeOrders[i];
                }
                for (let i = 0; i < costOfSalesOrders.length; i++) {

                    totalCostOfSales += costOfSalesOrders[i];
                }
                for (let i = 0; i < netRevenueOrders.length; i++) {

                    totalNetRevenue += netRevenueOrders[i];
                }
                for (let i = 0; i < avgIncomeOrders.length; i++) {

                    totalAvgIncome += avgIncomeOrders[i];
                }
                for (let i = 0; i < avgCOSOrders.length; i++) {

                    totalAvgCOS += avgCOSOrders[i];
                }
                for (let i = 0; i < avgNetRevenueOrders.length; i++) {

                    totalAvgNetRevenue += avgNetRevenueOrders[i];
                }
                topData.push({
                    Agents: "Total",
                    Closed: totalClosed,
                    Canceled: totalCanceled,
                    Income: totalIncome,
                    CostOfSales: totalCostOfSales,
                    NetRevenue: totalNetRevenue,
                    AvgIncome: totalAvgIncome,
                    AvgCOS: totalAvgCOS,
                    AvgNetRevenue: totalAvgNetRevenue
                });

                reply({
                    data: topData
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countClosedOrdersByClientForStaffGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        let {
            agent
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_client_for_staff_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        const rawSql = `SELECT tbl.Agents as Agents
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS Closed
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) AS Canceled
	
        ,Sum(BrokerFee) AS Income
        ,Sum(SignerFee) AS CostOfSales
        ,Sum(BrokerFee) - Sum(SignerFee) AS NetRevenue
        ,Sum(BrokerFee) / Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS AvgIncome
        ,Sum(SignerFee) / Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS AvgCOS
        ,(Sum(BrokerFee) - Sum(SignerFee))/Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS AvgNetRevenue 
        FROM agent a 
        LEFT JOIN 
        (${sqlStr}) tbl ON a.AgentId = tbl.AgentId
	
        GROUP BY Agents
        order by Closed DESC;
        `;
        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                let flag = false;
                const topData = [];
                let topNo = 0;

                let closed = 0;
                let canceled = 0;
                let income = 0;
                let costOfSales = 0;
                let netRevenue = 0;
                let avgIncome = 0;
                let avgCOS = 0;
                let avgNetRevenue = 0;

                if (agent === "Top 10 And Others") {
                    agent = "Top10AndOthers";
                } else if (agent === "Top 20 And Others") {
                    agent = "Top20AndOthers";
                }
                switch (agent) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = rs[0].length;
                        break;
                    default:
                        topNo = rs[0].length;
                        break;
                }
                if (topNo > rs[0].length) {
                    topNo = rs[0].length;
                    flag = true;
                }
                for (let i = 0; i < topNo; i++) {
                    topData.push(rs[0][i]);
                }
                for (let i = topNo; i < rs[0].length; i++) {

                    closed += parseInt(rs[0][i].Closed);
                    canceled += parseInt(rs[0][i].Canceled);
                    income += parseInt(rs[0][i].Income);
                    costOfSales += parseInt(rs[0][i].CostOfSales);
                    netRevenue += parseInt(rs[0][i].NetRevenue);
                    avgIncome += parseInt(rs[0][i].AvgIncome);
                    avgCOS += parseInt(rs[0][i].AvgCOS);
                    avgNetRevenue += parseInt(rs[0][i].AvgNetRevenue);
                }
                if (hasStringValue(agent) && agent !== "All" && !flag) {
                    topData.push({
                        Agents: "Others",
                        Closed: closed,
                        Canceled: canceled,
                        Income: income,
                        CostOfSales: costOfSales,
                        NetRevenue: netRevenue,
                        AvgIncome: avgIncome,
                        AvgCOS: avgCOS,
                        AvgNetRevenue: avgNetRevenue
                    });
                }

                reply(
                    topData.length
                );
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchOrderByCustomerAndStatusForStaffChartData(request, reply) {
        const sqlResult = buildSqlQuery("open_order_by_customer_and_status_for_staff_chart_v", request.payload);
        const {
            sqlStr
        } = sqlResult;
        const {
            searchObject
        } = request.payload;
        const {
            orderStatus,
            customer
        } = searchObject;
        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                const datasets = [];

                const rawData = rs[0];
                let labels = distinctSingleValueArray(rawData.map(i => i.AgentName));
                let labelOrderStatus;
                if (orderStatus.length > 0) {
                    labelOrderStatus = distinctSingleValueArray(orderStatus.map(item => item.label));
                } else {
                    labelOrderStatus = distinctSingleValueArray(rawData.map(item => item.OrderStatus));
                }
                let tData = {
                    label: "All Data",
                    data: []
                };

                if (customer === "All" || !customer) {

                    labels = ["All Customer"];
                    for (let i = 0; i < labelOrderStatus.length; i++) {
                        tData = {
                            label: labelOrderStatus[i],
                            data: []
                        };
                        const f = rawData.filter(r => r.OrderStatus === labelOrderStatus[i]);
                        tData.data.push(f ? f.length : 0);
                        datasets.push(tData);
                    }
                } else {
                    for (let i = 0; i < labelOrderStatus.length; i++) {
                        tData = {
                            label: labelOrderStatus[i],
                            data: []
                        };
                        for (let j = 0; j < labels.length; j++) {
                            // eslint-disable-next-line
                            const f = rawData.filter(r => ((r.AgentName === labels[j]) && (r.OrderStatus === labelOrderStatus[i])));
                            tData.data.push(f ? f.length : 0);
                        }
                        datasets.push(tData);
                    }
                }
                if (datasets.length > 0) {
                    // prepare temporary datasets to count total
                    const totalDatasets = datasets[0].data.map(i => {
                        return {
                            value: i,
                            label: ""
                        };
                    });

                    // count total
                    for (let i = 0; i < datasets.length; i++) {
                        for (let j = 0; j < totalDatasets.length; j++) {
                            if (i === 0) {
                                totalDatasets[j].label = labels[j];
                            } else {
                                totalDatasets[j].value += datasets[i].data[j];
                            }
                        }
                    }

                    // do sort
                    totalDatasets.sort((a, b) => {
                        if (a.value > b.value) {
                            return -1;
                        }

                        if (a.value < b.value) {
                            return 1;
                        }

                        return 0;
                    });

                    const sortedLabels = totalDatasets.map(i => i.label);
                    // sort data of datasets
                    for (let i = 0; i < datasets.length; i++) {
                        const oldData = datasets[i].data;
                        const newData = [];
                        for (let j = 0; j < sortedLabels.length; j++) {
                            const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                            newData.push(oldData[oldIndex]);
                        }
                        datasets[i].data = newData;
                    }

                    // get top of customers
                    let topNo = 0;

                    switch (customer) {
                        case "Top10AndOthers":
                            topNo = 10;
                            break;
                        case "Top20AndOthers":
                            topNo = 20;
                            break;
                        default:
                            topNo = labels.length;
                            break;
                    }

                    labels = sortedLabels.filter((i, index) => index < topNo);

                    if (hasStringValue(customer) && customer !== "All" && labels.length > topNo) {
                        labels.push("Others");
                    }

                    for (let i = 0; i < datasets.length; i++) {
                        const oldData = datasets[i].data;
                        const newData = [];
                        for (let j = 0; j < labels.length; j++) {
                            if (labels[j] === "Others") {
                                // count other data
                                let otherData = 0;
                                // eslint-disable-next-line
                                for (let k = labels.length - 1; k < sortedLabels.length; k++) {
                                    otherData += oldData[k];
                                }

                                newData.push(otherData);
                            } else {
                                newData.push(oldData[j]);
                            }
                        }
                        datasets[i].data = newData;
                    }
                } else if (hasStringValue(customer) && customer !== "All") {
                    labels.push("Others");
                }
                reply({
                    labels,
                    datasets
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchOrderByCustomerAndStatusForStaffGridData(request, reply) {
        const sqlResult = buildSqlQuery("open_order_by_customer_and_status_for_staff_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                const dataMedium = rs[0];
                const data = [];
                const labels = distinctSingleValueArray(dataMedium.map(i => i.Customer));
                for (let i = 0; i < labels.length; i++) {
                    let countOpen = 0;
                    let countClose = 0;
                    let countCancel = 0;
                    let countPending = 0;
                    let cancellationPercentage = 0;
                    const f = dataMedium.filter(rd => rd.Customer === labels[i]);
                    for (let j = 0; j < f.length; j++) {
                        if (f[j].OrderStatus === "Open") {
                            countOpen += f[j].Count;
                        } else if (f[j].OrderStatus === "Closing Completed") {
                            countClose += f[j].Count;
                        } else if (f[j].OrderStatus === "Canceled") {
                            countCancel += f[j].Count;
                        } else {
                            countPending += f[j].Count;
                        }
                    }

                    if (countOpen === 0) {
                        cancellationPercentage = countCancel * 100;
                    } else {
                        cancellationPercentage = countCancel / countOpen;
                    }

                    data.push({
                        Customer: labels[i],
                        TotalOrder: countOpen,
                        Closed: countClose,
                        Pending: countPending,
                        Canceled: countCancel,
                        CancellationPercentage: cancellationPercentage
                    });
                }
                reply({
                    data
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countOrderByCustomerAndStatusForStaffGridData(request, reply) {
        const sqlResult = buildSqlCountQuery("open_order_by_customer_and_status_for_staff_drilldown_v", request.payload);

        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }
}

export default new CustomerReportController();