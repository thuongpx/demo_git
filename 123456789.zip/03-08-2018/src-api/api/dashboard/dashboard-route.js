import DashboardController from "./dashboard-controller";

const routes = [
    {
        path: "/client-dashboard/getOrdersInfoDashboard",
        method: "GET",
        handler: DashboardController.getOrdersInfoDashboard
    },
    {
        path: "/client-dashboard/getOrdersInfoDetailDashboard",
        method: "GET",
        handler: DashboardController.getOrdersInfoDetailDashboard
    },
    {
        path: "/client-dashboard/getSLADashboard",
        method: "GET",
        handler: DashboardController.getSLADashboard
    },
    {
        path: "/staff-dashboard/getOrdersInfoSchedulerDashboard",
        method: "GET",
        handler: DashboardController.getOrdersInfoSchedulerDashboard
    }
];

export default routes;