import Boom from "boom";
import Bookshelf from "../../db/database";
import Signer from "../../db/model/signers";
import Users from "../../db/model/users";
import moment from "moment";

class VendorDashboardController {

    getDataVendorDashboard(request, reply) {
        const { signerId } = request.query;

        const orderUnCompleteSql = `SELECT COUNT(*) AS orderUnComplete 
                                    FROM ` +
            "`order`" +
            ` WHERE SignerId = ${signerId} AND ProgressId NOT IN (8, 10, 11);`;

        const orderCompleteSql = `SELECT COUNT(OrderID) AS orderComplete
                                    FROM order_stats
                                    WHERE SignerID = ${signerId} AND AptDateTime >= ADDDATE(utc_timestamp(), INTERVAL -2 YEAR)`;

        const signerDocSql = `SELECT DISTINCT s.DocTypeID AS docTypeID, sd.DocType AS docType, s.ExpireDate AS expireDate, s.State AS state
                                FROM signer_doctypes sd 
                                    LEFT JOIN signer_docs s on sd.DocTypeID = s.DocTypeId and s.SignerId = ${signerId}
                                WHERE sd.DocTypeID IN (1, 5, 6, 7, 8, 9, 10 );`;

        const orderErrorSql = `SELECT SUM(Mistake) AS totalError
                                FROM order_stats
                                WHERE SignerID = ${signerId}`;

        const avgTurnSql = `SELECT AVG(Turnaround) AS avgTurn
                            FROM order_stats
                            WHERE SignerID = ${signerId};`;
        const avgFeeSql = `SELECT AVG(sFee) AS avgFee
                            FROM order_stats
                            WHERE SignerID = ${signerId}`;
        const ratingSql = `SELECT r.Rating AS rating
                            FROM signer s 
                            INNER JOIN rating r on s.Rating = r.RatingID
                            WHERE SignerId = ${signerId};`;
        const checkCompleteAllOrderSql = `SELECT (CASE WHEN COUNT(*) > 0 THEN false ELSE true END) AS isCompleteAll
                                        FROM ` +
            "`order`" +
            ` WHERE SignerId = ${signerId} AND ProgressId NOT IN (8);`;

        const getFirstAptDateTimeSql = `SELECT AptDateTime AS aptDateTime
            FROM order_stats WHERE SignerId = ${signerId} AND AptDateTime IS NOT NULL ORDER BY AptDateTime LIMIT 1;`;

        const queue = [];

        queue.push(Promise.resolve(Bookshelf.knex.raw(orderUnCompleteSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(signerDocSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(orderCompleteSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(orderErrorSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(avgTurnSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(avgFeeSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(ratingSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(checkCompleteAllOrderSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(getFirstAptDateTimeSql)));

        Promise.all(queue).then((result) => {
            if (result !== null && result !== undefined) {
                const signerDoc = result[1][0].map(item => {
                    return {
                        docTypeID: item.docTypeID,
                        docType: `${item.docType} ${item.state ? `(${item.state})` : ""}`,
                        expireDate: item.expireDate
                    };
                });

                reply({
                    orderUnComplete: result[0][0][0] ? result[0][0][0].orderUnComplete : 0,
                    signerDoc,
                    orderComplete: result[2][0][0] ? result[2][0][0].orderComplete : 0,
                    totalError: result[3][0][0] ? result[3][0][0].totalError : 0,
                    avgTurn: result[4][0][0] ? result[4][0][0].avgTurn : 0,
                    avgFee: result[5][0][0] ? result[5][0][0].avgFee : 0,
                    rating: result[6][0][0] ? result[6][0][0].rating : 0,
                    isCompleteAll: result[7][0][0] ? result[7][0][0].isCompleteAll : false,
                    aptDateTime: result[8][0][0] ? result[8][0][0].aptDateTime : null
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    deactivateVendor(request, reply) {
        const { signerId, accountId } = request.payload;

        const deactivateSigner = Promise.resolve(Signer.where({ SignerId: signerId }).save({
            InActive: 1,
            InActiveDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        }, { method: "update" }));
        const deactivateUser = Promise.resolve(Users.where({ UsersId: accountId }).save({
            Inactive: true
        }, { method: "update" }));

        Promise.all([deactivateSigner, deactivateUser]).then(() => {
            reply({
                isSuccess: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getDocumentExpireBySignerId(request, reply) {
        const { signerId } = request.query;

        const rawSql = `SELECT DISTINCT s.DocTypeID AS docTypeID, sd.DocType AS docType, s.ExpireDate AS expireDate, s.State AS state,
        ( CASE WHEN s.DocTypeID IS NULL THEN 1 
        WHEN s.ExpireDate < now() THEN 2
        WHEN s.ExpireDate < ADDDATE(now(), INTERVAL 7 day) AND s.ExpireDate > NOW() THEN 3
        ELSE 0 END) AS expire
                                        FROM signer_doctypes sd 
                                            LEFT JOIN signer_docs s on sd.DocTypeID = s.DocTypeId and s.SignerId = ${signerId}
                                        WHERE sd.DocTypeID IN (1, 5, 6, 7, 8, 9, 10 );`;

        Bookshelf.knex.raw(rawSql).then(async result => {
            if (result !== null && result !== undefined) {
                const docGoingExpire = [];
                const docNotUpload = [];
                const docExpire = [];
                await result[0].map(async item => {
                    const signerDoc = await {
                        docTypeID: item.docTypeID,
                        docType: `${item.docType} ${item.state ? `(${item.state})` : ""}`,
                        expireDate: item.expireDate,
                        expire: item.expire
                    };
                    switch (item.expire) {
                        case 1:
                            docNotUpload.push(signerDoc);
                            break;
                        case 2:
                            docExpire.push(signerDoc);
                            break;
                        case 3:
                            docGoingExpire.push(signerDoc);
                            break;
                    }
                });

                reply({
                    docExpire,
                    docGoingExpire,
                    docNotUpload
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}

export default new VendorDashboardController();