import Boom from "boom";
import Bookshelf from "../../db/database";
import SystemSettings from "../../db/model/system-settings";
import {
    replaceAll
} from "../../helper/common-helper";

class BonusCalculationController {
    constructor() {}

    getBonusCalculationData(request, reply) {
        const rawSql = `select UnitGoal, FillOutDeduction, ErrorDeduction, ErrorOutDeduction, MaximunGP, MaximunGPBonus from system_settings;`;
        const rawLoadGP = `select * from starting_bonus_configuration`;

        const getBonusCalculationData = Promise.resolve(Bookshelf.knex.raw(rawSql));
        const getGPData = Promise.resolve(Bookshelf.knex.raw(rawLoadGP));

        Promise.all([getBonusCalculationData, getGPData])
            .then((result) => {
                const data = {};
                if (result !== null) {
                    result.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.bonusCalculationData = item[0];
                                    break;
                                case 1:
                                    data.listGP = item[0];
                                    break;
                            }
                        }
                    });
                    reply(data);
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }

    updateBonusCalculationData(request, reply) {
        const {
            bonusCalculationData,
            listGP
        } = request.payload;

        const newbonusCalculationData = {
            UnitGoal: bonusCalculationData.UnitGoal,
            FillOutDeduction: replaceAll(bonusCalculationData.FillOutDeduction, "$", ""),
            ErrorDeduction: replaceAll(bonusCalculationData.ErrorDeduction, "$", ""),
            ErrorOutDeduction: replaceAll(bonusCalculationData.ErrorOutDeduction, "$", ""),
            MaximunGP: replaceAll(bonusCalculationData.MaximunGP, "$", ""),
            MaximunGPBonus: replaceAll(bonusCalculationData.MaximunGPBonus, "$", "")
        };

        SystemSettings.where({
            Id: 1
        }).save(newbonusCalculationData, {
            method: "update"
        }).then((result) => {
            if (result !== null) {
                if (listGP.length > 0) {
                    const rawDeleteSql = `DELETE FROM starting_bonus_configuration;`;
                    Bookshelf.knex.raw(rawDeleteSql)
                        .then(() => {
                            let inserSql = `insert into \`starting_bonus_configuration\` (\`GPFrom\`, \`GPTo\`, \`BonusPerOrder\`) values `;
                            for (let i = 0; i < listGP.length; i++) {
                                inserSql += `(${listGP[i].from},${listGP[i].to},${listGP[i].total})`;
                                if (i < listGP.length - 1) {
                                    inserSql += `, `;
                                } else {
                                    inserSql += `;`;
                                }
                            }

                            inserSql = replaceAll(inserSql, "$", "");

                            Bookshelf.knex.raw(inserSql)
                                .then(() => {
                                    reply({
                                        isSuccess: true
                                    });
                                }).catch((error) => {
                                    reply(Boom.badRequest(error));
                                });
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                } else {
                    reply({
                        isSuccess: true
                    });
                }

            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}
export default new BonusCalculationController();