use tce_dev;

DROP PROCEDURE IF EXISTS `alter_table_broker_fee`;

DELIMITER $$
CREATE PROCEDURE `alter_table_broker_fee` ()
BEGIN
	-- remove fee description id
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'broker_fee' AND 
                            COLUMN_NAME = 'FeeDescripId') THEN
	BEGIN
		ALTER TABLE `broker_fee` 
		DROP FOREIGN KEY `feedesid_broker_fee`;
		ALTER TABLE `broker_fee` 
        DROP INDEX `feedesid_broker_fee_idx`,
		DROP COLUMN `FeeDescripId`;
	END;
    END IF;
    
    -- add description
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'broker_fee' AND 
                            COLUMN_NAME = 'FeeDescription') THEN
	BEGIN
		ALTER TABLE `broker_fee`
		ADD COLUMN `FeeDescription` VARCHAR(100) NULL;
	END;
    END IF;
    
    -- add loan type
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'broker_fee' AND 
                            COLUMN_NAME = 'LoanTypeId') THEN
	BEGIN
		ALTER TABLE `broker_fee`
		ADD COLUMN `LoanTypeId` INT NULL,
		ADD INDEX `loantpyeId_broker_fee_idx` (`LoanTypeId` ASC);
        
		ALTER TABLE `broker_fee` 
		ADD CONSTRAINT `loantpyeId_broker_fee`
		  FOREIGN KEY (`LoanTypeId`)
		  REFERENCES `loan_type` (`LoanTypeId`)
		  ON DELETE NO ACTION
		  ON UPDATE NO ACTION;
	END;
    END IF;
    
    -- add product type
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'broker_fee' AND 
                            COLUMN_NAME = 'IsAdditionalFee') THEN
	BEGIN
		ALTER TABLE `broker_fee`
		ADD COLUMN `IsAdditionalFee` BIT NULL;
	END;
    END IF;
    
    -- this field is used to link to system fee
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'broker_fee' AND 
                            COLUMN_NAME = 'SystemFee') THEN
	BEGIN
		ALTER TABLE `broker_fee`
		ADD COLUMN `SystemFee` INT NULL;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_broker_fee();

DROP PROCEDURE IF EXISTS `alter_table_broker_fee`;





