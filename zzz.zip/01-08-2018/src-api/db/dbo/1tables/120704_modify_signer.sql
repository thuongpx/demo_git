DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	-- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'signer' AND 
                            COLUMN_NAME = 'OneYearNotSigningStatus') THEN
	BEGIN
		ALTER TABLE `signer`
        ADD COLUMN `OneYearNotSigningStatus` INT;
	END;
    END IF;
    
    -- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'signer' AND 
                            COLUMN_NAME = 'OneYearNotSigningTimeStamp') THEN
	BEGIN
		ALTER TABLE `signer`
        ADD COLUMN `OneYearNotSigningTimeStamp` DATETIME;
	END;
    END IF;
    
END$$

DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;