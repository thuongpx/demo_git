DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'client_services_config_log' AND 
                            COLUMN_NAME = 'OrderPerDay') THEN
	BEGIN
		ALTER TABLE `client_services_config_log` 
		MODIFY COLUMN `OrderPerDay` INT(11);
	END;
    END IF;    
END$$

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;