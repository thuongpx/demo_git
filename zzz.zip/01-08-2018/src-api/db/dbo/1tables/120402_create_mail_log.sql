CREATE TABLE IF NOT EXISTS `mail_log` (
  `MailId` INT NOT NULL AUTO_INCREMENT,
  `MailFrom` VARCHAR(100) NULL,
  `MailTo` VARCHAR(100) NULL,
  `MailContent` VARCHAR(20000) NULL,
  `MailHost` VARCHAR(45) NULL,
  `EmailPort` VARCHAR(4) NULL,
  `ErrorMessage` VARCHAR(200) NULL,
  `IsSuccess` BIT NULL,
  PRIMARY KEY (`MailId`));