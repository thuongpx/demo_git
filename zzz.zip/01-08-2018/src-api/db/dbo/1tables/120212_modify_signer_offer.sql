use tce_dev;

DELIMITER $$
CREATE PROCEDURE `alter_table_signer_offer` ()
BEGIN
	-- GUID: this field will display on offer link that is sent to vendor
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'signer_offer' AND 
                            COLUMN_NAME = 'GUID') THEN
	BEGIN
		ALTER TABLE `signer_offer` 
		ADD COLUMN `GUID` CHAR(36) NULL;
	END;
    END IF;
    
END$$

DELIMITER ;

call alter_table_signer_offer();

DROP PROCEDURE IF EXISTS `alter_table_signer_offer`;





