-- Request from KhanhLV
-- Remove FirstName
-- Remove LastName
-- Add FullName varchar(150)

ALTER TABLE `agent` 
DROP COLUMN `LastName`,
DROP COLUMN `FirstName`,
ADD COLUMN `FullName` VARCHAR(150) NULL