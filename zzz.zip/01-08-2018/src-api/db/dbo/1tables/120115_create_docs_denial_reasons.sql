CREATE TABLE IF NOT EXISTS `docs_denial_reasons` (
  `ReasonID` INT(11) NOT NULL AUTO_INCREMENT,
  `ReasonCode` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`ReasonID`)
)
