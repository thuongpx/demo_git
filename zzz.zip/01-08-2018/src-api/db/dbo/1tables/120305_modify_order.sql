use tce_dev;

DROP PROCEDURE IF EXISTS `alter_table_order`;

DELIMITER $$
CREATE PROCEDURE `alter_table_order` ()
BEGIN
	-- current stage
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order' AND 
                            COLUMN_NAME = 'CurrentStage') THEN
	BEGIN
		ALTER TABLE `order` ADD COLUMN `CurrentStage` SMALLINT NULL;
	END;
    END IF;
    
    -- current action
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order' AND 
                            COLUMN_NAME = 'CurrentAction') THEN
	BEGIN
        ALTER TABLE `order` ADD COLUMN `CurrentAction` SMALLINT NULL;
	END;
    END IF;
    
    -- last updated date
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order' AND 
                            COLUMN_NAME = 'LastUpdatedDate') THEN
	BEGIN
        ALTER TABLE `order` ADD COLUMN `LastUpdatedDate` DATETIME NULL;
	END;
    END IF;
    
    -- last updated by -- user id
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order' AND 
                            COLUMN_NAME = 'LastUpdatedBy') THEN
	BEGIN
        ALTER TABLE `order` ADD COLUMN `LastUpdatedBy` INT NULL;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_order();

DROP PROCEDURE IF EXISTS `alter_table_order`;





