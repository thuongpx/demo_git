import Boom from "boom";
import { paginate, generateCommonQuickBook, deleteCommonQuickBookFile, downloadCommonQuickBookFile, getCommonQuickBookFiles, getInvoiceReports, getInvoiceSpreadsheet, sendInvoiceEmail } from "../../helper/quickbook-helper";
import Bookshelf from "../../db/database";
import pdf from "html-pdf";
import moment from "moment";
class QuickbookInvoiceController {
    constructor() { }
    async exportQuickBook(request, reply) {
        const { fromDate, toDate, quickBookType, selectedItems } = request.payload;
        await generateCommonQuickBook(fromDate, toDate, quickBookType, selectedItems, (error) => {
            if (error === "no-records-found") {
                reply({ isNoRecordFound: true });
            } else if (error) reply(Boom.badRequest(error));
            else reply({ isSuccess: true });
        });
    }

    async getQuickBooks(request, reply) {
        const { quickBookType, page, itemPerPage, sortDirection, sortColumn } = request.payload;
        const files = await getCommonQuickBookFiles(quickBookType);

        reply({ data: paginate(files, itemPerPage, page, sortDirection, sortColumn), totalRecords: files.length });
    }

    deleteQuickBookInvoice(request, reply) {
        const { fileName, quickBookType } = request.payload;
        deleteCommonQuickBookFile(fileName, quickBookType, (error) => {
            if (error) reply(Boom.badRequest(error));
            else {
                reply({ isSuccess: true });
            }
        });
    }

    downloadQuickBookInvoice(request, reply) {
        const { fileName, quickBookType } = request.query;
        downloadCommonQuickBookFile(reply, fileName, quickBookType);
    }

    getInvoiceReports(request, reply) {
        const { brokerId, isIncludeBranchs, state, startMonth, endMonth, inYear } = request.payload;
        const startDate = `${inYear}-${startMonth}-01 00:00:00`;
        const startDateOfEndMonth = `${inYear}-${endMonth}-01 00:00:00`;
        const endDate = moment(startDateOfEndMonth).add(1, "months").add(-1, "days").format("YYYY-MM-DD HH:mm:ss");
        getInvoiceReports(brokerId, isIncludeBranchs, state, startDate, endDate, null, null, (data, error) => {
            if (error === "no-records-found") {
                reply({ isNoRecordFound: true });
            } else if (error) {
                reply(Boom.badRequest(error));
            } else {
                reply(data);
            }
        });
    }

    getVendorList(request, reply) {
        const rawSql = `SELECT CONCAT(sn.firstName,' ',sn.lastName,' - ',u.userName) as label, sn.signerId as value
        FROM signer sn
        LEFT JOIN users u on sn.signerId = u.mappingUserId
        LEFT JOIN user_roles ur on ur.usersId = u.usersId
        LEFT JOIN roles r on r.roleId = ur.roleId 
        WHERE r.RoleName = 'Vendor' and (sn.inactive is null or sn.inactive = 0)`;
        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                reply(result[0] || []);
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getBrokerList(request, reply) {
        const rawSql = `SELECT CASE WHEN CONCAT(br.company,' - ',br.city,' ',br.state,' ',br.zip) IS NULL THEN ''
		ELSE CONCAT(br.company,' - ',br.city,' ',br.state,' ',br.zip) END as label, br.brokerId as value
        FROM broker br
        WHERE (br.inactive is null or br.inactive = 0)`;
        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                reply(result[0] || []);
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    downloadInvoiceSpreadsheet(request, reply) {
        const { brokerId, isIncludeBranchs, state, startMonth, endMonth, inYear } = request.query;
        const startDate = `${inYear}-${startMonth}-01 00:00:00`;
        const startDateOfEndMonth = `${inYear}-${endMonth}-01 00:00:00`;
        const endDate = moment(startDateOfEndMonth).add(1, "months").add(-1, "days").format("YYYY-MM-DD HH:mm:ss");
        getInvoiceSpreadsheet(brokerId, isIncludeBranchs, state, startDate, endDate, null, (error, contentHtml) => {
            if (error) {
                reply(Boom.badRequest(error));
            } else {
                pdf.create(contentHtml).toStream((err, stream) => {
                    reply(stream);
                });
            }
        });
    }

    sendInvoiceEmail(request, reply) {
        const { orderId, brokerId, isIncludeBranchs, state, startDate, endDate, isGenerateSpreadSheet, isSelfService } = request.payload;
        console.log(request.payload);
        sendInvoiceEmail(brokerId, isIncludeBranchs, state, startDate, endDate, isGenerateSpreadSheet, orderId, isSelfService, (error) => {
            if (error === "no-records-found") {
                reply({ isNoRecordFound: true });
            } else if (error) {
                reply(Boom.badRequest(error));
            } else {
                reply({ isSuccess: true });
            }
        });
    }
}
export default new QuickbookInvoiceController();