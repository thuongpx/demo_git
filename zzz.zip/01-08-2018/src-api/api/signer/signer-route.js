import SignerController from "./signer-controller";
import SignerProfileController from "./signer-profile-controller";
import SignerMobileController from "./signer-mobile-controller";
const routes = [
    //get user address official
    {
        path: "/signer/getUserAddress",
        method: "GET",

        handler: SignerProfileController.getUserAddress
    },
    //get user address that waiting to admin approve
    {
        path: "/signer/getUserAddressPending",
        method: "GET",

        handler: SignerProfileController.getUserAddressPending
    },
    //set new user address then waiting to admin approve
    {
        path: "/signer/updateUserAddressPending",
        method: "POST",
        handler: SignerProfileController.updateUserAddressPending
    },
    //get signer by signerId
    {
        path: "/signer/getSignerFullNameById",
        method: "GET",
        handler: SignerController.getSignerFullNameById
    },
    //get signer full name by signerId
    {
        path: "/signer/getSignerById",
        method: "GET",
        config: {
            auth: false
        },
        handler: SignerController.getSignerById
    },
    //get signer username by signerId
    {
        path: "/signer/getSignerUserNameById",
        method: "GET",
        handler: SignerController.getSignerUserNameById
    },
    // get signer registration step
    {
        path: "/signer/getIsVendorRegistrationDone",
        method: "GET",
        handler: SignerController.getIsVendorRegistrationDone
    },
    {
        path: "/signer/getSignerLocationDataById",
        method: "GET",
        config: {
            auth: false
        },
        handler: SignerController.getSignerLocationDataById
    },
    {
        path: "/signer/getSignerPhoneDataById",
        method: "GET",
        config: {
            auth: false
        },
        handler: SignerController.getSignerPhoneDataById
    },
    {
        path: "/signer/addSigner",
        method: "POST",
        handler: SignerController.addSigner
    },
    {
        path: "/signer/updateSigner",
        method: "POST",
        config: {
            auth: false
        },
        handler: SignerController.updateSigner
    },
    //get init for tab questionaires
    {
        path: "/signer/getInitSignerQuestionaires",
        method: "GET",
        config: {
            auth: false
        },
        handler: SignerController.getInitSignerQuestionaires
    },
    //get User Additional Info
    {
        path: "/signer/getUserAdditionalInfo",
        method: "GET",
        handler: SignerProfileController.getUserAdditionalInfo
    },
    //set new user additional info
    {
        path: "/signer/updateUserAdditionalInfo",
        method: "POST",
        handler: SignerProfileController.updateUserAdditionalInfo
    },
    //get Signer data for Service information tab
    {
        path: "/signer/getSignerServiceDataById",
        method: "GET",
        config: {
            auth: false
        },
        handler: SignerController.getSignerServiceDataById
    },
    //set new user additional info list
    {
        path: "/signer/getUserAdditionalInfoList",
        method: "GET",
        handler: SignerProfileController.getUserAdditionalInfoList
    },
    {
        path: "/signer/saveSignerProfilePicture",
        method: "POST",
        handler: SignerController.saveSignerProfilePicture
    },
    {
        path: "/signer/updateQuestionnaires",
        method: "POST",
        config: {
            auth: false
        },
        handler: SignerController.updateQuestionnaires
    },
    {
        path: "/signer/getTotalOpenOfferOfSigner",
        method: "GET",
        handler: SignerController.getTotalOpenOfferOfSigner
    }, {
        path: "/mobile/signer/getSignersPerformanceRatingsStats",
        method: "GET",
        handler: SignerMobileController.getSignersPerformanceRatingsStats
    }, {
        path: "/mobile/signer/getSignersAttentions",
        method: "GET",
        handler: SignerMobileController.getSignersAttentions
    },
    {
        path: "/mobile/signer/getVendorNotifications",
        method: "GET",
        handler: SignerController.mobileGetVendorNotifications
    },
    {
        path: "/signer/getStaffVendors",
        method: "POST",
        handler: SignerController.getStaffVendors
    },
    {
        path: "/signer/getAllVendorManagement",
        method: "GET",
        handler: SignerController.getAllVendorManagement
    },
    {
        path: "/signer/activeVendor",
        method: "POST",
        handler: SignerController.activeVendor
    },
    {
        path: "/signer/getVendorOrders",
        method: "GET",
        handler: SignerController.getVendorOrders
    },
    {
        path: "/signer/deactivateVendor",
        method: "POST",
        handler: SignerController.deactivateVendor
    },
    {
        path: "/signer/checkSignerAssignedOpenOrder",
        method: "GET",
        handler: SignerController.checkSignerAssignedOpenOrder
    },
    {
        path: "/signer/addVendor",
        method: "POST",
        handler: SignerController.addNewVendor
    },
    {
        path: "/signer/getVendorRegisterPrograms",
        method: "GET",
        handler: SignerProfileController.getVendorRegisterPrograms
    },
    {
        path: "/signer/getCourseTestList",
        method: "GET",
        handler: SignerProfileController.getCourseTestList
    },
    {
        path: "/signer/getAllDataDocs",
        method: "GET",
        handler: SignerController.getAllDataDocs
    },
    {
        path: "/signer/confirmDocs",
        method: "POST",
        handler: SignerController.confirmDocs
    },
    {
        path: "/signer/getAppointmentDetailsData",
        method: "GET",
        handler: SignerController.getAppointmentDetailsData
    },
    {
        path: "/signer/updateAppointment",
        method: "POST",
        handler: SignerController.updateAppointment
    },
    {
        path: "/signer/confirmAppointment",
        method: "POST",
        handler: SignerController.confirmAppointment
    },
    {
        path: "/signer/getSigningAndPropertyAddressData",
        method: "GET",
        handler: SignerController.getSigningAndPropertyAddressData
    },
    {
        path: "/signer/getShippingInfoData",
        method: "GET",
        handler: SignerController.getShippingInfoData
    },
    {
        path: "/signer/resetVendorPassword",
        method: "POST",
        handler: SignerController.resetVendorPassword
    },
    {
        path: "/signer/getSignerBasicInformation",
        method: "POST",
        handler: SignerController.getSignerBasicInformation
    },
    {
        path: "/signer/updateSignerBasicInformation",
        method: "POST",
        handler: SignerController.updateSignerBasicInformation
    },
    {
        path: "/signer/revalidateAuthentication",
        method: "POST",
        handler: SignerController.revalidateAuthentication
    },
    {
        path: "/signer/getSignerAdditionalInformation",
        method: "GET",
        handler: SignerController.getSignerAdditionalInformation
    },
    {
        path: "/signer/getSignerAdditionalInforRecentOrders",
        method: "GET",
        handler: SignerController.getSignerAdditionalInforRecentOrders
    },
    {
        path: "/signer/getSignerAdditionalInformationModal",
        method: "GET",
        handler: SignerController.getSignerAdditionalInformationModal
    },
    {
        path: "/signer/updateSignerAdditionalInformation",
        method: "POST",
        handler: SignerController.updateSignerAdditionalInformation
    },
    {
        path: "/signer/getListVendorByNameOrEmail",
        method: "GET",
        handler: SignerController.getListVendorByNameOrEmail
    },
    {
        path: "/signer/getTotalVendorPoolForClientOrderAssignConfig",
        method: "POST",
        handler: SignerController.getTotalVendorPoolForClientOrderAssignConfig
    },
    {
        path: "/signer/getOrderRatingBySignerId",
        method: "GET",
        handler: SignerController.getOrderRatingBySignerId
    },
    {
        path: "/signer/getVendorNotifications",
        method: "GET",
        handler: SignerProfileController.getVendorNotifications
    },
    {
        path: "/signer/updateSignerAddress",
        method: "POST",
        handler: SignerController.updateSignerAddress
    },
    {
        path: "/signer/getDataAssignVendor",
        method: "GET",
        handler: SignerController.getDataAssignVendor
    },
    {
        path: "/signer/calculateSignerRating",
        method: "POST",
        handler: SignerController.calculateSignerRating
    },
    {
        path: "/signer/checkTceValidation",
        method: "POST",
        handler: SignerController.checkTceValidation
    },
    {
        path: "/signer/getSignerCertificateById",
        method: "GET",
        handler: SignerController.getSignerCertificateById
    }
];


export default routes;