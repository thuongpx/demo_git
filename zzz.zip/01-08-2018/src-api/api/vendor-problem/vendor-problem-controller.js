import Boom from "boom";
import Bookshelf from "../../db/database";
import moment from "moment";
import { handleSingleQuote } from "../../helper/common-helper";
import { COMMENT_TYPE } from "../../constant/common-constant";

class VendorProblemController {
    getVendorProblems(request, reply) {
        const { orderId, status, problemType, fromDate, toDate, itemPerPage, page, sortColumn, sortDirection } = request.query;
        const newfromDate = (fromDate === "" || fromDate === undefined || fromDate === null || fromDate === "Invalid date") ? "" : moment(fromDate).utc().format("YYYY-MM-DD HH:mm:ss").toString();
        const newtoDate = (toDate === "" || toDate === undefined || toDate === null || toDate === "Invalid date") ? "" : moment(toDate).add(1, "days").utc().format("YYYY-MM-DD HH:mm:ss").toString();

        const rawSql = `call GetOrderIssuesByVendorFilters(
            ${(orderId === undefined || orderId === "") ? null : `${!isNaN((orderId)) ? parseInt(orderId) : -1}`},
            ${(status === undefined || status === "") ? null : `${!isNaN((status)) ? parseInt(status) : -1}`},
            ${(problemType === undefined || problemType === "") ? null : `${!isNaN((problemType)) ? parseInt(problemType) : -1}`},
            '${newfromDate}',
            '${newtoDate}',
            ${(sortColumn === undefined || sortColumn === "") ? null : `'${handleSingleQuote(sortColumn)}'`},
            ${handleSingleQuote(sortDirection)},
            ${!isNaN((page)) ? parseInt(page) : 1},
            ${!isNaN((itemPerPage)) ? parseInt(itemPerPage) : 50})
        `;
        Bookshelf.knex.raw(rawSql).then((result) => {
            reply({ data: result[0][0], totalRecord: result[0][1][0].TotalRecords });
        }).catch(error => reply(Boom.badRequest(error)));
        return;
    }

    //
    getAllVendorProblems(request, reply) {
        const { description, orderId, duration, status, itemPerPage, page, sortColumn, sortDirection } = request.query;
        const rawSql = `call GetAllOrderIssuesByVendor(
            ${(description === undefined || description === "") ? null : `'${handleSingleQuote(description)}'`},
            ${(orderId === undefined || orderId === "") ? null : `${!isNaN((orderId)) ? parseInt(orderId) : -1}`},
            ${(duration === undefined || duration === "") ? null : `${parseInt(duration)}`},
            ${(status === undefined || status === "") ? null : `${!isNaN((status)) ? parseInt(status) : -1}`},
            ${(sortColumn === undefined || sortColumn === "") ? null : `'${handleSingleQuote(sortColumn)}'`},
            ${handleSingleQuote(sortDirection)},
            ${!isNaN((page)) ? parseInt(page) : 1},
            ${!isNaN((itemPerPage)) ? parseInt(itemPerPage) : 50})
        `;
        Bookshelf.knex.raw(rawSql).then((result) => {
            reply({ data: result[0][0], totalRecord: result[0][1][0].TotalRecords });
        }).catch(error => reply(Boom.badRequest(error)));
        return;
    }

    getProblemDetail(request, reply) {
        const { id } = request.query;
        const rawSql = `SELECT op.OrderId, op.ProblemID,
            op.Notes as Description, op.Date,
            op.SubType, op.RepId,
            op.ApprovedDate, op.Mistake,
            GetFullNameByUserId(op.EnteredBy) as CreatedBy,
            SignerUser.UserName as Vendor,
            RepUser.UserName as Rep,
            ResolvedUser.UserName as ResolvedBy,
            ApprovedUser.UserName as ApprovedBy,
            problem_status.Description as Status,
            problem_types.Description as ProblemType, pt2.Description as ProblemSubType
            FROM order_problem as op
            LEFT JOIN \`order\` ON (op.OrderId=\`order\`.OrderId)
            LEFT JOIN users as SignerUser ON (\`order\`.SignerId=SignerUser.UsersId)
            LEFT JOIN users as RepUser ON (op.RepId=RepUser.UsersId)
            LEFT JOIN users as ResolvedUser ON (op.ResolvedBy=ResolvedUser.UsersId)
            LEFT JOIN users as ApprovedUser ON (op.ApprovedBy=ApprovedUser.UsersId)
            LEFT JOIN problem_status ON (op.Status=problem_status.id)
            LEFT JOIN problem_types ON (op.Type=problem_types.Id)
            LEFT JOIN problem_types as pt2 ON (op.SubType=pt2.Id)
            WHERE ProblemId = ${id}
        `;
        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result) {
                const commentSQL = `SELECT C.CreatedDate, C.Description, users.UserName
                    FROM comment as C 
                    LEFT JOIN users ON (users.UsersId=C.CreatedBy)
                    WHERE OwnerID = ${result[0][0].OrderId} AND TypeID = ${COMMENT_TYPE.OrderIssueCommentType}
                `;
                Bookshelf.knex.raw(commentSQL).then(cmResult => {
                    reply({
                        problemDetail: result[0][0],
                        comments: cmResult[0]
                    });
                });
            }
        }).catch(error => reply(Boom.badRequest(error)));
        return;
    }

    getProblemStatus(request, reply) {
        const rawSql = `SELECT * FROM problem_status
            ORDER BY Id
        `;
        Bookshelf.knex.raw(rawSql).then((result) => {
            reply({ problemStatuses: result[0] });
        }).catch(error => reply(Boom.badRequest(error)));
        return;
    }

    initVendorProblemSearch(request, reply) {

        const rawSqlStatus = `SELECT * FROM problem_status ORDER BY Id`;
        const rawSqlTypes = `SELECT * FROM problem_types ORDER BY Id`;

        const getProblemStatus = new Promise((resolve, reject) => {
            Bookshelf.knex.raw(rawSqlStatus).then((result) => {
                resolve(result[0]);
            }).catch(() => { reject(); });
        });
        const getProblemTypes = new Promise((resolve, reject) => {
            Bookshelf.knex.raw(rawSqlTypes).then((result) => {
                resolve(result[0]);
            }).catch(() => { reject(); });
        });

        Promise.all([
            getProblemStatus,
            getProblemTypes
        ]).then((values) => {
            const data = {};

            if (values !== null) {
                values.forEach((item, index) => {
                    if (item !== null) {
                        switch (index) {
                            case 0:
                                data.problemStatuses = item;
                                break;
                            case 1:
                                data.problemTypes = item;
                                break;
                        }
                    }
                });

                reply(data);
            } else {
                reply(Boom.badRequest({
                    message: "Error!"
                }));
            }
        });
        return;
    }

}

export default new VendorProblemController();