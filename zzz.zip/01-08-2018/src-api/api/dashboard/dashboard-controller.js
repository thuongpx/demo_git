import Boom from "boom";
import Bookshelf from "./../../db/database";

class DashboardController {
    constructor() { }

    getSLADashboard(request, reply) {
        const {
            clientId
        } = request.query;
        const getBrokerSLAs = new Promise((resolve, reject) => {
            const sql = `SELECT sla.SLA, CASE WHEN sla.From IS NOT NULL THEN sla.From ELSE sla.DefaultFrom END AS \`From\`, CASE WHEN sla.To IS NOT NULL THEN sla.To ELSE sla.DefaultTo END AS \`To\`  FROM \`broker_slas\` sla
                        WHERE sla.BrokerId = ${clientId}`;

            Bookshelf.knex.raw(sql)
                .then(data => {
                    if (data) resolve(data[0]);
                    else resolve({});
                })
                .catch(err => reject(err));
        });
        const getSLAs = new Promise((resolve, reject) => {
            const sql = `SELECT sla.SLA, CASE WHEN sla.From IS NOT NULL THEN sla.From ELSE sla.DefaultFrom END AS \`From\`, CASE WHEN sla.To IS NOT NULL THEN sla.To ELSE sla.DefaultTo END AS \`To\`  FROM \`slas\` sla`;

            Bookshelf.knex.raw(sql)
                .then(data => {
                    if (data) resolve(data[0]);
                    else resolve({});
                })
                .catch(err => reject(err));
        });

        Promise.all([
            getBrokerSLAs,
            getSLAs
        ]).then((values) => {
            const data = {};

            if (values !== null) {
                values.forEach((item, index) => {
                    if (item !== null) {
                        switch (index) {
                            case 0:
                                data.SLA_Broker = item;
                                break;
                            case 1:
                                data.SLA = item;
                                break;
                        }
                    }
                });
                reply(data);
            } else {
                reply(Boom.badRequest({
                    message: "Error!"
                }));
            }
        });
    }

    getOrdersInfoDashboard(request, reply) {
        const {
            role,
            id,
            timeZone
        } = request.query;
        const rawSqlFaxbacksOrder = `call GetOrdersInfoDashboard('${role}',${id},${timeZone})`;

        Bookshelf.knex.raw(rawSqlFaxbacksOrder)
            .then((result) => {
                if (result !== null) {
                    if (role.includes("Admin") || role.includes("Operational Manager") || role.includes("Quality Control") || role.includes("Scheduler") || role.includes("Status Rep") || role.includes("Training Manager")) {
                        reply({
                            AllService: {
                                //Open
                                OpenFullService: result[0][0][0].OpenFullService,
                                OpenSLAApproachingFullService: result[0][1][0].OpenSLAApproachingFullService,
                                OpenSLAOutOfFullService: result[0][2][0].OpenSLAOutOfFullService,
                                //Assigned
                                UnconfirmedFullService: result[0][3][0].UnconfirmedFullService,
                                UnconfirmedSLAApproachingFullService: result[0][4][0].UnconfirmedSLAApproachingFullService,
                                UnconfirmedSLAOutOfFullService: result[0][5][0].UnconfirmedSLAOutOfFullService,
                                PendingDocsFullService: result[0][6][0].PendingDocsFullService,
                                PendingDocsSLAApproachingFullService: result[0][7][0].PendingDocsSLAApproachingFullService,
                                PendingDocsSLAOutOfFullService: result[0][8][0].PendingDocsSLAOutOfFullService,
                                NeedingPreCallFullService: result[0][9][0].NeedingPreCallFullService,
                                NeedingPreCallSLAApproachingFullService: result[0][10][0].NeedingPreCallSLAApproachingFullService,
                                NeedingPreCallSLAOutOfFullService: result[0][11][0].NeedingPreCallSLAOutOfFullService,
                                //ApptReady
                                ApptReadyFullService: result[0][12][0].ApptReadyFullService,
                                ApptReadySLAApproachingFullService: result[0][13][0].ApptReadySLAApproachingFullService,
                                ApptReadySLAOutOfFullService: result[0][14][0].ApptReadySLAOutOfFullService,
                                PendingReviewPCFullService: result[0][15][0].PendingReviewPCFullService,
                                PendingReviewPCSLAApproachingFullService: result[0][16][0].PendingReviewPCSLAApproachingFullService,
                                PendingReviewPCSLAOutOfFullService: result[0][17][0].PendingReviewPCSLAOutOfFullService,
                                AwaitingScanbacksFullService: result[0][18][0].AwaitingScanbacksFullService,
                                PendingQCReviewFullService: result[0][19][0].PendingQCReviewFullService,
                                PendingQCReviewSLAApproachingFullService: result[0][20][0].PendingQCReviewSLAApproachingFullService,
                                PendingQCReviewSLAOutOfFullService: result[0][21][0].PendingQCReviewSLAOutOfFullService,
                                //Closing Complete
                                ClosedMTDFullService: result[0][22][0].ClosedMTDFullService,
                                PostCloseIssueFullService: result[0][23][0].PostCloseIssueFullService,
                                PostCloseIssueSLAApproachingFullService: result[0][24][0].PostCloseIssueSLAApproachingFullService,
                                PostCloseIssueSLAOutOfFullService: result[0][25][0].PostCloseIssueSLAOutOfFullService,
                                //Did not close
                                CanceledByClientMTDFullService: result[0][26][0].CanceledByClientMTDFullService,
                                UnsuccessfulMTDFullService: result[0][27][0].UnsuccessfulMTDFullService,
                                PlacedOnHoldMTDFullService: result[0][28][0].PlacedOnHoldMTDFullService
                            }
                        });
                    } else {
                        reply({
                            //self service
                            SelfService: {
                                //Open
                                OpenSelfService: result[0][0][0].OpenSelfService,
                                OpenSLAApproachingSelfService: result[0][1][0].OpenSLAApproachingSelfService,
                                OpenSLAOutOfSelfService: result[0][2][0].OpenSLAOutOfSelfService,
                                //Assigned
                                UnconfirmedSelfService: result[0][3][0].UnconfirmedSelfService,
                                UnconfirmedSLAApproachingSelfService: result[0][4][0].UnconfirmedSLAApproachingSelfService,
                                UnconfirmedSLAOutOfSelfService: result[0][5][0].UnconfirmedSLAOutOfSelfService,
                                PendingDocsSelfService: result[0][6][0].PendingDocsSelfService,
                                PendingDocsSLAApproachingSelfService: result[0][7][0].PendingDocsSLAApproachingSelfService,
                                PendingDocsSLAOutOfSelfService: result[0][8][0].PendingDocsSLAOutOfSelfService,
                                NeedingPreCallSelfService: result[0][9][0].NeedingPreCallSelfService,
                                NeedingPreCallSLAApproachingSelfService: result[0][10][0].NeedingPreCallSLAApproachingSelfService,
                                NeedingPreCallSLAOutOfSelfService: result[0][11][0].NeedingPreCallSLAOutOfSelfService,
                                //ApptReady
                                ApptReadySelfService: result[0][12][0].ApptReadySelfService,
                                ApptReadySLAApproachingSelfService: result[0][13][0].ApptReadySLAApproachingSelfService,
                                ApptReadySLAOutOfSelfService: result[0][14][0].ApptReadySLAOutOfSelfService,
                                //Closed pending
                                PendingReviewPCSelfService: result[0][15][0].PendingReviewPCSelfService,
                                PendingReviewPCSLAApproachingSelfService: result[0][16][0].PendingReviewPCSLAApproachingSelfService,
                                PendingReviewPCSLAOutOfSelfService: result[0][17][0].PendingReviewPCSLAOutOfSelfService,
                                AwaitingScanbacksSelfService: result[0][18][0].AwaitingScanbacksSelfService,
                                PendingQCReviewSelfService: result[0][19][0].PendingQCReviewSelfService,
                                PendingQCReviewSLAApproachingSelfService: result[0][20][0].PendingQCReviewSLAApproachingSelfService,
                                PendingQCReviewSLAOutOfSelfService: result[0][21][0].PendingQCReviewSLAOutOfSelfService,
                                //Closing Complete
                                ClosedMTDSelfService: result[0][22][0].ClosedMTDSelfService,
                                PostCloseIssueSelfService: result[0][23][0].PostCloseIssueSelfService,
                                PostCloseIssueSLAApproachingSelfService: result[0][24][0].PostCloseIssueSLAApproachingSelfService,
                                PostCloseIssueSLAOutOfSelfService: result[0][25][0].PostCloseIssueSLAOutOfSelfService,
                                //Did not close
                                CanceledByClientMTDSelfService: result[0][26][0].CanceledByClientMTDSelfService,
                                UnsuccessfulMTDSelfService: result[0][27][0].UnsuccessfulMTDSelfService,
                                PlacedOnHoldMTDSelfService: result[0][28][0].PlacedOnHoldMTDSelfService
                            },
                            //full service
                            FullService: {
                                //Open
                                OpenFullService: result[0][29][0].OpenFullService,
                                OpenSLAApproachingFullService: result[0][30][0].OpenSLAApproachingFullService,
                                OpenSLAOutOfFullService: result[0][31][0].OpenSLAOutOfFullService,
                                //Assigned
                                UnconfirmedFullService: result[0][32][0].UnconfirmedFullService,
                                UnconfirmedSLAApproachingFullService: result[0][33][0].UnconfirmedSLAApproachingFullService,
                                UnconfirmedSLAOutOfFullService: result[0][34][0].UnconfirmedSLAOutOfFullService,
                                PendingDocsFullService: result[0][35][0].PendingDocsFullService,
                                PendingDocsSLAApproachingFullService: result[0][36][0].PendingDocsSLAApproachingFullService,
                                PendingDocsSLAOutOfFullService: result[0][37][0].PendingDocsSLAOutOfFullService,
                                NeedingPreCallFullService: result[0][38][0].NeedingPreCallFullService,
                                NeedingPreCallSLAApproachingFullService: result[0][39][0].NeedingPreCallSLAApproachingFullService,
                                NeedingPreCallSLAOutOfFullService: result[0][40][0].NeedingPreCallSLAOutOfFullService,
                                //ApptReady
                                ApptReadyFullService: result[0][41][0].ApptReadyFullService,
                                ApptReadySLAApproachingFullService: result[0][42][0].ApptReadySLAApproachingFullService,
                                ApptReadySLAOutOfFullService: result[0][43][0].ApptReadySLAOutOfFullService,
                                PendingReviewPCFullService: result[0][44][0].PendingReviewPCFullService,
                                PendingReviewPCSLAApproachingFullService: result[0][45][0].PendingReviewPCSLAApproachingFullService,
                                PendingReviewPCSLAOutOfFullService: result[0][46][0].PendingReviewPCSLAOutOfFullService,
                                AwaitingScanbacksFullService: result[0][47][0].AwaitingScanbacksFullService,
                                PendingQCReviewFullService: result[0][48][0].PendingQCReviewFullService,
                                PendingQCReviewSLAApproachingFullService: result[0][49][0].PendingQCReviewSLAApproachingFullService,
                                PendingQCReviewSLAOutOfFullService: result[0][50][0].PendingQCReviewSLAOutOfFullService,
                                //Closing Complete
                                ClosedMTDFullService: result[0][51][0].ClosedMTDFullService,
                                PostCloseIssueFullService: result[0][52][0].PostCloseIssueFullService,
                                PostCloseIssueSLAApproachingFullService: result[0][53][0].PostCloseIssueSLAApproachingFullService,
                                PostCloseIssueSLAOutOfFullService: result[0][54][0].PostCloseIssueSLAOutOfFullService,
                                //Did not close
                                CanceledByClientMTDFullService: result[0][55][0].CanceledByClientMTDFullService,
                                UnsuccessfulMTDFullService: result[0][56][0].UnsuccessfulMTDFullService,
                                PlacedOnHoldMTDFullService: result[0][57][0].PlacedOnHoldMTDFullService
                            }
                        });
                    }
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getOrdersInfoSchedulerDashboard(request, reply) {
        const {
            employeeId,
            timeZone
        } = request.query;
        const rawSqlFaxbacksOrder = `call GetOrdersInfoSchedulerDashboard(${employeeId},${timeZone})`;

        Bookshelf.knex.raw(rawSqlFaxbacksOrder)
            .then((result) => {
                if (result !== null) {
                    reply({
                        TotalOrders: result[0][0][0].TotalOrders,
                        EligibleOrders: result[0][1][0].EligibleOrders,
                        TotalErrors: result[0][2][0].TotalErrors,
                        FillOutOfSLA: result[0][3][0].FillOutOfSLA,
                        ErrorsOutOfSLA: result[0][4][0].ErrorsOutOfSLA,
                        StartingBonus: result[0][5][0].StartingBonus,
                        UnitGoal: result[0][6][0].UnitGoal,
                        FillOutDeduction: result[0][6][0].FillOutDeduction
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getOrdersInfoDetailDashboard(request, reply) {
        const {
            role,
            id,
            service,
            statusGroup,
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            timeZone
        } = request.query;
        const rawSqlOrders = `call GetOrdersInfoDetailDashboard('${role}',${id}, '${service}', '${statusGroup}',
        '${sortColumn}',${sortDirection},${page},${itemPerPage},${timeZone})`;

        Bookshelf.knex.raw(rawSqlOrders)
            .then((result) => {
                if (result !== null) {
                    //Open
                    if (statusGroup === "OpenAll") {
                        reply({
                            OpenOrders: result[0][0],
                            OpenOrdersTotal: result[0][1][0].TotalRecords,
                            OpenOrdersSLAApproaching: result[0][2],
                            OpenOrdersSLAApproachingTotal: result[0][3][0].TotalRecords,
                            OpenOrdersSLAOutOf: result[0][4],
                            OpenOrdersSLAOutOfTotal: result[0][5][0].TotalRecords
                        });
                    }
                    if (statusGroup === "Open") {
                        reply({
                            OpenOrders: result[0][0],
                            OpenOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                    if (statusGroup === "OpenSLAApproaching") {
                        reply({
                            OpenOrdersSLAApproaching: result[0][0],
                            OpenOrdersSLAApproachingTotal: result[0][1][0].TotalRecords
                        });
                    }
                    if (statusGroup === "OpenSLAOutOf") {
                        reply({
                            OpenOrdersSLAOutOf: result[0][0],
                            OpenOrdersSLAOutOfTotal: result[0][1][0].TotalRecords
                        });
                    }
                    //Assigned
                    if (statusGroup === "Assigned") {
                        reply({
                            UnconfirmedOrders: result[0][0],
                            UnconfirmedOrdersTotal: result[0][1][0].TotalRecords,
                            PendingDocsOrders: result[0][2],
                            PendingDocsOrdersTotal: result[0][3][0].TotalRecords,
                            NeedingPreCallOrders: result[0][4],
                            NeedingPreCallOrdersTotal: result[0][5][0].TotalRecords
                        });
                    }
                    if (statusGroup === "Unconfirmed") {
                        reply({
                            UnconfirmedOrders: result[0][0],
                            UnconfirmedOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                    if (statusGroup === "Pending Docs") {
                        reply({
                            PendingDocsOrders: result[0][0],
                            PendingDocsOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                    if (statusGroup === "Needing Pre-call") {
                        reply({
                            NeedingPreCallOrders: result[0][0],
                            NeedingPreCallOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                    //Appt Ready
                    if (statusGroup === "Appt Ready") {
                        reply({
                            ApptReadyOrders: result[0][0],
                            ApptReadyOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                    //Closed Pending
                    if (statusGroup === "Closed Pending") {
                        reply({
                            PendingReviewPCOrders: result[0][0],
                            PendingReviewPCOrdersTotal: result[0][1][0].TotalRecords,
                            AwaitingScanbacksOrders: result[0][2],
                            AwaitingScanbacksOrdersTotal: result[0][3][0].TotalRecords,
                            PendingQCReviewOrders: result[0][4],
                            PendingQCReviewOrdersTotal: result[0][5][0].TotalRecords
                        });
                    }
                    if (statusGroup === "PendingReviewPC") {
                        reply({
                            PendingReviewPCOrders: result[0][0],
                            PendingReviewPCOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                    if (statusGroup === "AwaitingScanbacks") {
                        reply({
                            AwaitingScanbacksOrders: result[0][0],
                            AwaitingScanbacksOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                    if (statusGroup === "PendingQCReview") {
                        reply({
                            PendingQCReviewOrders: result[0][0],
                            PendingQCReviewOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                    //Closing Complete
                    if (statusGroup === "Closing Complete") {
                        reply({
                            ClosedMTDOrders: result[0][0],
                            ClosedMTDOrdersTotal: result[0][1][0].TotalRecords,
                            PostCloseIssueOrders: result[0][2],
                            PostCloseIssueOrdersTotal: result[0][3][0].TotalRecords
                        });
                    }
                    if (statusGroup === "Closed MTD") {
                        reply({
                            ClosedMTDOrders: result[0][0],
                            ClosedMTDOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                    if (statusGroup === "Post Close Issue") {
                        reply({
                            PostCloseIssueOrders: result[0][0],
                            PostCloseIssueOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                    //Did Not Close
                    if (statusGroup === "Did Not Close") {
                        reply({
                            CanceledByClientOrders: result[0][0],
                            CanceledByClientOrdersTotal: result[0][1][0].TotalRecords,
                            UnsuccessfulOrders: result[0][2],
                            UnsuccessfulOrdersTotal: result[0][3][0].TotalRecords,
                            PlacedOnHoldOrders: result[0][4],
                            PlacedOnHoldOrdersTotal: result[0][5][0].TotalRecords
                        });
                    }
                    if (statusGroup === "Canceled By Client") {
                        reply({
                            CanceledByClientOrders: result[0][0],
                            CanceledByClientOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                    if (statusGroup === "Unsuccessful") {
                        reply({
                            UnsuccessfulOrders: result[0][0],
                            UnsuccessfulOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                    if (statusGroup === "Placed On Hold") {
                        reply({
                            PlacedOnHoldOrders: result[0][0],
                            PlacedOnHoldOrdersTotal: result[0][1][0].TotalRecords
                        });
                    }
                } else {
                    reply({
                        isSuccess: false
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
}

export default new DashboardController();