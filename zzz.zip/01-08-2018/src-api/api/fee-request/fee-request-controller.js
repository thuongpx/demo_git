import Boom from "boom";
import Bookshelf from "../../db/database";
import { handleSingleQuote } from "../../helper/common-helper";

class GetFeeRequest {
    constructor() { }

    // Get fee request which CE Schedulers/ Status Representatives are responsible
    getFeeRequest(request, reply) {
        const { sortColumn, sortDirection, page, itemPerPage, orderId, feeApproved, repId, statusId, qCId } = request.query;
        const rawQuery = `call GetFeeRequest('${sortColumn}', 
            ${sortDirection === "true" ? 1 : 0}, 
            ${page}, 
            ${itemPerPage},
            ${repId !== undefined && repId !== "" ? handleSingleQuote(repId) : null},
            ${statusId !== undefined && statusId !== "" ? handleSingleQuote(statusId) : null},
            ${qCId !== undefined && qCId !== "" ? handleSingleQuote(qCId) : null},
            ${orderId !== undefined && orderId !== "" ? handleSingleQuote(orderId) : null},
            ${feeApproved ? `'${feeApproved}'` : null})`;

        Bookshelf.knex.raw(rawQuery)
            .then(result => {
                if (result === null || !result[0] || !result[0][0]) {
                    reply({ isSuccess: false });
                    return;
                }

                const datasources = result[0][0];
                const totalRecords = result[0][1][0];

                reply({ isSuccess: true, datasources, totalRecords: totalRecords.TotalRecords });
                return;
            }).catch(err => {
                reply(Boom.badRequest(err));
                return;
            });
    }
}

export default new GetFeeRequest();