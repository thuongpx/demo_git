const fs = require("fs");

import Boom from "boom";

import {
	distinctSingleValueArray,
	bufferToBoolean
} from "../../helper/common-helper";
import {
	getOrderTypes,
	getAgents,
	getScheduler,
	buildSqlQuery
} from "./canned-report";
//
import ManualReportTemplate from "../../db/model/manual-report-templates";
import moment from "moment";
import Bookshelf from "../../db/database";
import { exportExcelFile } from "../../helper/excel-helper";

class CannedReportController {
	constructor() { }

	async getInitDataForCannedReport(request, reply) {
		// get order types list
		const orderTypes = await getOrderTypes();
		const agents = await getAgents();
		const schedulers = await getScheduler();

		reply({
			orderTypes: distinctSingleValueArray(orderTypes.map(i => i.LoanType)),
			agents: distinctSingleValueArray(agents.map(item => ({
				value: item.AgentId,
				label: item.Agents
			}))),
			schedulers: distinctSingleValueArray(schedulers.map(item => ({
				value: item.RepId,
				label: item.Scheduler
			})))
		});
	}

	addTemplateReport(request, reply) {
		const {
			reportName,
			searchBy,
			fromDate,
			toDate,
			searchAll,
			vendorStatus,
			columns
		} = request.payload;

		const reportObj = {
			ReportName: reportName,
			SearchBy: searchBy,
			FromDate: moment(fromDate).format("YYYY/MM/DD"),
			ToDate: moment(toDate).format("YYYY/MM/DD"),
			SearchAll: searchAll,
			VendorStatus: vendorStatus,
			Columns: columns
		};
		new ManualReportTemplate().save(
			reportObj, {
				method: "insert"
			}).then((result) => {
				if (result !== null) {
					const data = result.attributes;
					const reportId = data.id;
					reply({
						reportId,
						isSuccess: true
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));

			});
	}

	deleteTemplateReport(request, reply) {
		const {
			reportId
		} = request.payload;

		ManualReportTemplate.where({
			reportId
		}).destroy().then((result) => {
			if (result !== null) {
				reply({
					isSuccess: true
				});

			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getTemplateReport(request, reply) {
		const rawSql = "Select ReportName From manual_report_templates";

		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null && result[0] !== null) {
					const listReport = result[0];
					reply({
						listReport
					});
				}
				return;
			}).catch(error => {
				reply(Boom.badRequest(error));
			});
	}

	getMetricGrossProfit(request, reply) {
		const firstDayOfCurrentMonth = moment().startOf("month").format("YYYY-MM-DD");
		const sqlQuery = `SELECT sum(GETORDERSIGNERFEEBYID(o.OrderId)) AS SignerFee, sum(GETORDERBROKERFEEBYID(o.OrderId)) AS BrokerFee, sum(GETORDERBROKERFEEBYID(o.OrderId)) - sum(GETORDERSIGNERFEEBYID(o.OrderId)) AS GrossProfit FROM \`order\` o`;

		const getGrossProfitToday = Promise.resolve(Bookshelf.knex.raw(`${sqlQuery} WHERE DATE(o.ClosedDate) = CURRENT_DATE();`));

		const getGrossProfitMtd = Promise.resolve(Bookshelf.knex.raw(`${sqlQuery}  WHERE ${firstDayOfCurrentMonth} <= o.ClosedDate AND o.ClosedDate  <= current_date();`));

		const promiseData = Promise.all([getGrossProfitToday, getGrossProfitMtd]);

		promiseData.then(values => {
			const data = {};
			if (values !== null) {
				values.forEach((item, index) => {
					if (item !== null) {
						switch (index) {
							case 0:
								data.today = item[0][0].GrossProfit ? item[0][0].GrossProfit : 0;
								break;
							case 1:
								data.mtd = item[0][0].GrossProfit ? item[0][0].GrossProfit : 0;
								break;
						}
					}
				});

				reply(data);
			}
		}).catch(err => {
			reply(Boom.badRequest(err));
		});
		return reply;
	}

	getMetricOpenedVolume(request, reply) {
		const startDayOfMonth = moment().startOf("month").format("YYYY-MM-DD");

		const rawSql = `select 
		COUNT((CASE WHEN date_format(OrderDate, '%Y-%m-%d') >= '${startDayOfMonth}' and date_format(OrderDate, '%Y-%m-%d') <= current_date() THEN OrderId ELSE NULL END)) AS mtd, 
		COUNT((CASE WHEN Date(OrderDate) = current_date() THEN OrderId ELSE NULL END)) AS today 
		from \`order\``;
		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null && result[0] !== null) {
					const data = result[0][0];
					reply({
						today: data.today,
						mtd: data.mtd
					});
				}
				return;
			}).catch(error => {
				reply(Boom.badRequest(error));
			});
	}

	getMetricRevenue(request, reply) {
		const firstDayOfCurrentMonth = moment().startOf("month").format("YYYY-MM-DD");
		const sqlQuery = "Select sum(GETORDERBROKERFEEBYID(o.OrderId)) AS TotalBrokerFee FROM \`order`\ o";
		const getAmountOfRevenueFromMTD = Promise.resolve(Bookshelf.knex.raw(`${sqlQuery} where  ${firstDayOfCurrentMonth} <= o.ClosedDate and o.ClosedDate  <= current_date()`));

		const getAmountOfRevenueInCurrentDay = Promise.resolve(Bookshelf.knex.raw(`${sqlQuery}  where Date(ClosedDate) =  current_date()`));

		const promiseData = Promise.all([getAmountOfRevenueInCurrentDay, getAmountOfRevenueFromMTD]);

		promiseData
			.then(values => {
				const data = {};
				if (values !== null) {
					values.forEach((item, index) => {
						if (item !== null) {
							switch (index) {
								case 0:
									data.today = item[0][0].TotalBrokerFee ? item[0][0].TotalBrokerFee : 0;
									break;
								case 1:
									data.mtd = item[0][0].TotalBrokerFee ? item[0][0].TotalBrokerFee : 0;
									break;

							}
						}
					});
				}


				reply(data);
			}).catch(err => {
				reply(Boom.badRequest(err));
			});
		return reply;
	}

	getMetricClosedVolume(request, reply) {
		const firstDayofMonth = moment().startOf("month").format("YYYY-MM-DD");
		const rawSql = `select 
						count(case when (date(ClosedDate) = curdate()) then OrderId else null end) as closedVolumeToday,
						count(case when (date(ClosedDate) >= ${firstDayofMonth} and date(ClosedDate) <= curdate()) then OrderId else null end) as closedVolumeMtd
						FROM  \`order\``;
		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null && result[0] !== null) {
					const data = result[0][0];
					reply({
						closedVolumeToday: data.closedVolumeToday,
						closedVolumeMtd: data.closedVolumeMtd
					});
				}
				return;
			}).catch(error => {
				reply(Boom.badRequest(error));
			});
	}

	writeDataToJson(request, reply) {
		const { columns } = request.query;
		const rawSql = `SELECT * FROM tce_dev2.manual_report_templates Where Columns like '%${columns}%'`;
		console.log("rawSql", rawSql);
		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null && result[0] !== null) {
					const listReport = result[0];
					// const jsonData = listReport;

					// // parse json
					const jsonObj = JSON.parse(JSON.stringify(listReport));
					console.log("jsonObj", jsonObj);

					// stringify JSON Object
					const jsonContent = JSON.stringify(jsonObj);
					console.log("jsonContent", jsonContent);

					const jsonExport = fs.writeFile("myjsonfile.json", jsonContent, "utf8");

					// const jsonExport = fs.writeFile("../../content/reports/myjsonfile.json", jsonContent, "utf8", (err) => {
					// 	if (err) {
					// 		console.log("An error occured while writing JSON Object to File.");
					// 		return console.log(err);
					// 	}
					// 	console.log("JSON file has been saved.");
					// 	return "";
					// });
					// const jsonExport = fs.writeFile(`myjsonfile.json`, JSON.stringify(jsonContent), (err) => {
					// 	if (err) throw err;
					// 	console.log("complete");
					// 	console.log("jsonExport", jsonExport);
					// }
					// );
					reply({
						jsonExport
						// listReport
					});
				}
				return;
			}).catch(error => {
				reply(Boom.badRequest(error));
			});
	}
	// export manual report
	exportManualReport(request, reply) {
		const inputs = JSON.parse(request.payload.toString());
		const { searchObject } = inputs;
		console.log("$$$searchObject", searchObject);
		const vendorStatus = searchObject.vendorStatus;
		const fromDate = searchObject.fromDate;
		const toDate = searchObject.toDate;
		const { reportType } = searchObject;
		if (reportType === "OrderReport" || reportType === undefined) {
			const sqlResult = buildSqlQuery("manual_order_report_v", inputs);
			console.log("sqlResult", sqlResult);
			const {
				sqlStr
			} = sqlResult;
			Bookshelf.knex.raw(sqlStr)
				.then(rs => {
					if (!rs) {
						reply(Boom.badRequest("Empty response"));
						return;
					}
					const data = rs[0];
					console.log("data-view-order-report", data);
					const columns = [
						{ label: "From Date", value: "fromDate" },
						{ label: "To Date", value: "toDate" },
						{ label: "Vendor Status", value: "vendorStatus" },
						{ label: "Order ID", value: "OrderId" },
						{ label: "Product Type", value: "ProductType" },
						{ label: "Order Month", value: "OrderMonth" },
						{ label: "Agent First Name", value: "AgentFirstName" },
						{ label: "Agent Last Name", value: "AgentLastName" },
						{ label: "Vendor First Name", value: "VendorFirstName" },
						{ label: "Vendor Last Name", value: "VendorLastName" },
						{ label: "AptDateTime", value: "AptDateTime", type: "date" },
						{ label: "Company", value: "Company" },
						{ label: "Order Date", value: "OrderDate", type: "date" },
						{ label: "Order Status", value: "OrderStatus" },
						{ label: "Vendor Fee", value: "VendorFee", type: "money" },
						{ label: "Vendor Email", value: "VendorEmail" },
						{ label: "Appointment Address", value: "AppointmentAddress" },
						{ label: "Appointment City", value: "AppointmentCity" },
						{ label: "Appointment State", value: "AppointmentState" },
						{ label: "Appointment Zip", value: "AppointmentZip" },
						{ label: "Property Address", value: "PropertyAddress" },
						{ label: "Property City", value: "PropertyCity" },
						{ label: "Property State", value: "PropertyState" },
						{ label: "Property Zip", value: "PropertyZip" }
					];

					exportExcelFile(data, columns, "Manual Report Order")
						.then(async file => {
							const { isSuccess, error, fileInfo } = file;
							if (isSuccess) {
								await reply.file(fileInfo.path);
							} else {
								reply(Boom.badRequest(error));
							}
						}).catch(err => reply(Boom.badRequest(err)));
				})
				.catch(err => reply(Boom.badRequest(err)));
		}

		if (reportType === "VendorReport") {
			const sqlResult = buildSqlQuery("manual_vendor_report_v", inputs);
			console.log("sqlResult", sqlResult);
			const {
				sqlStr
			} = sqlResult;
			console.log("##sqlStr", sqlStr);
			Bookshelf.knex.raw(sqlStr)
				.then(rs => {
					if (!rs) {
						reply(Boom.badRequest("Empty response"));
						return;
					}
					const data = rs[0];
					console.log("data-view-order-report", data);
					const columns = [
						{ label: "Active", value: "Active", type: "bool" },
						{ label: "First Name", value: "FirstName" },
						{ label: "Last Name", value: "LastName" },
						{ label: "Email", value: "Email" },
						{ label: "WeekdayStreet", value: "WeekdayStreet" },
						{ label: "WeekdayCity", value: "WeekdayCity" },
						{ label: "WeekdayState", value: "WeekdayState" },
						{ label: "WeekdayZip", value: "WeekdayZip" },
						{ label: "Commission Number", value: "CommissionNumber" },
						{ label: "Commission Expiration", value: "CommissionExpiration", type: "date" },
						{ label: "Commission States", value: "CommissionStates" },
						{ label: "TitleProducersLicenseNumber", value: "TitleProducersLicenseNumber" },
						{ label: "TitleProducersLicenseExpiration", value: "TitleProducersLicenseExpiration", type: "date" },
						{ label: "BondExpiration", value: "BondExpiration", type: "date" },
						{ label: "BondPolicyNumber", value: "BondPolicyNumber" },
						{ label: "E&OExpiration", value: "E&OExpiration", type: "date" },
						{ label: "E&OEPolicyNumber", value: "E&OEPolicyNumber" },
						{ label: "DocTypeId", value: "DocTypeId" },
						{ label: "DocType", value: "DocType" },
						{ label: "AreyouanAttorney", value: bufferToBoolean("AreyouanAttorney"), type: "bool" },
						{ label: "Language", value: "Language" },
						{ label: "HomePhone", value: "HomePhone" },
						{ label: "WorkPhone", value: "WorkPhone" },
						{ label: "Mobile", value: "Mobile" },
						{ label: "OrdersCount", value: "OrdersCount" },
						{ label: "Rating", value: "Rating" }
					];

					exportExcelFile(data, columns, "Manual Report Vendor")
						.then(async file => {
							const { isSuccess, error, fileInfo } = file;
							if (isSuccess) {
								await reply.file(fileInfo.path);
							} else {
								reply(Boom.badRequest(error));
							}
						}).catch(err => reply(Boom.badRequest(err)));
				})
				.catch(err => reply(Boom.badRequest(err)));
		}
	}
}
export default new CannedReportController();