import Bookshelf from "../../db/database";
import {
    hasStringValue,
    findNearestAvailableDay,
    handleSingleQuoteRawSql
} from "../../helper/common-helper";
import moment from "moment";

const _buildSqlWhereClause = (searchObject) => {
    const {
        orderStatus,
        orderType,
        dayFrom,
        dayTo,
        month,
        year,
        agents,
        customerName,
        date,
        milestone,
        agentId,
        reqFromDate,
        reqToDate,
        fromDate,
        toDate,
        isGetDataForEconomicDrillDown,
        isFullService,
        isAutoAssign,
        scheduler,
        assignType,
        monthEconomic,
        brokerId,
        closedOrderFromDate,
        closedOrderToDate,
        listLoanType,
        isGetDataForEconomicClosedOrder,
        userPrimaryId
    } = searchObject;
    let whereStr = "";
    let tSql = "";
    let isShowAll = true;

    // order type
    if (orderType && orderType.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < orderType.length; i++) {
            tSql += ` OR OrderType LIKE '${orderType[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // order status
    if (orderStatus && orderStatus.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < orderStatus.length; i++) {
            tSql += ` OR OrderStatus LIKE '${orderStatus[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // month
    // day from
    // day to
    if (month && month.length > 0) {
        tSql = "1 != 1";

        for (let i = 0; i < month.length; i++) {
            // const dateFrom = `${year}-${month[i].value}-${dayFrom}`;
            const dateFrom = findNearestAvailableDay(year, month[i].value, dayFrom, "YYYY-MM-DD");
            const dateTo = moment(findNearestAvailableDay(year, month[i].value, dayTo, "YYYY-MM-DD")).add(1, "days").format("YYYY-MM-DD");

            tSql += ` OR (OrderDate >= '${dateFrom}' AND OrderDate < '${dateTo}')`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // day to
    if (date) {
        tSql = "1 != 1";
        tSql += ` OR (Date LIKE '${date}')`;

        whereStr += ` AND (${tSql})`;
    }

    // agents
    if (agents && agents.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < agents.length; i++) {
            tSql += ` OR AgentId LIKE '${agents[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }
    // customer
    if (customerName && customerName.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < customerName.length; i++) {
            tSql += `OR customerName LIKE '%${customerName[i].value || ""}%'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }
    // milestone
    if (milestone && milestone.length > 0) {
        tSql = "1 != 1";
        switch (milestone) {
            case "1":
                tSql += ` OR TotalClosedOrders >= 1 AND TotalClosedOrders < 25`;
                break;
            case "25":
                tSql += ` OR TotalClosedOrders >= 25 AND TotalClosedOrders < 50`;
                break;
            case "50":
                tSql += ` OR TotalClosedOrders >= 50 AND TotalClosedOrders < 100`;
                break;
            case "100":
                tSql += ` OR TotalClosedOrders >= 100 AND TotalClosedOrders < 250`;
                break;
            case "250":
                tSql += ` OR TotalClosedOrders >= 250 AND TotalClosedOrders < 500`;
                break;
            case "500":
                tSql += ` OR TotalClosedOrders >= 250 AND TotalClosedOrders < 500`;
                break;
        }
        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // agentId
    if (agentId && agentId.length > 0) {
        let arrayAgent = "(";
        tSql = ``;
        for (let i = 0; i < agentId.length; i++) {
            arrayAgent += `${agentId[i]}`;
            if (i < agentId.length - 1) {
                arrayAgent += `,`;
            } else {
                arrayAgent += `)`;
            }
        }

        if (arrayAgent !== "()") {
            tSql = `agentId in ${arrayAgent}`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // scheduler
    if (scheduler && scheduler.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < scheduler.length; i++) {
            tSql += ` OR RepId LIKE '${scheduler[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // reqFromDate
    if (hasStringValue(reqFromDate)) {
        const momentDate = moment(`${reqFromDate} 00:00:00`).utc().format("YYYY-MM-DD HH:mm:ss");
        if (momentDate !== "Invalid date") {
            tSql = `DateStamp >= '${momentDate}'`;
            whereStr += ` AND (${tSql})`;
            isShowAll = false;
        }
    }

    //reqToDate
    if (hasStringValue(reqToDate)) {
        const momentDate = moment(`${reqToDate} 23:59:59`).utc().format("YYYY-MM-DD HH:mm:ss");
        if (momentDate !== "Invalid date") {
            tSql = `DateStamp <= '${momentDate}'`;
            whereStr += ` AND (${tSql})`;
            isShowAll = false;
        }
    }

    // fromDate
    if (hasStringValue(fromDate)) {
        const momentDate = moment(fromDate).format("YYYY-MM-DD");
        if (momentDate !== "Invalid date") {
            tSql = `OrderDate >= '${momentDate}'`;
            whereStr += ` AND (${tSql})`;
            isShowAll = false;
        }
    }

    // toDate
    if (hasStringValue(toDate)) {
        const momentDate = moment(toDate).format("YYYY-MM-DD");
        if (momentDate !== "Invalid date") {
            tSql = `OrderDate <= '${momentDate} 23:59:59'`;
            whereStr += ` AND (${tSql})`;
            isShowAll = false;
        }
    }

    // economic Request Status
    if (isGetDataForEconomicDrillDown) {
        const fetchStatus = searchObject.status;
        const arrayStatus = Object.keys(fetchStatus);
        if (arrayStatus.length > 0) {
            let arrayWhereStatus = "(";
            tSql = ``;

            for (let i = 0; i < arrayStatus.length; i++) {
                if (fetchStatus[arrayStatus[i]]) arrayWhereStatus += `'${arrayStatus[i]}'`;
                if (i < arrayStatus.length - 1) {
                    arrayWhereStatus += `,`;
                } else {
                    arrayWhereStatus += `)`;
                }
            }

            if (arrayWhereStatus !== "()") {
                tSql = `approved in ${arrayWhereStatus}`;
            }

            whereStr += ` AND (${tSql})`;
            isShowAll = false;
        }

    }

    // isFullService
    if (isFullService !== undefined) {
        if (isFullService) {
            tSql = "1 != 1";
            tSql += ` OR (IsSelfService = 0 OR IsSelfService is NULL )`;
        } else {
            tSql = "1 != 1";
            tSql += ` OR (IsSelfService = true)`;
        }

        whereStr += ` AND (${tSql})`;
    }

    // auto assign
    if (isAutoAssign !== undefined) {
        tSql = isAutoAssign ? "IsAutoAssign = true" : "IsAutoAssign = false or IsAutoAssign is null";

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // type assign
    if (assignType && assignType !== "0") {
        tSql = "1 != 1";
        if (assignType === "1") {
            tSql += ` OR (IsAutoAssign = false OR IsAutoAssign is NULL)`;
        } else if (assignType === "2") {
            tSql += ` OR (IsAutoAssign = true)`;
        }
        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // month Economic
    if (monthEconomic && monthEconomic.length > 0) {
        tSql = "1 != 1";

        for (let i = 0; i < monthEconomic.length; i++) {
            const monthSearch = `${year}-${monthEconomic[i].value}`;

            tSql += ` OR (ClosedDate = '${monthSearch}')`;
        }
        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // broker id
    if (brokerId && brokerId.length > 0) {
        tSql = `(BrokerId = ${brokerId[0]} OR BrokerId in (SELECT BrokerID FROM broker WHERE GID = ${brokerId[0]}))`;
        whereStr += ` AND (${tSql})`;
        isShowAll = true;
    }

    //closedOrderFromDate and closedOrderToDate
    if (hasStringValue(closedOrderFromDate)) {
        tSql = `ClosedDate >= '${closedOrderFromDate}'`;
        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    if (hasStringValue(closedOrderToDate)) {
        tSql = `ClosedDate <= '${closedOrderToDate}'`;
        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    if (isGetDataForEconomicClosedOrder && listLoanType && Array.isArray(listLoanType) && listLoanType.length > 0) {
        tSql = "LoanType in (";

        for (let i = 0; i < listLoanType.length; i++) {
            const data = listLoanType[i];
            tSql += `'${handleSingleQuoteRawSql(data)}'`;
            if (i < listLoanType.length - 1) {
                tSql += `,`;
            } else {
                tSql += `) `;
            }
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    //get economic data when client view report
    if (hasStringValue(userPrimaryId)) {
        tSql = `brokerId = ${userPrimaryId} OR GID = ${userPrimaryId}`;

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    return {
        whereStr,
        isShowAll
    };
};


export const buildSqlCountQuery = (viewName, criterias) => {
    const {
        searchObject
    } = criterias;

    let sqlStr = `SELECT Count(*) AS Num FROM ${viewName} WHERE 1 = 1`;
    let isShowAll = true;

    const whereObj = _buildSqlWhereClause(searchObject);

    isShowAll = whereObj.isShowAll;
    sqlStr += whereObj.whereStr;

    return {
        sqlStr,
        isShowAll
    };
};

export const buildSqlQuery = (viewName, criterias, listFetchColumn = [], ignoreOptions) => {
    const {
        searchObject,
        options
    } = criterias;

    let sqlStr = "";
    let isShowAll = true;

    if (Array.isArray(listFetchColumn) && listFetchColumn.length > 0) {
        let fetchColumnStr = ``;
        for (let i = 0; i < listFetchColumn.length; i++) {
            fetchColumnStr = `${fetchColumnStr}${listFetchColumn[i]}`;
            if (i < listFetchColumn.length - 1) fetchColumnStr = `${fetchColumnStr}, `;
        }

        sqlStr = `SELECT ${fetchColumnStr} FROM ${viewName} WHERE 1 = 1`;
    } else {
        sqlStr = `SELECT * FROM ${viewName} WHERE 1 = 1`;
    }
    const whereObj = _buildSqlWhereClause(searchObject);

    isShowAll = whereObj.isShowAll;
    sqlStr += whereObj.whereStr;

    let groupByStr = "";
    let sortByStr = "";
    let pagingStr = "";

    if (options) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            groupBy
        } = options;

        // group by
        if (hasStringValue(groupBy)) {
            groupByStr = ` GROUP BY ${groupBy} `;
            if (!ignoreOptions) {
                sqlStr += groupByStr;
            }
        }

        // sort
        if (hasStringValue(sortColumn)) {
            sortByStr = ` ORDER BY ${sortColumn} ${sortDirection ? "ASC" : "DESC"}`;
            if (!ignoreOptions) {
                sqlStr += sortByStr;
            }
        }

        // offset and limit
        if (hasStringValue(page) && hasStringValue(itemPerPage)) {
            pagingStr = ` LIMIT ${itemPerPage} OFFSET ${(page - 1) * itemPerPage}`;
            if (!ignoreOptions) {
                sqlStr += pagingStr;
            }
        }
    }

    // eslint-disable-next-line
    console.log(`SQL string:= ${sqlStr}`);

    return {
        sqlStr,
        groupByStr,
        sortByStr,
        pagingStr,
        isShowAll
    };
};

export const getAgents = async () => {
    const rawSql = `SELECT CONCAT(a.FirstName, ' ', a.LastName) AS Agents,
                    a.AgentId As AgentId
                    FROM agent a
                    ORDER BY Agents ASC;`;

    const rs = await Bookshelf.knex.raw(rawSql);
    if (rs) {
        if (rs[0] && rs[0].length > 0) {
            return rs[0].map(i => {
                return {
                    Agents: i.Agents || "",
                    AgentId: i.AgentId
                };
            });
        }
    }

    return [];
};

export const getScheduler = async () => {
    const rawSql = `SELECT DISTINCT e.RepId, CONCAT(e.FirstName, ' ', e.LastName) AS Scheduler
    FROM employees e
        JOIN \`order\` o ON e.RepId = o.RepId
    WHERE
        e.Status = 0
        AND e.Accounting = 0
        AND e.Manager is null
        AND e.Active = 1
        AND o.RepAssignDate is not null
        ORDER BY Scheduler ASC`;

    const rs = await Bookshelf.knex.raw(rawSql);

    if (rs) {
        return rs[0];
    }

    return [];
};

export const getOrderTypes = async () => {
    const rawSql = `SELECT LoanType FROM loan_type ORDER BY LoanType ASC`;

    const rs = await Bookshelf.knex.raw(rawSql);

    if (rs) {
        return rs[0];
    }

    return [];
};