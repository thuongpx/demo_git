import Bookshelf from "../../db/database";
import Boom from "boom";

import {
    distinctSingleValueArray,
    bufferToBoolean
} from "../../helper/common-helper";
import {
    buildSqlQuery,
    buildSqlCountQuery
} from "./canned-report";
import { exportExcelFile } from "../../helper/excel-helper";

class DailyReportController {
    constructor() { }

    fetchOrderByStatusChartData(request, reply) {
        const sqlResult = buildSqlQuery("open_order_chart_v", request.payload);
        const {
            sqlStr,
            isShowAll
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                let labels = distinctSingleValueArray(rawData.map(i => i.OrderStatus)); // build labels
                const orderTypes = distinctSingleValueArray(rawData.map(i => i.OrderType)); // build datasets

                const datasets = [];

                if (isShowAll) {
                    const tData = {
                        label: "All Data",
                        data: []
                    };

                    for (let i = 0; i < labels.length; i++) {
                        // eslint-disable-next-line
                        const f = rawData.filter(rd => rd.OrderStatus === labels[i]);
                        const r = f.reduce((a, c) => {
                            return {
                                Count: a.Count + c.Count
                            };
                        });
                        tData.data.push(r.Count);
                    }

                    datasets.push(tData);
                } else {
                    for (let o = 0; o < orderTypes.length; o++) {
                        const tData = {
                            label: orderTypes[o],
                            data: []
                        };

                        for (let i = 0; i < labels.length; i++) {
                            // eslint-disable-next-line
                            const f = rawData.find(r => {
                                return r.OrderType === orderTypes[o] && r.OrderStatus === labels[i];
                            });

                            tData.data.push(f ? f.Count : 0);
                        }

                        datasets.push(tData);
                    }
                }
                // sort data

                // prepare temporary datasets to count total
                const totalDatasets = datasets[0].data.map(i => {
                    return {
                        value: i,
                        label: ""
                    };
                });

                // count total
                for (let i = 0; i < datasets.length; i++) {
                    for (let j = 0; j < totalDatasets.length; j++) {
                        if (i === 0) {
                            totalDatasets[j].label = labels[j];
                        } else {
                            totalDatasets[j].value += datasets[i].data[j];
                        }
                    }
                }

                // do sort
                totalDatasets.sort((a, b) => {
                    if (a.value > b.value) {
                        return -1;
                    }

                    if (a.value < b.value) {
                        return 1;
                    }

                    return 0;
                });

                const sortedLabels = totalDatasets.map(i => i.label);
                // sort data of datasets
                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < sortedLabels.length; j++) {
                        const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                        newData.push(oldData[oldIndex]);
                    }
                    datasets[i].data = newData;
                }
                labels = sortedLabels;
                return reply({
                    labels,
                    datasets
                });
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchOrderComparisonByBussinessChartData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            month
        } = searchObject;

        const sqlResult = buildSqlQuery("open_order_comparison_by_business_day_chart_v", request.payload);
        const {
            sqlStr
        } = sqlResult;
        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                const sortedMonth = month.sort((a, b) => {
                    return parseInt(a.value) - parseInt(b.value);
                });
                const labels = distinctSingleValueArray(sortedMonth.map(item => item.label));
                const labelValue = distinctSingleValueArray(sortedMonth.map(item => item.value));
                const datasets = [];
                const tData = {
                    label: "All Data",
                    data: []
                };
                for (let i = 0; i < labelValue.length; i++) {
                    const f = rawData.filter(rd => (rd.OrderMonth === parseInt(labelValue[i])));

                    tData.data.push(f.length);
                }
                datasets.push(tData);
                return reply({
                    labels,
                    datasets
                });
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchOrderByStatusGridData(request, reply) {
        const sqlResult = buildSqlQuery("open_order_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];
                reply({
                    data
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countOrderByStatusGridData(request, reply) {
        const sqlResult = buildSqlCountQuery("open_order_drilldown_v", request.payload);

        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchDailyAutoAssignOrdersByStatusChartData(request, reply) {
        const sqlResult = buildSqlQuery("daily_counter_report_chart_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0].filter(rd => bufferToBoolean(rd.IsAutoAssign));
                const labels = distinctSingleValueArray(rawData.map(i => i.OrderStatus)); // build labels
                const datasets = [];

                // build bar datasets
                const bData = {
                    label: "Total orders",
                    type: "bar",
                    data: []
                };

                for (let i = 0; i < labels.length; i++) {
                    const f = rawData.filter(rd => rd.OrderStatus === labels[i]);
                    const r = f.reduce((a, c) => {
                        return {
                            Count: a.Count + c.Count
                        };
                    });

                    bData.data.push(r.Count);
                }

                datasets.push(bData);

                // build line datasets
                const lData = {
                    label: "Avg of Profit",
                    type: "line",
                    data: []
                };

                for (let i = 0; i < labels.length; i++) {
                    const f = rawData.filter(rd => rd.OrderStatus === labels[i]);
                    const r = f.reduce((a, c) => {
                        return {
                            SumFee: a.SumFee + c.SumFee
                        };
                    });
                    r.SumFee /= f.length;
                    lData.data.push(r.SumFee);
                }

                datasets.push(lData);

                return reply({
                    labels,
                    datasets
                });
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchDailyAutoAssignOrdersByStatusGridData(request, reply) {
        const sqlResult = buildSqlQuery("daily_counter_report_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                const dataMedium = rs[0].filter(rd => bufferToBoolean(rd.IsAutoAssign));
                const data = [];
                const labels = distinctSingleValueArray(dataMedium.map(i => i.OrderStatus));
                for (let i = 0; i < labels.length; i++) {
                    const f = dataMedium.filter(rd => rd.OrderStatus === labels[i]);
                    if (f.length > 1) {
                        const r = f.reduce((a, c) => {
                            return {
                                OrderStatus: a.OrderStatus,
                                TotalOrder: a.TotalOrder + c.TotalOrder,
                                SumOfAssignTime: a.SumOfAssignTime + c.SumOfAssignTime,
                                SumOfProfit: a.SumOfProfit + c.SumOfProfit
                            };
                        });
                        r.AverageOfAssignTime = r.SumOfAssignTime / r.TotalOrder;
                        r.AverageProfit = r.SumOfProfit / r.TotalOrder;
                        data.push(r);
                    } else if (f.length === 1) {
                        const r = {
                            OrderStatus: f[0].OrderStatus,
                            TotalOrder: f[0].TotalOrder,
                            SumOfAssignTime: f[0].SumOfAssignTime,
                            AverageOfAssignTime: f[0].AverageOfAssignTime,
                            SumOfProfit: f[0].SumOfProfit,
                            AverageProfit: f[0].AverageProfit
                        };
                        data.push(r);
                    }
                }
                if (data.length > 1) {
                    const r = data.reduce((a, c) => {
                        return {
                            OrderStatus: "Sub Total",
                            TotalOrder: a.TotalOrder + c.TotalOrder,
                            SumOfAssignTime: "",
                            AverageOfAssignTime: "",
                            SumOfProfit: a.SumOfProfit + c.SumOfProfit,
                            AverageProfit: ""
                        };
                    });
                    data.push(r);
                } else if (data.length === 1) {
                    const r = {
                        OrderStatus: "Sub Total",
                        TotalOrder: data[0].TotalOrder,
                        SumOfAssignTime: "",
                        AverageOfAssignTime: "",
                        SumOfProfit: data[0].SumOfProfit,
                        AverageProfit: ""
                    };
                    data.push(r);
                }
                reply({
                    data
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countDailyAutoAssignOrdersByStatusGridData(request, reply) {
        const sqlResult = buildSqlCountQuery("daily_counter_report_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchDailyManualAssignOrdersByStatusChartData(request, reply) {
        const sqlResult = buildSqlQuery("daily_counter_report_chart_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0].filter(rd => !bufferToBoolean(rd.IsAutoAssign));
                const labels = distinctSingleValueArray(rawData.map(i => i.OrderStatus)); // build labels
                const datasets = [];

                // build bar datasets
                const bData = {
                    label: "Total orders",
                    type: "bar",
                    data: []
                };

                for (let i = 0; i < labels.length; i++) {
                    const f = rawData.filter(rd => rd.OrderStatus === labels[i]);
                    const r = f.reduce((a, c) => {
                        return {
                            Count: a.Count + c.Count
                        };
                    });

                    bData.data.push(r.Count);
                }

                datasets.push(bData);

                // build line datasets
                const lData = {
                    label: "Avg of Profit",
                    type: "line",
                    data: []
                };

                for (let i = 0; i < labels.length; i++) {
                    const f = rawData.filter(rd => rd.OrderStatus === labels[i]);
                    const r = f.reduce((a, c) => {
                        return {
                            SumFee: a.SumFee + c.SumFee
                        };
                    });
                    r.SumFee /= f.length;
                    lData.data.push(r.SumFee);
                }

                datasets.push(lData);

                return reply({
                    labels,
                    datasets
                });
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchDailyManualAssignOrdersByStatusGridData(request, reply) {
        const sqlResult = buildSqlQuery("daily_counter_report_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                const dataMedium = rs[0].filter(rd => !bufferToBoolean(rd.IsAutoAssign));
                const data = [];
                const labels = distinctSingleValueArray(dataMedium.map(i => i.OrderStatus));
                for (let i = 0; i < labels.length; i++) {
                    const f = dataMedium.filter(rd => rd.OrderStatus === labels[i]);
                    if (f.length > 1) {
                        const r = f.reduce((a, c) => {
                            return {
                                OrderStatus: a.OrderStatus,
                                TotalOrder: a.TotalOrder + c.TotalOrder,
                                SumOfAssignTime: a.SumOfAssignTime + c.SumOfAssignTime,
                                SumOfProfit: a.SumOfProfit + c.SumOfProfit
                            };
                        });
                        r.AverageOfAssignTime = r.SumOfAssignTime / r.TotalOrder;
                        r.AverageProfit = r.SumOfProfit / r.TotalOrder;
                        data.push(r);
                    } else if (f.length === 1) {
                        const r = {
                            OrderStatus: f[0].OrderStatus,
                            TotalOrder: f[0].TotalOrder,
                            SumOfAssignTime: f[0].SumOfAssignTime,
                            AverageOfAssignTime: f[0].AverageOfAssignTime,
                            SumOfProfit: f[0].SumOfProfit,
                            AverageProfit: f[0].AverageProfit
                        };
                        data.push(r);
                    }
                }
                if (data.length > 1) {
                    const r = data.reduce((a, c) => {
                        return {
                            OrderStatus: "Sub Total",
                            TotalOrder: a.TotalOrder + c.TotalOrder,
                            SumOfAssignTime: "",
                            AverageOfAssignTime: "",
                            SumOfProfit: a.SumOfProfit + c.SumOfProfit,
                            AverageProfit: ""
                        };
                    });
                    data.push(r);
                } else if (data.length === 1) {
                    const r = {
                        OrderStatus: "Sub Total",
                        TotalOrder: data[0].TotalOrder,
                        SumOfAssignTime: "",
                        AverageOfAssignTime: "",
                        SumOfProfit: data[0].SumOfProfit,
                        AverageProfit: ""
                    };
                    data.push(r);
                }

                reply({
                    data
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countDailyManualAssignOrdersByStatusGridData(request, reply) {
        const sqlResult = buildSqlCountQuery("daily_counter_report_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    //exportComparisonByBusinessDayGridData
    exportComparisonByBusinessDayGridData(request, reply) {
        const inputs = JSON.parse(request.payload.toString());
        inputs.options = {
            sortColumn: "OpenDate"
        };
        const sqlResult = buildSqlQuery("open_order_drilldown_v", inputs);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];
                const columns = [
                    { label: "Open Date", value: "OpenDate", type: "date" },
                    { label: "Order Number", value: "OrderNumber" },
                    { label: "Closing Date", value: "ClosingDate", type: "date" },
                    { label: "Title Company", value: "TitleCompany" },
                    { label: "Agents", value: "Agents" },
                    { label: "Borrower Last", value: "BorrowerLast" },
                    { label: "Type of Transaction", value: "LoanType" },
                    { label: "Status", value: "OrderStatus" },
                    { label: "Vendor Fee", value: "VendorFee", type: "money" },
                    { label: "Client Fee", value: "ClientFee", type: "money" },
                    { label: "Appoint Assigned By", value: "AppointAssignedBy" }
                ];

                exportExcelFile(data, columns, "Open Orders Comparison by Business Day")
                    .then(async file => {
                        const { isSuccess, error, fileInfo } = file;
                        if (isSuccess) {
                            await reply.file(fileInfo.path);
                        } else {
                            reply(Boom.badRequest(error));
                        }
                    }).catch(err => reply(Boom.badRequest(err)));
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    //exportOrderByStatusGridData
    exportOrderByStatusGridData(request, reply) {
        const inputs = JSON.parse(request.payload.toString());
        inputs.options = {
            sortColumn: "OpenDate"
        };
        const sqlResult = buildSqlQuery("open_order_drilldown_v", inputs);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];
                const columns = [
                    { label: "Open Date", value: "OpenDate", type: "date" },
                    { label: "Order Number", value: "OrderNumber" },
                    { label: "Closing Date", value: "ClosingDate", type: "date" },
                    { label: "Title Company", value: "TitleCompany" },
                    { label: "Agents", value: "Agents" },
                    { label: "Borrower Last", value: "BorrowerLast" },
                    { label: "Type of Transaction", value: "LoanType" },
                    { label: "Status", value: "OrderStatus" },
                    { label: "Vendor Fee", value: "VendorFee", type: "money" },
                    { label: "Client Fee", value: "ClientFee", type: "money" },
                    { label: "Appoint Assigned By", value: "AppointAssignedBy" }
                ];

                exportExcelFile(data, columns, "Open Order List by Status")
                    .then(async file => {
                        const { isSuccess, error, fileInfo } = file;
                        if (isSuccess) {
                            await reply.file(fileInfo.path);
                        } else {
                            reply(Boom.badRequest(error));
                        }
                    }).catch(err => reply(Boom.badRequest(err)));
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    // exportDailyAutoAssignedOrdersByStatusGrid
    exportDailyAutoAssignedOrdersByStatusGrid(request, reply) {
        const inputs = JSON.parse(request.payload.toString());
        inputs.options = {
            sortColumn: "OrderStatus"
        };
        const sqlResult = buildSqlQuery("daily_counter_report_drilldown_v", inputs);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const dataMedium = rs[0].filter(rd => bufferToBoolean(rd.IsAutoAssign));
                const data = [];
                const labels = distinctSingleValueArray(dataMedium.map(i => i.OrderStatus));
                for (let i = 0; i < labels.length; i++) {
                    const f = dataMedium.filter(rd => rd.OrderStatus === labels[i]);
                    if (f.length > 1) {
                        const r = f.reduce((a, c) => {
                            return {
                                OrderStatus: a.OrderStatus,
                                TotalOrder: a.TotalOrder + c.TotalOrder,
                                SumOfAssignTime: a.SumOfAssignTime + c.SumOfAssignTime,
                                SumOfProfit: a.SumOfProfit + c.SumOfProfit
                            };
                        });
                        r.AverageOfAssignTime = r.SumOfAssignTime / r.TotalOrder;
                        r.AverageProfit = r.SumOfProfit / r.TotalOrder;
                        data.push(r);
                    } else if (f.length === 1) {
                        const r = {
                            OrderStatus: f[0].OrderStatus,
                            TotalOrder: f[0].TotalOrder,
                            SumOfAssignTime: f[0].SumOfAssignTime,
                            AverageOfAssignTime: f[0].AverageOfAssignTime,
                            SumOfProfit: f[0].SumOfProfit,
                            AverageProfit: f[0].AverageProfit
                        };
                        data.push(r);
                    }
                }
                if (data.length > 1) {
                    const r = data.reduce((a, c) => {
                        return {
                            OrderStatus: "Sub Total",
                            TotalOrder: a.TotalOrder + c.TotalOrder,
                            SumOfAssignTime: "",
                            AverageOfAssignTime: "",
                            SumOfProfit: a.SumOfProfit + c.SumOfProfit,
                            AverageProfit: ""
                        };
                    });
                    data.push(r);
                } else if (data.length === 1) {
                    const r = {
                        OrderStatus: "Sub Total",
                        TotalOrder: data[0].TotalOrder,
                        SumOfAssignTime: "",
                        AverageOfAssignTime: "",
                        SumOfProfit: data[0].SumOfProfit,
                        AverageProfit: ""
                    };
                    data.push(r);
                }
                const columns = [
                    { label: "Open Status", value: "OrderStatus" },
                    { label: "Total Order", value: "TotalOrder" },
                    { label: "Sum Of Assign Time", value: "SumOfAssignTime" },
                    { label: "Average Of Assign Time", value: "AverageOfAssignTime" }
                ];

                exportExcelFile(data, columns, "Daily Auto-Assigned Orders by Status")
                    .then(async file => {
                        const { isSuccess, error, fileInfo } = file;
                        if (isSuccess) {
                            await reply.file(fileInfo.path);
                        } else {
                            reply(Boom.badRequest(error));
                        }
                    }).catch(err => reply(Boom.badRequest(err)));
            })
            .catch(err => reply(Boom.badRequest(err)));
    }
    // exportDailyManualAssignedOrdersByStatusGrid
    exportDailyManualAssignedOrdersByStatusGrid(request, reply) {
        const inputs = JSON.parse(request.payload.toString());
        inputs.options = {
            sortColumn: "OrderStatus"
        };
        const sqlResult = buildSqlQuery("daily_counter_report_drilldown_v", inputs);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const dataMedium = rs[0].filter(rd => !bufferToBoolean(rd.IsAutoAssign));
                const data = [];
                const labels = distinctSingleValueArray(dataMedium.map(i => i.OrderStatus));
                for (let i = 0; i < labels.length; i++) {
                    const f = dataMedium.filter(rd => rd.OrderStatus === labels[i]);
                    if (f.length > 1) {
                        const r = f.reduce((a, c) => {
                            return {
                                OrderStatus: a.OrderStatus,
                                TotalOrder: a.TotalOrder + c.TotalOrder,
                                SumOfAssignTime: a.SumOfAssignTime + c.SumOfAssignTime,
                                SumOfProfit: a.SumOfProfit + c.SumOfProfit
                            };
                        });
                        r.AverageOfAssignTime = r.SumOfAssignTime / r.TotalOrder;
                        r.AverageProfit = r.SumOfProfit / r.TotalOrder;
                        data.push(r);
                    } else if (f.length === 1) {
                        const r = {
                            OrderStatus: f[0].OrderStatus,
                            TotalOrder: f[0].TotalOrder,
                            SumOfAssignTime: f[0].SumOfAssignTime,
                            AverageOfAssignTime: f[0].AverageOfAssignTime,
                            SumOfProfit: f[0].SumOfProfit,
                            AverageProfit: f[0].AverageProfit
                        };
                        data.push(r);
                    }
                }
                if (data.length > 1) {
                    const r = data.reduce((a, c) => {
                        return {
                            OrderStatus: "Sub Total",
                            TotalOrder: a.TotalOrder + c.TotalOrder,
                            SumOfAssignTime: "",
                            AverageOfAssignTime: "",
                            SumOfProfit: a.SumOfProfit + c.SumOfProfit,
                            AverageProfit: ""
                        };
                    });
                    data.push(r);
                } else if (data.length === 1) {
                    const r = {
                        OrderStatus: "Sub Total",
                        TotalOrder: data[0].TotalOrder,
                        SumOfAssignTime: "",
                        AverageOfAssignTime: "",
                        SumOfProfit: data[0].SumOfProfit,
                        AverageProfit: ""
                    };
                    data.push(r);
                }
                const columns = [
                    { label: "Open Status", value: "OrderStatus" },
                    { label: "Total Order", value: "TotalOrder" },
                    { label: "Sum Of Assign Time", value: "SumOfAssignTime" },
                    { label: "Average Of Assign Time", value: "AverageOfAssignTime" }
                ];

                exportExcelFile(data, columns, "Daily Manual-Assigned Orders by Status")
                    .then(async file => {
                        const { isSuccess, error, fileInfo } = file;
                        if (isSuccess) {
                            await reply.file(fileInfo.path);
                        } else {
                            reply(Boom.badRequest(error));
                        }
                    }).catch(err => reply(Boom.badRequest(err)));
            })
            .catch(err => reply(Boom.badRequest(err)));
    }
}
export default new DailyReportController();