import FeeConfiguration from "./fee-configuration-controller";

const routes = [
    {
        path: "/feeConfiguration/getInitDataForMatrix",
        method: "GET",
        handler: FeeConfiguration.getInitDataForMatrix
    },
    {
        path: "/feeConfiguration/saveFee",
        method: "POST",
        handler: FeeConfiguration.saveFee
    },
    {
        path: "/feeConfiguration/getRefreshData",
        method: "GET",
        handler: FeeConfiguration.getRefreshData
    }
];

export default routes;