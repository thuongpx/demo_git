import Branch from "../../db/model/branches";
import Bookshelf from "../../db/database";
import Boom from "boom";
import Broker from "../../db/model/brokers";
import {
    handleSingleQuote
} from "../../helper/common-helper";
import {
    ORDER_PROGRESS_ID
} from "../../constant/progress-constant";

class BranchController {
    constructor() { }

    getBranchesForDropdown(request, reply) {
        new Branch().fetchAll({
            columns: ["BranchID", "BranchName"]
        }).then((result) => {
            if (result !== null) {
                reply(result);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

        return;
    }

    getBranchNameByKeyword(request, reply) {
        const {
            GID,
            searchText,
            selectedValues,
            limit
        } = request.query;

        const selectedValuesStr = selectedValues ? `AND Company NOT IN (${selectedValues})` : "";

        const rawSql = `SELECT BrokerID, Company FROM broker WHERE (Company LIKE '%${handleSingleQuote(searchText)}%' AND GID = '${GID}') ${selectedValuesStr} ORDER BY BrokerID LIMIT ${limit};`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        sources: result[0]
                    });
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

    lockBranch(request, reply) {
        const branchId = request.query;

        Branch.where(branchId).save({
            Inactive: true
        }, {
                method: "update"
            }).then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getBranchManagementData(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            brokerID,
            company,
            contactFirst,
            contactLast,
            GID
        } = request.payload;

        const getClients = Promise.resolve(Bookshelf.knex.raw(
            `call GetBranches('${sortColumn}',${sortDirection},${page},
			${itemPerPage},'${brokerID}','${company}','${handleSingleQuote(contactFirst)}','${handleSingleQuote(contactLast)}','${GID}')`));

        Promise.all([getClients])
            .then(values => {
                const data = {};

                if (values !== null) {
                    values.forEach((item) => {
                        if (item !== null) {
                            data.listBranch = {
                                branches: item[0][0],
                                totalRecords: item[0][1][0].TotalRecords
                            };
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });

        return reply;
    }

    updateBranch(request, reply) {
        const broker = request.payload;

        Broker.where({
            BrokerId: broker.BrokerId
        }).save(broker, {
            method: "update"
        }).then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    checkBranchMergeable(request, reply) {
        const {
            brokerId,
            userId
        } = request.query;
        const agentCheck = `SELECT AgentId FROM agent WHERE BrokerId = ${brokerId} AND Inactive = 0;`;
        const orderCheck = `SELECT OrderId FROM \`order\` WHERE BrokerId = ${brokerId} AND ProgressId != ${ORDER_PROGRESS_ID.CLOSING_COMPLETED} AND ProgressId != ${ORDER_PROGRESS_ID.CANCELED};`;
        const listMergeBranches = `SELECT BrokerID, Company FROM broker WHERE GID = ${userId} AND BrokerID != ${brokerId} AND IsAvailable = 1 AND !Inactive ORDER BY Company ASC;`;

        Bookshelf.knex.raw(agentCheck)
            .then(agentResult => {
                Bookshelf.knex.raw(orderCheck)
                    .then(orderResult => {
                        Bookshelf.knex.raw(listMergeBranches)
                            .then(listMergeResult => {
                                reply({
                                    agentEmpty: agentResult[0].length === 0,
                                    orderEmpty: orderResult[0].length === 0,
                                    listMerge: listMergeResult[0]
                                });
                                return reply;
                            }).catch((error) => {
                                reply(Boom.badRequest(error));

                                return reply;
                            });
                    }).catch((error) => {
                        reply(Boom.badRequest(error));

                        return reply;
                    });
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

    mergeBranch(request, reply) {
        const {
            originId,
            destinationId
        } = request.query;

        const updateOrder = `UPDATE \`order\` SET BrokerID = ${destinationId} WHERE BrokerId = ${originId};`;
        const updateAgent = `UPDATE agent SET BrokerId = ${destinationId} WHERE BrokerId = ${originId}`;

        Bookshelf.knex.raw(updateOrder)
            .then(orderResult => {
                Bookshelf.knex.raw(updateAgent)
                    .then(agentResult => {
                        if (orderResult !== null && agentResult !== null) {
                            reply({
                                isSuccess: true
                            });
                        }
                        return reply;
                    }).catch((error) => {
                        reply(Boom.badRequest(error));

                        return reply;
                    });
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

    disableBranch(request, reply) {
        const {
            branchId
        } = request.query;
        const rawSql = `
        UPDATE broker SET Inactive = 1 WHERE BrokerId = ${branchId};`;

        const findUserSql = `
            SELECT U.UsersId
            FROM \`users\` U
            JOIN \`user_roles\` UL ON U.UsersId = UL.UsersId AND UL.RoleId = 6
            WHERE MappingUserId = ${branchId};`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    Bookshelf.knex.raw(findUserSql)
                        .then(findUserResult => {
                            if (findUserResult !== null) {
                                const inactiveUsersSql = `UPDATE \`users\` SET Inactive = 1 WHERE UsersId = ${findUserResult[0][0].UsersId}`;

                                Bookshelf.knex.raw(inactiveUsersSql)
                                    .then(inactiveUsersResult => {
                                        if (inactiveUsersResult !== null) {
                                            reply({
                                                isSuccess: true
                                            });
                                        }
                                        return reply;
                                    }).catch((error) => {
                                        reply(Boom.badRequest(error));
                                        return reply;
                                    });
                            }
                            return reply;
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                            return reply;
                        });
                }
                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return reply;
            });
    }

    activeBranch(request, reply) {
        const {
            branchId
        } = request.payload;
        const rawSql = `UPDATE broker SET Inactive = 0 WHERE BrokerId = ${branchId};`;
        const findUserSql = `
        SELECT U.UsersId
        FROM \`users\` U
        JOIN \`user_roles\` UL ON U.UsersId = UL.UsersId AND UL.RoleId = 6
        WHERE MappingUserId = ${branchId};`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    Bookshelf.knex.raw(findUserSql)
                        .then(findUserResult => {
                            if (findUserResult !== null) {
                                const inactiveUsersSql = `UPDATE \`users\` SET Inactive = 0 WHERE UsersId = ${findUserResult[0][0].UsersId}`;

                                Bookshelf.knex.raw(inactiveUsersSql)
                                    .then(inactiveUsersResult => {
                                        if (inactiveUsersResult !== null) {
                                            reply({
                                                isSuccess: true
                                            });
                                        }
                                    }).catch((error) => {
                                        reply(Boom.badRequest(error));
                                    });
                            }
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
}

export default new BranchController();