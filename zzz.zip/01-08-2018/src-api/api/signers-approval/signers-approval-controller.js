import Bookshelf from "../../db/database";
import Boom from "boom";
import moment from "moment";
import Comment from "../../db/model/comment";
import SignersApproval from "../../db/model/signers-approval";
import Order from "../../db/model/order";
import OrderProgressLog from "../../db/model/order-progress-log";
import {
	handleSingleQuote
} from "../../helper/common-helper";
import {
	ORDER_REQUEST_STATUS
} from "./../../constant/common-constant";
import {
	ORDER_PROGRESS_ID
} from "./../../constant/progress-constant";
import {
	NOTIFICATION_TEMPLATE_PURPOSE
} from "../../constant/common-constant";
import {
	replaceAll,
	thousandSep,
	logNotificationAndSendToVendor
} from "./../../helper/common-helper";
import sendMailCore from "../../mail/mail-helper";

class SignersApprovalController {
	constructor() { }

	getSignersApproval(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			orderId,
			status,
			requesterName
		} = request.query;
		const rawSql = `CALL GetAllSignersApproval('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId === "" ? null : orderId}, '${status}', '${requesterName}');`;

		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null) {
					reply(result[0]);
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	getSignersApprovalRequest(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			orderId
		} = request.query;
		const rawSql = `CALL GetSignersApprovalRequest('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId === "" ? null : orderId});`;

		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null) {
					result[0][0].forEach((item) => {
						item.RequestDate = item.RequestDate === null ? null : moment(item.RequestDate).format("MM/DD/YY HH:mm:ss");
						item.ApprovedDate = item.ApprovedDate === null ? null : moment(item.ApprovedDate).format("MM/DD/YY HH:mm:ss");
					});
					reply(result[0]);
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	getSignersApprovalById(request, reply) {
		const {
			identifier,
			sortColumn,
			sortDirection
		} = request.query;
		const rawSql = `call GetSignersApprovalById(${identifier}, '${sortColumn}',${sortDirection});`;
		Bookshelf.knex.raw(rawSql)
			.then((result) => {
				if (result !== null) {
					reply(result[0]);
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	updateSignerApproval(request, reply) {

		const payload = request.payload;
		let templateMail = {};
		let templateMailAgent = {};
		let templateMailReject = {};
		const signerApproval = {
			approvedBy: payload.approvedBy,
			approvalId: payload.approvalId,
			orderId: payload.orderId,
			signerId: payload.signerId,
			status: payload.status,
			mgrReason: payload.mgrReason,
			approvedDate: payload.approvedDate
		};

		const usersId = payload.usersId;
		const email = payload.email;
		const loanType = payload.loanType;
		const distance = payload.distance;
		const offerAmount = payload.offerAmount;
		const city = payload.city;
		const vendorName = payload.vendorName;
		const userName = payload.userName ? payload.userName : "";
		const fullNameAgent = payload.fullNameAgent;
		Bookshelf.transaction((trsn) => {
			SignersApproval.where({
				approvalId: signerApproval.approvalId,
				Status: ORDER_REQUEST_STATUS.OPEN
			})
				.save(signerApproval, {
					method: "update",
					require: true,
					transacting: trsn
				})
				.then(() => {
					if (signerApproval.status === ORDER_REQUEST_STATUS.APPROVED) {

						//if status is Aprroved -> change order's progress to Assigned to Vendor -> write to OrderProgressLog
						Order.where({
							OrderId: signerApproval.orderId
						})
							.save({
								SignerId: signerApproval.signerId,
								ProgressId: ORDER_PROGRESS_ID.ASSIGNED_TO_VENDOR
							}, {
								method: "update",
								require: true,
								transacting: trsn
							})
							.then(async () => {
								//save new progresslog
								await new OrderProgressLog()
									.save({
										OrderId: signerApproval.orderId,
										Activity: `${userName} is assigned to order #${signerApproval.orderId}`,
										UsersId: usersId,
										DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss")
									}, {
										method: "insert",
										transacting: trsn
									})
									// eslint-disable-next-line
									.then(() => {
										trsn.commit();
										// reply({ isSuccess: true });
										return;
									})
									// eslint-disable-next-line
									.catch((error) => {
										trsn.rollback(error);
									});

							})
							.catch((error) => {
								trsn.rollback(error);
							});
					} else {
						new OrderProgressLog().save({
							OrderId: signerApproval.orderId,
							Activity: `${userName} is removed from order #${signerApproval.orderId}`,
							UsersId: usersId,
							DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss")
						}, {
								method: "insert",
								transacting: trsn
							})
							.then(() => {
								trsn.commit();
								// reply({ isSuccess: true });
								return;
							})
							.catch((error) => {
								trsn.rollback(error);
							});
					}
				}).catch((error) => {
					trsn.rollback(error);
				});
		})
			.then(async () => {
				if (signerApproval.status === "Approved") {
					const rawSqlGetTemplate = `SELECT * FROM notification_templates nt WHERE nt.Purpose = '${NOTIFICATION_TEMPLATE_PURPOSE.OFFER_ACCEPTED_VENDOR}';`;
					await new Promise(resolve => Bookshelf.knex.raw(rawSqlGetTemplate)
						.then(result => {
							if (result[0][0]) templateMail = result[0][0];
							resolve();
						}).catch(err => {
							reply(Boom.badRequest(err));
						})
					);

					//render email content and subject
					const subject = templateMail.Subject.replace("[orderId]", signerApproval.orderId).replace("[fileNo]", signerApproval.BrokerIdNum);
					let htmlContent = templateMail.Message;

					htmlContent = replaceAll(htmlContent, "[orderId]", signerApproval.orderId);
					htmlContent = replaceAll(htmlContent, "[type]", loanType);
					htmlContent = replaceAll(htmlContent, "[aptDateTime]", signerApproval.approvedDate);
					htmlContent = replaceAll(htmlContent, "[vendorName]", vendorName);
					htmlContent = replaceAll(htmlContent, "[city]", city);
					htmlContent = replaceAll(htmlContent, "[distance]", distance);
					htmlContent = replaceAll(htmlContent, "[offerAmount]", `$${thousandSep(parseFloat(offerAmount).toFixed(2))}`);

					const mailOptions = {
						from: templateMail.FromEmail || "weborders@notarydirect.com",
						to: email,
						subject,
						html: htmlContent
					};
					sendMailCore(mailOptions, async () => {
						const rawSqlGetTemplateAgent = `SELECT * FROM notification_templates nt WHERE nt.Purpose = '${NOTIFICATION_TEMPLATE_PURPOSE.VENDOR_RECOMMENDATION_APPROVED}';`;
						await new Promise(resolve => Bookshelf.knex.raw(rawSqlGetTemplateAgent)
							.then(result => {
								if (result[0][0]) templateMailAgent = result[0][0];
								resolve();
							}).catch(err => {
								reply(Boom.badRequest(err));
							})
						);

						//render email content and subject
						const subjects = templateMailAgent.Subject.replace("[OrderID]", signerApproval.orderId).replace("[fileNo]", signerApproval.BrokerIdNum);
						let htmlContentAgent = templateMailAgent.Message;

						htmlContentAgent = replaceAll(htmlContentAgent, "[OrderID]", signerApproval.orderId);
						htmlContentAgent = replaceAll(htmlContentAgent, "[VendorName]", vendorName);
						htmlContentAgent = replaceAll(htmlContentAgent, "[AgentName]", fullNameAgent);
						const mailOptionsAgent = {
							from: templateMailAgent.FromEmail || "weborders@notarydirect.com",
							to: email,
							subject: subjects,
							html: htmlContentAgent
						};
						sendMailCore(mailOptionsAgent, (result) => {
							reply(result.error ? {
								error: result.error
							} : {
									isSuccess: true
								});
						});

					});
				} else if (signerApproval.status === "Rejected") {
					const rawSqlGetTemplate = `SELECT * FROM notification_templates nt WHERE nt.Purpose = '${NOTIFICATION_TEMPLATE_PURPOSE.RECOMMENDATION_REJECT_TO_VENDOR}';`;
					await new Promise(resolve => Bookshelf.knex.raw(rawSqlGetTemplate)
						.then(result => {
							if (result[0][0]) templateMailReject = result[0][0];
							resolve();
						}).catch(err => {
							reply(Boom.badRequest(err));
						})
					);

					//render email content and subject
					const subject = templateMailReject.Subject.replace("[Order ID]", signerApproval.orderId).replace("[fileNo]", signerApproval.BrokerIdNum);
					let htmlContent = templateMailReject.Message;

					htmlContent = replaceAll(htmlContent, "[Order ID]", signerApproval.orderId);
					htmlContent = replaceAll(htmlContent, "[vendorName]", vendorName);
					htmlContent = replaceAll(htmlContent, "[Agent Full Name]", fullNameAgent);
					const mailOptions = {
						from: templateMailReject.FromEmail || "weborders@notarydirect.com",
						to: email,
						subject,
						html: htmlContent
					};
					sendMailCore(mailOptions, (result) => {
						reply(result.error ? {
							error: result.error
						} : {
								isSuccess: true
							});
					});

				}
			})
			.catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	isUpdatableSignerApproval(request, reply) {
		const {
			orderId,
			signerId
		} = request.query;

		//get order aptDateTime
		Order.where({
			orderId
		}).fetch({
			columns: ["aptDateTime", "signerId", "progressId"]
		}).then((order) => {

			if (order.attributes.progressId === ORDER_PROGRESS_ID.CLOSED_PENDING_QC_REVIEW ||
				order.attributes.progressId === ORDER_PROGRESS_ID.CLOSED_PENDING_REVIEW_PC_RESOLUTION ||
				order.attributes.progressId === ORDER_PROGRESS_ID.CLOSING_COMPLETED ||
				order.attributes.progressId === ORDER_PROGRESS_ID.POST_CLOSE ||
				order.attributes.progressId === ORDER_PROGRESS_ID.CANCELED) {
				reply({
					case: "CLOSED_ORDER"
				});
				return;
			}

			//get signer's Order's aptDateTime
			Order.where({
				signerId
			}).fetch({
				columns: ["aptDateTime"]
			}).then((assignedOrder) => {
				//compare -> if duplicated -> return ADT_DUPLICATED
				if (assignedOrder !== null) {
					if (assignedOrder.attributes.aptDateTime !== null &&
						order.attributes.aptDateTime !== null &&
						assignedOrder.attributes.aptDateTime.toString() === order.attributes.aptDateTime.toString()) {
						reply({
							case: "ADT_DUPLICATED"
						});
						return;
					}
				}

				//already have signer
				if (order.attributes.signerId !== null && order.attributes.signerId !== undefined && order.attributes.signerId !== "") {
					reply({
						case: "SIGNER_ALREADY"
					});
					return;
				}

				reply({
					case: "SUCCESS"
				});

			}).catch((error) => {
				reply(Boom.badRequest(error));
			});

		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	addSignerApprovalAndComments(request, reply) {
		const data = request.payload;

		const {
			comments
		} = data;
		const Comments = Bookshelf.Collection.extend({
			model: Comment
		});
		const {
			signerApproval
		} = data;

		new SignersApproval().save({
			TenantId: 1,
			OrderId: signerApproval.orderId,
			RequestBy: signerApproval.userId,
			RequestDate: moment().utc().format("YY/MM/DD HH:mm:ss").toString(),
			Status: "Pending",
			SignerId: signerApproval.signerId
		}, {
				method: "insert"
			}).then((result) => {
				if (result !== null) {
					comments.map((item) => {
						item.ownerId = result.attributes.id;
					});

					const commentsAdd = Comments.forge(comments);

					commentsAdd.invokeThen("save").then((response) => {
						if (response !== null) {
							reply({
								isSuccess: true
							});
						}
					}).catch(error => {
						reply(Boom.badRequest(`${error.code}: ${error.sqlMessage}`));
					});
				}
			});
	}

	addSignerApproval(request, reply) {
		const signerApproval = request.payload;
		new SignersApproval().save({
			TenantId: 1,
			OrderId: signerApproval.orderId,
			RequestBy: signerApproval.userId,
			RequestDate: moment().utc().format("YY/MM/DD HH:mm:ss").toString(),
			Status: "Pending",
			SignerId: signerApproval.signerId
		}, {
				method: "insert"
			}).then((result) => {
				if (result !== null) {
					reply({
						isSuccess: true
					});
				}
			});
	}


	getSignersApprovalByBrokerId(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			orderId,
			status,
			requestedBy,
			brokerId
		} = request.query;
		let rawSql = "";
		if (brokerId !== "0") {
			rawSql = `CALL GetApprovalVendorRequests('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId === "" ? null : orderId}, '${status}', '${handleSingleQuote(requestedBy)}',' ${brokerId}');`;
		} else {
			rawSql = `CALL GetApprovalVendorRequestsTCE('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId === "" ? null : orderId}, '${status}', '${handleSingleQuote(requestedBy)}');`;
		}

		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null) {
					const data = {
						approvals: result[0][0],
						totalRecords: result[0][1][0].TotalRecords
					};

					reply(data);
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	getSignersApprovalBySignerId(request, reply) {
		const {
			signerId,
			orderId
		} = request.query;

		const rawSql = `SELECT ApprovalID FROM signers_approval WHERE SignerId = ${signerId} AND Status='Pending' AND OrderId = ${orderId}`;
		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result[0] !== null) {
					if (result[0].length > 0) {
						reply({
							isInvalid: false
						});
					} else {
						reply({
							isInvalid: true
						});
					}
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	updateVendorApprovalRequest(request, reply) {
		const {
			isApprove,
			approvalId,
			signerId,
			approvedBy,
			orderId,
			activity,
			reason,
			clientAgentId
		} = request.payload;
		new SignersApproval().where({
			ApprovalId: approvalId
		}).save({
			Status: isApprove ? "Approved" : "Rejected",
			ApprovedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
			ApprovedBy: approvedBy
		}, {
				method: "update"
			}).then(() => {
				new OrderProgressLog().save({
					orderId,
					DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
					activity,
					usersId: approvedBy
				}, {
						method: "insert"
					}).then(async () => {
						if (isApprove) {
							//log vendor notification
							await logNotificationAndSendToVendor(orderId, signerId, false);

							new Order().where({
								orderId
							}).save({
								signerId,
								ProgressId: ORDER_PROGRESS_ID.ASSIGNED_TO_VENDOR,
								filledDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
							}, {
									method: "update"
								}).then(() => {
									reply({
										isSuccess: true
									});
									// eslint-disable-next-line
									Bookshelf.knex.raw(`call GetDataSendMailApproval(${isApprove}, ${clientAgentId}, ${signerId}, 1, ${approvalId})`).then(data => {
										// eslint-disable-next-line
										const renderHtmlContent = (rawContent) => {
											let returnTemplate = rawContent;
											returnTemplate = replaceAll(returnTemplate, "[AgentName]", data[0][0][0].agentName);
											returnTemplate = replaceAll(returnTemplate, "[OrderID]", orderId);
											returnTemplate = replaceAll(returnTemplate, "[VendorName]", data[0][0][0].vendorName);
											returnTemplate = replaceAll(returnTemplate, "[description]", reason);

											return returnTemplate;
										};
										const mailOptions = {
											from: data[0][0][0].FromEmail,
											to: data[0][0][0].toAgentEmail,
											subject: data[0][0][0].Subject.replace("[OrderID]", `${orderId}`),
											html: renderHtmlContent(data[0][0][0].Message)
										};

										let htmlContent = data[0][1][0].Message;

										htmlContent = replaceAll(htmlContent, "[orderId]", orderId);
										htmlContent = replaceAll(htmlContent, "[type]", data[0][1][0].loanType);
										htmlContent = replaceAll(htmlContent, "[aptDateTime]", moment(data[0][1][0].aptDateTime).utc().format("MM/DD/YYYY HH:mm:ss"));
										htmlContent = replaceAll(htmlContent, "[vendorFirstName]", data[0][1][0].firstName);
										htmlContent = replaceAll(htmlContent, "[vendorLastName]", data[0][1][0].lastName);
										htmlContent = replaceAll(htmlContent, "[city]", data[0][1][0].city);
										htmlContent = replaceAll(htmlContent, "[distance]", data[0][1][0].distance);
										htmlContent = replaceAll(htmlContent, "[offerAmount]", `$${thousandSep(parseFloat(data[0][1][0].originalSignerFee).toFixed(2))}`);

										const mailSendToVendor = {
											from: data[0][1][0].FromEmail,
											to: data[0][1][0].toVendorEmail,
											subject: data[0][1][0].Subject,
											html: htmlContent
										};
										// eslint-disable-next-line
										sendMailCore(mailOptions);
										setTimeout(() => {
											sendMailCore(mailSendToVendor);
										}, 1000);
									});
								}).catch((error) => reply(Boom.badRequest(error)));
						} else {
							reply({
								isSuccess: true
							});
							// eslint-disable-next-line
							Bookshelf.knex.raw(`call GetDataSendMailApproval(${isApprove}, ${clientAgentId}, ${signerId}, 1, ${approvalId})`).then(data => {
								if (data !== null) {
									// eslint-disable-next-line
									const renderHtmlContent = (rawContent) => {
										let returnTemplate = rawContent;
										returnTemplate = replaceAll(returnTemplate, "[AgentName]", data[0][0][0].agentName);
										returnTemplate = replaceAll(returnTemplate, "[OrderID]", `${orderId}`);
										returnTemplate = replaceAll(returnTemplate, "[VendorName]", data[0][0][0].vendorName);
										returnTemplate = replaceAll(returnTemplate, "[description]", reason);

										return returnTemplate;
									};
									const mailOptions = {
										from: data[0][0][0].FromEmail,
										to: data[0][0][0].toAgentEmail,
										subject: data[0][0][0].Subject.replace("[OrderID]", `${orderId}`),
										html: renderHtmlContent(data[0][0][0].Message)
									};
									// eslint-disable-next-line
									sendMailCore(mailOptions);
								}
							});
						}
					}).catch((error) => reply(Boom.badRequest(error)));
			}).catch((error) => reply(Boom.badRequest(error)));
	}
}

export default new SignersApprovalController();