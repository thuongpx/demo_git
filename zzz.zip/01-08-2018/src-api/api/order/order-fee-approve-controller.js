import Boom from "boom";
import Bookshelf from "../../db/database";
import { handleSingleQuote, replaceAll, thousandSep, logNotificationAndSendToVendor } from "../../helper/common-helper";
import moment from "moment";
import OrderProgressLog from "../../db/model/order-progress-log";
import SignerOffer from "../../db/model/signer-offer";
import Order from "../../db/model/order";
import OrderFeeApproval from "../../db/model/order-fee-approve";
import { ORDER_PROGRESS_ID } from "./../../constant/progress-constant";
import {
    NOTIFICATION_TEMPLATE_PURPOSE
} from "../../constant/common-constant";
import sendMailCore from "../../mail/mail-helper";

class OrderFeeApproveController {
    constructor() { }

    // Get all data for Order Detail Fee screen
    getOrdersFeeApproveData(request, reply) {
        const { sortColumn, sortDirection, page, itemPerPage, orderId, feeApproved } = request.query;
        const rawQuery = `call GetOrderFeeApproveGridView('${sortColumn}', ${sortDirection === "true" ? 1 : 0}, ${page}, ${itemPerPage}, ${orderId !== undefined && orderId !== "" ? handleSingleQuote(orderId) : null}, ${feeApproved ? `'${feeApproved}'` : null})`;

        Bookshelf.knex.raw(rawQuery)
            .then(result => {

                if (result === null || !result[0] || !result[0][0]) {
                    reply({ isSuccess: false });
                    return;
                }

                const datasources = result[0][0];
                const totalRecords = result[0][1][0];

                reply({ isSuccess: true, datasources, totalRecords: totalRecords.TotalRecords });
                return;
            }).catch(err => {
                reply(Boom.badRequest(err));
                return;
            });
    }

    changeOrderFeeApproveStatus(request, reply) {
        const { feeApprovalId, feeApproved, offerStatus, orderId, signerId, userId } = request.payload;
        const rawQuery = `call ChangeOrderFeeApproveStatus(${feeApprovalId}, '${feeApproved}', '${offerStatus}', ${orderId}, ${signerId}, ${userId})`;

        Bookshelf.knex.raw(rawQuery)
            .then(result => {
                const data = Array.isArray(result[0]) ? { isSuccess: false } : result[0][0];

                reply(data);
                return;
            }).catch(err => {
                reply(Boom.badRequest(err));
                return;
            });

    }

    sendMailNotification(data, reply) { // MinhTC3
        if (!data.isSuccess) {
            return;
        }

        const { orderId } = data;

        const rawSqlGetTemplate = `SELECT * FROM notification_templates nt WHERE nt.Purpose = '${NOTIFICATION_TEMPLATE_PURPOSE.APPROVE_FEE_REQUEST_BY_AGENT}';`;
        Bookshelf.knex.raw(rawSqlGetTemplate)
            .then(result => {
                if (result[0][0]) {
                    let templateMail = result[0][0];
                    const dataToBinding = {
                        AgentName: "data",
                        OrderID: orderId,
                        OriginalFee: 20,
                        ExpectedFee: 20,
                        VendorName: "Minh",
                        description: "asd asd asd"
                    };
                    Object.keys(dataToBinding).forEach(key => {
                        templateMail = replaceAll(templateMail, key, dataToBinding[key]);
                    });

                    const { email, subject } = data;

                    const mailOptions = {
                        from: templateMail.FromEmail || "weborders@notarydirect.com",
                        to: email,
                        subject,
                        html: templateMail
                    };
                    sendMailCore(mailOptions, (rs) => {
                        reply(rs.error ? { error: rs.error } : { isSuccess: true });
                    });
                    // <p>Hello [AgentName],</p><p>Your Manager has approved the following fee increase request for the order #[OrderID]</p><p>Original Fee: [OriginalFee]</p><p>Expected Fee: [ExpectedFee]</p><p>Vendor Name: [VendorName]</p><p>Reason: [description]</p><br/><p>Regards,</p><p>The Closing Exchange</p>
                }
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getOrdersFeeApprovalRequest(request, reply) {
        const { sortColumn, sortDirection, page, itemPerPage, orderId, status, brokerId, userId, isClientFee } = request.query;
        let rawSql = "";
        if (brokerId !== "0") {
            rawSql = `call GetApprovalFeeRequests('${sortColumn}',${sortDirection},${page},${itemPerPage},'${orderId}','${status}','${brokerId}')`;
        } else {
            rawSql = `call GetApprovalFeeRequestsTCE('${sortColumn}',${sortDirection},${page},${itemPerPage},'${orderId}','${status}', ${userId === "" ? null : userId}, ${isClientFee === undefined ? null : isClientFee})`;
        }

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    const data = {
                        approvals: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    };

                    reply(data);
                }
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    updateOrdersFeeApprove(request, reply) {
        const { approval } = request.payload;
        new OrderFeeApproval().where({ feeApprovalId: approval.feeApprovalId }).save({ FeeApproved: approval.isApprove ? "Approved" : "Rejected", ApprovedBy: approval.usersId, feeApprovalDate: moment().utc().format("YYYY-MM-DD HH:mm:ss") }, { method: "update" }).then(() => {
            new OrderProgressLog().save({ orderId: approval.orderId, activity: approval.activity, dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"), usersId: approval.usersId }, { method: "insert" }).then(async () => {
                if (approval.isApprove) {
                    // log vendor notification and send notif
                    // await logNotificationAndSendToVendor(approval.orderId, approval.signerId, false);

                    // Order.where({ orderId: approval.orderId }).save({ filledDate: moment().utc().format("YYYY-MM-DD HH:mm:ss") }, { method: "update" }).then(() => { }).catch(err => {
                    //     reply(Boom.badRequest(err));
                    // });
                    Bookshelf.knex.raw(`call UpdateOrderFeeApproval('${approval.orderId}',${approval.signerId ? approval.signerId : 0},${ORDER_PROGRESS_ID.ASSIGNED_TO_VENDOR},${approval.feeDescripId},${approval.feeAmount},${approval.offerId ? approval.offerId : 0}, ${approval.isApprove}, ${approval.feeApprovalId})`)
                        .then(async result => {
                            reply({ isSuccess: true });
                            if (result !== null) {
                                if (approval.brokerId !== 0) {
                                    // eslint-disable-next-line
                                    Bookshelf.knex.raw(`call GetDataSendMailApproval(${approval.isApprove}, ${approval.clientAgentId}, ${approval.signerId},0, ${approval.feeApprovalId})`).then(data => {
                                        // let htmlContent = data[0][1][0].Message;

                                        // htmlContent = replaceAll(htmlContent, "[orderId]", approval.orderId);
                                        // htmlContent = replaceAll(htmlContent, "[type]", data[0][1][0].loanType);
                                        // htmlContent = replaceAll(htmlContent, "[aptDateTime]", moment(data[0][1][0].aptDateTime).utc().format("MM/DD/YYYY HH:mm:ss"));
                                        // htmlContent = replaceAll(htmlContent, "[vendorFirstName]", data[0][1][0].firstName);
                                        // htmlContent = replaceAll(htmlContent, "[vendorLastName]", data[0][1][0].lastName);
                                        // htmlContent = replaceAll(htmlContent, "[city]", data[0][1][0].city);
                                        // htmlContent = replaceAll(htmlContent, "[distance]", data[0][1][0].distance);
                                        // htmlContent = replaceAll(htmlContent, "[offerAmount]", `$${thousandSep(parseFloat(approval.feeAmount).toFixed(2))}`);

                                        // const mailSendToVendor = {
                                        //     from: data[0][1][0].FromEmail,
                                        //     to: data[0][1][0].toVendorEmail,
                                        //     subject: data[0][1][0].Subject,
                                        //     html: htmlContent
                                        // };
                                        // eslint-disable-next-line
                                        const renderHtmlContent = (rawContent) => {
                                            let returnTemplate = rawContent;
                                            returnTemplate = replaceAll(returnTemplate, "[AgentName]", data[0][0][0].agentName);
                                            returnTemplate = replaceAll(returnTemplate, "[OrderID]", approval.orderId);
                                            returnTemplate = replaceAll(returnTemplate, "[OriginalFee]", `$${thousandSep(parseFloat(approval.originalAmount).toFixed(2))}`);
                                            returnTemplate = replaceAll(returnTemplate, "[ExpectedFee]", `$${thousandSep(parseFloat(approval.feeAmount).toFixed(2))}`);
                                            returnTemplate = replaceAll(returnTemplate, "[VendorName]", data[0][0][0].vendorName);
                                            returnTemplate = replaceAll(returnTemplate, "[description]", approval.reason);

                                            return returnTemplate;
                                        };
                                        const mailOptions = {
                                            from: data[0][0][0].FromEmail,
                                            to: data[0][0][0].toAgentEmail,
                                            subject: data[0][0][0].Subject.replace("[OrderID]", `${approval.orderId}`),
                                            html: renderHtmlContent(data[0][0][0].Message)
                                        };
                                        // eslint-disable-next-line
                                        sendMailCore(mailOptions);

                                        // if (approval.offerId !== null && approval.offerId !== undefined) {
                                        //     // eslint-disable-next-line
                                        //     setTimeout(() => {
                                        //         sendMailCore(mailSendToVendor);
                                        //     }, (1000));
                                        // }

                                        // eslint-disable-next-line
                                    }).catch(err => {
                                        reply(Boom.badRequest(err));
                                    });
                                } else {
                                    const getEmailDataSql = `select s.LastName as vendorLastName,
                                    s.FirstName as vendorFirstName,
                                    s.Email as vendorEmail,
                                    em.FirstName as employeesFirstName,
                                    em.LastName as employeesLastName,
                                    em.Email as employeesEmail,
                                    69.1*sqrt(POWER((s.Lat - o.Lat), 2) + 0.6*POWER((s.Long - o.Long), 2)) AS distance,
                                    o.AptDateTime as aptDateTime,
                                    o.City as city,
                                    o.LoanType as loanType
                                    from order_fee_approve AS f
                                    inner join `
                                        + "`order`" +
                                        ` as o on f.OrderId=o.OrderId
                                    inner join signer as s on f.signerid = s.signerid
                                    inner join employees as em on o.RepId = em.RepId
                                    left join loan_type lo on o.LoanType = lo.LoanTypeId
                                    where f.FeeApprovalId = ${approval.feeApprovalId};`;
                                    let emailData = {};
                                    await new Promise((resolve) =>
                                        Bookshelf.knex.raw(getEmailDataSql)
                                            .then((getEmailDataResult) => {
                                                if (getEmailDataResult !== undefined) {
                                                    emailData = getEmailDataResult[0][0];
                                                }
                                                resolve();
                                            })
                                    );

                                    const rawSqlEmploy = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'Fee Request Approved Scheduler';`));
                                    const rawSqlVendor = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'Offer Accepted-Vendor' and Receiver= 'Vendor';`));

                                    Promise.all([rawSqlEmploy, rawSqlVendor])
                                        .then(values => {
                                            if (values !== null) {
                                                let subject = "";
                                                let to = "";

                                                values.forEach((item, index) => {
                                                    if (item !== null) {
                                                        switch (index) {
                                                            case 0:
                                                                {
                                                                    subject = replaceAll(item[0][0].subject, "[orderId]", approval.orderId);
                                                                    to = emailData.employeesEmail;
                                                                    break;
                                                                }
                                                            case 1:
                                                                {
                                                                    subject = item[0][0].subject;
                                                                    to = emailData.vendorEmail;
                                                                    break;
                                                                }
                                                        }
                                                        let html = item[0][0].message;
                                                        html = replaceAll(html, "[EmployeesName]", `${emailData.employeesFirstName} ${emailData.employeesLastName}`);
                                                        html = replaceAll(html, "[orderId]", approval.orderId);
                                                        html = replaceAll(html, "[RepID]", approval.orderId);
                                                        html = replaceAll(html, "[OriginalFee]", `$${thousandSep(parseFloat(approval.originalAmount).toFixed(2))}`);
                                                        html = replaceAll(html, "[ExpectedFee]", `$${thousandSep(parseFloat(approval.feeAmount).toFixed(2))}`);
                                                        html = replaceAll(html, "[VendorName]", `${emailData.vendorFirstName} ${emailData.vendorLastName}`);
                                                        html = replaceAll(html, "[Description]", approval.reason);
                                                        html = replaceAll(html, "[city]", emailData.city);
                                                        html = replaceAll(html, "[distance]", `${thousandSep(parseFloat(emailData.distance).toFixed(2))} Miles`);
                                                        html = replaceAll(html, "[offerAmount]", `$${thousandSep(parseFloat(approval.feeAmount).toFixed(2))}`);
                                                        html = replaceAll(html, "[type]", emailData.loanType);
                                                        html = replaceAll(html, "[aptDateTime]", moment(emailData.aptDateTime).utc().format("MM/DD/YYYY HH:mm:ss"));

                                                        const mailOptions = {
                                                            from: item[0][0].fromEmail,
                                                            to,
                                                            subject,
                                                            text: `Send Email`,
                                                            html
                                                        };

                                                        sendMailCore(mailOptions);
                                                    }
                                                });
                                            }
                                        });
                                }
                            }
                        }).catch(err => {
                            reply(Boom.badRequest(err));
                        });
                } else {
                    reply({ isSuccess: true });
                    if (approval.brokerId !== 0) {
                        Bookshelf.knex.raw(`call GetDataSendMailApproval(${approval.isApprove}, ${approval.clientAgentId}, ${approval.signerId},0, ${approval.feeApprovalId})`).then(data => {
                            const renderHtmlContentForVendor = (rawContent) => {
                                let returnTemplate = rawContent;
                                returnTemplate = replaceAll(returnTemplate, "[VendorName]", data[0][1][0].vendorName);
                                returnTemplate = replaceAll(returnTemplate, "[OrderID]", approval.orderId);
                                returnTemplate = replaceAll(returnTemplate, "[OriginalFee]", `$${thousandSep(parseFloat(approval.originalAmount).toFixed(2))}`);
                                returnTemplate = replaceAll(returnTemplate, "[ExpectedFee]", `$${thousandSep(parseFloat(approval.feeAmount).toFixed(2))}`);
                                returnTemplate = replaceAll(returnTemplate, "[VendorName]", data[0][1][0].vendorName);
                                returnTemplate = replaceAll(returnTemplate, "[description]", approval.reason);

                                return returnTemplate;
                            };
                            const mailOptionsVendor = {
                                from: data[0][1][0].FromEmail,
                                to: data[0][1][0].toVendorEmail,
                                subject: data[0][1][0].Subject.replace("[OrderID]", `${approval.orderId}`),
                                html: renderHtmlContentForVendor(data[0][1][0].Message)
                            };

                            const renderHtmlContent = (rawContent) => {
                                let returnTemplate = rawContent;
                                returnTemplate = replaceAll(returnTemplate, "[AgentName]", data[0][0][0].agentName);
                                returnTemplate = replaceAll(returnTemplate, "[OrderID]", approval.orderId);
                                returnTemplate = replaceAll(returnTemplate, "[OriginalFee]", `$${thousandSep(parseFloat(approval.originalAmount).toFixed(2))}`);
                                returnTemplate = replaceAll(returnTemplate, "[ExpectedFee]", `$${thousandSep(parseFloat(approval.feeAmount).toFixed(2))}`);
                                returnTemplate = replaceAll(returnTemplate, "[VendorName]", data[0][0][0].vendorName);
                                returnTemplate = replaceAll(returnTemplate, "[description]", approval.reason);

                                return returnTemplate;
                            };
                            const mailOptions = {
                                from: data[0][0][0].FromEmail,
                                to: data[0][0][0].toAgentEmail,
                                subject: data[0][0][0].Subject.replace("[OrderID]", `${approval.orderId}`),
                                html: renderHtmlContent(data[0][0][0].Message)
                            };
                            sendMailCore(mailOptions);
                            if (approval.offerId !== null && approval.offerId !== undefined) {
                                setTimeout(() => {
                                    SignerOffer.where({ offerId: approval.offerId }).save({ offerStatus: "D" }, { method: "update" }).then(() => { }).catch((error) => reply(Boom.badRequest(error)));
                                    sendMailCore(mailOptionsVendor);
                                }, (1000));
                            }
                        });
                    } else {
                        const getEmailDataSql = `select s.LastName as vendorLastName,
                        s.FirstName as vendorFirstName,
                        s.Email as vendorEmail,
                        em.FirstName as employeesFirstName,
                        em.LastName as employeesLastName,
                        em.Email as employeesEmail,
                        69.1*sqrt(POWER((s.Lat - o.Lat), 2) + 0.6*POWER((s.Long - o.Long), 2)) AS distance,
                        o.AptDateTime as aptDateTime,
                        o.City as city,
                        o.LoanType as loanType
                        from order_fee_approve AS f
                        inner join `
                            + "`order`" +
                            ` as o on f.OrderId=o.OrderId
                        inner join signer as s on f.signerid = s.signerid
                        inner join employees as em on o.RepId = em.RepId
                        left join loan_type lo on o.LoanType = lo.LoanTypeId
                        where f.FeeApprovalId = ${approval.feeApprovalId};`;
                        let emailData = {};
                        await new Promise((resolve) =>
                            Bookshelf.knex.raw(getEmailDataSql)
                                .then((getEmailDataResult) => {
                                    if (getEmailDataResult !== undefined) {
                                        emailData = getEmailDataResult[0][0];
                                    }
                                    resolve();
                                })
                        );

                        const rawSqlEmploy = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'Fee Request Rejected Scheduler';`));
                        const rawSqlVendor = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'Fee Request Rejected Vendor';`));

                        Promise.all([rawSqlEmploy, rawSqlVendor])
                            .then(values => {
                                if (values !== null) {
                                    let subject = "";
                                    let to = "";

                                    values.forEach((item, index) => {
                                        if (item !== null) {
                                            switch (index) {
                                                case 0:
                                                    {
                                                        subject = replaceAll(item[0][0].subject, "[orderId]", approval.orderId);
                                                        to = emailData.employeesEmail;
                                                        break;
                                                    }
                                                case 1:
                                                    {
                                                        subject = replaceAll(item[0][0].subject, "[orderId]", approval.orderId);
                                                        to = emailData.vendorEmail;
                                                        break;
                                                    }
                                            }
                                            let html = item[0][0].message;
                                            html = replaceAll(html, "[EmployeesName]", `${emailData.employeesFirstName} ${emailData.employeesLastName}`);
                                            html = replaceAll(html, "[orderId]", approval.orderId);
                                            html = replaceAll(html, "[OriginalFee]", `$${thousandSep(parseFloat(approval.originalAmount).toFixed(2))}`);
                                            html = replaceAll(html, "[ExpectedFee]", `$${thousandSep(parseFloat(approval.feeAmount).toFixed(2))}`);
                                            html = replaceAll(html, "[VendorName]", `${emailData.vendorFirstName} ${emailData.vendorLastName}`);
                                            html = replaceAll(html, "[Description]", approval.reason);

                                            const mailOptions = {
                                                from: item[0][0].fromEmail,
                                                to,
                                                subject,
                                                text: `Send Email`,
                                                html
                                            };

                                            sendMailCore(mailOptions);
                                        }
                                    });
                                }
                            });
                        if (approval.offerId !== null && approval.offerId !== undefined) {
                            SignerOffer.where({ offerId: approval.offerId }).save({ offerStatus: "D" }, { method: "update" }).then(() => { }).catch((error) => reply(Boom.badRequest(error)));
                        }
                    }
                }
            }).catch((error) => reply(Boom.badRequest(error)));
        }).catch((error) => reply(Boom.badRequest(error)));
    }
}

export default new OrderFeeApproveController();