import Boom from "boom";
import appConfig from "../../config/config";
import fs from "fs";
import Bookshelf from "../../db/database";
import {
    handleSingleQuote, handleSingleQuoteRawSql
} from "../../helper/common-helper";
import {
    TOOL_PAGE_DISPLAY, TOOL_LINK_DISPLAY
} from "../../constant/common-constant";

class ToolController {
    constructor() { }
    getListResource(request, reply) {

        const {
            typePage,
            pageDisplay, isClient, isVendor
        } = request.payload;

        let sqlQuery = `SELECT * FROM resources`;

        if (pageDisplay === true) {
            const listType = [];

            typePage.forEach((item, index) => {
                listType[index] = item.key;
            });

            if (listType !== null) {
                listType.forEach((item, index) => {
                    if (index === 0) {
                        sqlQuery = `${sqlQuery} WHERE (find_in_set('${listType[0]}',Views))`;
                    } else {
                        sqlQuery = `${sqlQuery} OR (find_in_set('${listType[index]}',Views))`;
                    }
                });
            }

            Bookshelf.knex.raw(sqlQuery)
                .then((result) => {
                    if (result !== null) {
                        reply({
                            isSuccess: true, isNotFound: false,
                            isStaff: true,
                            isClient: false,
                            isVendor: false,
                            listResource: result[0]
                        });
                    } else {
                        reply({
                            isSuccess: false, isNotFound: true,
                            isStaff: true,
                            isClient: false,
                            isVendor: false
                        });
                    }
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });

        } else {
            if (isClient) {
                sqlQuery = `${sqlQuery} WHERE SUBSTRING_INDEX(Views, ',', 5) LIKE ('%CLIENT_PORTAL%');`;
            } else if (isVendor) {
                sqlQuery = `${sqlQuery} WHERE SUBSTRING_INDEX(Views, ',', 5) LIKE ('%VENDOR_PORTAL%');`;
            }

            Bookshelf.knex.raw(sqlQuery)
                .then((result) => {
                    if (result !== null) {
                        reply({
                            isSuccess: true,
                            isNotFound: false,
                            isStaff: false,
                            isClient: { isClient },
                            isVendor: { isVendor },
                            listResource: result[0]
                        });
                    } else {
                        reply({
                            isSuccess: false,
                            isStaff: false,
                            isClient: { isClient },
                            isVendor: { isVendor },
                            isNotFound: true
                        });
                    }
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });

        }
        return;
    }

    downloadResources(request, reply) {
        const {
            fileName
        } = request.query;

        const filePath = `${appConfig.file.serverPath}/upload/resources/${fileName}`;

        if (fs.existsSync(filePath)) {
            fs.readFile(filePath, (err, data) => {
                if (err) reply(Boom.badRequest(err.message));
                return reply(data).header("content-disposition", `attachment; filename=${fileName}`);
            });
        } else {
            reply(Boom.badRequest(`File ${filePath} is not exists.`));
        }
    }

    getListLink(request, reply) {
        const {
            typePage,
            pageDisplay,
            isClient, isVendor
        } = request.payload;

        let listType = ``;

        typePage.forEach((item, index) => {
            if (index === 0) listType = `(`;
            listType = `${listType}'${item.key}'`;
            if (index < typePage.length - 1) {
                listType = `${listType},`;
            } else {
                listType = `${listType})`;
            }
        });

        if (pageDisplay === true) {
            const sqlQuery = `SELECT Id, LinkTitle, Link, Description, Type, Target, Views
            FROM links ${typePage.length > 0 ? `WHERE Views in ${listType}` : ""}`;

            Bookshelf.knex.raw(sqlQuery)
                .then((result) => {
                    if (result !== null) {
                        reply({
                            isSuccess: true,
                            isNotFound: false,
                            isStaff: true,
                            isClient: false,
                            isVendor: false,
                            links: result[0]
                        });
                    } else {
                        reply({
                            isSuccess: false, isNotFound: true,
                            isStaff: true,
                            isClient: false,
                            isVendor: false
                        });
                    }
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });
        } else if (isClient) {
            const sqlQuery = `SELECT Id, LinkTitle, Link, Description, Type, Target
            FROM links
            WHERE Views IN ('CLIENT')`;

            Bookshelf.knex.raw(sqlQuery)
                .then((result) => {
                    if (result !== null) {
                        reply({
                            isSuccess: true,
                            isNotFound: false,
                            isStaff: false,
                            isClient: true,
                            isVendor: false,
                            links: result[0]
                        });
                    } else {
                        reply({
                            isSuccess: false, isNotFound: true,
                            isStaff: false,
                            isClient: true,
                            isVendor: false
                        });
                    }
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });
        } else if (isVendor) {
            const sqlQuery = `SELECT Id, LinkTitle, Link, Description, Type, Target
            FROM links
            WHERE Views IN ('VENDOR')`;

            Bookshelf.knex.raw(sqlQuery)
                .then((result) => {
                    if (result !== null) {
                        reply({
                            isSuccess: true,
                            isNotFound: false,
                            isStaff: false,
                            isClient: false,
                            isVendor: true,
                            links: result[0]
                        });
                    } else {
                        reply({
                            isSuccess: false, isNotFound: true,
                            isStaff: false,
                            isClient: false,
                            isVendor: true
                        });
                    }
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });
        }
        return;

    }

    addResourcesToDataBase(request, reply) {
        const {
            title, resource, description, views
        } = request.payload;


        const sqlQuery = `INSERT INTO resources (Resource, Title, Description, Views)
                VALUES ('${resource}', '${handleSingleQuoteRawSql(title)}', '${handleSingleQuoteRawSql(description)}','${views}');
        `;

        Bookshelf.knex.raw(sqlQuery).then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });
            }
            reply({
                isSuccess: false,
                isNotFound: true
            });
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }

    deleteResourcesById(request, reply) {
        const {
            Id
        } = request.query;

        const sqlQuery = `DELETE FROM resources WHERE Id = ${Id}`;

        Bookshelf.knex.raw(sqlQuery).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });


    }

    deleteResourceFileById(request, reply) {
        const {
            Id
        } = request.query;

        fs.unlink(`${appConfig.file.serverPath}/upload/resources/${Id}`, (err) => {
            if (err) {
                reply(Boom.badRequest(err));
                return;
            }
        });
    }

    editResourcesById(request, reply) {
        const {
            resourceId, title, resource, description
        } = request.payload;

        const sqlQuery = `UPDATE resources SET
        Resource = '${resource}', Title = '${handleSingleQuoteRawSql(title)}', Description = '${handleSingleQuoteRawSql(description)}'
            WHERE Id = ${resourceId}`;

        Bookshelf.knex.raw(sqlQuery).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    getListFaqByViews(request, reply) {
        const { typePage } = request.payload;

        const listType = [];

        typePage.forEach((item, index) => {
            listType[index] = item.key;
        });

        let sqlQuery = `SELECT Id, Question, Answer, Views FROM faq `;

        if (listType !== null) {
            listType.forEach((item, index) => {
                if (index === 0) {
                    sqlQuery = `${sqlQuery} WHERE (find_in_set('${listType[0]}',Views))`;
                } else {
                    sqlQuery = `${sqlQuery} OR (find_in_set('${listType[index]}',Views))`;
                }
            });
        }

        Bookshelf.knex.raw(sqlQuery)
            .then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        isNotFound: false,
                        isStaff: true,
                        isClient: false,
                        isVendor: false,
                        faqs: result[0]
                    });
                } else {
                    reply({
                        isSuccess: false, isNotFound: true,
                        isStaff: true,
                        isClient: false,
                        isVendor: false
                    });
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
        return;
    }


    getFaqsByQuestion(request, reply) {
        const { question, isClient, isVendor } = request.query;

        const newQuestion = (question === "" || question === undefined) ? "" : handleSingleQuote(question);

        let sqlQuery = `SELECT Id, Question, Answer, Views
        FROM faq
        WHERE Question LIKE '%${newQuestion}%'`;

        if (isClient === "true") {
            sqlQuery = `${sqlQuery} AND SUBSTRING_INDEX(Views, ',', 5) LIKE ('%CLIENT_PORTAL%')`;
        }
        if (isVendor === "true") {
            sqlQuery = `${sqlQuery} AND SUBSTRING_INDEX(Views, ',', 5) LIKE ('%VENDOR_PORTAL%')`;
        }

        Bookshelf.knex.raw(sqlQuery)
            .then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        faqs: result[0]
                    });
                    return;
                }
                reply({ isSuccess: false, isNotFound: true });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        return;
    }

    getPageDisplayFromConstant(request, reply) {
        reply({
            listPage: TOOL_PAGE_DISPLAY
        });
    }

    getLinksDisplayFromConstant(request, reply) {
        reply({
            listPage: TOOL_LINK_DISPLAY
        });
    }

    addLinksToDataBase(request, reply) {
        const {
            linkTitle, link, type, target, description, views
        } = request.payload;

        const sqlQuery = `INSERT INTO links (LinkTitle, Link, Description, Type, Target, Views)
                VALUES ('${handleSingleQuoteRawSql(linkTitle)}', '${handleSingleQuoteRawSql(link)}', '${handleSingleQuoteRawSql(description)}', '${type}', '${target}', '${views}');
        `;

        Bookshelf.knex.raw(sqlQuery).then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });

            }
            reply({
                isSuccess: false,
                isNotFound: true
            });
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }

    deleteLinksById(request, reply) {
        const {
            Id
        } = request.query;

        const sqlQuery = `DELETE FROM links WHERE Id = ${Id}`;

        Bookshelf.knex.raw(sqlQuery).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });

    }

    editLinksById(request, reply) {
        const {
            linkId, Title, Link, type, target, Description, views
        } = request.payload;

        const sqlQuery = `UPDATE links SET
            LinkTitle = '${handleSingleQuoteRawSql(Title)}', Link = '${handleSingleQuoteRawSql(Link)}', Description = '${handleSingleQuoteRawSql(Description)}', Type = '${type}', Target = '${target}', Views = '${views}'
            WHERE Id = ${linkId}`;

        Bookshelf.knex.raw(sqlQuery).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    addFaqsToDatabase(request, reply) {
        const {
            question, answer, views
        } = request.payload;

        const newQuestion = (question === "" || question === undefined) ? "" : handleSingleQuoteRawSql(question);
        const newAnswer = (answer === "" || answer === undefined) ? "" : handleSingleQuoteRawSql(answer);

        const sqlQuery = `INSERT INTO faq (Question, Answer, Views) 
        VALUES ( '${newQuestion}', '${newAnswer}', '${views}');;
        `;

        Bookshelf.knex.raw(sqlQuery).then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });
            }
            reply({
                isSuccess: false,
                isNotFound: true
            });
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }

    editFaqById(request, reply) {
        const {
            faqId, question, answer
        } = request.payload;

        const newQuestion = (question === "" || question === undefined) ? "" : handleSingleQuoteRawSql(question);
        const newAnswer = (answer === "" || answer === undefined) ? "" : handleSingleQuoteRawSql(answer);

        const sqlQuery = `UPDATE faq SET
            Question = '${newQuestion}', Answer ='${newAnswer}'
            WHERE Id = ${faqId};`;

        Bookshelf.knex.raw(sqlQuery).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    deleteFaqById(request, reply) {
        const {
            Id
        } = request.query;

        const sqlQuery = `DELETE FROM faq WHERE Id = ${Id}`;

        Bookshelf.knex.raw(sqlQuery).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });

    }
}

export default new ToolController();