import VendorCategoriesRatingController from "./vendor-categories-rating-controller";
const routes = [{
    path: "/vendor-categories-rating/getVendorCategoriesRating",
    method: "GET",
    handler: VendorCategoriesRatingController.getVendorCategoriesRating
},
{
    path: "/vendor-categories-rating/updateVendorRatingSetting",
    method: "POST",
    handler: VendorCategoriesRatingController.updateVendorRatingSetting
}];

export default routes;