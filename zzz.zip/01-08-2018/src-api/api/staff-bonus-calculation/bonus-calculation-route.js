import BonusCalculationController from "./bonus-calculation-controller";

const routes = [{
        path: "/bonus/getBonusCalculationData",
        method: "GET",
        handler: BonusCalculationController.getBonusCalculationData
    },
    {
        path: "/bonus/updateBonusCalculationData",
        method: "POST",
        handler: BonusCalculationController.updateBonusCalculationData
    }
];

export default routes;