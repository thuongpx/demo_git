import UserController from "./user-controller";

const routes = [{
    path: "/user/checkExistUser",
    method: "GET",
    config: {
        auth: false
    },
    handler: UserController.checkExistUser
}, {
    path: "/user/resetPassword",
    method: "GET",
    handler: UserController.resetPassword
}, {
    path: "/user/resetPasswordByUserId",
    method: "GET",
    config: {
        auth: false
    },
    handler: UserController.resetPasswordByUserId
},
{
    path: "/user/getStaffInfo",
    method: "GET",
    handler: UserController.getStaffInfo
},
{
    path: "/user/saveStaffProfile",
    method: "POST",
    config: {
        auth: false,
        payload: {
            maxBytes: 5242880
        }
    },
    handler: UserController.saveStaffProfile
}, {
    path: "/user/generateDefaultLogin",
    method: "GET",
    handler: UserController.generateDefaultLogin,
    config: {
        auth: false
    }
}, {
    path: "/user/addVendor",
    method: "POST",
    config: {
        auth: false
    },
    handler: UserController.addVendor
}, {
    path: "/user/addBranch",
    method: "POST",
    handler: UserController.addBranch
}, {
    path: "/user/getBillingInformationDefault",
    method: "GET",
    handler: UserController.getBillingInformationDefault
},
{
    path: "/user/updateBillingInformation",
    method: "POST",
    config: {
        auth: "jwt",
        payload: {
            maxBytes: 5242880
        }
    },
    handler: UserController.updateBillingInformation
},
{
    path: "/user/getClientBilling",
    method: "GET",
    config: {
        auth: false
    },
    handler: UserController.getClientBilling
},
{
    path: "/user/getAdditionalInformationDefault",
    method: "GET",
    handler: UserController.getAdditionalInformationDefault
},
{
    path: "/user/updateAdditionalInformation",
    method: "POST",
    handler: UserController.updateAdditionalInformation
},
{
    path: "/user/emailVerification",
    method: "POST",
    config: {
        auth: false
    },
    handler: UserController.emailVerification
},
{
    path: "/user/checkSignerFirstLogin",
    method: "GET",
    handler: UserController.checkSignerFirstLogin
},
{
    path: "/user/resendEmailVerification",
    method: "POST",
    config: {
        auth: false
    },
    handler: UserController.resendEmailVerification
},
{
    path: "/user/addClient",
    method: "POST",
    config: {
        auth: false
    },
    handler: UserController.addClientUser
},
{
    path: "/user/resendVerificationUserEmail",
    method: "POST",
    config: {
        auth: false
    },
    handler: UserController.resendVerificationUserEmail
},
{
    path: "/user/checkUserCreds",
    method: "GET",
    config: {
        auth: false
    },
    handler: UserController.checkUserCreds
},
{
    path: "/user/sendForgotPasswordEmail",
    method: "POST",
    config: {
        auth: false
    },
    handler: UserController.sendForgotPasswordEmail
},
{
    path: "/user/checkForgotPasswordSecurityCode",
    method: "GET",
    config: {
        auth: false
    },
    handler: UserController.checkForgotPasswordSecurityCode
},
{
    path: "/user/changeUserPassword",
    method: "POST",
    config: {
        auth: false
    },
    handler: UserController.changeUserPassword
},
{
    path: "/user/resetUserPassword",
    method: "POST",
    config: {
        auth: false
    },
    handler: UserController.resetUserPassword
},
{
    path: "/user/checkUserFirstLogin",
    method: "GET",
    config: {
        auth: false
    },
    handler: UserController.checkUserFirstLogin
},
{
    path: "/user/checkUserNeedToResetPassword",
    method: "GET",
    config: {
        auth: false
    },
    handler: UserController.checkUserNeedToResetPassword
},
{
    path: "/user/clientInviteUser",
    method: "GET",
    config: {
        auth: false
    },
    handler: UserController.clientInviteUser
},
{
    path: "/user/getClientsUserByRole",
    method: "GET",
    handler: UserController.getClientsUserByRole
},
{
    path: "/user/updateUserStatus",
    method: "PUT",
    config: {
        auth: false
    },
    handler: UserController.updateUserStatus
},
{
    path: "/user/checkResetPasswordSecurityCode",
    method: "POST",
    config: {
        auth: false
    },
    handler: UserController.checkResetPasswordSecurityCode
},
{
    path: "/user/checkPasswordExpired",
    method: "GET",
    handler: UserController.checkPasswordExpired
},
{
    path: "/user/fetchBillingInformation",
    method: "GET",
    handler: UserController.fetchBillingInformation
},
{
    path: "/user/getProfilePicture",
    method: "GET",
    handler: UserController.getProfilePicture
},
{
    path: "/user/changePassword",
    method: "POST",
    config: {
        auth: false
    },
    handler: UserController.changePassword
}
];

export default routes;