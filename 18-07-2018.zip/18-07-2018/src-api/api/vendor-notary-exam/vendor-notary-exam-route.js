import VendorNotaryExam from "./vendor-notary-exam-controller";

const routes = [
    {
        path: "/notaryexam/getCheckValidExamAndGetTestQaByTestId",
        method: "GET",
        config: {
            auth: false
        },
        handler: VendorNotaryExam.getCheckValidExamAndGetTestQaByTestId
    }
];

export default routes;