import VendorManageController from "./vendor-manage-controller";

const routes = [
    {
        path: "/vendorManage/getOrdersVendorList",
        method: "GET",
        handler: VendorManageController.getOrdersVendorList
    },
    {
        path: "/vendorManage/checkClientSatisfiedVendor",
        method: "GET",
        handler: VendorManageController.checkClientSatisfiedVendor
    },
    {
        path: "/vendorManage/getDefaultVendorSearch",
        method: "GET",
        handler: VendorManageController.getDataInit
    },
    {
        path: "/vendorManage/checkVendorPassedExam",
        method: "GET",
        config: {
            auth: false
        },
        handler: VendorManageController.checkVendorPassedExam
    }
];

export default routes;