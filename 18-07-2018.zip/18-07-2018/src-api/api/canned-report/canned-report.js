import Bookshelf from "../../db/database";
import {
    hasStringValue
} from "../../helper/common-helper";

export const getOrderTypes = async () => {
    const rawSql = `SELECT LoanType FROM loan_type`;

    const rs = await Bookshelf.knex.raw(rawSql);

    if (rs) {
        return rs[0];
    }

    return [];
};

const _buildSqlWhereClause = (searchObject) => {
    const {
        orderStatus,
        orderType,
        dayFrom,
        dayTo,
        month,
        year,
        scheduler,
        customerName,
        date,
        milestone
    } = searchObject;
    let whereStr = "";
    let tSql = "";
    let isShowAll = true;

    // order type
    if (orderType && orderType.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < orderType.length; i++) {
            tSql += ` OR OrderType LIKE '${orderType[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // order status
    if (orderStatus && orderStatus.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < orderStatus.length; i++) {
            tSql += ` OR OrderStatus LIKE '${orderStatus[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // month
    // day from
    // day to
    if (month && month.length > 0) {
        tSql = "1 != 1";

        for (let i = 0; i < month.length; i++) {
            const fromDate = `${year}-${month[i].value}-${dayFrom}`;
            const toDate = `${year}-${month[i].value}-${dayTo}`;

            tSql += ` OR (OrderDate >= '${fromDate}' AND OrderDate <= '${toDate}')`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // day to
    if (date) {
        tSql = "1 != 1";
        tSql += ` OR (Date LIKE '${date}')`;

        whereStr += ` AND (${tSql})`;
    }

    //scheduler
    if (scheduler && scheduler.length) {
        tSql = "1 != 1";
        for (let i = 0; i < scheduler.length; i++) {
            tSql += ` OR FullName LIKE '${scheduler[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }
    //customer
    if (customerName && customerName.length) {
        tSql = "1 != 1";
        for (let i = 0; i < customerName.length; i++) {
            tSql += `OR customerName LIKE '${customerName[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }
    //milestone
    if (milestone && milestone.length > 0) {
        tSql = "1 != 1";
        switch (milestone) {
            case "1":
                tSql += ` OR TotalClosedOrders >= 1 AND TotalClosedOrders < 25`;
                break;
            case "25":
                tSql += ` OR TotalClosedOrders >= 25 AND TotalClosedOrders < 50`;
                break;
            case "50":
                tSql += ` OR TotalClosedOrders >= 50 AND TotalClosedOrders < 100`;
                break;
            case "100":
                tSql += ` OR TotalClosedOrders >= 100 AND TotalClosedOrders < 250`;
                break;
            case "250":
                tSql += ` OR TotalClosedOrders >= 250 AND TotalClosedOrders < 500`;
                break;
            case "500":
                tSql += ` OR TotalClosedOrders >= 250 AND TotalClosedOrders < 500`;
                break;
        }
        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }


    return {
        whereStr,
        isShowAll
    };
};


export const buildSqlCountQuery = (viewName, criterias) => {
    const {
        searchObject
    } = criterias;

    let sqlStr = `SELECT Count(*) AS Num FROM ${viewName} WHERE 1 = 1`;
    let isShowAll = true;

    const whereObj = _buildSqlWhereClause(searchObject);

    isShowAll = whereObj.isShowAll;
    sqlStr += whereObj.whereStr;

    return {
        sqlStr,
        isShowAll
    };
};

export const buildSqlQuery = (viewName, criterias) => {
    const {
        searchObject,
        options
    } = criterias;

    let sqlStr = "";
    let isShowAll = true;
    sqlStr = `SELECT * FROM ${viewName} WHERE 1 = 1`;
    const whereObj = _buildSqlWhereClause(searchObject);

    isShowAll = whereObj.isShowAll;
    sqlStr += whereObj.whereStr;

    if (options) {
        const {
            // sortColumn,
            // sortDirection,
            page,
            itemPerPage
        } = options;

        // offset and limit
        if (hasStringValue(page) && hasStringValue(itemPerPage)) {
            sqlStr += ` LIMIT ${itemPerPage} OFFSET ${(page - 1) * itemPerPage}`;
        }

        // sort column && sort direction
        // if (hasStringValue(sortColumn) && hasStringValue(sortDirection)) {
        //     sqlStr += ` ORDER BY ${sortColumn}`
        // }
    }

    // eslint-disable-next-line
    //console.log(`SQL string:= ${sqlStr}`);
    console.log("sqlStr: ", sqlStr);
    return {
        sqlStr,
        isShowAll
    };
};

export const getScheduler = async () => {
    const rawSql = `SELECT CONCAT(e.FirstName, " ", e.LastName) AS FullName
                    FROM employees e
                    WHERE 
                        e.Status = 0
                        AND e.Accounting = 0
                        AND e.Manager is null
                        AND e.Active = 1;`;

    const rs = await Bookshelf.knex.raw(rawSql);

    if (rs) {
        return rs[0];
    }

    return [];
};