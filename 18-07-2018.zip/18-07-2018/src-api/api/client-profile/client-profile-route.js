import ClientProfileController from "./client-profile-controller";

const routes = [{
    path: "/client-profile/getClientProfiles",
    method: "GET",
    handler: ClientProfileController.getClientProfiles
}, {
    path: "/client-profile/updateClientProfiles",
    method: "POST",
    handler: ClientProfileController.updateClientProfiles
}, {
    path: "/client-profile/updateClientBillingDetail",
    method: "POST",
    handler: ClientProfileController.updateClientBillingDetail
}];

export default routes;