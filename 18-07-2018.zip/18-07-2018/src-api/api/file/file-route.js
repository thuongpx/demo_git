import FileController from "./file-controller";
import config from "../../config/config";

const routes = [{
    path: "/file/uploadFile",
    method: "POST",
    config: {
        auth: false,
        payload: {
            output: "stream",
            maxBytes: config.file.maxBytes, // max: 50 MB
            allow: "multipart/form-data" // important
        }
    },
    handler: FileController.uploadFile
}];


export default routes;