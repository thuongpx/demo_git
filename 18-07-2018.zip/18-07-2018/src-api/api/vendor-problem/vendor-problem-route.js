import VendorProblemController from "./vendor-problem-controller";
const routes = [
    {
        path: "/vendor-problem/getVendorProblems",
        method: "GET",
        handler: VendorProblemController.getVendorProblems
    },
    {
        path: "/vendor-problem/vendorProblem",
        method: "GET",
        handler: VendorProblemController.getProblemDetail
    },
    {
        path: "/vendor-problem/getVendorProblemStatus",
        method: "GET",
        handler: VendorProblemController.getProblemStatus
    },
    {
        path: "/vendor-problem/initVendorProblemSearch",
        method: "GET",
        handler: VendorProblemController.initVendorProblemSearch
    },
    {
        path: "/vendor-problem/getAllVendorProblems",
        method: "GET",
        handler: VendorProblemController.getAllVendorProblems
    }
];

export default routes;