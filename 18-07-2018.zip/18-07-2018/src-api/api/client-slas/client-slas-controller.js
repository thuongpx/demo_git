import Boom from "boom";
import Bookshelf from "../../db/database";
import BrokerSlas from "../../db/model/client-slas";
import Slas from "../../db/model/slas";

class ClientSlasController {
    getClientSlasById(request, reply) {
        const { id, roleType } = request.query;
        if (roleType === "Client") {
            const rawSql = `select Id, BrokerId, SLA, DefaultFrom, DefaultTo, \`From\`, \`To\` from broker_slas where BrokerId = ${id}`;

            Bookshelf.knex.raw(rawSql)
                .then(result => {
                    if (result !== null) {
                        reply({
                            isSuccess: true,
                            listClientSlas: result[0]
                        });
                    }
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                });
        } else {
            const rawSql = `select Id, SLA, DefaultFrom, DefaultTo, \`From\`, \`To\` from slas`;

            Bookshelf.knex.raw(rawSql)
                .then(result => {
                    if (result !== null) {
                        reply({
                            isSuccess: true,
                            listClientSlas: result[0]
                        });
                    }
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                });
        }
    }

    updateClientSlasById(request, reply) {
        const { listClientSlasNew, roleType } = request.payload;

        if (listClientSlasNew.length > 0) {
            if (roleType === "Client") {
                listClientSlasNew.forEach(item => {
                    if (item.Id > 0) {
                        BrokerSlas.where({ Id: item.Id }).save(item, { method: "update" }).then(() => {
                            reply({ isSuccess: true });
                        }).catch(error => Boom.badRequest(error));
                    }
                });
            } else {
                listClientSlasNew.forEach(item => {
                    if (item.Id > 0) {
                        Slas.where({ Id: item.Id }).save(item, { method: "update" }).then(() => {
                            reply({ isSuccess: true });
                        }).catch(error => Boom.badRequest(error));
                    }
                });
            }
        }
    }
}
export default new ClientSlasController();