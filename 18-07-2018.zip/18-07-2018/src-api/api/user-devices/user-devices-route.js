import UserDevicesController from "./user-devices-controller";
const routes = [
    {
        path: "/mobile/userDevices/signInOutDevice",
        method: "POST",
        handler: UserDevicesController.signInOutDevice
    }
];

export default routes;