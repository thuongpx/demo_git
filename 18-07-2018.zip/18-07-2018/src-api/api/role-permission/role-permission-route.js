import RolePermissionController from "./role-permission-controller";

const routes = [
    {
        path: "/rolePermission/updateRolePermissions",
        method: "PUT",
        handler: RolePermissionController.updateRolePermissions
    },
    {
        path: "/rolesPermissions/getRolesPermissions",
        method: "GET",
        handler: RolePermissionController.getRolesPermissions
    }];

export default routes;