DROP FUNCTION IF EXISTS `GetAlertPosition`;

DELIMITER $$

CREATE FUNCTION `GetAlertPosition`(
	role varchar(255),
	userId int,
    alertId int
) RETURNS int(11)
BEGIN
	DECLARE returnPosition INT;
    SET returnPosition = 0;
    
    IF (role = 'Client') 
		THEN SELECT x.position INTO returnPosition FROM (SELECT t1.*, @rownum := @rownum + 1 AS position FROM (SELECT
			op.progressLogId,
			op.orderId
            FROM `order` as o
            LEFT JOIN `order_progress_log` as op ON o.OrderId=op.orderId 
            Where op.ProgressType = 1 and op.UsersId <> accountId
            AND (o.BrokerId=userId or o.BrokerId in (select Brokerid from `broker` where `broker`.GID = userId)) 
            ORDER BY op.DateLog DESC) t1, (SELECT @rownum := 0) r) x where x.progressLogId = alertId;
	ELSE IF  (role = 'Vendor') 
		THEN SELECT x.position INTO returnPosition FROM (SELECT t1.*, @rownum := @rownum + 1 AS position FROM (SELECT op.progressLogId,
			op.orderId
            FROM `order` as o
            LEFT JOIN `order_progress_log` as op ON o.OrderId=op.orderId
            Where op.ProgressType = 1 and op.UsersId <> accountId and o.SignerId = userId AND op.DateLog >= o.FilledDate
            order by op.DateLog desc) t1, (SELECT @rownum := 0) r) x where x.progressLogId = alertId;
	ELSE IF (role = 'Agent') 
		THEN SET returnPosition = 0;
		END IF;
    END IF;
    END IF;
RETURN returnPosition;
END$$

DELIMITER ;