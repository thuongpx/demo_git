DROP FUNCTION IF EXISTS `CalculateBusinessHourByWorkingTime`;

DELIMITER $$

CREATE FUNCTION `CalculateBusinessHourByWorkingTime`(
startDateTime DATETIME, 
endDateTime DATETIME, 
workStartTime TIME,
workEndTime TIME
) RETURNS INT
BEGIN
    DECLARE startDate DATE;
    DECLARE endDate DATE;
    DECLARE startTime TIME;
    DECLARE endTime TIME;
    DECLARE dailyWorkingTime INT;

    DECLARE totalMinutes INT;
    
    DECLARE currentDate DATE;
    
    SET startDate= DATE(startDateTime);
    SET endDate = DATE(endDateTime);
    
    SET startTime = TIME(startDateTime);
    SET endTime = TIME(endDateTime);
    
    SET dailyWorkingTime = FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, startTime))/60);
    
    IF(startTime < workStartTime)
		THEN SET startTime  = workStartTime;
    END IF;
    
     IF(startTime > workEndTime)
		THEN SET startTime  = workEndTime;
    END IF;
    
    IF(endTime > workEndTime)
		THEN set endTime = workEndTime;
	END IF;
    
    IF(endTime < workStartTime)
		THEN set endTime = workStartTime;
	END IF;
    
	SET currentDate = startDate;
    SET totalMinutes = 0;
    
    WHILE(currentDate <= endDate)
	DO 
		IF(currentDate <> startDate AND currentDate <> endDate)
			THEN SET totalMinutes = totalMinutes + dailyWorkingTime;
		ELSEIF(currentDate =  startDate AND currentDate <> endDate)
			THEN SET totalMinutes = totalMinutes + FLOOR(TIME_TO_SEC(TIMEDIFF(workEndTime, startTime))/60);
		ELSEIF(currentDate <>  startDate AND currentDate = endDate)
			THEN SET totalMinutes = totalMinutes + FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, workStartTime))/60);
		ELSE
			SET totalMinutes = totalMinutes + FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, startTime))/60);
        END IF;
        
        SET currentDate = DATE_ADD(currentDate,INTERVAL 1 DAY);
        
	END WHILE;
    
    IF(totalMinutes < 0)
		THEN SET totalMinutes = 0;
	END IF;
    
	RETURN totalMinutes;
END