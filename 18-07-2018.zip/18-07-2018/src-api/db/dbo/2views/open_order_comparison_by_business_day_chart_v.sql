DROP VIEW IF EXISTS `open_order_comparison_by_business_day_chart_v`;

DELIMITER $$

CREATE VIEW `open_order_comparison_by_business_day_chart_v`
AS

	SELECT 
        `o`.`OrderId` AS `OrderId`,
        MONTH(`o`.`OrderDate`) AS `OrderMonth`,
        DAYOFMONTH(`o`.`OrderDate`) AS `OrderDay`,
        YEAR(`o`.`OrderDate`) AS `OrderYear`,
        `lt`.`LoanType` AS `OrderType`
    FROM
        (`order` `o`
        JOIN `loan_type` `lt` ON ((`o`.`LoanType` = `lt`.`LoanTypeId`)))

$$

DELIMITER ;