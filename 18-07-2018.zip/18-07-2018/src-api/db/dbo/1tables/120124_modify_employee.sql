DELIMITER $$
CREATE PROCEDURE `alter_table_employees` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'employees' AND 
                            COLUMN_NAME = 'IsDeleted') THEN
		ALTER TABLE `employees` ADD COLUMN `IsDeleted` BIT;
	END IF;
END$$

DELIMITER ;

call alter_table_employees();

DROP PROCEDURE IF EXISTS `alter_table_employees`;