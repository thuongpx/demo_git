DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
    -- change column size
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'vendor_test_result' AND 
                            COLUMN_NAME = 'StartDate' AND
                            COLUMN_NAME = 'EndDate') THEN
	BEGIN
		ALTER TABLE `vendor_test_result` 
        ADD COLUMN `StartDate` DATETIME NULL,
        ADD COLUMN `EndDate` DATETIME NULL;
	END;
    END IF;
END$$

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;