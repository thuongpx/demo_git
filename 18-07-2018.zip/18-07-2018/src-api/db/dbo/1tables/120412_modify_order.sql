DROP PROCEDURE IF EXISTS `alter_table_order`;

DELIMITER $$
CREATE PROCEDURE `alter_table_order` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order' AND 
                            COLUMN_NAME = 'IsNeedPreCall') THEN
	BEGIN
		ALTER TABLE `order` 
		ADD COLUMN `IsNeedPreCall` BIT NULL;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_order();

DROP PROCEDURE IF EXISTS `alter_table_order`;

