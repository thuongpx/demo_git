DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	-- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_problem' AND 
                            COLUMN_NAME = 'IsClientContacted') THEN
	BEGIN
		ALTER TABLE `order_problem`
        ADD COLUMN `IsClientContacted` BIT;
	END;
    END IF;
    
    -- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_problem' AND 
                            COLUMN_NAME = 'EmailGenerated') THEN
	BEGIN
		ALTER TABLE `order_problem`
        ADD COLUMN `EmailGenerated` BIT;
	END;
    END IF;
    
    -- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_problem' AND 
                            COLUMN_NAME = 'WhoContacted') THEN
	BEGIN
		ALTER TABLE `order_problem`
        ADD COLUMN `WhoContacted` VARCHAR(50);
	END;
    END IF;

    -- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_problem' AND 
                            COLUMN_NAME = 'FixedTime') THEN
	BEGIN
		ALTER TABLE `order_problem`
        ADD COLUMN `FixedTime` DATETIME NULL;
	END;
    END IF;

    
END$$

DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;