CREATE TABLE IF NOT EXISTS `signer_history` (
	`HistoryId` INT(11) NOT NULL AUTO_INCREMENT,
    `OrderId` INT(11) NULL,
    `SignerId` INT(11) NULL,
    `Status` VARCHAR(20),
    `HistoryDate` DATETIME,
    PRIMARY KEY (`HistoryId`),
    KEY `orderid_signer_history_idx` (`OrderId`),
    CONSTRAINT `orderid_signer_history` FOREIGN KEY(`OrderId`) 
		REFERENCES `order` (`OrderId`) ON UPDATE NO ACTION ON DELETE NO ACTION,
    KEY `signerid_signer_history_idx` (`SignerId`),
    CONSTRAINT `signerid_signer_history` FOREIGN KEY(`SignerId`)
		REFERENCES `signer` (`SignerId`) ON UPDATE NO ACTION ON DELETE NO ACTION
);