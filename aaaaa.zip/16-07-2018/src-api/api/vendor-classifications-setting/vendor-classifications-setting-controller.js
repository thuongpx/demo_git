import Bookshelf from "../../db/database";
import VendorCategories from "../../db/model/vendor-categories";
import VendorCatTestTaken from "../../db/model/vendor-cat-testtaken";
import Boom from "boom";


class VendorClassificationsSettingController {
    constructor() { }

    getVendorClassifications(request, reply) {
        const catSql = "select * From vendor_categories ORDER BY CatId";
        const testSql = `Select v.CatId, t.TestId, t.TestName From vendor_categories AS v 
                            INNER JOIN vendor_cat_testtaken AS vt ON v.CatId = vt.CatId 
                            INNER JOIN test_info AS t ON vt.TestId = t.TestId;`;
        // const allTestSql = "Select  TestId , TestName From test_info ORDER BY TestId";
        const allTestSql = `SELECT distinct TI.TestId, TestName FROM test_info TI inner join training_program_test TPT 
                            on TI.TestId = TPT.TestId where
                            ProgramId in (SELECT ProgramId FROM training_programs where ForVendor = 1 and IsPublished = 1)
                            order by TestDesc`;
        const colorSql = "select Color from vendor_categories";
        const queue = [];

        queue.push(Promise.resolve(Bookshelf.knex.raw(catSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(testSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(allTestSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(colorSql)));

        Promise.all(queue)
            .then((result) => {
                if (result !== null) {
                    const categories = result[0][0];
                    const testTaken = result[1][0];
                    const tests = result[2][0];
                    const dataColor = result[3][0];
                    reply({ categories, testTaken, tests, dataColor });
                }

                return;
            }).catch((error) => {
                reply(Boom.badRequest(error));

            });
    }

    addVendorCategoryClassifications(request, reply) {
        const { catName, color } = request.payload;
        let minRMOrder = 0;

        if (catName === "Reverse Mortgage") {
            minRMOrder = 20;
        }

        new VendorCategories().save({
            CatName: catName,
            Color: color,
            MinOrder: 50,
            MinRating: 3,
            MinRMOrder: minRMOrder

        },
            { method: "insert" }).then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));

            });
    }

    async deleteVendorCategory(request, reply) {
        const { catId } = request.payload;

        await VendorCatTestTaken.where({ catId }).destroy().then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });

            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

        await VendorCategories.where({ catId }).destroy().then((result2) => {
            if (result2 !== null) {
                reply({
                    isSuccess: true
                });

            }
        }).catch((error) => {
            reply(Boom.badRequest(error));

        });
    }

    updateVendorCategory(request, reply) {
        const vendorCategory = request.payload;

        VendorCategories.where({ CatId: vendorCategory.catId }).save(vendorCategory, { method: "update" }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });

            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
        return;
    }

    checkExistCatName(request, reply) {
        const vendorCategory = request.payload;

        VendorCategories.where({ CatName: vendorCategory.CatName }).count("*").then((count) => {
            const isExist = count > 0;
            reply({ isExist });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

        return;
    }

    async updateVendorClassifications(request, reply) {
        const { vendorCat, testTaken } = request.payload;
        const queue = [];

        if (testTaken !== undefined && testTaken.length > 0) {
            // delete
            const deleteSql = `DELETE FROM vendor_cat_testtaken;`;
            await new Promise(resolve => {
                Bookshelf.knex.raw(deleteSql).then(() => {
                    resolve();
                });
            });

            // add
            let insertSql = `INSERT INTO vendor_cat_testtaken (CatId, TestId) values `;
            let i = 0;

            testTaken.map((test) => {
                insertSql += `(${test.CatId}, ${test.TestId})`;
                if (++i !== testTaken.length) insertSql += `, `;
            });
            await new Promise(resolve => {
                Bookshelf.knex.raw(insertSql).then(() => {
                    resolve();
                });
            });

        }

        if (vendorCat !== undefined && vendorCat.length > 0) {
            vendorCat.map((catListUpdate) => {
                queue.push(Promise.resolve(VendorCategories.where({ CatId: catListUpdate.CatId }).save(catListUpdate, { method: "update" })));
            });
        }

        Promise.all(queue).then(() => {
            reply({ isSuccess: true });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

        return reply;

    }

    // reset all data
    async resetVendorCategory(request, reply) {
        const insertSQL = "INSERT INTO `vendor_categories` (`CatName`, `MinOrder`,`MinRating`, `MinRMOrder`,`Color`) VALUES ('Elite', '50','3', null,'lnr-home'),('Reverse Mortgage ','50','3', '20', 'lnr-dice'),('eClosing/ eNotarization', '50','3', null,'lnr-gift'),('Auto Lending group', '20','3', null,'lnr-unlink'),('Structured Settlements', '20','3', null,'lnr-frame-expand')";
        const deleteAllVendorCategory = `Delete From vendor_categories`;
        const deleteAllVendorCatTesttaken = `DELETE FROM vendor_cat_testtaken;`;

        await new Promise((resolve) => Bookshelf.knex.raw(deleteAllVendorCatTesttaken)
            .then(result => {
                if (result === null && result[0] === null) {
                    reply({
                        isSuccess: true
                    });
                }
                resolve();
            }));

        await new Promise((resolve) => Bookshelf.knex.raw(deleteAllVendorCategory)
            .then(result => {
                if (result === null && result[0] === null) {
                    reply({
                        isSuccess: true
                    });
                }
                resolve();
            }));

        await new Promise((resolve) => Bookshelf.knex.raw(insertSQL)
            .then(result => {
                if (result !== null && result[0] !== null) {
                    reply({
                        isSuccess: true
                    });
                }
                resolve();
            }));

    }

}

export default new VendorClassificationsSettingController();