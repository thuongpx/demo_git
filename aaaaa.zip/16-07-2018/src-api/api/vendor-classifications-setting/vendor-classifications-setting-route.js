import VendorClassificationsSettingController from "./vendor-classifications-setting-controller";

const routes = [
    {
        path: "/vendor-classifications/getVendorClassificationsSetting",
        method: "GET",
        handler: VendorClassificationsSettingController.getVendorClassifications
    },
    {
        path: "/vendor-classifications/addVendorCategoryClassifications",
        method: "POST",
        handler: VendorClassificationsSettingController.addVendorCategoryClassifications
    },
    {
        path: "/vendor-classifications/deleteVendorCategory",
        method: "POST",
        handler: VendorClassificationsSettingController.deleteVendorCategory
    },
    {
        path: "/vendor-classifications/updateVendorCategory",
        method: "POST",
        handler: VendorClassificationsSettingController.updateVendorCategory
    },
    {
        path: "/vendor-classifications/updateVendorClassifications",
        method: "POST",
        handler: VendorClassificationsSettingController.updateVendorClassifications
    },
    {
        path: "/vendor-classifications/checkExistCatName",
        method: "POST",
        handler: VendorClassificationsSettingController.checkExistCatName
    },
    {
        path: "/vendor-classifications/resetVendorCategory",
        method: "POST",
        handler: VendorClassificationsSettingController.resetVendorCategory
    }

];

export default routes;