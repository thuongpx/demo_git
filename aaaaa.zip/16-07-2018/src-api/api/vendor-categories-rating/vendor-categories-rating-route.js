import VendorCategoriesRatingController from "./vendor-categories-rating-controller";
const routes = [{
    path: "/vendor-categories-rating/getVendorCategoriesRating",
    method: "GET",
    handler: VendorCategoriesRatingController.getVendorCategoriesRating
}];

export default routes;