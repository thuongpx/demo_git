import Boom from "boom";
import Bookshelf from "../../db/database";
//import BrokerSlas from "../../db/model/client-slas";
//import Slas from "../../db/model/slas";

class VendorCategoriesRatingController {
    getVendorCategoriesRating(request, reply) {
        console.log("test");
        const { id, roleType } = request.query;
        // if (roleType === "Client") {
        //     const rawSql = `select Id, BrokerId, SLA, DefaultFrom, DefaultTo, \`From\`, \`To\` from broker_slas where BrokerId = ${id}`;

        //     Bookshelf.knex.raw(rawSql)
        //         .then(result => {
        //             if (result !== null) {
        //                 reply({
        //                     isSuccess: true,
        //                     listClientSlas: result[0]
        //                 });
        //             }

        //             return reply;
        //         }).catch((error) => {
        //             reply(Boom.badRequest(error));

        //             return reply;
        //         });
        // } else {
        const rawSql = `select vcr.Id, vcr.Category, vcr.Percent, vcr.RatingId, vcr.MaxPoint, vcr.ThresholdFrom, vcr.ThresholdTo, cr.Unit from vendor_categories_rating vcr
        inner join categories_rating cr on vcr.RatingId = cr.Id`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        listVendorCategoryRating: result[0]
                    });
                }
                console.log(result[0]);
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        //}
    }
}
export default new VendorCategoriesRatingController();