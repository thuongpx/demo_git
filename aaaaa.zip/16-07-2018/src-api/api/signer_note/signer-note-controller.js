import Boom from "boom";
import SignerNote from "./../../db/model/signer-note";
import moment from "moment";
import Bookshelf from "../../db/database";

class SignerNoteController {
    constructor() { }
    getSignerNotes(request, reply) {
        const { signerId } = request.query;
        const rawSql = `
                        SELECT sn.noteId,sn.signerId,sn.note,sn.createdDate,e.profilePicture,sn.createdBy,u.userName
                        FROM signer_notes sn
                        LEFT JOIN users u on u.usersId = sn.createdBy
                        LEFT JOIN employees e on e.repId = u.mappingUserId
                        WHERE signerId = ${signerId} order by createdDate`;
        Bookshelf.knex.raw(rawSql).then((result) => {
            const response = result[0];
            if (response) {
                response.forEach(x => {
                    if (x.profilePicture) {
                        x.profilePicture = x.profilePicture.toString();
                    }
                });
            }
            reply(response);
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    addSignerNote(request, reply) {
        const { signerId, note, createdBy } = request.payload;
        new SignerNote().save({ createdBy, note, signerId, createdDate: moment().utc().format("YYYY-MM-DD HH:mm:ss") }, { method: "insert" }).then(() => reply({ isSuccess: true })).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}
export default new SignerNoteController();