import IssueController from "./issue-controller";

const routes = [{
    path: "/issue/getIssues",
    method: "GET",
    handler: IssueController.getIssues
},
{
    path: "/issue/addIssue",
    method: "POST",
    handler: IssueController.addIssue
},
{
    path: "/issue/updateIssue",
    method: "POST",
    handler: IssueController.updateIssue
},
{
    path: "/issue/deleteIssue",
    method: "POST",
    handler: IssueController.deleteIssue
},
{
    path: "/issue/getIssueById",
    method: "GET",
    handler: IssueController.getIssueById
},
{
    path: "/issue/getIssuesNumberById",
    method: "GET",
    handler: IssueController.getIssuesNumberById
},
{
    path: "/issue/getCorrectionType",
    method: "GET",
    handler: IssueController.getCorrectionType
}
];


export default routes;