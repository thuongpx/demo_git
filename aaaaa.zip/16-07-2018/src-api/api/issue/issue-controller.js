// import { authConstant } from "../../server/constant";
import Issue from "../../db/model/issue";
import Boom from "boom";
import Bookshelf from "../../db/database";
import moment from "moment";
import sendMailCore from "../../mail/mail-helper";
import {
	isBuffer,
	bufferToBoolean,
	replaceAll
} from "../../helper/common-helper";
import OrderProgressLog from "../../db/model/order-progress-log";

class IssueController {
	constructor() { }

	getIssueById(request, reply) {
		const {
			problemId
		} = request.query;
		const rawSql = `SELECT op.problemId, op.orderId, sn.firstName as 'signerFirstName',
		sn.lastname as 'signerLastName', ps.description as 'status',
		pt.description as 'type',em.firstName as 'repFirstName',
		em.lastname as 'repLastName', op.date, op.enteredBy as enteredById, us.username as 'enteredBy', op.trackingNumber,
		op.mistake,op.acknowledged,op.apologySentDate,op.notes,op.resolution,
		usap.username as 'approvedBy',usrs.username as 'resolvedBy', od.IsSelfService as 'isSelfService', od.BorrowerId as borrowerId, em.Email as toEmail, sn.Email as toVendorEmail, pt1.description AS subType,
		op.IsClientContacted AS isClientContacted, op.WhoContacted AS whoContacted, (CASE WHEN op.FixedTime IS NULL THEN 0 ELSE 1 END) AS isFixed
		FROM order_problem op
		LEFT JOIN signer sn on sn.signerId = op.signerId
		LEFT JOIN problem_status ps on ps.id = op.status
		LEFT JOIN problem_types pt on pt.id= op.type
		LEFT JOIN problem_types pt1 on pt1.id= op.SubType
		LEFT JOIN employees em on em.repId = op.repId
		LEFT JOIN users us on us.usersId = op.enteredBy
		LEFT JOIN users usap on usap.usersId = op.approvedBy
		LEFT JOIN users usrs on usrs.usersId = op.resolvedBy
		LEFT JOIN ` +
			"`order`" +
			` od on op.OrderId = od.OrderId 
		WHERE op.problemId = ${problemId}`;
		Bookshelf.knex.raw(rawSql).then((result) => {
			if (result !== null) {
				result = result[0][0];
				Object.keys(result).forEach((key) => {
					const value = result[key];
					if (isBuffer(value)) {
						result[key] = bufferToBoolean(value);
					}
				});
				reply(result);
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return;
	}

	getIssues(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			orderId
		} = request.query;
		Bookshelf.knex.raw(`call GetOrderIssuesByOrderId(${orderId},'${sortColumn}',${sortDirection},${page},
			${itemPerPage})`)
			.then((result) => {
				if (result !== null) {
					reply({
						data: result[0][0],
						totalRecords: result[0][1][0].TotalRecords,
						types: result[0][2]
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});

		return reply;
	}

	addIssue(request, reply) {
		const issue = request.payload;
		delete issue.isEmailLender;
		delete issue.isEmailVendor;
		issue.mistake = issue.mistake === "1";
		new Issue(issue).save({
			date: moment().utc().format("YYYY-MM-DD HH:mm:ss")
		}, {
				method: "insert"
			}).then(() => {
				new OrderProgressLog().save({
					orderId: issue.orderId,
					activity: "Problem Added",
					dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
					usersId: issue.enteredBy
				}, {
						method: "insert"
					}).then(() => {
						reply({
							isSuccess: true
						});
					}).catch((error) => reply(Boom.badRequest(error)));
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	getIssuesNumberById(request, reply) {
		const {
			userId,
			isAgent
		} = request.query;
		let whereQuery = "";

		if (isAgent) {
			whereQuery = ` where op.Status in (1,2) AND ag.AgentId = ${userId}`;
		} else {
			whereQuery = ` where op.Status = 3 AND br.BrokerID = ${userId}`;
		}

		const currentDate = moment().subtract(365, "day").format("YYYY-MM-DD");
		const dateFrom = moment(currentDate).utc().format("YYYY-MM-DD HH:mm:ss").toString();
		const rawSql = `SELECT count(op.ProblemId) as issuesRequestCount from order_problem op
		left join ` +
			"`order`" +
			` o on op.OrderId=o.OrderId
		left join agent ag ON ag.AgentId = o.AgentId
		left join broker br ON br.BrokerID = o.BrokerId
		${whereQuery}
		and op.Date >= '${dateFrom}';`;

		Bookshelf.knex.raw(rawSql).then(result => {
			if (result !== null) {
				reply(result[0][0]);
			}
		}, error => {
			reply(Boom.badRequest(error));
		});
	}

	updateIssue(request, reply) {
		const issue = request.payload;
		const { isAddProgress, usersId, dataEmail, userName, enteredById, orderId, problemId, vendorFirstName, vendorLastName, toEmail, emailVendor } = issue;

		const rawUserTypeSql = Promise.resolve(Bookshelf.knex.raw(`select GetUserType(${enteredById}) as UserType, GetFullNameOfUser(${enteredById}) as FullName;`));
		const rawResolvedFullServiceSql = Promise.resolve(Bookshelf.knex.raw(`select * from notification_templates where Purpose = 'Problem Resolved - TCE';`));
		const rawResolvedSelfServiceSql = Promise.resolve(Bookshelf.knex.raw(`select * from notification_templates where Purpose = 'Problem Resolved - Vendor - Self Service';`));
		const rawApproveFullServiceSql = Promise.resolve(Bookshelf.knex.raw(`select * from notification_templates where Purpose = 'Problem Aprroved - TCE';`));
		const rawApproveSelfServiceSql = Promise.resolve(Bookshelf.knex.raw(`select * from notification_templates where Purpose = 'Problem Approved - Vendor - Self Service';`));
		const rawRejectFullServiceSql = Promise.resolve(Bookshelf.knex.raw(`select * from notification_templates where Purpose = 'Problem Rejected - TCE';`));
		const rawRejectSelfServiceSql = Promise.resolve(Bookshelf.knex.raw(`select * from notification_templates where Purpose = 'Problem Rejected - Vendor - Self Service';`));
		const rawGetBorrowerInfoSql = Promise.resolve(Bookshelf.knex.raw(`SELECT LastName as borrowerLastName FROM borrower WHERE BorrowerId = ${dataEmail ? dataEmail.borrowerId : null}`));

		delete issue.isAddProgress;
		delete issue.usersId;
		delete issue.dataEmail;
		delete issue.userName;
		delete issue.enteredById;
		delete issue.vendorFirstName;
		delete issue.vendorLastName;
		delete issue.toEmail;
		delete issue.emailVendor;

		let activity = "";
		let comment = "";
		let resolutionStr = "";

		if (dataEmail !== undefined && dataEmail !== null) {
			dataEmail.comments.forEach(item => {
				comment = `${comment} <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;${item.Description}`;
			});
			dataEmail.resolutions.forEach(item => {
				resolutionStr = `${resolutionStr}  <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;${item.resolution}`;
			});
		}

		Issue.where({
			problemId: issue.problemId
		}).save(issue, {
			method: "update"
		}).then(() => {
			switch (issue.status) {
				case 2:
					activity = "Problem Acknowledged";
					rawUserTypeSql.then(result => {
						if (result !== null && result[0] !== null) {
							const userType = result[0][0].UserType;
							const fullName = result[0][0].FullName;
							const mailTo = userType === "Staff" ? "TCE" : "Agent";
							const rawAcknowledgedSql = Promise.resolve(Bookshelf.knex.raw(`select * from notification_templates where Purpose = 'Problem Acknowledged - ${mailTo}';`));
							rawAcknowledgedSql.then(ret => {
								let message = ret[0][0].Message;
								let subject = ret[0][0].Subject;
								const fromEmail = ret[0][0].FromEmail;

								subject = replaceAll(subject, ["[orderId]"], `${orderId}`);
								message = replaceAll(message, ["[orderId]"], `${orderId}`);
								message = replaceAll(message, ["[FullName]"], `${fullName}`);
								message = replaceAll(message, ["[vendorFirstName]"], `${vendorFirstName}`);
								message = replaceAll(message, ["[vendorLastName]"], `${vendorLastName}`);
								message = replaceAll(message, ["[problemId]"], `${problemId}`);

								sendMailCore({
									from: fromEmail,
									subject,
									html: message,
									to: toEmail
								});
							});
						}
					});
					break;
				case 3:
					activity = `Problem Resolve by ${userName}`;
					Promise.all([rawResolvedFullServiceSql, rawGetBorrowerInfoSql, rawResolvedSelfServiceSql]).then(result => {
						if (result !== null && result[0] !== null) {
							if (!dataEmail.isSelfService) {
								let messageStaff = result[0][0][0].Message;
								let subjectStaff = result[0][0][0].Subject;
								const fromEmailStaff = result[0][0][0].FromEmail;
								const toEmailStaff = dataEmail.toEmail;

								messageStaff = replaceAll(messageStaff, ["[first_name]"], `${dataEmail.repFirstName}`);
								messageStaff = replaceAll(messageStaff, ["[last_name]"], `${dataEmail.repLastName}`);
								messageStaff = replaceAll(messageStaff, ["[problemId]"], `${issue.problemId}`);
								messageStaff = replaceAll(messageStaff, ["[resolution_notes]"], `${resolutionStr}`);
								subjectStaff = replaceAll(subjectStaff, ["[OrderID]"], `${issue.orderId}`);
								subjectStaff = replaceAll(subjectStaff, ["[ClientID]"], `${usersId}`);
								subjectStaff = replaceAll(subjectStaff, ["[LastName]"], `${(result[1][0][0] !== undefined && result[1][0][0] !== null) ? result[1][0][0].borrowerLastName : "N/A"}${" "}`);

								sendMailCore({
									from: fromEmailStaff,
									subject: subjectStaff,
									html: messageStaff,
									to: "corrections@theclosingexchange.com"
								});

								sendMailCore({
									from: fromEmailStaff,
									subject: subjectStaff,
									html: messageStaff,
									to: toEmailStaff
								});
							}

							if (dataEmail.mistake && emailVendor) {
								let messageVendor = result[2][0][0].Message;
								let subjectVendor = result[2][0][0].Subject;
								const fromEmailVendor = result[2][0][0].FromEmail;
								const toEmailVendor = dataEmail.toVendorEmail;

								messageVendor = replaceAll(messageVendor, ["[first_name]"], `${dataEmail.signerFirstName}`);
								messageVendor = replaceAll(messageVendor, ["[last_name]"], `${dataEmail.signerLastName}`);
								messageVendor = replaceAll(messageVendor, ["[problemId]"], `${issue.problemId}`);
								messageVendor = replaceAll(messageVendor, ["[resolution_notes]"], `${resolutionStr}`);
								subjectVendor = replaceAll(subjectVendor, ["[OrderID]"], `${issue.orderId}`);
								subjectVendor = replaceAll(subjectVendor, ["[ClientID]"], `${usersId}`);
								subjectVendor = replaceAll(subjectVendor, ["[LastName]"], `${(result[1][0][0] !== undefined && result[1][0][0] !== null) ? result[1][0][0].borrowerLastName : "N/A"}${" "}`);

								sendMailCore({
									from: fromEmailVendor,
									to: toEmailVendor,
									subject: subjectVendor,
									html: messageVendor
								});
							}
						}

					});
					break;
				case 4:
					activity = `Problem Approve by ${userName}`;
					Promise.all([rawApproveFullServiceSql, rawGetBorrowerInfoSql, rawApproveSelfServiceSql]).then(result => {
						if (result !== null && result[0] !== null) {
							if (!dataEmail.isSelfService) {
								let messageStaff = result[0][0][0].Message;
								let subjectStaff = result[0][0][0].Subject;
								const fromEmailStaff = result[0][0][0].FromEmail;
								const toEmailStaff = dataEmail.toEmail;

								messageStaff = replaceAll(messageStaff, ["[first_name]"], `${dataEmail.repFirstName}`);
								messageStaff = replaceAll(messageStaff, ["[last_name]"], `${dataEmail.repLastName}`);
								messageStaff = replaceAll(messageStaff, ["[problemId]"], `${issue.problemId}`);
								messageStaff = replaceAll(messageStaff, ["[comment]"], `${comment ? comment : "N/A"}`);
								subjectStaff = replaceAll(subjectStaff, ["[OrderID]"], `${issue.orderId}`);
								subjectStaff = replaceAll(subjectStaff, ["[ClientID]"], `${usersId}`);
								subjectStaff = replaceAll(subjectStaff, ["[LastName]"], `${(result[1][0][0] !== undefined && result[1][0][0] !== null) ? result[1][0][0].borrowerLastName : "N/A"}${" "}`);

								sendMailCore({
									from: fromEmailStaff,
									subject: subjectStaff,
									html: messageStaff,
									to: "corrections@theclosingexchange.com"
								});

								sendMailCore({
									from: fromEmailStaff,
									subject: subjectStaff,
									html: messageStaff,
									to: toEmailStaff
								});
							}

							if (dataEmail.mistake && emailVendor) {
								let messageVendor = result[2][0][0].Message;
								let subjectVendor = result[2][0][0].Subject;
								const fromEmailVendor = result[2][0][0].FromEmail;
								const toEmailVendor = dataEmail.toVendorEmail;

								messageVendor = replaceAll(messageVendor, ["[first_name]"], `${dataEmail.signerFirstName}`);
								messageVendor = replaceAll(messageVendor, ["[last_name]"], `${dataEmail.signerLastName}`);
								messageVendor = replaceAll(messageVendor, ["[problemId]"], `${issue.problemId}`);
								messageVendor = replaceAll(messageVendor, ["[comment]"], `${comment ? comment : "N/A"}`);
								subjectVendor = replaceAll(subjectVendor, ["[OrderID]"], `${issue.orderId}`);
								subjectVendor = replaceAll(subjectVendor, ["[ClientID]"], `${usersId}`);
								subjectVendor = replaceAll(subjectVendor, ["[LastName]"], `${(result[1][0][0] !== undefined && result[1][0][0] !== null) ? result[1][0][0].borrowerLastName : "N/A"}${" "}`);

								sendMailCore({
									from: fromEmailVendor,
									to: toEmailVendor,
									subject: subjectVendor,
									html: messageVendor
								});
							}
						}

					});
					break;
				case 5:
					activity = `Problem Reject by ${userName}`;
					Promise.all([rawRejectFullServiceSql, rawGetBorrowerInfoSql, rawRejectSelfServiceSql]).then(result => {
						if (result !== null && result[0] !== null) {
							if (!dataEmail.isSelfService) {
								let messageStaff = result[0][0][0].Message;
								let subjectStaff = result[0][0][0].Subject;
								const fromEmailStaff = result[0][0][0].FromEmail;
								const toEmailStaff = dataEmail.toEmail;

								messageStaff = replaceAll(messageStaff, ["[first_name]"], `${dataEmail.repFirstName}`);
								messageStaff = replaceAll(messageStaff, ["[last_name]"], `${dataEmail.repLastName}`);
								messageStaff = replaceAll(messageStaff, ["[problemId]"], `${issue.problemId}`);
								messageStaff = replaceAll(messageStaff, ["[comment]"], `${comment ? comment : "N/A"}`);
								subjectStaff = replaceAll(subjectStaff, ["[OrderID]"], `${issue.orderId}`);
								subjectStaff = replaceAll(subjectStaff, ["[ClientID]"], `${usersId}`);
								subjectStaff = replaceAll(subjectStaff, ["[LastName]"], `${(result[1][0][0] !== undefined && result[1][0][0] !== null) ? result[1][0][0].borrowerLastName : "N/A"}${" "}`);

								sendMailCore({
									from: fromEmailStaff,
									subject: subjectStaff,
									html: messageStaff,
									to: "corrections@theclosingexchange.com"
								});

								sendMailCore({
									from: fromEmailStaff,
									subject: subjectStaff,
									html: messageStaff,
									to: toEmailStaff
								});
							}

							if (dataEmail.mistake && emailVendor) {
								let messageVendor = result[2][0][0].Message;
								let subjectVendor = result[2][0][0].Subject;
								const fromEmailVendor = result[2][0][0].FromEmail;
								const toEmailVendor = dataEmail.toVendorEmail;

								messageVendor = replaceAll(messageVendor, ["[first_name]"], `${dataEmail.signerFirstName}`);
								messageVendor = replaceAll(messageVendor, ["[last_name]"], `${dataEmail.signerLastName}`);
								messageVendor = replaceAll(messageVendor, ["[problemId]"], `${issue.problemId}`);
								messageVendor = replaceAll(messageVendor, ["[comment]"], `${comment ? comment : "N/A"}`);
								subjectVendor = replaceAll(subjectVendor, ["[OrderID]"], `${issue.orderId}`);
								subjectVendor = replaceAll(subjectVendor, ["[ClientID]"], `${usersId}`);
								subjectVendor = replaceAll(subjectVendor, ["[LastName]"], `${(result[1][0][0] !== undefined && result[1][0][0] !== null) ? result[1][0][0].borrowerLastName : "N/A"}${" "}`);

								sendMailCore({
									from: fromEmailVendor,
									to: toEmailVendor,
									subject: subjectVendor,
									html: messageVendor
								});
							}
						}

					});
					break;
			}
			if (isAddProgress) {
				new OrderProgressLog().save({
					orderId: issue.orderId,
					activity,
					dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
					usersId,
					ProgressType: 1
				}, {
						method: "insert"
					}).then(() => {
						reply({
							isSuccess: true
						});
					}).catch((error) => reply(Boom.badRequest(error)));
			} else {
				reply({
					isSuccess: true
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	// Delete a issue of order
	deleteIssue(request, reply) {
		const problemId = request.payload;

		Issue.where(problemId).destroy().then((result) => {
			if (result !== null) {
				reply({
					isSuccess: true
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return reply;
	}

	getCorrectionType(request, reply) {
		const getCorrectionType = Promise.resolve(Bookshelf.knex.raw(`Select * from problem_types WHERE ParentId IS NULL`));
		const getCorrectionSubType = Promise.resolve(Bookshelf.knex.raw(`Select * from problem_types WHERE ParentId IS NOT NULL`));

		Promise.all([getCorrectionType, getCorrectionSubType]).then(result => {
			if (result !== null) {
				reply({
					correctionType: result[0][0],
					correctionSubType: result[1][0]
				});
			}

		}).catch(error => {
			reply(Boom.badRequest(error));
		});
	}
}

export default new IssueController();