DROP FUNCTION IF EXISTS `DetectSelfService`;

DELIMITER $$
CREATE FUNCTION `DetectSelfService`
(
	brokerId INT, 
    orderCity VARCHAR(50), 
    orderState VARCHAR(2)
) RETURNS BIT
BEGIN
	DECLARE isUserCalendar BIT;
    DECLARE isUseGeography BIT;
    DECLARE isUseVolume BIT;
    
    DECLARE isValidUseCalendar BIT;
    DECLARE isValidUseVolume BIT;
    DECLARE isValidGeography BIT;

    DECLARE ordersDirectly BIT;
	DECLARE fullFill BIT;
    
    DECLARE totalOrderToday INT;
        
    SELECT 
		`AssignOrdersDirectly`,
        `TceFullFill`
	INTO ordersDirectly, fullFill
	FROM `broker` b
    WHERE b.`BrokerID` = brokerId;
    
    IF (ordersDirectly IS NULL) THEN
		SET ordersDirectly = false;
    END IF;
    
    IF (fullFill IS NULL) THEN
		SET fullFill = false;
    END IF;
	
    IF (NOT ordersDirectly) THEN
		RETURN false;
	END IF;
    
    IF (ordersDirectly AND NOT fullFill) THEN
		RETURN true;
    END IF;
    
    -- count number of order in current day
    SELECT
		COUNT(OrderId)
	INTO totalOrderToday
	FROM `order` o
    WHERE `BrokerID` = brokerId AND DATE(o.OrderDate) = DATE(UTC_TIMESTAMP());
    
    IF (totalOrderToday IS NULL) THEN
		SET totalOrderToday = 0;
    END IF;
    
    -- check config
	SELECT 
		csc.`UseCalendar`,
        csc.`UseGeography`,
        csc.`UseVolume`,
        DAY(UTC_TIMESTAMP()) <= csc.`CutoffDate`,
        totalOrderToday < csc.`OrderPerDay`,
        csc.`State1` LIKE CONCAT('%', orderState, '%') AND IF(csc.`MSA1` IS NOT NULL, csc.`MSA1` LIKE CONCAT('%', orderCity, '%'), TRUE)
	INTO
		isUserCalendar,
        isUseGeography,
        isUseVolume,
        isValidUseCalendar,
        isValidUseVolume,
        isValidGeography
	FROM `client_services_config` csc WHERE csc.ClientID = brokerId AND csc.`EffecttiveDate` IS NOT NULL
    ORDER BY csc.`EffecttiveDate` DESC LIMIT 0,1;
	
    IF (NOT isUserCalendar AND NOT isUseGeography AND NOT isUseVolume) THEN
		RETURN false;
	END IF;
    
    IF (isUserCalendar AND NOT isValidUseCalendar) THEN
		RETURN false;
	END IF;
    
    IF (isUseGeography AND NOT isValidGeography) THEN
		RETURN false;
    END IF;
    
    IF (isUseVolume AND NOT isValidUseVolume) THEN
		RETURN false;
    END IF;    
    
	RETURN true;
END$$

DELIMITER ;