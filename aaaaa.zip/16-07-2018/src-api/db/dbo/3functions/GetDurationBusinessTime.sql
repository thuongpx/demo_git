DROP FUNCTION IF EXISTS `GetDurationBusinessTime`;

DELIMITER $$

CREATE FUNCTION `GetDurationBusinessTime`(
startDateTime DATETIME, 
endDateTime DATETIME, 
timeZone INT
) RETURNS INT
BEGIN
	DECLARE startDateTimeLocal DATETIME;
    DECLARE startDateLocal DATE;
    DECLARE endDateTimeLocal DATETIME;
    DECLARE endDateLocal DATE;
    DECLARE currentDateTime DATETIME;
    DECLARE isClosed BIT;
    DECLARE isHoliday BIT;
    DECLARE isClosedHoliday BIT DEFAULT 0;
    DECLARE dayOfWeek VARCHAR(50);
    
    DECLARE startCalculatedDateTime DATETIME;
    DECLARE endCalculatedDateTime DATETIME;
    DECLARE startOfCurrentDateTime DATETIME;
    DECLARE endOfCurrentDateTime DATETIME;
    
    DECLARE workStartTime TIME;
    DECLARE workEndTime TIME;
    
    DECLARE holidayOffStartTime TIME;
    DECLARE holidayOffEndTime TIME;
    
    DECLARE endCurrentDateTime DATETIME;
    DECLARE startCurrentDateTime DATETIME;
    
    DECLARE currentDate DATE;
    DECLARE currentTime TIME;
    
    DECLARE tempDateTime DATETIME;
    DECLARE IsNegativeMinutes BIT DEFAULT 0;
    
    DECLARE totalMinutes INT DEFAULT 0;
    
    IF(startDateTime > endDateTime)
		THEN SET tempDateTime = startDateTime;
			 SET startDateTime = endDateTime;
             SET endDateTime = tempDateTime;
             SET IsNegativeMinutes = 1;
	END IF;
    
	SET startDateTimeLocal = DATE_ADD(startDateTime, INTERVAL timeZone HOUR);
    SET endDateTimeLocal = DATE_ADD(endDateTime, INTERVAL timeZone HOUR);
    SET endDateLocal =  DATE(endDateTimeLocal);
    SET startDateLocal = DATE(startDateTimeLocal);
    
    SET currentDateTime = startDateTimeLocal;
    
    WHILE(DATE(currentDateTime) <= endDateLocal)
     DO
		SET currentDate = DATE(currentDateTime);
		SET currentTime = TIME(currentDateTime);
        
        SELECT TIME(bh.OpenTime),TIME(bh.CloseTime), bh.isClose
		INTO workStartTime, workEndTime, isClosed
        FROM business_hours bh WHERE bh.dayOfWeek = DAYOFWEEK(currentDateTime);
        
		SET startOfCurrentDateTime= CONVERT(CONCAT(currentDate,' ','00:00:00'), DATETIME);
        SET endOfCurrentDateTime= CONVERT(CONCAT(currentDate,' ','23:59:59'), DATETIME);
		
        SELECT bhe.CloseTime, bhe.OpenTime, bhe.Closed, (CASE WHEN COUNT(bhe.OpenTime) > 0 THEN 1 ELSE 0 END)
        INTO holidayOffEndTime, holidayOffStartTime, isClosedHoliday, isHoliday FROM biz_hours_except bhe 
						WHERE currentDate BETWEEN DATE(bhe.OpenTime) AND DATE(bhe.CloseTime) LIMIT 0,1;
		
		IF(isClosed = 0 OR isClosed IS NULL) 
        THEN
			IF (currentDate <> startDateLocal AND currentDate <> endDateLocal)
				THEN SET startCalculatedDateTime = startOfCurrentDateTime;
					 SET endCalculatedDateTime = endOfCurrentDateTime;
            ELSEIF (currentDate = startDateLocal AND currentDate <> endDateLocal)
				THEN SET startCalculatedDateTime = currentDateTime;
					 SET endCalculatedDateTime = endOfCurrentDateTime;
			ELSEIF (currentDate <> startDateLocal AND currentDate = endDateLocal)
				THEN SET startCalculatedDateTime = startOfCurrentDateTime;
					 SET endCalculatedDateTime = endDateTimeLocal;
			ELSE 	 SET startCalculatedDateTime = currentDateTime;
					 SET endCalculatedDateTime = endDateTimeLocal;
			END IF;	
            
            IF(isHoliday = 1 AND (isClosedHoliday = 0 OR isClosedHoliday IS NULL))
				THEN SET totalMinutes = totalMinutes + 
                CalculateBusinessHourByOffTime(TIME(startCalculatedDateTime),TIME(endCalculatedDateTime),'04:30:00','18:30:00',holidayOffStartTime,holidayOffEndTime);
			ELSEIF(isHoliday = 0) 				
				THEN SET totalMinutes = totalMinutes + 
			    CalculateBusinessHourByWorkingTime(startCalculatedDateTime,endCalculatedDateTime,workStartTime,workEndTime);				
			END IF;
		
		END IF;
		  
        SET currentDateTime = DATE_ADD(currentDateTime,INTERVAL 1 DAY);
        
	END WHILE;
    
    IF(IsNegativeMinutes = 1)
		THEN SET totalMinutes = 0 - totalMinutes;
	END IF;
    
    RETURN totalMinutes;
END