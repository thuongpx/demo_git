DROP FUNCTION IF EXISTS `GetFirstComment`;

DELIMITER $$

CREATE FUNCTION `GetFirstComment`(type_id int(11), owner_id int(11)) RETURNS varchar(250)
BEGIN
	DECLARE comment VARCHAR(250);    
	SET comment = '';
    
	IF owner_id IS NOT NULL THEN
    BEGIN
        SELECT c.description
        INTO comment
        FROM `comment` AS c
		WHERE c.typeid = type_id and ownerid = owner_id
        ORDER BY CreatedDate DESC
        LIMIT 1;			
    END;
    END IF;
    
	RETURN comment;
END$$

DELIMITER ;