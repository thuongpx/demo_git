DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	-- Add column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Instructions') THEN
	BEGIN
		ALTER TABLE `order_special_instructions`
        CHANGE COLUMN `Instructions` `Instructions1` VARCHAR(250) NULL;
	END;
    END IF;
    
    -- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Instructions2') THEN
	BEGIN
		ALTER TABLE `order_special_instructions`
        ADD COLUMN `Instructions2` VARCHAR(250);
	END;
    END IF;
    
    -- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Instructions3') THEN
	BEGIN
		ALTER TABLE `order_special_instructions`
        ADD COLUMN `Instructions3` VARCHAR(250);
	END;
    END IF;
    
    -- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Instructions4') THEN
	BEGIN
		ALTER TABLE `order_special_instructions`
        ADD COLUMN `Instructions4` VARCHAR(250);
	END;
    END IF;
    
	-- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Instructions5') THEN
	BEGIN
		ALTER TABLE `order_special_instructions`
        ADD COLUMN `Instructions5` VARCHAR(250);
	END;
    END IF;
    
    -- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Instructions6') THEN
	BEGIN
		ALTER TABLE `order_special_instructions`
        ADD COLUMN `Instructions6` VARCHAR(250);
	END;
    END IF;
    
    -- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Instructions7') THEN
	BEGIN
		ALTER TABLE `order_special_instructions`
        ADD COLUMN `Instructions7` VARCHAR(250);
	END;
    END IF;
    
    -- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Instructions8') THEN
	BEGIN
		ALTER TABLE `order_special_instructions`
        ADD COLUMN `Instructions8` VARCHAR(250);
	END;
    END IF;
    
    -- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Instructions9') THEN
	BEGIN
		ALTER TABLE `order_special_instructions`
        ADD COLUMN `Instructions9` VARCHAR(250);
	END;
    END IF;
    
    -- Add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Instructions10') THEN
	BEGIN
		ALTER TABLE `order_special_instructions`
        ADD COLUMN `Instructions10` VARCHAR(250);
	END;
    END IF;
END$$

DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;