DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
	-- Change table Name
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'role_permission') THEN
	BEGIN
		RENAME TABLE `role_permission` TO `roles`;
	END;
    END IF;
END$$

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;

CREATE TABLE IF NOT EXISTS `role_permissions` (
    `RpId` INT NOT NULL AUTO_INCREMENT,
    `RoleId` INT NOT NULL,
    `PermissionId` INT NOT NULL, 
    PRIMARY KEY (`RpId`)
);