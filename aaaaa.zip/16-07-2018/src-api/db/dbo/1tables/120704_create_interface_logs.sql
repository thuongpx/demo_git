CREATE TABLE IF NOT EXISTS `interface_logs`
(
	`LogId` INT NOT NULL AUTO_INCREMENT,
	`TimeStamp` DATETIME NULL,
	`Interface` VARCHAR(50) NULL,
	`Request` TEXT NULL,
    PRIMARY KEY(`LogId`)
) ;