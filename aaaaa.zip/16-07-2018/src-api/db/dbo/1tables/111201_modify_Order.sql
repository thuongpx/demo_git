-- request from LamVT;
-- Rename column from CreateDate to OrderDate
-- Add columns to table order;
-- FirstName VARCHAR(50); => table borrower
-- LastName VARCHAR(100); => table borrower
-- State VARCHAR(2);
-- RepId VARCHAR(25); => table staff

ALTER TABLE `order` CHANGE `CreateDate` `OrderDate` DATETIME;

ALTER TABLE `order` ADD COLUMN `State` VARCHAR(2) NULL;

ALTER TABLE `order` ADD COLUMN `BrokerIdNum` VARCHAR(50) NULL;

ALTER TABLE `order` ADD COLUMN `ProgressId` INT(11) NULL;