
DELIMITER $$
CREATE PROCEDURE `alter_table_broker` ()
BEGIN
	-- Suite
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'IndustryId') THEN
	BEGIN
		ALTER TABLE `broker` 
		ADD COLUMN `IndustryId` INT NULL,
		ADD INDEX `industryid_broker_idx` (`IndustryId` ASC);
		ALTER TABLE `broker` 
		ADD CONSTRAINT `industryid_broker`
		  FOREIGN KEY (`IndustryId`)
		  REFERENCES `industry` (`IndustryId`)
		  ON DELETE NO ACTION
		  ON UPDATE NO ACTION;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_broker();

DROP PROCEDURE IF EXISTS `alter_table_broker`;



