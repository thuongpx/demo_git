
CREATE TABLE IF NOT EXISTS `announcements_state` (
	`AnnouncementID` INT,
    `State` VARCHAR(2)
);