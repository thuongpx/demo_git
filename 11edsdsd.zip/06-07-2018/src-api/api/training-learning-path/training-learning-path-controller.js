import TrainingLearning from "../../db/model/training-learning-path";
import TrainingLPProgram from "../../db/model/training-lp-programs";
import Boom from "boom";
import Bookshelf from "../../db/database";
import {
	handleSingleQuote
} from "../../helper/common-helper";

class TrainingLearningPathController {
	constructor() { }

	checkExistLearningPath(request, reply) {
		const {
			lPName
		} = request.query;
		TrainingLearning.where({
			lPName
		}).count("*").then((count) => {
			const isExist = count > 0;
			reply({
				isExist
			});
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return;
	}

	getTrainingLearningPath(request, reply) {
		const {
			lPName,
			sortColumn,
			sortDirection,
			page,
			itemPerPage
		} = request.query;
		const rawSql = `call GetAllTrainingLearningPath(
			${lPName === undefined ? null : `'${handleSingleQuote(lPName)}'`},
            '\`${sortColumn}\`',
            ${sortDirection},
            ${page},
            ${itemPerPage} 
		);`;
		Bookshelf.knex.raw(rawSql)
			.then((result) => {
				if (result !== null) {
					reply({
						learningPaths: result[0][0],
						totalRecords: result[0][1][0].TotalRecords
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});

		return reply;
	}

	getRequiredProgramOfLearningPath(request, reply) {
		const {
			lpId
		} = request.query;
		let requiredPrograms = [];

		const rawSql = `select p.ProgramId, p.Title, case when l.LPID is null then 0 else 1 end as isMove, l.SortOrder
						from training_programs as p
						left join training_lp_programs as l ON p.ProgramId = l.ProgramId and l.LPID=${lpId === undefined ? 0 : `${lpId}`} ORDER BY p.Title ASC`;
		Bookshelf.knex.raw(rawSql)
			.then((result) => {
				if (result !== null) {
					requiredPrograms = result[0];
				}

				reply(requiredPrograms);
			}).catch((err) => {
				reply(Boom.badRequest(err));
			});

		return;
	}

	// Delete a TrainingLearningPath of order
	deleteTrainingLearningPath(request, reply) {
		const lPID = request.payload;

		TrainingLPProgram.where(lPID).destroy().then((result) => {
			if (result !== null) {
				TrainingLearning.where(lPID).destroy().then(() => {
					if (result !== null) {
						reply({
							isSuccess: true
						});
					}
				}).catch((error) => {
					reply(Boom.badRequest(error));
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return reply;
	}
	// Add MySQL
	addLearningPath(request, reply) {
		const input = request.payload;
		new TrainingLearning().save({
			LPName: input.LPName,
			Description: input.Description
		}, {
				method: "insert"
			}).then((result) => {
				if (result && result.attributes) {

					const lPID = result.attributes.id;
					const programsArray = input.ProgramsArray;

					programsArray.forEach((item) => {
						new TrainingLPProgram().save({
							LPID: lPID,
							ProgramId: item.ProgramId,
							SortOrder: item.SortOrder
						}, {
								method: "insert"
							}).then(() => reply({
								isSuccess: true
							})).catch(error => reply(Boom.badRequest(error)));
					});
				}
			}).catch((error) => {
				return reply(Boom.badRequest(error));
			});
	}

	updateLearningPath(request, reply) {
		const input = request.payload;

		TrainingLearning.where({
			LPID: input.LPID
		}).save({
			LPName: input.LPName,
			Description: input.Description
		}, {
				method: "update"
			}).then((result) => {
				if (result) {
					new TrainingLPProgram().where({
						LPID: input.LPID
					}).destroy().then(() => {
						const programsArray = input.ProgramsArray;
						programsArray.forEach((programId) => {
							new TrainingLPProgram().save({
								LPID: input.LPID,
								ProgramId: programId.ProgramId,
								SortOrder: programId.SortOrder
							}, {
									method: "insert"
								})
								.then(() => reply({
									isSuccess: true
								}))
								.catch(error => reply(Boom.badRequest(error)));
						});
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}
}

export default new TrainingLearningPathController();