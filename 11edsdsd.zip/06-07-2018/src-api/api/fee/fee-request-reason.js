import Boom from "boom";
import Bookshelf from "../../db/database";

class FeeRequestReason {
    constructor() { }

    getReasonCode(request, reply) {
        Bookshelf.knex.raw(`call GetAllReasonCodes()`)
            .then((result) => {
                if (result !== null) {
                    reply({
                        reasonData: result[0][0]
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        return reply;
    }
}

export default new FeeRequestReason();