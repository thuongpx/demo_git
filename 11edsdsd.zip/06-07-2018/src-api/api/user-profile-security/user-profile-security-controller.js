import User from "../../db/model/users";
import Signer from "../../db/model/signers";

import Boom from "boom";
import Jwt from "../../lib/jwt";
import { hasStringValue, hasValue } from "../../helper/common-helper";
import { AUTH } from "../../constant/common-constant";


class UserProfileSecurityController {
    constructor() { }

    getUserProfileSecurity(request, reply) {
        const { accountId, userId } = request.query;

        User.where({
            UsersId: accountId
        }).fetch({ columns: ["UsersId", "UserName", "MappingUserId"] })
            .then((account) => {
                if (account === null) {
                    reply(Boom.badRequest(AUTH.USER_NOT_FOUND));
                    return;
                }

                const { RoleId, UserName } = account.attributes;

                // get user information
                Signer.where({
                    SignerId: userId
                }).fetch({ columns: ["FirstName", "LastName", "Company", "Email", "TaxID", "HomePhone", "WorkPhone", "Ext", "Fax", "ProfilePicture"] })
                    .then((profile) => {
                        if (profile === null) {
                            reply(Boom.badRequest(AUTH.USER_NOT_FOUND));
                            return;
                        }

                        const { FirstName, LastName, Company, CompanyType, HomePhone, WorkPhone, Fax, Email, Ext, TaxID, ProfilePicture } = profile.attributes;
                        reply({
                            roleId: RoleId,
                            firstName: FirstName,
                            lastName: LastName,
                            email: Email,
                            taxID: TaxID,
                            ext: Ext,
                            userName: UserName,
                            company: Company,
                            companyType: CompanyType,
                            homePhone: HomePhone,
                            workPhone: WorkPhone,
                            fax: Fax,
                            img: hasValue(ProfilePicture) ? ProfilePicture.toString() : ""
                        });
                        return;
                    })
                    .catch((error) => {
                        reply(error);
                        return;
                    });
            });
    }

    saveUserProfileSecurity(request, reply) {
        const { userId, accountId, profile } = request.payload;

        if (!hasValue(profile) || !hasStringValue(userId) || !hasStringValue(accountId)) {
            reply(Boom.badRequest("Missing required values"));
            return;
        }

        const signer = {
            Company: profile.company,
            CompanyType: profile.companyType,
            Email: profile.email,
            TaxID: profile.taxID,
            Ext: profile.ext,
            HomePhone: profile.homePhone,
            Fax: profile.fax,
            WorkPhone: profile.workPhone,
            ProfilePicture: Buffer.from(profile.img, "utf-8")
        };

        const updateSigner = () => {
            Signer.where({ SignerId: userId }).save(signer, { method: "update" }).then(() => {
                reply({
                    isSuccess: true
                });
                return;
            }).catch(error => {
                reply(Boom.badRequest(error));
            });
        };

        if (hasStringValue(profile.newPassword) || hasStringValue(profile.currentPassword) || hasStringValue(profile.confirmPassword)) {
            // check current password first
            User.where({ UsersId: accountId }).fetch({ columns: ["HashSalt", "Password"] })
                .then((user) => {
                    if (user === null) {
                        reply(Boom.badRequest("Can not find this user"));
                        return;
                    }
                    const { HashSalt, Password } = user.attributes;

                    if (Jwt.checkPassword(Password, HashSalt, profile.currentPassword)) {
                        // current password is correct
                        // then, update new password
                        User.where({ UserId: accountId }).save({
                            Password: Jwt.hash(profile.newPassword, HashSalt)
                        }, { method: "update" }).then(() => {
                            // done update password => update signer
                            updateSigner(signer);
                            return;
                        });
                    } else {
                        reply(Boom.badRequest("Password is not matched."));
                        return;
                    }
                }).catch(error => reply(Boom.badRequest(error)));
        } else {
            // update only signer
            updateSigner(signer);
        }
    }
}

export default new UserProfileSecurityController();