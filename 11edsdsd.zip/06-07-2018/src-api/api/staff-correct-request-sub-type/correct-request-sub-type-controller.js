import Boom from "boom";
import Bookshelf from "../../db/database";
import {
    handleSingleQuote
} from "../../helper/common-helper";
import ProblemTypes from "../../db/model/problem-types";

class CorrectRequestSubTypeController {
    constructor() {}

    getCorrectionRequestSubList(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            correctionType
        } = request.query;
        const newCorrectionType = (correctionType === "" || correctionType === undefined) ? "" : handleSingleQuote(correctionType);

        const getCorrectionReuqestSubType = Promise.resolve(Bookshelf.knex.raw(`call GetCorrectionRequestSubType(
            ${(sortColumn === undefined || sortColumn === "") ? null : `'${sortColumn}'`},
            ${(sortDirection === undefined || sortDirection === "") ? null : `${sortDirection}`},
            ${(page === undefined || page === "") ? null : `${page}`},
            ${(itemPerPage === undefined || itemPerPage === "") ? null : `${itemPerPage}`},
            '${newCorrectionType}'
        );`));
        const getAllCorrectionRequest = Promise.resolve(Bookshelf.knex.raw(`call GetAllCorrectionRequest`));

        Promise.all([getCorrectionReuqestSubType, getAllCorrectionRequest])
            .then(value => {
                const data = {};
                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.data = item[0][0];
                                    data.totalRecords = item[0][1][0].TotalRecords;
                                    break;
                                case 1:
                                    data.CorrectionRequestList = item[0][0];
                                    break;
                            }
                        }
                    });
                    reply(data);
                } else {
                    reply(Boom.badRequest({
                        message: "Could not connect to server"
                    }));
                }
            }).catch(err => {
                reply(Boom.badRequest(err));
                return reply;
            });
    }

    getCorretionRequestSubTypeById(request, reply) {
        const {
            Id
        } = request.query;

        const rawSql = `select t2.* from (Select pt.Id, pt.Description, IF(t1.Description is not null, t1.Description, "") as SubType, t1.SubTypeId
        from problem_types pt 
        left join (select pt2.Id as SubTypeId, pt2.ParentId, pt2.Description from problem_types pt2 where pt2.ParentId is not null and pt2.ParentId > 0) as t1 on t1.ParentId = pt.Id 
        where pt.ParentId is null or pt.ParentId = 0) as t2 where SubTypeId = ${Id};`;

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                const response = result[0];
                reply(response);
            }
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    checkExistCorrectionRequestSubType(request, reply) {
        const {
            SubType
        } = request.payload;
        let {
            Id
        } = request.payload;
        if (!Id) {
            Id = 0;
        }
        const rawSql = `select count(*) as count from (Select pt.Id, pt.Description, IF(t1.Description is not null, t1.Description, "") as SubType, t1.SubTypeId
        from problem_types pt 
        left join (select pt2.Id as SubTypeId, pt2.ParentId, pt2.Description from problem_types pt2 where pt2.ParentId is not null and pt2.ParentId > 0) as t1 on t1.ParentId = pt.Id 
        where pt.ParentId is null or pt.ParentId = 0) as t2 where t2.SubType = '${SubType}' and t2.Id = ${Id};`;
        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                reply({
                    isExist: result[0][0].count > 0
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    addCorrectionRequestSubType(request, reply) {
        const {
            SubType,
            Id
        } = request.payload;
        const rawSql = `Insert into problem_types (Description, ParentId) values ('${SubType}', '${Id}')`;
        Bookshelf.knex.raw(rawSql)
            .then(() => {
                reply({
                    isSuccess: true
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    updateCorrectionRequestSubType(request, reply) {
        const {
            SubType,
            SubTypeId
        } = request.payload;
        ProblemTypes.where({
            Id: SubTypeId
        }).save({
            Description: SubType
        }, {
            method: "update"
        }).then(() => {
            reply({
                isSuccess: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

}

export default new CorrectRequestSubTypeController();