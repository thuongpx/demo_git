import Boom from "boom";
import Signers from "../../db/model/signers";
import UserRole from "../../db/model/user-roles";
import SignerLanguage from "../../db/model/signer_language";
import NotaryState from "../../db/model/notary_state";
import Order from "./../../db/model/order";
import {
    isBuffer,
    bufferToBoolean,
    handleSingleQuote,
    replaceAll,
    getUsernameByMappingUserIdAndRoleName,
    getUsersIdByMappingUserIdAndRoleName,
    hasStringValue,
    generatePassword,
    sendMailUpdateVendorProfile
} from "../../helper/common-helper";
import Bookshelf from "../../db/database";
import SignerDoc from "../../db/model/signer-doc";
import moment from "moment";
import sendMailCore from "../../mail/mail-helper";
import NotificationTemplate from "../../db/model/notification-management";
import SignerNote from "../../db/model/signer-note";
import User from "../../db/model/users";
import OrderDocs from "../../db/model/order-docs";
import {
    UPLOAD_PATH,
    STORE_PATH
} from "../../helper/file-helper";
import fs from "fs";
import archiver from "archiver";
import SecAnswer from "../../db/model/sec-answers";
import {
    RATING
} from "../../constant/common-constant";
import {
    LIST_TIMEZONE_US
} from "../../constant/common-constant";
import Jwt from "../../lib/jwt";

class SignerController {

    getSignerById(request, reply) {
        const SignerId = request.query;

        Signers.where(SignerId).fetch().then(async result => {
            if (result !== null) {
                const signer = result.attributes;

                Object.keys(signer).forEach((key) => {
                    const value = signer[key];

                    if (isBuffer(value)) {
                        signer[key] = bufferToBoolean(value);
                    }
                    if (key === "ProfilePicture") {
                        signer[key] = value ? value.toString() : "";
                    }
                });

                const checkSignerHasDoctypeId = async (signerId, docTypeId) => {
                    let hasDoctypeId = false;
                    await new Promise((resolve) => SignerDoc.where({
                        signerId,
                        docTypeId
                    }).fetch({
                        columns: ["signerId", "approved", "expireDate"]
                    }).then(doc => {
                        if (doc !== null) {
                            const expireDate = doc.get("expireDate");
                            const approved = bufferToBoolean(doc.get("approved"));
                            hasDoctypeId = moment(expireDate) > moment() && approved;
                        }
                        resolve();
                    }));
                    return hasDoctypeId;
                };

                const checkSignerHasApprovedDocs = async (signerId) => {
                    let hasApprovedDoc = false;
                    await new Promise((resolve) => SignerDoc.query((qb) => {
                        qb.where("signerId", "=", `${signerId}`).andWhere("approved", "=", "1");
                    }).count("*").then(count => {
                        hasApprovedDoc = count > 0;
                        resolve();
                    }));
                    return hasApprovedDoc;
                };

                const checkSignerChalengeQuestions = async (signerId) => {
                    const userId = await getUsersIdByMappingUserIdAndRoleName(signerId, "Vendor");
                    let isHasChallengeQuestions = false;
                    await new Promise((resolve) => SecAnswer.where({
                        userId
                    }).count("*").then(count => {
                        isHasChallengeQuestions = count > 0;
                        resolve();
                    }));
                    return isHasChallengeQuestions;
                };

                const isSignerHasNNA = await checkSignerHasDoctypeId(SignerId.signerId, 7);
                const isSignerHasComission = await checkSignerHasDoctypeId(SignerId.signerId, 1);
                const isSignerHasBackground = await checkSignerHasDoctypeId(SignerId.signerId, 8);

                signer.isSignerHasComission = isSignerHasComission;
                signer.isSignerHasBackground = isSignerHasBackground;
                signer.isSignerHasNNA = isSignerHasNNA;
                signer.isSignerHasHELOC = true;
                signer.isSignerTceCertificate = await checkSignerHasApprovedDocs(SignerId.signerId);
                signer.isHasChallengeQuestions = await checkSignerChalengeQuestions(SignerId.signerId);

                signer.username = await getUsernameByMappingUserIdAndRoleName(SignerId.signerId, "Vendor");

                reply({
                    isSuccess: true,
                    signer
                });
                return;
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    //get vendor full name by id
    getSignerFullNameById(request, reply) {
        const signerId = request.query;
        const columns = ["FirstName", "LastName"];

        Signers.where({
            SignerId: signerId
        }).fetch({
            columns
        }).then((result) => {
            if (result !== null) {
                const fullName = `${result.attributes.FirstName} ${result.attributes.LastName}`;
                reply({
                    fullName
                });
                return;
            }
            reply({
                isSuccess: false,
                message: "No record found!"
            });
            return;
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    //get vendor user name by id
    getSignerUserNameById(request, reply) {
        const {
            signerId
        } = request.query;
        const rawSql = `SELECT u.UserName FROM users u
        INNER JOIN user_roles ur ON u.UsersId = ur.UsersId
        WHERE ur.RoleId = 8 AND u.MappingUserId = ${signerId}`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                reply({
                    signerUserName: result[0][0].UserName
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    //get vendor registration step is done
    getIsVendorRegistrationDone(request, reply) {
        const signerId = request.query;
        const columns = ["RegistrationStep"];

        Signers.where(signerId).fetch({
            columns
        }).then((result) => {
            if (result !== null) {
                if (result.attributes.RegistrationStep === 7) {
                    reply({
                        isDone: true
                    });
                } else {
                    reply({
                        isDone: false
                    });
                }
            }
            reply({
                isSuccess: false,
                message: "No record found!"
            });
            return;
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    //get saved data for vendor registation location page
    getSignerLocationDataById(request, reply) {
        const SignerId = request.query;
        const columns = ["WeekdayStreet", "WeekdaySuite", "WeekdayCity", "WeekdayState", "WeekdayZip",
            "WeekendStreet", "WeekendSuite", "WeekendCity", "WeekendState", "WeekendZip"
        ];

        Signers.where(SignerId).fetch({
            columns
        }).then((result) => {
            if (result !== null) {
                const signer = result.attributes;
                reply({
                    isSuccess: true,
                    signer
                });
                return;
            }
            reply({
                isSuccess: false,
                message: "No record found!"
            });
            return;
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    //get saved data for vendor registation phone number page
    getSignerPhoneDataById(request, reply) {
        const SignerId = request.query;
        const columns = ["HomePhone", "Fax", "Mobile", "CarrierID", "WorkPhone",
            "Ext", "CallWork", "TextOpt"
        ];

        Signers.where(SignerId).fetch({
            columns
        }).then((result) => {
            if (result !== null) {
                const signer = result.attributes;
                const callWork = signer.CallWork;
                const textOpt = signer.TextOpt;

                if (isBuffer(signer.CallWork)) {
                    signer.CallWork = bufferToBoolean(callWork);
                }
                if (isBuffer(signer.TextOpt)) {
                    signer.TextOpt = bufferToBoolean(textOpt);
                }

                reply({
                    isSuccess: true,
                    signer
                });
                return;
            }
            reply({
                isSuccess: false,
                message: "No record found!"
            });
            return;
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    // add new signer
    addSigner(request, reply) {
        const signer = request.payload;

        new Signers().save({
            TenantId: 1, // default unknow
            FirstName: signer.firstName,
            LastName: signer.lastName,
            Company: signer.companyName,
            CompanyType: signer.companyType,
            Email: signer.email,
            TaxID: signer.ssnTaxId,
            EmailOpt: signer.emailOpt
        }, {
                method: "insert"
            }).then((result) => {
                if (result !== null) {
                    reply({
                        signerId: result.id,
                        isSuccess: true
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    addNewVendor(request, reply) {
        const {
            data,
            listSignerNote
        } = request.payload;
        new Signers().save({
            TenantId: 1, // default unknow
            EmailOpt: data.acceptEmail,
            AvgFee: data.avgSigningFee,
            Company: data.companyName,
            Email: data.emailAddress,
            Fax: data.faxPhone,
            FirstName: data.firstName,
            LastName: data.lastName,
            Ext: data.workExt,
            WorkPhone: data.workPhone,
            CallWork: data.callWork,
            HomePhone: data.homePhone,
            Mobile: data.cellPhone,
            Availability: data.availabilitySelected,
            TextOpt: data.acceptText,
            WeekdayStreet: data.weekdayStreet,
            WeekdaySuite: data.weekdaySuite,
            WeekdayCity: data.weekdayCity,
            WeekdayState: data.weekdayState,
            WeekdayZip: data.weekdayZip,
            WeekendStreet: data.weekendStreet,
            WeekendSuite: data.weekendSuite,
            WeekendCity: data.weekendCity,
            WeekendState: data.weekendState,
            WeekendZip: data.weekendZip,
            inactive: false
        }, {
                method: "insert"
            }).then(async (result) => {
                if (result !== null) {
                    const signerId = result.id;
                    const securityCode = Math.floor((Math.random() * 1000000));
                    const password = generatePassword();

                    if (data.languageSelected !== undefined && data.languageSelected.length > 0) {
                        data.languageSelected.map(async item => {
                            await new Promise((resolve => new SignerLanguage().save({
                                SignerId: signerId,
                                LanguageId: item.value
                            }, {
                                    method: "insert"
                                }).then(() => {
                                    resolve();
                                })));
                        });
                    }

                    if (data.stateSelected !== undefined && data.stateSelected.length > 0) {
                        data.stateSelected.map(async item => {
                            await new Promise((resolve => new NotaryState().save({
                                SignerId: signerId,
                                State: item.value
                            }, {
                                    method: "insert"
                                }).then(() => {
                                    resolve();
                                })));
                        });
                    }
                    if (listSignerNote.length > 0) {
                        listSignerNote.map(async item => {
                            await new Promise((resolve => new SignerNote().save({
                                SignerId: signerId,
                                Note: item.Note || "",
                                CreatedDate: item.CreatedDate,
                                CreatedBy: item.CreatedBy
                            }, {
                                    method: "insert"
                                }).then(() => {
                                    resolve();
                                })));
                        });
                    }

                    const salt = Jwt.generateSalt();
                    const hashedPassword = Jwt.hash(password, salt);
                    await new Promise(resolve => new User().save({
                        UserName: `Signer${signerId}`,
                        MappingUserId: signerId,
                        Password: hashedPassword,
                        hashSalt: salt,
                        DateCreated: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                        securityCode,
                        securityCreatedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                        Inactive: false,
                        TenantId: 1
                    }, {
                            method: "insert"
                        }).then(async (user) => {
                            const usersId = user.id;
                            new UserRole().save({
                                UsersId: usersId,
                                RoleId: 8
                            }, {
                                    method: "insert"
                                }).then(() => { });
                            NotificationTemplate.where({
                                purpose: "Invites New Vendor"
                            }).fetch({
                                columns: ["message", "subject", "fromEmail"]
                            }).then(async (template) => {
                                const subject = template.get("subject");
                                let message = template.get("message");
                                let signerFirstName = "";
                                let signerLastName = "";
                                let toEmail = "";

                                signerFirstName = data.firstName;
                                signerLastName = data.lastName;
                                toEmail = data.emailAddress;

                                message = replaceAll(message, ["[VendorName]"], `${signerFirstName} ${signerLastName}`);
                                message = replaceAll(message, ["[Username]"], `Signer${signerId}`);
                                message = replaceAll(message, ["[Password]"], password);

                                const mailOptions = {
                                    from: template.get("fromEmail"),
                                    to: toEmail,
                                    subject,
                                    html: message
                                };
                                sendMailCore(mailOptions);
                            }).catch(error => reply(Boom.badRequest(error)));
                            resolve();
                        }));
                }

                reply({
                    isSuccess: true
                });

            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    updateSigner(request, reply) {
        const signer = request.payload;

        Signers.where({
            SignerId: signer.SignerId
        }).save(signer, {
            method: "update"
        }).then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getInitSignerQuestionaires(request, reply) {
        const SignerId = request.query;
        const columns = ["SignerId", "Felony", "FelonyReason", "AvailDays", "AvailEves", "AvailWkEnds", "Fulltime", "Military", "AnotherStamp", "IsBroker", "IsREA", "IsAttorney", "IsCollegeGrad", "IsNone", "IsNNA",
            "IsOther", "IsAVA", "OtherAssociation", "HaveLaserPrinter", "HaveMobileScanner", "PrintLegal", "DigitalDocs", "DigitalDocCharge", "TrainedEClosing", "ConductedEClosing", "TrainedBy",
            "TrainedByOther", "HaveTablet", "WifiCapability", "NotaryStates"
        ];
        const getSignerById = Promise.resolve(Signers.where(SignerId).fetch({
            columns
        }));
        const getAllStates = Promise.resolve(Bookshelf.knex.raw(`call GetAllState`));
        const getAllLanguage = Promise.resolve(Bookshelf.knex.raw(`select LanguageID, Language from language order by Language;`));
        const getSignerLanguage = Promise.resolve(Bookshelf.knex.raw(`select signer_language.LanguageId as value, language.Language as label from signer_language inner join language on signer_language.LanguageId = language.LanguageID where signer_language.SignerId = ${SignerId.signerId} order by label;`));

        Promise.all([getSignerById, getAllStates, getAllLanguage, getSignerLanguage])
            .then(values => {
                const data = {};
                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    {
                                        const signer = item.attributes;
                                        Object.keys(signer).forEach((key) => {
                                            const value = signer[key];
                                            if (isBuffer(value)) {
                                                signer[key] = bufferToBoolean(value);
                                            }
                                        });
                                        data.signer = signer;
                                        break;
                                    }
                                case 1:
                                    data.listStates = item;
                                    break;
                                case 2:
                                    data.listLanguage = item;
                                    break;
                                case 3:
                                    data.listSignerLanguage = item;
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getSignerExperienceDataById(request, reply) {
        const SignerId = request.query;
        const columns = [
            "SignerId", "CommissionNum", "NotaryExp",
            "AnivDate", "NotarizedDocs", "NotarizedTime",
            "ExperiencedDocs", "ClientRef1", "PhoneRef1",
            "ClientRef2", "PhoneRef2", "ClientRef3", "PhoneRef3"
        ];

        Signers.where(SignerId).fetch({
            columns
        }).then((result) => {
            if (result !== null) {
                const signer = result.attributes;

                if (isBuffer(signer.NotarizedDocs)) {
                    signer.NotarizedDocs = bufferToBoolean(signer.NotarizedDocs);
                }

                reply({
                    isSuccess: true,
                    signer
                });
            }

            reply({
                isSuccess: false,
                message: "No record found!"
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getSignerServiceDataById(request, reply) {
        const {
            signerId
        } = request.query;

        // get all data via stored procedure
        Bookshelf.knex.raw(`CALL GetSignerServiceData(${signerId});`).then(result => {
            if (result !== null) {
                const signer = result[0][0][0];

                if (Array.isArray(result[0][1])) {
                    signer.CoverageArea = result[0][1];
                } else {
                    signer.CoverageArea = [];
                }
                reply({
                    isSuccess: true,
                    signer
                });

                return;
            }

            reply({
                isSuccess: false,
                message: "No record found!"
            });
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }

    saveSignerProfilePicture(request, reply) {
        const {
            image,
            signerId
        } = request.payload;
        const signer = {
            signerId,
            // eslint-disable-next-line
            ProfilePicture: Buffer.from(image, "utf8")
        };

        Signers.where({
            signerId
        }).save(signer, {
            method: "update"
        }).then(() => {
            // finish, return to client
            reply({
                isSuccess: true
            });
        }).catch(error => reply(Boom.badRequest(error)));
    }

    updateQuestionnaires(request, reply) {
        const {
            signer,
            languages
        } = request.payload;

        // const listLanguagesId = languages.map((item) => {
        //     return item.value;
        // });

        // const updateQuestionnaires = Promise.resolve(Signers.where({
        //     SignerId: signer.SignerId
        // }).save(signer, {
        //     method: "update"
        // }));
        const updateQuestionnaires = Promise.resolve(Signers.where({
            SignerId: signer.SignerId
        }).save(signer, {
            method: "update"
        }));

        const queue = [updateQuestionnaires];

        const delLanguagesById = `DELETE FROM signer_language WHERE SignerId=${signer.SignerId};`;
        queue.push(Promise.resolve(Bookshelf.knex.raw(delLanguagesById)));

        if (languages.length > 0) {
            languages.map((addr) => {
                const insertLanguagesSql = `INSERT INTO signer_language (LanguageId, SignerId) VALUES (${addr.value}, ${signer.SignerId});`;
                queue.push(Promise.resolve(Bookshelf.knex.raw(insertLanguagesSql)));
            });
        }

        Promise.all(queue).then(() => {
            reply({
                isSuccess: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getTotalOpenOfferOfSigner(request, reply) {
        const {
            signerId
        } = request.query;
        const rawSql = `select count(so.OfferID) as totalOffer from signer_offer so where so.OfferStatus='O' and so.SignerId = ${signerId};`;

        Bookshelf.knex.raw(rawSql)
            .then(value => {
                reply({
                    totalOffer: value[0][0].totalOffer
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    async mobileGetVendorNotifications(request, reply) {
        const {
            usersId,
            page,
            itemPerPage
        } = request.query;

        const rawSql = `SELECT
        opl.dateLog,opl.activity,opl.orderId FROM order_progress_log opl
        LEFT JOIN users u on u.usersId = opl.usersId
        LEFT JOIN signer s on s.signerId = u.mappingUserId
        WHERE opl.progressType=5 AND opl.usersId=${usersId} 
        ORDER BY opl.dateLog desc LIMIT  ${(page - 1) * itemPerPage},${itemPerPage}`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                const notifications = result[0];
                reply({
                    notifications
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getAllVendorManagement(request, reply) {
        const {
            vendorName,
            city,
            state,
            sortColumn,
            sortDirection,
            page,
            itemPerPage
        } = request.query;

        const newVendorName = (vendorName === "" || vendorName === undefined) ? "" : handleSingleQuote(vendorName);
        const newCity = (city === "" || city === undefined) ? "" : handleSingleQuote(city);
        const rawSql = `call GetVendorManagement(
			'${state}',
            '${newVendorName}',
            '${newCity}',
            '${sortColumn}',
            ${sortDirection},
            ${page},
            ${itemPerPage}
        )`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
    activeVendor(request, reply) {
        const {
            vendorID
        } = request.payload;

        const rawSql = `update signer set InActive=0 where SignerId=${vendorID};`;
        Bookshelf.knex.raw(rawSql)
            .then(async result => {
                if (result !== null) {
                    const usersId = await getUsersIdByMappingUserIdAndRoleName(vendorID, "Vendor");
                    await new Promise(resolve => User.where({
                        usersId
                    }).save({
                        inActive: false
                    }, {
                            method: "update"
                        }).then(() => {
                            resolve();
                        }));
                    let emailData = {};
                    await new Promise((resolve) =>
                        Bookshelf.knex.raw(`select distinct
                    CONCAT(s.FirstName," ",s.LastName) as VendorName,
                    s.Email as Email,
                    u.UserName as UserName
                    from signer s, users u, user_roles ur WHERE s.SignerId = u.MappingUserId and u.UsersId = ur.UsersId and ur.RoleId = 8 and SignerId=${vendorID}`)
                            .then((getEmailDataResult) => {
                                if (getEmailDataResult !== undefined) {
                                    emailData = getEmailDataResult[0][0];
                                }
                                resolve();
                            })
                    );

                    const rawSqlVendor = `select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'Account Deactivated - Vendor';`;
                    Bookshelf.knex.raw(rawSqlVendor)
                        .then((values) => {
                            if (values !== null) {
                                const to = emailData.Email;
                                let HTML = values[0][0].message;
                                HTML = replaceAll(HTML, `[VendorName]`, emailData.VendorName);
                                HTML = replaceAll(HTML, `[username]`, emailData.UserName);

                                const mailOptions = {
                                    from: values[0][0].fromEmail,
                                    to,
                                    subject: values[0][0].subject,
                                    text: `Send Email`,
                                    html: HTML
                                };

                                sendMailCore(mailOptions);
                            }
                            reply({
                                isSuccess: true
                            });
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getVendorOrders(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            orderId,
            firstName,
            lastName,
            fileNumber,
            statusOrder,
            daySelected,
            signerId
        } = request.query;
        const newOrderId = (orderId === "" || orderId === undefined) ? null : parseInt(orderId);
        const newFirstName = (firstName === "" || firstName === undefined) ? "" : handleSingleQuote(firstName);
        const newLastName = (lastName === "" || lastName === undefined) ? "" : handleSingleQuote(lastName);
        const newFileNumber = (fileNumber === "" || fileNumber === undefined) ? "" : handleSingleQuote(fileNumber);
        const newStatusOrder = (statusOrder === "" || statusOrder === undefined) ? null : parseInt(statusOrder);

        Bookshelf.knex.raw(`call GetVendorOrders(
            ${(sortColumn === undefined || sortColumn === "") ? null : `'${sortColumn}'`},
            ${(sortDirection === undefined || sortDirection === "") ? null : `${sortDirection}`},
            ${(page === undefined || page === "") ? null : `${page}`},
            ${(itemPerPage === undefined || itemPerPage === "") ? null : `${itemPerPage}`},
            ${newOrderId},
            '${newFirstName}',
            '${newLastName}',
            '${newFileNumber}',
            ${newStatusOrder},
            ${daySelected},
            ${signerId}
        );`).then(value => {
                const data = {};

                if (value !== null) {
                    const rawData = [];
                    value[0][0].map(item => {
                        if (item.AptDateTime !== null) {
                            const date = moment(item.AptDateTime).utc();
                            const dateString = `${date.isValid() ? `${date.format("MM/DD/YYYY hh:mm:ss A")}` : ""}`;
                            let timeZoneAbv = "";
                            LIST_TIMEZONE_US.forEach(zone => {
                                if (item.AptUTC && zone.UTC === item.AptUTC.toString()) {
                                    timeZoneAbv = `${timeZoneAbv} ${zone.abv}`;
                                }
                            });
                            item.AptDateTime = `${dateString} ${timeZoneAbv}`;
                        } else {
                            item.AptDateTime = "";
                        }
                        if (item.ProgressId === 1) {
                            item.ProgressId = "N/A";
                        } else if (item.ProgressId === 2) {
                            item.ProgressId = "Confirm With Customer";
                        } else if (item.ProgressId === 3) {
                            item.ProgressId = "Appt Confirmed";
                        } else if (item.ProgressId === 4) {
                            item.ProgressId = "Docs Available";
                        } else if (item.ProgressId === 5) {
                            item.ProgressId = "Awaiting Status";
                        } else if (item.ProgressId === 6) {
                            item.ProgressId = "Status Submitted";
                        } else if (item.ProgressId === 7) {
                            item.ProgressId = "Awaiting Scanbacks";
                        } else if (item.ProgressId === 8) {
                            item.ProgressId = "Closed";
                        } else if (item.ProgressId === 9) {
                            item.ProgressId = "Unsuccessful signing attempt";
                        } else if (item.ProgressId === 10) {
                            item.ProgressId = "Hold";
                        } else if (item.ProgressId === 11) {
                            item.ProgressId = "Canceled";
                        } else if (item.ProgressId === 12) {
                            item.ProgressId = "N/A";
                        }
                        rawData.push(item);
                    });
                    data.data = rawData;
                    data.totalRecords = value[0][1][0].TotalRecords;
                }
                reply(data);
                return reply;
            }).catch(err => {
                reply(Boom.badRequest(err));
                return reply;
            });
    }

    deactivateVendor(request, reply) {
        const {
            signerId,
            inActiveReason
        } = request.payload;
        Signers.where({
            signerId
        }).save({
            inactive: true,
            inActiveReason
        }, {
                method: "update"
            }).then(() => {
                reply({
                    isSuccess: true
                });
                NotificationTemplate.where({
                    purpose: "Account Deactivated by TCE - Vendor"
                }).fetch({
                    columns: ["message", "subject", "fromEmail"]
                }).then(async (template) => {
                    const subject = template.get("subject");
                    let message = template.get("message");
                    let signerFirstName = "";
                    let signerLastName = "";
                    let userName = "";
                    let toEmail = "";
                    let reason = "";

                    await new Promise(resolve => Signers.where({
                        signerId
                    }).fetch({
                        columns: ["firstName", "lastName", "inActiveReason", "email"]
                    }).then((signer) => {
                        signerFirstName = signer.get("firstName");
                        signerLastName = signer.get("lastName");
                        reason = signer.get("inActiveReason");
                        toEmail = signer.get("email");
                        resolve();
                    }));

                    const usersId = await getUsersIdByMappingUserIdAndRoleName(signerId, "Vendor");

                    await new Promise(resolve => User.where({
                        usersId
                    }).save({
                        inActive: true
                    }, {
                            method: "update"
                        }).then(() => {
                            resolve();
                        }));

                    const rawSqlGetUsername = `SELECT u.username as username FROM users u
                left join user_roles ur on u.usersId = ur.usersId 
                left join signer sn on u.MappingUserId = sn.signerId where sn.signerId =${signerId} and ur.RoleId=8`;

                    await new Promise(resolve => Bookshelf.knex.raw(rawSqlGetUsername).then((result) => {
                        userName = result[0][0].username;
                        resolve();
                    }));

                    message = replaceAll(message, ["[SignerFirstName]"], `${signerFirstName}`);
                    message = replaceAll(message, ["[SignerLastName]"], `${signerLastName}`);
                    message = replaceAll(message, ["[Username]"], `${userName}`);
                    message = replaceAll(message, ["[Reason]"], `${reason}`);

                    const mailOptions = {
                        from: template.get("fromEmail"),
                        to: toEmail,
                        subject,
                        html: message
                    };
                    sendMailCore(mailOptions);
                }).catch(error => reply(Boom.badRequest(error)));
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getStaffVendors(request, reply) {
        const {
            signerId,
            signerName,
            languages,
            city,
            state,
            zip,
            numberOfOrderMoreThan,
            rating,
            phone,
            email,
            categories,
            sortColumn,
            sortDirection,
            page,
            itemPerPage
        } = request.payload;

        let languagesInput = "";
        let categoriesInput = "";

        if (languages) {
            const languageIds = [];
            languages.forEach(x => {
                languageIds.push(x.value);
            });

            languagesInput = languageIds.join();
        }

        if (categories) {
            const categoryIds = [];
            categories.forEach(x => {
                categoryIds.push(x.catId);
            });

            categoriesInput = categoryIds.join();
        }

        const rawSql = `call GetStaffVendors('${signerId}','${handleSingleQuote(signerName)}','${languagesInput}','${handleSingleQuote(city)}','${state}','${zip}','${numberOfOrderMoreThan}','${rating}','${phone}','${handleSingleQuote(email)}','${categoriesInput}','${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage})`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    async checkSignerAssignedOpenOrder(request, reply) {
        const {
            signerId
        } = request.query;
        let isAssigned = false;
        const rawSql = `
        SELECT COUNT(*) as count FROM \`order\` where signerId = ${signerId} and progressId in (2,3,4,5,9,10)`;
        await new Promise((resolve) => Bookshelf.knex.raw(rawSql).then(result => {
            isAssigned = result[0][0].count > 0;
            resolve();
        }));
        reply({
            isAssigned
        });
    }

    getAllDataDocs(request, reply) {
        const {
            orderId
        } = request.query;

        const rawSql = `call GetAllDocs(${orderId})`;
        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                const rawData = [];
                result[0][0].map((item) => {
                    const rawItem = item;
                    if (rawItem.DownloadDate !== null) {
                        rawItem.DownloadDate = "Downloaded";
                    } else {
                        rawItem.DownloadDate = "";
                    }
                    rawData.push(rawItem);
                });
                reply({
                    data: rawData,
                    totalRecords: result[0][1][0].TotalRecords
                });
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
    }
    downloadDocs(request, reply) {
        const input = request.query;
        const docId = input.docID;
        const rawSql = `update order_docs set DownloadDate='${input.download}' where DocId=${docId};`;
        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    OrderDocs.where({
                        docId
                    }).fetch({
                        columns: ["OrderId", "Description"]
                    }).then((orderDoc) => {
                        const orderId = orderDoc.get("OrderId");
                        const docName = orderDoc.get("Description");

                        const filePath = `${UPLOAD_PATH}/orderDocs/uploadedDocs/${orderId}/${docName}`;
                        // const fileName = `${docName}`;
                        if (fs.existsSync(filePath)) {
                            // serve file
                            reply.file(filePath);
                        } else {
                            reply(Boom.badRequest(`File ${docName} is not exists.`));
                        }
                    }).catch((error) => reply(Boom.badRequest(error)));
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    downloadAllDocs(request, reply) {
        const input = JSON.parse(request.payload.toString());
        const orderID = input.orderID;
        const listDoc = input.list;
        // const docType = input.docsType;
        const listFilePath = [];
        const listFileName = [];

        let rawSqlUpdateDownloadDocs = `update order_docs set DownloadDate='${input.download}' where docId in (`;

        for (let i = 0; i < listDoc.length; i++) {
            const item = listDoc[i];
            if (i < listDoc.length - 1) {
                rawSqlUpdateDownloadDocs = `${rawSqlUpdateDownloadDocs} ${item.DocId},`;
            } else {
                rawSqlUpdateDownloadDocs = `${rawSqlUpdateDownloadDocs} ${item.DocId});`;
            }

            const filePath = `${UPLOAD_PATH}/orderDocs/uploadedDocs/${orderID}/${item.Description}`;
            listFilePath.push(filePath);
            listFileName.push(item.Description);
        }

        if (listDoc.length > 0) Bookshelf.knex.raw(rawSqlUpdateDownloadDocs).then(() => { }).catch(err => reply(Boom.badRequest(err)));

        const outputPath = `${STORE_PATH}/tempDownloadFile-${moment().format("YYYYMMDDhhmmss")}.zip`;

        const output = fs.createWriteStream(outputPath);
        const archive = archiver("zip", {
            zlib: {
                level: 9
            } // Sets the compression level.
        });

        output.on("finish", () => {
            reply.file(outputPath);
        });

        archive.on("error", (err) => {
            reply(Boom.badRequest(err));
        });

        archive.pipe(output);

        listFilePath.forEach((filePath, index) => {
            archive.file(filePath, {
                name: listFileName[index]
            });
        });

        archive.finalize();
    }

    confirmDocs(request, reply) {
        const data = request.payload;
        const rawSql = `update \`order\` set DocumentCompletedDate = '${data.dayConfirmed}', ProgressId= '${data.progressID}' where OrderId = ${data.orderID}`;
        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getAppointmentDetailsData(request, reply) {
        const {
            orderId
        } = request.query;
        const rawSql = `select AptDateTime, IsNeedPreCall, DocDelMethod, DocumentCompletedDate, IsVenOrCEDefineADT, AptUTC, BrokerIdNum, LastName, TurnAroundDate from \`order\` where OrderId = ${orderId};`;
        const dataAppointment = {};

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                result[0].map((item) => {
                    dataAppointment.aptDateTime = item.AptDateTime;
                    dataAppointment.timezone = item.AptUTC;
                    dataAppointment.isVenOrCEDefineADT = bufferToBoolean(item.IsVenOrCEDefineADT);
                    if (item.TurnAroundDate === null ? dataAppointment.turnAround = true : dataAppointment.turnAround = false);
                    dataAppointment.borrowerName = item.LastName;
                    dataAppointment.referenceId = item.BrokerIdNum;
                    if (item.DocumentCompletedDate === null ? dataAppointment.documentComplete = true : dataAppointment.documentComplete = false);
                    if (item.IsNeedPreCall === null || item.IsNeedPreCall === 0 ? dataAppointment.isNeedPrecall = false : dataAppointment.isNeedPrecall = true);
                    dataAppointment.docDelivery = item.DocDelMethod;
                });
                reply(dataAppointment);
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    updateAppointment(request, reply) {
        const inputsData = request.payload;
        const rawData = {};
        const appDateValue = (inputsData.aptDate !== null && inputsData.aptTime !== null) ? moment(`${inputsData.aptDate} ${inputsData.aptTime}`).format("YYYY-MM-DD HH:mm:ss") : null;
        rawData.AptDateTime = inputsData.isVenOrCEDefineADT ? null : appDateValue;
        rawData.IsVenOrCEDefineADT = inputsData.isVenOrCEDefineADT;

        Order.where({
            OrderId: inputsData.OrderId
        }).save(rawData, {
            method: "update"
        })
            .then(() => {
                reply({
                    isSuccess: true
                });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    confirmAppointment(request, reply) {
        const data = request.payload;
        const rawSql = `update \`order\` set TurnAroundDate = '${data.dayConfirmed}', ProgressId= '${data.progressID}' where OrderId = ${data.orderID}`;
        Bookshelf.knex.raw(rawSql)
            .then(async result => {
                if (result !== null) {
                    let emailAgentData = {};
                    await new Promise((resolve) =>
                        Bookshelf.knex.raw(`SELECT FullName, agent.Email, broker.EmailOpt
                        FROM ((agent
                        Left Join broker on broker.BrokerID = agent.BrokerID)
                        Left Join \`order\` on \`order\`.AgentID = agent.AgentID)
                        Where \`order\`.OrderId = ${data.orderID} and Cast(agent.BrokerID as char(8)) Not In ('2165,3121,4122,5349') and broker.EmailOpt = 1;`)
                            .then((getEmailDataResult) => {
                                if (getEmailDataResult !== undefined) {
                                    emailAgentData = getEmailDataResult[0][0];
                                }
                                resolve();
                            })
                    );
                    const rawSqlVendor = `select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'Appointment Confirmed – Vendor';`;
                    Bookshelf.knex.raw(rawSqlVendor)
                        .then((values) => {
                            if (values !== null) {
                                const to = emailAgentData.Email;
                                let HTML = values[0][0].message;
                                const subject = replaceAll(values[0][0].subject, `[OrderID]`, data.orderID);
                                HTML = replaceAll(HTML, `[Agent Name]`, emailAgentData.FullName);
                                HTML = replaceAll(HTML, `[OrderID]`, data.orderID);
                                HTML = replaceAll(HTML, `[Appointment Date&Time Time Zone]`, data.time);
                                HTML = replaceAll(HTML, `[Borrower Last Name]`, data.borrowerLastName);
                                HTML = replaceAll(HTML, `[ReferenceID]`, data.referenceID);

                                const mailOptions = {
                                    from: values[0][0].fromEmail,
                                    to,
                                    subject,
                                    text: `Send Email`,
                                    html: HTML
                                };
                                sendMailCore(mailOptions);
                            }
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                    let emailStaffData = {};
                    await new Promise((resolve) =>
                        Bookshelf.knex.raw(`SELECT employees.Email, concat(employees.FirstName, " ", employees.LastName) as fullName FROM (\`order\`
                        Left Join employees on \`order\`.RepID = employees.RepID)
                        Where OrderID = ${data.orderID};`)
                            .then((getEmailDataResult) => {
                                if (getEmailDataResult !== undefined) {
                                    emailStaffData = getEmailDataResult[0][0];
                                }
                                resolve();
                            })
                    );
                    const rawSqlStaff = `select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'Appointment Confirmed – TCE';`;
                    Bookshelf.knex.raw(rawSqlStaff)
                        .then((values) => {
                            if (values !== null) {
                                const to = emailStaffData.Email;
                                let HTML = values[0][0].message;
                                const subject = replaceAll(values[0][0].subject, `[OrderID]`, data.orderID);
                                HTML = replaceAll(HTML, `[Scheduler Name]`, emailStaffData.fullName);
                                HTML = replaceAll(HTML, `[OrderID]`, data.orderID);
                                HTML = replaceAll(HTML, `[Appointment Date&Time Time Zone]`, data.time);
                                HTML = replaceAll(HTML, `[Borrower Last Name]`, data.borrowerLastName);
                                HTML = replaceAll(HTML, `[ReferenceID]`, data.referenceID);

                                const mailOptions = {
                                    from: values[0][0].fromEmail,
                                    to,
                                    subject,
                                    text: `Send Email`,
                                    html: HTML
                                };
                                sendMailCore(mailOptions);
                            }
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                }
                reply({
                    isSuccess: true
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getSigningAndPropertyAddressData(request, reply) {
        const {
            orderId
        } = request.query;
        const rawSql = `select CONCAT(o.Address, ', ', o.Suite, ', ', o.City, ', ', o.State, ' ', o.Zip) as SigningLocation, o.Address, o.PropertyAddress,
                               CONCAT(o.PropertyAddress, ', ',o.PropertySuite, ', ', o.PropertyCity, ', ', o.PropertyState, ' ', o.PropertyZip) as PropertyLocation, signer.WeekdayStreet
                        from (\`order\` o
                        left Join signer on o.SignerId = signer.SignerId)
                        where OrderId = ${orderId};`;
        const dataAddress = {};

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                result[0].map((item) => {
                    dataAddress.signingAddress = item.SigningLocation;
                    dataAddress.address = item.Address;
                    dataAddress.propertyAddress = item.PropertyAddress;
                    dataAddress.propertyLocation = item.PropertyLocation;
                    dataAddress.vendorAddress = item.WeekdayStreet;
                });
                reply(dataAddress);
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    getShippingInfoData(request, reply) {
        const {
            orderId
        } = request.query;
        const rawSql = `select ReturnAddress, Courier from \`order\` left join courier on \`order\`.CourierID = courier.CourierID where OrderId = ${orderId};`;
        const dataAddress = {};

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                result[0].map((item) => {
                    if (item.ReturnAddress === null ? dataAddress.address = "---" : dataAddress.address = item.ReturnAddress);
                    if (item.Courier === null ? dataAddress.courier = "---" : dataAddress.courier = item.Courier);
                });
                reply(dataAddress);
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    resetVendorPassword(request, reply) {
        const {
            signerId
        } = request.payload;

        NotificationTemplate.where({
            purpose: "Reset Password by TCE - Vendor"
        }).fetch({
            columns: ["message", "subject", "fromEmail"]
        }).then(async (template) => {
            const subject = template.get("subject");
            const password = generatePassword();
            let message = template.get("message");
            let signerFirstName = "";
            let signerLastName = "";
            let toEmail = "";

            await new Promise(resolve => Signers.where({
                signerId
            }).fetch({
                columns: ["firstName", "lastName", "email"]
            }).then((signer) => {
                signerFirstName = signer.get("firstName");
                signerLastName = signer.get("lastName");
                toEmail = signer.get("email");
                resolve();
            }));

            const usersId = await getUsersIdByMappingUserIdAndRoleName(signerId, "Vendor");
            const userName = await getUsernameByMappingUserIdAndRoleName(signerId, "Vendor");

            const salt = Jwt.generateSalt();
            const hashedPassword = Jwt.hash(password, salt);

            await new Promise(resolve => User.where({
                usersId
            }).save({
                needToResetPassword: true,
                hashSalt: salt,
                password: hashedPassword,
                LastUpdate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
            }, {
                    method: "update"
                }).then(() => {
                    resolve();
                }));

            message = replaceAll(message, ["[SignerFirstName]"], `${signerFirstName}`);
            message = replaceAll(message, ["[SignerLastName]"], `${signerLastName}`);
            message = replaceAll(message, ["[Username]"], `${userName}`);
            message = replaceAll(message, ["[Password]"], `${password}`);

            const mailOptions = {
                from: template.get("fromEmail"),
                to: toEmail,
                subject,
                html: message
            };
            sendMailCore(mailOptions);

            reply({
                isSuccess: true
            });
        }).catch(error => reply(Boom.badRequest(error)));
    }

    getSignerBasicInformation(request, reply) {
        const {
            signerId
        } = request.payload;
        Signers.where({
            signerId
        }).fetch({
            columns: ["signerId", "firstName", "lastName", "homePhone", "workPhone", "fax", "ext", "mobile", "email", "callWork", "company", "textOpt", "emailOpt"]
        }).then(result => {
            const signer = result.attributes;
            Object.keys(signer).forEach((key) => {
                const value = signer[key];

                if (isBuffer(value)) {
                    signer[key] = bufferToBoolean(value);
                }
            });

            reply(signer);
        }).catch(error => reply(Boom.badRequest(error)));
    }

    updateSignerBasicInformation(request, reply) {
        const signer = request.payload;
        Signers.where({
            signerId: signer.signerId
        }).save(signer, {
            method: "update"
        }).then(() => {
            sendMailUpdateVendorProfile(signer.signerId);
            reply({
                isSuccess: true
            });
        }).catch(error => reply(Boom.badRequest(error)));
    }

    async revalidateAuthentication(request, reply) {
        const {
            signerId
        } = request.payload;
        const userId = await getUsersIdByMappingUserIdAndRoleName(signerId, "Vendor");
        SecAnswer.where({
            userId
        }).destroy().then(() => {
            reply({
                isSuccess: true
            });
        }).catch(error => reply(Boom.badRequest(error)));
    }

    getSignerAdditionalInformation(request, reply) {
        const {
            signerId
        } = request.query;
        const rawSql = `select (select group_concat(lg.language separator ', ') 
        from signer_language sl
        left join language lg on lg.languageId = sl.languageId
        where sl.signerId = sn.signerId) as languages,
        ordersCount,avgFee,signerFee,lastUpdate,lastSigning,availability,mistakesCount,inActiveReason,avgTurn,avgClose,notestoND, (select group_concat(ns.state separator ', ') 
        from notary_state ns
        where ns.signerId = sn.signerId) as dualStates
        from signer sn where signerId =${signerId}`;
        Bookshelf.knex.raw(rawSql).then((result) => {
            reply(result[0][0]);
        }).catch(error => reply(Boom.badRequest(error)));
    }

    getSignerAdditionalInforRecentOrders(request, reply) {
        const {
            signerId,
            sortColumn,
            sortDirection,
            page,
            itemPerPage
        } = request.query;

        const rawSql = `call GetSignerAdditionalInforRecentOrders(
            '${signerId}',
            '${sortColumn}',
            ${sortDirection},
            ${page},
            ${itemPerPage}
        )`;
        Bookshelf.knex.raw(rawSql).then(result => {
            reply({
                data: result[0][0],
                totalRecords: result[0][1][0].TotalRecords
            });
        }).catch(error => reply(Boom.badRequest(error)));
    }

    async getSignerAdditionalInformationModal(request, reply) {
        const {
            signerId
        } = request.query;
        const signer = {};
        await new Promise((resolve) => NotaryState.where({
            signerId
        }).fetchAll({
            columns: ["state"]
        }).then((states) => {
            const selectedDualStates = [];
            if (states !== null) {
                states.forEach(x => {
                    selectedDualStates.push({
                        label: x.get("state"),
                        value: x.get("state")
                    });
                });
            }
            signer.selectedDualStates = selectedDualStates;
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        const getLanguageSql = `select sl.languageId,l.language from signer_language sl
        left join language l on l.languageID = sl.languageID
        where signerId = ${signerId}`;
        await new Promise((resolve) => Bookshelf.knex.raw(getLanguageSql).then((result) => {
            const selectedLanguages = [];
            if (result[0] !== null) {
                result[0].forEach(x => {
                    selectedLanguages.push({
                        label: x.language,
                        value: x.languageId
                    });
                });
            }
            signer.selectedLanguages = selectedLanguages;
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Signers.where({
            signerId
        }).fetch({
            columns: ["availability "]
        }).then((model) => {
            signer.availability = model.get("availability");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        reply(signer);
    }

    async updateSignerAdditionalInformation(request, reply) {
        const {
            signerId,
            availability,
            selectedDualStates,
            selectedLanguages
        } = request.payload;

        await new Promise((resolve) => Signers.where({
            signerId
        }).save({
            availability
        }, {
                method: "update"
            }).then(() => {
                sendMailUpdateVendorProfile(signerId);
                resolve();
            }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => NotaryState.where({
            signerId
        }).destroy().then(async () => {
            const addDualState = async (dualState) => {
                await new Promise((resolveChild) => new NotaryState().save({
                    signerId,
                    state: dualState.value
                }, {
                        method: "insert"
                    }).then(() => {
                        resolveChild();
                    }).catch(error => reply(Boom.badRequest(error))));
            };
            for (const dualState of selectedDualStates) {
                await addDualState(dualState);
            }
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => SignerLanguage.where({
            signerId
        }).destroy().then(async () => {
            const addLanguage = async (language) => {
                await new Promise((resolveChild) => new SignerLanguage().save({
                    signerId,
                    languageId: language.value
                }, {
                        method: "insert"
                    }).then(() => {
                        resolveChild();
                    }).catch(error => reply(Boom.badRequest(error))));
            };
            for (const language of selectedLanguages) {
                await addLanguage(language);
            }
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        reply({
            isSuccess: true
        });
    }

    getListVendorByNameOrEmail(request, reply) {
        const {
            searchText,
            isCustomer,
            clientId
        } = request.query;
        const searchStr = hasStringValue(searchText) ? searchText : "";
        const sqlGetPreferredVendor = `SELECT c.SignerId  FROM ${isCustomer === "true" ? "customer_preferred_vendor" : "broker_preferred_vendor"} c 
                                        where c.${isCustomer === "true" ? "CustomerId" : "BrokerId"} = ${clientId} and c.SignerId is not null`;

        const rawSql = `SELECT signerId, email, concat(FirstName, ' ', LastName) as fullName FROM signer 
                        where (concat(FirstName, ' ', LastName) like '%${handleSingleQuote(searchStr)}%' 
                        or email like '%${handleSingleQuote(searchStr)}%') and (signerId not in (${sqlGetPreferredVendor})) and (InActive is null or InActive = false);`;

        Bookshelf.knex.raw(rawSql).then(result => {
            let returnData = [];
            if (result) {
                returnData = result[0] || [];
            }

            reply(returnData);
        }).catch(error => reply(Boom.badRequest(error)));
    }

    getTotalVendorPoolForClientOrderAssignConfig(request, reply) {
        const {
            inputs,
            isCustomer,
            clientId
        } = request.payload;

        let rating = ``;
        let specialty = ``;
        let trainingCourse = ``;

        const mappingRating = (value) => {
            return RATING[value] || 0;
        };

        if (inputs.performanceRating.isActive) {
            inputs.performanceRating.data.forEach((item, index) => {
                rating = `${rating}${mappingRating(item.value)}`;
                if (index < inputs.performanceRating.data.length - 1) {
                    rating = `${rating},`;
                }
            });
        }

        if (inputs.specialty.isActive) {
            inputs.specialty.data.forEach((item, index) => {
                specialty = `${specialty}${item.value}`;
                if (index < inputs.specialty.data.length - 1) {
                    specialty = `${specialty},`;
                }
            });
        }

        if (inputs.training.isActive) {
            inputs.training.data.forEach((item, index) => {
                trainingCourse = `${trainingCourse}${item.value}`;
                if (index < inputs.training.data.length - 1) {
                    trainingCourse = `${trainingCourse},`;
                }
            });
        }

        const rawSql = `call getTotalVendorPool( "${inputs.experience.data}", "${rating}", "${specialty}", "${trainingCourse}", ${clientId}, ${isCustomer}, ${inputs.clientPreferred.isActive});`;
        Bookshelf.knex.raw(rawSql).then(result => {
            let returnData = 0;
            if (result[0]) {
                returnData = result[0][1][0].TotalRecords || 0;
            }

            reply(returnData);
        }).catch(error => reply(Boom.badRequest(error)));
    }

    getOrderRatingBySignerId(request, reply) {
        const {
            signerId,
            page,
            itemPerPage,
            agentId,
            managerId
        } = request.query;

        const rawSql = `CALL GetOrderRating(${page}, ${itemPerPage}, ${agentId ? agentId : null},${managerId ? managerId : null}, ${signerId ? signerId : null})`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result[0]) {
                reply({
                    rating: result[0][0],
                    totalRecords: result[0][1][0].TotalRecords
                });
            }
        }).catch(error => reply(Boom.badRequest(error)));
    }

    getDataAssignVendor(request, reply) {
        const {
            signerId,
            orderId
        } = request.query;

        const unAcknowledgedSql = `SELECT COUNT(ProblemId) AS countProblem FROM order_problem WHERE SignerId = ${signerId} AND Acknowledged = 0`;
        const aptDateTimeSql = `SELECT AptDateTime AS aptDateTime FROM ` +
            "`order`" +
            ` WHERE OrderId = ${orderId}`;
        const loanTypeSql = `SELECT l.LoanType AS loantype FROM loan_type l WHERE l.LoanTypeId = (SELECT o.LoanType FROM ` +
            "`order`" +
            ` o WHERE o.OrderId = ${orderId})`;
        const agentSql = `SELECT a.FullName AS fullName, a.Email AS agentEmail FROM agent AS a where a.AgentId = (SELECT o.AgentId FROM ` +
            "`order`" +
            `AS o where o.OrderId = ${orderId})`;
        const offerAmountSql = `SELECT SUM(SignerFee) as offerAmount FROM order_fee where OrderID = ${orderId}`;
        const vendorSql = `SELECT s.WeekdayCity AS city, s.FirstName AS firstName, s.LastName AS lastName, CONCAT_WS(" ",s.FirstName, s.LastName) AS vendorName, s.Email AS vendorEmail, 
        (69.1*SQRT(POWER(z.Lat-(SELECT z1.Lat from Zip z1 inner join ` +
            "`order`" +
            ` o ON o.Zip = z1.Zip where o.OrderId = ${orderId}), 2)+0.6*POWER(z.Long -(SELECT z1.Lat from Zip z1 inner join ` +
            "`order`" +
            ` o ON o.Zip = z1.Zip where o.OrderId = ${orderId}), 2))) AS distance 
        FROM signer s 
        LEFT JOIN zip z ON z.Zip = s.WeekdayZip
        WHERE s.SignerId = ${signerId};`;
        const checkAssignedSql = `select count(*) AS isAssigned from ` +
            "`order`" +
            ` o inner join signer s on o.SignerId = s.SignerId where o.SignerId = ${signerId} and o.OrderId = ${orderId};`;

        const queue = [];
        queue.push(Promise.resolve(Bookshelf.knex.raw(unAcknowledgedSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(aptDateTimeSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(loanTypeSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(agentSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(offerAmountSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(vendorSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(checkAssignedSql)));

        Promise.all(queue).then((result) => {
            if (result !== null) {
                const dateTime = result[1][0][0].aptDateTime;
                const aptDateTime = dateTime ? moment(dateTime).utc().format("YYYY-MM-DD HH:mm:ss") : null;
                const loanType = result[2][0][0] ? result[2][0][0].loantype : null;
                reply({
                    unAcknowledged: result[0][0][0].countProblem > 0 ? true : false,
                    aptDateTime,
                    loanType,
                    agent: result[3][0][0],
                    offerAmount: result[4][0][0].offerAmount,
                    vendor: result[5][0][0],
                    isAssigned: result[6][0][0].isAssigned > 0 ? true : false
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    updateSignerAddress(request, reply) {
        const signer = request.payload;

        Signers.where({
            SignerId: signer.SignerId
        }).save(signer, {
            method: "update"
        }).then((result) => {
            if (result !== null) {
                sendMailUpdateVendorProfile(signer.SignerId);
                reply({
                    isSuccess: true
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

}

export default new SignerController();