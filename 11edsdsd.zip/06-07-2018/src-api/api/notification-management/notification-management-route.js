import NotificationManagementController from "../notification-management/notification-management-controller";

const routes = [
    {
        path: "/manageNotification/getAllNotificationManagement",
        method: "GET",
        handler: NotificationManagementController.getAllNotificationManagement
    },
    {
        path: "/manageNotification/updateNotif",
        method: "POST",
        handler: NotificationManagementController.updateNotif
    },
    {
        path: "/manageNotification/sendEMail",
        method: "POST",
        handler: NotificationManagementController.sendEMail
    },
    {
        path: "/manageNotification/sendSMS",
        method: "POST",
        handler: NotificationManagementController.sendSms
    },

    {
        path: "/manageNotification/addNewAnnouncement",
        method: "POST",
        handler: NotificationManagementController.addNewAnnouncement
    },
    {
        path: "/manageNotification/updateAnnouncement",
        method: "POST",
        handler: NotificationManagementController.updateAnnouncement
    },
    {
        path: "/manageNotification/updateAnnouncementStatus",
        method: "POST",
        handler: NotificationManagementController.updateAnnouncementStatus
    },
    {
        path: "/manageNotification/deleteAnnouncement",
        method: "GET",
        handler: NotificationManagementController.deleteAnnouncement
    },
    {
        path: "/manageNotification/getAllLoanTypeAndState",
        method: "GET",
        handler: NotificationManagementController.getLoanTypeAndState
    },
    {
        path: "/manageNotification/getAnnouncementInfo",
        method: "GET",
        handler: NotificationManagementController.getAnnouncementInfo
    },
    {
        path: "/manageNotification/getNotifByNotifID",
        method: "GET",
        handler: NotificationManagementController.getNotifByNotifID
    },
    {
        path: "/manageNotification/getAnnoucements",
        method: "GET",
        handler: NotificationManagementController.getAnnoucements
    }
];
export default routes;
