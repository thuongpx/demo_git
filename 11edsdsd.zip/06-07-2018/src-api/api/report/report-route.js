import SendReport from "./report-controller";

const routes = [{
    path: "/report/sendClosing",
    method: "GET",
    handler: SendReport.sendClosing
}, {
    path: "/report/sendAptScheduled",
    method: "GET",
    handler: SendReport.sendAptScheduled
}, {
    path: "/report/sendFaxcover",
    method: "GET",
    handler: SendReport.sendFaxcover
}, {
    path: "/report/sendMailFaxcover",
    method: "POST",
    handler: SendReport.sendMailFaxcover
}, {
    path: "/report/sendConfirmation",
    method: "GET",
    handler: SendReport.sendConfirmation
}, {
    path: "/report/sendInvoice",
    method: "GET",
    handler: SendReport.sendInvoice
}];

export default routes;