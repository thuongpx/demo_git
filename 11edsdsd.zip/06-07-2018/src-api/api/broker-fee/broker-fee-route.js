import BrokerFeeController from "./broker-fee-controller";

const routes = [
    {
        path: "/brokerfee/getBrokerFeeByBrokerId",
        method: "GET",
        handler: BrokerFeeController.getBrokerFeeByBrokerId
    },
    {
        path: "/brokerfee/updateBrokerFee",
        method: "POST",
        handler: BrokerFeeController.updateBrokerFee
    }];

export default routes;