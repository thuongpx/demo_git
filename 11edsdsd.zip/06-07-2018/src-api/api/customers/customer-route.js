import CustomerController from "./customer-controller";

const routes = [
    {
        path: "/customer/getCustomers",
        method: "GET",
        handler: CustomerController.getCustomers
    },
    {
        path: "/customer/getCustomerById",
        method: "GET",
        handler: CustomerController.getCustomerById
    },
    {
        path: "/customer/deleteCustomer",
        method: "GET",
        handler: CustomerController.deleteCustomer
    },
    {
        path: "/customer/addCustomer",
        method: "POST",
        handler: CustomerController.addCustomer
    },
    {
        path: "/customer/updateCustomer",
        method: "POST",
        handler: CustomerController.updateCustomer
    },
    {
        path: "/customer/getAvailableSigner",
        method: "GET",
        handler: CustomerController.getAvailableSigner
    },
    {
        path: "/customer/getBlackListSigner",
        method: "GET",
        handler: CustomerController.getBlackListSigner
    },
    {
        path: "/customer/updateBlackListSigner",
        method: "POST",
        handler: CustomerController.updateBlackListSigner
    },
    {
        path: "/customer/updateWhiteListSigner",
        method: "POST",
        handler: CustomerController.updateWhiteListSigner
    },
    {
        path: "/customer/checkExistOrderAssociated",
        method: "GET",
        handler: CustomerController.checkExistOrderAssociated
    }
];

export default routes;