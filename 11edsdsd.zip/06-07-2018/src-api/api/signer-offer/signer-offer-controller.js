import Bookshelf from "../../db/database";
import Boom from "boom";
import moment from "moment";
import { isBuffer, bufferToBoolean } from "../../helper/common-helper";

class SignerOfferController {
    constructor() { }

    getOrdersSentOffers(request, reply) {
        const { sortColumn, sortDirection, page, itemPerPage, orderId } = request.query;
        const rawSql = `CALL GetOrdersSentOffers('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId === "" ? null : orderId});`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    const ordersSentOffersList = result[0][0];
                    const totalRecords = result[0][1][0].TotalRecords;

                    ordersSentOffersList.forEach((item) => {
                        if (isBuffer(item.TextSent)) {
                            item.TextSent = bufferToBoolean(item.TextSent);
                        }
                    });

                    reply({
                        ordersSentOffersList,
                        totalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
}

export default new SignerOfferController();