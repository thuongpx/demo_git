import Bookshelf from "../../db/database";
import Boom from "boom";

import Order from "../../db/model/order";
import OrderFeeApproval from "../../db/model/order-fee-approve";
import OrderFee from "../../db/model/order-fee";
import OrderProgressLog from "../../db/model/order-progress-log";
import OrderFeeApproveReason from "../../db/model/order-fee-approve-reason";
import SignerOffer from "../../db/model/signer-offer";
import Signer from "../../db/model/signers";

import { ORDER_FEE_VENDOR_REQUEST_STATUS, OFFER_STATUS } from "./../../constant/common-constant";
import { ORDER_PROGRESS_ID } from "./../../constant/progress-constant";
import { bufferToBoolean, handleSingleQuote, isBuffer, replaceAll, hasStringValue, logNotificationAndSendToVendor } from "../../helper/common-helper";
import { NOTIFICATION_TEMPLATE_PURPOSE } from "../../constant/common-constant";
import sendMailCore from "../../mail/mail-helper";


class OrderRequestApprovalController {
    constructor() { }

    checkVendorAssignConditionsOfOrder(request, reply) {
        const { orderId, signerId } = request.query;

        //get order aptDateTime
        Order.where({ orderId }).fetch({ columns: ["aptDateTime", "isVenOrCEDefineADT", "signerId", "progressId"] }).then((order) => {
            if (order.attributes.progressId === ORDER_PROGRESS_ID.CLOSED_PENDING_CLIENT_REVIEW ||
                order.attributes.progressId === ORDER_PROGRESS_ID.CLOSED_PENDING_QC_REVIEW ||
                order.attributes.progressId === ORDER_PROGRESS_ID.CLOSED_PENDING_REVIEW_PC_RESOLUTION ||
                order.attributes.progressId === ORDER_PROGRESS_ID.CLOSING_COMPLETED ||
                order.attributes.progressId === ORDER_PROGRESS_ID.CANCELED) {
                reply({
                    case: "CLOSED_ORDER"
                });
                return;
            }

            if (!hasStringValue(signerId)) {
                reply({
                    case: "SUCCESS"
                });
                return;
            }

            //get signer's Order's aptDateTime
            Order.where({ signerId }).fetchAll({ columns: ["aptDateTime", "isVenOrCEDefineADT", "progressId"] }).then((assignedOrders) => {
                //compare -> if duplicated -> return ADT_DUPLICATED
                if (assignedOrders !== null) {
                    for (let i = 0; i < assignedOrders.length; i++) {
                        const assignedOrder = assignedOrders.models[i];

                        if (assignedOrder.attributes.aptDateTime !== null && !bufferToBoolean(assignedOrder.attributes.isVenOrCEDefineADT) &&
                            order.attributes.aptDateTime !== null && !bufferToBoolean(order.attributes.isVenOrCEDefineADT) &&
                            assignedOrder.attributes.aptDateTime.toString() === order.attributes.aptDateTime.toString() &&
                            assignedOrder.attributes.progressId !== ORDER_PROGRESS_ID.CLOSED_PENDING_QC_REVIEW &&
                            assignedOrder.attributes.progressId !== ORDER_PROGRESS_ID.CLOSED_PENDING_REVIEW_PC_RESOLUTION &&
                            assignedOrder.attributes.progressId !== ORDER_PROGRESS_ID.CLOSING_COMPLETED &&
                            assignedOrder.attributes.progressId !== ORDER_PROGRESS_ID.POST_CLOSE &&
                            assignedOrder.attributes.progressId !== ORDER_PROGRESS_ID.CANCELED
                        ) {
                            reply({
                                case: "ADT_DUPLICATED"
                            });
                            return;
                        }
                    }
                }

                //already have signer
                if (order.attributes.signerId !== null && order.attributes.signerId !== undefined && order.attributes.signerId !== "") {
                    reply({
                        case: "SIGNER_ALREADY"
                    });
                    return;
                }
                reply({
                    case: "SUCCESS"
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    async approveFeeRequest(request, reply) {
        const payload = request.payload;

        const feeApproval = {
            feeApprovalId: payload.feeApprovalId,
            orderId: payload.orderId,
            feeApprovalDate: payload.feeApprovalDate,
            feeApproved: payload.isApprove ? ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED : ORDER_FEE_VENDOR_REQUEST_STATUS.REJECTED
        };
        const order = {
            orderId: payload.orderId,
            signerId: hasStringValue(payload.signerId) ? payload.signerId : undefined,
            progressId: ORDER_PROGRESS_ID.ASSIGNED_TO_VENDOR,
            filledDate: payload.feeApprovalDate
        };
        const orderFee = {
            signerFee: payload.signerFee,
            signerId: hasStringValue(payload.signerId) ? payload.signerId : undefined,
            feeDescripId: payload.feeDescripId,
            orderId: payload.orderId,
            //
            brokerFee: payload.brokerFee
        };
        const progressLog = {
            activity: payload.activity,
            progressType: payload.progressType,
            usersId: payload.usersId,
            orderId: payload.orderId,
            dateLog: payload.feeApprovalDate
        };
        const offer = {
            offerId: payload.offerId,
            offerStatus: payload.isApprove ? OFFER_STATUS.ACCEPTED : OFFER_STATUS.DECLINED,
            offerAmount: payload.isApprove ? payload.requestAmount : payload.originalAmount
        };

        const mailTemplates = {};

        const sendMail = (data, mailTemplate) => {
            let html = mailTemplate.Message;
            let subject = mailTemplate.Subject;

            Object.keys(data.needBindData).forEach(key => {
                html = replaceAll(html, `[${key}]`, hasStringValue(data.needBindData[key]) ? data.needBindData[key] : "");
                subject = replaceAll(subject, `[${key}]`, hasStringValue(data.needBindData[key]) ? data.needBindData[key] : "");
            });

            const mailOptions = {
                from: mailTemplate.FromEmail || "weborders@notarydirect.com",
                to: data.email,
                subject,
                html
            };

            sendMailCore(mailOptions);
        };

        const preSendMail = async (data) => {

            const templateKey = `${data.purpose}-${data.receiver}`;

            if (!mailTemplates[templateKey]) {
                const rawSqlGetTemplate = `SELECT * FROM notification_templates nt WHERE nt.Purpose = '${handleSingleQuote(data.purpose)}' AND nt.Receiver = '${data.receiver}';`;

                const result = await Bookshelf.knex.raw(rawSqlGetTemplate);

                mailTemplates[templateKey] = result[0][0];
            }
            const mailTemplate = mailTemplates[templateKey];
            sendMail(data, mailTemplate);

        };

        const sendMailRejectToVendor = (signerId) => {

            const sendMailToVendor = new Promise(() => {
                Signer.where({ signerId })
                    .fetch({ columns: ["firstName", "lastName", "email"] }).then(signer => {
                        const signerInfo = signer ? signer.attributes : {};
                        const email = signerInfo.email;

                        const mailData = {
                            purpose: NOTIFICATION_TEMPLATE_PURPOSE.REJECTE_FEE_REQUEST_BY_VENDOR,
                            email,
                            receiver: "Vendor",
                            needBindData: {
                                VendorName: `${hasStringValue(signerInfo.firstName) ? signerInfo.firstName : ``} ${hasStringValue(signerInfo.lastName) ? signerInfo.lastName : ``}`,
                                OrderID: hasStringValue(payload.orderId) ? payload.orderId : ``,
                                description: hasStringValue(payload.reason) ? payload.reason : ``,
                                OriginalFee: hasStringValue(payload.originalAmount) ? payload.originalAmount : ``,
                                ExpectedFee: hasStringValue(payload.requestAmount) ? payload.requestAmount : ``
                            }
                        };

                        preSendMail(mailData);

                    }).catch();


            });

            Promise.all([sendMailToVendor]);
        };

        const sendMailApproveToVendor = (signerId) => {
            if (!hasStringValue(payload.offerId)) {
                return;
            }
            const sqlGetOrderInfo = `SELECT SO.OfferAmount, L.LoanType, O.OrderId, O.AptDateTime, O.City,
            (69.1*SQRT(POWER(Z2.Lat-Z1.Lat, 2) + 0.6*POWER(Z2.Long - Z1.Long, 2))) AS Distance
            FROM \`order\` O
            INNER JOIN signer S ON O.OrderId=${payload.orderId} AND S.SignerId = ${signerId}
            LEFT JOIN loan_type L ON L.LoanTypeId = O.LoanType
            LEFT JOIN zip Z1 ON O.Zip = Z1.Zip
            LEFT JOIN zip Z2 ON S.WeekdayZip  = Z2.Zip
            LEFT JOIN signer_offer SO ON SO.OrderID = O.OrderId
            WHERE SO.OfferID = ${payload.offerId}`;

            Bookshelf.knex.raw(sqlGetOrderInfo).then(result => {
                const orderInfo = result[0][0];

                Signer.where({ signerId })
                    .fetch({ columns: ["firstName", "lastName", "email"] }).then(signer => {
                        const signerInfo = signer ? signer.attributes : {};
                        const email = signerInfo.email;

                        const mailData = {
                            purpose: NOTIFICATION_TEMPLATE_PURPOSE.OFFER_ACCEPTED_VENDOR,
                            email,
                            receiver: "Vendor",
                            needBindData: {
                                vendorFirstName: hasStringValue(signerInfo.firstName) ? signerInfo.firstName : ``,
                                vendorLastName: hasStringValue(signerInfo.lastName) ? signerInfo.lastName : ``,
                                orderId: hasStringValue(orderInfo.OrderId) ? orderInfo.OrderId : ``,
                                type: hasStringValue(orderInfo.LoanType) ? orderInfo.LoanType : ``,
                                aptDateTime: hasStringValue(orderInfo.AptDateTime) ? orderInfo.AptDateTime : ``,
                                city: hasStringValue(orderInfo.City) ? orderInfo.City : ``,
                                distance: hasStringValue(orderInfo.Distance) ? orderInfo.Distance : ``,
                                offerAmount: hasStringValue(orderInfo.OfferAmount) ? orderInfo.OfferAmount : ``
                            }
                        };

                        preSendMail(mailData);

                    }).catch();

            }).catch();
        };

        const sendMailRejectToAgent = (userId, signerId) => {
            const sendMailToVendor = new Promise(() => {
                const sqlSelectAgentInfo = `SELECT a.email, a.fullName
				FROM agent a
				INNER JOIN users u ON a.AgentId = u.MappingUserId
                WHERE u.UsersId = ${userId}`;
                Bookshelf.knex.raw(sqlSelectAgentInfo).then(agentResult => {
                    const agentInfo = agentResult[0][0];

                    Signer.where({ signerId })
                        .fetch({ columns: ["firstName", "lastName", "email"] }).then(signer => {
                            const signerInfo = signer ? signer.attributes : {};
                            const email = agentInfo.email;

                            const mailData = {
                                purpose: NOTIFICATION_TEMPLATE_PURPOSE.REJECTE_FEE_REQUEST_BY_VENDOR,
                                email,
                                receiver: "Client Agent",
                                needBindData: {
                                    VendorName: `${hasStringValue(signerInfo.firstName) ? signerInfo.firstName : ``} ${hasStringValue(signerInfo.lastName) ? signerInfo.lastName : ``}`,
                                    OrderID: hasStringValue(payload.orderId) ? payload.orderId : ``,
                                    description: hasStringValue(payload.reason) ? payload.reason : ``,
                                    OriginalFee: hasStringValue(payload.originalAmount) ? payload.originalAmount : ``,
                                    ExpectedFee: hasStringValue(payload.requestAmount) ? payload.requestAmount : ``,
                                    AgentName: hasStringValue(agentInfo.fullName) ? agentInfo.fullName : ``
                                }
                            };

                            preSendMail(mailData);

                            const mailDataForVendor = Object.assign({}, mailData);
                            mailDataForVendor.needBindData = Object.assign({}, mailData.needBindData);
                            mailDataForVendor.receiver = "Vendor";
                            mailDataForVendor.email = signerInfo.email;
                            delete mailDataForVendor.needBindData.AgentName;
                            setTimeout(() => preSendMail(mailDataForVendor), 1000);

                        }).catch();
                }).catch();

            });

            Promise.all([sendMailToVendor]);
        };

        const sendMailApproveToAgent = (userId, signerId) => {
            const sendMailToVendor = new Promise(() => {
                const sqlSelectAgentInfo = `SELECT a.email, a.fullName
				FROM agent a
				INNER JOIN users u ON a.AgentId = u.MappingUserId
                WHERE u.UsersId = ${userId}`;
                Bookshelf.knex.raw(sqlSelectAgentInfo).then(agentResult => {
                    const agentInfo = agentResult[0][0];

                    Signer.where({ signerId })
                        .fetch({ columns: ["firstName", "lastName", "email"] }).then(signer => {
                            const signerInfo = signer ? signer.attributes : {};
                            const email = agentInfo.email;

                            const mailData = {
                                purpose: NOTIFICATION_TEMPLATE_PURPOSE.APPROVE_FEE_REQUEST_BY_AGENT,
                                email,
                                receiver: "Client Agent",
                                needBindData: {
                                    VendorName: `${hasStringValue(signerInfo.firstName) ? signerInfo.firstName : ``} ${hasStringValue(signerInfo.lastName) ? signerInfo.lastName : ``}`,
                                    OrderID: hasStringValue(payload.orderId) ? payload.orderId : ``,
                                    description: hasStringValue(payload.reason) ? payload.reason : ``,
                                    OriginalFee: hasStringValue(payload.originalAmount) ? payload.originalAmount : ``,
                                    ExpectedFee: hasStringValue(payload.requestAmount) ? payload.requestAmount : ``,
                                    AgentName: hasStringValue(agentInfo.fullName) ? agentInfo.fullName : ``
                                }
                            };

                            setTimeout(() => preSendMail(mailData), 1000);

                        }).catch();
                }).catch();

            });

            Promise.all([sendMailToVendor]);
        };

        const updateOthersApprovalInfo = () => {
            const sqlGetOtherFeeRequest = `SELECT feeApprovalId, offerId, signerID, usersId, IsUserVendor(usersId) as requestByVendor from order_fee_approve WHERE feeApproved = '${ORDER_FEE_VENDOR_REQUEST_STATUS.PENDING}' AND orderId = ${feeApproval.orderId}`;
            Bookshelf.knex.raw(sqlGetOtherFeeRequest)
                .then((data) => {
                    const otherOrder = data[0];

                    const rejectOthersApproval = (feeRequest) => {
                        let result = "success";
                        const { feeApprovalId, offerId, signerID } = feeRequest;

                        OrderFeeApproval
                            .where({ feeApprovalId })
                            .save({ feeApproved: ORDER_FEE_VENDOR_REQUEST_STATUS.REJECTED }, { method: "update" })
                            .then(() => {
                                //send rejected mail here
                                if (isBuffer(feeRequest.requestedByVendor)) {
                                    feeRequest.requestedByVendor = bufferToBoolean(feeRequest.requestedByVendor);
                                }
                                if (feeRequest.requestedByVendor) {
                                    sendMailRejectToVendor(signerID);
                                } else {
                                    sendMailRejectToAgent(feeRequest.usersId, feeRequest.signerID);
                                }

                                if (offerId !== null && offerId !== undefined && offerId !== offer.offerId) {
                                    SignerOffer
                                        .where({ offerId })
                                        .save({ offerStatus: OFFER_STATUS.DECLINED }, { method: "update" })
                                        .then(() => {
                                            //send offer declined here
                                        })
                                        .catch((error) => {
                                            result = error;
                                        });
                                }
                            })
                            .catch((error) => {
                                result = error;
                            });

                        return result;
                    };

                    let error = "success";
                    for (let i = 0; i < otherOrder.length; i++) {
                        const feeRequest = otherOrder[i];

                        const result = rejectOthersApproval(feeRequest);

                        if (result !== "success") {
                            error = result;
                        }
                    }

                    if (error !== "success") {
                        reply(Boom.badRequest(error));
                        return;
                    } else {

                        reply({ isSuccess: true });
                        return;
                    }
                })
                .catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                });
        };

        const updateAdditionalInfo = (trsn) => {
            if (feeApproval.feeApproved === ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED) {
                OrderFee
                    .where({ orderId: orderFee.orderId, feeDescripId: orderFee.feeDescripId })
                    .save(orderFee, { method: "update", require: true, transacting: trsn })
                    .then(() => {
                        Order
                            .where({ OrderId: order.orderId })
                            .save(order, { method: "update", require: true, transacting: trsn })
                            .then(() => {
                                //save new progresslog
                                new OrderProgressLog()
                                    .save(progressLog, { method: "insert", transacting: trsn })
                                    .then(() => {
                                        trsn.commit();

                                    })
                                    .catch((error) => {
                                        trsn.rollback(error);
                                    });
                            })
                            .catch((error) => {
                                trsn.rollback(error);
                            });
                    })
                    .catch((error) => {
                        trsn.rollback(error);
                    });
            } else {
                new OrderProgressLog().save(progressLog, { method: "insert", transacting: trsn })
                    .then(() => {
                        trsn.commit();
                    })
                    .catch((error) => {
                        trsn.rollback(error);
                    });
            }
        };

        if (order.signerId && payload.isApprove) {
            await logNotificationAndSendToVendor(order.orderId, order.signerId, false);
        }

        Bookshelf.transaction((trsn) => {
            OrderFeeApproval
                .where({ feeApprovalId: feeApproval.feeApprovalId, feeApproved: ORDER_FEE_VENDOR_REQUEST_STATUS.PENDING })
                .save(feeApproval, { method: "update", require: true, transacting: trsn })
                .then(() => {
                    if (offer.offerId !== null && offer.offerId !== undefined) {
                        SignerOffer
                            .where(feeApproval.feeApproved === ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED
                                ? { offerId: offer.offerId, offerStatus: OFFER_STATUS.PENDING }
                                : { offerId: offer.offerId })
                            .save(offer, { method: "update", require: true, transacting: trsn })
                            .then(() => {
                                updateAdditionalInfo(trsn);
                            })
                            .catch((error) => {
                                trsn.rollback(error);
                            });
                    } else {
                        updateAdditionalInfo(trsn);
                    }
                }).catch((error) => {
                    trsn.rollback(error);
                });
        })
            .then(() => {
                //send approve or decline mail here mail here
                if (feeApproval.feeApproved === ORDER_FEE_VENDOR_REQUEST_STATUS.APPROVED) {
                    updateOthersApprovalInfo();

                    // send mail approve request fee
                    if (payload.requestedByVendor) {
                        sendMailApproveToVendor(payload.signerId);
                    } else {
                        sendMailApproveToAgent(payload.requestedBy, payload.signerId);
                        sendMailApproveToVendor(payload.signerId);
                    }
                } else {

                    if (payload.requestedByVendor) {
                        sendMailRejectToVendor(payload.signerId);
                    } else {
                        sendMailRejectToAgent(payload.requestedBy, payload.signerId);
                    }

                    reply({ isSuccess: true });
                    return;
                }
            })
            .catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    submitFeeRequestToMgr(request, reply) {
        const payload = request.payload;
        const feeApproval = {
            feeApprovalId: payload.feeApprovalId,
            usersId: payload.usersId
        };

        Bookshelf.transaction((trsn) => {
            OrderFeeApproval.where({ feeApprovalId: feeApproval.feeApprovalId, feeApproved: ORDER_FEE_VENDOR_REQUEST_STATUS.PENDING })
                .save(feeApproval, { method: "update", require: true, transacting: trsn })
                .then(() => {
                    trsn.commit();
                    reply({ isSuccess: true });
                    return;
                }).catch((error) => {
                    trsn.rollback(error);
                    reply(Boom.badRequest(error));
                    return;
                });
        });
    }

    getOrderFeeApprovalReasonStaff(request, reply) {
        const columns = ["ReasonCode", "ReasonDescription"];

        OrderFeeApproveReason.where({ Type: "S" }).fetchAll({ columns }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true, result });
                return;
            }
            reply({ isSuccess: false, message: "No record found!" });
            return;
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    sendMailWhenSubmitToManager(request, reply) {
        const { orderId, signerId, originalAmount, requestAmount, vendorName, reason } = request.payload;

        const managerNameSql = `SELECT CONCAT_WS(" ",B.PrimaryContactFirst, B.PrimaryContactLast) AS ManagerName, B.Email
        FROM \`order\` O INNER JOIN broker B ON O.BrokerId = B.BrokerID AND O.OrderId = ${orderId};`;

        const rawSql = `select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'submit fee request to manager sent by agent';`;

        Bookshelf.knex.raw(managerNameSql)
            .then((data) => {
                const managerName = data[0][0].ManagerName;
                const managerEmail = data[0][0].Email;

                Bookshelf.knex.raw(rawSql)
                    .then((message) => {
                        let html = message[0][0].message;

                        html = replaceAll(html, `[managerFullName]`, hasStringValue(managerName) ? managerName : "");
                        html = replaceAll(html, `[orderId]`, hasStringValue(orderId) ? orderId : "");
                        html = replaceAll(html, `[repId]`, hasStringValue(signerId) ? signerId : "");
                        html = replaceAll(html, `[originalFee]`, hasStringValue(originalAmount) ? originalAmount : "");
                        html = replaceAll(html, `[expectedFee]`, hasStringValue(requestAmount) ? requestAmount : "");
                        html = replaceAll(html, `[vendorFullName]`, hasStringValue(vendorName) ? vendorName : "");
                        html = replaceAll(html, `[Description]`, hasStringValue(reason) ? reason : "");

                        const mailVendorOptions = {
                            html,
                            from: message[0][0].fromEmail,
                            to: managerEmail,
                            subject: replaceAll(message[0][0].subject, `[orderId]`, hasStringValue(orderId) ? orderId : ""),
                            text: `Send Email`
                        };
                        sendMailCore(mailVendorOptions);

                        reply({ isSuccess: true });
                        return;
                    })
                    .catch(() => {
                        reply({ isSuccess: true });
                        return;
                    });
            })
            .catch(() => {
                reply({ isSuccess: true });
                return;
            });
    }
}

export default new OrderRequestApprovalController();