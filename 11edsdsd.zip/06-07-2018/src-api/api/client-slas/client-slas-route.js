import ClientSlasController from "./client-slas-controller";
const routes = [{
    path: "/client-slas/getClientSlasById",
    method: "GET",
    handler: ClientSlasController.getClientSlasById
}];

export default routes;