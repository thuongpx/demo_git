import Boom from "boom";
import Bookshelf from "../../db/database";

class ClientSlasController {
    getClientSlasById(request, reply) {
        const { brokerId } = request.query;

        const rawSql = `select Id, BrokerId, SLA, DefaultFrom, DefaultTo, \`From\`, \`To\` from broker_slas where BrokerId = ${brokerId}`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        listClientSlas: result[0]
                    });
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }
}

export default new ClientSlasController();