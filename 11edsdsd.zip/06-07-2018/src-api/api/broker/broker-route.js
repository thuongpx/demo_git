import BrokerController from "./broker-controller";

const routes = [
    {
        path: "/broker/getBrokerAddressById",
        method: "GET",
        handler: BrokerController.getBrokerAddressById
    },
    {
        path: "/broker/updateBrokerById",
        method: "PUT",
        handler: BrokerController.updateBrokerById
    },
    {
        path: "/broker/getBrokerById",
        method: "GET",
        handler: BrokerController.getBrokerById
    },
    {
        path: "/broker/getAllBrokers",
        method: "GET",
        handler: BrokerController.getAllBrokers
    },
    {
        path: "/broker/getBrokerAdminById",
        method: "GET",
        handler: BrokerController.getBrokerAdminById
    },
    {
        path: "/broker/getBrokerBranchById",
        method: "GET",
        handler: BrokerController.getBrokerBranchById
    },
    {
        path: "/broker/getBrokerInfoDefault",
        method: "GET",
        handler: BrokerController.getBrokerInfoDefault
    },
    {
        path: "/broker/getApprovalRequestNumber",
        method: "GET",
        config: {
            auth: false
        },
        handler: BrokerController.getApprovalRequestNumber
    },
    {
        path: "/broker/getInitDataForClientOrderAssignConfig",
        method: "GET",
        handler: BrokerController.getInitDataForClientOrderAssignConfig
    },
    {
        path: "/broker/getlistClientPreferred",
        method: "GET",
        handler: BrokerController.getlistClientPreferred
    },
    {
        path: "/broker/getClientOrderAssignConfigLog",
        method: "GET",
        handler: BrokerController.getClientOrderAssignConfigLog
    },
    {
        path: "/broker/saveClientOrderAssignConfig",
        method: "POST",
        handler: BrokerController.saveClientOrderAssignConfig
    },
    {
        path: "/broker/getListClientAdmin",
        method: "GET",
        handler: BrokerController.getListClientAdmin
    },
    {
        path: "/broker/getBrokerDataById",
        method: "POST",
        handler: BrokerController.getBrokerDataById
    }
];

export default routes;