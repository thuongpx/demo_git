DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	-- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'RoleAndPermission') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `RoleAndPermission`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ClientManagement') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ClientManagement`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ClientPipeline') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ClientPipeline`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'Chatting') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `Chatting`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'VendorManagement') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `VendorManagement`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'VendorPipeline') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `VendorPipeline`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'InternalUserManagement') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `InternalUserManagement`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'AssignVendor') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `AssignVendor`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'VendorClassification') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `VendorClassification`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'Reporting') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `Reporting`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'AddViewOrder') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `AddViewOrder`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'VendorRatingSetting') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `VendorRatingSetting`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'FeeApproval') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `FeeApproval`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'VendorApproval') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `VendorApproval`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ServiceConfigurationApproval') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ServiceConfigurationApproval`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'VendorCredentialsDocumentApproval') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `VendorCredentialsDocumentApproval`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'SignedDocumentApproval') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `SignedDocumentApproval`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ChangeFeeOnClosedOrders') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ChangeFeeOnClosedOrders`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'DisableNewOrders') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `DisableNewOrders`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'AutoOrders') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `AutoOrders`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'IssueApproval') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `IssueApproval`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'IssueReporting') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `IssueReporting`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'UserProfileSetting') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `UserProfileSetting`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'FeeRequest') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `FeeRequest`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ClientProfile') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ClientProfile`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ServiceConfiguration') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ServiceConfiguration`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ManageCustomer') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ManageCustomer`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ManageBranch') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ManageBranch`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ManageAgent') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ManageAgent`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ViewAllOrders') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ViewAllOrders`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'AddOrder') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `AddOrder`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ManageOrderDetails') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ManageOrderDetails`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'VendorDoNotUse') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `VendorDoNotUse`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ViewVendorDetails') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ViewVendorDetails`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'Tools') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `Tools`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'UserManagement') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `UserManagement`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'ContentManagement') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `ContentManagement`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'TrainingAndTesting') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `TrainingAndTesting`;
	END;
    END IF;
    
    -- Drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'roles' AND 
                            COLUMN_NAME = 'Accounting') THEN
	BEGIN
		ALTER TABLE `roles`
        DROP COLUMN `Accounting`;
	END;
    END IF;
END$$
DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;