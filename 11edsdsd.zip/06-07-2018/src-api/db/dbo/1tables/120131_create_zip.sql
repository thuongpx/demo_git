CREATE TABLE IF NOT EXISTS `zip`(
	`Zip` CHAR(5) NOT NULL,
	`City` VARCHAR(30) NULL,
	`County` VARCHAR(30) NULL,
	`State` CHAR(2) NULL,
	`AreaCode` VARCHAR(20) NULL,
	`Long` FLOAT NULL,
	`Lat` FLOAT NULL,
	`TimeZone` VARCHAR(15) NULL,
	`UTC` FLoAT NULL,
	`DST` char(1) NULL,
    primary key(`Zip`)
) 

