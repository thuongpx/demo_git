-- Modify table broker
ALTER TABLE broker CHANGE COLUMN `OwnerFirst` `AdministratorFirst` VARCHAR(50) NULL;
ALTER TABLE broker CHANGE COLUMN `OwnerLast` `AdministratorLast` VARCHAR(50) NULL;
ALTER TABLE broker CHANGE COLUMN `OwnerExt` `AdministratorExt` VARCHAR(50) NULL;
ALTER TABLE broker CHANGE COLUMN `OwnerFax` `AdministratorEmail` VARCHAR(70) NULL;
ALTER TABLE broker ADD COLUMN `Suite` VARCHAR(50) NULL;