CREATE TABLE IF NOT EXISTS `test_sections` (
  `SectionId` INT(11) NOT NULL AUTO_INCREMENT,
  `SectionDescription` VARCHAR(255) NOT NULL,
  `TestID` INT NOT NULL,
  `SortOrder` SMALLINT,
  PRIMARY KEY (`SectionId`),
  KEY `testid_test_section_idx` (TestID),
  CONSTRAINT `testid_test_section` FOREIGN KEY(`TestID`) REFERENCES `test_info` (`TestID`) ON UPDATE NO ACTION ON DELETE NO ACTION
)
