DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
    -- change column size
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'AssignOrdersDirectly') THEN
	BEGIN
		ALTER TABLE `broker` 
		ADD COLUMN `AssignOrdersDirectly` BIT NULL;
	END;
    END IF;
    
    -- change column size
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'TceFullFill') THEN
	BEGIN
		ALTER TABLE `broker` 
		ADD COLUMN `TceFullFill` BIT NULL;
	END;
    END IF;
END$$

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;