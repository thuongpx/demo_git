DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'biz_hours_except' AND 
                            COLUMN_NAME = 'ExceptID') THEN
	BEGIN
		ALTER TABLE `biz_hours_except` 
		MODIFY COLUMN `ExceptID` INT AUTO_INCREMENT;
	END;
    END IF;    
END$$

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;