use tce_dev;

CREATE TABLE IF NOT EXISTS `client_services_config_log` (
	`LogID` INT NOT NULL AUTO_INCREMENT,
    `ConfigId` INT NOT NULL,
    `UpdatedDate` DATETIME NULL,
    `UpdatedBy` INT NULL,
    `Status` INT(11) NULL,
    `EffecttiveDate` DATETIME NULL,
    `UseVolume` BIT NULL,
    `OrderPerDay` TINYINT NULL,
    `UseCalendar` BIT NULL,
    `CutoffDate` TINYINT NULL,
    `UseGeography` BIT NULL,
    `State1` VARCHAR(200) NULL,
    `MSA1` VARCHAR(500) NULL,
    PRIMARY KEY (LogID),
    KEY `configid_client_services_config_log_idx` (`ConfigId`),
    CONSTRAINT `configid_client_services_config_log` FOREIGN KEY(`ConfigId`)
		REFERENCES `client_services_config` (`ConfigId`) ON UPDATE NO ACTION ON DELETE NO ACTION
);