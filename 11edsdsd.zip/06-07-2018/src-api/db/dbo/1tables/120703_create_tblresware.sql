CREATE TABLE IF NOT EXISTS `tblresware` (
	`BrokerId` INT NOT NULL,
	`UserName` VARCHAR(50),
	`Password` VARCHAR(50),
	PRIMARY KEY (`BrokerId`)
);
