DROP procedure IF EXISTS `ChangeOrderFeeApproveStatus`;

DELIMITER $$
CREATE PROCEDURE `ChangeOrderFeeApproveStatus`(
    IN inOrderId INT,
	IN inFeeApprovalId INT,
    IN inFeeApproved VARCHAR(15),
    IN inOfferStatus VARCHAR(3),
    IN inSignerId INT,
    IN inSignerFee DECIMAL,
    In inFeeDescripId INT,
    IN inActivity VARCHAR(255),
    IN inUserId INT,
    IN inIsOveride BOOLEAN
)
BEGIN
main: BEGIN
	DECLARE isSuccess INT;
    DECLARE anotherOrderId INT;
    DECLARE anotherSignerId INT;
    
	-- ----------------------
	START TRANSACTION;
        
        -- // Check conditions for approve
        IF inFeeApproved = 'Approved' THEN
        
			-- Check vendor is having the same ADT order
			SELECT `OrderId` INTO anotherOrderId
				FROM `order`
				WHERE `OrderId` <> inOrderId
					AND `SignerId` = inSignerId
					AND `AptDateTime` = (SELECT `AptDateTime`
											FROM `order`
											WHERE `OrderId` = inOrderId);
											
			IF anotherOrderId IS NOT null AND anotherOrderId <> ''
			THEN
				SELECT 2 as isSuccess;
				LEAVE main;
			END IF;
			-- //
			
			-- Check order has another assigned Vendor
			SELECT `SignerId` INTO anotherSignerId
				FROM `order`
				WHERE `OrderId` = inOrderId;
			
			IF !inIsOveride AND anotherSignerId IS NOT null AND anotherSignerId <> '' AND anotherSignerId <> inSignerId
			THEN
				BEGIN
				SELECT 3 as isSuccess;
				LEAVE main;
				END;
			END IF;
			-- //
            
        END IF;
    
		-- Change status FeeApproved in order_fee_approve
		UPDATE `order_fee_approve`
			SET `FeeApproved` = inFeeApproved
			WHERE `FeeApprovalId` = inFeeApprovalId;
	
		-- Change status OfferStatus in signer_offer
		UPDATE `signer_offer`
			SET `OfferStatus` = inOfferStatus
			WHERE `OrderId` = inOrderId AND `SignerId` = inSignerId;
            
		-- Update signer Fee in order_fee
        UPDATE `order_fee`
			SET `SignerFee` = inSignerFee
            WHERE `OrderId` = inOrderId AND `FeeDescripId` = inFeeDescripId;
            
		-- Insert to order_progress_log
        INSERT INTO `order_progress_log`
			(`OrderId`, `Activity`, `UsersId`, `DateLog`)
			VALUES
			(inOrderId, inActivity, inUserId, UTC_TIMESTAMP());
            
		-- If status of order_fee_approve is Rejected
			-- OR user request is not a vendor
            -- leave the procedure with success status
		IF inFeeApproved != 'Approved' OR inSignerId IS NULL THEN
			SELECT 1 as isSuccess;
            COMMIT;
            LEAVE main;
		END IF;
        -- //
        
        -- Update SignerId of order
        UPDATE `order`
			SET `SignerId` = inSignerId
			WHERE `OrderId` = inOrderId;
            
		-- PENDING ADD NEW RECORD FOR VENDOR HISTORY
        
	COMMIT;
    SELECT 1 as isSuccess;
END main;
END$$
DELIMITER ;
