module.exports = {
    "main": "./app.jsx",
    "vendor": [
        "react", "react-dom", "react-router", "prop-types",
        "react-redux", "redux", "redux-thunk",
        "braintree-web",
        "react-color",
        "react-input-mask",
        "react-tooltip",
        "moment",
        "react-selectize",
        "axios",
        "universal-cookie",
        "jwt-decode",
        "core-js"
    ]
};