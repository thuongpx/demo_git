// import "../../node_modules/core-js/fn/array/find";
// import "../../node_modules/core-js/fn"

import "core-js";

import React from "react";
import { render } from "react-dom";
import { routes } from "Routes";
import { Router, browserHistory } from "react-router";
import { createStore, compose, applyMiddleware } from "redux";
import { Provider } from "react-redux";
import rootReducer from "./screens/main-layout/reducers/root";
import thunkMiddleware from "redux-thunk";
import { createLogger, AUTH_REMOVE_TOKEN } from "redux-logger";

const loggerMiddleware = createLogger({
  predicate: (getState, action) => action.type !== AUTH_REMOVE_TOKEN
});

const enhancer = compose(
  applyMiddleware(thunkMiddleware, loggerMiddleware)
);

window.webappStart = () => {
  const initialState = window.__PRELOADED_STATE__;
  const store = createStore(rootReducer, initialState, enhancer);
  const createElement = (Component, props) => {
    // eslint-disable-next-line
    return <Component key={props.params.orderId} {...props} />;
  };

  render(
    <Provider store={store}>
      <Router history={browserHistory} createElement={createElement}>{routes}</Router>
    </Provider>,
    document.querySelector(".js-content .wrap-page")
  );
};