export const PERFORMANCE_RATING = {
    Excellent: 1,
    VeryGood: 2,
    Good: 3,
    Poor: 4,
    NeedsImprovement: 5,
    New: 6
};