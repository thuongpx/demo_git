export const COOKIES_KEY = {
  CE_ADDITIONAL_SECURITY_TOKEN: "CE_ADDITIONAL_SECURITY_TOKEN",
  CE_ACCESS_TOKEN: "CE_ACCESS_TOKEN",
  CE_AUTHENTICATION_USER: "CE_AUTHENTICATION_USER",
  CE_CHALLENGE_QUESTION_CONFIRMED: "CE_CHALLENGE_QUESTION_CONFIRMED"
};

export const COMMENT_TYPE = {
  OrderCommentType: 1,
  RequestFeeCommentType: 2,
  OrderIssueCommentType: 3,
  VendorApprovalCommentType: 4
};

export const USER_STATUS = {
  OFFLINE: 0,
  ONLINE: 1,
  DO_NOT_DISTURB: 2
};

export const USER_TYPE = {
  Staff: "Staff",
  Client: "Client",
  Vendor: "Vendor"
};

export const CLIENT_SUBTYPE_DISPLAY = {
  CLIENT: "Client",
  BRANCH: "Branch",
  AGENT: "Agent"
};

export const OFFER_STATUS = {
  Accepted: "A",
  Declined: "D",
  Expired: "E",
  Missed: "M",
  Pending: "P"
};

export const REQUEST_FEE_STATUS = {
  Open: "Open",
  Approved: "Approved",
  Rejected: "Rejected"
};

export const ORDER_REQUEST_APPROVE_STATUS = {
  OPEN: "Pending",
  APPROVED: "Approved",
  REJECTED: "Rejected"
};

export const SUCCESSFULLY_CREATED_MESSAGE = "Created Successfully";
export const SUCCESSFULLY_SAVED_MESSAGE = "Saved Successfully";
export const SUCCESSFULLY_UPDATE_MESSAGE = "Updated Successfully";
export const SUCCESSFULLY_DELETED_MESSAGE = "Deleted Successfully";
export const SUCCESSFULLY_DISABLED_MESSAGE = "Disabled Successfully";
export const SUCCESSFULLY_INACTIVED_MESSAGE = "Inactived Successfully";
export const SUCCESSFULLY_ACTIVED_MESSAGE = "Actived Successfully";
export const SUCCESSFULLY_RESET_PASSWORD = "The Password has been reset";
export const SUCCESSFULLY_INACTIVATED_MESSAGE = "Inactivated Successfully";

export const INVALID_RANGE_DATE = "From date cannot be greater than To date. Please re-select!";

export const ENTER_SEARCH_MESSAGE = "Please enter Search Criteria first!";

export const REJECTED_REASON_MESSAGE = "Please enter reason to reject!";

export const BI_LINGUAL_VENDOR_FEE_DESCRIPTION = "Bi-Lingual Vendor";
export const ROOM_RENTAL_FEE_DESCRIPTION = "Room Rental";

//CC Email Recipients
export const INVALID_CC_EMAIL_CHECK_MESSAGE = "You must select at least one option either Invoice Only or Status Only.";

export const CE_SYSTEM_ROLES = {
  Admin: "Admin",
  OperationalManage: "Operational Manager"
};

export const LIST_DROPDOWN_OF_CLIENT_REGISTRATION_ADDITIONAL_INFO = {
  howHear: ["Google Search", "Bing Search", "Email", "Tradeshow/Event", "Referral", "TCE Account Rep", "Social Media"],
  socialMedia: ["Facebook", "Twitter", "LinkedIn"]
};

export const SUCCESSFULLY_RE_VALIDATE_AUTHENTICATION = "Challenge questions have been removed for this company";

export const LIST_CONST_FOR_CLIENT_REGIST_VENDOR_REQUIREMENTS = {
  experience: [],
  performanceRatings: []
};

export const LIST_CONST_OF_CLIENT_ADDITIONAL_INFORMATION = {
  documentDelivery: [{
    id: "overNight",
    data: "Overnight to customer or signing agent"
  },
  {
    id: "secureEmail",
    data: "Secure Email to TCE"
  },
  {
    id: "uploadedToTCE",
    data: "Uploaded to TCE system website/portal"
  },
  {
    id: "docAtLocation",
    data: "Documents at location"
  }
  ],
  documentPrint: ["Legal", "Letter", "Both"],
  copyPackage: ["Automatically", "Vendor makes copy"],
  colorInk: ["Blue", "Black", "Either"],
  timeApptMustSchedule: ["Today", "24 hours", "48 hours", "72 hours", "96 hours", "Whenever the customer decides"]
};
export const CLIENT_ERROR_REQUIRED_SAVE = "Please complete all 2 required tabs before clicking Save button";

export const ORDER_STATUS_CAN_OVERRIDE_VENDOR = [1, 2, 3, 4, 5, 6, 11];

export const VENDOR_REQUIREMENTS_DATA = {
  experience: [
    {
      value: 100,
      data: "100+ Orders"
    },
    {
      value: 75,
      data: "75+ Orders"
    },
    {
      value: 50,
      data: "50+ Orders"
    },
    {
      value: 25,
      data: "25+ Orders"
    },
    {
      value: 0,
      data: "0+ Orders"
    }
  ],
  performanceRatings: [{
    value: "New",
    data: "New"
  },
  {
    value: "Good",
    data: "Good"
  },
  {
    value: "Very Good",
    data: "Very Good"
  },
  {
    value: "Excellent",
    data: "Excellent"
  }
  ]
};

export const CLIENT_TOTAL_TRANSACTIONS_IN_MONTH = [{
  value: 10,
  data: ">10 transactions"
},
{
  value: 30,
  data: ">30 transactions"
},
{
  value: 50,
  data: ">50 transactions"
},
{
  value: 100,
  data: ">100 transactions"
},
{
  value: 200,
  data: ">200 transactions"
}
];

export const COLORS_LIST = [
  "#000000", "#00303F", "#007849", "#008F95", "#015249", "#01ABAA", "#02558B", "#02C8A7", "#031424",
  "#0375B4", "#056571", "#063F4F", "#07889B", "#08302F", "#0A1612", "#0B3C5D", "#0E0B16", "#0E8044",
  "#0F1626", "#155765", "#16A085", "#18121E", "#192231", "#1A0315", "#1A2930", "#1ABC9C", "#1B7B34",
  "#1D2731", "#1E392A", "#1FB58F", "#22252C", "#233237", "#262228", "#27AE60", "#286DA8", "#2980B9",
  "#2C3E50", "#2ECC71", "#30415D", "#328CC1", "#333A56", "#34495E", "#3498DB", "#373737", "#373F27",
  "#3C3C3C", "#3CC47C", "#3F3250", "#414141", "#438496", "#4484CE", "#465C8B", "#4717F6", "#49274A",
  "#494E6B", "#4ABDAC", "#4CDEF5", "#4D2C3D", "#4EC5C1", "#52658F", "#535353", "#565656", "#575DA9",
  "#57652A", "#57BC90", "#5F0F4E", "#626E60", "#62EDD6", "#636B46", "#66AB8C", "#66B9BF", "#675682",
  "#67AECA", "#6B7A8F", "#6D7993", "#6E3667", "#6E7376", "#6EC4DB", "#76323F", "#77C9D4", "#7A9D96",
  "#7CDBD5", "#813772", "#828081", "#841983", "#874C62", "#88BBD6", "#88D317", "#8EAEBD", "#8FC33A",
  "#9099A2", "#93C178", "#945D60", "#94618E", "#96858F", "#984B43", "#985E6D", "#98878F", "#99CED4",
  "#99D3DF", "#9B59B6", "#A239CA", "#A4D555", "#A5A5AF", "#A7B3A5", "#A7D2CB", "#A9A9A9", "#A9B7C0",
  "#AB9353", "#AB987A", "#AF473C", "#B37D4E", "#B4DBC0", "#B56357", "#B5E582", "#B82601", "#BFD8D2",
  "#C06014", "#C09F80", "#C0B283", "#C0B3A0", "#C5C1C0", "#C7BB36", "#C7D8C6", "#C98474", "#CAE4DB",
  "#CAEBF2", "#CCCBC6", "#CCDFC8", "#CD5360", "#CDA34F", "#CDCDCD", "#CF6766", "#D35400", "#D48CF8",
  "#D5D5D5", "#D7CEC7", "#D7DD35", "#D9B310", "#D9D9D9", "#DCAE1D", "#DCB239", "#DCC7AA", "#DCD0C0",
  "#DF744A", "#DFDCE3", "#E14658", "#E24E42", "#E37222", "#E42D9F", "#E52A6F", "#E67E22", "#E74C3C",
  "#E7DFDD", "#E8E8E8", "#E9B000", "#E9C893", "#E9C904", "#E9E7DA", "#E9E9E9", "#EAB126", "#EAC67A",
  "#EAE3EA", "#EB6E80", "#EC576B", "#EDD8CD", "#EEAA7B", "#EEB6B7", "#EFD9C1", "#EFEFEF", "#F19F4D",
  "#F1C40F", "#F24C4E", "#F2D388", "#F39C12", "#F3A680", "#F4DECB", "#F4F4F4", "#F53240", "#F5F5F5",
  "#F7882F", "#F7B733", "#F7C331", "#F7CE3E", "#F7EF6A", "#F7F5F6", "#F8EEE7", "#F9BE02", "#F9CF00",
  "#FA7C92", "#FC4A1A", "#FE65B7", "#FEDC3D", "#FEDCD2", "#FF3B3F", "#FF533D", "#FF5992", "#FF6A5C",
  "#FFCE00", "#FFF7C0"
];
// client types: agent, branch and client
export const CLIENT_SUB_ROLE = {
  AGENT: "AGENT",
  BRANCH: "BRANCH",
  CLIENT: "CLIENT"
};

// message modal types: confirm, error, warning, inform
export const MESSAGE_MODAL_TYPES = {
  ERROR: "error",
  WARNING: "warning",
  CONFIRMATION: "confirm",
  INFORMATION: "information"
};

export const MESSAGE_CANCEL_UPDATING = "Are you sure you want to cancel to update ?";

export const ORDER_PROGRESS_LOG_ACTIVITIES = {
  FEE_REQUEST_SENT: "Fee Request Sent",
  FEE_REQUEST_APPROVED: "Fee Request Approved",
  FEE_REQUEST_REJECTED: "Fee Request Rejected",
  COMMENT_ADDED: "Comment Added",
  VENDOR_REQUEST_APPROVED: "Assigned to Vendor",
  VENDOR_REQUEST_REJECTED: "Vendor Request Rejected"
};

export const LOCATION_MESSAGES = {
  invalidUSAddress: "Your inputted Zip is not a valid US Zip Code. Please try again."
};

export const COMMENT_REQUIRED = "Description is required when Reason Code is Other. Please update.";

export const LIST_TIMEZONE_US = [{
  zone: "(UTC -10:00) Hawaii",
  UTC: "-10",
  abv: "HAST"
},
{
  zone: "(UTC -9:00) Alaska",
  UTC: "-9",
  abv: "AKST"
},
{
  zone: "(UTC -8:00) Pacific",
  UTC: "-8",
  abv: "PST"
},
{
  zone: "(UTC -7:00) Mountain",
  UTC: "-7",
  abv: "MST"
},
{
  zone: "(UTC -6:00) Central",
  UTC: "-6",
  abv: "CST"
},
{
  zone: "(UTC -5:00) Eastern",
  UTC: "-5",
  abv: "EST"
},
{
  zone: "(UTC -4:00) Atlantic",
  UTC: "-4",
  abv: "AST"
},
{
  zone: "(UTC +10:00)",
  UTC: "+10"
},
{
  zone: "(UTC +11:00)",
  UTC: "+11"
},
{
  zone: "(UTC +12:00)",
  UTC: "+12"
}
];

export const ICONTYPE = {
  required: 1,
  invalid: 2
};

export const DATETIME_FORMAT = "MM/DD/YYYY h:mm:ss A Z";

export const AUDIENCES_TYPE = {
  ClientAmdinsManagers: "Client Admins/Managers",
  Vendors: "Vendors",
  ClientAgents: "Client Agents",
  TCEAdminsManagers: "TCE Admins/Managers",
  TCEAgents: "TCE Agents"
};
export const ANNOUNCEMENT_STATUS = {
  Published: "Published",
  Unpublished: "Unpublished"
};
export const NOTIFICATION_ROLES = ["Admin", "Operational Manager"];
// constants for rich editor
export const BLOCK_TYPES = [{
  label: "H1",
  style: "header-one"
},
{
  label: "H2",
  style: "header-two"
},
{
  label: "H3",
  style: "header-three"
},
{
  label: "H4",
  style: "header-four"
},
{
  label: "H5",
  style: "header-five"
},
{
  label: "H6",
  style: "header-six"
},
{
  label: "Blockquote",
  style: "blockquote"
},
{
  label: "UL",
  style: "unordered-list-item"
},
{
  label: "OL",
  style: "ordered-list-item"
},
{
  label: "Code Block",
  style: "code-block"
}
];

// Custom overrides for "code" style in editor.
export const styleMap = {
  CODE: {
    backgroundColor: "rgba(0, 0, 0, 0.05)",
    fontFamily: `"Inconsolata", "Menlo", "Consolas", monospace`,
    fontSize: 16,
    padding: 2
  }
};

export const INLINE_STYLES = [{
  label: "Bold",
  style: "BOLD"
},
{
  label: "Italic",
  style: "ITALIC"
},
{
  label: "Underline",
  style: "UNDERLINE"
},
{
  label: "Monospace",
  style: "CODE"
}
];
///---end constant for editor---

export const CLIENT_PROGRAM = [{
  id: 1,
  label: "Standard",
  feePerOrder: 5
},
{
  id: 2,
  label: "Prime",
  feePerOrder: 10
},
{
  id: 3,
  label: "Elite",
  feePerOrder: 15
}
];

export const UPDATE_VENDOR_FEE_TYPE = {
  EXCEED: "EXCEED",
  UPDATE: "UPDATE",
  IGNORE: "IGNORE"
};

export const MENU_NAMES = {
  ORDERS: "Orders",
  MANAGEMENT: "Management",
  USER_MANAGEMENT: "User Management",
  CONFIGURATION_SETTINGS: "Configuration Settings",
  ACCOUNTING: "Accounting",
  ACCOUNTS: "Accounts",
  SETTINGS: "Settings",
  GENERAL: "General",
  TRAINING_TESTING: "Training & Testing",
  CONTENT_MANAGEMENT: "Content Management",
  TOOL: "Tools",
  VENDOR_OFFERS: "Order Offers"
};

export const PORTAL_NAMES = {
  CLIENT: "CLIENT",
  VENDOR: "VENDOR",
  STAFF: "STAFF"
};

export const VENDOR_PROFILES_BAR = [{
  name: "Phone Number",
  vendorProfileID: 1
}, {
  name: "Vendor Location",
  vendorProfileID: 2
}, {
  name: "Questionnaire",
  vendorProfileID: 3
}, {
  name: "Experience",
  vendorProfileID: 4
}, {
  name: "Credentials & Insurance",
  vendorProfileID: 5
}, {
  name: "Service Information",
  vendorProfileID: 6
}];

export const ORDER_PROGRESS_ID = {
  OPEN: 1,
  ASSIGNED_TO_VENDOR: 2,
  APPT_CONFIRMED_PENDING_DOCS: 3,
  PENDING_PRE_CALL: 4,
  APPT_READY: 5,
  CLOSED_PENDING_REVIEW_PC_RESOLUTION: 6,
  CLOSED_PENDING_QC_REVIEW: 7,
  CLOSING_COMPLETED: 8,
  POST_CLOSE: 9,
  HOLD: 10,
  CANCELED: 11,
  UNSUCCESSFUL: 12
};

export const SIGNED_DOC_STATUS = {
  APPROVED: {
    code: "A",
    description: "Approved"
  },
  REJECTED: {
    code: "R",
    description: "Rejected"
  },
  OPEN: {
    code: "O",
    description: "Open"
  }
};

export const SERVICE_CONFIG_STATUS = {
  Open: {
    code: 1,
    description: "Open"
  },
  Approved: {
    code: 2,
    description: "Approved"
  },
  Closed: {
    code: 3,
    description: "Closed"
  }
};

export const SERVICE_CONFIG_STATUS_SELECT_OPTION = [{
  code: 1,
  description: "Open"
}, {
  code: 2,
  description: "Approved"
}, {
  code: 3,
  description: "Closed"
}];

export const ICONS_LIST = [
  "lnr-home", "lnr-apartment", "lnr-pencil", "lnr-magic-wand", "lnr-drop",
  "lnr-lighter", "lnr-poop", "lnr-sun", "lnr-moon", "lnr-cloud",
  "lnr-cloud-upload", "lnr-cloud-download", "lnr-cloud-sync", "lnr-cloud-check", "lnr-database",
  "lnr-lock", "lnr-cog", "lnr-trash", "lnr-dice", "lnr-heart",
  "lnr-star", "lnr-star-half", "lnr-star-empty", "lnr-flag", "lnr-envelope",
  "lnr-paperclip", "lnr-inbox", "lnr-eye", "lnr-printer", "lnr-file-empty",
  "lnr-file-add", "lnr-enter", "lnr-exit", "lnr-graduation-hat", "lnr-license",
  "lnr-music-note", "lnr-film-play", "lnr-camera-video", "lnr-camera", "lnr-picture",
  "lnr-book", "lnr-bookmark", "lnr-user", "lnr-users", "lnr-shirt",
  "lnr-store", "lnr-cart", "lnr-tag", "lnr-phone-handset", "lnr-phone",
  "lnr-pushpin", "lnr-map-marker", "lnr-map", "lnr-location", "lnr-calendar-full",
  "lnr-keyboard", "lnr-spell-check", "lnr-screen", "lnr-smartphone", "lnr-tablet",
  "lnr-laptop", "lnr-laptop-phone", "lnr-power-switch", "lnr-bubble", "lnr-heart-pulse",
  "lnr-construction", "lnr-pie-chart", "lnr-chart-bars", "lnr-gift", "lnr-diamond",
  "lnr-linearicons", "lnr-dinner", "lnr-coffee-cup", "lnr-leaf", "lnr-paw",
  "lnr-rocket", "lnr-briefcase", "lnr-bus", "lnr-car", "lnr-train",
  "lnr-bicycle", "lnr-wheelchair", "lnr-select", "lnr-earth", "lnr-smile",
  "lnr-sad", "lnr-neutral", "lnr-mustache", "lnr-alarm", "lnr-bullhorn",
  "lnr-volume-high", "lnr-volume-medium", "lnr-volume-low", "lnr-volume", "lnr-mic",
  "lnr-hourglass", "lnr-undo", "lnr-redo", "lnr-sync", "lnr-history",
  "lnr-clock", "lnr-download", "lnr-upload", "lnr-enter-down", "lnr-exit-up",
  "lnr-bug", "lnr-code", "lnr-link", "lnr-unlink", "lnr-thumbs-up",
  "lnr-thumbs-down", "lnr-magnifier", "lnr-cross", "lnr-menu", "lnr-list",
  "lnr-chevron-up", "lnr-chevron-down", "lnr-chevron-left", "lnr-chevron-right", "lnr-arrow-up",
  "lnr-arrow-down", "lnr-arrow-left", "lnr-arrow-right", "lnr-move", "lnr-warning",
  "lnr-question-circle", "lnr-menu-circle", "lnr-checkmark-circle", "lnr-cross-circle", "lnr-plus-circle",
  "lnr-circle-minus", "lnr-arrow-up-circle", "lnr-arrow-down-circle", "lnr-arrow-left-circle", "lnr-arrow-right-circle",
  "lnr-chevron-up-circle", "lnr-chevron-down-circle", "lnr-chevron-left-circle", "lnr-chevron-right-circle", "lnr-crop",
  "lnr-frame-expand", "lnr-frame-contract", "lnr-layers", "lnr-funnel", "lnr-text-format",
  "lnr-text-format-remove", "lnr-text-size", "lnr-bold", "lnr-italic", "lnr-underline",
  "lnr-strikethrough", "lnr-highlight", "lnr-text-align-left", "lnr-text-align-center", "lnr-text-align-right",
  "lnr-text-align-justify", "lnr-line-spacing", "lnr-indent-increase", "lnr-indent-decrease", "lnr-pilcrow",
  "lnr-direction-ltr", "lnr-direction-rtl", "lnr-page-break", "lnr-sort-alpha-asc", "lnr-sort-amount-asc",
  "lnr-hand", "lnr-pointer-up", "lnr-pointer-right", "lnr-pointer-down", "lnr-pointer-left"
];

export const VENDOR_AVAILABILITY_DISPLAY = [{
  value: "F",
  label: "Full Time"
},
{
  value: "D",
  label: "Days"
},
{
  value: "E",
  label: "Evenings"
},
{
  value: "W",
  label: "Weekends"
}
];

export const QUICKBOOK_TYPE = {
  VENDOR_EXPORT: "vendor-export",
  VENDOR_CHECK_EXPORT: "vendor-check-export",
  VENDOR_BILL: "vendor-bill",
  CLIENT_EXPORT: "client-export",
  CLIENT_CHECK_EXPORT: "client-check-export",
  CLIENT_INVOICE: "client-invoice",
  INVOICE_REPORT: "invoice-report"
};

export const LINK_TYPE = [
  {
    value: "G",
    label: "General"
  },
  {
    value: "C",
    label: "Client"
  },
  {
    value: "V",
    label: "Vendor"
  }
];

export const LINK_TARGET = [{
  value: "_blank",
  label: "External"
},
{
  value: "_self",
  label: "Internal"
}
];

export const TOOL_VIEWS = [
  {
    key: "HOME_PAGE_COMPANY_PROFILE",
    text: "Home Page – Company Profile"
  },
  {
    key: "HOME_PAGE_CLIENT",
    text: "Home Page – Client"
  },
  {
    key: "HOME_PAGE_VENDOR",
    text: "Home Page – Vendor"
  },
  {
    key: "CLIENT",
    text: "Client"
  },
  {
    key: "VENDOR",
    text: "Vendor"
  }
];
export const ORDER_DOCUMENT_TYPE = {
  CLIENT_DOCS: 1,
  SIGNER_DOCS: 2
};

export const MONTH_LIST = [
  {
    value: "01",
    label: "January"
  },
  {
    value: "02",
    label: "February"
  },
  {
    value: "03",
    label: "March"
  },
  {
    value: "04",
    label: "April"
  },
  {
    value: "05",
    label: "May"
  },
  {
    value: "06",
    label: "June"
  },
  {
    value: "07",
    label: "July"
  },
  {
    value: "08",
    label: "August"
  },
  {
    value: "09",
    label: "September"
  },
  {
    value: "10",
    label: "October"
  },
  {
    value: "11",
    label: "November"
  },
  {
    value: "12",
    label: "December"
  }
];

export const LINK_DISPLAY = [
  {
    value: "HOME_PAGE",
    label: "Home Page"
  },
  {
    value: "CLIENT",
    label: "Client"
  },
  {
    value: "VENDOR",
    label: "Vendor"
  }
];
export const CHARJS_CONSTANTS = {
  BAR: "bar",
  HORIZONTAL_BAR: "horizontal bar",
  BUBBLE: "bubble",
  DOUGHNUT: "doughnut",
  DYNAMIC_DOUGHNUT: "dynamic doughnut",
  PIE: "pie",
  LINE: "line",
  RADAR: "radar",
  POLAR: "polar",
  SCATTER: "scatter",
  MIXED_BAR: "mixed"
};

export const ORDER_REPORT_AVAILABLE_FIELDS = [
  "Order ID",
  "Appointment Date Time",
  "Company",
  "Agent First Name",
  "Agent Last Name",
  "Signer Last Name",
  "Vendor First Name",
  "Vendor Last Name",
  "Product Type",
  "Order status",
  "Vendor Fee",
  "Client Fee",
  "Order Date",
  "Vendor Email",
  "Appointment Address",
  "Appointment City",
  "Appointment State",
  "Appointment Zip",
  "Property Address",
  "Property City",
  "Property State",
  "Property Zip"
];

export const VENDOR_REPORT_AVAILABLE_FIELDS = [
  "Active",
  "Vendor First Name",
  "Vendor Last Name",
  "Email",
  "Weekday Address",
  "Weekday City",
  "Weekday State",
  "Weekday Zip",
  "Commission Number",
  "Commission Expiration",
  "Commission States",
  "Title Producers License Expiration",
  "Title Producers License Number",
  "Are you an Attorney",
  "Bond Expiration",
  "Bond Amount",
  "Bond Policy Number",
  "E&O Expiration",
  "E&O Amount",
  "E&O Policy Number",
  "Background Check",
  "Languages",
  "Home Phone",
  "Work Phone",
  "Mobile Phone",
  "Number of Closed Orders",
  "Overall System Rating"
];

export const CLIENT_REPORT_AVAILABLE_FIELDS = [
  "Company Name",
  "Primary Contact First Name",
  "Primary Contact Last Name",
  "Address",
  "City",
  "State",
  "Zip",
  "Phone Number",
  "Ext",
  "After - hours Phone",
  "Fax Number",
  "Email",
  "Billing Contact First Name",
  "Billing Contact Last Name",
  "Billing Contact Phone Number",
  "Billing Contact Ext",
  "Billing Address",
  "Billing City",
  "Billing State",
  "Billing Zip",
  "Payment Terms",
  "Payment Method"
];

export const DASHBOARD_ITEMS_PERPAGE = 5;

export const CUSTOMER_FEEDBACK_VALUES = {
  NEUTRAL: "E",
  POSITIVE: "P",
  NEGATIVE: "N"
};

export const RED_COLORS =
  [
    "#d50000",
    "#ff1744",
    "#ff5252",
    "#ff8a80",
    "#b71c1c",
    "#c62828",
    "#d32f2f",
    "#e53935",
    "#f44336",
    "#ef5350"
  ];

export const GREEN_COLORS =
  [
    "#add65c",
    "#19d61f",
    "#0bddc5",
    "#97ef53",
    "#96bc36",
    "#91ffe7",
    "#6ed33f",
    "#788c13",
    "#9df9ac",
    "#7df29e",
    "#69db87",
    "#28e2a1",
    "#eeffad",
    "#adfff2",
    "#ddea8a",
    "#69eabd",
    "#98d14d",
    "#61dd91",
    "#83c41b",
    "#14e252",
    "#69f940",
    "#2cf439",
    "#3dffdb",
    "#1ea82e",
    "#60fc5d",
    "#dfea8c",
    "#8fc63b",
    "#86e278",
    "#9bef70",
    "#9fed2a",
    "#81e29e",
    "#077000",
    "#1eba10",
    "#f8ff9e",
    "#b1cc1e",
    "#5fd378",
    "#96f2ed",
    "#35e090",
    "#86b722",
    "#46c990",
    "#edf489",
    "#33a819",
    "#76f7d9",
    "#dff791",
    "#83ea99",
    "#a6ff21",
    "#51a31b",
    "#cef464",
    "#88fc74",
    "#67e853",
    "#25ce79",
    "#12aa0a",
    "#a4d815",
    "#b8e04a",
    "#4cad29",
    "#43dba6",
    "#7ff268",
    "#75d86c",
    "#28ef09",
    "#16e51d",
    "#67ed42",
    "#11c411",
    "#d6ff99",
    "#a3f477",
    "#abf48d",
    "#5dd35b",
    "#39db97",
    "#6df94d",
    "#8be899",
    "#05ba2c",
    "#a8f762",
    "#b4e062",
    "#3eef4d",
    "#7de0b2",
    "#c4ef97",
    "#87e876",
    "#3cc951",
    "#56ef96",
    "#28b526",
    "#b0f237",
    "#b8fcae",
    "#9af4d6",
    "#caff4f",
    "#707c03",
    "#17c45f",
    "#dff767",
    "#53c93c",
    "#0be2c2",
    "#6addbb",
    "#87ed9d",
    "#f3ffaa",
    "#2cbc12",
    "#d0e557",
    "#18a372",
    "#c6f9a4",
    "#d6f939",
    "#c6ff99",
    "#97f760",
    "#c6fca9",
    "#02efc8"
  ];

export const DOC_DELIVERY_METHOD = [
  {
    key: 1,
    value: "Upload"
  },
  {
    key: 2,
    value: "Emailed directly to Vendor"
  },
  {
    key: 3,
    value: "Overnight - To  Customer"
  },
  {
    key: 4,
    value: "Overnight  - To Vendor"
  },
  {
    key: 5,
    value: "Overnight/Courier to Closing Location"
  },
  {
    key: 6,
    value: "Printed at Closing Location"
  },
  {
    key: 7,
    value: "Customer has Documents"
  },
  {
    key: 8,
    value: "E-sign"
  }
];