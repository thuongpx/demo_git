export const ROLE_GENERAL = "General";
export const USER_MANAGEMENT = "UserManagement";
export const CONTENT_MANAGEMENT = "ContentManagement";
export const TRAINING_AND_TESTING = "TrainingAndTesting";
export const ACCOUNTING = "Accounting";
export const ROLE_AND_PERMISSION = "RoleAndPermission";
export const CLIENT_MANAGEMENT = "ClientManagement";
export const CLIENT_PIPELINE = "ClientPipeline";
export const CHATTING = "Chatting";
export const VENDOR_MANAGEMENT = "VendorManagement";
export const VENDOR_PIPELINE = "VendorPipeline";
export const INTERNAL_USER_MANAGEMENT = "InternalUserManagement";
export const ASSIGN_VENDER = "AssignVendor";
export const VENDOR_CLASSIFICATION = "VendorClassification";
export const REPORTING = "Reporting";
export const ADD_VIEW_ORDER = "AddViewOrder";
export const VENDOR_RATING_SETTING = "VendorRatingSetting";
export const FEE_APPROVAL = "FeeApproval";
export const VENDOR_APPROVAL = "VendorApproval";
export const SERVICE_CONFIG = "ServiceConfigurationApproval";
export const VENDOR_CREDENTIALS = "VendorCredentialsDocumentApproval";
export const SIGNED_DOCUMENT = "SignedDocumentApproval";
export const CHANGE_FEE = "ChangeFeeOnClosedOrders";
export const DISABLE_NEW_ORDERS = "DisableNewOrders";
export const AUTO_ORDERS = "AutoOrders";
export const ISSUE_APPROVAL = "IssueApproval";
export const ISSUE_REPORTING = "IssueReporting";
export const USER_PROFILE_SETTING = "UserProfileSetting";
export const FEE_REQUEST = "FeeRequest";

export const ROLE_NAMES = {
    STAFF_ADMIN: "Admin",
    STAFF_OPERATIONAL_MANAGER: "Operational Manager",
    STAFF_SCHEDULER: "Scheduler",
    STAFF_STATUS_REP: "Status Rep",
    STAFF_CONTENT_MANAGER: "Content Manager",
    STAFF_TRAINING_MANAGER: "Training Manager",
    STAFF_ACCOUNTING_MANAGER: "Accounting Manager",
    STAFF_QUALITY_CONTROL: "Quality Control",
    STAFF_SALE: "Sale",
    CLIENT_ADMIN: "Client",
    CLIENT_MANAGER: "Branch",
    CLIENT_SCHEDULER: "Agent",
    CLIENT_SUB_ADMIN: "Sub Admin",
    VENDOR: "Vendor"
}