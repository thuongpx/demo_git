export const ORDER_DETAIL_STAGE = [
    {
        name: "Open",
        lastProgressId: 1
    }, {
        name: "Assigned",
        lastProgressId: 4
    }, {
        name: "Appointment Ready",
        lastProgressId: 5
    }, {
        name: "Closed Pending",
        lastProgressId: 7
    }, {
        name: "Closing Complete",
        lastProgressId: 9
    }, {
        name: "Did Not Close",
        lastProgressId: 12
    }
];

export const ORDER_DETAIL_PROGRESS = [
    {},
    {
        stageId: 0,
        name: "Open" //progressId = 1
    },
    {
        stageId: 1,
        name: "Assigned to Vendor" //progressId = 2
    },
    {
        stageId: 1,
        name: "Appt Confirmed Pending Docs" //progressId = 3
    },
    {
        stageId: 1,
        name: "Pending Pre-call" //progressId = 4
    },
    {
        stageId: 2,
        name: "Appt Ready" //progressId = 5
    },
    {
        stageId: 3,
        name: "Closed Pending Review/PC Resolution" //progressId = 6
    },
    {
        stageId: 3,
        name: "Closed Pending QC Review" //progressId = 7
    },
    {
        stageId: 4,
        name: "Closing Completed" //progressId = 8
    },
    {
        stageId: 4,
        name: "Post Close" //progressId = 9
    },
    {
        stageId: 5,
        name: "Hold" //progressId = 10
    },
    {
        stageId: 5,
        name: "Canceled" //progressId = 11
    },
    {
        stageId: 5,
        name: "Unsuccessful signing attempt" //progressId = 12
    }
];

export const VENDOR_ORDER_DETAIL_PROGRESS = [
    {},
    {
        stageId: 0,
        name: "" //progressId = 1
    },
    {
        stageId: 1,
        name: "Confirm With Customer" //progressId = 2
    },
    {
        stageId: 1,
        name: "Appt Confirmed" //progressId = 3
    },
    {
        stageId: 1,
        name: "Docs Available" //progressId = 4
    },
    {
        stageId: 2,
        name: "Awaiting Status" //progressId = 5
    },
    {
        stageId: 3,
        name: "Status Submitted" //progressId = 6
    },
    {
        stageId: 3,
        name: "Awaiting Scanbacks" //progressId = 7
    },
    {
        stageId: 4,
        name: "Closed" //progressId = 8
    },
    {
        stageId: 4,
        name: "Post Close" //progressId = 9
    },
    {
        stageId: 5,
        name: "Hold" //progressId = 10
    },
    {
        stageId: 5,
        name: "Canceled" //progressId = 11
    },
    {
        stageId: 5,
        name: "Unsuccessful signing attempt" //progressId = 12
    }
];


export const ORDER_DETAIL_STAGE_ID_NULL = 12;

export const ORDER_PROGRESS_ID = {
    // OPEN: 1,
    // AUTO_ASSIGN: 2,
    // ASSIGNED_TO_VENDOR: 3,
    // APPT_CONFIRMED: 4,
    // PENDING_PRE_CALL: 5,
    // APPT_READY: 6,
    // CLOSED_PENDING_REVIEW: 7,
    // CLOSED_PENDING_QC_REVIEW: 8,
    // CLOSED_PENDING_CLIENT_REVIEW: 9,
    // CLOSING_COMPLETED: 10,
    // HOLD: 11,
    // CANCELED: 12
    OPEN: 1,
    ASSIGNED_TO_VENDOR: 2,
    APPT_CONFIRMED_PENDING_DOCS: 3,
    PENDING_PRE_CALL: 4,
    APPT_READY: 5,
    CLOSED_PENDING_REVIEW_PC_RESOLUTION: 6,
    CLOSED_PENDING_QC_REVIEW: 7,
    CLOSING_COMPLETED: 8,
    POST_CLOSE: 9,
    HOLD: 10,
    CANCELED: 11,
    UNSUCCESSFUL: 12
};