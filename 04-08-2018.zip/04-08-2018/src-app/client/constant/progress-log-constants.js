export const ACTION = 1;
export const MESSAGE_SENT = 2;
export const MESSAGE_RECEIVE = 3;
export const FEE_SUBMIT = 4;
export const VENDOR_NOTIFICATION = 5;