import { showError } from "../../client/screens/main-layout/actions";

export const handleErrorMesage = (dispatch, message) => {
    dispatch(showError(message));
};

export const handleApiError = (dispatch, error) => {
    if (!error || !error.response || !error.response.status) {
        // do nothing
        return;
    }

    switch (error.response.status) {
        case 401:
            dispatch(showError(`Invalid or expired token`));
            break;
        default:
            if (dispatch) {
                if (error && error.response && error.response.data) {
                    dispatch(showError(error.response.data.message));
                } else {
                    dispatch(showError(error.message));
                }
            }
            break;
    }
};

export const handleError = (dispatch, error) => {
    if (!error || !error.message) {
        return;
    }

    dispatch(showError(error.message));
};