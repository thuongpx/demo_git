import axios from "axios";
import { getCookies } from "Helpers/cookies-helper";
import { COOKIES_KEY } from "../constant/constants";

export const axiosGet = (url, params, isIgnoreAuth, axiosToken) => {
    const config = { params };

    if (!isIgnoreAuth) {
        const token = getCookies(COOKIES_KEY.CE_ACCESS_TOKEN);

        config.headers = {
            Authorization: `Bearer ${token}`
        };

        if (token) {
            config.cancelToken = axiosToken;
        }
    }

    return axios.get(url, config);
};

export const axiosDelete = (url, params, isIgnoreAuth) => {
    const config = {};

    if (!isIgnoreAuth) {
        const token = getCookies(COOKIES_KEY.CE_ACCESS_TOKEN);

        config.headers = {
            Authorization: `Bearer ${token}`
        };
    }

    return axios.delete(url, { params }, config);
};

export const axiosPost = (url, data, isIgnoreAuth) => {
    const config = {};

    if (!isIgnoreAuth) {
        const token = getCookies(COOKIES_KEY.CE_ACCESS_TOKEN);

        config.headers = {
            "Authorization": `Bearer ${token}`
        };
    }

    return axios.post(url, data, config);
};

export const axiosPut = (url, data, isIgnoreAuth) => {
    const config = {};

    if (!isIgnoreAuth) {
        const token = getCookies(COOKIES_KEY.CE_ACCESS_TOKEN);

        config.headers = {
            "Authorization": `Bearer ${token}`
        };
    }

    return axios.put(url, data, config);
};

export const getAxiosSource = () => {
    const CancelToken = axios.CancelToken;

    return CancelToken.source();
};

export const axiosCancel = (source) => {
    source.cancel("Request is cancelled by user.");
};

export const isCancel = (err) => {
    return axios.isCancel(err);
};

export const axiosDownload = (url, data, fileName, onSuccess = () => { }, isPostMethod, mime) => {
    const config = {};
    const token = getCookies(COOKIES_KEY.CE_ACCESS_TOKEN);

    config.headers = {
        "Authorization": `Bearer ${token}`,
        "Content-Type": mime || "application/octet-stream"
    };

    config.responseType = "blob";

    const responseCb = (responseData => {
        const blob = new Blob([responseData.data], { type: mime || "application/octet-stream" });

        if (typeof window.navigator.msSaveBlob !== "undefined") {
            // IE workaround for "HTML7007: One or more blob URLs were
            // revoked by closing the blob for which they were created.
            // These URLs will no longer resolve as the data backing
            // the URL has been freed."
            window.navigator.msSaveBlob(blob, fileName);
        } else {
            const blobURL = window.URL.createObjectURL(blob);
            const tempLink = document.createElement("a");
            tempLink.style.display = "none";
            tempLink.href = blobURL;
            tempLink.setAttribute("download", fileName);

            // Safari thinks _blank anchor are pop ups. We only want to set _blank
            // target if the browser does not support the HTML5 download attribute.
            // This allows you to download files in desktop safari if pop up blocking
            // is enabled.
            if (typeof tempLink.download === "undefined") {
                tempLink.setAttribute("target", "_blank");
            }

            document.body.appendChild(tempLink);
            tempLink.click();
            document.body.removeChild(tempLink);
            window.URL.revokeObjectURL(blobURL);
        }

        onSuccess();
    });

    if (!isPostMethod) {
        config.params = data;

        return axios.get(url, config).then(result => {
            responseCb(result);
        });
    }

    return axios.post(url, data, config).then(result => responseCb(result));
};