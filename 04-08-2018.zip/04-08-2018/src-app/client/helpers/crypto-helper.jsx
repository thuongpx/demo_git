export const guid = () => {
    const s4 = () => {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    };

    return `${s4()}${s4()}-${s4()}-${s4()}-${s4()}-${s4()}${s4()}${s4()}`;
};

export const gpwd = () => {
    const possibleUperCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const possibleLowerCase = "abcdefghijklmnopqrstuvwxyz";
    const possibleNonChar = "`~!@#$%^&*()-_+={};:'?,./[]";
    const possibleNumberChar = "0123456789";
    const combineStr = `${possibleUperCase}${possibleLowerCase}${possibleNumberChar}${possibleNonChar}`;
    const g = (possibleStr, numberOfChar = 1) => {
        let tempStr = "";

        for (let i = 0; i < numberOfChar; i++) {
            tempStr = `${tempStr}${possibleStr.charAt(Math.floor(Math.random() * possibleStr.length))}`;
        }

        return tempStr;
    };
    const uperStr = `${g(possibleUperCase)}`;
    const lowerStr = `${g(possibleLowerCase)}`;
    const nonChar = `${g(possibleNonChar, 2)}`;
    const number = `${g(possibleNumberChar)}`;
    const randomStr = `${g(combineStr, 10)}`;


    return `${uperStr}${nonChar.charAt(0)}${randomStr}${number}${nonChar.charAt(1)}${lowerStr}`;
};