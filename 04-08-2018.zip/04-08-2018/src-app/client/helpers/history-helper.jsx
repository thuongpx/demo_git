import { browserHistory } from "react-router";

export const getHistory = () => {
    return window.locations;
};

export const resetHistory = () => {
    window.locations = [];
};

export const trackHistory = () => {
    resetHistory();

    // tracking history
    browserHistory.listen((location) => {
        if (!window.locations) {
            window.locations = [];
        }

        if (window.locations.length === 0 || window.locations[window.locations.length - 1].pathName !== location.pathname) {
            window.locations.push({
                key: location.key,
                pathName: location.pathname
            });
        }
    });
};