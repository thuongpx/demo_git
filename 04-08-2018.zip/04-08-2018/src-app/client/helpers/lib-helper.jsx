/*global Tawk_API:true*/
/*eslint no-undef: "error"*/
/*eslint camelcase: ["error", {properties: "never"}]*/
import { hasStringValue } from "../helpers/common-helper";

export const TawkToApi = {
    getStatus: () => {
        if (!Tawk_API) return {};

        return {
            status: Tawk_API.getStatus(),
            isChatMaximized: Tawk_API.isChatMaximized(),
            isChatMinimized: Tawk_API.isChatMinimized(),
            isChatHidden: Tawk_API.isChatHidden(),
            isChatOngoing: Tawk_API.isChatOngoing(),
            isVisitorEngaged: Tawk_API.isVisitorEngaged()
        };
    },
    showWidget: () => {
        if (!Tawk_API) return;

        if (Tawk_API.isChatHidden()) {
            Tawk_API.showWidget();

            if (!Tawk_API.isChatOngoing() && !Tawk_API.isVisitorEngaged()) {
                Tawk_API.minimize();
            }
            return;
        }
    },
    hideWidget: () => {
        if (!Tawk_API) return;

        if (!Tawk_API.isChatHidden()) {
            Tawk_API.minimize();
            Tawk_API.hideWidget();
            return;
        }
    },
    endChat: () => {
        Tawk_API.endChat();
    },
    setUpTawkToClient: (hash, profile, role) => {
        switch (role) {
            case "Vendor":
            case "Client":
                if (hasStringValue(hash)) {
                    Tawk_API.setAttributes({
                        name: `${profile.firstName} ${profile.lastName}`,
                        email: profile.email,
                        hash
                    }, (error) => { console.log(error); });
                }
                TawkToApi.showWidget();
                break;
            default:
                break;
        }
    }
};