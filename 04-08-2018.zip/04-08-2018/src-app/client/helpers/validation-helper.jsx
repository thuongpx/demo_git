import React from "react";
import moment from "moment";

import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import { INPUT_ERROR_1X_IMAGE_URL } from "ImageConfig";
import { ICONTYPE } from "Constants";

export const validateRequired = (value) => {
    return value !== null && value !== undefined && value.length > 0;
};

export const validateComboboxRequired = (value) => {
    return value !== undefined && value !== "-1" && value !== "";
};

export const validatePassword = (value) => {
    return /(?=^.{8,30}$)((?=.*[_])|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9]).*$/.test(value) || value.length === 0;
};

export const validateEmail = (value) => {
    return /^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/.test(value) || value.length === 0;
};

export const validateMultipleEmail = (value) => {
    let arrayOfEmail = [];
    const email = value.split(";");
    let tmp = false;

    arrayOfEmail = arrayOfEmail.concat(email);

    arrayOfEmail.forEach(item => {
        const newItem = item.trim();
        if (!validateEmail(newItem)) {
            tmp = true;
        }
    });
    return tmp;
};

export const validateCompare = (value1, value2) => {
    return value1 === value2 || value1.length === 0 || value2.length === 0;
};

// format: (999) 999-9999
/*export const validatePhone = (value) => {
    return /^[0-9]\d{2}-\d{3}-\d{4}$/.test(value) || /^(\()?\d{3}(\))?(-|\s)?\d{3}(-|\s)\d{4}$/.test(value) || /^\d{10}$/.test(value) || value.length === 0;
};*/

export const validatePhone = (value) => {
    return /^(\()?\d{3}(\))?(-|\s)?\d{3}(-|\s)\d{4}$/.test(value) || /^\d{10}$/.test(value) || value.length === 0;
};

export const validateZip = (value) => {
    return /(^\d{5}$)|(^\d{5}-\d{4}$)/.test(value) || value.length === 0;
};

export const invalidZipMessage = (value) => {
    return `Invalid ${value} – The Format is: XXXXX`;
};

export const validateDecimal = (value) => {
    return (/^-{0,1}\d*\.{0,1}\d+$/.test(value)) || value.length === 0;
};

export const requireMessage = (value) => {
    return `Please enter a value for the '${value}' Field.`;
};

export const invalidMessage = (value) => {
    return `Invalid ${value} – Please Re-Enter!`;
};

export const invalidPasswordMessage = () => {
    return `Your Password must follow the Password Policy. Please enter again!`;
};

export const comparePasswordMessage = (value1, value2) => {
    return `The '${value1}' and '${value2}' do not match.`;
};

export const requireComboBoxMessage = (value) => {
    return `Please select a value for the '${value}' Field.`;
};

export const existingUsernameMessage = (value) => {
    return `${value} is already in use.  Please create an alternate username.  If there is a possibility that you are already a member, please contact The Closing Exchange.`;
};

export const existingMessage = (value) => {
    return `${value} already exists. Please rename.`;
};

export const hasStringValue = (input) => {
    return input !== null && input !== undefined && input !== "";
};

export const validatePhoneWithoutHyphen = (value) => {
    return /^\d{10}$/.test(value) || value.length === 0;
};

export const validateSpecialCharacter = (value) => {
    return !/[~`!@#$%\^&*()+=\-\[\]\\';,/{}|\\":<>\?]/g.test(value) || value.length === 0;
};

export const getIconTypeFromMessage = (message) => {
    if (!hasStringValue(message)) {
        return null;
    }

    if (message.includes("Please enter") || message.includes("Please select")) {
        return ICONTYPE.required;
    }

    return ICONTYPE.invalid;
};

export const getIcon = (message) => {
    const iconType = getIconTypeFromMessage(message);

    if (iconType === ICONTYPE.required) {
        return (<img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={message} />);
    }

    if (iconType === ICONTYPE.invalid) {
        return (<img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={message} />);
    }

    return null;
};


export const validationMessage = (message, id, right) => {
    if (message !== "" && message !== null && message !== undefined) {
        return (
            <span className={`suffix-text`} style={{ display: "block!important", marginRight: right ? right : 0 }}>
                {getIcon(message)}
            </span>
        );
    }

    return (<span></span>);
};

export const getValidationCssClass = (message) => {
    const iconType = getIconTypeFromMessage(message);

    if (iconType === ICONTYPE.required) {
        return "required-field";
    }

    if (iconType === ICONTYPE.invalid) {
        return "has-error";
    }

    return "";
};

export const validateDateStringByMoment = (dateStr, format = "MM/DD/YYYY") => {
    return moment(dateStr, format, true).isValid();
};

export const validateDateByMoment = (date) => {
    return moment(date).isValid();
};

export const validateTime = (str) => {
    const now = new Date();
    const date = new Date(`${now.getMonth() + 1}/${now.getDate()}/${now.getFullYear()} ${str}`);

    return validateDateByMoment(date);
};

export const validateDateTimeStringByMoment = (dateStr, format = "MM/DD/YYYY hh:mm A") => {
    return moment(dateStr, format, true).isValid();
};