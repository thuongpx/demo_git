import Cookies from "universal-cookie";
import moment from "moment";

export const setCookies = (key, name, path, expires) => {
    const cookies = new Cookies();

    if (path === null || path === undefined || path === "") {
        path = "/";
    }

    if (expires === null || expires === undefined) {
        expires = moment().add(1, "days").toDate();
    }

    cookies.set(key, name, { path, expires });
};

export const getCookies = (key) => {
    const cookies = new Cookies();

    return cookies.get(key);
};

export const removeCookies = (key, path) => {
    const cookies = new Cookies();

    if (path === null || path === undefined || path === "") {
        path = "/";
    }

    return cookies.remove(key, { path });
};