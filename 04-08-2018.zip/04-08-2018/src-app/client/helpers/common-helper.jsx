import moment from "moment";
import React from "react";

import { getCookies } from "./cookies-helper";
import { APP_URL } from "Config/config";
import { CLIENT_SUB_ROLE } from "Constants";

import { PAYMENT_IMAGE_URLS } from "../config/img.config";
import { COOKIES_KEY } from "../constant/constants.js";
import { apiGetProfilePicture } from "Api/account-api";
import noAvatarImg from "../../client/public/images/no-avatar.png";

export const trimObject = (object) => {
    for (const key in object) {
        if (typeof object[key] === "string" && key !== "Password" && key !== "ConfirmPassword") {
            object[key] = object[key].trim();
        }
    }

    return object;
};

export const thousandSep = (val) => {
    if (val === "NaN") val = parseFloat(0.0).toFixed(2);
    return String(val).split("").reverse().join("")
        .replace(/(\d{3}\B)/g, "$1,")
        .split("").reverse().join("");
};

export const getAuthenticatedUser = () => {
    const accessToken = getCookies(COOKIES_KEY.CE_ACCESS_TOKEN);
    const user = getCookies(COOKIES_KEY.CE_AUTHENTICATION_USER);

    if (accessToken && user) {
        return {
            accessToken,
            ...user
        };
    }

    return null;
};

export const hasStringValue = (input) => {
    return input !== null && input !== undefined && input !== "";
};

export const hasStringValueTrim = (input) => {
    return hasStringValue(input) && input.trim() !== "";
};

export const hasObjectValue = (input) => {
    return input !== null && input !== undefined;
};

export const parseInputsToPayload = (inputs) => {
    let payload = {};

    Object.keys(inputs).forEach((item) => {
        const prop = inputs[item];

        payload = {
            ...payload
        };

        payload[item] = prop.value || "";
    });

    return payload;
};

//format: xxx-xxx-xxxx
export const toPhoneFormat = (phone) => {
    if (phone && phone.length === 10) {
        return `${phone.substr(0, 3)}-${phone.substr(3, 3)}-${phone.substr(6, 4)}`;
    } else {
        return phone;
    }
};

//format: (xxx) xxx-xxxx
export const convert2PhoneWithFormat = (phone) => {
    if (!phone) return "";

    if (phone.length === 10) {
        return `(${phone.substr(0, 3)}) ${phone.substr(3, 3)}-${phone.substr(6, 4)}`;
    } else {
        phone = `(${phone.substring(0, 3)}) ${phone.substring(3, 6)}-${phone.substring(6, 10)}`;
    }
    return phone;
};

export const isBuffer = (input) => {
    return input.type === "Buffer";
};

export const bufferToBoolean = (input) => {
    let result = false;

    if (isBuffer(input)) {
        const data = input.data;

        for (const value of data) {
            if (value === 1) {
                result = true;
                break;
            }
        }
    }

    return result;
};

export const updateInputValue = (e) => {
    return { value: e.target.value, message: "" };
};

export const replaceAll = (str, searchStr, replaceStr) => {
    if (replaceStr === undefined) return str;
    if (!str) return "";
    return str.split(searchStr).join(replaceStr);
};

export const updateMaskedInputValue = (e) => {
    const input = e.target.value;

    if (input.indexOf("-") > -1) {
        return { value: replaceAll(input, "-", ""), message: "" };
    }

    return { value: input, message: "" };
};

export const convertToPhoneNumber = (input) => {
    if (input === undefined || input === null) {
        return "";
    }
    // input: (123) 456-7890
    return input.replace("(", "").replace(")", "").replace(" ", "").replace("-", "");
};

export const splitTime = (time, type) => {
    if (!time || time.length !== 10) { return ""; }
    if (type === "day") {
        return time.substring(3, 5);
    } else if (type === "month") {
        return time.substring(0, 2);
    } else if (type === "year") {
        return time.substring(6, 10);
    }
    return "";
};

export const joinTime = (variable, time, type) => {
    if (!time || time.length !== 10) { time = moment.unix(new Date() / 1000).format("MM/DD/YYYY"); }
    let result = "";
    if (type === "day") {
        result = time.substring(0, 3) + variable + time.substring(5);
    } else if (type === "month") {
        result = variable + time.substring(2);
    } else if (type === "year") {
        result = time.substring(0, 6) + variable;
    }
    if (variable.length === 0) {
        result = "";
    }
    return result;
};

export const daysOfMonth = () => {
    const dayArr = [];
    let dayCount = 1;
    while (dayCount <= 31) {
        if (dayCount <= 9) {
            dayArr.push(`0${dayCount}`);
        } else {
            dayArr.push(dayCount);
        }
        dayCount++;
    }
    return dayArr;
};

export const recentYears = () => {
    const yearArr = [];
    const yearLimit = new Date().getFullYear();
    let yearCount = yearLimit - 20;
    while (yearCount <= yearLimit) {
        yearArr.push(yearCount++);
    }
    return yearArr;
};

export const convertArrayString = (arr, char) => {
    return arr.split(char);
};

export const convertArrayNumber = (arr, char) => {
    if (!arr) {

        return [];
    }
    const tr = arr.split(char);

    return tr.map((item) => {
        return parseInt(item);
    });
};

export const convertArrayFloat = (arr, char) => {
    if (!arr) {

        return [];
    }
    const tr = arr.split(char);

    return tr.map((item) => {
        return parseFloat(item);
    });
};


export const addHashCharIntoRoute = () => {
    if (window.hasHashChar === true) return;

    window.location = `${location.pathname}#`;
    window.hasHashChar = true;
};

export const confirmReloadOrRedirectPage = (isClientPlaceOder = false, cbHandleBackBtn = () => { }, justUseCb = false) => {
    if (isClientPlaceOder) {
        addHashCharIntoRoute();
        window.isClientPlaceOder = { isClientPlaceOder, cbHandleBackBtn, justUseCb };
    }

    if (!justUseCb) {
        window.needConfirm = true;
    }
};

export const removeConfirmReLoadOrRedirectPage = () => {
    window.needConfirm = false;
    window.isClientPlaceOder = false;
};


export const removeHashChar = () => {
    window.hasHashChar = false;
};

export const buildAppUrl = (path) => {
    return `${APP_URL}${path}`;
};

export const renameFile = (basicName, step) => {
    const pos1 = basicName.lastIndexOf("(");
    const pos2 = basicName.lastIndexOf(")");
    if (pos2 === basicName.length - 1 && pos1 > 0) {
        const subNum = basicName.substring(pos1 + 1, pos2);
        if (isNaN(subNum) === false) {
            const newNum = parseInt(subNum) + step;
            basicName = `${basicName.substring(0, pos1)}(${newNum})`;
        } else {
            basicName += "(1)";
        }
    } else {
        basicName += "(1)";
    }
    return basicName;
};

export const parseDateToString = (date, format = "MM/DD/YYYY hh:mm a") => {
    const mDate = moment(date).format(format).toString();

    return mDate;
};

export const getTheFirstWord = (str) => {
    if (str && str !== "" && typeof str === "string") {
        const strArr = str.split(" ");

        if (strArr.length > 0) {
            return strArr[0];
        }
    }

    return "";
};

export const compareArrays = (arr1, arr2) => {
    if ((!arr1 && arr2) || (!arr2 && arr1)) {
        return false;
    }

    if (!arr1) arr1 = [];
    if (!arr2) arr2 = [];

    // array has different length
    if (arr1.length !== arr2.length) {
        return false;
    }

    // array has different items
    const arr1Json = JSON.stringify(arr1);
    const arr2Json = JSON.stringify(arr2);

    if (arr1Json !== arr2Json) {
        return false;
    }

    return true;
};

export const getAmPmFromDate = (date) => {
    const hours = date.getHours();

    return hours >= 12 ? "PM" : "AM";
};

export const getAmPmFromTimeStr = (timeStr, del) => {
    const times = timeStr.split(del);

    if (times.length > 0) {
        const h = times[0];

        return h >= 12 ? "PM" : "AM";
    }

    return "AM";
};

export const parseTimeToString = (time, format = "hh:mm a") => {
    if (!time) return "";

    const now = new Date();
    const date = new Date(`${now.getMonth() + 1}/${now.getDate()}/${now.getFullYear()} ${time}`);

    const hours = date.getHours() > 12 ? date.getHours() - 12 : date.getHours();
    const apm = date.getHours() >= 12 ? "PM" : "AM";

    let rs = format;
    rs = rs.replace("hh", hours < 10 ? `0${hours}` : hours);
    rs = rs.replace("mm", date.getMinutes() < 10 ? `0${date.getMinutes()}` : date.getMinutes());
    rs = rs.replace("a", apm);

    return rs;
};

export const parseDateTimeToString = (time, date, format = "MM/dd/yyyy h:mm a") => {
    const tDate = new Date(date);
    const iDate = new Date(`${tDate.getMonth() + 1}/${tDate.getDate()}/${tDate.getFullYear()} ${time}`);

    const hours = iDate.getHours() > 12 ? iDate.getHours() - 12 : iDate.getHours();
    const apm = iDate.getHours() > 12 ? "PM" : "AM";

    let rs = format;
    rs = rs.replace("MM", (iDate.getMonth() + 1) < 10 ? `0${(iDate.getMonth() + 1)}` : (iDate.getMonth() + 1));
    rs = rs.replace("dd", iDate.getDate() < 10 ? `0${iDate.getDate()}` : iDate.getDate());
    rs = rs.replace("yyyy", iDate.getFullYear());
    rs = rs.replace("h", hours ? `0${hours}` : hours);
    rs = rs.replace("mm", iDate.getMinutes() < 10 ? `0${iDate.getMinutes()}` : iDate.getMinutes());
    rs = rs.replace("a", apm);

    return rs;
};

export const displayIntervalTime = (inputDate, timeZone) => {
    const now = moment(new Date());
    const targetDate = moment(inputDate);
    const interval = targetDate.diff(now, "hours") - timeZone + 7;
    const days = parseInt(interval / 24);
    const hours = (interval % 24);
    const absDays = Math.abs(days);
    const absHours = Math.abs(hours);

    if (days > 0) {
        if (days === 1) {
            return `in ${days * 24 + hours} hours`;
        } else {
            if (hours === 1) {
                return `in ${days} days ${hours} hour`;
            } else if (hours > 1) {
                return `in ${days} days ${hours} hours`;
            }

            return `in ${days} days`;
        }
    } else if (days < 0) {
        if (absDays === 1) {
            return `${absDays * 24 + hours} hours ago`;
        } else {
            if (absHours !== 0) {
                if (absHours === 1) {
                    return `${absDays} days ${absHours} hour ago`;
                } else {
                    return `${absDays} days ${absHours} hours ago`;
                }
            }
            return `${absDays} days ago`;
        }
    } else if (hours > 0) {
        return `in ${absHours} hour`;
    } else if (hours < 0) {
        return `${absHours} hours ago`;
    }

    return "";
};

export const displayIntervalTimeForNotifications = (inputDate) => {
    const now = moment(new Date());
    const targetDate = moment(inputDate);
    const interval = targetDate.diff(now, "minutes");
    const hours = parseInt(interval / 60);
    const minutes = (interval % 60);
    const absMinutes = Math.abs(minutes);
    const absHours = Math.abs(hours);

    if (absHours > 23) {
        return `${moment(inputDate).format("LLL")}`;
    } else if (absHours < 24) {
        if (absHours === 0) {
            if (absMinutes <= 59) {
                return `${absHours * 24 + absMinutes} minutes ago`;
            } else {
                return `1 hour ago`;
            }
        } else if (absHours === 1) {
            if (absMinutes <= 59) {
                return `${absHours} hour ${absMinutes} minutes ago`;
            } else {
                return `${absHours + 1} hours ago`;
            }
        } else if (absHours > 1) {
            if (absMinutes <= 59) {
                return `${absHours} hours ${absMinutes} minutes ago`;
            } else {
                return `${absHours + 1} hours ago`;
            }
        }
    }
    return "";
};

export const getCurrentPortal = () => {
    const accessToken = getCookies(COOKIES_KEY.CE_ACCESS_TOKEN);
    const user = getCookies(COOKIES_KEY.CE_AUTHENTICATION_USER);

    if (accessToken && user) {
        const { role } = user;
        const { roleType } = role;

        return roleType || "";
    }

    return "";
};

export const slugify = (text) => {
    if (text !== undefined) {
        return text.toString().toLowerCase()
            .replace(/\s+/g, "-") // Replace spaces with -
            .replace(/[^\w\-]+/g, "") // Remove all non-word chars
            .replace(/\-\-+/g, "-") // Replace multiple - with single -
            .replace(/^-+/, "") // Trim - from start of text
            .replace(/-+$/, ""); // Trim - from end of text
    } else {
        return "";
    }
};

export const roleNameFinal = (roles) => {
    if (roles !== undefined && roles.length > 0) {
        if (roles.indexOf(CLIENT_SUB_ROLE.AGENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.AGENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        if (roles.indexOf(CLIENT_SUB_ROLE.CLIENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.CLIENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        if (roles.indexOf(CLIENT_SUB_ROLE.BRANCH.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.BRANCH.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
    }
    return "";
};

export const toSafeString = (str) => {
    if (hasStringValue(str)) return str;
    return "";
};

export const isReactElement = (suspectedElement) => {
    let isElem = false;
    if (React.isValidElement(suspectedElement)) {
        isElem = true;
    } else if (Array.isArray(suspectedElement)) {
        for (let i = 0, l = suspectedElement.length; i < l; i++) {
            if (React.isValidElement(suspectedElement[i])) {
                isElem = true;
                break;
            }
        }
    }
    return isElem;
};

export const shallowCompareState = (thisState, nextState) => {
    return thisState === nextState;
};

export const shallowCompareProps = (thisProps, nextProps) => {
    let equals = false;
    if (thisProps === nextProps) {
        equals = true;
    } else if (typeof thisProps === "object" && typeof nextProps === "object") {
        equals = true;
        const propNames = new Set(Object.keys(thisProps), Object.keys(nextProps));
        const jsonStringifyFilter = (key, value) => {
            if (key === "_meta") {
                return "";
            } else {
                return value;
            }
        };

        for (const propName of propNames) {
            if (!isReactElement(thisProps[propName]) && JSON.stringify(thisProps[propName], jsonStringifyFilter) !== JSON.stringify(nextProps[propName], jsonStringifyFilter)) {
                // No need to check nextProps[propName] as well, as we know they are not equal
                equals = false;
                break;
            }
        }
    }
    return equals;
};

export const getCreditCardIcon = (cardType) => {
    if (!hasStringValue(PAYMENT_IMAGE_URLS[cardType])) {
        return PAYMENT_IMAGE_URLS.Credit;
    }

    return PAYMENT_IMAGE_URLS[cardType];
};

export const deepClone = (o) => {
    return JSON.parse(JSON.stringify(o));
};

export const getProfilePicture = (accountId) => {
    apiGetProfilePicture(accountId, (result) => {
        const { profilePicture } = result.data;
        if (profilePicture !== null && profilePicture !== "") {
            $("#profilePicture").attr("src", `${profilePicture}`);
        } else {
            $("#profilePicture").attr("src", `${noAvatarImg}`);
        }
    }, () => { });
};

export const parseSearchObjectToQuery = (object) => {
    let query = "?1=1";

    for (const key of Object.keys(object)) {
        if (object[key].constructor === Array) {
            // if it is Array
            const values = object[key].map(i => i.value);
            query += `&${key}=${values.join()}`;
        } else {
            query += `&${key}=${object[key]}`;
        }
    }

    return query;
};

export const openNewTab = (url) => {
    const win = window.open(url, "_blank");
    win.focus();
};

export const getOrderStatusError = (errorCode) => {
    switch (errorCode) {
        case 1:
            return "This order has not been assigned to any vendor yet. Please assign vendor before changing order’s status.";
        case 2:
            return "This order requires eDocs, so order’ status should be changed to Appt Confirmed Pending Docs first.";
        case 3:
            return "This order requires manual pre-call, so order’ status should be changed to Pending Pre-Call first.";
        case 4:
            return "This order’s status must be changed to “Appt Ready” first.";
        case 5:
            return "This order requires QC review so status must be changed to \"Closed Pending QC Review\".";
        case 6:
            return "This order requires Review/PC Resolution so status must be changed to \"Closed Pending Review/PC Resolution\".";
        case 7:
            return "This order’s status must be changed to Closing Completed.";
        case 8:
            return "This order has been closed. In case of any issue, order’s status must be changed to \"Post Close\".";
        case 9:
            return "This order has been closed and had an issue so order’s status must be changed to \"Closed Pending Review/PC Resolution\".";
        default:
            return "";
    }
};