import Axios from "axios";
import { GOOGLE_MAP_API } from "Config/config";
import { replaceAll } from "./common-helper";

// get city and state from zipcode

// get coordinate from address
export const getCoordinateFromAddress = (addr) => {
    const baseUrl = `https://maps.googleapis.com/maps/api/geocode/json?address=${addr}&language=en-US&key=${GOOGLE_MAP_API}`;

    Axios.get(baseUrl).then((response) => {
        if (response !== null && response.data !== null && response.data.results !== null && response.data.results.length > 0) {
            return {
                lng: (response.data.results[0].geometry.location.lng),
                lat: (response.data.results[0].geometry.location.lat)
            };
        }

        return {
            lng: 0,
            lat: 0
        };
    });
};

// Calculate distance from 2 different location
export const calculateDistanceFromLocation = (locationA, locationB) => {
    const radius = 6371; // Radius of the earth in km
    const mathConst = Math.PI / 180;
    const kmToMi = 0.62137119224;

    const dLat = (locationA.lat - locationB.lat) * mathConst;
    const dLon = (locationA.lng - locationB.lng) * mathConst;
    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(locationA.lat * mathConst) * Math.cos(locationB.lat * mathConst) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return radius * c * kmToMi;
};

// Decode Zip string to State and City
export const decodeZiptoStateAndCity = (data) => {
    const returnData = {};

    data.address_components.map(item => {
        item.types.map(type => {
            switch (type) {
                case "postal_code":
                    returnData.zip = item.short_name;
                    return false;
                case "administrative_area_level_1":
                    returnData.state = item.short_name;
                    return false;
                case "country":
                    returnData.country = item.long_name;
                    return false;
                case "locality":
                    returnData.city = item.long_name;
                    return false;
                default:
                    return true;
            }
        });
    });

    return returnData;
};

// Get state code from zip code
export const getStateCodeAndCityFromZip = (zipCode, callback) => {
    let stateCode = "";
    if (zipCode === "00000") {
        stateCode = "Invalid Zip Code";
        callback(stateCode);
    } else {
        const baseUrl = `https://maps.googleapis.com/maps/api/geocode/json?address=${zipCode}&language=en-US&key=${GOOGLE_MAP_API}`;

        Axios.get(baseUrl).then((response) => {
            if (response !== null && response.data !== null && response.data.results !== null && response.data.results.length > 0) {
                stateCode = decodeZiptoStateAndCity(response.data.results[0]);
                if (stateCode.country !== "United States" || stateCode.zip !== zipCode) {
                    stateCode = "Invalid Zip Code";
                }
            } else {
                stateCode = "Invalid Zip Code";
            }
            callback(stateCode);
        });
    }
    return stateCode;
};

// Get direction from two addresses or coordinate
export const getDirectionFromAddresses = (var1, var2) => {
    let location1 = var1.trim().split(" ").join("+");
    let location2 = var2.trim().split(" ").join("+");

    location1 = replaceAll(location1, "#", "%23");
    location2 = replaceAll(location2, "#", "%23");

    const directionUrl = `https://www.google.com/maps/dir/?api=1&origin=${location1}&destination=${location2}&language=en-US`;

    return directionUrl;
};

export const showGoogleMap = (addr) => {
    const directionUrl = `https://maps.googleapis.com/maps/api/geocode/json?address=${addr}&language=en-US&key=${GOOGLE_MAP_API}`;

    return directionUrl;
};