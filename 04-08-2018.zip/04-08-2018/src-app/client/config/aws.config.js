export const API_URL = "https://apistaging.theclosingexchange.com";
export const APP_URL = "https://staging.theclosingexchange.com";
export const GOOGLE_MAP_API = "AIzaSyDagnQM49mYJcX9HSI7Q1DOp4g8YywaIFc";
export const CLIENT_AUTHORIZATION = "sandbox_x528srrh_jx4xv6ybnbwp62cd";
export const FILE_UPLOAD_SIZE = "52428800";
export const FILE_UPLOAD_EXTENSIONS = ["pdf", "tiff", "doc", "docx", "jpg", "xls", "xlsx"];
export const MAX_VENDOR_DOC_FILE_SIZE = 1024 * 1024 * 10; // 10MB for vendor document file
