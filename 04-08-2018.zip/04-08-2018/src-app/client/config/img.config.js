export const LOGO_1X_IMAGE_URL = "/images/Registration/LogoCallout_Large%401x.png";
export const LOGO_2X_IMAGE_URL = "/images/Registration/LogoCallout_Large%402x.png";
export const INPUT_MISSING_1X_IMAGE_URL = "/images/Icon/Input%20Missing%401x.png";
export const INPUT_ERROR_1X_IMAGE_URL = "/images/Icon/Input%20Error%401x.png";
export const DEFAULT_AVATAR_IMAGE_URL = "/images/avt.JPG";
export const CROWN_IMAGE_URL = "/images/Icon/crown.png";
export const REGWIZ_STEP1_2X_IMAGE_URL = "/images/Registration/regWiz_Step1%402x.png";
export const REGWIZ_STEP2_2X_IMAGE_URL = "/images/Registration/regWiz_Step2%402x.png";
export const REGWIZ_STEP3_2X_IMAGE_URL = "/images/Registration/regWiz_Step3%402x.png";
export const REGWIZ_VENDOR_STEP1_2X_IMAGE_URL = "/images/Registration/regWiz_Step1active@2x_2step.png";
export const REGWIZ_VENDOR_STEP2_2X_IMAGE_URL = "/images/Registration/regWiz_Step2active@2x_2step.png";
export const LOGO_3X_IMAGE_URL = "/images/Icon/logo.png";
export const LOGO_BAR_IMAGE_URL = "/images/logo_bar.PNG";
export const PAYMENT_IMAGE_URLS = {
    "American Express": "/images/Payment/amex.png",
    "Diners Club": "/images/Payment/diners_club.png",
    Discover: "/images/Payment/discover.png",
    JCB: "/images/Payment/jcb.png",
    Maestro: "/images/Payment/maestro.png",
    MasterCard: "/images/Payment/master_card.png",
    Visa: "/images/Payment/visa.png",
    Credit: "/images/Payment/credit.png",
    Paypal: "/images/Payment/paypal.png"
};
export const INPUT_CHECK_BOX_CHECKED_IMAGE_URL = "/images/Icon/checked.png";
export const INPUT_CHECK_BOX_UNCHECKED_IMAGE_URL = "/images/Icon/unchecked.png";