export const API_URL = "http://localhost:3001";
export const APP_URL = "http://localhost:3000";
export const GOOGLE_MAP_API = "AIzaSyDagnQM49mYJcX9HSI7Q1DOp4g8YywaIFc";
export const CLIENT_AUTHORIZATION = "sandbox_x528srrh_jx4xv6ybnbwp62cd";
export const FILE_UPLOAD_SIZE = "52428800";
export const FILE_UPLOAD_EXTENSIONS = ["PDF", "pdf", "tiff", "doc", "docx", "jpg", "xls", "xlsx"];
export const MAX_VENDOR_DOC_FILE_SIZE = 1024 * 1024 * 10; // 10MB for vendor document file
export const TAWK_TO_CLIENT_SRC = "https://embed.tawk.to/5b2b40b1eba8cd3125e30b4d/default";