import {
  axiosGet, axiosPost, axiosDownload
} from "Helpers/axios-helper";
import {
  API_URL
} from "Config/config";

export const apiGetQuickBooks = (criteria, onSuccess, onError) => {
  return axiosPost(`${API_URL}/quickbook-invoice/getQuickBooks`, criteria).then(onSuccess).catch(onError);
};

export const apiGetQuickBookContent = (data, onSuccess, onError) => {
  return axiosGet(`${API_URL}/quickbook-invoice/downloadQuickBookInvoice`, data).then(onSuccess).catch(onError);
};

export const apiExportQuickBook = (criteria, onSuccess, onError) => {
  return axiosPost(`${API_URL}/quickbook-invoice/exportQuickBook`, criteria).then(onSuccess).catch(onError);
};

export const apiDownloadQuickBookInvoice = (data, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/quickbook-invoice/downloadQuickBookInvoice`, data, fileName, onSuccess).catch(onError);
};

export const apiDeleteQuickBookInvoice = (data, onSuccess, onError) => {
  return axiosPost(`${API_URL}/quickbook-invoice/deleteQuickBookInvoice`, data).then(onSuccess).catch(onError);
};

export const apiGetInvoiceReports = (data, onSuccess, onError) => {
  return axiosPost(`${API_URL}/quickbook-invoice/getInvoiceReports`, data).then(onSuccess).catch(onError);
};

export const apiGetVendorList = (onSuccess, onError) => {
  return axiosGet(`${API_URL}/quickbook-invoice/getVendorList`).then(onSuccess).catch(onError);
};

export const apiGetBrokerList = (onSuccess, onError) => {
  return axiosGet(`${API_URL}/quickbook-invoice/getBrokerList`).then(onSuccess).catch(onError);
};

export const apiDownloadInvoiceSpreadsheet = (data, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/quickbook-invoice/downloadInvoiceSpreadsheet`, data, fileName, onSuccess).catch(onError);
};
