import { axiosGet, axiosPost } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetSignerNotes = (signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/signer-note/getSignerNotes`, { signerId }, false).then(onSuccess).catch(onError);
};

export const apiAddSignerNote = (data, onSuccess, onError) => {
    return axiosPost(`${API_URL}/signer-note/addSignerNote`, data, false).then(onSuccess).catch(onError);
};
