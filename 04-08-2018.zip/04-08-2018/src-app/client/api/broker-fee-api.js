import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "Helpers/axios-helper";

export const apiGetBrokerFeeByBrokerId = (inputs, onSuccess, onError) => {
    return axiosGet(`${API_URL}/brokerfee/getBrokerFeeByBrokerId`, inputs, false).then(onSuccess).catch(onError);
};

export const apiUpdateBrokerFee = (brokerFee, onSuccess, onError) => {
    return axiosPost(`${API_URL}/brokerfee/updateBrokerFee`, brokerFee, false).then(onSuccess).catch(onError);
};