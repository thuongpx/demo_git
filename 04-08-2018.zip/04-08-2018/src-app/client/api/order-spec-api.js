import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "Helpers/axios-helper";

export const apiGetOrderSpecificsData = (orderId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/order/getOrderSpecificsData?orderId=${orderId}`).then(onSuccess).catch(onError);
};

export const apiUpdateOrderSpecificsData = (data, onSuccess, onError) => {
    return axiosPost(`${API_URL}/order/updateOrderSpecific`, data).then(onSuccess).catch(onError);
};