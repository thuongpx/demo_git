import {
  API_URL
} from "Config/config";
import {
  axiosGet,
  axiosPost,
  axiosDownload
} from "../helpers/axios-helper";
import {
  trimObject
} from "Helpers/common-helper";

export const apiGetDocGrid = (criteria, onSuccess, onError) => {
  return axiosGet(`${API_URL}/order/getDocGrid`, criteria).then(onSuccess).catch(onError);
};
export const apiGetDocGridMultiple = (criteria, onSuccess, onError) => {
  return axiosGet(`${API_URL}/order/getDocGridMultiple`, criteria).then(onSuccess).catch(onError);
};

export const apiGetOrderDoc = (orderId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/order/getOrderDocsByOrderId?orderId=${orderId}`).then(onSuccess).catch(onError);
};

export const apiUploadClientDoc = (formData, onSuccess, onError) => {
  return axiosPost(`${API_URL}/order/uploadClientDoc`, formData, false).then(onSuccess).catch(onError);
};

export const apiUpdateOrderDoc = (data, onSuccess, onError) => {
  return axiosPost(`${API_URL}/order/updateOrderDoc`, trimObject(data), false).then(onSuccess).catch(onError);
};

export const apiInsertOrderDoc = (data, onSuccess, onError) => {
  return axiosPost(`${API_URL}/order/insertOrderDoc`, trimObject(data), false).then(onSuccess).catch(onError);
};

export const apiDeleteOrderDoc = (docId, onSuccess, onError) => {
  return axiosPost(`${API_URL}/order/deleteOrderDoc`, {
    docId
  }).then(onSuccess).catch(onError);
};

export const apiCheckDocName = (orderId, docName, docType, onSuccess, onError) => {
  return axiosGet(`${API_URL}/order/checkDocName?orderId=${orderId}&docName=${docName}&docType=${docType}`).then(onSuccess).catch(onError);
};

export const apiDeleteMultipleOrderDoc = (docList, onSuccess, onError) => {
  return axiosPost(`${API_URL}/order/deleteMultipleOrderDoc`, docList).then(onSuccess).catch(onError);
};

export const apiShareAllDocsByOrderId = (orderId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/order/shareAllDocsByOrderId`, {
    orderId
  }).then(onSuccess).catch(onError);
};

export const apiDownloadOrderDoc = (data, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/order/downloadOrderDoc`, data, fileName, onSuccess).catch(onError);
};

export const apiChangeStatusOnFirstDocUploaded = (data, onSuccess, onError) => {
  return axiosGet(`${API_URL}/order/changeStatusOnFirstDocUploaded`, data).then(onSuccess).catch(onError);
};

export const apiGetListDocRejectReason = (onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getListDocRejectReason`).then(onSuccess).catch(onFail);
};

export const apiSendEmailRejectSignedDoc = (data, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/sendEmailRejectSignedDoc`, data).then(onSuccess).catch(onFail);
};

export const apiGetClientDocuments = (data, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/getClientDocuments`, data).then(onSuccess).catch(onFail);
};

export const apiGetListOrderDocComments = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getListOrderDocComments`, inputs).then(onSuccess).catch(onFail);
};

export const apiAddOrderDocAdditionalComment = (inputs, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/addOrderDocAdditionalComment`, inputs).then(onSuccess).catch(onFail);
};

export const apiGetSignerDocs = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getSignerDocs`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

export const apiShareAllSignerDoc = (orderId, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/shareAllSignerDoc`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

export const apiArchiveOrderDoc = (docId, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/archiveOrderDoc`, {
    docId
  }).then(onSuccess).catch(onFail);
};

export const apiDownloadAllDocs = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/order/downloadAllDocs`, input, fileName, onSuccess, true)
    .catch(onError);
};
