import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "Helpers/axios-helper";

export const apiGetOrderDateData = (orderId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/order/getOrderDatesById?orderId=${orderId}`).then(onSuccess).catch(onError);
};

export const apiUpdateOrderDateData = (newOrderDate, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/order/updateOrderDate`, newOrderDate, false).then(onSuccess).catch(onFail);
};