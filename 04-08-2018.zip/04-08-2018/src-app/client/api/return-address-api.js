import { API_URL } from "Config/config";
import { axiosPost, axiosGet } from "Helpers/axios-helper";

export const apiAddReturnAddress = (address, onSuccess, onError) => {
    return axiosPost(`${API_URL}/return-address/addReturnAddress`, address).then(onSuccess).catch(onError);
};

export const apiDeleteReturnAddress = (raId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/return-address/deleteReturnAddress`, { raId }, false).then(onSuccess).catch(onError);
};

export const apiUpdateReturnAddress = (criteria, onSuccess, onError) => {
    return axiosPost(`${API_URL}/return-address/updateReturnAddress`, criteria, false).then(onSuccess).catch(onError);
};