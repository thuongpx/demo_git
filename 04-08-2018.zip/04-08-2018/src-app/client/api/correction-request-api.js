import {
  axiosPost,
  axiosGet
} from "Helpers/axios-helper";
import {
  API_URL
} from "Config/config";
import {
  trimObject
} from "../helpers/common-helper";

export const apiGetCorrectionRequestList = (filter, successCb, failCb) => {
  return axiosGet(`${API_URL}/problem/getCorrectionRequestType`, filter, false).then(successCb).catch(failCb);
};

export const apiDeleteCorrectionRequest = (Id, onSuccess, onError) => {
  return axiosPost(`${API_URL}/problem/deleteCorrectionRequestType`, {
    Id
  }).then(onSuccess).catch(onError);
};

export const apiGetCorretionRequestById = (Id, onSuccess, onError) => {
  return axiosGet(`${API_URL}/problem/getCorretionRequestById`, {
    Id
  }).then(onSuccess).catch(onError);
};

export const apiCheckExistCorrectionRequest = (problem, onSuccess, onError) => {
  return axiosPost(`${API_URL}/problem/checkExistCorrectionRequest`, problem, false).then(onSuccess).catch(onError);
};

export const apiUpdateCorrectionRequest = (problem, onSuccess, onError) => {
  return axiosPost(`${API_URL}/problem/updateCorrectionRequest`, trimObject(problem), false).then(onSuccess).catch(onError);
};

export const apiAddCorrectionRequest = (problem, onSuccess, onError) => {
  return axiosPost(`${API_URL}/problem/addCorrectionRequest`, trimObject(problem), false).then(onSuccess).catch(onError);
};
