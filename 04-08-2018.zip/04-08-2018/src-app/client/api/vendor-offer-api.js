import { axiosPost, axiosGet } from "Helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";
import { API_URL } from "Config/config";

export const apiGetVendorOffers = (gridCriteria, signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-offer/getVendorOffer`, trimObject({ ...gridCriteria, signerId })).then(onSuccess).catch(onError);
};

export const apiUpdateStatusVendorOffer = (feedbackObject, offerStatus, signerId, valueExistVendorOffer, onSuccess, onFail) => {
    feedbackObject.offerStatus = offerStatus;
    feedbackObject.signerId = signerId;
    feedbackObject.valueExistVendorOffer = valueExistVendorOffer;
    return axiosPost(`${API_URL}/vendor-offer/updateStatusVendorOffer`, trimObject(feedbackObject))
        .then(onSuccess)
        .catch(onFail);
};

export const apiGetReasonDeclined = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-offer/getReasonDeclined`).then(onSuccess).catch(onError);
};

export const apiSendRequestFeedback = (feedbackObject, userId, signerId, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/vendor-offer/sendRequestFeedback`, trimObject({ ...feedbackObject, userId, signerId }))
        .then(onSuccess)
        .catch(onFail);
};

export const apiInactivatedUser = (userId, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/vendor-offer/inactivatedUser`, trimObject({ UsersId: userId }))
        .then(onSuccess)
        .catch(onFail);
};

export const apiCheckExistVendorOffer = (aptDateTime, aptUTC, signerId, orderId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-offer/checkExistVendorOffer`, trimObject({ aptDateTime, aptUTC, signerId, orderId })).then(onSuccess).catch(onError);
};

export const apiGetVendorOfferByGUID = (paramGUID, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-offer/getVendorOfferByGUID`, trimObject({ paramGUID })).then(onSuccess).catch(onError);
};

export const apiGetAccountbyGUID = (paramGUID, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-offer/getAccountbyGUID`, trimObject({ paramGUID })).then(onSuccess).catch(onError);
};

export const apiGetVendorFeeByOrderId = (orderId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-offer/getVendorFeeByOrderId`, trimObject({ orderId })).then(onSuccess).catch(onError);
};