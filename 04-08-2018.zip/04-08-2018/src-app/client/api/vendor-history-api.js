import { axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetVendorHistory = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-history/getVendorHistory`, criteria, false).then(onSuccess).catch(onError);
};
