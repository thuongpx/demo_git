import { axiosGet, axiosPut } from "Helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";
import { API_URL } from "Config/config";

export const apiUpdateBrokerById = (broker, onSuccess, onError) => {
    return axiosPut(`${API_URL}/broker/updateBrokerById`, trimObject(broker), false).then(onSuccess).catch(onError);
};

export const apiGetBrokerById = (brokerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/broker/getBrokerById`, { brokerId }, false).then(onSuccess).catch(onError);
};

export const apiGetBrokerInfoDefault = (brokerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/broker/getBrokerInfoDefault`, { brokerId }, false).then(onSuccess).catch(onError);
};

export const apitGetSpecialInstrucionOfClient = (input, onSuccess, onError) => {
    return axiosGet(`${API_URL}/client/getSpecialInstrucionOfClient`, input).then(onSuccess).catch(onError);
};