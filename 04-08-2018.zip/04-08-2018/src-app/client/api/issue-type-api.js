import { axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetAllIssueType = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/issueType/getAllIssueType`, false).then(onSuccess).catch(onError);
};


