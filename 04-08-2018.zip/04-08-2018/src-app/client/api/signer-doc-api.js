import { axiosPost, axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiUploadSignerDocument = (signerDocument, onSuccess, onError) => {
    return axiosPost(`${API_URL}/signerDoc/uploadSignerDocument`, signerDocument, false).then(onSuccess).catch(onError);
};

export const apiGetSignerDocBySignerId = (signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/signerDoc/getSignerDocBySignerId`, { signerId }, false).then(onSuccess).catch(onError);
};

export const apiGetSignerDocsStatus = (signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/signerDoc/getSignerDocsStatus`, { signerId }, false).then(onSuccess).catch(onError);
};

export const apiCheckSignerDocExisting = (signerDoc, onSuccess, onError) => {
    return axiosGet(`${API_URL}/signerDoc/checkSignerDocExisting`, signerDoc, false).then(onSuccess).catch(onError);
};

export const apiVendorDocsStatusById = (signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/signerDoc/getVendorDocsStatusById`, { signerId }, false).then(onSuccess).catch(onError);
};

export const apiAprroveVendorDoc = (docId, userId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/signerDoc/aprroveVendorDoc`, { docId, userId }, false).then(onSuccess).catch(onError);
};

export const apiRejectVendorDoc = (docId, rejectReason, userId, signerId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/signerDoc/rejectVendorDoc`, { docId, rejectReason, userId, signerId }, false).then(onSuccess).catch(onError);
};

export const apiArchiveVendorDoc = (docData, signerId, userId, onSuccess, onError) => {
    docData.SignerId = signerId;
    docData.UserId = userId;
    return axiosPost(`${API_URL}/signerDoc/archiveVendorDoc`, docData, false).then(onSuccess).catch(onError);
};

export const apiGetVendorDocsArchiveById = (signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/signerDoc/getVendorDocsArchiveById`, { signerId }, false).then(onSuccess).catch(onError);
};

export const apiArchiveVendorDocArchive = (docArchiveData, onSuccess, onError) => {
    return axiosPost(`${API_URL}/signerDoc/archiveVendorDocArchive`, docArchiveData, false).then(onSuccess).catch(onError);
};

export const apiGetSignerDocsForTceValidation = (signerId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/signerDoc/getSignerDocsForTceValidation`, { signerId }, false).then(onSuccess).catch(onError);
};

