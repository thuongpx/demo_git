import { axiosPost, axiosGet } from "Helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";
import { API_URL } from "Config/config";


export const apiGetAgentsByBrokerId = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/agent/getAgentsByBrokerId`, criteria, false).then(onSuccess).catch(onError);
};

export const apiGetAgent = (agentId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/agent/getAgentById`, { agentId }, false).then(onSuccess).catch(onError);
};

export const apiGetAllAgents = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/agent/getAllAgents`, criteria, false).then(onSuccess).catch(onError);
};

export const apiAddAgent = (agent, user, onSuccess, onError) => {
    return axiosPost(`${API_URL}/agent/addAgent`, { agent: trimObject(agent), user: trimObject(user) }, false).then(onSuccess).catch(onError);
};

export const apiUpdateAgent = (agent, onSuccess, onError) => {
    return axiosPost(`${API_URL}/agent/updateAgent`, trimObject(agent), false).then(onSuccess).catch(onError);
};

export const apiDisableOrActiveAgent = (agent, onSuccess, onError) => {
    return axiosPost(`${API_URL}/agent/disableOrActiveAgent`, trimObject(agent), false).then(onSuccess).catch(onError);
};

export const apiGetAgentByOption = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/agent/getAgentByOption`, trimObject(criteria), false).then(onSuccess).catch(onError);
};

export const apiDeactivateAgent = (data, onSuccess, onError) => {
    return axiosPost(`${API_URL}/agent/deactivateAgent`, data, false).then(onSuccess).catch(onError);
};