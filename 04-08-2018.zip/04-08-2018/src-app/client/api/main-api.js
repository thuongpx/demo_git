import { axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

// annv2: comment out beacause it is duplicate with broker-api
// export const apiGetApprovalRequestNumber = (brokerId, onSuccess, onError) => {
//     return axiosGet(`${API_URL}/main/getApprovalRequestNumber?brokerid=${brokerId}`).then(onSuccess).catch(onError);
// };
