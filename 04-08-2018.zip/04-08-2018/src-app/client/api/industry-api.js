import { axiosGet, axiosPost } from "Helpers/axios-helper";
import { API_URL } from "Config/config";
import { trimObject } from "Helpers/common-helper";

export const apiGetAllIndustry = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/industry/getAllIndustry`, null, false).then(onSuccess).catch(onError);
};


export const apiDeleteIndustry = (industryId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/industry/deleteIndustry`, { industryId }, false).then(onSuccess).catch(onError);
};

export const apiGetIndustries = (criteria, onSuccess, onError) => {
    return axiosPost(`${API_URL}/industry/getIndustries`, trimObject(criteria), false).then(onSuccess).catch(onError);
};

export const apiCheckExistIndustry = (industry, onSuccess, onError) => {
    return axiosPost(`${API_URL}/industry/checkExistIndustry`, industry, false).then(onSuccess).catch(onError);
};

export const apiUpdateIndustry = (industry, onSuccess, onError) => {
    return axiosPost(`${API_URL}/industry/updateIndustry`, trimObject(industry), false).then(onSuccess).catch(onError);
};

export const apiAddIndustry = (industry, onSuccess, onError) => {
    return axiosPost(`${API_URL}/industry/addIndustry`, trimObject(industry), false).then(onSuccess).catch(onError);
};