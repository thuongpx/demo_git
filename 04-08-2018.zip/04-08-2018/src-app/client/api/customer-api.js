import { API_URL } from "Config/config";
import { axiosPost, axiosGet } from "Helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";

export const apiGetCustomers = (criteria, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/customer/getCustomers`, trimObject(criteria)).then(onSuccess).catch(onFail);
};

export const apiGetCustomerById = (customerId, brokerId, industryId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/customer/getCustomerById?customerId=${customerId}&&brokerId=${brokerId}&&industryId=${industryId}`).then(onSuccess).catch(onFail);
};

export const apiAddCustomer = (customer, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/customer/addCustomer`, trimObject(customer)).then(onSuccess).catch(onFail);
};

export const apiUpdateCustomer = (customer, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/customer/updateCustomer`, trimObject(customer)).then(onSuccess).catch(onFail);
};

export const apiDeleteCustomer = (customerId, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/customer/deleteCustomer`, { customerId }, false).then(onSuccess).catch(onFail);
};

export const apiGetSubLoanTypes = (loanTypeId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/sub-loan-type/getSubLoanTypes?LoanTypeId=${loanTypeId}`).then(onSuccess).catch(onFail);
};

export const apiGetAvailableSigner = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/customer/getAvailableSigner`, criteria, false).then(onSuccess).catch(onError);
};

export const apiGetBlackListSigner = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/customer/getBlackListSigner`, criteria, false).then(onSuccess).catch(onError);
};

export const apiUpdateBlackListSigner = (brokerId, blackList, onSuccess, onError) => {
    axiosPost(`${API_URL}/customer/updateBlackListSigner`, { brokerId, blackList }, false).then(onSuccess).catch(onError);
};

export const apiUpdateWhiteListSigner = (brokerId, whiteList, onSuccess, onError) => {
    axiosPost(`${API_URL}/customer/updateWhiteListSigner`, { brokerId, whiteList }, false).then(onSuccess).catch(onError);
};

export const apiCheckExistOrderAssociated = (customerId, onSuccess, onError) => {
  axiosGet(`${API_URL}/customer/checkExistOrderAssociated`, {
    customerId
  }, false).then(onSuccess).catch(onError);
};

export const apiGetLoanTypes = (industryId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/loan-type/getLoanTypeByIndustryId?industryId=${industryId}`).then(onSuccess).catch(onFail);
};
