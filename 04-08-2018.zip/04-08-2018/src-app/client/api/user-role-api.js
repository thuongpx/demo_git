import { API_URL } from "Config/config";
import { axiosPost } from "Helpers/axios-helper";

export const apiSaveUsersroles = (userRoles, onSuccess, onError) => {
    return axiosPost(`${API_URL}/userRoles/addUserRole`, {
        data: userRoles
    }).then(onSuccess).catch(onError);
};
