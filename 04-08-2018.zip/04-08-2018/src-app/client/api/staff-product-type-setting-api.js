import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "../helpers/axios-helper";


export const apiGetProductType = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/product-type/getProductType`, criteria, false).then(onSuccess).catch(onError);
};

export const apiProductTypeExist = (loanType, onSuccess, onError) => {
    return axiosGet(`${API_URL}/product-type/checkExistProductType`, { loanType }, false).then(onSuccess).catch(onError);
};

export const apiDeleteProductType = (loanTypeId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/product-type/deleteProductType`, { loanTypeId }).then(onSuccess).catch(onError);
};

export const apiAddProductType = (input, onSuccess, onError) => {
    return axiosPost(`${API_URL}/product-type/addProductType`, input).then(onSuccess).catch(onError);
};

export const apiUpdateProductType = (input, onSuccess, onError) => {
    return axiosPost(`${API_URL}/product-type/updateProductType`, input).then(onSuccess).catch(onError);
};