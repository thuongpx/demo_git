import { API_URL } from "Config/config";
import { axiosGet } from "Helpers/axios-helper";

export const apiGetOrdersSignerHistory = (conditions, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/signerHistory/getOrdersSignerHistory`, conditions).then(onSuccess).catch(onFail);
};