import {
    axiosGet, axiosPost
} from "Helpers/axios-helper";
import {
    API_URL
} from "Config/config";

export const apiSendFaxcover = (orderID, selectSendMailOption, onSuccess, onError) => {
    return axiosGet(`${API_URL}/report/sendFaxcover`, { orderID, selectSendMailOption }).then(onSuccess).catch(onError);
};

export const apiSendMailReport = (mailOptions, onSuccess, onError) => {
    return axiosPost(`${API_URL}/report/sendMailReport`, mailOptions).then(onSuccess).catch(onError);
};

export const apiSendConfirmation = (orderID, selectSendMailOption, onSuccess, onError) => {
    return axiosGet(`${API_URL}/report/sendConfirmation`, { orderID, selectSendMailOption }).then(onSuccess).catch(onError);
};

export const apiSendAptScheduled = (orderID, selectSendMailOption, onSuccess, onError) => {
    return axiosGet(`${API_URL}/report/sendAptScheduled`, { orderID, selectSendMailOption }).then(onSuccess).catch(onError);
};

export const apiSendClosing = (orderID, selectSendMailOption, onSuccess, onError) => {
    return axiosGet(`${API_URL}/report/sendClosing`, { orderID, selectSendMailOption }).then(onSuccess).catch(onError);
};

export const apiSendInvoice = (orderID, selectSendMailOption, onSuccess, onError) => {
    return axiosGet(`${API_URL}/report/sendInvoice`, { orderID, selectSendMailOption }).then(onSuccess).catch(onError);
};