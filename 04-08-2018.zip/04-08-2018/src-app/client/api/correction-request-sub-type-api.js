import {
  axiosPost,
  axiosGet
} from "Helpers/axios-helper";
import {
  API_URL
} from "Config/config";
import {
  trimObject
} from "../helpers/common-helper";

export const apiGetCorrectionRequestSubList = (filter, successCb, failCb) => {
  return axiosGet(`${API_URL}/problem/getCorrectionRequestSubList`, filter, false).then(successCb).catch(failCb);
};

export const apiGetCorretionRequestSubTypeById = (Id, onSuccess, onError) => {
  return axiosGet(`${API_URL}/problem/getCorretionRequestSubTypeById`, {
    Id
  }).then(onSuccess).catch(onError);
};

export const apiCheckExistCorrectionRequestSubType = (problem, onSuccess, onError) => {
  return axiosPost(`${API_URL}/problem/checkExistCorrectionRequestSubType`, problem, false).then(onSuccess).catch(onError);
};

export const apiUpdateCorrectionRequestSubType = (problem, onSuccess, onError) => {
  return axiosPost(`${API_URL}/problem/updateCorrectionRequestSubType`, trimObject(problem), false).then(onSuccess).catch(onError);
};

export const apiAddCorrectionRequestSubType = (problem, onSuccess, onError) => {
  return axiosPost(`${API_URL}/problem/addCorrectionRequestSubType`, trimObject(problem), false).then(onSuccess).catch(onError);
};
