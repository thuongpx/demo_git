import {
  axiosGet,
  axiosPost,
  axiosPut
} from "Helpers/axios-helper";
import {
  API_URL
} from "Config/config";
import {
  trimObject
} from "Helpers/common-helper";
import {
  APP_URL
} from "../config/config";

export const apiCheckExistUser = async (username, onSuccess, onError) => {
  if (onSuccess) {
    return axiosGet(`${API_URL}/user/checkExistUser`, {
      username
    }, true).then(onSuccess).catch(onError);
  } else {
    return await axiosGet(`${API_URL}/user/checkExistUser`, {
      username
    }, true);
  }
};

export const apiResetPassword = (params, onSuccess, onError) => {
  return axiosGet(`${API_URL}/user/resetPassword`, params, false).then(onSuccess).catch(onError);
};

export const apiResetPasswordByUserId = (param, onSuccess, onError) => {
  return axiosGet(`${API_URL}/user/resetPasswordByUserId`, {
    param
  }, false).then(onSuccess).catch(onError);
};

export const apiGetStaffInfo = (params, onSuccess, onError) => {
  return axiosGet(`${API_URL}/user/getStaffInfo`, params, false).then(onSuccess).catch(onError);
};

export const apiSaveStaffProfile = (payload, onSuccess, onError) => {
  return axiosPost(`${API_URL}/user/saveStaffProfile`, payload, false).then(onSuccess).catch(onError);
};

export const apiGenerateDefaultLogin = (params, onSuccess, onError) => {
  return axiosGet(`${API_URL}/user/generateDefaultLogin`, params, true).then(onSuccess).catch(onError);
};

export const apiAddVendor = (vendor, onSuccess, onFail) => {
  const data = {
    vendor,
    url: APP_URL
  };
  axiosPost(`${API_URL}/user/addVendor`, trimObject(data)).then(onSuccess).catch(onFail);
};

export const apiAddBranch = (branch, onSuccess, onFail) => {
  axiosPost(`${API_URL}/user/addBranch`, trimObject(branch)).then(onSuccess).catch(onFail);
};

export const apiGetBillingInformationDefault = (input, onSuccess, onFail) => {
  axiosGet(`${API_URL}/user/getBillingInformationDefault`, {
    accountId: input.accountId,
    userId: input.userId,
    roleType: input.roleType
  }).then(onSuccess).catch(onFail);
};

export const apiUpdateBillingInformation = (id, input, onSuccess, onFail) => {
  axiosPost(`${API_URL}/user/updateBillingInformation?brokerId=${id}`, input).then(onSuccess).catch(onFail);
};

export const apiGetUserProfileSecurity = (params, onSuccess, onError) => {
  return axiosGet(`${API_URL}/user-profile-security/getUserProfile`, params, false).then(onSuccess).catch(onError);
};

export const apiUpdateUserProfileSecurity = (payload, onSuccess, onError) => {
  return axiosPost(`${API_URL}/user-profile-security/updateUserProfileSecurity`, payload, false).then(onSuccess).catch(onError);
};

export const apiGetAdditionalInformationDefault = (input, onSuccess, onFail) => {
  axiosGet(`${API_URL}/user/getAdditionalInformationDefault`, {
    accountId: input.accountId,
    userId: input.userId,
    roleType: input.roleType
  }).then(onSuccess).catch(onFail);
};

export const apiSaveAdditionalInformation = (input, onSuccess, onFail) => {
  axiosPost(`${API_URL}/user/updateAdditionalInformation`, {
    data: input.data,
    brokerId: input.brokerId,
    listTrainingOld: input.listTrainingOld
  }).then(onSuccess).catch(onFail);
};

export const apiEmailVerification = (userId, token, onSuccess, onError) => {
  return axiosPost(`${API_URL}/user/emailVerification`, {
    userId,
    token
  }, false).then(onSuccess).catch(onError);
};

export const apiAddClientUser = (inputs, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/user/addClient`, inputs, false).then(onSuccess).catch(onFail);
};

export const apiGetClientBilling = (clientId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/user/getClientBilling`, {
    clientId
  }).then(onSuccess).catch(onFail);
};

export const apiResendEmailVerification = (inputs, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/user/resendVerificationUserEmail`, inputs).then(onSuccess).catch(onFail);
};

export const apiCheckSignerFirstLogin = (signerId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/user/checkSignerFirstLogin`, {
    signerId
  }).then(onSuccess).catch(onFail);
};

export const apiVendorResendEmailVerification = (params, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/user/resendEmailVerification`, params).then(onSuccess).catch(onFail);
};

export const apiCheckUserCreds = (creds, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/user/checkUserCreds`, {
    creds
  }).then(onSuccess).catch(onFail);
};

export const apiGetClientsUserByRole = (userData, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/user/getClientsUserByRole`, userData).then(onSuccess).catch(onFail);
};

export const apiUpdateUserStatus = (inputs, onSuccess, onFail) => {
  return axiosPut(`${API_URL}/user/updateUserStatus`, inputs).then(onSuccess).catch(onFail);
};

export const apiSendForgotPasswordEmail = (params, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/user/sendForgotPasswordEmail`, params).then(onSuccess).catch(onFail);
};

export const apiCheckForgotPasswordSecurityCode = (securityCode, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/user/checkForgotPasswordSecurityCode`, {
    securityCode
  }).then(onSuccess).catch(onFail);
};

export const apiChangeUserPassword = (params, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/user/changeUserPassword`, params).then(onSuccess).catch(onFail);
};

export const apiResetUserPassword = (params, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/user/resetUserPassword`, params).then(onSuccess).catch(onFail);
};

export const apiCheckUserFirstLogin = (userId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/user/checkUserFirstLogin`, {
    userId
  }).then(onSuccess).catch(onFail);
};

export const apiCheckUserNeedToResetPassword = (userId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/user/checkUserNeedToResetPassword`, {
    userId
  }).then(onSuccess).catch(onFail);
};

export const apiClientInviteUser = (email, role, brokerId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/user/clientInviteUser`, {
    email,
    role,
    brokerId
  }).then(onSuccess).catch(onFail);
};

export const apiCheckPasswordExpired = (userId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/user/checkPasswordExpired`, {
    userId
  }).then(onSuccess).catch(onFail);
};

export const apiCheckResetPasswordSecurityCode = (data, onSuccess, onFail) => {
  console.log(data);
  return axiosPost(`${API_URL}/user/checkResetPasswordSecurityCode`, data).then(onSuccess).catch(onFail);
};

export const apiFetchBillingInformation = (userId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/user/fetchBillingInformation`, {
    userId
  }).then(onSuccess).catch(onFail);
};

export const apiGetProfilePicture = (id, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/user/getProfilePicture`, {
    id
  }).then(onSuccess).catch(onFail);
};

export const apiChangePassword = (payload, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/user/changePassword`, payload).then(onSuccess).catch(onFail);
};

export const apiUpdateFirstLogin = (usersId, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/user/updateFirstLogin`, { usersId }).then(onSuccess).catch(onFail);
};

export const apiCheckFirstLogin = (usersId, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/user/checkFirstLogin`, { usersId }).then(onSuccess).catch(onFail);
};
