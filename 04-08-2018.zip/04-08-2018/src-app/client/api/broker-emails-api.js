import { axiosGet, axiosPost } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiAddCcEmail = (ccEmail, onSuccess, onError) => {
    return axiosPost(`${API_URL}/broker-emails/addCcEmail`, ccEmail).then(onSuccess).catch(onError);
};

export const apiDeleteCcEmail = (BrokerEmailId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/broker-emails/deleteCcEmail`, { BrokerEmailId }, false).then(onSuccess).catch(onError);
};

export const apiUpdateCcEmail = (ccEmail, onSuccess, onError) => {
    return axiosPost(`${API_URL}/broker-emails/updateCcEmail`, ccEmail).then(onSuccess).catch(onError);
};