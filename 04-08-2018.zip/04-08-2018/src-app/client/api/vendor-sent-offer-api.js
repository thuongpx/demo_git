import { axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetVendorSentOffer = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-sent-offer/getVendorSentOffer`, criteria, false).then(onSuccess).catch(onError);
};
