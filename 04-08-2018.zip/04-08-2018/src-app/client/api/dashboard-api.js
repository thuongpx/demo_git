import { axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetOrdersInfoDashboard = (data, success, fail) => {
    return axiosGet(`${API_URL}/client-dashboard/getOrdersInfoDashboard`, data).then(success).catch(fail);
};

export const apiGetOrdersInfoDetailDashboard = (data, success, fail) => {
    return axiosGet(`${API_URL}/client-dashboard/getOrdersInfoDetailDashboard`, data).then(success).catch(fail);
};

export const apiGetSLA = (data, success, fail) => {
    return axiosGet(`${API_URL}/client-dashboard/getSLADashboard`, data).then(success).catch(fail);
};

export const apiGetOrdersInfoSchedulerDashboard = (data, success, fail) => {
    return axiosGet(`${API_URL}/staff-dashboard/getOrdersInfoSchedulerDashboard`, data).then(success).catch(fail);
};