import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "../helpers/axios-helper";

export const apiGetAllNotificationManagement = (input, onSuccess, onError) => {

    return axiosGet(`${API_URL}/manageNotification/getAllNotificationManagement`, input, false)
        .then(onSuccess)
        .catch(onError);
};

export const apiGetInitDataDrop = (onSuccess, onError) => {

    return axiosGet(`${API_URL}/manageNotification/getInitDataDrop`, false)
        .then(onSuccess)
        .catch(onError);
};

export const apiDeleteManageNotification = (NotificationId, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/manageNotification/deleteNotificationManagement`, { NotificationId })
        .then(onSuccess)
        .catch(onFail);
};
export const apiGetNotifByRepNotifID = (notificationId, successCb, failCb) => {
    return axiosGet(`${API_URL}/manageNotification/getNotifByNotifID`, { notificationId }, false)
        .then(successCb)
        .catch(failCb);
};
export const apiUpdateNotif = (input, successCb, failCb) => {
    return axiosPost(`${API_URL}/manageNotification/updateNotif`, input, false)
        .then(successCb)
        .catch(failCb);
};

export const apiSendMail = (mailData, onSuccess, onFail) => {
    axiosPost(`${API_URL}/manageNotification/sendEMail`, mailData)
        .then(onSuccess)
        .catch(onFail);
};

export const apiSendSMS = (smsData, onSuccess, onFail) => {
    axiosPost(`${API_URL}/manageNotification/sendSMS`, smsData)
        .then(onSuccess)
        .catch(onFail);
};
