import { axiosPost, axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiFilterCitiesOfStates = (data, onSuccess, onError) => {
    return axiosPost(`${API_URL}/zip/filterCitiesOfStates`, data).then(onSuccess).catch(onError);
};

export const apiGetTimeZoneByZip = (zip, onSuccess, onError) => {
    return axiosGet(`${API_URL}/zip/getTimeZoneByZip`, { zip }).then(onSuccess).catch(onError);
};