import { axiosGet, axiosPost } from "Helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";
import { API_URL } from "Config/config";

export const apiGetVendorProblems = (gridCriteria, onSuccess, onError) => {
    return axiosGet(
        `${API_URL}/vendor-problem/getVendorProblems`,
        trimObject({ ...gridCriteria })
    ).then(onSuccess)
        .catch(onError);
};

export const apiGetVendorProblemStatus = (onSuccess, onError) => {
    return axiosGet(
        `${API_URL}/vendor-problem/getVendorProblemStatus`
    ).then(onSuccess)
        .catch(onError);
};

export const apiGetVendorProblemDetail = (id, onSuccess, onError) => {
    return axiosGet(
        `${API_URL}/vendor-problem/vendorProblem`, { id }
    ).then(onSuccess)
        .catch(onError);
};

export const apiInitVendorProblemSearch = (onSuccess, onError) => {
    return axiosGet(
        `${API_URL}/vendor-problem/initVendorProblemSearch`
    ).then(onSuccess)
        .catch(onError);
};

export const apiUpdateProblem2Acknowledge = (data, onSuccess, onError) => {
    return axiosPost(
        `${API_URL}/vendor-problem/setProblem2Acknowledge`, data
    ).then(onSuccess)
        .catch(onError);
};

//
export const apiGetAllVendorProblems = (gridCriteria, onSuccess, onError) => {
    return axiosGet(
        `${API_URL}/vendor-problem/getAllVendorProblems`,
        trimObject({ ...gridCriteria })
    ).then(onSuccess)
        .catch(onError);
};

