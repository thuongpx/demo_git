import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "../helpers/axios-helper";


export const apiGetTrainingLearningPath = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/training-learning-path/getTrainingLearningPath`, criteria, false).then(onSuccess).catch(onError);
};

export const apiCheckLearningPathExist = (lPName, onSuccess, onError) => {
    return axiosGet(`${API_URL}/training-learning-path/checkExistLearningPath`, { lPName }, false).then(onSuccess).catch(onError);
};

export const apiDeleteTrainingLearningPath = (lPID, onSuccess, onError) => {
    return axiosPost(`${API_URL}/training-learning-path/deleteTrainingLearningPath`, { lPID }).then(onSuccess).catch(onError);
};

export const apiAddLearningPath = (input, onSuccess, onError) => {
    return axiosPost(`${API_URL}/training-learning-path/addLearningPath`, input).then(onSuccess).catch(onError);
};

export const apiGetRequiredPrograms = (lpId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/training-learning-path/getRequiredPrograms`, { lpId }, false).then(onSuccess).catch(onError);
};

export const apiUpdateLearningPath = (input, onSuccess, onError) => {
    return axiosPost(`${API_URL}/training-learning-path/updateLearningPath`, input).then(onSuccess).catch(onError);
};