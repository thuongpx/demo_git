import {
  API_URL
} from "Config/config";
import {
  axiosPost,
  axiosGet
} from "Helpers/axios-helper";
import {
  trimObject
} from "Helpers/common-helper";

export const apiGetClients = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/client/getClients`, trimObject(criteria)).then(onSuccess).catch(onFail);
};

export const apiGetClientManagement = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/client/getClientManagementData`, criteria).then(onSuccess).catch(onFail);
};

export const apiChangeStatusClient = (brokerId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/client/changeStatusClient?brokerId=${brokerId}`).then(onSuccess).catch(onFail);
};

export const apiLockBranch = (branchId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/branch/lockBranch?branchId=${branchId}`).then(onSuccess).catch(onFail);
};

export const apiAddClient = (client, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/client/addClient`, trimObject(client), false).then(onSuccess).catch(onFail);
};

export const apiUpdateClient = (client, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/client/updateClient`, trimObject(client)).then(onSuccess).catch(onFail);
};

export const apiUpdateClientContact = (clientContact, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/client/updateClientContact`, trimObject(clientContact)).then(onSuccess).catch(onFail);
};

export const apiUpdateClientIsAvailable = (brokerId, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/client/updateClientIsAvailable`, {
    brokerId
  }).then(onSuccess).catch(onFail);
};

export const apiGetClientById = (brokerId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/client/getClientById?brokerId=${brokerId}`).then(onSuccess).catch(onFail);
};

export const apiGetClientContactByClientId = (brokerId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/client/getClientContactByClientId`, {
    brokerId
  }).then(onSuccess).catch(onFail);
};

export const apiGetClientOrderByClientId = (brokerId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/client/getClientOrderByClientId`, {
    brokerId
  }).then(onSuccess).catch(onFail);
};

export const apiGetAllClientForDropDown = (onSuccess, onFail) => {
  return axiosGet(`${API_URL}/client/getAllClientForDropDown`).then(onSuccess).catch(onFail);
};

export const apiGetBranchesByBrokerId = (brokerId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/client/getBranchesByBrokerId`, {
    brokerId
  }).then(onSuccess).catch(onFail);
};

export const apiGetClientProfiles = (clientId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/client-profile/getClientProfiles`, {
    clientId
  }).then(onSuccess).catch(onFail);
};

export const apiGetCredentialsInformation = (params, onSuccess, onError) => {
  return axiosGet(`${API_URL}/client-profile/getUserProfileCredentials`, params, false).then(onSuccess).catch(onError);
};

export const apiUpdateCredentialsInformation = (payload, onSuccess, onError) => {
  return axiosPost(`${API_URL}/client-profile/updateUserProfileCredentials`, payload, false).then(onSuccess).catch(onError);
};

export const apiUpdateClientProfiles = (payload, onSuccess, onError) => {
  return axiosPost(`${API_URL}/client-profile/updateClientProfiles`, payload, false).then(onSuccess).catch(onError);
};

export const apiUpdateClientBillingDetail = (payload, onSuccess, onError) => {
  return axiosPost(`${API_URL}/client-profile/updateClientBillingDetail`, payload, false).then(onSuccess).catch(onError);
};

export const apiAddClientPreferredVendor = (inputs, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/client-preferred-vendor/addClientPreferredVendor`, inputs).then(onSuccess).catch(onFail);
};

export const apiAddClientPreferredVendorOutsideTCE = (inputs, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/client-preferred-vendor/addClientPreferredVendorOutsideTCE`, inputs).then(onSuccess).catch(onFail);
};

export const apiDeletePreferredVendor = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/client-preferred-vendor/deletePreferredVendor`, inputs).then(onSuccess).catch(onFail);
};

export const apiDeleteAllClientPreferredVendor = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/client-preferred-vendor/deleteAllClientPreferredVendor`, inputs).then(onSuccess).catch(onFail);
};

export const apiGetClientBranchDropDown = (onSuccess, onFail) => {
  return axiosGet(`${API_URL}/client/getClientBranchDropDown`).then(onSuccess).catch(onFail);
};

export const apiCheckExistsClientPreferredVendor = (inputs, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/client-preferred-vendor/isExistsClientPreferred`, inputs).then(onSuccess).catch(onFail);
};