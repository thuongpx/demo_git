import { API_URL } from "Config/config";
import { axiosGet } from "Helpers/axios-helper";

export const apiGetAllCarrierForDropDown = (onSuccess, onFail) => {
    return axiosGet(`${API_URL}/carrier/getAllCarriersForDropDown`).then(onSuccess).catch(onFail);
};
