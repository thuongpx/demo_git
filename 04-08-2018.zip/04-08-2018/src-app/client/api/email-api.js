import { API_URL } from "Config/config";
import { axiosPost } from "Helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";

export const apiSendMail = (mailObj, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/mail/sendMail`, trimObject(mailObj)).then(onSuccess).catch(onFail);
};

export const apiSendMailToVendorCommunication = (data, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/mail/sendEmailToVendorCommunication`, data).then(onSuccess).catch(onFail);
};

export const apiSendSmsToVendorCommunication = (data, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/sms/sendSmsToVendorCommunication`, data).then(onSuccess).catch(onFail);
};

export const apiSendEmailToTCECommunication = (data, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/mail/sendEmailToTCECommunication`, data).then(onSuccess).catch(onFail);
};

export const apiSendEmailToClientCommunication = (data, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/mail/sendEmailToClientCommunication`, data).then(onSuccess).catch(onFail);
};

export const apiSendCloseSuccessfully = (data, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/mail/sendSendCloseSuccessfully`, data).then(onSuccess).catch(onFail);
};

export const apiSendCloseUnuccessfully = (data, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/mail/sendSendCloseUnsuccessfully`, data).then(onSuccess).catch(onFail);
};