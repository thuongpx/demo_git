import { API_URL } from "Config/config";
import { axiosGet, axiosPut } from "Helpers/axios-helper";

export const apiGetRolesAndPermissions = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/rolePermission/getRolePermissions`).then(onSuccess).catch(onError);
};

export const apiUpdateRolePermissions = (inputs, roleType, onSuccess, onError) => {
    return axiosPut(`${API_URL}/rolePermission/updateRolePermissions`, {
        data: inputs,
        roleType
    }).then(onSuccess).catch(onError);
};

export const apiGetConsoleStaffUser = (data, onSuccess, onError) => {
    return axiosGet(`${API_URL}/rolePermission/getConsoleStaffUser`, data).then(onSuccess).catch(onError);
};

export const apiGetRolesPermissions = (roleType, onSuccess, onError) => {
    return axiosGet(`${API_URL}/rolesPermissions/getRolesPermissions`, { roleType }, null).then(onSuccess).catch(onError);
};

