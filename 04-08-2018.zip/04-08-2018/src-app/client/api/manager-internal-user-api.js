import { API_URL } from "Config/config";
import { trimObject } from "Helpers/common-helper";
import { axiosGet, axiosPost } from "../helpers/axios-helper";

export const apiGetAllManagerInternalUser = (criteria, onSuccess, onError) => {

    return axiosGet(`${API_URL}/managerinternaluser/getAllManagerInternalUser`, trimObject(criteria))
        .then(onSuccess)
        .catch(onError);
};

export const apiDeleteManagerInternalUser = (RepId, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/managerinternaluser/deleteManagerInternalUser`, { RepId })
        .then(onSuccess)
        .catch(onFail);
};

export const apiGetManagerInternalUser = (input, successCb, failCb) => {
    return axiosGet(`${API_URL}/managerinternaluser/getManagerInternalUser`, input, false)
        .then(successCb)
        .catch(failCb);
};

export const apiGetUsersByRepId = (repId, successCb, failCb) => {
    return axiosGet(`${API_URL}/managerinternaluser/getUsersByRepId`, { repId }, false)
        .then(successCb)
        .catch(failCb);
};

export const apiGetRoleName = (successCb, failCb) => {
    return axiosGet(`${API_URL}/managerinternaluser/getRoleName`, false)
        .then(successCb)
        .catch(failCb);
};

export const apiCheckExistUser = (username, onSuccess, onError) => {
    return axiosGet(`${API_URL}/user/checkExistUser`, { username }, true).then(onSuccess).catch(onError);
};

export const apiAddUser = (input, onSuccess, onError) => {
    return axiosPost(`${API_URL}/managerinternaluser/addManagerInternalUser`, input, false).then(onSuccess).catch(onError);
};

export const apiUpdateUser = (input, onSuccess, onError) => {
    return axiosPost(`${API_URL}/managerinternaluser/updateEmployees`, input, false).then(onSuccess).catch(onError);
};

export const apiUpdateActive = (input, onSuccess, onError) => {
    return axiosPost(`${API_URL}/managerinternaluser/updateActive`, input, false).then(onSuccess).catch(onError);
};

export const apiGetUserIdByRepId = (repId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/managerinternaluser/getUserIdByRepId`, { repId }, false).then(onSuccess).catch(onError);
};
