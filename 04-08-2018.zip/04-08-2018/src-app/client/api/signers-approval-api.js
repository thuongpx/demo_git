import {
  API_URL
} from "Config/config";
import {
  axiosPost,
  axiosGet
} from "Helpers/axios-helper";
import {
  trimObject
} from "Helpers/common-helper";

export const apiGetSignersApproval = (conditions, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/staffApprovalManagement/getSignersApproval`, conditions).then(onSuccess).catch(onFail);
};

export const apiUpdateSignerApproval = (approvalData, onSuccess, onFail) => {
  axiosPost(`${API_URL}/staffApprovalManagement/updateSignerApproval`, trimObject(approvalData)).then(onSuccess).catch(onFail);
};

export const apiCheckValidApproval = (checkData, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/staffApprovalManagement/isUpdatableSignerApproval`, checkData).then(onSuccess).catch(onFail);
};

export const apiGetSignersApprovalByBrokerId = (conditions, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/staffApprovalManagement/getSignersApprovalByBrokerId`, conditions).then(onSuccess).catch(onFail);
};

export const apiGetSignersApprovalById = (criteria, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/staffApprovalManagement/getSignersApprovalById`, criteria).then(onSuccess).catch(onFail);
};

export const apiUpdateVendorApprovalRequest = (signerApproval, onSuccess, onFail) => {
  axiosPost(`${API_URL}/staffApprovalManagement/updateVendorApprovalRequest`, trimObject(signerApproval)).then(onSuccess).catch(onFail);
};

export const apiAddSignerApprovalAndComments = (data, onSuccess, onFail) => {
  axiosPost(`${API_URL}/staffApprovalManagement/addSignerApprovalAndComments`, data).then(onSuccess).catch(onFail);
};

export const apiAddSignerApproval = (signerApproval, onSuccess, onFail) => {
  axiosPost(`${API_URL}/staffApprovalManagement/addSignerApproval`, trimObject(signerApproval)).then(onSuccess).catch(onFail);
};

export const apiGetSignersApprovalBySignerId = (signerId, orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/staffApprovalManagement/getSignersApprovalBySignerId`, {
    signerId,
    orderId
  }).then(onSuccess).catch(onFail);
};
