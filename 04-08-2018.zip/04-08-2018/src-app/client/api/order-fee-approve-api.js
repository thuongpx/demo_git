import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "Helpers/axios-helper";

export const apiGetOrdersFeeApproveData = (criteria, searchValues, onSuccess, onError) => {
    return axiosGet(`${API_URL}/order/getOrdersFeeApproveData`, { ...criteria, ...searchValues }).then(onSuccess).catch(onError);
};

export const apiGetOrderFeeCommentsByOwnerId = (data, onSuccess, onError) => {
    return axiosPost(`${API_URL}/order/changeOrderFeeApproveStatus`, { ...data }).then(onSuccess).catch(onError);
};

export const apiGetOrdersFeeApprovalRequest = (criteria, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/order/getOrdersFeeApprovalRequest`, criteria).then(onSuccess).catch(onFail);
};

export const apiGetOrdersFeeApprovalDetails = (approvalId, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/order/getOrdersFeeApprovalDetails?approvalId=${approvalId}`).then(onSuccess).catch(onFail);
};

export const apiUpdateOrdersFeeApprove = (approval, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/order/updateOrdersFeeApprove`, { approval }).then(onSuccess).catch(onFail);
};

export const apiGetOrderFeeApprovalReasonStaff = (onSuccess, onFail) => {
    return axiosGet(`${API_URL}/orderRequestApproval/getOrderFeeApprovalReasonStaff`).then(onSuccess).catch(onFail);
};

export const apiFeeRequestSendEmailToManager = (mailData, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/orderRequestApproval/sendEmailFeeRequestToTceManager`, mailData).then(onSuccess).catch(onFail);
};