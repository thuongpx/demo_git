import { API_URL } from "Config/config";
import { axiosGet } from "Helpers/axios-helper";

export const apiGetFeeRequestReason = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/fee/getFeeRequestReason`, null).then(onSuccess).catch(onError);
};

export const apiGetFeeRequest = (criteria, searchValues, onSuccess, onError) => {
    return axiosGet(`${API_URL}/feeRequest/getFeeRequest`, { ...criteria, ...searchValues }).then(onSuccess).catch(onError);
};