import {
    axiosGet,
    axiosPost
} from "Helpers/axios-helper";
import {
    API_URL
} from "Config/config";
import {
    trimObject
} from "Helpers/common-helper";

export const apiUpdateBusinessHours = (businessHours, onSuccess, onError) => {
    return axiosPost(`${API_URL}/business-hours/updateBusinessHours`, trimObject(businessHours)).then(onSuccess).catch(onError);
};

export const apiGetBusinessHours = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/business-hours/getBusinessHours`, null).then(onSuccess).catch(onError);
};

export const apiGetBizHoursExcept = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/biz-hours-except/getBizHoursExcept`, trimObject(criteria)).then(onSuccess).catch(onError);
};

export const addBizHoursExcept = (bizHoursExcept, onSuccess, onError) => {
    return axiosPost(`${API_URL}/biz-hours-except/addBizHoursExcept`, trimObject(bizHoursExcept)).then(onSuccess).catch(onError);
};

export const apiDeleteBizHoursExcept = (exceptId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/biz-hours-except/deleteBizHoursExcept`, { exceptId }).then(onSuccess).catch(onError);
};

