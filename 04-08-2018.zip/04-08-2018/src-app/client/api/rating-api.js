import {
  axiosGet
} from "Helpers/axios-helper";
import {
  API_URL
} from "Config/config";

export const apiGetRatings = (onSuccess, onError) => {
  return axiosGet(`${API_URL}/rating/getRatings`, null).then(onSuccess).catch(onError);
};
