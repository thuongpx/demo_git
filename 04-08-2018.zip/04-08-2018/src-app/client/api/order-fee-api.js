import { API_URL } from "Config/config";
import { axiosPost, axiosGet } from "Helpers/axios-helper";

export const apiGetOrdersFeeData = (orderId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/order/getOrdersFeeData`, { orderId }).then(onSuccess).catch(onError);
};

export const apiDeleteOrderFee = (feeId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/order/deleteOrderFee`, { feeId }).then(onSuccess).catch(onError);
};

export const apiGetOrderFee = (orderId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/order/getOrderFee`, { orderId }).then(onSuccess).catch(onError);
};

export const apiAddOrderFee = (fee, onSuccess, onError) => {
    return axiosPost(`${API_URL}/order/addOrderFee`, fee).then(onSuccess).catch(onError);
};

export const apiAddNewRequestFee = (fee, onSuccess, onError) => {
    return axiosPost(`${API_URL}/order/addOrderRequestedFee`, fee).then(onSuccess).catch(onError);
};

export const apiGetOrderRequestedFee = (orderId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/order/getOrderRequestedFee`, { orderId }).then(onSuccess).catch(onError);
};

export const apiUpdateRequestFee = (fee, onSuccess, onError) => {
    return axiosPost(`${API_URL}/order/updateOrderRequestedFee`, fee).then(onSuccess).catch(onError);
};

export const apiProcessRequestFee = (fee, onSuccess, onError) => {
    return axiosPost(`${API_URL}/order/processRequestFee`, fee).then(onSuccess).catch(onError);
};
