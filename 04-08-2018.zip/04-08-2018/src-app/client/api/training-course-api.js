import { API_URL } from "Config/config";
import { axiosPost, axiosGet } from "Helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";

export const apiGetCourses = (criteria, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/training-courses/getCourses`, trimObject(criteria)).then(onSuccess).catch(onFail);
};

export const apiGetCourseById = (courseId, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/training-courses/getCourseById?courseId=${courseId}`).then(onSuccess).catch(onFail);
};

export const apiAddCourse = (courseModel, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/training-courses/addCourse`, trimObject(courseModel)).then(onSuccess).catch(onFail);
};

export const apiUpdateCourse = (courseModel, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/training-courses/updateCourse`, trimObject(courseModel)).then(onSuccess).catch(onFail);
};

export const apiDeleteCourse = (courseId, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/training-courses/deleteCourse`, { courseId }, false).then(onSuccess).catch(onFail);
};

export const apiChangeStatusCourse = (courseId, isActive, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/training-courses/changeStatusCourse`, { courseId, isActive }, false).then(onSuccess).catch(onFail);
};

export const apiCheckExistCourseName = (courseName, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/training-courses/checkExistCourseName`, { courseName }, false).then(onSuccess).catch(onFail);
};