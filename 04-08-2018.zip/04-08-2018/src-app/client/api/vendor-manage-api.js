import { axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";
import { trimObject } from "Helpers/common-helper";

export const apiGetOrdersVendorList = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendorManage/getOrdersVendorList`, { criteria: trimObject(criteria) }
    ).then(onSuccess).catch(onError);
};

export const apiCheckClientSatisfiedVendor = (orderId, signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendorManage/checkClientSatisfiedVendor`, { orderId, signerId }).then(onSuccess).catch(onError);
};

export const apiGetDefaultVendorSearch = (orderId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendorManage/getDefaultVendorSearch`, { orderId }).then(onSuccess).catch(onError);
};

export const apiCheckVendorPassedExam = (vendorId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendorManage/checkVendorPassedExam`, { vendorId }).then(onSuccess).catch(onError);
};
