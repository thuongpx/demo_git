import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "../helpers/axios-helper";


export const apiGetCredentialDocument = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/credential-document/getCredentialDocument`, criteria, false).then(onSuccess).catch(onError);
};

export const apiCredentialDocumentExist = (docType, onSuccess, onError) => {
    return axiosGet(`${API_URL}/credential-document/checkExistCredentialDocument`, { docType }, false).then(onSuccess).catch(onError);
};

export const apiFileNameExist = (fileName, onSuccess, onError) => {
    return axiosGet(`${API_URL}/credential-document/checkExistFileName`, { fileName }, false).then(onSuccess).catch(onError);
};

export const apiDeleteCredentialDocument = (docTypeID, onSuccess, onError) => {
    return axiosPost(`${API_URL}/credential-document/deleteCredentialDocument`, { docTypeID }).then(onSuccess).catch(onError);
};

export const apiAddCredentialDocument = (input, onSuccess, onError) => {
    return axiosPost(`${API_URL}/credential-document/addCredentialDocument`, input).then(onSuccess).catch(onError);
};

export const apiUpdateCredentialDocument = (input, onSuccess, onError) => {
    return axiosPost(`${API_URL}/credential-document/updateCredentialDocument`, input).then(onSuccess).catch(onError);
};