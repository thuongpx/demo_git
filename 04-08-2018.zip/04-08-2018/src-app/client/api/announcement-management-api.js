import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "../helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";

export const apiGetAnnouncements = (criteria, onSuccess, onError) => {

    return axiosGet(`${API_URL}/manageNotification/getAnnoucements`, criteria, false)
        .then(onSuccess)
        .catch(onError);
};
export const apiGetLoanAndStates = (onSuccess, onError) => {

    return axiosGet(`${API_URL}/manageNotification/getAllLoanTypeAndState`, false)
        .then(onSuccess)
        .catch(onError);
};

export const apigetAnnouncementInfo = (announcementID, onSuccess, onError) => {
    return axiosGet(`${API_URL}/manageNotification/getAnnouncementInfo`, { announcementID }, false)
        .then(onSuccess)
        .catch(onError);
};


export const apiAddNewAnnouncement = (payload, onSuccess, onError) => {
    return axiosPost(`${API_URL}/manageNotification/addNewAnnouncement`, trimObject(payload), false).then(onSuccess).catch(onError);
};

export const apiUpdateAnnouncement = (payload, onSuccess, onError) => {
    return axiosPost(`${API_URL}/manageNotification/updateAnnouncement`, trimObject(payload), false).then(onSuccess).catch(onError);
};

export const apiUpdateAnnouncementStatus = (payload, onSuccess, onError) => {
    return axiosPost(`${API_URL}/manageNotification/updateAnnouncementStatus`, payload, false).then(onSuccess).catch(onError);
};

export const apiDeleteAnnouncement = (announcementID, onSuccess, onError) => {
    return axiosGet(`${API_URL}/manageNotification/deleteAnnouncement`, { announcementID }, false)
        .then(onSuccess)
        .catch(onError);
};
