import { axiosPost, axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiLoginUser = (creds, successCb, failCb) => {
    const data = {
        username: creds.username,
        password: creds.password,
        GUID: creds.GUID,
        userId: creds.userId,
        tempToken: creds.tempToken,
        supervisor: creds.supervisor,
        isLoginAsAnotherUser: creds.isLoginAsAnotherUser
    };

    return axiosPost(`${API_URL}/authorize`, data, true).then(successCb).catch(failCb);
};

export const apiGetProfilePicture = (accountId, successCb, failCb) => {

    return axiosGet(`${API_URL}/getProfilePicture`, { accountId }, false).then(successCb).catch(failCb);
};

export const apiLoginAsAnotherUser = (creds, successCb, failCb) => {
    return axiosPost(`${API_URL}/auth/loginAsAnotherUser`, creds, false).then(successCb).catch(failCb);
};

export const createAccount = (inputs, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/createAccount`, inputs).then(onSuccess).catch(onFail);
};