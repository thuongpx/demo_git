import { axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetLanguages = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/language/getLanguages`, null, true).then(onSuccess).catch(onError);
};
