import {
  axiosPost,
  axiosGet
} from "Helpers/axios-helper";
import {
  API_URL
} from "Config/config";


export const apiGetBonusCalculationDataData = (successCb, failCb) => {
  return axiosGet(`${API_URL}/bonus/getBonusCalculationData`, false).then(successCb).catch(failCb);
};

export const apiUpdateBonusCalculationData = (data, onSuccess, onError) => {
  return axiosPost(`${API_URL}/bonus/updateBonusCalculationData`, data).then(onSuccess).catch(onError);
};
