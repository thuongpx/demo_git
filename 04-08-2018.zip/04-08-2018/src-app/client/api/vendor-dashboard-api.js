import { axiosGet, axiosPost } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetDataVendorDashboard = (signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-dashboard/getDataVendorDashboard`, { signerId }, false).then(onSuccess).catch(onError);
};

export const apiDeactivateVendor = (signerId, accountId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/vendor-dashboard/deactivateVendor`, { signerId, accountId }, false).then(onSuccess).catch(onError);
};

export const apiGetDocumentExpireBySignerId = (signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-dashboard/getDocumentExpireBySignerId`, { signerId }, false).then(onSuccess).catch(onError);
};
