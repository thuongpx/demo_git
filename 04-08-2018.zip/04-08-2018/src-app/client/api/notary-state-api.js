import {
  axiosGet
} from "Helpers/axios-helper";
import {
  API_URL
} from "Config/config";

export const apiGetDualStatesBySignerId = (signerId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/notary-state/getDualStatesBySignerId`, { signerId }).then(onSuccess).catch(onError);
};
