import { API_URL } from "Config/config";
import { axiosGet } from "Helpers/axios-helper";
import { axiosPost } from "../helpers/axios-helper";

export const apiGetAdminByBrokerId = (brokerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/broker/getBrokerAdminById`, { brokerId }).then(onSuccess).catch(onError);
};

export const apiGetBranchByBrokerId = (identify, onSuccess, onError) => {
    return axiosGet(`${API_URL}/broker/getBrokerBranchById`, identify).then(onSuccess).catch(onError);
};

export const apiGetAllBrokers = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/broker/getAllBrokers`).then(onSuccess).catch(onError);
};

export const apiGetApprovalRequestNumber = (data, onSuccess, onError) => {
    return axiosGet(`${API_URL}/broker/getApprovalRequestNumber`, data).then(onSuccess).catch(onError);
};

export const apiGetInitDataForClientOrderAssignConfig = (inputs, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/broker/getInitDataForClientOrderAssignConfig`, inputs).then(onSuccess).catch(onFail);
};

export const apiGetlistClientPreferred = (inputs, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/broker/getlistClientPreferred`, inputs).then(onSuccess).catch(onFail);
};

export const apiGetClientOrderAssignConfigLog = (inputs, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/broker/getClientOrderAssignConfigLog`, inputs).then(onSuccess).catch(onFail);
};

export const apiSaveClientOrderAssignConfig = (inputs, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/broker/saveClientOrderAssignConfig`, inputs).then(onSuccess).catch(onFail);
};

export const apiGetListClientAdmin = (onSuccess, onFail) => {
    return axiosGet(`${API_URL}/broker/getListClientAdmin`).then(onSuccess).catch(onFail);
};

export const apiGetBrokerDataById = (inputs, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/broker/getBrokerDataById`, inputs).then(onSuccess).catch(onFail);
};

export const apiGetHybridQuestionData = (inputs, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/client/getHybridQuestionData`, inputs).then(onSuccess).catch(onFail);
};

export const apiSendMailUpdateInfoClient = (inputs, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/client/sendMailUpdateInfoClient`, inputs).then(onSuccess).catch(onFail);
};

export const apiSendInvite = (inputs, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/broker/sendInvite`, inputs).then(onSuccess).catch(onFail);
};