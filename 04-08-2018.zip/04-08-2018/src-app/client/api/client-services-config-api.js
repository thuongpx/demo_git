import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "../helpers/axios-helper";

export const apiGetClientServicesConfigData = (data, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/client-services-config/getClientServicesConfigData`, data, false).then(onSuccess).catch(onFail);
};

export const apiHasPendingServicesConfig = (createdBy, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/client-services-config/hasPendingServicesConfig`, { createdBy }, false).then(onSuccess).catch(onFail);
};

export const apiAddClientServicesConfig = (servicesConfig, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/client-services-config/addServicesConfig`, servicesConfig, false).then(onSuccess).catch(onFail);
};

export const apiUpdateClientServicesConfig = (servicesConfig, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/client-services-config/updateServicesConfig`, servicesConfig, false).then(onSuccess).catch(onFail);
};

export const apiGetListServiceConfig = (inputs, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/client-services-config/getListServiceConfig`, inputs).then(onSuccess).catch(onFail);
};

export const apiGetServiceConfigChange = (inputs, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/client-services-config/getServiceConfigChange`, inputs).then(onSuccess).catch(onFail);
};

export const apiApprovalServiceConfig = (data, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/client-services-config/approvalServiceConfig`, data).then(onSuccess).catch(onFail);
};