import { axiosGet, axiosPost } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetIssuesReporting = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/issueReporting/getIssuesReporting`, criteria, false).then(onSuccess).catch(onError);
};

export const apiGetIssueByIdReporting = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/issueReporting/getIssuesReportingById`, criteria, false).then(onSuccess).catch(onError);
};


export const apiUpdateIssueReporting = (input, onSuccess, onError) => {
    return axiosPost(`${API_URL}/issueReporting/updateIssueReporting`, { input }, false).then(onSuccess).catch(onError);
};

