import {
    axiosGet,
    axiosPost,
    axiosDownload
} from "Helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";
import {
    API_URL
} from "Config/config";

export const apiGetListRegisteredPrograms = (userId, searchValue, onSuccess, onError) => {
    return axiosGet(`${API_URL}/notarytraning/getListRegisteredPrograms`, {
        userId,
        searchValue
    }).then(onSuccess).catch(onError);
};

export const apiGetListLearningPath = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-notary-training-controller/getListLearningPath`).then(onSuccess).catch(onError);
};

export const apiGetListOfPopularPrograms = (signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-notary-training-controller/getListPopularProgram`, { signerId }).then(onSuccess).catch(onError);
};

export const apiGetListRecentCourses = (signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-notary-training-controller/getListRecentCourses`, {
        signerId
    }).then(onSuccess).catch(onError);
};

export const apiRegisterProram = (signerId, programId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/vendor-notary-training-controller/registerPopularProgram`, {
        signerId,
        programId
    }).then(onSuccess).catch(onError);
};

export const apiGetAllProgram = (userId, searchValue, onSuccess, onError) => {
    return axiosGet(`${API_URL}/notarytraning/getListAllPrograms`, {
        userId,
        searchValue
    }).then(onSuccess).catch(onError);
};

export const apiGetaRegisteredProgram = (program, userId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/notarytraning/getCurrentRegisteredPrograms`, {
        program,
        userId
    }).then(onSuccess).catch(onError);
};

export const apiGetCoursesandTestsbyProgramId = (programId, signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/notarytraning/getCourseAndTestByProgramId`, {
        programId,
        signerId
    }).then(onSuccess).catch(onError);
};

export const apiGetCourseOfCurrentProgram = (ProgramId, CourseId, signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-training-controller/getCourseOfCurrentProgram`, {
        ProgramId,
        CourseId,
        signerId
    }).then(onSuccess).catch(onError);
};

export const apiDownloadCourseDocs = (input, fileName, onSuccess, onError) => {
    return axiosDownload(`${API_URL}/vendor-training-controller/downloadDoc`, input, fileName).then(onSuccess).catch(onError);
};

export const apiAddVendorCoursesResult = (course, onSuccess, onError) => {
    return axiosPost(`${API_URL}/vendor-training-controller/addVendorCoursesResult`, trimObject(course)).then(onSuccess).catch(onError);
};

export const apiUpdateCourse = (CourseId, ViewsCount, onSuccess, onError) => {
    return axiosPost(`${API_URL}/vendor-training-controller/updateCourse`, {
        CourseId,
        ViewsCount
    }).then(onSuccess).catch(onError);
};