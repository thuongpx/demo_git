import { axiosGet, axiosPost } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetVendorClassificationsSetting = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/vendor-classifications/getVendorClassificationsSetting`, false).then(onSuccess).catch(onError);
};

export const apiAddVendorClassifications = (catColorName, onSuccess, onError) => {
    return axiosPost(`${API_URL}/vendor-classifications/addVendorCategoryClassifications`, catColorName, false).then(onSuccess).catch(onError);
};

export const apiDeleteVendorClassifications = (catId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/vendor-classifications/deleteVendorCategory`, { catId }, false).then(onSuccess).catch(onError);
};

export const apiUpdateVendorCategory = (vendorCategory, onSuccess, onError) => {
    return axiosPost(`${API_URL}/vendor-classifications/updateVendorCategory`, vendorCategory, false).then(onSuccess).catch(onError);
};

export const apiUpdateVendorClassifications = (vendorCategory, onSuccess, onError) => {
    return axiosPost(`${API_URL}/vendor-classifications/updateVendorClassifications`, vendorCategory, false).then(onSuccess).catch(onError);
};

export const apiCheckExistCatName = (CatName, onSuccess, onError) => {
    return axiosPost(`${API_URL}/vendor-classifications/checkExistCatName`, { CatName }, false).then(onSuccess).catch(onError);
};

export const apigetAllColor = (onSuccess, onError) => {
    return axiosPost(`${API_URL}/vendor-classifications/vendor-classifications/getAllColor`, false).then(onSuccess).catch(onError);
};
//
export const apiResetVendorCategory = (onSuccess, onError) => {
    return axiosPost(`${API_URL}/vendor-classifications/resetVendorCategory`, false).then(onSuccess).catch(onError);
};