import { API_URL } from "Config/config";
import { axiosPost } from "Helpers/axios-helper";

export const apiRequestPaymentToken = (payload, onSuccess, onError) => {
    return axiosPost(`${API_URL}/payment/requestPaymentToken`, payload).then(onSuccess).catch(onError);
};

export const apiUpdateOrderSpecificsData = (data, onSuccess, onError) => {
    return axiosPost(`${API_URL}/order/updateOrderSpecific`, data).then(onSuccess).catch(onError);
};

export const apiRemovePaymentMethod = (paymentId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/payment/removePaymentMethod`, paymentId).then(onSuccess).catch(onError);
};