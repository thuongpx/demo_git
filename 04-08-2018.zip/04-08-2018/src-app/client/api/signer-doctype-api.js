import { axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetDocTypeBySignerId = (signerId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/signerDocType/getDocTypeBySignerId`, { signerId }, false).then(onSuccess).catch(onError);
};
