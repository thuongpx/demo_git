import { axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetStates = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/state/getAllState`, null, true).then(onSuccess).catch(onError);
};
