import { API_URL } from "Config/config";
import { axiosPost, axiosGet } from "Helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";

export const apiApproveFeeRequest = (approvalData, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/orderRequestApproval/approveFeeRequest`, trimObject(approvalData)).then(onSuccess).catch(onFail);
};

export const apiCheckVendorAssignConditionsOfOrder = (checkData, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/orderRequestApproval/checkVendorAssignConditionsOfOrder`, checkData).then(onSuccess).catch(onFail);
};

export const apiSubmitFeeRequestToMgr = (approvalData, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/orderRequestApproval/submitFeeRequestToMgr`, trimObject(approvalData)).then(onSuccess).catch(onFail);
};

export const apiSubmitFeeRequestToMgrSendMail = (mailData, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/orderRequestApproval/sendMailWhenSubmitToManager`, mailData).then(onSuccess).catch(onFail);
};

export const apiProcessClientFeeRequest = (approvalData, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/orderRequestApproval/processClientFeeRequest`, trimObject(approvalData)).then(onSuccess).catch(onFail);
};