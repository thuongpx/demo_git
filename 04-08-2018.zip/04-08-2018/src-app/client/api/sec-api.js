import { axiosGet, axiosPost } from "Helpers/axios-helper";
import { API_URL } from "Config/config";
import { trimObject } from "Helpers/common-helper";

export const apiGetSecQuestionsForDropdown = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/sec/getSecQuestionsForDropdown`, false, true).then(onSuccess).catch(onError);
};

export const apiGetSecQuestionsOfUser = (userId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/sec/getSecQuestionsOfUser`, { userId }).then(onSuccess).catch(onError);
};

export const apiAddSecAnswer = (secAnswer, onSuccess, onFail) => {
    axiosPost(`${API_URL}/sec/addSecAnswer`, trimObject(secAnswer)).then(onSuccess).catch(onFail);
};

export const apiDeleteSecAnswers = (username, onSuccess, onError) => {
    return axiosGet(`${API_URL}/sec/deleteSecAnswers?username=${username}`, false).then(onSuccess).catch(onError);
};

export const apiUpdateSecQuestionAnswers = (secAnswer, onSuccess, onFail) => {
    axiosPost(`${API_URL}/sec/updateSecAnswers`, trimObject(secAnswer)).then(onSuccess).catch(onFail);
};

export const apiCheckUserAnswer = (answer, onSuccess, onFail) => {
    axiosPost(`${API_URL}/sec/checkUserAnswer`, trimObject(answer)).then(onSuccess).catch(onFail);
};

export const apiGetUserSecQuestion = (userId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/sec/getUserSecQuestion`, { userId }).then(onSuccess).catch(onError);
};

export const apiCheckUserSecAnswer = (userId, secAnswer, onSuccess, onFail) => {
    axiosPost(`${API_URL}/sec/checkUserSecAnswer`, trimObject({ userId, secAnswer })).then(onSuccess).catch(onFail);
};
