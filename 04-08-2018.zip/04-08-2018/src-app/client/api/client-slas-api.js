import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "../helpers/axios-helper";

export const apiGetClientSlasById = (id, roleType, onSuccess, onFail) => {

    return axiosGet(`${API_URL}/client-slas/getClientSlasById`, { id, roleType }, false).then(onSuccess).catch(onFail);
};

export const apiUpdateClientSlasById = (listClientSlasNew, roleType, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/client-slas/updateClientSlasById`, { listClientSlasNew, roleType }, false).then(onSuccess).catch(onFail);
};