import {
  axiosPost,
  axiosGet
} from "Helpers/axios-helper";
import {
  API_URL
} from "Config/config";
import {
  trimObject
} from "Helpers/common-helper";

export const apiGetUserAddress = (signerId, tenantId, onSuccess, onFail) => {
  axiosGet(`${API_URL}/signer/getUserAddress`, {
    signerId,
    tenantId
  }).then(onSuccess).catch(onFail);
};

export const apiGetLoanTypes = (onSuccess, onFail) => {
  return axiosGet(`${API_URL}/loan-type/getLoanTypes`).then(onSuccess).catch(onFail);
};

export const apiGetAreas = (onSuccess, onFail) => {
  return axiosGet(`${API_URL}/area/getAreas`).then(onSuccess).catch(onFail);
};

export const apiAddSigner = (signer, onSuccess, onFail) => {
  axiosPost(`${API_URL}/signer/addSigner`, trimObject(signer)).then(onSuccess).catch(onFail);
};

export const apiUpdateSigner = (signer, onSuccess, onFail) => {
  axiosPost(`${API_URL}/signer/updateSigner`, trimObject(signer)).then(onSuccess).catch(onFail);
};

export const apiGetSignerById = (signerId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/signer/getSignerById`, {
    signerId
  }).then(onSuccess).catch(onError);
};

export const apiGetSignerLocationDataById = (signerId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/signer/getSignerLocationDataById`, {
    signerId
  }, false).then(onSuccess).catch(onError);
};

export const apiGetSignerPhoneDataById = (signerId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/signer/getSignerPhoneDataById`, {
    signerId
  }, false).then(onSuccess).catch(onError);
};

export const apiGetUserAddressPending = (signerId, onSuccess, onFail) => {
  axiosGet(`${API_URL}/signer/getUserAddressPending`, {
    signerId
  }).then(onSuccess).catch(onFail);
};

export const apiUpdateUserAddressPending = (userAddressPending, onSuccess, onFail) => {
  axiosPost(`${API_URL}/signer/updateUserAddressPending`, trimObject(userAddressPending), false).then(onSuccess).catch(onFail);
};

export const apiGetInitSignerQuestionaires = (signerId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/signer/getInitSignerQuestionaires`, {
    signerId
  }, false)
    .then(onSuccess)
    .catch(onError);
};

export const apiGetUserAdditionalInfo = (signerId, tenantId, onSuccess, onFail) => {
  axiosGet(`${API_URL}/signer/getUserAdditionalInfo`, {
    signerId,
    tenantId
  }).then(onSuccess).catch(onFail);
};

export const apiUpdateUserAdditionalInfo = (userAdditionalInfo, onSuccess, onFail) => {
  axiosPost(`${API_URL}/signer/updateUserAdditionalInfo`, trimObject(userAdditionalInfo), false).then(onSuccess).catch(onFail);
};

export const getSignerServiceDataById = (signerId, onSuccess, onFail) => {
  axiosGet(`${API_URL}/signer/getSignerServiceDataById`, {
    signerId
  }).then(onSuccess).catch(onFail);
};

export const apiGetUserAdditionalInfoList = (signerId, onSuccess, onFail) => {
  axiosGet(`${API_URL}/signer/getUserAdditionalInfoList`, {
    signerId
  }).then(onSuccess).catch(onFail);
};

export const apiSaveSignerProfilePicture = (signer, onSuccess, onFail) => {
  console.log(signer);
  axiosPost(`${API_URL}/signer/saveSignerProfilePicture`, signer).then(onSuccess).catch(onFail);
};

export const apiSendMail = (mailData, onSuccess, onFail) => {
  axiosPost(`${API_URL}/email/sendMail`, mailData).then(onSuccess).catch(onFail);
};
export const apiUpdateQuestionnaires = (signer, languages, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/signer/updateQuestionnaires`, trimObject({
    signer,
    languages
  }))
    .then(onSuccess)
    .catch(onFail);
};
export const apiGetSignerFullNameById = (signerId, onSuccess, onFail) => {
  axiosGet(`${API_URL}/signer/getSignerFullNameById`, {
    signerId
  }).then(onSuccess).catch(onFail);
};

export const apiGetSignerUserNameById = (signerIds, onSuccess, onFail) => {
  axiosGet(`${API_URL}/signer/getSignerUserNameById`, {
    signerIds
  }).then(onSuccess).catch(onFail);
};

export const apiGetTotalOpenOfferOfSigner = (signerId, onSuccess, onFail) => {
  axiosGet(`${API_URL}/signer/getTotalOpenOfferOfSigner`, {
    signerId
  }).then(onSuccess).catch(onFail);
};

export const aptGetStaffVendors = (data, onSuccess, onFail) => {
  axiosPost(`${API_URL}/signer/getStaffVendors`, trimObject(data)).then(onSuccess).catch(onFail);
};

export const apiGetIsVendorRegistrationDone = (signerId, onSuccess, onFail) => {
  axiosGet(`${API_URL}/signer/getIsVendorRegistrationDone`, {
    signerId
  }).then(onSuccess).catch(onFail);
};

export const apiGetVendorManagement = (input, onSuccess, onError) => {

  return axiosGet(`${API_URL}/signer/getAllVendorManagement`, input, false)
    .then(onSuccess)
    .catch(onError);
};

export const apiActiveVendor = (vendorID, onSuccess, onError) => {

  return axiosPost(`${API_URL}/signer/activeVendor`, {
    vendorID
  }, false)
    .then(onSuccess)
    .catch(onError);
};


export const apiDeactivateVendor = (data, onSuccess, onError) => {
  return axiosPost(`${API_URL}/signer/deactivateVendor`, trimObject(data), false)
    .then(onSuccess)
    .catch(onError);
};

export const apiCheckSignerAssignedOpenOrder = (signerId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/signer/checkSignerAssignedOpenOrder`, {
    signerId
  }, false)
    .then(onSuccess)
    .catch(onError);
};

export const apiAddVendor = (data, listSignerNote, onSuccess, onError) => {
  return axiosPost(`${API_URL}/signer/addVendor`, trimObject({
    data,
    listSignerNote
  }))
    .then(onSuccess)
    .catch(onError);
};

export const apiGetRightPanelAllDocsData = (orderId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/signer/getAllDataDocs`, {
    orderId
  }, false)
    .then(onSuccess)
    .catch(onError);
};

export const apiConfirmDocs = (data, success, fail) => {
  return axiosPost(`${API_URL}/signer/confirmDocs`, data).then(success).catch(fail);
};

export const apiGetAppointmentDetailsData = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/signer/getAppointmentDetailsData`, {
    orderId
  }).then(onSuccess).catch(onFail);
};
export const apiUpdateAppointment = (data, success, fail) => {
  return axiosPost(`${API_URL}/signer/updateAppointment`, data).then(success).catch(fail);
};

export const apiResetVendorPassword = (signerId, onSuccess, onError) => {
  return axiosPost(`${API_URL}/signer/resetVendorPassword`, {
    signerId
  })
    .then(onSuccess)
    .catch(onError);
};

export const apiConfirmAppointment = (data, success, fail) => {
  return axiosPost(`${API_URL}/signer/confirmAppointment`, data).then(success).catch(fail);
};

export const apiGetSignerBasicInformation = (signerId, onSuccess, onError) => {
  return axiosPost(`${API_URL}/signer/getSignerBasicInformation`, {
    signerId
  })
    .then(onSuccess)
    .catch(onError);
};

export const apiSigningAndPropertyAddressData = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/signer/getSigningAndPropertyAddressData`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

export const apigetShippingInfoData = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/signer/getShippingInfoData`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

export const apiUpdateSignerBasicInformation = (data, onSuccess, onError) => {
  return axiosPost(`${API_URL}/signer/updateSignerBasicInformation`, trimObject(data))
    .then(onSuccess)
    .catch(onError);
};

export const apiRevalidateAuthentication = (signerId, onSuccess, onError) => {
  return axiosPost(`${API_URL}/signer/revalidateAuthentication`, {
    signerId
  })
    .then(onSuccess)
    .catch(onError);
};

export const apiUpdateSignerAdditionalInformation = (data, onSuccess, onError) => {
  return axiosPost(`${API_URL}/signer/updateSignerAdditionalInformation`, data)
    .then(onSuccess)
    .catch(onError);
};

export const apiGetSignerAdditionalInformation = (signerId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/signer/getSignerAdditionalInformation`, {
    signerId
  })
    .then(onSuccess)
    .catch(onError);
};

export const apiGetSignerAdditionalInforRecentOrders = (data, onSuccess, onError) => {
  return axiosGet(`${API_URL}/signer/getSignerAdditionalInforRecentOrders`, data)
    .then(onSuccess)
    .catch(onError);
};

export const apiGetSignerAdditionalInformationModal = (signerId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/signer/getSignerAdditionalInformationModal`, {
    signerId
  })
    .then(onSuccess)
    .catch(onError);
};

export const apiGetVendorRegisterPrograms = (gridCriteria, signerId, onSuccess, onError) => {
  gridCriteria.signerId = signerId;
  return axiosGet(`${API_URL}/signer/getVendorRegisterPrograms`, trimObject(gridCriteria))
    .then(onSuccess)
    .catch(onError);
};

export const apiGetCourseTestList = (ProgramId, signerId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/signer/getCourseTestList`, trimObject({
    ProgramId,
    signerId
  }))
    .then(onSuccess)
    .catch(onError);
};

export const apiGetListVendorByNameOrEmail = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/signer/getListVendorByNameOrEmail`, trimObject(inputs)).then(onSuccess).catch(onFail);
};

export const apiGetTotalVendorPoolForClientOrderAssignConfig = (inputs, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/signer/getTotalVendorPoolForClientOrderAssignConfig`, trimObject(inputs)).then(onSuccess).catch(onFail);
};

export const apiGetVendorOrderList = (filter, successCb, failCb) => {
  return axiosGet(`${API_URL}/signer/getVendorOrders`, filter, false).then(successCb).catch(failCb);
};

export const apiGetOrderRatingBySignerId = (gridCriteria, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/signer/getOrderRatingBySignerId`, trimObject(gridCriteria)).then(onSuccess).catch(onFail);
};

export const apiGetVendorNotifications = (criteria, signerId, onSuccess, onFail) => {
  criteria.signerId = signerId;
  return axiosGet(`${API_URL}/signer/getVendorNotifications`, criteria, null).then(onSuccess).catch(onFail);
};

export const apiUpdateSignerAddress = (signer, onSuccess, onFail) => {
  axiosPost(`${API_URL}/signer/updateSignerAddress`, trimObject(signer)).then(onSuccess).catch(onFail);
};

export const apiGetDataAssignVendor = (signerId, orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/signer/getDataAssignVendor`, {
    signerId,
    orderId
  }, null).then(onSuccess).catch(onFail);
};

export const apiCalculateSignerRating = (signerId, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/signer/calculateSignerRating`, { signerId }).then(onSuccess).catch(onFail);
};

export const apiCheckTceValidation = (signerId, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/signer/checkTceValidation`, { signerId }).then(onSuccess).catch(onFail);
};

export const apiGetSignerCertificateById = (signerId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/signer/getSignerCertificateById`, { signerId }).then(onSuccess).catch(onFail);
};


