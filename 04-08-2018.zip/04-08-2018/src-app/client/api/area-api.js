import { axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetStateByZipCode = (zipCode, onSuccess, onError) => {
    return axiosGet(`${API_URL}/area/getStateByZipCode`, { zipCode }, false).then(onSuccess).catch(onError);
};