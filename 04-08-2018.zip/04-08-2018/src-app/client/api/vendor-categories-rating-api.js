import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "../helpers/axios-helper";

export const apiGetVendorCategoriesRating = (clientId, roleType, onSuccess, onFail) => {

    return axiosGet(`${API_URL}/vendor-categories-rating/getVendorCategoriesRating`, { clientId, roleType }, false).then(onSuccess).catch(onFail);
};

export const apiUpdateVendorRatingSetting = (listVendorCategoryRating, listVendorModifierBonus, listRating, clientId, roleType, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/vendor-categories-rating/updateVendorRatingSetting`, { listVendorCategoryRating, listVendorModifierBonus, listRating, clientId, roleType }, false).then(onSuccess).catch(onFail);
};