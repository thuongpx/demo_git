import {
  API_URL
} from "Config/config";
import {
  axiosGet,
  axiosPost,
  axiosDownload
} from "Helpers/axios-helper";

export const apiFetchOrderByStatusChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchOrderByStatusChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchOrderByStatusGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchOrderByStatusGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiGetInitDataForCannedReport = (onSuccess, onFail) => {
  return axiosGet(`${API_URL}/cannedReport/getInitDataForCannedReport`)
    .then(onSuccess)
    .catch(onFail);
};

export const apiCountOrderByStatusGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countOrderByStatusGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiFetchOrderComparisonByBussinessChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchOrderComparisonByBussinessChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchMilestonesChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchMilestonesChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchOpenOrderTrendChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchOpenOrderTrendByCustomersChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchAssignedOrderByAgentChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchAssignedOrderByAgentsChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchMilestonesGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchMilestonesGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiCountMilestonesGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countMilestonesGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiFetchDailyAutoAssignedOrderByStatusChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchDailyAutoAssignOrdersByStatusChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchDailyAutoAssignOrdersByStatusGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchDailyAutoAssignOrdersByStatusGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apicountDailyAutoAssignOrdersByStatusGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countDailyAutoAssignOrdersByStatusGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiFetchClosedOrdersByCustomersChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchClosedOrdersByCustomersChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchDailyManualAssignedOrderByStatusChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchDailyManualAssignOrdersByStatusChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchDailyManualAssignOrdersByStatusGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchDailyManualAssignOrdersByStatusGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apicountDailyManualAssignOrdersByStatusGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countDailyManualAssignOrdersByStatusGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiFetchClosedOrdersByCustomersGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchClosedOrdersByCustomersGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiCountClosedOrdersByCustomersGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countClosedOrdersByCustomersGridData`, criteria).then(onSuccess).catch(onFail);
};
export const apiFetchOpenOrderTrendGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchOpenOrderTrendByCustomersGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiCountOpenOrderTrendGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countOpenOrderTrendByCustomersGridData`, criteria).then(onSuccess).catch(onFail);
};
export const apiFetchEconomicChartData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchEconomicChartData`, criteria).then(onSuccess).catch(onFail);
};
export const apiFetchAssignedOrderListGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchAssignedOrderBySchedulerGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiCountAssignedOrderListGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countAssignedOrderBySchedulerGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiCountEconomicGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countEconomicGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiFetchEconomicGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchEconomicGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiGetDefaultEconomicAgent = (inputs, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/getDefaultEconomicAgent`, inputs).then(onSuccess).catch(onFail);
};

export const apiFetchOrderByCustomerAndStatusChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchOrderByCustomerAndStatusChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchOrderByCustomerAndStatusGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchOrderByCustomerAndStatusGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiCountOrderByCustomerAndStatusGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countOrderByCustomerAndStatusGridData`, criteria).then(onSuccess).catch(onFail);
};

//
export const apiAddTemplateReport = (dataObjSave, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/addTemplateReport`, dataObjSave).then(onSuccess).catch(onFail);
};

export const apiDeleteTemplateReport = (reportId, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/deleteTemplateReport`, {
    reportId
  }).then(onSuccess).catch(onFail);
};


export const apiFetchClosedOrdersByClientForStaffChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchClosedOrdersByClientForStaffChartData`, searchObject).then(onSuccess).catch(onFail);
};


export const apiFetchClosedOrdersByClientForStaffGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchClosedOrdersByClientForStaffGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiCountClosedOrdersByClientForStaffGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countClosedOrdersByClientForStaffGridData`, criteria).then(onSuccess).catch(onFail);
};
export const apiFetchOpenOrderTrendForStaffChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchOpenOrderTrendForStaffChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchOpenOrderTrendForStaffGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchOpenOrderTrendForStaffGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiCountOpenOrderTrendForStaffGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countOpenOrderTrendForStaffGridData`, criteria).then(onSuccess).catch(onFail);
};
export const apiFetchAssignedOrderBySchedulerForStaffGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchAssignedOrderBySchedulerForStaffGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiGetTemplateReport = (onSuccess, onFail) => {
  return axiosGet(`${API_URL}/cannedReport/getTemplateReport`).then(onSuccess).catch(onFail);
};

export const apiFetchOrderByCustomerAndStatusForStaffChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchOrderByCustomerAndStatusForStaffChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchOrderByCustomerAndStatusForStaffGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchOrderByCustomerAndStatusForStaffGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiCountOrderByCustomerAndStatusForStaffGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countOrderByCustomerAndStatusForStaffGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiFetchMilestonesForStaffChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchMilestonesForStaffChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchMilestonesForStaffGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchMilestonesForStaffGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiCountMilestonesForStaffGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countMilestonesForStaffGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiFetchAssignedOrderBySchedulerForStaffChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchAssignedOrderBySchedulerForStaffChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiFetchEconomicProfitTrendDailyChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchEconomicProfitTrendDailyChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiGetMetricRevenue = (onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/getMetricRevenue`).then(onSuccess).catch(onFail);
};
export const apiGetMetricOpenedVolume = (onSuccess, onFail) => {
  return axiosGet(`${API_URL}/cannedReport/getMetricOpenedVolume`).then(onSuccess).catch(onFail);
};

export const apiGetMetricClosedVolume = (onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/getMetricClosedVolume`).then(onSuccess).catch(onFail);
};
export const apiGetMetricGrossProfit = (onSuccess, onFail) => {
  return axiosGet(`${API_URL}/cannedReport/getMetricGrossProfit`).then(onSuccess).catch(onFail);
};

export const apiFetchEconomicProfitTrendMonthlyChartData = (searchObject, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchEconomicProfitTrendMonthlyChartData`, searchObject).then(onSuccess).catch(onFail);
};

export const apiCountAssignedOrderBySchedulerForStaffGridData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countAssignedOrderBySchedulerForStaffGridData`, criteria).then(onSuccess).catch(onFail);
};

export const apiFetchEconomicMixChartData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchEconomicMixChartData`, criteria).then(onSuccess).catch(onFail);
};

export const apiGetListLoanTypeForMixChart = (onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/getListLoanTypeForMixChart`).then(onSuccess).catch(onFail);
};

export const apiFetchEconomicClosedOrderDrilldownData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/fetchEconomicClosedOrderDrilldownData`, criteria).then(onSuccess).catch(onFail);
};

export const apiCountEconomicClosedOrderDrilldownData = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/cannedReport/countEconomicClosedOrderDrilldownData`, criteria).then(onSuccess).catch(onFail);
};

export const apiExportDrillDownData = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportDrillDownData`, input, fileName, onSuccess, true, "application/json").catch(onError);
};

export const apiDownloadExcelEconomicRequestFeeGridData = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportEconomicRequestFeeGridData`, input, fileName, onSuccess, true, "application/json").catch(onError);
};

export const apiDownloadAssignedOrderBySchedulerGridData = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportAssignedOrderBySchedulerGridData`, input, fileName, onSuccess, true, "application/json").catch(onError);
};

export const apiDownloadComparisonByBusinessDayGridData = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportComparisonByBusinessDayGridData`, input, fileName, onSuccess, true).catch(onError);
};

export const apiDownloadOrderByStatusGridData = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportOrderByStatusGridData`, input, fileName, onSuccess, true).catch(onError);
};

export const apiDailyAutoAssignedOrdersByStatusGrid = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportDailyAutoAssignedOrdersByStatusGrid`, input, fileName, onSuccess, true).catch(onError);
};

export const apiDailyManualAssignedOrdersByStatusGrid = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportDailyManualAssignedOrdersByStatusGrid`, input, fileName, onSuccess, true).catch(onError);
};

//
export const apiDownloadExcelManualReportOrder = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportManualReportOrder`, input, fileName, onSuccess, true).catch(onError);
};

export const apiDownloadExcelManualReportVendor = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportManualReportVendor`, input, fileName, onSuccess, true).catch(onError);
};

export const apiGetTemplateByName = (reportName, onSuccess, onError) => {
  return axiosGet(`${API_URL}/cannedReport/getTemplateReportByName`, reportName, onSuccess, true).then(onSuccess).catch(onError);
};

export const apiExportMilestoneGridData = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportMilestoneGridData`, input, fileName, onSuccess, true, "application/json").catch(onError);
};

export const apiExportOpenOrdersTrendByCustomer = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportOpenOrdersTrendByCustomer`, input, fileName, onSuccess, true, "application/json").catch(onError);
};

export const apiExportClosedOrdersByCustomersGridData = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportClosedOrdersByCustomersGridData`, input, fileName, onSuccess, true, "application/json").catch(onError);
};

export const apiExportOrderByCustomerAndStatusGridData = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportOrderByCustomerAndStatusGridData`, input, fileName, onSuccess, true, "application/json").catch(onError);
};
export const apiDailylAssignedOrdersByStatusGrid = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportDailyAssignedOrdersByStatusGrid`, input, fileName, onSuccess, true).catch(onError);
};

export const apiDownloadComparisonByBusinessDayGridDataForStaff = (input, fileName, onSuccess, onError) => {
  return axiosDownload(`${API_URL}/cannedReport/exportComparisonByBusinessDayGridDataForStaff`, input, fileName, onSuccess, true).catch(onError);
};