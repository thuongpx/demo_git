import {
  API_URL
} from "Config/config";
import {
  axiosPost,
  axiosGet
} from "Helpers/axios-helper";

export const apiGetOrdersSentOffers = (conditions, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/signerOffer/getOrdersSentOffers`, conditions).then(onSuccess).catch(onFail);
};

export const apiAddVendorOffer = (signerOffer, onSuccess, onError) => {
  return axiosPost(`${API_URL}/vendor-offer/addVendorOffer`, {
    data: signerOffer
  }).then(onSuccess).catch(onError);
};
