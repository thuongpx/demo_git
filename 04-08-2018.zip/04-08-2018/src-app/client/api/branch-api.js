import {
  axiosGet,
  axiosPost
} from "Helpers/axios-helper";
import {
  API_URL
} from "Config/config";
import {
  trimObject
} from "Helpers/common-helper";

export const apiGetBranchesForDropdown = (onSuccess, onError) => {
  return axiosGet(`${API_URL}/branch/getBranchesForDropdown`, false).then(onSuccess).catch(onError);
};

export const apiGetBranchManagement = (criteria, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/branch/getBranchManagementData`, criteria).then(onSuccess).catch(onFail);
};

export const apiUpdateBranch = (branch, onSuccess, onFail) => {
  axiosPost(`${API_URL}/branch/updateBranch`, trimObject(branch)).then(onSuccess).catch(onFail);
};

export const apiCheckBranchMergeable = (brokerId, userId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/branch/checkBranchMergeable`, {
    brokerId,
    userId
  }, false).then(onSuccess).catch(onError);
};

export const apiMergeBranch = (originId, destinationId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/branch/mergeBranch`, {
    originId,
    destinationId
  }, false).then(onSuccess).catch(onError);
};

export const apiDisableBranch = (branchId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/branch/disableBranch`, {
    branchId
  }, false).then(onSuccess).catch(onError);
};

export const apiEnableBranch = (branchId, onSuccess, onError) => {
  return axiosPost(`${API_URL}/branch/enableBranch`, {
    branchId
  }, false).then(onSuccess).catch(onError);
};
