import {
  API_URL
} from "Config/config";
import {
  axiosPost,
  axiosGet
} from "Helpers/axios-helper";

export const apiGetResolutionByProblemId = (problemId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/resolution/getResolutionByProblemId`, {
    problemId
  }).then(onSuccess).catch(onError);
};

export const apiAddResolution = (resolution, onSuccess, onError) => {
  return axiosPost(`${API_URL}/resolution/AddResolution`, resolution, false).then(onSuccess).catch(onError);
};
