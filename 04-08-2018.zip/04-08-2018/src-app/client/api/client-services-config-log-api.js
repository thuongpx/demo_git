import { API_URL } from "Config/config";
import { axiosGet } from "../helpers/axios-helper";

export const apiGetConfigLogByConfigId = (configId, onSuccess, onFail) => {

    return axiosGet(`${API_URL}/client-services-config-log/getConfigLogByConfigId`, { configId }, false).then(onSuccess).catch(onFail);
};