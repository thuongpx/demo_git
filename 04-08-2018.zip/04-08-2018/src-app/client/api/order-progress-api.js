import {
  API_URL
} from "Config/config";
import {
  axiosPost,
  axiosGet
} from "Helpers/axios-helper";
import {
  emitHaveNewActivity
} from "../socket/orders";
import {
  emitSendDataToListUsers
} from "../socket/users";

export const apiAddNewOrderProgress = (data, onSuccess, onError) => {
  return axiosPost(`${API_URL}/orderprogress/addProgressLog`, data).then(() => {
    if (typeof onSuccess === "function") onSuccess();
    if (data.OrderId !== undefined) emitHaveNewActivity(data.OrderId);
    if (data.OrderId !== undefined) emitHaveNewActivity(data.orderId);
    if (data.OrderId !== undefined) {
      axiosGet(`${API_URL}/orderprogress/getListUsers`, data).then((response) => {
        const listUsers = response.data.listUsers;
        emitSendDataToListUsers({
          type: "RELOAD_ALERT"
        }, listUsers);
      }).catch(onError);
    }
  }).catch(onError);
};

export const apiAddMultiProgressLog = (data, onSuccess, onError) => {
  return axiosPost(`${API_URL}/orderprogress/addMultiProgressLog`, data).then(() => {
    if (typeof onSuccess === "function") onSuccess();
    const {
      logs
    } = data;
    if (logs[0].OrderId !== undefined) emitHaveNewActivity(logs[0].OrderId);
    if (logs[0].orderId !== undefined) emitHaveNewActivity(logs[0].orderId);
  }).catch(onError);
};

export const apiGetOrderProgressLogById = (orderId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/orderprogress/getOrderProgressLogById`, {
    orderId
  }).then(onSuccess).catch(onError);
};

export const apiGetDataAlert = (criteria, role, userId, accountId, success, fail) => {
  criteria.role = role;
  criteria.userId = userId;
  criteria.accountId = accountId;
  return axiosGet(`${API_URL}/orderprogress/getDataAlert`, criteria).then(success).catch(fail);
};

export const apiUpdateMaskReadOrUnread = (progressLog, success, fail) => {
  return axiosPost(`${API_URL}/orderprogress/updateMaskAsReadOrUnread`, progressLog).then(success).catch(fail);
};

export const apiMarkAsRead = (data, success, fail) => {
  return axiosPost(`${API_URL}/orderprogress/markAsRead`, data).then(success).catch(fail);
};

export const apiGetAllDataAlert = (criteria, role, userId, accountId, isSelfService, success, fail) => {
  criteria.role = role;
  criteria.userId = userId;
  criteria.accountId = accountId;
  criteria.isSelfService = isSelfService;
  return axiosGet(`${API_URL}/orderprogress/getAllDataAlert`, criteria).then(success).catch(fail);
};

export const apiGetPositionAlert = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/orderprogress/getPositionAlert`, inputs).then(onSuccess).catch(onFail);
};
