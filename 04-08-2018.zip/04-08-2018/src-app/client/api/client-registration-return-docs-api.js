import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "Helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";

export const apiGetReturnDocsData = (brokerId, onSuccess, onError) => {
    //return axiosGet(`${API_URL}/client-registration/getReturnDocsDataById?orderId=${brokerId}`).then(onSuccess).catch(onError);
    return axiosGet(`${API_URL}/client-registration/getReturnDocsDataById`).then(onSuccess).catch(onError);
};

export const apiAddNewInputData = (newAddressData, onSuccess, onError) => {
    return axiosPost(`${API_URL}/client-registration/addNewInputData`, trimObject(newAddressData), false).then(onSuccess).catch(onError);
};