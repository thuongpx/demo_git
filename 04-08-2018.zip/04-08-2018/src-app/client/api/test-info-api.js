import { axiosPost, axiosGet } from "Helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";
import { API_URL } from "Config/config";

export const apiAddTestInfo = (testInfo, onSuccess, onError) => {
    return axiosPost(`${API_URL}/testInfo/addTestInfo`, trimObject(testInfo), false).then(onSuccess).catch(onError);
};

export const apiUpdateTestInfo = (testInfo, onSuccess, onError) => {
    return axiosPost(`${API_URL}/testInfo/updateTestInfo`, trimObject(testInfo), false).then(onSuccess).catch(onError);
};

export const apiGetTestInfos = (criteria, onSuccess, onError) => {
    return axiosPost(`${API_URL}/testInfo/getTestInfos`, trimObject(criteria), false).then(onSuccess).catch(onError);
};

export const apiCheckExistTest = (testInfo, onSuccess, onError) => {
    return axiosPost(`${API_URL}/testInfo/checkExistTest`, testInfo, false).then(onSuccess).catch(onError);
};

export const apiGetTestInfoById = (testId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/testInfo/getTestInfoById`, { testId }, false).then(onSuccess).catch(onError);
};

export const apiDeleteTestInfo = (testId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/testInfo/deleteTestInfo`, { testId }, false).then(onSuccess).catch(onError);
};

export const apiGetTestSectionsDefaultTest = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/testInfo/getTestSectionsDefaultTest`, {}, false).then(onSuccess).catch(onError);
};

export const apiGetTestQaBySectionId = (sectionId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/testInfo/getTestQaBySectionId`, { sectionId }, false).then(onSuccess).catch(onError);
};

export const apiActiveDeactiveTestInfo = (testInfo, onSuccess, onError) => {
    return axiosPost(`${API_URL}/testInfo/activeDeactiveTestInfo`, trimObject(testInfo), false).then(onSuccess).catch(onError);
};

export const apiCheckTestAnswers = (data, onSuccess, onError) => {
    return axiosPost(`${API_URL}/testInfo/checkTestAnswers`, data, false).then(onSuccess).catch(onError);
};

export const apiCheckDefaultTestAnswers = (data, onSuccess, onError) => {
    return axiosPost(`${API_URL}/testInfo/checkDefaultTestAnswers`, data, false).then(onSuccess).catch(onError);
};

export const apiIsVendorFailedExam = (vendorId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/testInfo/isVendorFailedExam`, { vendorId }, false).then(onSuccess).catch(onError);
};

export const apiSetDefaultTest = (testId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/testInfo/setDefaultTest`, { testId }, false).then(onSuccess).catch(onError);
};

export const apiGetTestCategory = (onSuccess, onError) => {
    return axiosGet(`${API_URL}/testInfo/getTestCategory`, false).then(onSuccess).catch(onError);
};