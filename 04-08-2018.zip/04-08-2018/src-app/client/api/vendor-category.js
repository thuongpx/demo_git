import {
  axiosGet
} from "Helpers/axios-helper";
import {
  API_URL
} from "Config/config";

export const apiGetVendorCategories = (onSuccess, onError) => {
  return axiosGet(`${API_URL}/vendor-category/getCategories`, null).then(onSuccess).catch(onError);
};
