import {
  API_URL
} from "Config/config";
import {
  axiosGet,
  axiosPost
} from "Helpers/axios-helper";


export const apiGetOrders = (filter, successCb, failCb) => {
  return axiosGet(`${API_URL}/order/getOrders`, filter, false).then(successCb).catch(failCb);
};

export const apiGetInitDataForViewOrders = (successCb, failCb) => {
  return axiosGet(`${API_URL}/order/getInitData`, false).then(successCb).catch(failCb);
};

export const apiGetOrderCollectItemsData = (orderId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/order/getOrderCollect`, {
    orderId
  }).then(onSuccess).catch(onError);
};

export const apiGetOrderStatusInitData = (data, successCb, failCb) => {
  return axiosGet(`${API_URL}/order/getOrderStatusInitData`, data, false).then(successCb).catch(failCb);
};

export const apiGetOrderProgressLog = (criteria, successCb, failCb) => {
  return axiosGet(`${API_URL}/order/getOrderStatusProgressLog`, criteria, false).then(successCb).catch(failCb);
};

export const apiGetOrderClientDropdownDataByClientId = (clientId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getOrderClientDropdownDataByClientId`, {
    clientId
  }).then(onSuccess).catch(onFail);
};

export const apiGetOrderClientAgentsData = (data, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getOrderClientAgentData`, data).then(onSuccess).catch(onFail);
};

export const apiGetOrderClientById = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getOrderClientById`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

export const apiGetInitDataForOrderCustomer = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getInitDataForOrderCustomer`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

export const apiUpdateOrderDetailStatus = (newOrderStatus, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/updateOrderDetailStatus`, newOrderStatus).then(onSuccess).catch(onFail);
};

export const apiUpdateOrderDetailClient = (orderDetailClient, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/updateOrderDetailClient`, orderDetailClient).then(onSuccess).catch(onFail);
};

export const apiUpdateOrderDetailCustomer = (newOrderDetailCustomer, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/updateOrderDetailCustomer`, newOrderDetailCustomer).then(onSuccess).catch(onFail);
};

export const apiAddNewOrder = (onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/addOrder`).then(onSuccess).catch(onFail);
};

export const apiGetDefaultDataForOrderDetailHeader = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getDefaultDataForOrderDetailHeader`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

export const apiGetListCustomerForStatusByClientId = (BrokerId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getListCustomerByBrokerId`, {
    BrokerId
  }).then(onSuccess).catch(onFail);
};

export const apiGetListProductTypeForStatusByCustomerId = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getOrderDetailProductTypeByCustomerId`, inputs).then(onSuccess).catch(onFail);
};

export const apiGetInitRequiredTabForOrder = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getInitRequiredTabForOrderDetail`, inputs).then(onSuccess).catch(onFail);
};

export const apiCheckInCompleteOrder = (userId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/checkInCompleteOrder`, {
    userId
  }).then(onSuccess).catch(onFail);
};

export const apiRemoveInCompleteOrder = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/removeInCompleteOrder`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

export const apiSetActiveOrder = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/setActiveOrder`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

export const apiSetCurrentTabOfInCompleteOrder = (input, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/setCurrentTabOfInCompleteOrder`, input).then(onSuccess).catch(onFail);
};

export const apiGetOrderDetailDropDownDataForClientPlaceOrder = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getOrderDetailDropDownDataForClientPlaceOrder`, inputs).then(onSuccess).catch(onFail);
};

//get default data for order details when client place order
export const apiGetDefaultOrderDetailsData = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getDefaultDataOrderDetails`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

//get init data for tab customer info when clinet place order
export const apiGetInitDataOfCustomerInfo = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getInitDataOfCustomerInfoForClientPlaceOrder`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

//save change data of tab customer when client place order
export const apiUpdateClientPlaceOrderCustomerData = (data, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/updateClientPlaceOrderCustomerData`, data).then(onSuccess).catch(onFail);
};

//get init data when client place an order for appointment details tab
export const apiGetAppointmentDetailsInitData = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getAppointmentDetailsInitData`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

//save data of appointment details tab to DB
export const apiUpdateAppointmentDetailsData = (input, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/updateAppointmentDetailsData`, input).then(onSuccess).catch(onFail);
};

export const apiUpdateOrderSpecialIns = (inputs, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/updateOrderSpecialIns`, inputs).then(onSuccess).catch(onFail);
};

export const apiGetListOrderAdditionalFee = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getListOrderAdditionalFee`, inputs).then(onSuccess).catch(onFail);
};

export const apiUpdateListOrderAddionalFee = (inputs, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/updateListOrderAddionalFee`, inputs).then(onSuccess).catch(onFail);
};

export const apiGetParticipantInOrder = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getParticipantInOrder?orderId=${orderId}`).then(onSuccess).catch(onFail);
};

export const apiCheckInfoOfClientWhenPlaceOrder = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/checkGeneralInfoOfClientWhenPlaceOrder`, inputs).then(onSuccess).catch(onFail);
};

export const apiCheckOrderService = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/checkOrderService`, inputs).then(onSuccess).catch(onFail);
};

export const apiAssignVendor = (order, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/assignVendor`, {
    order
  }).then(onSuccess).catch(onFail);
};

export const apiAutoAssign = (orderId, userId, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/autoAssign`, {
    orderId,
    userId
  }).then(onSuccess).catch(onFail);
};

export const apiCancelAutoAssign = (orderId, onSuccess, onFail) => {
  return axiosPost(`${API_URL}/order/cancelAutoAssign`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

export const apiGetOrderAutoProgress = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getOrderAutoProgress`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

export const apiGetOrdersClientStaff = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getOrdersClientStaff`, inputs).then(onSuccess).catch(onFail);
};

export const apiGetInitSearchOrdersClient = (inputs, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getInitSearchOrdersClient`, inputs).then(onSuccess).catch(onFail);
};

export const apiGetOrderDetailLeftPanelInitData = (data, success, fail) => {
  return axiosGet(`${API_URL}/order/getOrderDetailLeftPanelInitData`, data).then(success).catch(fail);
};

export const apiGetVendorOrderDetailLeftPanelInitData = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/getVendorOrderDetailLeftPanelInitData`, {
    orderId
  }).then(success).catch(fail);
};

export const apiGetVendorOrderDetailMainPanelInitData = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/getVendorOrderDetailMainPanelInitData`, {
    orderId
  }).then(success).catch(fail);
};

export const apiGetOrderProgressLogByOrderId = (orderId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/order/getOrderProgressLogByOrderId`, {
    orderId
  }).then(onSuccess).catch(onError);
};


export const apiGetInitOrderDetailData = (query, success, fail) => {
  return axiosGet(`${API_URL}/order/getInitOrderDetailData`, {
    ...query
  }).then(success).catch(fail);
};

export const apiCheckOrderStatusForApprove = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/checkOrderStatusForApprove`, {
    orderId
  }).then(success).catch(fail);
};

export const apiGetRightPanelDocsData = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/getRightPanelDocsData`, {
    orderId
  }).then(success).catch(fail);
};

export const apiRemoveVendorFromOrder = (data, success, fail) => {
  return axiosPost(`${API_URL}/order/removeVendorFromOrder`, data).then(success).catch(fail);
};

export const apiGetVendorLog = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/getVendorLog`, {
    orderId
  }).then(success).catch(fail);
};

export const apiGetOrderDetailLeftPanelFeeInitData = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/getOrderDetailLeftPanelFeeInitData`, {
    orderId
  }).then(success).catch(fail);
};

export const apiGetOrderDetailLeftPanelShippingInitData = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/getOrderDetailLeftPanelShippingInitData`, {
    orderId
  }).then(success).catch(fail);
};

export const apiSaveLeftPanelFees = (data, success, fail) => {
  return axiosPost(`${API_URL}/order/saveLeftPanelFees`, data).then(success).catch(fail);
};

export const apiUpdateLeftPanel = (data, success, fail) => {
  return axiosPost(`${API_URL}/order/updateLeftPanel`, data).then(success).catch(fail);
};

export const apiUpdateAppointment = (data, success, fail) => {
  return axiosPost(`${API_URL}/order/updateAppointment`, data).then(success).catch(fail);
};

export const apiGetRecentVendorData = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/getRecentVendorData`, {
    orderId
  }).then(success).catch(fail);
};

export const apiSendOrderConfirmAndBasicInfo = (inputs, success, fail) => {
  return axiosPost(`${API_URL}/order/sendOrderConfirmAndBasicInfo`, inputs).then(success).catch(fail);
};

export const apiGetOrdersProgressId = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/getOrdersProgressId`, {
    orderId
  }).then(success).catch(fail);
};

export const apiUpdateProgressManually = (orderProgressId, success, fail) => {
  return axiosPost(`${API_URL}/order/updateProgressManually`, orderProgressId).then(success).catch(fail);
};
export const apiSendEmailCloseRequestForOrder = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/sendEmailCloseRequestForOrder`, {
    orderId
  }).then(success).catch(fail);
};
export const apiCheckValidOrderId = (orderId, roleName, userId, success, fail) => {
  return axiosGet(`${API_URL}/order/checkValidOrderId`, {
    orderId,
    roleName,
    userId
  }).then(success).catch(fail);
};
export const apiCheckIsSelfSerivce = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/checkIsSelfService`, {
    orderId
  }).then(success).catch(fail);
};

export const apiCheckAssignVendor = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/checkAssignVendor`, {
    orderId
  }).then(success).catch(fail);
};

export const apiGetAllProblemTypes = (success, fail) => {
  return axiosGet(`${API_URL}/order/getAllProblemTypes`).then(success).catch(fail);
};

export const apiGetProblemSubtypeById = (problemTypesId, success, fail) => {
  return axiosGet(`${API_URL}/order/getProblemSubtypeById`, { problemTypesId }).then(success).catch(fail);
};

export const apiSetOrderProgress = (data, success, fail) => {
  return axiosPost(`${API_URL}/order/setOrderProgress`, data).then(success).catch(fail);
};

export const apiSetOrderAgent = (data, success, fail) => {
  return axiosPost(`${API_URL}/order/setOrderAgent`, data).then(success).catch(fail);
};

export const apiGetOrdersProcessGroup = (data, success, fail) => {
  return axiosGet(`${API_URL}/order/getOrderProgressGroup`, data, false).then(success).catch(fail);
};

// export const apiGetOrderProgressClientDashboard = (data, success, fail) => {
//   return axiosGet(`${API_URL}/order/getOrderProgressClientDashboard`, data).then(success).catch(fail);
// };

export const apiGetOrderProgressClient = (data, success, fail) => {
  return axiosGet(`${API_URL}/order/getOrderProgressClient`, data).then(success).catch(fail);
};

export const apiUpdateOrder = (data, success, fail) => {
  return axiosPost(`${API_URL}/order/updateOrder`, data).then(success).catch(fail);
};

export const apiGetNameScheduler = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/getUserNameScheduler`, orderId).then(success).catch(fail);
};

export const apiGetFaxBackReq = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/getFaxBackReq`, {
    orderId
  }).then(success).catch(fail);
};

export const apiCheckFileNoUnique = (orderId, brokerIdNum, success, fail) => {
  return axiosGet(`${API_URL}/order/checkFileNoUnique`, {
    orderId,
    brokerIdNum
  }).then(success).catch(fail);
};

export const apigetOtherDetailsData = (orderId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/getOtherDetailsData`, {
    orderId
  }).then(onSuccess).catch(onFail);
};

export const apiUpdatePreCall = (data, success, fail) => {
  return axiosPost(`${API_URL}/order/updatePreCall`, data).then(success).catch(fail);
};

export const apiUpdateDocsReview = (data, success, fail) => {
  return axiosPost(`${API_URL}/order/updateDocsReview`, data).then(success).catch(fail);
};

export const apiCheckExistOrderOpenByBrokerId = (brokerId, onSuccess, onFail) => {
  return axiosGet(`${API_URL}/order/checkExistOrderOpenByBrokerId`, {
    brokerId
  }).then(onSuccess).catch(onFail);
};

export const apiValidateOrderBeforeChangeStatus = (data, success, fail) => {
  return axiosGet(`${API_URL}/order/validateOrderBeforeChangeStatus`, data).then(success).catch(fail);
};

// AnNV2: Update UCC-12 Customer feedback
export const apiGetOrderCustomerFeedback = (orderId, success, fail) => {
  return axiosGet(`${API_URL}/order/getOrderCustomerFeedback`, { orderId }).then(success).catch(fail);
};

export const apiSubmitCustomerFeedback = (data, success, fail) => {
  return axiosPost(`${API_URL}/order/submitCustomerFeedback`, data).then(success).catch(fail);
};

export const apiUpdateOrderService = (data, success, fail) => {
  return axiosPost(`${API_URL}/order/updateOrderService`, data).then(success).catch(fail);
};