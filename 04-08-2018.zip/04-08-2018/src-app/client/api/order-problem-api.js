import {
  axiosGet, axiosPost
} from "Helpers/axios-helper";
import {
  API_URL
} from "Config/config";
import {
  trimObject
} from "Helpers/common-helper";

export const apiGetOrderProblem = (criteria, onSuccess, onError) => {
  return axiosGet(`${API_URL}/orderproblem/getOrderProblem`, criteria).then(onSuccess).catch(onError);
};

export const apiGetOrderProblemsByOrder = (criteria, onSuccess, onError) => {
  return axiosGet(`${API_URL}/orderproblem/getOrderProblemsByOrder`, criteria).then(onSuccess).catch(onError);
};

export const apiRemoveProblem = (problemId, onSuccess, onError) => {
  return axiosPost(`${API_URL}/orderproblem/removeOrderProblem`, { problemId }).then(onSuccess).catch(onError);
};

export const apiAddOrderProblem = (data, onSuccess, onError) => {
  return axiosPost(`${API_URL}/orderproblem/addOrderProblem`, data).then(onSuccess).catch(onError);
};

export const apiGetVendorOrderProblem = (criteria, signerId, onSuccess, onError) => {
  criteria.signerId = signerId;
  return axiosGet(`${API_URL}/orderproblem/getVendorOrderProblem`, trimObject(criteria)).then(onSuccess).catch(onError);
};