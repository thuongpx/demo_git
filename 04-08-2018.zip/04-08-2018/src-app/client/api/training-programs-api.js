import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "../helpers/axios-helper";
import { trimObject } from "Helpers/common-helper";


export const apiGetTrainingPrograms = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/training-program/getTrainingPrograms`, trimObject(criteria)).then(onSuccess).catch(onError);
};
export const apiGetInputProgagram = (programId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/training-program/getInputProgagram`, trimObject({ programId })).then(onSuccess).catch(onError);
};

export const apiUpdateTraningProgram = (objectSelected, courses, tests, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/training-program/updateTraningProgram`, trimObject({ program: objectSelected, courses, tests }))
        .then(onSuccess)
        .catch(onFail);
};

export const apiDeleteTrainingProgram = (programId, onSuccess, onError) => {
    return axiosPost(`${API_URL}/training-program/deleteTrainingProgram`, trimObject({ programId })).then(onSuccess).catch(onError);
};

export const apiPublicUnPublicTrainingProgram = (objectSelected, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/training-program/publicUnPublicTrainingProgram`, trimObject({ program: objectSelected }))
        .then(onSuccess)
        .catch(onFail);
};

export const apiCheckProgramName = (programName, programId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/training-program/checkProgramName`, trimObject({ programName, programId })).then(onSuccess).catch(onError);
};

export const apiCountCoursesTestsById = (programId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/training-program/countCoursesTestsById`, trimObject({ programId })).then(onSuccess).catch(onError);
};
