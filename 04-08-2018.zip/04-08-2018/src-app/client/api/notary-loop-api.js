import { axiosPost } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiAddNotaryLoop = (notaryLoop, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/notaryloop/addNotaryLoop`, notaryLoop).then(onSuccess).catch(onFail);
};