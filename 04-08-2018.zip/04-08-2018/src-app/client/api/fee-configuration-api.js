import { axiosGet, axiosPost } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiGetInitDataForMatrix = (actor, actorId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/feeConfiguration/getInitDataForMatrix`, { actor, actorId }, false).then(onSuccess).catch(onError);
};

export const apiSaveFee = (saveData, onSuccess, onError) => {
    return axiosPost(`${API_URL}/feeConfiguration/saveFee`, saveData, false).then(onSuccess).catch(onError);
};

export const apiRefreshData = (actor, actorId, industryId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/feeConfiguration/getRefreshData`, { actor, actorId, industryId }, false).then(onSuccess).catch(onError);
};