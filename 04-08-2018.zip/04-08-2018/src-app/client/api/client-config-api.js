import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "Helpers/axios-helper";

export const apiGetClientMTDConfigByUserId = (userId, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/clientMTDConfig/getClientMTDConfigByUserId`, { userId }).then(onSuccess).catch(onFail);
};

export const addClientMTDConfig = (inputs, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/clientMTDConfig/addClientMTDConfig`, inputs).then(onSuccess).catch(onFail);
};