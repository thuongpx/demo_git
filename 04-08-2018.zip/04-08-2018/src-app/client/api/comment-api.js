import { API_URL } from "Config/config";
import { axiosGet, axiosPost } from "../helpers/axios-helper";

export const apiGetComments = (listComment, onSuccess, onError) => {
    return axiosGet(`${API_URL}/comment/getComments`, listComment).then(onSuccess).catch(onError);
};

export const apiDeleteComment = (CommentID, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/comment/deleteComment`, { CommentID }).then(onSuccess).catch(onFail);
};

export const apiAddComment = (comment, onSuccess, onError) => {
    return axiosPost(`${API_URL}/comment/addComment`, comment, false).then(onSuccess).catch(onError);
};

export const getCommentByType = (filter, onSuccess, onError) => {
    return axiosGet(`${API_URL}/comment/getCommentByType`, filter, false).then(onSuccess).catch(onError);
};

export const apiAddMultiComment = (comments, onSuccess, onError) => {
    return axiosPost(`${API_URL}/comment/addMultiComment`, comments, false).then(onSuccess).catch(onError);
};

export const apiGetOrderCommentWithUserData = (params, onSuccess, onError) => {
    return axiosGet(`${API_URL}/comment/getOrderCommentWithUserData`, params, false).then(onSuccess).catch(onError);
};