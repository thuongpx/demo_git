import { axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";

export const apiCheckValidExamAndGetTestQaByTestId = (programId, testId, vendorId, onSuccess, onError) => {
    return axiosGet(`${API_URL}/notaryexam/getCheckValidExamAndGetTestQaByTestId`, { programId, testId, vendorId }, false).then(onSuccess).catch(onError);
};
