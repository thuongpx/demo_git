import {
  axiosGet,
  axiosPost
} from "Helpers/axios-helper";
import {
  API_URL
} from "Config/config";
import {
  trimObject
} from "Helpers/common-helper";

export const apiGetAnnouncementsByUserId = (userId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/announcements/getAnnouncementsByUserId`, {
    userId
  }).then(onSuccess).catch(onError);
};

export const apiGetAnnouncements = (onSuccess, onError) => {
  return axiosGet(`${API_URL}/announcements/getAnnouncements`, false).then(onSuccess).catch(onError);
};

export const apiAddUpdateUserAnnouncements = (data, onSuccess, onError) => {
  return axiosPost(`${API_URL}/announcements/addUpdateUserAnnouncements`, trimObject(data)).then(onSuccess).catch(onError);
};

export const apiGetVendorAnnouncements = (criteria, signerId, onSuccess, onError) => {
  criteria.signerId = signerId;
  return axiosGet(`${API_URL}/announcements/getVendorAnnouncements`, trimObject(criteria), false).then(onSuccess).catch(onError);
};

export const apiGetUserUnreadAnnouncements = (criteria, userId, onSuccess, onError) => {
  criteria.userId = userId;
  return axiosGet(`${API_URL}/announcements/getUserUnreadAnnouncements`, trimObject(criteria), false).then(onSuccess).catch(onError);
};

export const apiGetUserReadAnnouncements = (criteria, userId, onSuccess, onError) => {
  criteria.userId = userId;
  return axiosGet(`${API_URL}/announcements/getUserReadAnnouncements`, trimObject(criteria), false).then(onSuccess).catch(onError);
};

export const apiUpdateReadUserAnnouncement = (announcementData, userId, onSuccess, onError) => {
  announcementData.userId = userId;
  return axiosPost(`${API_URL}/announcements/updateReadUserAnnouncement`, trimObject(announcementData), false).then(onSuccess).catch(onError);
};

export const apiGetTotalUnreadAnnouncement = (userId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/announcements/getTotalUnreadAnnouncement`, trimObject({ userId }), false).then(onSuccess).catch(onError);
};