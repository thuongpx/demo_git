import { API_URL } from "Config/config";
import { axiosGet, axiosDownload, axiosPost } from "../helpers/axios-helper";

export const apiGetListResource = (typePage, pageDisplay, isClient, isVendor, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/tool/getListResource`, { typePage, pageDisplay, isClient, isVendor }).then(onSuccess).catch(onFail);
};

export const apiDownloadResources = (fileName, onSuccess, onFail) => {
    return axiosDownload(`${API_URL}/tool/downloadResources`, { fileName }, fileName, onSuccess).catch(onFail);
};

export const apiGetListLink = (typePage, pageDisplay, isClient, isVendor, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/tool/getListLink`, { typePage, pageDisplay, isClient, isVendor }).then(onSuccess).catch(onFail);
};

export const apiGetFaqsByQuestion = (question, isClient, isVendor, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/tool/getFaqsByQuestion`, { question, isClient, isVendor }).then(onSuccess).catch(onFail);
};


export const apiGetPageDisplayFromConstant = (onSuccess, onFail) => {
    return axiosGet(`${API_URL}/tool/getPageDisplayFromConstant`).then(onSuccess).catch(onFail);
};

export const apiAddLinksToDataBase = (
    linkTitle, link, type, target, description, views,
    onSuccess, onFail) => {
    return axiosPost(`${API_URL}/tool/addLinksToDataBase`, {
        linkTitle, link, type, target, description, views
    }).then(onSuccess).catch(onFail);
};

export const apiDeleteLinksById = (Id, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/tool/deleteLinksById`, { Id }).then(onSuccess).catch(onFail);
};

export const apiEditLinksById = (
    linkId, Title, Link, type, target, Description, views,
    onSuccess, onFail) => {
    return axiosPost(`${API_URL}/tool/editLinksById`, {
        linkId, Title, Link, type, target, Description, views
    }).then(onSuccess).catch(onFail);
};

export const apiGetListFaqByViews = (typePage, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/tool/getListFaqByViews`, { typePage }).then(onSuccess).catch(onFail);
};

export const apiAddFaqsToDatabase = (
    question, answer, views,
    onSuccess, onFail) => {
    return axiosPost(`${API_URL}/tool/addFaqsToDatabase`, {
        question, answer, views
    }).then(onSuccess).catch(onFail);
};

export const apiEditFaqById = (
    faqId, question, answer,
    onSuccess, onFail) => {
    return axiosPost(`${API_URL}/tool/editFaqById`, {
        faqId, question, answer
    }).then(onSuccess).catch(onFail);
};

export const apiDeleteFaqById = (Id, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/tool/deleteFaqById`, { Id }).then(onSuccess).catch(onFail);
};

export const apiGetLinksDisplayFromConstant = (onSuccess, onFail) => {
    return axiosGet(`${API_URL}/tool/getLinksDisplayFromConstant`).then(onSuccess).catch(onFail);
};
//resource
export const apiAddResourcesToDataBase = (
    title, resource, description, views,
    onSuccess, onFail) => {
    return axiosPost(`${API_URL}/tool/addResourcesToDataBase`, {
        title, resource, description, views
    }).then(onSuccess).catch(onFail);
};

export const apiDeleteResourcesById = (Id, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/tool/deleteResourcesById`, { Id }).then(onSuccess).catch(onFail);
};

export const apiEditResourcesById = (
    resourceId, title, resource, description,
    onSuccess, onFail) => {
    return axiosPost(`${API_URL}/tool/editResourcesById`, {
        resourceId, title, resource, description
    }).then(onSuccess).catch(onFail);
};

export const apiDeleteResourceFileById = (Id, onSuccess, onFail) => {
    return axiosGet(`${API_URL}/tool/deleteResourceFileById`, { Id }).then(onSuccess).catch(onFail);
};

//resource
