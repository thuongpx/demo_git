import {
  axiosPost,
  axiosGet
} from "Helpers/axios-helper";
import {
  trimObject
} from "Helpers/common-helper";
import {
  API_URL
} from "Config/config";

export const apiGetIssues = (criteria, onSuccess, onError) => {
  return axiosGet(`${API_URL}/issue/getIssues`, criteria, false).then(onSuccess).catch(onError);
};

export const apiGetIssueById = (problemId, onSuccess, onError) => {
  return axiosGet(`${API_URL}/issue/getIssueById`, {
    problemId
  }, false).then(onSuccess).catch(onError);
};

export const apiGetIssuesNumberById = (userId, isAgent, onSuccess, onError) => {
  return axiosGet(`${API_URL}/issue/getIssuesNumberById`, {
    userId, isAgent
  }).then(onSuccess).catch(onError);
};

export const apiAddIssue = (issue, onSuccess, onError) => {
  return axiosPost(`${API_URL}/issue/addIssue`, trimObject(issue), false).then(onSuccess).catch(onError);
};

export const apiUpdateIssue = (issue, onSuccess, onError) => {
  return axiosPost(`${API_URL}/issue/updateIssue`, trimObject(issue), false).then(onSuccess).catch(onError);
};

export const apiDeleteIssue = (problemId, onSuccess, onError) => {
  return axiosPost(`${API_URL}/issue/deleteIssue`, {
    problemId
  }).then(onSuccess).catch(onError);
};

export const apiGetCorectionType = (onSuccess, onError) => {
  return axiosGet(`${API_URL}/issue/getCorrectionType`, false).then(onSuccess).catch(onError);
};