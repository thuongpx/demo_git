import { axiosPost, axiosGet } from "Helpers/axios-helper";
import { API_URL } from "Config/config";
import { trimObject } from "Helpers/common-helper";

export const apiGetClientSpecifics = (brokerId, tenantId, onSuccess, onFail) => {
    axiosGet(`${API_URL}/clientDetail/getClientSpecifics`, { brokerId, tenantId }).then(onSuccess).catch(onFail);
};

export const apiAddClientSpecifics = (specifics, onSuccess, onFail) => {
    axiosPost(`${API_URL}/clientDetail/addClientSpecifics`, trimObject(specifics), false).then(onSuccess).catch(onFail);
};

export const apiUpdateClientSpecifics = (specifics, onSuccess, onFail) => {
    axiosPost(`${API_URL}/clientDetail/updateClientSpecifics`, trimObject(specifics), false).then(onSuccess).catch(onFail);
};

export const apiGetRecentOrders = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/clientDetail/getRecentOrders`, criteria, false).then(onSuccess).catch(onError);
};

export const apiGetAvailableSigner = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/clientDetail/getAvailableSigner`, criteria, false).then(onSuccess).catch(onError);
};

export const apiGetBlackListSigner = (criteria, onSuccess, onError) => {
    return axiosGet(`${API_URL}/clientDetail/getBlackListSigner`, criteria, false).then(onSuccess).catch(onError);
};

export const apiUpdateBlackListSigner = (brokerId, blackList, onSuccess, onError) => {
    axiosPost(`${API_URL}/clientDetail/updateBlackListSigner`, { brokerId, blackList }, false).then(onSuccess).catch(onError);
};

export const apiUpdateWhiteListSigner = (brokerId, whiteList, onSuccess, onError) => {
    axiosPost(`${API_URL}/clientDetail/updateWhiteListSigner`, { brokerId, whiteList }, false).then(onSuccess).catch(onError);
};

export const apiUploadLendorSpecifics = (data, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/client/uploadLendorSpecifics`, trimObject(data)).then(onSuccess).catch(onFail);
};

export const apiDeleteLendorSpecifics = (brokerId, onSuccess, onFail) => {
    return axiosPost(`${API_URL}/client/deleteLendorSpecifics`, { brokerId }).then(onSuccess).catch(onFail);
};