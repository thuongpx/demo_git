import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";

class ValidatorMessage extends Component {
    render() {
        const { className, messages } = this.props;
        return (
            <span>
                {messages.map((message, index) => {
                    return (
                        <span key={index} className={className} >{message}</span>
                    );
                })}
            </span>
        );
    }
}

ValidatorMessage.propTypes = {
    messages: PropTypes.array,
    className: PropTypes.string
};

export default ValidatorMessage;