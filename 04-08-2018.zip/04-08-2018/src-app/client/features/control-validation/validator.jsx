class Validator {
    // validate function, message function, field name, extFile for message
    constructor(validate, message, field, extField = "") {
        this.validateFunction = validate;
        this.message = message;
        this.field = field;
        this.extField = extField;
    }

    validate(value, ...ext) {
        return this.validateFunction(value, ...ext);
    }

    getMessage() {
        const fields = (this.extField && this.extField.length > 0) ? [this.field, this.extField] : [this.field];
        return this.message(...fields);
    }
}

export default Validator;