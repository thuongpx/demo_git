import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { ICONS_LIST } from "Constants";

class IconPickerSampleList extends Component {
    constructor(props) {
        super(props);
    }

    handleChange(value) {
        const { onChange } = this.props;

        onChange(value);
    }

    renderColorBlock(value, index) {
        const selected = this.props.value;
        const styles = {
            colorBlock: {
                width: "30px",
                height: "30px",
                textAlign: "center",
                lineHeight: "30px",
                fontSize: "20px",
                color: "#828181",
                display: "inline-block",
                borderRadius: "4px",
                verticalAlign: "top",
                border: '1px solid #ddd',
                boxShadow: value === selected && "#006ca9 0px 0px 3px 1px"
            },
            fillBlock: {
                width: "30px",
                height: "30px",
                textAlign: "center",
                lineHeight: "30px",
                fontSize: "20px",
                color: "#828181",
                display: "inline-block",
                borderRadius: "4px",
                verticalAlign: "top",
                cursor: "default"
            }
        };

        if (value === "fillBlock") {
            return (
                <span className={`lnr ${value}`} style={styles.fillBlock} key={index}>#</span>
            );
        }

        return (
            <span className={`lnr ${value}`} style={styles.colorBlock} key={index} onClick={() => this.handleChange(value)}>{index === 9 && ""}</span>
        );
    }

    render() {
        const { sampleColors } = this.props;

        return (
            <span>
                {
                    sampleColors.map((color, index) => {
                        return this.renderColorBlock(color, index);
                    })
                }
            </span>
        );
    }
}


IconPickerSampleList.defaultProps = {
    sampleColors: ICONS_LIST
};

IconPickerSampleList.propTypes = {
    value: PropTypes.string,
    sampleColors: PropTypes.array,
    onChange: PropTypes.func
};

export default IconPickerSampleList;