import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import IconPickerAdditional from "./icon-picker-additional";
import IconPickerSampleList from "./icon-picker-sample-list";
import { ICONS_LIST } from "Constants";

class IconPicker extends Component {
    constructor(props) {
        super(props);
        this.state = this.processPropsToState(this.props);
    }

    componentWillReceiveProps(nextProps) {
        const { value, colors, notUsedColors } = nextProps;

        if (notUsedColors !== this.props.notUsedColors || colors !== this.props.colors) {
            //if update notUsedColors or colors -> refresh random sampleColors and remainColors
            this.setState(this.processPropsToState(nextProps));
            return;
        }

        // if just change value -> update value
        if (this.props.notUsedColors.indexOf(value) === -1 && this.props.colors.indexOf(value) !== -1) {
            this.syncValueWithSampleList(value);
        } else {
            // if value is not valid -> set to ""
            this.setState({
                value: ""
            });
        }
    }

    processPropsToState(props) {
        const { value, colors, notUsedColors } = props;

        const tempValue = (notUsedColors.indexOf(value) === -1 && colors.indexOf(value) !== -1) ? value : "";
        const randomSampleColors = this.randomSampleColors(value, colors, notUsedColors);

        return {
            value: tempValue,
            sampleColors: randomSampleColors.sampleColors,
            remainColors: randomSampleColors.remainColors,
            isAdditionalShow: randomSampleColors.remainColors.length - notUsedColors.length > 0
        };
    }

    randomSampleColors(value, colors, notUsedColors) {
        const sampleColors = [];
        const remainColors = [...colors];

        //if number of colors is more than number of sample -> random sample and remove from remain
        if (colors.length - notUsedColors.length > 9) {

            while (sampleColors.length < 9) {
                const randIndex = Math.floor(Math.random() * (remainColors.length));

                if (sampleColors.indexOf(remainColors[randIndex]) === -1 &&
                    notUsedColors.indexOf(remainColors[randIndex]) === -1 &&
                    remainColors[randIndex] !== value) {

                    sampleColors.push(remainColors[randIndex]);
                    remainColors.splice(randIndex, 1);
                }
            }

            //if component have valid value -> push in last block or push fillBlock
            sampleColors.push((notUsedColors.indexOf(value) === -1 && colors.indexOf(value) !== -1) ? value : "fillBlock");

            return {
                sampleColors,
                remainColors: this.sortColors(remainColors, notUsedColors)
            };
        }

        ////if number of colors is less than number of sample -> push all to sampleColors and remains is notUsedColors
        for (let index = 0; index < colors.length; index++) {
            if (notUsedColors.indexOf(colors[index]) === -1 && colors[index] !== value) {
                sampleColors.push(colors[index]);
            }
        }
        //value is always last block
        if (notUsedColors.indexOf(value) === -1 && sampleColors.indexOf(value) === -1 && colors.indexOf(value) !== -1) {
            sampleColors.push(value);
        }

        return {
            sampleColors,
            remainColors: notUsedColors
        };
    }

    sortColors(colors, notUsedColors) {
        return colors.sort((color1, color2) => {
            if (notUsedColors.indexOf(color1) === -1 && notUsedColors.indexOf(color2) !== -1) {
                return -1;
            }
            if (notUsedColors.indexOf(color1) !== -1 && notUsedColors.indexOf(color2) === -1) {
                return 1;
            }
            return (color1 < color2) ? -1 : 1;
        });
    }

    handleChange(value) {
        const { onChange } = this.props;

        this.setState({ value });
        onChange(value);
    }

    handleChangeAdditional(value) {
        const { onChange } = this.props;
        //default values - user do not changes color
        if (value === "#999") {
            return;
        }
        this.syncValueWithSampleList(value);
        onChange(value);
    }

    syncValueWithSampleList(value) {
        let { sampleColors } = this.state;

        if (sampleColors.indexOf(value) === -1) {
            sampleColors = sampleColors.slice(0, 9);
            sampleColors.push(value);
        }

        this.setState({
            value,
            sampleColors
        });
    }

    render() {
        return (
            <div className="list-icon-picker">
                <div>
                    <IconPickerSampleList
                        value={this.state.value}
                        sampleColors={this.state.sampleColors}
                        onChange={(value) => this.handleChange(value)}
                    />
                    {
                        this.state.isAdditionalShow &&
                        <IconPickerAdditional
                            value={this.state.value}
                            colors={this.state.remainColors}
                            notUsedColors={this.props.notUsedColors}
                            onChangeAdditional={(value) => this.handleChangeAdditional(value)}
                        />
                    }
                </div>
            </div>
        );
    }

}
IconPicker.defaultProps = {
    value: "",
    notUsedColors: [],
    colors: ICONS_LIST
};

IconPicker.propTypes = {
    value: PropTypes.string,
    notUsedColors: PropTypes.array,
    colors: PropTypes.array,
    onChange: PropTypes.func
};

export default IconPicker;