import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { ICONS_LIST } from "Constants";

class IconPickerAdditional extends Component {
    constructor(props) {
        super(props);
        this.state = {
            displayColorPicker: false,
            value: "#999"
        };
    }

    handleClick() {
        this.setState({ displayColorPicker: !this.state.displayColorPicker });
    }

    handleClose() {
        this.setState({
            value: "#999",
            displayColorPicker: false
        });
    }

    handleChange(value) {
        const { onChangeAdditional } = this.props;

        onChangeAdditional(value);
        this.setState({
            ...this.state,
            value
        });
        this.handleClose();
    }

    editBlockPicker() {
        const blockPicker = $(".block-picker")[0];

        if (blockPicker) {
            // add style
            const colorsViewer = blockPicker.lastChild;

            colorsViewer.style.overflow = "auto";
            colorsViewer.style.maxHeight = "150px";

            // remove input
            const input = $(blockPicker).find("input");

            if (input[0] && input[0].remove());

            //disable not-use-color
            const colorDivs = $(blockPicker).find("span>div");
            const { notUsedColors } = this.props;

            for (let i = 0; i < colorDivs.length; i++) {

                if (notUsedColors.indexOf(colorDivs[i].title) !== -1) {
                    $(colorDivs[i]).css({
                        textAlign: "center",
                        verticalAlign: "top",
                        lineHeight: "22px",
                        fontSize: "15px",
                        fontWeight: "bold",
                        color: "white"
                    });
                    $(colorDivs[i]).html(
                        "X"
                    );
                    $(colorDivs[i]).off("click");
                    $(colorDivs[i]).on("click", (e) => {
                        e.preventDefault();
                        return false;
                    });
                }
            }
        }
    }

    componentDidMount() {
        this.editBlockPicker();
    }

    componentDidUpdate() {
        this.editBlockPicker();
    }
    render() {
        const styles = {
            main: {
                // position: "relative"
            },
            color: {
                width: "30px",
                height: "30px",
                textAlign: "center",
                lineHeight: "30px",
                fontSize: "30px",
                color: "blue",
                borderRadius: "4px",
                background: "red",
                paddingRight: "2px"
            },
            swatch: {
                display: "inline-block",
                verticalAlign: "top",
                cursor: "pointer"
            },
            popover: {
                position: "relative",
                zIndex: "2",
                maxHeight: "280px",
                overflow: "auto"
                // left: "-36px",
                // top: "15px"
            },
            cover: {
                position: "fixed",
                top: "0px",
                right: "0px",
                bottom: "0px",
                left: "0px"
            },
            colorIcon: {
                // width: "30px",
                // height: "30px",
                // textAlign: "center",
                // lineHeight: "30px",
                // fontSize: "20px",
                // borderRadius: "4px",
                // paddingRight: "2px",
            },
            styleDivIcon: {
                // height: "90px",
                // overflow: "auto"
            }
        };
        const { colors } = this.props;
        let i = 0;
        let tempIcon = "";

        const isContain = (icon) => {
            for (let i = 0; i < this.props.notUsedColors.length; i++) {
                const item = this.props.notUsedColors[i];
                if (item.Color === icon) {
                    return true;
                }

            }
            return false;
        };

        const filteredListIcon = colors.filter((item) => !isContain(item));

        const listColorAdditional = filteredListIcon.map((item, index) => {
            tempIcon = <span key={index}><span className={`lnr ${item} `} key={index} onClick={() => this.handleChange(item)}></span></span>;
            i++;
            if (i % 24 === 0) {
                return (
                    <span key={index}>
                        {tempIcon}
                    </span>
                );
            }
            return (
                <span key={index}>
                    {tempIcon}
                </span>
            );
        });

        return (
            <span style={styles.main} >
                <div style={styles.swatch} onClick={() => this.handleClick()}>
                    <div style={{ marginTop: "10px" }}>
                        <a>More Icons</a>
                    </div>
                </div>
                {this.state.displayColorPicker ?
                    <div style={styles.popover} className="list-icon-wrap" >
                        < div style={styles.styleDivIcon}>
                            {listColorAdditional}
                        </div >
                    </div > : null
                }
            </span >
        );
    }
}

IconPickerAdditional.defaultProps = {
    colors: ICONS_LIST
};

IconPickerAdditional.propTypes = {
    value: PropTypes.string,
    colors: PropTypes.array,
    notUsedColors: PropTypes.array,
    onChange: PropTypes.func,
    onChangeAdditional: PropTypes.func
};

export default IconPickerAdditional;