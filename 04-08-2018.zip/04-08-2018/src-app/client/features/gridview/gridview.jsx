import React from "react";
import GridLine from "./grid-line";
import GridHeader from "./grid-header";
import GridPaginate from "./grid-paginate";
import PropTypes from "prop-types";
import { Component } from "react";
import FilterSelect from "./filter-select";
import FilterDate from "./filter-date";
import Loader from "../loader";

export class GridView extends Component {
    constructor(props) {
        super(props);
        this.state = {
            sortColumn: this.props.criteria.sortColumn,
            sortDirection: this.props.criteria.sortDirection,
            itemPerPage: this.props.criteria.itemPerPage,
            page: this.props.criteria.page,
            allowRowSelect: this.props.allowRowSelect,
            filters: this.props.filters,
            filtersObjects: []
        };
    }

    addFilterRef(node) {
        const { filtersObjects } = this.state;
        filtersObjects.push(node);
    }

    componentWillReceiveProps(nextProps) {
        const { criteria, datasources } = nextProps;
        let { filters } = nextProps;
        //get Data for each column
        const filtersData = {};
        if (datasources[0] !== undefined && datasources[0] !== null) {
            Object.keys(datasources[0]).forEach(column => {
                filtersData[column] = [];
            });
        } else if (filters.length > 0) {
            //reset data for filters when have no datasources
            filters = filters.map(item => {
                item.data = [];
                switch (item.type) {
                    case "FilterSelect":
                        item.filter = <FilterSelect key={`ran_key${item.column}${Math.random()}`} onChangeDirty={isDirty => this.handleChangeDirty(isDirty, item.columnTitle)} onRef={ref => this.addFilterRef(ref)} data={item.data} transformvalue={item.transformvalue} onApply={(selected) => this.handleFilterApply(selected, item.column)} columnTitle={item.columnTitle} onOpen={() => this.handleOpenFilter(item.columnTitle)} />;
                        break;
                    case "FilterDate":
                        item.filter = <FilterDate key={`ran_key${item.column}${Math.random()}`} onChangeDirty={isDirty => this.handleChangeDirty(isDirty, item.columnTitle)} onRef={ref => this.addFilterRef(ref)} data={item.data} transformvalue={item.transformvalue} onApply={(dateState) => this.handleFilterApply(dateState, item.column)} columnTitle={item.columnTitle} onOpen={() => this.handleOpenFilter(item.columnTitle)} />;
                        break;
                }
                return item;
            });
        }
        if (filters.length > 0 && Object.keys(filtersData).length !== 0) {
            datasources.forEach(item => {
                Object.keys(item).forEach(key => {
                    if (filtersData[key].indexOf(item[key]) < 0) {
                        filtersData[key].push(item[key]);
                    }
                });
            });
            filters.forEach(item => {
                if (filtersData[item.column] !== undefined) {
                    item.data = filtersData[item.column].map((itemfilter, key) => {
                        return { key, value: itemfilter, checked: true };
                    }).sort((a, b) => {
                        if (a.value === null) return -1;
                        if (b.value === null) return 1;
                        if (!(isNaN(a.value) || (isNaN(b.value)))) {
                            if (a.value < b.value) return -1;
                            if (a.value > b.value) return 1;
                        } else {
                            if (a.value.toLowerCase() < b.value.toLowerCase()) return -1;
                            if (a.value.toLowerCase() > b.value.toLowerCase()) return 1;
                        }
                        return 0;
                    });
                    switch (item.type) {
                        case "FilterSelect":
                            item.filter = <FilterSelect key={`ran_key${item.column}${Math.random()}`} onChangeDirty={isDirty => this.handleChangeDirty(isDirty, item.columnTitle)} onRef={ref => this.addFilterRef(ref)} data={item.data} transformvalue={item.transformvalue} onApply={(selected) => this.handleFilterApply(selected, item.column)} columnTitle={item.columnTitle} onOpen={() => this.handleOpenFilter(item.columnTitle)} />;
                            break;
                        case "FilterDate":
                            item.filter = <FilterDate key={`ran_key${item.column}${Math.random()}`} onChangeDirty={isDirty => this.handleChangeDirty(isDirty, item.columnTitle)} onRef={ref => this.addFilterRef(ref)} data={item.data} transformvalue={item.transformvalue} onApply={(dateState) => this.handleFilterApply(dateState, item.column)} columnTitle={item.columnTitle} onOpen={() => this.handleOpenFilter(item.columnTitle)} />;
                            break;
                    }
                }
                return item;
            });
        }
        const newState = {
            sortColumn: criteria.sortColumn,
            sortDirection: criteria.sortDirection,
            itemPerPage: criteria.itemPerPage,
            page: criteria.page,
            allowRowSelect: nextProps.allowRowSelect,
            filters,
            filtersObjects: []
        };

        this.setState(newState);
    }

    componentDidUpdate() {
        this.props.cbAfterUpdate();
    }

    componentDidMount() {
        this.props.cbAfterUpdate();
    }

    handleSorting(sortColumn) {
        let sortDirection = this.state.sortDirection;
        if (sortColumn === this.state.sortColumn) {
            sortDirection = !sortDirection;
        }

        this.setState({
            sortColumn,
            sortDirection
        });

        this.props.onGridViewReload({ ...this.state, sortColumn, sortDirection, filters: "", filtersObjects: "" });
    }

    handlePaginateChanged(page, itemPerPage) {
        this.setState({
            page,
            itemPerPage
        });
        this.props.onGridViewReload({ ...this.state, page, itemPerPage, filters: "", filtersObjects: "" });
    }

    handleFilterApply(data, column) {
        let { filters } = this.state;
        filters = filters.map(filter => {
            if (filter.column === column) {
                filter = {
                    ...filter,
                    data
                };
            }
            return filter;
        });
        this.setState({
            filters
        });
    }

    handleOpenFilter(column) {
        const { filtersObjects } = this.state;
        filtersObjects.forEach(element => {
            if (element.props.columnTitle !== column) {
                element.closeTooltip();
            }
        });
    }

    handleChangeDirty(isDirty, column) {
        const { filters } = this.state;
        filters.forEach(element => {
            if (element.columnTitle === column) {
                element.isDirty = isDirty;
            }
        });
    }

    render() {
        const { totalRecords, datasources, columns, actions, identifier, allowSorting, allowRowSelect, displayLength, isLoading } = this.props;
        const { filters } = this.state;
        const self = this;

        const renderGridLines = () => {

            if (datasources.length === 0) {

                const noRecordFoundMessage = "There are no records to show.";

                let colSpan = columns.length;
                if (actions.length > 0) {
                    colSpan += 1;
                }

                return (
                    <tr>
                        <td colSpan={colSpan} className="center">
                            {noRecordFoundMessage}
                        </td>
                    </tr>
                );
            }

            return datasources.filter(item => {
                let isPass = true;
                if (filters !== undefined && filters.length > 0) {
                    filters.forEach(filter => {
                        if (item[filter.column] !== undefined && filter.data !== undefined) {
                            const matchData = filter.data.filter(f => f.value === item[filter.column]);
                            if (matchData.length > 0 && !matchData[0].checked) {
                                isPass = false;
                            }
                        }
                    });
                }
                return isPass;
            }).map((data, i) => {
                return (
                    <GridLine displayLength={displayLength}
                        onRowClick={(rowData) => { this.props.onRowClick(rowData); }}
                        onCustomActionClick={(action, id) => { this.props.onActionClick(action, id); }}
                        onActionClick={(action) => { this.props.onActionClick(action, data[identifier]); }}
                        onCheckboxClick={(value, column) => this.props.onCheckboxClick(data[identifier], value, column)}
                        key={i} rownumber={i} data={data} columns={columns} actions={actions} allowRowSelect={allowRowSelect}
                    />
                );
            });
        };

        const renderGridPaginate = function () {
            if (self.props.allowPaging && totalRecords > 0) {
                return (
                    <GridPaginate onPaginateChanged={self.handlePaginateChanged.bind(self)} totalRecords={totalRecords} {...self.props.criteria} />
                );
            }
            return null;
        };

        return (
            <div>
                <Loader isShow={isLoading}>
                    <table className="striped highlight responsive-table">
                        <GridHeader onSorting={this.handleSorting.bind(this)} allowSorting={allowSorting}
                            columns={columns} actions={actions} sortColumn={this.state.sortColumn}
                            sortDirection={this.state.sortDirection} actionHeader={this.props.actionHeader}
                            filters={filters}
                        />
                        <tbody>
                            {renderGridLines()}
                        </tbody>
                    </table>
                    {renderGridPaginate()}
                </Loader>
            </div>
        );
    }
}


GridView.defaultProps = {
    datasources: [],
    columns: [],
    filters: [],
    actions: [],
    allowPaging: true,
    allowSorting: true,
    totalRecords: 0,
    isUseNoRecordFoundSearchMessage: false,
    allowRowSelect: false,
    displayLength: 60,
    cbAfterUpdate: () => { },
    clientPaging: false
};

GridView.propTypes = {
    datasources: PropTypes.array,
    columns: PropTypes.array,
    filters: PropTypes.array,
    actions: PropTypes.arrayOf(PropTypes.string),
    identifier: PropTypes.string,
    defaultSortColumn: PropTypes.string,
    allowSorting: PropTypes.bool,
    onActionClick: PropTypes.func,
    onCustomActionClick: PropTypes.func,
    onCheckboxClick: PropTypes.func,
    allowPaging: PropTypes.bool,
    onGridViewReload: PropTypes.func,
    onGridViewChangeFilters: PropTypes.func,
    totalRecords: PropTypes.number,
    criteria: PropTypes.object,
    noRecordFoundStr: PropTypes.string,
    isUseNoRecordFoundSearchMessage: PropTypes.bool,
    allowRowSelect: PropTypes.bool,
    actionHeader: PropTypes.string,
    agentCustomAction: PropTypes.bool,
    displayLength: PropTypes.number,
    onRowClick: PropTypes.func,
    isLoading: PropTypes.bool,
    cbAfterUpdate: PropTypes.func,
    clientPaging: PropTypes.bool
};

export default GridView;