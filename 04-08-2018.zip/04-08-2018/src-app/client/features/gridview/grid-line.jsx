import React from "react";
import moment from "moment";
import { thousandSep } from "Helpers/common-helper";
import { getDirectionFromAddresses } from "Helpers/location-helper";
import { Link } from "react-router";
import { bufferToBoolean } from "Helpers/common-helper";
import PropTypes from "prop-types";
import { Component } from "react";
import ReactTooltip from "react-tooltip";
import { ORDER_DETAIL_STAGE, ORDER_DETAIL_PROGRESS } from "./../../constant/order-detail-constants";
import { SERVICE_CONFIG_STATUS } from "../../constant/constants";
import { LIST_TIMEZONE_US } from "./../../constant/constants";
import DetailFeeToolTip from "./../../screens/vendor-offer-management/components/detail-fee-tooltip";
import { hasStringValue } from "../../helpers/validation-helper";

export const styleVendorCat = (icon) => {
    return {
        border: "1px solid #b8d54a",
        background: "#b8d54a",
        textAlign: "center",
        padding: "0px",
        lineHeight: "30px",
        marginRight: "5px",
        backgroundColor: `#${icon}`, width: "30px", height: "30px",
        display: "inline-block", borderRadius: "50%"
    };
};

export class GridLine extends Component {

    showGoogleMaps(data) {
        // const url = getDirectionFromAddresses(`${data.vendorLat},${data.vendorLong}`, `${data.orderLat},${data.orderLong}`);
        const url = getDirectionFromAddresses(`${data.vendorAddress}`, `${data.orderAddress}`);
        window.open(url, "", "width=800,height=600,top=100,left=200");
    }

    render() {
        const self = this;
        const { data, columns, actions, rownumber, allowRowSelect, displayLength } = this.props;

        const renderCells = function () {
            return columns.map((column, cellId) => {
                switch (column.type) {
                    case "customize":
                        return column.render(self, data, cellId);
                    case "checkbox":
                        return (
                            <td key={cellId}>
                                <label>
                                    <input type="checkbox" readOnly="readOnly" checked={data[column.data]} />
                                    <span></span>
                                </label>
                            </td>
                        );
                    case "checkboxClosed":
                        return (
                            <td key={cellId}>
                                <label>
                                    <input type="checkbox" readOnly="readOnly" checked={data[column.data]} />
                                    <span>Closed</span>
                                </label>
                            </td>
                        );
                    case "checkboxChange":
                        return (
                            <td key={cellId} className="center-align">
                                <label>
                                    <input disabled={data.isDisabled ? "disabled" : ""} type="checkbox" style={{ width: "100%" }} checked={data[column.data]} onChange={(e) => self.props.onCheckboxClick(e.target.checked, column.data)} />
                                    <span></span>
                                </label>
                            </td >
                        );
                    case "correctionRequest":
                        return (
                            <td key={cellId}>
                                <a key={`${cellId}_${column.id}`} onClick={() => self.props.onActionClick("review")}>{data[column.data]}</a>
                            </td >
                        );
                    case "checkboxDisable":
                        return (
                            <td key={cellId} className="center-align">
                                <label>
                                    <input disabled type="checkbox" style={{ width: "100%" }} checked={data[column.data]} />
                                    <span></span>
                                </label>
                            </td >
                        );
                    case "money":
                        {
                            let money = ``;
                            if (data[column.data] !== null && data[column.data] !== undefined && data[column.data] !== "") {
                                money = `$${thousandSep(parseFloat(data[column.data]).toFixed(2))
                                    }`;
                            }
                            return (
                                <td key={cellId} className="center-align">{money}</td>
                            );
                        }
                    case "datetime":
                        {
                            let format = "MM/DD/YY h:mm:ss A";
                            if (column.format) {
                                format = column.format;
                            }
                            let date = "N/A";
                            if (data[column.data]) {
                                date = moment(data[column.data]).format(format);
                            } else if (column.defaultIsCurrent) {
                                date = moment().format(format);
                            }
                            return (
                                <td key={cellId}>{date}</td>
                            );
                        }
                    case "datetimeUtc":
                        {
                            let date = "N/A";
                            if (data[column.data]) {
                                date = moment(data[column.data]).utc().format("MM/DD/YY h:mm:ss A");
                            }
                            return (
                                <td key={cellId}>{date}</td>
                            );
                        }
                    case "date":
                        {
                            let format = "MM/DD/YYYY";
                            if (column.format) {
                                format = column.format;
                            }
                            let date = "N/A";
                            if (data[column.data]) {
                                date = moment(data[column.data]).format(format);
                            } else if (column.defaultIsCurrent) {
                                date = moment().format(format);
                            }

                            return (
                                <td key={cellId}>{`${date === "Invalid date" ? "N/A" : date}`}</td>
                            );
                        }
                    case "time":
                        {
                            return (
                                <td key={cellId}>{`${(data[column.data] === "Invalid date") ? "N/A" : data[column.data]}`}</td>
                            );
                        }
                    case "dateRange":
                        {
                            return (
                                <td key={cellId}>{`${(data[column.data] === null || data[column.data] === undefined) ? "N/A" : data[column.data]}`}</td>
                            );
                        }
                    case "datetimezone":
                        {
                            let dateString = "";
                            let timeZoneAbv = "";
                            if (data[column.data]) {
                                if (data.AptUtc || data.aptUtc) {
                                    const timezone = data.AptUtc || data.aptUtc;
                                    timeZoneAbv = LIST_TIMEZONE_US.map((item) => {
                                        if (timezone && item.UTC === timezone.toString()) {
                                            return item.abv;
                                        }
                                        return "";
                                    });
                                }
                                const date = moment(data[column.data]).utc();
                                dateString = `${date.isValid() ? `${date.format("MMM D YYYY, h:mm A")}` : ""}`;
                            }
                            return (
                                <td key={cellId}>{dateString} {timeZoneAbv}</td>
                            );
                        }
                    case "countdowntime":
                        {
                            if (data[column.data]) {
                                const diffTime = data[column.data].split(":");
                                if (parseInt(diffTime[0]) > 0) {
                                    const diffDay = Math.round(parseInt(diffTime[0]) / 24);
                                    if (diffDay >= 0 && diffDay <= 2) return <td key={cellId} className="red-text text-darken-2">in {parseInt(diffTime[0])} {parseInt(diffTime[0]) === 1 ? "hour" : "hours"}</td>;
                                    if (diffDay > 2 && diffDay <= 5) return <td key={cellId} className="orange-text text-darken-2">in {`${diffDay} days`}</td>;
                                    if (diffDay > 5) return <td key={cellId}>in {diffDay} days</td>;
                                    return <td key={cellId}>in {parseInt(diffTime[0])} hours</td>;
                                }
                            }
                            return <td key={cellId}>&nbsp;</td>;
                        }
                    case "countdownday":
                        {
                            if (data[column.data] !== null) {
                                let strCount = "";
                                if (parseInt(data[column.data]) === 0) strCount = "Today";
                                if (parseInt(data[column.data]) === 1) strCount = "Yesterday";
                                if (parseInt(data[column.data]) > 1) strCount = `${parseInt(data[column.data])} days ago`;
                                return <td key={cellId}>{strCount}</td>;
                            }
                            return <td key={cellId}>&nbsp;</td>;
                        }
                    case "stage":
                        {
                            if (column.Status !== undefined && (data[column.Status] === null)) {
                                return <td key={cellId}><Link key={cellId} onClick={() => window.clientAddNewOrder(false)}>{column.id === undefined ? `Incomplete` : `Complete`}</Link></td>;
                            }
                            if (data[column.data]) {
                                if (parseInt(data[column.data]) < 13) {
                                    const Step = ORDER_DETAIL_PROGRESS[parseInt(data[column.data])].name;
                                    const Stage = ORDER_DETAIL_STAGE[ORDER_DETAIL_PROGRESS[data[column.data]].stageId].name;
                                    if (column.id !== undefined && ORDER_DETAIL_PROGRESS[data[column.data]].stageId === 5) {
                                        return <td key={cellId}>&nbsp;</td>;
                                    } else {
                                        return (
                                            <td key={cellId}>
                                                <b>{Stage}: <br /></b> {data[column.id] !== undefined ? <Link key={`${cellId}_${column.id}`} to={`/order-detail/${data[column.id]}`}>{Step}</Link> : Step}
                                            </td>
                                        );
                                    }
                                } else {
                                    return <td key={cellId}>&nbsp;</td>;
                                }
                            }
                            return <td key={cellId}>&nbsp;</td>;
                        }
                    case "next-action":
                        {
                            if (data[column.data]) {
                                if (parseInt(data[column.data]) < 13) {
                                    const Step = ORDER_DETAIL_PROGRESS[parseInt(data[column.data])].name;
                                    let nextAction = "";
                                    switch (Step) {
                                        case "Open":
                                            nextAction = "Order assigned";
                                            break;
                                        case "Assigned to Vendor":
                                            nextAction = "Signer is contacted and appointment confirmed";
                                            break;
                                        case "Appt Confirmed Pending Docs":
                                            nextAction = "Once documents received and printed by vendor";
                                            break;
                                        case "Pending Pre-call":
                                            nextAction = "Pre-call made to vendor";
                                            break;
                                        case "Appt Ready":
                                            nextAction = "Awaiting Status update from Vendor";
                                            break;
                                        case "Closed Pending Review/PC Resolution":
                                            nextAction = "Client or TCE staff approves status as closed or did not close";
                                            break;
                                        case "Closed Pending QC Review":
                                            nextAction = "Reviewed by Client or TCE staff, approves status as closed";
                                            break;
                                        case "Closing Completed":
                                            nextAction = "";
                                            break;
                                        case "Post Close":
                                            nextAction = "Client identified issues and is requesting corrections/resolution to issues";
                                            break;
                                        case "Hold":
                                        case "Canceled":
                                        case "Unsuccessful signing attempt":
                                            nextAction = "";
                                            break;
                                    }
                                    return (
                                        <td key={cellId}>{nextAction}</td>
                                    );
                                } else {
                                    return <td key={cellId}>&nbsp;</td>;
                                }
                            }
                            return <td key={cellId}>&nbsp;</td>;
                        }
                    case "orderid_colorbind":
                        {
                            const getColor = () => {
                                const current = moment();
                                const commentDate = moment(data.CommentDate);
                                const localAptTime = moment(data.AptDateTime);
                                const Progress = data.Status;
                                let color = "#006CA9";

                                const condition1 = (current < localAptTime && (commentDate.diff(current, "minutes") < -120));
                                if (condition1 && (Progress === "Appt Confirmed Pending Docs" || Progress === "Open" || Progress === "Pending Pre-call" || Progress === "Assigned to Vendor")) {
                                    color = "#f1c40f"; //yellow
                                } else if (data.Rep === null || data.Rep === "Open") {
                                    color = "#ff6600"; //orange
                                } else if (data.signerId === null) {
                                    color = "#b1b069";//light yellow
                                }

                                return color;
                            };

                            return (
                                <td key={cellId} ><Link style={{ color: getColor(), cursor: "pointer" }} onClick={() => self.props.onActionClick(column.action)}>{data[column.data]}</Link></td>
                            );
                        }
                    case "orderDetailClientLink":
                        {
                            const getColor = () => {
                                const current = moment();
                                const commentDate = moment(data.CommentDate);
                                const localAptTime = moment(data.AptDateTime);
                                const Progress = data.Status;
                                let color = "#006CA9";

                                const condition1 = (current < localAptTime && (commentDate.diff(current, "minutes") < -120));
                                if (condition1 && (Progress === "Appt Confirmed Pending Docs" || Progress === "Open" || Progress === "Pending Pre-call" || Progress === "Assigned to Vendor")) {
                                    color = "#f1c40f"; //yellow
                                } else if (data.Rep === null || data.Rep === "Open") {
                                    color = "#ff6600"; //orange
                                } else if (data.signerId === null) {
                                    color = "#b1b069";//light yellow
                                }

                                return color;
                            };
                            if (column.Status !== undefined && (data[column.Status] === null)) {
                                return <td key={cellId}><a key={cellId} onClick={() => window.clientAddNewOrder()}>{data[column.data]}</a></td>;
                            } else {
                                return (
                                    <td key={cellId}><Link style={{ color: getColor() }} key={cellId} to={`/order-detail/${data[column.id]}`}>{data[column.data]}</Link></td>
                                );
                            }
                        }
                    case "tcefill":
                        {
                            const getTCEColor = () => {
                                let color = "";
                                if (data[column.data] <= 30) {
                                    color = "#2ecc71";
                                } else if (data[column.data] <= 60) {
                                    color = "#f1c40f";
                                } else if (data[column.data] <= 500) {
                                    color = "#ff6600";
                                } else {
                                    color = "#222";
                                }

                                return { color };
                            };

                            return (
                                <td key={cellId} ><span style={getTCEColor()}>{data[column.data]}</span></td>
                            );
                        }
                    case "colorDocs":
                        {
                            const getColor = () => {
                                let backgroundColor = "";
                                if (data[column.data] === "Y") {
                                    backgroundColor = "#2ecc71";
                                }

                                return { backgroundColor };
                            };

                            return (
                                <td key={cellId} style={getColor()} ><span>{data[column.data]}</span></td>
                            );
                        }
                    case "colorFB":
                        {
                            const getColor = () => {
                                let backgroundColor = "";
                                if (data[column.data] === "Y") {
                                    backgroundColor = "#FF0000";
                                }

                                return { backgroundColor };
                            };

                            return (
                                <td key={cellId} style={getColor()} ><span>{data[column.data]}</span></td>
                            );
                        }
                    case "colorFBDocs":
                        {
                            const getColor = () => {
                                let backgroundColor = "";
                                if (data[column.data] === "Y") {
                                    backgroundColor = "#0000FF";
                                }

                                return { backgroundColor };
                            };

                            return (
                                <td key={cellId} style={getColor()} ><span>{data[column.data]}</span></td>
                            );
                        }
                    case "link":
                        return (<td key={cellId}><a style={{ cursor: "pointer" }} onClick={() => self.props.onActionClick(column.action)}>{data[column.data]}</a></td>);
                    case "rownumber":
                        return (<td key={cellId}>{rownumber + 1}</td>);
                    case "rowNumberCenter":
                        return (<td key={cellId} className="center-align">{data[column.data]}</td>);
                    case "phone":
                        {
                            const phone = data[column.data];
                            if (phone && phone.length === 10) {
                                const phoneFormated = `(${phone.substr(0, 3)}) ${phone.substr(3, 3)}-${phone.substr(6, 4)}`;
                                return (<td key={cellId}>{phoneFormated}</td>);
                            } else {
                                return (<td key={cellId}>{data[column.data]}</td>);
                            }
                        }
                    case "signerLink": {
                        const vendorId = data.vendorId || data.signerId || data.SignerId;
                        return (
                            <td key={cellId}><a key={cellId} href={`/vendor-profile/${vendorId}`} target="_blank">{data[column.data]}</a></td>
                        );
                    }
                    case "assignVendorLink": {
                        const vendorId = data.vendorId || data.signerId || data.SignerId;
                        const orderId = data.orderId || data.OrderId || data.OrderId;
                        return (
                            <td key={cellId}><a key={cellId} href={`/vendor-profile/${vendorId}/${orderId}`} target="_blank">{data[column.data]}</a></td>
                        );
                    }
                    case "vendorLink": {
                        const vendorId = data.vendorId || data.signerId || data.SignerId;
                        return (
                            <td key={cellId}><a key={cellId} href={`/vendor-profile/${vendorId}`} target="_blank">{data[column.data]}</a></td>
                        );
                    }
                    case "messageIDLink": {
                        return (
                            <td key={cellId}><a key={cellId} role="button" onClick={() => self.props.onActionClick("viewMessage")}>{data[column.data]} </a></td>
                        );
                    }
                    case "messageReadLink": {
                        return (
                            <td key={cellId} className={data.isRead === 0 ? `mark-message-read` : "mark-message-unread"}>
                                <a key={cellId} role="button" onClick={() => self.props.onActionClick("changeStatus")}>{data.isRead === 0 ? "Mark As Read" : "Mark As UnRead"} </a>
                            </td>
                        );
                    }
                    case "ActionDocs": {
                        return (
                            <td key={cellId}>
                                <button className="btn btn-s-small standard-color mr-1" title="View" onClick={() => self.props.onActionClick("view")}><span className="lnr lnr-eye"></span></button>
                            </td>
                        );
                    }
                    case "orderLink":
                        {
                            return (
                                <td key={cellId}><Link key={cellId} to={`/order-detail/${data[column.data]}`}>{data[column.data]}</Link></td>
                            );
                        }
                    case "orderLinkWithOrderId":
                        {
                            return (
                                <td key={cellId}><Link key={cellId} to={`/order-detail/${data[column.data]}`}>Order Id: {data[column.data]}</Link></td>
                            );
                        }
                    case "vendorNameLink": {
                        return (
                            // eslint-disable-next-line
                            <td key={cellId}><Link key={cellId} onClick={() => alert(`Information ${data[column.data]}`)}>{data[column.data]}</Link></td>
                        );
                    }
                    case "download": {
                        return (
                            <td key={cellId}>
                                <button className="btn btn-s-small default-color mr-1" title="Download" onClick={() => self.props.onActionClick("download")}><span className="lnr lnr-download"></span></button>
                            </td>
                        );
                    }
                    case "orderDetailLink":
                        {
                            return (
                                <td key={cellId}><Link key={cellId} to={`/order-detail/${data[column.id]}`}>{data[column.data]}</Link></td>
                            );
                        }
                    case "problemLink":
                        {
                            return (
                                <td key={cellId}><a key={cellId} role="button" onClick={() => self.props.onActionClick("problemLink")}>{data[column.data]}</a></td>
                            );
                        }
                    case "client-action":
                        {
                            const inActive = data.Inactive;
                            return (
                                <td key={cellId}>
                                    <button className="btn btn-s-small success-color mr-1" title="Edit" onClick={() => self.props.onActionClick("edit")}><span className="lnr lnr-pencil"></span></button>
                                    <button className="btn btn-s-small error-color mr-1" title={inActive ? "UnLock" : "Lock"} onClick={() => self.props.onActionClick("changeStatus")}><span className={inActive ? "ti-unlock" : "ti-lock"}></span></button>
                                </td>
                            );
                        }
                    case "order-offer-status-action":
                        {
                            const offerStatus = data.OfferStatus;
                            const style = { width: "15%" };
                            switch (offerStatus) {
                                case "A":
                                    return (<td style={style}>Accepted</td>);
                                case "D":
                                    return (<td style={style}>Declined</td>);
                                case "E":
                                    return (<td style={style}>Expired</td>);
                                case "M":
                                    return (<td style={style}>Missed</td>);
                                case "P":
                                    return (<td style={style}>Pending</td>);
                                default:
                                    return (
                                        <td style={style} key={cellId}>
                                            <button className="btn btn-s-small success-color mr-1" onClick={() => self.props.onActionClick("accepted")}>Accept</button>
                                            <button className="btn btn-s-small error-color mr-1" onClick={() => self.props.onActionClick("declined")}>Decline</button>
                                        </td>
                                    );
                            }
                        }
                    case "training-programs-action":
                        {
                            const inactive = data.inactive;
                            const isPublished = data.isPublished;
                            const isTestTaken = data.isTestTaken === "Yes";
                            const isCourseTaken = data.isCourseTaken === "Yes";
                            return (
                                <td key={cellId} style={{ width: "15%" }}>
                                    <button onClick={() => self.props.onActionClick("ViewEdit")} className="btn btn-s-small success-color mr-1">{isPublished ? <span className="lnr lnr-eye" title="View"></span> : <span className="lnr lnr-pencil" title="Edit"></span>}</button>
                                    <button disabled={(isTestTaken || isCourseTaken)} onClick={() => self.props.onActionClick("Publish")} className="btn btn-s-small standard-color mr-1">{isPublished ? <span className="ti-cloud-down" title="UnPublish"></span> : <span className="ti-cloud-up" title="Publish"></span>}</button>
                                    {inactive ? <button onClick={() => self.props.onActionClick("Delete")} className="btn btn-s-small error-color mr-1"><span className="lnr lnr-trash" title="Delete"></span></button> : ""}
                                </td >
                            );
                        }
                    case "training-programs-trainee-action":
                        {
                            const vendor = data.forVendor ? "Vendor" : "";
                            const staff = data.forStaff ? "Staff" : "";
                            const trainee = (vendor === "Vendor" && staff === "Staff") ? vendor.concat(", ", staff) : vendor.concat(staff);

                            return (
                                <td key={cellId}>
                                    {trainee}
                                </td>
                            );
                        }
                    case "OrderIDHovered":
                        {
                            const bilingual = data.Bilingual ? "Bilingual" : "Not required Bilingual";
                            const scanbacks = data.Scanbacks ? "Scan backs required" : "Scan backs not required";

                            return (
                                <td key={cellId} title={bilingual.concat("\n", scanbacks)}>
                                    {data.OrderID}
                                </td>
                            );
                        }
                    case "distance":
                        {
                            let distance = data.distance;
                            if (distance !== null && distance !== undefined && distance !== "") {
                                distance = `${thousandSep(parseFloat(distance).toFixed(2))} Miles`;
                            }

                            return (
                                <td key={cellId}><a role="button" onClick={() => self.showGoogleMaps(data)}>{distance}</a></td>
                            );
                        }
                    case "specialties":
                        {
                            const categories = data.vendorGroupsColor;
                            if (categories === null) {
                                return (<td key={cellId} style={{ padding: "0px" }}></td>);
                            } else {
                                const specialties = categories.split(";");

                                specialties.sort();
                                specialties.map((item, index) => {
                                    if (item === "crown") {
                                        specialties.splice(index, 1);
                                        specialties.unshift(item);
                                    }
                                });

                                const renderSpecialties = specialties.map((item, index) => {
                                    return (
                                        <span key={index} style={styleVendorCat()}>
                                            <span className={`lnr ${item} center-align`}></span>
                                        </span>
                                    );
                                });
                                return (
                                    <td key={cellId}>
                                        {renderSpecialties}
                                    </td >
                                );
                            }
                        }
                    case "branch-action":
                        {
                            const inActive = data.Inactive;
                            return (
                                <td key={cellId}>
                                    <button onClick={() => self.props.onActionClick("edit")} className="btn btn-s-small success-color mr-1"><span data-tip data-for="branch-edit" className="lnr lnr-pencil"></span><ReactTooltip id="branch-edit" aria-haspopup="true" role="example">
                                        <p>Edit</p>
                                    </ReactTooltip></button>
                                    {inActive !== "Active" ? <button onClick={() => self.props.onActionClick("activate")} title="Activate" className="btn btn-s-small error-color mr-1"><span data-tip data-for="branch-disable" className="ti-unlock"></span></button> :
                                        <button onClick={() => self.props.onActionClick("disable")} title="Deactivate" className="btn btn-s-small error-color mr-1"><span data-tip data-for="branch-disable" className="ti-lock"></span></button>}
                                </td>
                            );
                        }

                    case "hasAlterData":
                        return (
                            <td key={cellId}>{data[column.data] || data[column.alterData]}</td>
                        );

                    case "userStatus":
                        {
                            const getUserStatusColor = () => {
                                let color = "";
                                if (data[column.data] === "Offline") {
                                    color = "#282828";
                                } else if (data[column.data] === "Available") {
                                    color = "#0DCF0D";
                                } else if (data[column.data] === "Do Not Disturb") {
                                    color = "#FF2727";
                                } else {
                                    color = "#222";
                                }

                                return { color };
                            };

                            return (
                                <td key={cellId} ><span style={getUserStatusColor()}>{data[column.data]}</span></td>
                            );
                        }

                    case "agent-action":
                        {
                            const inActive = data.Inactive;
                            return (
                                <td key={cellId}>
                                    <div className="row">
                                        <button type="button" onClick={() => self.props.onActionClick("Edit")} title="Edit" className="btn btn-s-small success-color mr-1"><span className="lnr lnr-pencil"></span></button>
                                        {inActive ? <button onClick={() => self.props.onActionClick("Activate")} title="Activate" className="btn btn-s-small error-color mr-1"><span className="ti-lock"></span></button> :
                                            <button type="button" onClick={() => self.props.onActionClick("Disable")} title="Deactivate" className="btn btn-s-small default-color mr-1"><span className="ti-unlock"></span></button>}
                                    </div>
                                </td>
                            );
                        }
                    case "training-course-action":
                        {
                            const isActive = data.isActive;
                            const isActiveProgram = data.isActiveProgram;
                            const isPublished = data.isPublishedProgram === "Y";
                            return (
                                <td key={cellId}>
                                    {isPublished ? <button className="btn btn-s-small success-color mr-1" title="View" onClick={() => self.props.onActionClick("view")}><span className="ti-eye"></span></button> :
                                        <button className="btn btn-s-small success-color mr-1" title="Edit" onClick={() => self.props.onActionClick("edit")}><span className="lnr lnr-pencil"></span></button>}
                                    <span title={isActive ? "Activate" : "Deactivate"}><button className="btn btn-s-small success-color mr-1" onClick={() => self.props.onActionClick("changeStatus")} disabled={isActiveProgram}><span className={isActive ? "ti-unlock" : "ti-lock"}></span></button></span>
                                    {<span title="Delete"><button className="btn btn-s-small error-color mr-1" onClick={() => self.props.onActionClick("delete")} disabled={isActiveProgram}><span className="lnr lnr-trash"></span></button></span>}
                                </td>
                            );
                        }
                    case "training-test-maker-actions":
                        {
                            const isActiveTest = data.isActive === "Y";
                            const isProgramTestActive = data.isProgramActive === "Y";
                            const isPublishedTest = data.published === "Y";
                            const isDefaultTest = data.defaultTest;
                            return (
                                <td key={cellId}>
                                    <span title="Edit" >
                                        <button disabled={isPublishedTest ? "disabled" : ""} className="btn btn-s-small success-color mr-1" onClick={() => self.props.onActionClick("edit")}><span className="lnr lnr-pencil"></span></button>
                                    </span>
                                    <span title="Preview" >
                                        <button className="btn btn-s-small success-color mr-1" onClick={() => self.props.onActionClick("review")}><span className="ti-eye"></span></button>
                                    </span>
                                    <span title={isActiveTest ? "Deactivate" : "Activate"} >
                                        <button disabled={isProgramTestActive || isDefaultTest ? "disabled" : ""} className="btn btn-s-small success-color mr-1" onClick={() => self.props.onActionClick("setActive")} ><span className={isActiveTest ? "ti-lock" : "ti-unlock"}></span></button>
                                    </span>
                                    <span title="Delete" >
                                        <button disabled={isProgramTestActive || isDefaultTest ? "disabled" : ""} className="btn btn-s-small error-color mr-1" onClick={() => self.props.onActionClick("delete")}><span className="lnr lnr-trash"></span></button>
                                    </span>
                                </td>
                            );
                        }
                    case "order-docs-delete":
                        {
                            const canDelete = data.canDelete;
                            return (
                                <td key={cellId}>
                                    <button disabled={!canDelete ? "disabled" : ""} title="Delete" onClick={() => self.props.onActionClick("delete")} className="btn btn-s-small error-color"><span className="lnr lnr-trash"></span></button></td>
                            );
                        }
                    case "order-docs-action":
                        {
                            const hasPermission = data.hasPermission;
                            const canDelete = data.canDelete;
                            const isDisable = data.Status === "Open" || data.Status === "Approved" || data.Status === "Rejected";
                            return (
                                <td key={cellId}>
                                    {hasPermission ?
                                        <div>
                                            <button className="btn btn-s-small success-color" disabled={isDisable ? "disabled" : ""} title="Approve" onClick={(action, id) => self.props.onActionClick("approve", id)}><span className="lnr lnr-thumbs-up"></span></button>
                                            <button className="btn btn-s-small error-color" disabled={isDisable ? "disabled" : ""} title="Reject" onClick={(action, id) => self.props.onActionClick("reject", id)}><span className="lnr lnr-thumbs-down"></span></button>
                                            <button className="btn btn-s-small default-color" disabled={isDisable ? "disabled" : ""} title="Approve With" onClick={(action, id) => self.props.onActionClick("approveWith", id)}><span className="lnr lnr-thumbs-up"></span></button>
                                        </div> : ""
                                    }
                                    <button className="btn btn-s-small error-color" disabled={!canDelete ? "disabled" : ""} title="Delete" onClick={(action, id) => self.props.onActionClick("delete", id)}><span className="lnr lnr-trash"></span></button></td>
                            );
                        }
                    case "test-vendor-docs-action":
                        {
                            const download = data.documentAction;
                            return (
                                <td key={cellId}>
                                    {download ? <i style={{ cursor: "pointer" }} onClick={() => self.props.onActionClick("Download")} className="small material-icons">file_download</i> : ""}
                                    {(download !== "" && !download) ? <i style={{ cursor: "pointer" }} onClick={() => self.props.onActionClick("Delete")} className="small material-icons">clear</i> : ""}
                                </td>
                            );
                        }
                    case "order-vendor-sent-offer-list-action":
                        {
                            const isShow = data.OfferStatus === "No Response";

                            return (
                                <td key={cellId}>
                                    {isShow ?
                                        <button
                                            className="btn btn-s-small standard-color"
                                            title="Resend"
                                            onClick={(action, id) => self.props.onActionClick("resend", id)}
                                        >
                                            <span className="">Resend</span>
                                        </button> : ""}
                                </td>
                            );
                        }
                    case "announcement-action":
                        {
                            const status = data.Status;
                            const PUBLISH_ICON = "ti-cloud-up";
                            const btnPublish = "Publish";
                            const btnUnpublish = "Unpublish";
                            const UNPUBLISH_ICON = "ti-cloud-down";
                            const iconCLassName = status === "Published" ? UNPUBLISH_ICON : PUBLISH_ICON;
                            const btnAction = status === "Published" ? btnUnpublish : btnPublish;
                            return (
                                <td key={cellId}>
                                    <button onClick={(action, id) => self.props.onActionClick("Edit", id)} title="Edit" className="btn btn-s-small success-color mr-1"> <span className="lnr lnr-pencil"></span></button>
                                    <button onClick={(action, id) => self.props.onActionClick(btnAction, id)} title={btnAction} className="btn btn-s-small standard-color mr-1"><span className={iconCLassName}></span></button>
                                    <button onClick={(action, id) => self.props.onActionClick("Delete", id)} title="Delete" className="btn btn-s-small error-color mr-1"><span className="lnr lnr-trash"></span></button>
                                </td >
                            );
                        }
                    case "delete-client-document-action": {
                        return (
                            <td key={cellId}>
                                <button title="Delete" onClick={() => self.props.onActionClick("delete")} className="btn btn-s-small error-color"><span className="lnr lnr-trash"></span></button></td>
                        );
                    }
                    case "service-config-status": {
                        if (Number(data[column.data]) === SERVICE_CONFIG_STATUS.Approved.code) {
                            return (<td key={cellId}>{SERVICE_CONFIG_STATUS.Approved.description}</td>);
                        } else if (Number(data[column.data]) === SERVICE_CONFIG_STATUS.Closed.code) {
                            return (<td key={cellId}>{SERVICE_CONFIG_STATUS.Closed.description}</td>);
                        } else {
                            return (<td key={cellId}>{SERVICE_CONFIG_STATUS.Open.description}</td>);
                        }
                    }

                    case "vendor-list-view-docs-action": {
                        return (
                            <td key={cellId}>
                                <button className="btn btn-s-small success-color mr-1" title="View Docs" onClick={() => self.props.onActionClick("view-docs")}><span className="ti-eye"></span></button></td>
                        );
                    }

                    case "vendor-list-view-notes-action": {
                        return (
                            <td key={cellId}>
                                <button className="btn btn-s-small success-color mr-1" title="View Note" onClick={() => self.props.onActionClick("view-notes")}><span className="ti-eye"></span></button></td>
                        );
                    }

                    case "vendor-list-action": {
                        return (
                            <td key={cellId}>
                                <button className="btn btn-s-small success-color mr-1" title="Deactivate" onClick={() => self.props.onActionClick("deActivate")} ><span className="ti-lock"></span></button></td>
                        );
                    }
                    case "deleteReturnAddressAction": {
                        return (
                            <td key={cellId}>
                                <button className="btn btn-s-small error-color mr-1" disabled={data.DefaultAddr ? "disabled" : ""} title="Delete" onClick={() => self.props.onActionClick("delete")} ><span className="lnr lnr-trash"></span></button></td>
                        );
                    }

                    case "radioChange":
                        return (
                            <td key={cellId}>
                                <label>
                                    <input disabled={data.isDisabled ? "disabled" : ""} className="with-gap" type="radio" style={{ width: "100%" }} checked={data[column.data]} onChange={(e) => self.props.onCheckboxClick(e.target.checked, column.data)} />
                                    <span></span>
                                </label>
                            </td >
                        );

                    case "taxId":
                        {
                            const taxId = `${data.taxId}`;
                            let taxStr = ``;
                            for (let i = 0; i < taxId.length; i++) {
                                if (i + 4 > taxId.length - 1) {
                                    taxStr = `${taxStr}${taxId.charAt(i)}`;
                                } else {
                                    taxStr = `${taxStr}*`;
                                }
                            }

                            return (
                                <td key={cellId}>{taxStr}</td>
                            );
                        }
                    case "Acknowledged":
                        {
                            const acknowledged = data.Acknowledged;
                            return (
                                <td key={cellId}>
                                    {acknowledged ? "Yes" : "No"}
                                </td >
                            );
                        }
                    case "Viewed":
                        {
                            const viewed = data.Viewed;
                            return (
                                <td key={cellId}>
                                    {viewed ? "Read" : "Unread"}
                                </td >
                            );
                        }
                    case "detailFeeLink": {
                        const offerID = data.OfferID;
                        let money = ``;
                        if (data[column.data] !== null && data[column.data] !== undefined && data[column.data] !== "") {
                            money = `$${thousandSep(parseFloat(data[column.data]).toFixed(2))
                                }`;
                        }

                        return (<td key={cellId}>
                            <div className="vendor-tooltip">
                                <ReactTooltip className="p-0" globalEventOff="click" event="click" place="right" id={`vendor-tooltip-id:${offerID}`} aria-haspopup="true" role="example" allow>
                                    <DetailFeeToolTip orderId={data.OrderID} />
                                </ReactTooltip>
                            </div>
                            <span style={{ cursor: "pointer", color: "#006CA9" }} data-for={`vendor-tooltip-id:${offerID}`} data-tip key={`vendor-tooltip-link-key:${cellId}`}>{money}</span>
                        </td >);
                    }
                    case "bufferBoolean":
                        {
                            return (
                                <td key={cellId}>
                                    {bufferToBoolean(data[column.data]) ? "Yes" : "No"}
                                </td >
                            );
                        }
                    case "client-problem-action":
                        {
                            return (
                                <td key={cellId}>
                                    <button onClick={(action, id) => self.props.onActionClick("Delete", id)} title="Delete" className="btn btn-s-small error-color mr-1"><span className="lnr lnr-trash"></span></button>
                                </td>
                            );
                        }
                    case "experience":
                        {
                            return (
                                <td key={cellId}>
                                    {hasStringValue(data[column.data]) ? `${data[column.data]}+ Orders` : ``}
                                </td >
                            );
                        }
                    case "staff-product-type-action":
                        {
                            const canDelete = data.AmountOfOrder > 0;
                            return (
                                <td key={cellId}>
                                    <button className="btn btn-s-small success-color mr-1" title="Edit" onClick={() => self.props.onActionClick("edit")}><span className="lnr lnr-pencil"></span></button>
                                    <button className="btn btn-s-small error-color mr-1" onClick={() => self.props.onActionClick("delete")} disabled={canDelete}><span className="lnr lnr-trash"></span></button>
                                </td>
                            );
                        }
                    case "vendor-credential-doc-action":
                        {
                            const canDelete = data.AmountOfSignerDoc > 0;
                            return (
                                <td key={cellId}>
                                    <button className="btn btn-s-small success-color mr-1" title="Edit" onClick={() => self.props.onActionClick("edit")}><span className="lnr lnr-pencil"></span></button>
                                    <button className="btn btn-s-small error-color mr-1" onClick={() => self.props.onActionClick("delete")} disabled={canDelete}><span className="lnr lnr-trash"></span></button>
                                </td>
                            );
                        }
                    case "staff-correction-request-sub-type":
                        {
                            const canEditAndDelete = (data.SubTypeId === null ? true : false);
                            return (
                                <td key={cellId}>
                                    <button className="btn btn-s-small success-color mr-1" title="Edit" disabled={canEditAndDelete} onClick={() => self.props.onActionClick("edit")}><span className="lnr lnr-pencil"></span></button>
                                    <button className="btn btn-s-small error-color mr-1" title="Delete" disabled={canEditAndDelete} onClick={() => self.props.onActionClick("delete")}><span className="lnr lnr-trash"></span></button>
                                </td>
                            );
                        }
                    default:
                        {
                            const content = data[column.data];
                            const div = document.createElement("div");
                            div.innerHTML = content;
                            const text = div.textContent || div.innerText || "";
                            if (text && text.length > displayLength) {
                                return (<td key={cellId} title={content}>{`${text.substr(0, displayLength)}...`}</td>);
                            } else {
                                return (
                                    <td key={cellId}>{text}</td>
                                );
                            }
                        }
                }
            });
        };


        const renderActionCell = function () {
            if (actions.length > 0) {
                const renderActionButtons = () => {
                    return actions.map((action, actionId) => {
                        let buttonIcon = "";
                        let buttonTitle = "";
                        let buttonClass = "";
                        switch (action) {
                            case "edit":
                                buttonTitle = "Edit";
                                buttonIcon = <span className="lnr lnr-pencil"></span>;
                                buttonClass = "btn btn-s-small success-color mr-1";
                                break;
                            case "delete":
                                buttonTitle = "Delete";
                                buttonIcon = <span className="lnr lnr-trash"></span>;
                                buttonClass = "btn btn-s-small error-color mr-1";
                                break;
                            case "review":
                                buttonTitle = "Review";
                                buttonIcon = <span className="ti-eye"></span>;
                                buttonClass = "btn btn-s-small standard-color mr-1";
                                break;
                            case "select":
                                buttonTitle = "Select";
                                buttonIcon = <span className="ti-eye"></span>;
                                buttonClass = "btn btn-s-small standard-color mr-1";
                                break;
                            case "view-service-changes":
                                buttonTitle = "Review";
                                buttonIcon = <span className="lnr lnr-magnifier"></span>;
                                buttonClass = "btn btn-s-small standard-color mr-1";
                                break;
                            case "active":
                                buttonTitle = "Activate";
                                buttonIcon = <span className="lnr lnr-lock"></span>;
                                buttonClass = "btn btn-s-small error-color mr-1";
                                break;
                            case "order-assigment-config":
                                buttonTitle = "Order Assignment Configuration ";
                                buttonIcon = <span className="lnr lnr-book"></span>;
                                buttonClass = "btn btn-s-small default-color mr-1";
                                break;
                            case "downnload":
                                buttonTitle = "Download";
                                buttonIcon = <span className="lnr lnr-download"></span>;
                                buttonClass = "btn btn-s-small default-color mr-1";
                                break;
                            default:
                                buttonTitle = action;
                                buttonIcon = action;
                                buttonClass = "btn btn-s-small btn-default mr-1";
                        }
                        return (
                            <button className={buttonClass} title={buttonTitle} onClick={() => {
                                self.props.onActionClick(action);
                            }} key={actionId}
                            >{buttonIcon}</button>
                        );
                    });
                };

                return (<td>{renderActionButtons()}</td>);
            }

            return null;
        };

        const renderMainRow = function () {
            if (allowRowSelect) {
                data.isSelected = !data.isSelected;
                self.props.onRowClick(data);
            }
        };

        return (
            <tr className={(data.isSelected && allowRowSelect) ?
                "selected-row-vender" : ""} onClick={(e) => {
                    renderMainRow(e);
                }}
            // style={(data.isSelected && allowRowSelect) ? { background: "#5faad4", color: "#194172" } : {}}
            >
                {renderCells()}
                {renderActionCell()}
            </tr>
        );
    }
}

GridLine.propTypes = {
    columns: PropTypes.array,
    actions: PropTypes.array,
    data: PropTypes.object,
    onActionClick: PropTypes.func,
    onCheckboxClick: PropTypes.func,
    rownumber: PropTypes.number,
    allowRowSelect: PropTypes.bool,
    displayLength: PropTypes.number,
    dispatch: PropTypes.func
};

export default GridLine;