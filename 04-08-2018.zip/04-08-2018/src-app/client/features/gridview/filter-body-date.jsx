import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import DatePicker from "../form/date-picker";
import moment from "moment";

const DATE_FORMAT = "MM/DD/YYYY";
const DT_ID = `${Math.random()}`;

class FilterBodyDate extends Component {

    constructor(props) {
        super(props);
        this.state = {
            fromDate: null,
            toDate: null,
            rollbackFromDate: null,
            rollbackToDate: null,
            isDisableApply: true,
            status: "Close"
        };
    }

    setStatus(value) {
        this.setState({
            status: value
        });
    }

    getStatus() {
        return this.state.status;
    }

    handleDirty(isDirty) {
        this.props.onDirty(isDirty);
    }

    handleOnBlurFromDate(value) {
        const toDate = this.refs[`toDate${DT_ID}`].props.defaultValue;
        this.setState({
            fromDate: value,
            isDisableApply: (value === "" || value === "Invalid date") && (toDate === "" || toDate === "Invalid date") //true if all null
        });
    }
    handleOnBlurToDate(value) {
        const fromDate = this.refs[`fromDate${DT_ID}`].props.defaultValue;
        this.setState({
            toDate: value,
            isDisableApply: (value === "" || value === "Invalid date") && (fromDate === "" || fromDate === "Invalid date")
        });
    }
    handleOnCloseDate() {
        const fromDate = this.refs[`fromDate${DT_ID}`].props.defaultValue;
        const toDate = this.refs[`toDate${DT_ID}`].props.defaultValue;
        this.setState({
            isDisableApply: (fromDate === "" || fromDate === "Invalid date") && (toDate === "" || toDate === "Invalid date")
        });
    }

    handleTodayClicked() {
        this.setState({
            fromDate: moment().format(DATE_FORMAT),
            toDate: moment().format(DATE_FORMAT),
            rollbackFromDate: moment().format(DATE_FORMAT),
            rollbackToDate: moment().format(DATE_FORMAT),
            status: "Close",
            isDisableApply: false
        });
        this.handleDirty(true);
        this.props.onApply({ fromDate: moment(), toDate: moment() });
    }
    handleTomorrowClicked() {
        this.setState({
            fromDate: moment().add(1, "d").format(DATE_FORMAT),
            toDate: moment().add(1, "d").format(DATE_FORMAT),
            rollbackFromDate: moment().add(1, "d").format(DATE_FORMAT),
            rollbackToDate: moment().add(1, "d").format(DATE_FORMAT),
            status: "Close",
            isDisableApply: false
        });
        this.handleDirty(true);
        this.props.onApply({ fromDate: moment().add(1, "d"), toDate: moment().add(1, "d") });
    }
    handleThisWeekClicked() {
        this.setState({
            fromDate: moment().startOf("isoWeek").format(DATE_FORMAT),
            toDate: moment().startOf("isoWeek").add(6, "days").format(DATE_FORMAT),
            rollbackFromDate: moment().startOf("isoWeek").format(DATE_FORMAT),
            rollbackToDate: moment().startOf("isoWeek").add(6, "days").format(DATE_FORMAT),
            status: "Close",
            isDisableApply: false
        });
        this.handleDirty(true);
        this.props.onApply({ fromDate: moment().startOf("isoWeek"), toDate: moment().startOf("isoWeek").add(6, "days") });
    }

    handleCancelClicked() {
        this.setState(prevState => {
            return ({
                fromDate: prevState.rollbackFromDate,
                toDate: prevState.rollbackToDate
            });
        });
    }
    handleClearClicked() {
        this.setState({
            fromDate: "",
            toDate: "",
            rollbackFromDate: "",
            rollbackToDate: "",
            isDisableApply: true,
            status: "Close"
        });
        this.handleDirty(false);
        this.props.onApply({ fromDate: "", toDate: "" });
    }
    handleApplyClicked() {
        const fromDate = this.refs[`fromDate${DT_ID}`].props.defaultValue;
        const toDate = this.refs[`toDate${DT_ID}`].props.defaultValue;
        this.setState({
            fromDate,
            toDate,
            rollbackFromDate: fromDate,
            rollbackToDate: toDate,
            status: "Close"
        });
        this.handleDirty(!((fromDate === "" || fromDate === "Invalid date") && (toDate === "" || toDate === "Invalid date")));
        this.props.onApply({ fromDate, toDate });
    }

    render() {
        const { fromDate, toDate, isDisableApply } = this.state;
        return (
            <div className="row filter-tooltip-select">
                <div className="col s6">
                    <DatePicker
                        // id={`fromDate${DT_ID}`}
                        ref={`fromDate${DT_ID}`}
                        labelText="From"
                        onBlur={e => this.handleOnBlurFromDate(moment(e).format(DATE_FORMAT).toString())}
                        onClose={() => this.handleOnCloseDate()}
                        defaultValue={fromDate || ""}
                    />
                </div>
                <div className="col s6">
                    <DatePicker
                        // id={`toDate${DT_ID}`}
                        ref={`toDate${DT_ID}`}
                        labelText="To"
                        onBlur={e => this.handleOnBlurToDate(moment(e).format(DATE_FORMAT).toString())}
                        onClose={() => this.handleOnCloseDate()}
                        defaultValue={toDate || ""}
                    />
                </div>
                <div className="col s12 p-0 center-align">
                    <button type="button" onClick={() => this.handleTodayClicked()} className="btn btn-small default-color">TODAY</button>&nbsp;
                    <button type="button" onClick={() => this.handleTomorrowClicked()} className="btn btn-small default-color">TOMORROW</button>&nbsp;
                    <button type="button" onClick={() => this.handleThisWeekClicked()} className="btn btn-small default-color">THIS WEEK</button>
                </div>
                <div className="clear"></div>
                <footer>
                    <div className="row">
                        <div className="col s6"><button type="button" onClick={() => this.handleClearClicked()} className="btn btn-small error-color w-100">Clear</button></div>
                        <div className="col s6"> <button type="button" disabled={isDisableApply} onClick={() => this.handleApplyClicked()} className="btn btn-small success-color w-100">Apply</button></div>
                    </div>
                </footer>
            </div>
        );
    }
}

FilterBodyDate.propTypes = {
    onApply: PropTypes.func,
    onDirty: PropTypes.func,
    columnTitle: PropTypes.string
};

export default FilterBodyDate;