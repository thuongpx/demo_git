import React from "react";
import PropTypes from "prop-types";

import { Component } from "react";

export class GridHeader extends Component {
    render() {

        const { actions, columns, sortColumn, sortDirection, allowSorting, actionHeader, filters } = this.props;


        const renderHeaderCells = () => {
            return columns.map((column, id) => {
                const renderSortIcon = function () {
                    if (allowSorting) {
                        if (column.data === sortColumn) {
                            const triangleTopClassName = sortDirection ? "lnr lnr-arrow-up" : "";
                            const triangleBottomClassName = sortDirection ? "" : "lnr lnr-arrow-down";
                            return (
                                <span>
                                    <i className={`allow-sort ${triangleTopClassName}`}></i>
                                    <i className={`allow-sort ${triangleBottomClassName}`}></i>
                                </span>
                            );
                        }
                    }

                    return null;
                };

                const renderFilterIcon = function (arrFilters) {
                    if (arrFilters.length > 0) {
                        return arrFilters[0].filter;
                    }
                    return null;
                };

                return (
                    <th key={id} onClick={(e) => {
                        if (allowSorting && (!column.type || (column.type && column.type.indexOf("-action") === -1 && (column.type && column.type.indexOf("customize") === -1))) && $(e.target).hasClass("allow-sort")) {
                            this.props.onSorting(column.data);
                        }
                    }} className={`allow-sort ${column.type === "money" ? "center-align" : ""}`}
                    >
                        <span className="allow-sort">{column.title} {renderSortIcon()}</span>{renderFilterIcon(filters.filter(filter => filter.column === column.data))}
                    </th>
                );
            });
        };

        const renderHeaderActionsCell = function () {
            if (actions.length > 0) {
                return (
                    <th>{actionHeader !== undefined ? `${actionHeader}` : "Action"}</th>
                );
            }

            return null;
        };

        return (
            <thead>
                <tr>
                    {renderHeaderCells()}
                    {renderHeaderActionsCell()}
                </tr>
            </thead>
        );
    }
}

GridHeader.propTypes = {
    columns: PropTypes.array,
    filters: PropTypes.array,
    actions: PropTypes.array,
    sortColumn: PropTypes.string,
    sortDirection: PropTypes.bool,
    allowSorting: PropTypes.bool,
    onSorting: PropTypes.func,
    actionHeader: PropTypes.string
};

export default GridHeader;