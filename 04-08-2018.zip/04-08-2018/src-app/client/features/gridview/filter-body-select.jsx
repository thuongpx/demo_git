import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";

class FilterBodySelect extends Component {

    constructor(props) {
        super(props);
        this.state = {
            selected: this.props.data,
            rollback: JSON.parse(JSON.stringify(this.props.data)),
            isDisableApply: false,
            status: "Close"
        };
    }

    setStatus(value) {
        this.setState({
            status: value
        });
    }

    getStatus() {
        return this.state.status;
    }

    handleDirty(selected) {
        let isDirty = false;
        selected.map(element => {
            if (!element.checked) {
                isDirty = true;
            }
            return element;
        });
        this.props.onDirty(isDirty);
    }

    handleSelect(evt, item) {
        const { selected } = this.state;
        let isDisabled = true;
        const newSelected = selected.map(element => {
            if (this.transformValue(element.value) === this.transformValue(item.value)) {
                element.checked = evt.target.checked;
            }
            if (element.checked) { isDisabled = false; }
            return element;
        });
        this.setState({
            selected: newSelected,
            isDisableApply: isDisabled
        });
    }

    handleCancelClicked() {
        this.setState({
            selected: JSON.parse(JSON.stringify(this.state.rollback)),
            isDisableApply: false,
            status: "Close"
        });
        this.handleDirty(this.state.rollback);
        this.props.onApply(this.state.rollback);
    }

    handleClearClicked() {
        this.setState({
            selected: this.props.data.map(item => { return { ...item, checked: true }; })
        });
        this.props.onDirty(false);
    }

    handleApplyClicked() {
        this.setState({
            rollback: JSON.parse(JSON.stringify(this.state.selected)),
            status: "Close"
        });
        this.handleDirty(this.state.selected);
        this.props.onApply(this.state.selected);
    }

    transformValue(value) {
        const { transformvalue } = this.props;
        switch (transformvalue) {
            case "countdowntime":
                if (value !== null) {
                    const diffTime = value.split(":");
                    if (parseInt(diffTime[0]) > 0) {
                        const diffDay = Math.round(parseInt(diffTime[0]) / 24);
                        if (diffDay >= 0 && diffDay <= 2) return `${parseInt(diffTime[0])} ${parseInt(diffTime[0]) > 1 ? "hours" : "hour"}`;
                        if (diffDay > 2 && diffDay <= 5) return `${diffDay} days`;
                        if (diffDay > 5) return `${diffDay} days`;
                        return `${parseInt(diffTime[0])} hours`;
                    }
                }
                return "[Blank]";
            case "countdownday":
                if (value !== null) {
                    let strCount = "[Blank]";
                    if (parseInt(value) === 0) strCount = "Today";
                    if (parseInt(value) === 1) strCount = "Yesterday";
                    if (parseInt(value) > 1) strCount = `${parseInt(value)} days ago`;
                    return strCount;
                }
                return "[Blank]";
            default:
                return (value === undefined || value === null || value === "") ? "[Blank]" : value;
        }
    }


    render() {
        const { columnTitle } = this.props;
        const { selected } = this.state;
        let { isDisableApply } = this.state;
        if (selected.length === 0) isDisableApply = true;
        let tempData = -111111111111111;
        return (
            <div className="row filter-tooltip-select">
                <label>Select {columnTitle}</label>
                <ul >
                    {selected.map(item => {
                        let isNeedHide = false;
                        const check = (item.checked) ? { defaultChecked: true } : {};
                        check.key = `ran_orderkey${Math.random()}`;
                        if (this.transformValue(item.value) === tempData) {
                            isNeedHide = true;
                        } else {
                            tempData = this.transformValue(item.value);
                        }
                        return (
                            <li key={item.key} className={isNeedHide ? `hide` : ``}>
                                <span>{this.transformValue(item.value)}</span>
                                <label className="right"><input type="checkbox" onClick={(evt) => this.handleSelect(evt, item)} {...check} /> <span></span></label>
                            </li>
                        );
                    })}
                </ul>
                <footer>
                    <div className="row">
                        {/* <div className="col s6"><button type="button" onClick={() => this.handleClearClicked()} className="btn btn-small error-color w-100">Clear</button></div> */}
                        <div className="col s6"><button type="button" onClick={() => this.handleCancelClicked()} className="btn btn btn-small white w-100">Cancel</button></div>
                        <div className="col s6"><button type="button" disabled={isDisableApply} onClick={() => this.handleApplyClicked()} className="btn btn-small success-color w-100">Apply</button></div>
                    </div>
                </footer>
            </div>
        );
    }
}

FilterBodySelect.propTypes = {
    onApply: PropTypes.func,
    onDirty: PropTypes.func,
    data: PropTypes.array,
    columnTitle: PropTypes.string,
    transformvalue: PropTypes.string
};

export default FilterBodySelect;