import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import ReactTooltip from "react-tooltip";
import moment from "moment";
import { slugify } from "../../helpers/common-helper";
import FilterBodyDate from "./filter-body-date";

const DATE_FORMAT = "MM/DD/YYYY";

class FilterDate extends Component {

    constructor(props) {
        super(props);
        this.state = {
            selected: this.props.data,
            isDirty: false
        };
    }

    componentDidMount() {
        this.props.onRef(this);
    }

    filter(fromDate, toDate) {
        this.state.selected.map(element => {
            if (fromDate !== "" || toDate !== "") {
                if (fromDate !== "" && toDate !== "") {
                    element.checked = (moment(element.value).isSameOrAfter(fromDate, "day") && toDate.isSameOrAfter(moment(element.value), "day"));
                } else if (fromDate !== "") {
                    element.checked = moment(element.value).isSameOrAfter(fromDate, "day");
                } else {
                    element.checked = toDate.isSameOrAfter(moment(element.value), "day");
                }
            } else {
                element.checked = true;
            }
            return element;
        });
        this.props.onApply(this.state.selected);
        this.closeTooltip();
    }

    handleApplyClicked(dates) {
        const fromDate = (dates.fromDate !== "" && dates.fromDate !== "Invalid date") ? moment(dates.fromDate, DATE_FORMAT) : "";
        const toDate = (dates.toDate !== "" && dates.toDate !== "Invalid date") ? moment(dates.toDate, DATE_FORMAT) : "";
        this.filter(fromDate, toDate);
    }
    handleDirty(isDirty) {
        this.setState({
            isDirty
        });
    }

    closeTooltip() {
        this.FilterTooltip.hideTooltip();
    }

    handleHideTooltip() {
        if (this.refs.FilterBody.getStatus() === "Open") {
            this.refs.FilterBody.handleCancelClicked();
        }
    }
    handleShowTooltip() {
        this.refs.FilterBody.setStatus("Open");
        this.props.onOpen();
    }


    render() {
        const { columnTitle, data } = this.props;
        const { isDirty } = this.state;
        return (
            <span className="filter-tooltip">
                <i className={`ti-filter${isDirty ? " red-text text-darken-2" : ""}`} data-tip data-for={`volume-helper${slugify(columnTitle)}`}></i>
                <ReactTooltip
                    ref={(node) => { this.FilterTooltip = node; }}
                    id={`volume-helper${slugify(columnTitle)}`}
                    place="bottom" event="click" aria-haspopup="true" role="example" allow
                    afterHide={() => this.handleHideTooltip()}
                    afterShow={() => this.handleShowTooltip()}
                >
                    <FilterBodyDate ref="FilterBody" data={data} onApply={(selected) => this.handleApplyClicked(selected)} onDirty={(dirty) => this.handleDirty(dirty)} />
                </ReactTooltip>
            </span>
        );
    }
}

FilterDate.propTypes = {
    handleSearch: PropTypes.func,
    onApply: PropTypes.func,
    onOpen: PropTypes.func,
    onRef: PropTypes.func,
    data: PropTypes.array,
    columnTitle: PropTypes.string
};

export default FilterDate;