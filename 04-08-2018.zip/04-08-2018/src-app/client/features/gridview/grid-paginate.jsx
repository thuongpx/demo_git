import React from "react";
import gridViewStyle from "Styles/gridview.css";
import PropTypes from "prop-types";
import { Component } from "react";
import Select from "Select";

export class GridPaginate extends Component {
    constructor(props) {
        super(props);
    }

    handleItemPerPageChanged(value) {
        const itemPerPage = parseInt(value, 10);
        this.props.onPaginateChanged(1, itemPerPage);
        this.refs.page.value = 1;
    }

    handlePageChanged(e) {
        let page = parseInt(this.refs.page.value, 10);
        const totalRecords = this.props.totalRecords;
        const totalPages = Math.ceil(totalRecords / this.props.itemPerPage);

        if (e.type === "keyup" && e.keyCode !== 13) {
            return;
        }

        if (isNaN(page)) {
            page = this.props.page;
        }

        if (page < 1) {
            page = 1;
        }

        if (page > totalPages) {
            page = totalPages;
        }

        this.props.onPaginateChanged(page, this.props.itemPerPage);
        this.refs.page.value = page;
    }

    componentDidUpdate() {
        const { page } = this.props;

        this.refs.page.value = page;
    }

    render() {
        let { page } = this.props;
        const { totalRecords, itemPerPage } = this.props;
        const firstPageClassName = (totalRecords === 0 || page === 1) ? gridViewStyle.disabled : "";
        const previousPageClassName = firstPageClassName;
        const totalPages = Math.ceil(totalRecords / itemPerPage);
        const nextPageClassName = (totalRecords === 0 || page === totalPages) ? gridViewStyle.disabled : "";
        const lastPageClassName = nextPageClassName;

        if (totalRecords === 0) {
            page = 0;
        }

        const pageList = this.props.pageList;

        return (

            <div className="row mt-1 pagination">
                <div className="col s12 m12 pb-1" style={{ position: "relative" }}>
                    <div className="left left-bar">
                        <ul className={`${gridViewStyle.pagination} clearfix m-0`} style={{ padding: "0" }}>
                            <li title="First Page" className={`${gridViewStyle["pagination ul"]}`}>
                                <a style={{ cursor: "pointer" }} className={firstPageClassName} onClick={() => {
                                    this.refs.page.value = 1;
                                    this.props.onPaginateChanged(1, itemPerPage);
                                }}>
                                    <span className="ti-angle-double-left"></span>
                                </a>
                            </li>
                            <li title="Previous Page">
                                <a style={{ cursor: "pointer" }} className={previousPageClassName} onClick={() => {
                                    this.refs.page.value = page - 1;
                                    this.props.onPaginateChanged(page - 1, itemPerPage);
                                }}>
                                    <span className="ti-angle-left"></span>
                                </a>
                            </li>
                            <li>
                                <div className="clearfix page-input">
                                    Page <input className={`${gridViewStyle["txt-page-number"]} validate valid`} type="text" ref="page" id="txt-page-number" defaultValue={1} onBlur={this.handlePageChanged.bind(this)} onKeyUp={this.handlePageChanged.bind(this)} /> of {totalPages}
                                </div>
                            </li>
                            <li title="Next Page">
                                <a style={{ cursor: "pointer" }} className={nextPageClassName} onClick={() => {
                                    this.refs.page.value = page + 1;
                                    this.props.onPaginateChanged(page + 1, itemPerPage);
                                }}>
                                    <span className="ti-angle-right"></span>
                                </a>
                            </li>
                            <li title="Last Page">
                                <a style={{ cursor: "pointer" }} className={lastPageClassName} onClick={() => {
                                    this.refs.page.value = totalPages;
                                    this.props.onPaginateChanged(totalPages, itemPerPage);
                                }}>
                                    <span className="ti-angle-double-right"></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div className="center text" style={{ position: "absolute", left: "46%", zIndex: "1" }}>
                        <span>{totalRecords} record(s) found</span>
                    </div>
                    <div className="right right-bar">
                        <ul className={`${gridViewStyle["page-options"]} ${gridViewStyle["pull-right"]} clearfix  m-0`}>
                            <li><span>Show</span></li>
                            <li className="table-show-number">
                                <Select
                                    dataSource={pageList}
                                    onChange={(value) => this.handleItemPerPageChanged(value)}
                                    mapDataToRenderOptions={{ value: "itemPerPage", label: "itemPerPage" }}
                                    ref="itemPerPage"
                                    value={itemPerPage}
                                />
                            </li>
                            <li>
                                <span>items/page.</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div >
        );
    }
}

GridPaginate.defaultProps = {
    pageList: [
        {
            itemPerPage: 25
        },
        {
            itemPerPage: 50
        },
        {
            itemPerPage: 100
        },
        {
            itemPerPage: 250
        },
        {
            itemPerPage: 500
        },
        {
            itemPerPage: 1000
        }
    ]
};

GridPaginate.propTypes = {
    totalRecords: PropTypes.number,
    page: PropTypes.number,
    itemPerPage: PropTypes.number,
    onPaginateChanged: PropTypes.func,
    pageList: PropTypes.array
};

export default GridPaginate;