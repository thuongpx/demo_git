import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import ReactTooltip from "react-tooltip";
import FilterBodySelect from "./filter-body-select";
import { slugify } from "../../helpers/common-helper";

class FilterSelect extends Component {

    constructor(props) {
        super(props);
        this.state = {
            selected: this.props.data,
            rollback: JSON.parse(JSON.stringify(this.props.data)),
            isDisableApply: false,
            isDirty: false
        };
    }

    componentDidMount() {
        this.props.onRef(this);
    }

    handleApplyClicked(selected) {
        this.setState({
            rollback: JSON.parse(JSON.stringify(selected))
        });
        this.props.onApply(selected);
        this.FilterTooltip.hideTooltip();
    }
    handleDirty(isDirty) {
        this.setState({
            isDirty
        });
        this.props.onChangeDirty(isDirty);
    }

    closeTooltip() {
        this.FilterTooltip.hideTooltip();
    }

    handleHideTooltip() {
        if (this.refs.FilterBody.getStatus() === "Open") {
            this.refs.FilterBody.handleCancelClicked();
        }
    }
    handleShowTooltip() {
        this.refs.FilterBody.setStatus("Open");
        this.props.onOpen();
    }

    render() {
        const { columnTitle, data, transformvalue } = this.props;
        const { isDirty } = this.state;
        return (
            <span className="filter-tooltip">
                <i className={`ti-filter${isDirty ? " red-text text-darken-2" : ""}`} data-tip data-for={`volume-helper${slugify(columnTitle)}`}></i>
                <ReactTooltip
                    ref={(node) => { this.FilterTooltip = node; }}
                    id={`volume-helper${slugify(columnTitle)}`}
                    place="bottom" event="click" aria-haspopup="true" role="example" allow
                    afterHide={() => this.handleHideTooltip()}
                    afterShow={() => this.handleShowTooltip()}
                >
                    <FilterBodySelect ref="FilterBody" columnTitle={columnTitle} transformvalue={transformvalue} data={data} onApply={(selected) => this.handleApplyClicked(selected)} onDirty={(dirty) => this.handleDirty(dirty)} />
                </ReactTooltip>
            </span>
        );
    }
}

FilterSelect.propTypes = {
    handleSearch: PropTypes.func,
    onApply: PropTypes.func,
    onCancel: PropTypes.func,
    onOpen: PropTypes.func,
    onRef: PropTypes.func,
    data: PropTypes.array,
    onChangeDirty: PropTypes.func,
    columnTitle: PropTypes.string,
    transformvalue: PropTypes.string
};

export default FilterSelect;