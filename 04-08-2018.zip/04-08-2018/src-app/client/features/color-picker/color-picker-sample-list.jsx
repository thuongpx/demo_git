import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";

class ColorPickerSampleList extends Component {
    constructor(props) {
        super(props);
    }

    handleChange(value) {
        const { onChange } = this.props;

        onChange(value);
    }

    renderColorBlock(value, index) {
        const selected = this.props.value;
        const styles = {
            colorBlock: {
                width: "30px",
                height: "30px",
                textAlign: "center",
                lineHeight: "30px",
                fontSize: "20px",
                color: "#fff",
                display: "inline-block",
                borderRadius: "4px",
                verticalAlign: "top",
                margin: "0px 3px",
                background: `${value}`,
                boxShadow: value === selected && "0px 0px 1px 3px #444"
            },
            fillBlock: {
                width: "30px",
                height: "30px",
                textAlign: "center",
                lineHeight: "30px",
                fontSize: "20px",
                color: "#fff",
                display: "inline-block",
                borderRadius: "4px",
                verticalAlign: "top",
                margin: "0px 3px",
                background: `#999`,
                cursor: "default"
            }
        };

        if (value === "fillBlock") {
            return (
                <span style={styles.fillBlock} key={value}>#</span>
            );
        }

        return (
            <span style={styles.colorBlock} key={value} onClick={() => this.handleChange(value)}>{index === 9 && "#"}</span>
        );
    }

    render() {
        const { sampleColors } = this.props;

        return (
            <span>
                {
                    sampleColors.map((color, index) => {
                        return this.renderColorBlock(color, index);
                    })
                }
            </span>
        );
    }
}


ColorPickerSampleList.defaultProps = {
    sampleColors: []
};

ColorPickerSampleList.propTypes = {
    value: PropTypes.string,
    sampleColors: PropTypes.array,
    onChange: PropTypes.func
};

export default ColorPickerSampleList;