import React from "react";
import { Component } from "react";
import ColorPicker from "../../features/color-picker/color-picker";

class ColorPickerDemo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: "",
            notUsedColors: [
            ]
        };
    }
    handleChangeColor(value) {
        this.setState({
            value
        });
    }

    handleBlack() {
        this.setState({
            value: "#000000"
        });
    }

    handleChangeNotUseColors() {
        this.setState({
            notUsedColors: [
                "#015249", "#01ABAA", "#02558B", "#02C8A7", "#031424",
                "#0375B4", "#056571", "#063F4F", "#0E0B16",
                "#0F1626", "#155765", "#1ABC9C", "#1B7B34",
                "#1D2731", "#233237", "#262228", "#27AE60", "#286DA8",
                "#2C3E50", "#2ECC71", "#30415D", "#328CC1", "#333A56", "#34495E", "#3498DB", "#373737",
                "#3C3C3C", "#465C8B", "#4717F6", "#49274A",
                "#494E6B", "#4ABDAC", "#4CDEF5", "#535353", "#565656", "#575DA9",
                "#57652A", "#57BC90", "#5F0F4E", "#66AB8C", "#66B9BF", "#675682",
                "#67AECA", "#6B7A8F", "#6D7993", "#6E3667", "#6E7376",
                "#7CDBD5", "#841983", "#874C62", "#88BBD6", "#88D317", "#8EAEBD", "#8FC33A",
                "#9099A2", "#93C178", "#985E6D", "#98878F", "#99CED4",
                "#A7B3A5", "#A7D2CB", "#A9A9A9", "#A9B7C0",
                "#B37D4E", "#B4DBC0", "#B56357", "#B5E582", "#B82601", "#BFD8D2",
                "#C06014", "#C09F80", "#C5C1C0", "#C7BB36", "#C7D8C6", "#C98474", "#CAE4DB",
                "#CAEBF2", "#CCCBC6", "#CDCDCD", "#CF6766", "#D35400", "#D48CF8",
                "#D5D5D5", "#D7CEC7", "#DCD0C0",
                "#DF744A", "#DFDCE3", "#E14658", "#E24E42", "#E37222",
                "#E7DFDD", "#E8E8E8", "#E9B000", "#E9C893", "#E9C904", "#EAB126", "#EAC67A",
                "#EAE3EA", "#EB6E80", "#EC576B", "#EDD8CD", "#EEAA7B", "#EEB6B7", "#EFD9C1", "#EFEFEF", "#F19F4D",
                "#F1C40F", "#F24C4E", "#F2D388", "#F53240", "#F5F5F5",
                "#F7882F", "#F7B733", "#F7C331", "#F9BE02", "#F9CF00",
                "#FA7C92", "#FC4A1A", "#FE65B7", "#FEDC3D", "#FEDCD2", "#FF3B3F", "#FF533D"
            ]
        });
    }

    render() {
        return (
            <div>
                <h2>{this.state.value}</h2>
                <hr />
                <div>
                    <ColorPicker
                        value={this.state.value}
                        notUsedColors={this.state.notUsedColors}
                        onChange={(value) => this.handleChangeColor(value)}
                    />
                </div>
                <hr />
                <button onClick={() => this.handleBlack()}>Change Value to Black</button>
                <button onClick={() => this.handleChangeNotUseColors()}>Change not user color</button>
            </div>
        );
    }
}

export default ColorPickerDemo;