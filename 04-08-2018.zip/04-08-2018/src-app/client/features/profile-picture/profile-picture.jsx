import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import {
    Modal,
    ModalBody,
    ModalTitle,
    ModalFooter
} from "Modal";
import CommonModal from "CommonModal";
import { showError } from "../../screens/main-layout/actions";

export class ProfilePicture extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pictureSrc: this.props.pictureSrc,
            pictureSrcTemp: "",
            isShowModal: false,
            addUpdateString: this.props.pictureSrc ? "Update" : "Add"
        };
    }
    handleDrop(e) {
        e.preventDefault();
        let files;
        if (e.dataTransfer) {
            files = e.dataTransfer.files;
        } else if (e.target) {
            files = e.target.files;
        }

        if (files.length > 0) {
            const file = files[0];
            const fileExtension = file.name.split(".")[file.name.split(".").length - 1];
            const accept = this.props.accept.split(",").map(item => { return item.replace(".", ""); });

            if (accept.indexOf(fileExtension.toLowerCase()) > -1) {
                const formData = new FormData();
                formData.append("file", file);
                this.loadImage(file);
                this.fileName.value = file.name;
            } else {
                this.props.dispatch(showError(`YOUR IMAGE WAS NOT UPLOADED. \nValid extensions are JPG, BMP, GIF and PNG.`));
            }
        }
    }

    handleShowModal() {
        this.fileName.value = null;
        this.fileElement.value = null;
        this.setState({ isShowModal: true });
    }

    handleCloseModal() {
        this.setState({ isShowModal: false });
    }

    componentWillReceiveProps(nextProps) {
        this.setState({ pictureSrc: nextProps.pictureSrc });
    }

    loadImage(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            this.setState({
                pictureSrcTemp: e.target.result
            });
        };

        reader.readAsDataURL(file);
    }

    render() {
        const { accept, style, isUseCustomAvatar, pictureWidth, pictureHeight } = this.props;
        const { pictureSrc } = this.state;

        const renderPicture = () => {
            if (this.state.pictureSrc !== "") {
                return (
                    <img width={pictureWidth} height={pictureHeight} src={this.state.pictureSrc} />
                );
            } else {
                return (
                    <div style={{ textAlign: "center" }}>
                        <div style={{ fontSize: "150px" }}>
                            <i className="fa fa-user"></i>
                        </div>
                    </div>
                );
            }
        };

        return (
            <div className="modal-upload-profile">
                {!isUseCustomAvatar && <div>
                    <div className="card-image waves-effect waves-block waves-light center-block custome-box-shadow">
                        {pictureSrc ? <img width={pictureWidth} height={pictureHeight} src={pictureSrc} /> : (
                            <div style={{ width: "100%", height: "auto" }}>
                                <div style={{ fontSize: "150px", width: "200px", textAlign: "center" }}>
                                    <i className="fa fa-user"></i>
                                </div>
                            </div>
                        )}
                    </div>
                    {this.props.isShowButtonUploadPicture && <div className="mt-1 center-align">
                        <button className="btn success-color action-btn" onClick={() => this.handleShowModal()}>Upload Profile Pic</button>
                    </div>}
                </div>}
                <Modal isOpen={this.state.isShowModal} style={style}>
                    <ModalBody>
                        <ModalTitle onClickClose={() => this.handleCloseModal()}>{pictureSrc ? "Update Your Profile Picture" : "Add Your Profile Picture"}</ModalTitle>
                        <div className="tab-content popup-update-img-profile">
                            <div className="row">
                                <div className="col s12 m10 offset-m1"> {/*style={{ float: "inherit", position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)" }}*/}
                                    <div className="card horizontal box-shadow-none mt-6">

                                        <div className="card-image custome-box-shadow" style={{ height: "fit-content", width: "195px", margin: "0 auto" }}>
                                            <div onDragOver={(e) => { e.preventDefault(); }} onDrop={this.handleDrop.bind(this)}>
                                                {renderPicture()}
                                            </div>
                                        </div>

                                        <div className="profile-action">
                                            <p className="m-0"><strong>Current Profile Picture</strong></p>
                                            <button className="btn error-color action-btn mt-1"
                                                onClick={() => {
                                                    this.commonModal.showModal({
                                                        type: "confirm",
                                                        message: `Are you sure you want to remove your profile picture?`
                                                    }, () => {
                                                        // clear source
                                                        this.setState({
                                                            pictureSrc: ""
                                                        });
                                                        this.props.onChange("");
                                                        // clear input
                                                        this.fileName.value = null;
                                                        this.fileElement.value = null;
                                                    });
                                                }}
                                                disabled={!this.state.pictureSrc}
                                            >Remove</button>
                                        </div>
                                        <div className="card-stacked">
                                            <div className="card-content">
                                                <p style={{ "fontStyle": "italic" }}>Please browse and select an image</p>

                                                <div className="file-field input-field">
                                                    <div className="btn" style={{ float: "right", marginRight: "10px" }}>
                                                        <button className="btn btn-primary action-btn" style={{ height: "3rem" }} onClick={() => {
                                                            this.fileElement.click();
                                                        }
                                                        }
                                                        >Browse</button>
                                                    </div>
                                                    <div className="file-path-wrapper">
                                                        <input type="text" disabled ref={input => { this.fileName = input; }} />
                                                        <input ref={input => { this.fileElement = input; }} id="profile-file-input" type="file" style={{ display: "none" }} accept={accept} onChange={this.handleDrop.bind(this)} />
                                                    </div>
                                                    <strong>Accepted Image Formats are:</strong><span> .JPG, .GIF, .BMP, .PNG</span>
                                                </div>

                                                <div>
                                                    <button className="btn success-color action-btn"
                                                        onClick={() => {
                                                            this.setState({
                                                                pictureSrc: this.state.pictureSrcTemp
                                                            });
                                                            this.props.onChange(this.state.pictureSrcTemp);
                                                        }}
                                                        disabled={!(this.fileElement && this.fileElement.value)}
                                                    >Add</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* <div className="row">
                                        <div className="col s3 center-align mt-1" style={{ width: "230px" }}>
                                            
                                        </div>
                                    </div> */}
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row">
                            <div className="col s12">
                                <button className="btn w-100 white" onClick={() => { this.setState({ isShowModal: false }); }}>Close</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

ProfilePicture.defaultProps = {
    pictureWidth: "180px",
    pictureHeight: "180px",
    pictureSrc: "",
    accept: ".jpg,.png,.gif,.bmp",
    isUseCustomAvatar: false,
    isShowButtonUploadPicture: true
};

ProfilePicture.propTypes = {
    onChange: PropTypes.func.isRequired,
    accept: PropTypes.string,
    pictureWidth: PropTypes.string,
    pictureHeight: PropTypes.string,
    pictureSrc: PropTypes.string,
    dispatch: PropTypes.func,
    style: PropTypes.object,
    isUseCustomAvatar: PropTypes.bool,
    isShowModal: PropTypes.bool,
    isShowButtonUploadPicture: PropTypes.bool
};

export default connect(null, null, null, { withRef: true })(ProfilePicture);