import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { showError, showSuccess } from "../../screens/main-layout/actions";

import { getDirectionFromAddresses } from "Helpers/location-helper";

class MapRouteDemo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            routeUrl: ""
        };
    }

    handleKeyPress(e) {
        if (e.key === "Enter") {
            this.handleSubmit();
        }
    }

    handleSubmit() {
        const { dispatch } = this.props;

        this.refs.addressA.value = this.refs.addressA.value.trim();
        this.refs.addressB.value = this.refs.addressB.value.trim();

        if (this.refs.addressA.value !== "" && this.refs.addressB.value !== "") {
            const url = getDirectionFromAddresses(this.refs.addressA.value, this.refs.addressB.value);

            this.setState({
                routeUrl: url
            });

            dispatch(showSuccess(`Generate direction from ${this.refs.addressA.value} to ${this.refs.addressB.value} successfully!`));
        } else {
            dispatch(showError("Addresses can not be blank!"));
        }
    }

    handleClick(e) {
        e.preventDefault();

        window.open(this.state.routeUrl, "", "width=800,height=600,top=100,left=200");
        this.setState({
            routeUrl: ""
        });
    }

    handleCancel() {
        const { dispatch } = this.props;

        this.setState({
            routeUrl: ""
        });
        dispatch(showSuccess("Cancelled direction route link!"));
    }

    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="form-group col m12">
                        <label>Origin</label>
                        <input disabled={this.state.routeUrl !== ""} onKeyPress={(e) => this.handleKeyPress(e)} type="text" className="form-control" ref="addressA" placeholder="Text or Coordinate..." />
                    </div>
                </div>
                <div className="row">
                    <div className="form-group col m12">
                        <label>Destination</label>
                        <input disabled={this.state.routeUrl !== ""} onKeyPress={(e) => this.handleKeyPress(e)} type="text" className="form-control" ref="addressB" placeholder="Text or Coordinate..." />
                    </div>
                </div>
                <div className="row">
                    <div className="form-group col m12">
                        <button disabled={this.state.routeUrl !== ""} className="btn default-color" onClick={() => this.handleSubmit()}>Get direction</button> &nbsp;
                        {this.state.routeUrl !== "" ? <span>Click <a role="button" onClick={(e) => this.handleClick(e)}>here</a> to see Google Map's Direction <button className="btn error-color" onClick={() => this.handleCancel()}>Cancel</button></span> : null}
                    </div>
                </div>
                <hr />
                <div className="row">
                    <div>Example Coordinate</div>
                    <div><code>10 Nam Ky Khoi Nghia</code> 15.9779549,108.26197239999999</div>
                    <div><code>13 Bach Dang</code> 16.0731614,108.2250487</div>
                </div>
            </div>
        );
    }
}

MapRouteDemo.propTypes = {
    dispatch: PropTypes.func
};

export default connect()(MapRouteDemo);