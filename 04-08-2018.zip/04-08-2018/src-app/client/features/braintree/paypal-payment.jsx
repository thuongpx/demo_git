import React from "react";
import braintree from "braintree-web";
import { connect } from "react-redux";
import PropTypes from "prop-types";

import { CLIENT_AUTHORIZATION } from "Config/config";

import { showError } from "../../screens/main-layout/actions";

import { Component } from "react";
import { handleApiError } from "ErrorHandler";

import { guid } from "../../helpers/crypto-helper";
import { getCreditCardIcon } from "../../helpers/common-helper";
import { shallowCompareState, shallowCompareProps } from "../../helpers/common-helper";

class BraintreePaypalPayment extends Component {
    constructor(props) {
        super(props);

        this.state = {
            isPaymentCreated: false,
            isReady: false
        };

        this.hostedFieldsInstance = null;
    }

    // componentDidMount() {
    //     const { currentPayments } = this.props;

    //     if (!currentPayments || currentPayments.length === 0) {
    //         this.initBraintree();
    //     }
    // }

    componentDidUpdate() {
        const { isReady } = this.state;

        if (!isReady) {
            this.initBraintree();
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    initBraintree() {
        braintree.client.create({ authorization: CLIENT_AUTHORIZATION })
            .then((client) => this.createPaypalInstance(client))
            .catch((error) => handleApiError(this.props.dispatch, error));
    }

    createPaypalInstance(client) {
        braintree.paypal.create({
            client
        })
            .then((paypalCheckoutInstance) => this.paypalCheckoutDidCreate(paypalCheckoutInstance))
            .catch((error) => handleApiError(this.props.dispatch, error));
    }

    paypalCheckoutDidCreate(paypalCheckoutInstance) {
        this.paypalCheckoutInstance = paypalCheckoutInstance;

        this.setState({
            isReady: true
        });
    }

    linkPaypalAccount() {
        this.paypalCheckoutInstance.tokenize({
            flow: "vault"
        }, (tokenizeErr, payload) => {
            // Stop if there was an error.
            if (tokenizeErr) {
                const { dispatch } = this.props;
                dispatch(showError(tokenizeErr.message));
                return;
            }

            const { handleCreatePayment } = this.props;

            // do after request payment token
            if (handleCreatePayment) {
                handleCreatePayment({
                    description: `${payload.details.email}`,
                    nonce: payload.nonce,
                    type: payload.type,
                    imageUrl: getCreditCardIcon("Paypal"),
                    paymentId: guid()
                });
            }

            this.setState({
                isAddingPayment: false
            });
        });
    }

    handleRemovePayment(e, paymentId) {
        e.preventDefault();
        const { handleRemovePayment } = this.props;

        // do after request payment token
        if (handleRemovePayment) {
            handleRemovePayment(paymentId);
        }
    }

    render() {
        const { currentPayments, defaultPayment, isActive } = this.props;
        const { isReady } = this.state;

        const isOpen = isActive && (!currentPayments || currentPayments.length === 0);

        const renderCurrentPayments = () => {
            return currentPayments.map((item, index) => {
                const isDefault = defaultPayment === item.paymentId;

                return (
                    <div key={`payment-${index}`} className="payment-item-container">
                        <a className="payment-item">
                            <span className="payment-item-expander">
                                <div className="info">
                                    <div className="img-container">
                                        <label>
                                            <input className="with-gap" type="radio" checked={isDefault} onChange={e => this.handleSelectDefault(e, item.paymentId)} />
                                            <span style={{ paddingRight: "0" }}><img alt={item.cardType} src={item.imageUrl} /></span>
                                        </label>
                                    </div>
                                    <div className="info-right">
                                        <div style={{ position: "relative" }}>
                                            <div className="info-right-inner">
                                                <div className="info-col-left">
                                                    <span>{item.description}</span>
                                                </div>
                                                <div className="info-col-right">
                                                    <div style={{ fontSize: "21px" }}>
                                                        <span style={{ marginRight: "8px" }} onClick={e => this.handleRemovePayment(e, item.paymentId)}><i className="fa fa-minus-circle red-text"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </span>
                        </a>
                    </div>
                );
            });
        };

        return (
            <div id={guid()} key={guid()}>
                {isOpen &&
                    <button disabled={!isReady} className="btn btn-small btn-paypal" onClick={() => this.linkPaypalAccount()}>
                        <i className="fa fa-paypal"></i> Login with Paypal</button>
                }
                {(currentPayments && currentPayments.length > 0) &&
                    <div className="card">
                        <div className="card-action padding-top-10 padding-bottom-5 padding-left-20 payment-card-action">
                            <strong>Paypal</strong>
                        </div>
                        <div className="card-content padding-10">
                            {renderCurrentPayments()}
                        </div>
                    </div>
                }
            </div>
        );
    }
}

BraintreePaypalPayment.propTypes = {
    dispatch: PropTypes.func,
    isActive: PropTypes.bool,
    handleCancel: PropTypes.func,
    currentPayments: PropTypes.array,
    defaultPayment: PropTypes.string,
    handleCreatePayment: PropTypes.func,
    handleRemovePayment: PropTypes.func,
    handleSelectDefault: PropTypes.func,
    handleCancelPayment: PropTypes.func
};

export default connect(null, null, null, { withRef: true })(BraintreePaypalPayment);

