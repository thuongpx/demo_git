import React from "react";
import braintree from "braintree-web";
import { connect } from "react-redux";
import { Component } from "react";
import PropTypes from "prop-types";

import { shallowCompareState, shallowCompareProps } from "../../helpers/common-helper";
import {
  Modal,
  ModalTitle,
  ModalBody,
  ModalFooter
} from "Modal";
import { guid } from "../../helpers/crypto-helper";
import { CLIENT_AUTHORIZATION } from "../../config/config";
import { showError } from "../../screens/main-layout/actions";
import { apiRequestPaymentToken, apiRemovePaymentMethod } from "../../api/payment-api";
import { handleApiError, handleError } from "ErrorHandler";
import { getCreditCardIcon } from "../../helpers/common-helper";

class BraintreeCreditCardPayment extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isAddingPayment: false
    };

    this.hostedFieldsInstance = null;
  }

  componentDidUpdate() {
    if (this.shouldOpenCreditCardBox()) {
      this.initBraintree();
    }
  }

  initBraintree() {
    this.toggleLoader(true);

    braintree.client.create({ authorization: CLIENT_AUTHORIZATION })
      .then((client) => this.createHostedFields(client))
      .catch((error) => handleError(this.props.dispatch, error));
  }

  createHostedFields(client) {
    braintree.hostedFields.create({
      client,
      styles: {
        "input": {
          "font-size": "14px",
          "font-family": "helvetica, tahoma, calibri, sans-serif",
          "color": "#3a3a3a"
        }
      },
      fields: {
        number: {
          selector: "#card-number",
          placeholder: "#### #### #### ####"
        },
        cvv: {
          selector: "#cvv",
          placeholder: "###"
        },
        expirationDate: {
          selector: "#expiration-date",
          placeholder: "##/##"
        }
      }
    })
      .then((hostedFields) => this.hostedFieldsDidCreate(hostedFields))
      .catch((error) => handleError(this.props.dispatch, error));
  }

  hostedFieldsDidCreate(hostedFieldsInstance) {
    this.hostedFieldsInstance = hostedFieldsInstance;

    this.toggleLoader(false);
  }

  requestPayment(callback) {
    const { hostedFields } = this.state;
    const { dispatch } = this.props;

    const requestPaymentToken = (oneTimeNonce) => {
      // from nonce, get payment method token
      apiRequestPaymentToken({
        nonce: oneTimeNonce
      },
        (data) => {
          callback(data);
        }, (error) => handleApiError(dispatch, error));
    };

    // credit cards - hosted fields
    hostedFields.tokenize((err, payload) => {
      if (err) {
        dispatch(showError(err.message));
      } else {
        requestPaymentToken(payload.nonce);
      }
    });
  }

  handleSavePayment() {
    this.hostedFieldsInstance.tokenize((err, payload) => {
      const { dispatch } = this.props;

      if (err) {
        handleError(dispatch, err);
        return;
      }

      const { handleCreatePayment } = this.props;

      // do after request payment token
      if (handleCreatePayment) {
        handleCreatePayment({
          description: `Ending in ${payload.details.lastFour}`,
          nonce: payload.nonce,
          type: payload.type,
          cardType: payload.details.cardType,
          imageUrl: getCreditCardIcon(payload.details.cardType),
          paymentId: guid()
        });
      }

      this.setState({
        isAddingPayment: false
      });
    });
  }

  removePaymentMethod(paymentId) {
    const { dispatch } = this.props;

    apiRemovePaymentMethod({ paymentId }, (result) => {
      if (result && result.isSuccess) {
        const { handleRemovePayment } = this.props;

        // do after request payment token
        if (handleRemovePayment) {
          handleRemovePayment(paymentId);
        }
      }
    }, (error) => handleApiError(dispatch, error));
  }

  requestPaymentToken(input, cb) {
    const { dispatch } = this.props;

    // from nonce, get payment method token
    apiRequestPaymentToken(
      {
        nonce: input.nonce,
        description: input.description,
        cardType: input.details.cardType,
        type: input.type
      },
      (result) => {
        if (cb) cb(result);
      }, (error) => handleApiError(dispatch, error));
  }

  toggleLoader(isOn) {
    if (!isOn) {
      $("#credit-card-loader").hide();
    } else {
      $("#credit-card-loader").fadeIn(1e3);
    }
  }

  renderButton() {
    return (
      <div className="row m-0">
        <div className="col m6">
          <button className="btn white w-100" onClick={() => this.handleCancel()}>Cancel</button>
        </div>
        <div className="col m6">
          <button className="btn success-color w-100" onClick={() => this.handleSavePayment()}>Save</button>
        </div>
      </div>
    );
  }

  handleCancel() {
    const { handleCancelPayment } = this.props;

    if (handleCancelPayment) handleCancelPayment();

    this.setState({
      isAddingPayment: false
    });
  }

  handleRemovePayment(e, paymentId) {
    e.preventDefault();
    const { handleRemovePayment } = this.props;

    // do after request payment token
    if (handleRemovePayment) {
      handleRemovePayment(paymentId);
    }
  }

  handleAddPayment(e) {
    e.preventDefault();

    this.setState({
      isAddingPayment: true
    });
  }

  handleSelectDefault(e, paymentId) {
    e.preventDefault();

    const { handleSelectDefault } = this.props;

    if (handleSelectDefault) handleSelectDefault(paymentId);
  }

  shouldComponentUpdate(nextProps, nextState) {
    return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
  }

  shouldOpenCreditCardBox() {
    const { currentPayments, isActive } = this.props;
    const { isAddingPayment } = this.state;

    return (isActive && (!currentPayments || currentPayments.length === 0)) || isAddingPayment;
  }

  render() {
    const { currentPayments, defaultPayment } = this.props;

    const isOpen = this.shouldOpenCreditCardBox();

    const renderCurrentPayments = () => {
      return currentPayments.map((item, index) => {
        const isDefault = defaultPayment === item.paymentId;

        return (
          <div key={`payment-${index}`} className="payment-item-container">
            <a className="payment-item">
              <span className="payment-item-expander">
                <div className="info">
                  <div className="img-container">
                    <label>
                      <input className="with-gap" type="radio" checked={isDefault} onChange={e => this.handleSelectDefault(e, item.paymentId)} />
                      <span style={{ paddingRight: "0" }}><img alt={item.cardType} src={item.imageUrl} /></span>
                    </label>
                  </div>
                  <div className="info-right">
                    <div style={{ position: "relative" }}>
                      <div className="info-right-inner">
                        <div className="info-col-left">
                          <span>{item.description}</span>
                        </div>
                        <div className="info-col-right">
                          <div style={{ fontSize: "21px" }}>
                            {!isDefault &&
                              <span style={{ marginRight: "8px" }} onClick={e => this.handleRemovePayment(e, item.paymentId)}><i className="fa fa-minus-circle red-text"></i></span>
                            }
                            <span disabled={currentPayments && currentPayments.length === 5} onClick={e => this.handleAddPayment(e)}><i className="fa fa-plus-circle green-text"></i></span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </span>
            </a>
          </div>
        );
      });
    };

    return (
      <div id={guid()} key={guid()}>
        <div key={guid()}>
          <Modal isOpen={isOpen} style={{ width: "25%", height: "35%" }}>
            <ModalBody>
              <ModalTitle onClickClose={() => this.handleCancel()}>Credit Card Details</ModalTitle>
              <div key={guid()} id="credit-card-loader" className="page-loader" style={{ display: "none", marginTop: "40px" }}>
                <div className="loader">Loading...</div>
              </div>
              <div className="payment-panel">
                <div className="row">
                  <div className="col s12 m12">
                    <label className="control-label">Card Number</label>
                    <div className="input-field braintree-input required" id="card-number"></div>
                    <span className="helper-text"></span>
                  </div>
                </div>
                <div className="row">
                  <div className="col s8 m8">
                    <label className="control-label">Expiry Date</label>
                    <div className="input-field braintree-input required" id="expiration-date"></div>
                    <span className="helper-text"></span>
                  </div>
                  <div className="col s4 m4">
                    <label className="control-label">CCV Code</label>
                    <div className="input-field braintree-input required" id="cvv"></div>
                    <span className="helper-text"></span>
                  </div>
                </div>
              </div>
            </ModalBody>
            <ModalFooter>{this.renderButton()}</ModalFooter>
          </Modal>
        </div>
        <div key={guid()}>
          {(currentPayments && currentPayments.length > 0) &&
            <div className="card">
              <div className="card-action padding-top-10 padding-bottom-5 padding-left-20 payment-card-action">
                <strong>Credit Card</strong>
                <strong style={{ float: "right" }}>Max number of Credit Card: 5</strong>
              </div>
              <div className="card-content padding-10">
                {renderCurrentPayments()}
              </div>
            </div>
          }
        </div>
      </div>
    );
  }
}

BraintreeCreditCardPayment.propTypes = {
  dispatch: PropTypes.func,
  isActive: PropTypes.bool,
  handleCancel: PropTypes.func,
  currentPayments: PropTypes.array,
  defaultPayment: PropTypes.string,
  handleCreatePayment: PropTypes.func,
  handleRemovePayment: PropTypes.func,
  handleSelectDefault: PropTypes.func,
  handleCancelPayment: PropTypes.func
};

export default connect(null, null, null, { withRef: true })(BraintreeCreditCardPayment);

