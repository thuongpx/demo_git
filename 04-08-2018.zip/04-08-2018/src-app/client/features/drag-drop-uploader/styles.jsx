const styles = {
  dropTargetStyle: {
    border: "2px dashed #a7a7a7",
    padding: 10,
    backgroundColor: "#f7f7f7",
    cursor: "pointer",
    borderRadius: "10px"
  },
  dropTargetActiveStyle: {
    border: "2px dashed #1b920d",
    backgroundColor: "#ccffcc"
  },
  placeHolderStyle: {
    paddingLeft: "20%",
    paddingRight: "20%",
    textAlign: "center"
  },
  fileset: {
    marginTop: 10,
    paddingTop: 10,
    paddingBottom: 10
  },
  fileDetails: {
    paddingTop: 10,
    display: "flex",
    alignItems: "flex-start"
  },
  fileName: {
    flexGrow: "8"
  },
  fileSize: {
    float: "right",
    marginRight: "10px"
  },
  removeButton: {
    alignSelf: "flex-end"
  },
  progress: {
    WebkitAppearance: "none",
    appearance: "none",
    marginTop: 10,
    width: "100%",
    height: 16
  }
};

export default styles;