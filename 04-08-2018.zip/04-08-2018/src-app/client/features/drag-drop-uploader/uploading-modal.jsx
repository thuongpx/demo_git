import React from "react";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";

import PropTypes from "prop-types";
import { Component } from "react";
import styles from "./styles";

class UploadingModal extends Component {
    constructor(props) {
        super(props);

        this.state = {
            isOpen: false,
            uploadedItems: []
        };
    }

    toggleModal(isShowUploading = true) {
        this.setState({
            isOpen: (!this.state.isOpen && isShowUploading),
            uploadedItems: []
        }, () => {
            const { onToggle } = this.props;

            if (onToggle && onToggle(this.state.isOpen));
        });
    }

    componentWillReceiveProps(props) {
        const { items } = props;
        const { uploadedItems } = this.state;

        const newCompleted = items.filter(item => !item.cancelled && !!item.file && item.isCompleted && !uploadedItems.includes(item.index)).map(item => item.index);

        if (newCompleted.length > 0) {
            this.setState({
                uploadedItems: [...newCompleted, ...uploadedItems]
            });
        }
    }

    // Render list file with upload progress bar
    renderFileSet() {
        const items = this.props.items;
        const { progressClass: addProgressClass, onCancelFile: cancelFile } = this.props;
        const { uploadedItems } = this.state;
        if (items.length > 0) {
            const { cancelIconClass, completeIconClass } = this.props;

            return (
                <div className="list-group">
                    Documents Uploaded: {uploadedItems.length}/{items.length}
                    {items.filter(item => !item.cancelled && !!item.file).map(item => {
                        const file = item.file;
                        const sizeInMB = (file.size / (1024 * 1024)).toPrecision(2);
                        const iconClass = item.isCompleted ? completeIconClass : cancelIconClass;
                        const fileStyle = item.cancelled ? { display: "none" } : {};

                        // Progress bar class
                        const progressClass = ["progress-bar", "progress-bar-striped"];

                        if (addProgressClass) progressClass.push(addProgressClass);

                        if (item.isCompleted) {
                            progressClass.push("progress-bar-success");
                        } else if (item.error) {
                            progressClass.push("progress-bar-danger");
                        } else {
                            progressClass.push("progress-bar-info");
                            progressClass.push("active");
                        }

                        return (
                            <div key={item.index} className="list-group-item" style={fileStyle}>
                                <div style={styles.fileDetails}>
                                    <span className={`icon-file icon-large filetypes-unknown filetypes-${item.file.extension}`}>&nbsp;</span>
                                    <span style={styles.fileName}>{file.name}</span>
                                    <span style={styles.fileSize}>{`${sizeInMB} Mb`}</span>
                                    <i
                                        className={iconClass}
                                        style={{ cursor: "pointer" }}
                                        onClick={e => {
                                            e.stopPropagation();
                                            cancelFile(item.index);
                                        }}
                                    />
                                </div>
                                <div>
                                    <div className="progress">
                                        <div
                                            className={progressClass.join(" ")} role="progressbar"
                                            aria-valuenow={item.progress} aria-valuemin="0" aria-valuemax="100" style={{ width: `${item.progress}%` }}
                                        >
                                            {item.isCompleted ? "Completed" : `${item.progress}%`}
                                        </div>
                                    </div>
                                    {item.error && <span className="red-text">{item.error}</span>}
                                </div>
                            </div>
                        );
                    })}
                </div>
            );
        }
        return null;
    }

    render() {
        const { modalTitle, displayUploadButton, buttonLabel, onUploadButtonClick } = this.props;
        const { isOpen } = this.state;
        return (
            <Modal size={""} isOpen={isOpen}>
                <ModalBody>
                    <ModalTitle onClickClose={() => this.toggleModal()}>{modalTitle}</ModalTitle>
                    {this.renderFileSet()}
                </ModalBody>
                <ModalFooter>
                    <div>
                        {displayUploadButton &&
                            <button className="btn btn-small success-color w-100" onClick={() => onUploadButtonClick()}>
                                {buttonLabel}
                            </button>
                        }
                        <button className="btn btn-small white w-100" onClick={() => this.toggleModal()}>Close</button>
                    </div>
                </ModalFooter>
            </Modal>
        );
    }
}

UploadingModal.propTypes = {
    modalTitle: PropTypes.string,
    items: PropTypes.array,
    onToggle: PropTypes.func,
    onCancelFile: PropTypes.func,
    clearTimeOut: PropTypes.number,
    filesetTransitionName: PropTypes.string,
    styles: PropTypes.shape({}),
    cancelIconClass: PropTypes.string,
    completeIconClass: PropTypes.string,
    uploadIconClass: PropTypes.string,
    progressClass: PropTypes.string,
    displayUploadButton: PropTypes.bool,
    buttonLabel: PropTypes.string,
    onUploadButtonClick: PropTypes.func
};

UploadingModal.defaultProps = {
    modalTitle: "Upload Progress",
    clearTimeOut: 3000,
    filesetTransitionName: "fileset",
    cancelIconClass: "lnr lnr-cross-circle red-text",
    completeIconClass: "lnr lnr-checkmark-circle green-text",
    uploadIconClass: "lnr lnr-upload"
};

export default UploadingModal;