import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import defaultStyles from "./styles";
import CommonModal from "../common-modal/common-modal";
import UploadingModal from "./uploading-modal";
import { showError, showSuccess } from "../../screens/main-layout/actions";
// import {
//     SUCCESSFULLY_SAVED_MESSAGE,
//     SUCCESSFULLY_CREATED_MESSAGE
// } from "Constants";

class DragDropUploader extends Component {
    constructor(props) {
        super(props);
        this.state = { items: [], styles: Object.assign({}, defaultStyles, props.styles) };
        this.activeDrag = 0;
        this.xhrs = [];
    }

    onClick() {
        this.fileInput.click();
    }

    onUploadButtonClick() {
        this.upload();
    }

    handleFileSelect() {

        if (!this.fileInput.files) {
            return;
        }

        this.prepareFileForUpload(this.fileInput.files);
    }

    onDragEnter() {
        this.activeDrag += 1;
        this.setState({ isActive: this.activeDrag > 0 });
    }

    onDragOver(e) {
        if (e) {
            e.preventDefault();
        }
        return false;
    }

    onDragLeave() {
        this.activeDrag -= 1;
        if (this.activeDrag === 0) {
            this.setState({ isActive: false });
        }
    }

    onDrop(e) {
        if (!e) {
            return;
        }
        e.preventDefault();
        this.activeDrag = 0;
        const droppedFiles = e.dataTransfer ? e.dataTransfer.files : [];

        this.prepareFileForUpload(droppedFiles);

    }

    resetUploader() {
        // reset fileInput value
        this.fileInput.value = "";
        // this.fileInput.files = undefined;

        // set isActive to false to reset state of dropzone
        this.setState({
            isActive: false,
            items: []
        });
    }

    prepareFileForUpload(files) {
        if (files.length === 0) {
            return;
        }

        // show warning on over maxFile and return
        if (files.length > this.props.maxFiles) {
            this.commonModal.showModal({
                type: "warning",
                message: `Max files: ${this.props.maxFiles}`
            },
                () => {
                    console.log("Max file YES");
                },
                () => {
                    console.log("Max file NO");
                }
            );

            this.resetUploader();

            return;
        }

        // show confirm upload
        this.commonModal.showModal({
            type: "confirm",
            message: "Upload this file(s)?"
        }, () => {
            // handle "YES"

            const items = this.filesToItems(files);

            this.setState({ isActive: false, items }, () => {
                if (this.props.auto && this.state.items.length > 0) {
                    this.upload();
                }
            });

        }, () => {
            // handle "NO"

            this.resetUploader();
        });
    }

    updateFileProgress(index, fileAttributes) {
        const newItems = [...this.state.items];
        newItems[index] = Object.assign({}, this.state.items[index], { ...fileAttributes });
        this.setState({ items: newItems });
    }

    updateFileChunkProgress(index, chunkIndex, progress) {
        const newItems = [...this.state.items];
        const currentItem = this.state.items[index];
        const newProgressArr = [...currentItem.chunkProgress];
        const totalProgress = newProgressArr.reduce((a, b) => a + b) / (newProgressArr.length - 1);
        // -1 because there is always single chunk for "0" percentage pushed as chunkProgress.push(0) in method filesToItems)
        newProgressArr[chunkIndex] = progress;
        newItems[index] = Object.assign({}, currentItem, { chunkProgress: newProgressArr, progress: totalProgress });
        this.setState({ items: newItems });
    }

    cancelFile(index) {
        const newItems = [...this.state.items];
        newItems[index] = Object.assign({}, this.state.items[index], { cancelled: true });
        if (this.xhrs[index]) {
            this.xhrs[index].upload.removeEventListener("progress");
            this.xhrs[index].removeEventListener("load");
            this.xhrs[index].abort();
        }
        this.setState({ items: newItems });
    }

    upload() {
        this.uploadingModal.toggleModal();

        const items = this.state.items;
        if (items) {
            items.filter(item => !item.cancelled).forEach(item => {
                this.uploadItem(item);
            });
        }
    }

    uploadItem(item) {
        if (this.props.chunks && item.file) {
            const BYTES_PER_CHUNK = this.props.chunkSize;
            const SIZE = item.file.size;

            let start = 0;
            let end = BYTES_PER_CHUNK;

            const chunkProgressHandler = (percentage, chunkIndex) => {
                this.updateFileChunkProgress(item.index, chunkIndex, percentage);
            };
            let chunkIndex = 0;
            while (start < SIZE) {
                this.uploadChunk(item.file.slice(start, end), (chunkIndex += 1), item.file.name, chunkProgressHandler);
                start = end;
                end = start + BYTES_PER_CHUNK;
            }
        } else {
            this.uploadFile(item.file, (fileAttributes) => this.updateFileProgress(item.index, fileAttributes));
        }
    }

    uploadChunk(blob, chunkIndex, fileName, progressCallback) {
        if (blob) {
            const formData = new FormData();
            const xhr = new XMLHttpRequest();

            formData.append(this.props.fieldName, blob, `${fileName}-chunk${chunkIndex}`);

            xhr.onload = () => {
                progressCallback(100, chunkIndex);
            };
            xhr.upload.onprogress = e => {
                if (e.lengthComputable) {
                    progressCallback(e.loaded / e.total * 100, chunkIndex);
                }
            };
            xhr.open(this.props.method, this.props.url, true);
            xhr.send(formData);
        }
    }

    uploadFile(file, progressCallback) {
        if (file) {
            const formData = new FormData();
            const xhr = new XMLHttpRequest();

            formData.append(this.props.fieldName, file, file.name);

            xhr.onload = () => {
                const status = xhr.status;
                let isSuccess = true;
                const data = JSON.parse(xhr.responseText);
                if (status === 200) {
                    isSuccess = data.isSuccess;
                } else {
                    isSuccess = false;
                }

                if (isSuccess) {
                    progressCallback({
                        progress: 100,
                        isCompleted: true
                    });
                    this.props.onUploadFileSuccess(data.file);
                } else {
                    progressCallback({
                        progress: 100,
                        isCompleted: false,
                        error: `Upload error: ${data.message}`
                    });
                }
            };

            xhr.onerror = () => {
                progressCallback({
                    progress: 100,
                    isCompleted: false,
                    error: `Upload error: Can not connect to server`
                });
            };

            xhr.upload.onprogress = e => {
                if (e.lengthComputable) {
                    progressCallback({
                        progress: e.loaded / e.total * 100
                    });
                }
            };

            xhr.open(this.props.method, this.props.url, true);
            xhr.send(formData);
            this.xhrs[file.index] = xhr;
        }
    }

    filesToItems(files) {
        const { fileExtensions } = this.props;
        const fileItems = Array.prototype.slice.call(files).slice(0, this.props.maxFiles);

        const items = fileItems.filter((item) => {
            const ext = item.name.split(".").pop();

            return !Array.isArray(fileExtensions) || fileExtensions.indexOf(ext) !== -1;

        }).map((f, i) => {
            f.extension = f.name.split(".").pop();

            const item = { file: f, index: i, progress: 0, cancelled: false, isCompleted: false };

            if (this.props.chunks) {
                item.chunkProgress = [];
                for (let j = 0; j <= f.size / this.props.chunkSize; j += 1) {
                    item.chunkProgress.push(0);
                }
            }

            return item;
        });

        return items;
    }

    renderDropTarget() {
        const { uploadIconClass } = this.props;
        const { styles } = this.state;
        let dropTargetStyle = styles.dropTargetStyle;
        if (this.state.isActive) {
            dropTargetStyle = Object.assign({}, dropTargetStyle, styles.dropTargetActiveStyle);
        }
        return (
            <div
                data-test-id="dropTarget"
                style={dropTargetStyle}
                onClick={() => this.onClick()}
                onDragEnter={() => this.onDragEnter()}
                onDragOver={(e) => this.onDragOver(e)}
                onDragLeave={() => this.onDragLeave()}
                onDrop={(e) => this.onDrop(e)}
            >
                <div style={styles.placeHolderStyle}>
                    <p>{this.props.dropzoneLabel}</p>
                    <i className={uploadIconClass} />
                </div>
            </div>
        );
    }

    renderButton() {
        const { styles } = this.state;
        const displayButton = !this.props.auto;
        if (displayButton) {
            return (
                <button style={styles.uploadButtonStyle} onClick={this.onUploadButtonClick}>
                    {this.props.buttonLabel}
                </button>
            );
        }
        return null;
    }

    renderInput() {
        const { maxFiles, fileExtensions } = this.props;
        const attributes = {
            accept: fileExtensions ? fileExtensions.map(item => `.${item}`).join(",") : undefined
        };
        return (
            <input
                style={{ display: "none" }}
                multiple={maxFiles > 1}
                type="file"
                ref={c => {
                    if (c) {
                        this.fileInput = c;
                    }
                }}
                onChange={() => this.handleFileSelect()}
                {...attributes}
            />
        );
    }

    handleUploadingModalToggle(isOpen) {
        if (!isOpen) {
            this.setState({
                items: []
            });
        }
    }

    render() {
        const { styles, items } = this.state;
        return (
            <div style={styles.root}>
                {this.renderDropTarget()}
                {this.renderButton()}
                {this.renderInput()}
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
                <UploadingModal
                    ref={(uploadingModal) => { this.uploadingModal = uploadingModal; }}
                    items={items}
                    onCancelFile={(index) => this.cancelFile(index)}
                    onToggle={(isOpen) => isOpen ? "" : this.resetUploader()}
                />
            </div>
        );
    }
}

DragDropUploader.propTypes = {
    dispatch: PropTypes.func,
    url: PropTypes.string.isRequired,
    onUploadFileSuccess: PropTypes.func.isRequired,
    method: PropTypes.string,
    auto: PropTypes.bool,
    fieldName: PropTypes.string,
    buttonLabel: PropTypes.string,
    dropzoneLabel: PropTypes.string,
    chunks: PropTypes.bool,
    chunkSize: PropTypes.number,
    fileExtensions: PropTypes.array,
    maxFiles: PropTypes.number,
    clearTimeOut: PropTypes.number,
    filesetTransitionName: PropTypes.string,
    styles: PropTypes.shape({}),
    cancelIconClass: PropTypes.string,
    completeIconClass: PropTypes.string,
    uploadIconClass: PropTypes.string,
    progressClass: PropTypes.string
};

DragDropUploader.defaultProps = {
    method: "POST",
    auto: true,
    fieldName: "file",
    buttonLabel: "Upload",
    dropzoneLabel: "Drag and drop your files here or pick them from your computer",
    maxSize: 25 * 1024 * 1024,
    chunks: false,
    chunkSize: 512 * 1024,
    localStore: false,
    maxFiles: 1,
    encrypt: false,
    clearTimeOut: 3000,
    filesetTransitionName: "fileset",
    cancelIconClass: "fa fa-close",
    completeIconClass: "fa fa-check",
    uploadIconClass: "fa fa-upload"
};

export default connect()(DragDropUploader);