import React from "react";
import DragDropUploader from "./drag-drop-uploader";
import CommonModal from "../common-modal/common-modal";

class DemoDragDropUploader extends React.Component {
    constructor(props) {
        super(props);

        // All things just for demo
        const orderId = 1;

        this.state = {
            path: `/orderDocs/${orderId}/`,
            uploadedFiles: [],
            maxFiles: 5,
            fileExtensions: ["doc", "docx", "png", "jpg", "jpeg", "exe"]
        };
    }

    handleUploadFileSuccess(file) {
        const { uploadedFiles } = this.state;

        uploadedFiles.push(file);
        this.setState({
            uploadedFiles
        });
    }

    handleValidate(files) {
        const { fileExtensions, maxFiles } = this.state;

        if (files.length === 0) {
            return;
        }

        // show warning on over maxFile and return
        if (files.length > maxFiles) {
            this.commonModal.showModal({
                type: "warning",
                message: `Max files: ${maxFiles}`
            },
                () => {
                    // confirm
                }
            );

            return;
        }

        // Remove in valid file extension
        files = files.filter((file, index) => {
            const ext = file.name.split(".").pop();
            files[index].newName = `file-name-${index}.doc`;

            return file.type !== ""
                && (!Array.isArray(fileExtensions) || fileExtensions.indexOf(ext) !== -1);
        });

        // show confirm upload and start upload
        this.commonModal.showModal({
            type: "confirm",
            message: (<p>
                <strong>Upload this file(s)?</strong>
            </p>)
        }, () => {
            // handle "YES"
            this.uploader.upload(files);

        });
    }

    render() {

        const { uploadedFiles, maxFiles, fileExtensions, path } = this.state;

        const renderListUploadedFiles = uploadedFiles.map(file => {
            return (
                <div className="col m6" key={file.filename}>
                    <div className="panel panel-primary">
                        <div className="panel-heading">File name: {file.originalName}</div>
                        <div className="panel-body">
                            <p>Size: {file.size}</p>
                            <p>Path: {file.path}</p>
                            <p>Mime Type: {file.mimeType}</p>
                            <p>Destination: {file.destination}</p>
                        </div>
                    </div>
                </div>
            );
        });

        return (
            <div className="container">
                <DragDropUploader ref={uploader => { this.uploader = uploader; }}
                    path={path}
                    fileExtensions={fileExtensions}
                    onUploadFileSuccess={(file) => this.handleUploadFileSuccess(file)}
                    maxFiles={maxFiles}
                    onValidate={(files) => this.handleValidate(files)}
                />
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
                <hr />
                <div className="row">
                    {renderListUploadedFiles}
                </div>
            </div>
        );
    }
}

export default DemoDragDropUploader;