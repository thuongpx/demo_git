import React, { Component } from "react";
import FilteredInput from "./index";

class DemoFilteredInput extends Component {
    render() {
        return (
            <FilteredInput
                onChange={(value) => console.log(value)}
                onBlur={(e) => console.log(e)}
                type="alphaNumber" // alpha||number||alphaNumber - default: number
                maxLength="50"
            />
        );
    }
}

export default DemoFilteredInput;