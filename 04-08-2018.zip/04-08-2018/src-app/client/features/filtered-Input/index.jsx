import React, { Component } from "react";
import PropTypes from "prop-types";

class FilteredInput extends Component {
    constructor(props) {
        super(props);

        const patterns = {
            number: /^[\d]*$/,
            alpha: /^[\w]*$/,
            alphaNumber: /^[a-zA-Z0-9\s]*$/
        };

        const { pattern, type, value } = props;
        if (!pattern) {
            if (patterns[type]) {
                this.pattern = patterns[type];
            } else {
                this.pattern = patterns.number;
            }
        } else {
            this.pattern = pattern;
        }

        this.state = {
            value: value || ""
        };
    }

    onChange(e) {
        const value = e.target.value;
        if (value.match(this.pattern)) {
            if (this.props.onChange) {
                this.props.onChange(value);
            } else {
                this.setState({
                    value
                });
            }
        }
    }

    onBlur(e) {
        if (this.props.onBlur) this.props.onBlur(e.target.value);
    }

    render() {
        const { maxLength, className, id, disabled, title, ref } = this.props;

        const attributes = {
            maxLength,
            className,
            id,
            disabled,
            title,
            ref
        };

        return (
            <input type="text" value={this.props.onChange ? this.props.value : this.state.value}
                onChange={(e) => this.onChange(e)}
                onBlur={(e) => this.onBlur(e)}
                {...attributes}
            />
        );
    }
}

FilteredInput.propTypes = {
    onChange: PropTypes.func,
    onBlur: PropTypes.func,
    maxLength: PropTypes.string,
    type: PropTypes.string,
    pattern: PropTypes.string,
    value: PropTypes.string,
    className: PropTypes.string,
    id: PropTypes.string,
    disabled: PropTypes.bool,
    title: PropTypes.string,
    ref: PropTypes.string
};

export default FilteredInput;