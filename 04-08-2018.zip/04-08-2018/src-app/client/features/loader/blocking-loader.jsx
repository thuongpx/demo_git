import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";

import { guid } from "../../helpers/crypto-helper";

class BlockingLoader extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        const { isShow, text } = this.props;

        return (
            <div>
                {isShow && <div key={guid()} className="page-loader"><div className="loader">{text}</div>
                    <span className="flashit" style={{ position: "absolute", top: "9.5%", left: "43%" }}>{text}</span>
                </div>
                }
            </div>
        );
    }
}

BlockingLoader.propTypes = {
    text: PropTypes.string,
    onlyIcon: PropTypes.bool,
    isShow: PropTypes.bool
};

export default BlockingLoader;