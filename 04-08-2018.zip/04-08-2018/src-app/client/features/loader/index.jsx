import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";

import { guid } from "../../helpers/crypto-helper";

class Loader extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        const { children, isShow, onlyIcon } = this.props;

        return (
            <div>
                {isShow &&
                    <div key={guid()} className="page-loader"><div className="loader">Loading...</div>
                        {onlyIcon &&
                            <span className="flashit" style={{ position: "absolute", top: "9.5%", left: "43%" }}>Loading...</span>
                        }
                    </div>}
                {!isShow &&
                    <div>
                        {children}
                    </div>
                }
            </div>
        );
    }
}

Loader.propTypes = {
    isShow: PropTypes.bool,
    onlyIcon: PropTypes.bool
};

export default Loader;