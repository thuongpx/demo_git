import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";

import DragDropTable from "./drag-drop-table";

class DemoDragDropTable extends React.Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
    }

    render() {
        const arr1 = ["#", "Name", "Birthday", "Company"];
        const arr2 = [
            {
                id: "160-54",
                name: "Grace J. Bishop",
                birthday: "January 18, 1997",
                company: "American Wholesale Club"
            },
            {
                id: "563-52",
                name: "Holly D. Fogel",
                birthday: "October 30, 1967",
                company: "Magik Gray"
            },
            {
                id: "678-01",
                name: "Adrienne R. Stead",
                birthday: "July 31, 1978",
                company: "Terra"
            },
            {
                id: "678-07",
                name: "Krista R. Duckworth",
                birthday: "November 18, 1974",
                company: "Kessel Food Market"
            },
            {
                id: "503-11",
                name: "Daniel D. Ford",
                birthday: "October 2, 1938",
                company: "Custom Lawn Service"
            },
            {
                id: "097-50",
                name: "Robert A. Miller",
                birthday: "February 20, 1971",
                company: "Asian Plan"
            }
        ];

        return (
            <div>
                <DragDropTable source={arr2} handleOnEnd={(evt) => this.handleOnEnd(evt)} />
            </div>
        );
    }
}

DemoDragDropTable.propTypes = {
    dispatch: PropTypes.func,
    paymentLoaded: PropTypes.func,
    paymentLoading: PropTypes.func
};

export default connect(null, null, null, { withRef: true })(DemoDragDropTable);
