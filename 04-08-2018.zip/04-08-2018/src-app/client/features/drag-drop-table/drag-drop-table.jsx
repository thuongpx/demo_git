import React from "react";
import { connect } from "react-redux";
import { Component } from "react";
import PropTypes from "prop-types";

import { showError } from "../../screens/main-layout/actions";
import { guid } from "../../helpers/crypto-helper";

class DragDropTable extends Component {
    constructor(props) {
        super(props);

        this.state = {
            tableId: `dnd-body-${guid()}`,
            sortable: {},
            rows: {}
        };
    }

    bindingSortable() {
        const $table = $(`#${this.state.tableId}`);

        const {
            handleOnChoose,
            handleOnStart,
            handleOnEnd,
            handleOnAdd,
            handleOnUpdate,
            handleOnSort,
            handleOnRemove,
            handleOnFilter,
            handleOnMove,
            handleSetData
        } = this.props;

        // eslint-disable-next-line
        const sortable = new Sortable($table[0], {
            animation: 150,
            ghostClass: "dnd-table-ghost",
            setData: (dataTransfer, dragEl) => {
                if (handleSetData) {
                    handleSetData(dataTransfer, dragEl);
                }
            },
            // Element is chosen
            onChoose: (evt) => {
                if (handleOnChoose) {
                    handleOnChoose(evt);
                }
            },
            // Element dragging started
            onStart: (/**Event*/evt) => {
                if (handleOnStart) {
                    handleOnStart(evt);
                }
            },
            // Element dragging ended
            onEnd: (/**Event*/evt) => {
                if (handleOnEnd) {
                    handleOnEnd(evt);
                }
            },
            // Element is dropped into the list from another list
            onAdd: (/**Event*/evt) => {
                if (handleOnAdd) {
                    handleOnAdd(evt);
                }
            },
            // Changed sorting within list
            onUpdate: (/**Event*/evt) => {
                if (handleOnUpdate) {
                    handleOnUpdate(evt);
                }
            },
            // Called by any change to the list (add / update / remove)
            onSort: (/**Event*/evt) => {
                if (handleOnSort) {
                    handleOnSort(evt);
                }
            },
            // Element is removed from the list into another list
            onRemove: (/**Event*/evt) => {
                if (handleOnRemove) {
                    handleOnRemove(evt);
                }
            },
            // Attempt to drag a filtered element
            onFilter: (/**Event*/evt) => {
                if (handleOnFilter) {
                    handleOnFilter(evt);
                }
            },
            // Event when you move an item in the list or between lists
            onMove: (/**Event*/evt, /**Event*/originalEvent) => {
                if (handleOnMove) {
                    handleOnMove(evt, originalEvent);
                }
            }
        });

        // sortable.sort();
    }

    componentDidMount() {
        this.bindingSortable();
    }

    componentDidUpdate() {
        this.bindingSortable();
    }

    componentWillReceiveProps(nextProps) {
        const { source, primaryKey } = nextProps;
        if (this.props.allowFocus) {
            if (this.props.source.length !== source.length) {
                const rows = {};
                source.forEach(data => {
                    rows[data[primaryKey]] = false;
                });
                this.setState({
                    rows
                });
            }
        }
    }

    handleClick(rowID) {
        if (this.props.allowFocus) {
            const prevValue = this.state.rows[`${rowID}`];
            const { rows } = this.state;

            this.setState({
                rows: {
                    ...rows,
                    [rowID]: !prevValue
                }
            });
        }

    }

    buildHeaders() {
        const { isShowHeaders, columns } = this.props;

        if (isShowHeaders === undefined || !isShowHeaders) {
            return (<tr></tr>);
        }

        const headerCells = columns.map((item, index) => {
            return (<td key={index}>{item.header}</td>);
        });

        return (<tr>
            {headerCells}
        </tr>);
    }

    buildBody() {
        const { source, dispatch, columns, highlightKey, primaryKey, onRowClick, onRowMouseUp } = this.props;

        const buildRow = (data, index) => {
            const cells = [];

            columns.map((item, key) => {
                if (data[highlightKey] !== undefined && data[highlightKey]) {
                    cells.push(<td className="center-align blue-text" key={key}>{data[item.dataField]}</td>);
                } else {
                    cells.push(<td className="center-align" key={key}>{data[item.dataField]}</td>);
                }
            });

            return (
                <tr className={this.state.rows[data[primaryKey]] ? "selected-row-vender" : ""} onClick={() => this.handleClick(data[primaryKey])} key={index} id={data[primaryKey]} onMouseDown={() => { if (onRowClick) onRowClick(data[primaryKey]); }} onMouseUp={() => { if (onRowMouseUp) onRowMouseUp(data[primaryKey]); }} >{cells}</tr>
            );
        };

        if (!source || !Array.isArray(source)) {
            dispatch(showError(`Source of table should be an array.`));
            return (<tr></tr>);
        }

        // build table
        return source.map((item, index) => {
            return buildRow(item, index);
        });
    }

    render() {
        const { tableId } = this.state;

        return (
            <div>
                <table className="table">
                    <thead>
                        {this.buildHeaders()}
                    </thead>
                    <tbody id={tableId}>
                        {this.buildBody()}
                    </tbody>
                </table>
            </div>
        );
    }
}
DragDropTable.defaultProps = {
    allowFocus: false
};

DragDropTable.propTypes = {
    dispatch: PropTypes.func,
    isShowHeaders: PropTypes.bool,
    source: PropTypes.array,
    handleOnChoose: PropTypes.func,
    handleOnStart: PropTypes.func,
    handleOnEnd: PropTypes.func,
    handleOnAdd: PropTypes.func,
    handleOnUpdate: PropTypes.func,
    handleOnSort: PropTypes.func,
    handleOnRemove: PropTypes.func,
    handleOnFilter: PropTypes.func,
    handleOnMove: PropTypes.func,
    handleSetData: PropTypes.func,
    columns: PropTypes.array,
    highlightKey: PropTypes.string,
    primaryKey: PropTypes.string,
    onRowClick: PropTypes.func,
    onRowMouseUp: PropTypes.func,
    allowFocus: PropTypes.bool
};

export default connect()(DragDropTable);

