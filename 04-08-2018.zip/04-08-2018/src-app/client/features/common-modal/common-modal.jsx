import React from "react";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";

import { Component } from "react";

class CommonModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false,
            confirmYesButton: "Yes",
            confirmNoButton: "No",
            isJSX: false,
            isNoFocus: false
        };
    }

    componentDidUpdate() {
        setTimeout(() => {
            if (this.state.isNoFocus) {
                this.noButton.focus();
            } else if (this.yesButton) {
                this.yesButton.focus();
            }
        }, 100);
    }

    showModal({ type, message, isNoFocus, isWarningWithOneButton, addClass }, callback, callbackCancel, isJSX = false, confirmYesButton = "Yes", confirmNoButton = "No") {
        let noFocus = false;

        if (!isJSX && (message.toLowerCase().indexOf("are you sure you would like to remove") > -1 || message.toLowerCase().indexOf("are you sure you would like to delete") > -1 || message.toLowerCase().indexOf("are you sure you want to delete") > -1 || message.toLowerCase().indexOf("are you sure you would like to deactivate") > -1)) {
            noFocus = true;
        } else {
            noFocus = false;
        }

        if (isNoFocus) {
            noFocus = isNoFocus;
        }

        this.setState({ isOpen: true, type, message, callback, callbackCancel, isJSX, isNoFocus: noFocus, confirmYesButton, confirmNoButton, isWarningWithOneButton, addClass });
    }

    handleYesAction() {
        this.setState({ isOpen: false }, () => {
            if (this.state.callback !== undefined) {
                this.state.callback();
            }
        });
    }

    handleNoAction() {
        const { callbackCancel } = this.state;

        this.setState({ isOpen: false }, () => {
            if (callbackCancel !== undefined) {
                callbackCancel();
            };
        });
    }

    render() {
        const { type } = this.state;

        const renderTitle = () => {
            switch (type) {
                case "confirm":
                    return (<span>Confirmation Message</span>);
                case "warning":
                    return (<span>Warning Message</span>);
                case "error":
                    return (<span>Error Message</span>);
                case "resendEmail":
                    return (<span>Re-sent Email Successfully</span>);
                case "inviteSent":
                    return (<span>Invites Sent</span>);
                default:
                    return (<span>Information Message</span>);
            }
        };

        const renderIcon = () => {
            switch (type) {
                case "confirm":
                    return (<span className="fa fa-question-circle"></span>);
                case "warning":
                    return (<span className="fa fa-warning"></span>);
                case "error":
                    return (<span className="fa fa-times-circle"></span>);
                default:
                    return (<span className="fa fa-info-circle"></span>);
            }
        };

        return (
            <Modal size={""} isOpen={this.state.isOpen} fixedFooter={false} style={{ width: "45%" }} addclassName={`${this.state.addClass}`} addClass={`common-popup ${type === "confirm" ? "confirm-com" : ""} ${type === "warning" ? "warning-com" : ""} ${type === "error" ? "error-com" : ""} `}>
                <ModalTitle onClickClose={() => {
                    if (type === "confirm" || type === "warning") {
                        this.handleNoAction();
                    } else {
                        this.handleYesAction();
                    }
                }} className="text-primary">{renderIcon()}{renderTitle()}</ModalTitle>
                <ModalBody>
                    <div className="row mb-0">
                        <div className="col s12">
                            {this.state.isJSX ? this.state.message : <p className="m-0">{this.state.message}</p>}
                        </div>
                    </div>
                </ModalBody>
                <ModalFooter>
                    {
                        type === "confirm" || type === "warning" ? <div className="row m-0">

                            {this.state.isWarningWithOneButton ? <span></span> : <div className="col s6"> <button ref={(noButton) => { this.noButton = noButton; }} className="btn white w-100" onClick={() => this.handleNoAction()}>{this.state.confirmNoButton}</button> </div>}

                            <div className={this.state.isWarningWithOneButton ? "col m6 offset-m3" : "col s6"}>
                                <button ref={(yesButton) => { this.yesButton = yesButton; }} className="btn success-color w-100" style={{ marginRight: 5 }} onClick={() => this.handleYesAction()}>{this.state.confirmYesButton}</button>
                            </div>
                        </div> : null
                    }
                    {
                        type !== "confirm" && type !== "warning" ? <div className="row"><div className="col s12 m6 center-col"><button className="btn success-color w-100" onClick={() => { this.setState({ isOpen: false }); this.handleYesAction(); }}>OK</button></div></div> : null
                    }
                </ModalFooter>
            </Modal>
            // <div className="modal custome-modal open" style={{ width: "600px" }}>
            //     <p className="header-title-modal" style={{
            //         margin: 0,
            //         padding: "1rem 2rem",
            //         background: "#ffcea9",
            //         fontSize: "13pt",
            //         fontWeight: "400",
            //         color: "#ab4900"
            //     }}
            //     >
            //         <span className="fa fa-warning" style={{ marginRight: "10px" }}></span><span>Warning Message</span></p>
            //     <div className="modal-content">
            //         <div className="row">
            //             <div className="col s12">
            //                 <p className="m-0">The followings in your Client Profile have not been completed yet. [Contact Information, Billing Setup, Return Address]. Please update your Client Profile before placing a new order.</p>
            //             </div>
            //         </div>
            //     </div>
            //     <div className="modal-footer" style={{ height: "auto", borderTop: "1px solid #eee" }}>
            //         <div className="row m-0">
            //             <div className="col s6 offset-s3"><button className="btn success-color w-100">OK</button></div>
            //         </div>
            //     </div>
            // </div>
        );
    }
}

export default CommonModal;