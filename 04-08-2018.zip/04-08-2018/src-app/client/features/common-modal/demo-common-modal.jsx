import React from "react";
import CommonModal from "./common-modal";

class DemoCommonModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isShowModal: false
        };
    }

    handleShowConfirm() {
        this.commonModal.showModal({
            type: "confirm",
            message: "This is confirmation message."
        }, () => {
            //handle callback yes click here
        });
    }

    handleShowWarning() {
        this.commonModal.showModal({
            type: "warning",
            message: "This is warning message."
        }, () => {
            //handle callback yes click here
        });
    }


    render() {
        return (
            <div>
                <button className="btn default-color" onClick={ this.handleShowConfirm.bind(this)
                }
                >Show Confirm</button>
                <button className="btn error-color" onClick={ () =>
                    this.commonModal.showModal({ type: "error", message: "This is error message." })
                }
                >Show Error</button>
                <button className="btn success-color" onClick={ () =>
                    this.commonModal.showModal({ type: "infor", message: "This is information message." })
                }
                >Show Infor</button>
                <button className="btn btn-warning" onClick={ this.handleShowWarning.bind(this)
                }
                >Show Warning</button>
                <CommonModal ref={ (commonModal) => { this.commonModal = commonModal; } } />
            </div >
        );
    }
}

export default DemoCommonModal;