import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";

import InputMask from "react-input-mask";

import { guid } from "./../../helpers/crypto-helper";
import { parseDateToString, parseDateTimeToString, hasStringValue } from "./../../helpers/common-helper";
import { validateDateTimeStringByMoment, validateDateByMoment, validateTime } from "./../../helpers/validation-helper";
import { updateTextFields } from "./../../helpers/theme-helper";

class DateTimePicker extends Component {
    constructor(props) {
        super(props);

        const controlId = this.props.id || `date-picker-${guid()}`;

        this.tempValue = "";
        this.selectedDateValue = "";
        this.isInvalid = false;

        this.state = {
            controlId,
            controlTimeId: `${controlId}-time`,
            controlDateId: `${controlId}-date`,
            triggerId: `${controlId}-trigger`,
            controlValueId: `${controlId}-value`,
            controlMessageId: `${controlId}-message`,
            controlWrapperId: `${controlId}-wrapper`,
            controlValue: ""
        };
    }

    setDate(value) {
        // eslint-disable-next-line
        const instance = M.Datepicker.getInstance($(`#${this.state.controlDateId}`));

        this.isSetDefaultValue = true; // to make this component not to re-render
        instance.setDate(new Date(value));
    }

    setTime(value = "") {
        if (!value) {
            value = "";
        }

        // get only time string
        const str = value.split(" ");

        if (str.length === 3) {
            // destroy the current instance
            // eslint-disable-next-line
            const instance = M.Timepicker.getInstance($(`#${this.state.controlTimeId}`));
            const time = `${str[str.length - 2]} ${str[str.length - 1]}`;

            $(`#${this.state.controlTimeId}`).val(time);
        }
    }

    showError(message, isRequired) {
        const { controlValueId, controlWrapperId, triggerId } = this.state;
        const colorTextClass = !isRequired ? "red-text" : "yellow-text";

        if (isRequired && this.isInvalid) return;

        $(`#${triggerId}`).removeClass("yellow-text");
        $(`#${triggerId}`).removeClass("red-text");

        if (isRequired) {
            $(`#${triggerId}`).addClass(colorTextClass);
        } else if (message && message !== "") {
            this.isInvalid = true;
            $(`#${controlWrapperId}`).addClass("has-error");
            $(`#${controlValueId}`).addClass("invalid");
            $(`#${controlValueId}`).removeClass("valid");
            $(`#${triggerId}`).addClass(colorTextClass);
        } else {
            this.isInvalid = false;
            $(`#${controlWrapperId}`).removeClass("has-error");
            $(`#${controlValueId}`).addClass("valid");
            $(`#${controlValueId}`).removeClass("invalid");
        }

        $(`#${triggerId}`).prop("title", message);
        $(`#${controlValueId}`).prop("title", message);
    }

    componentWillReceiveProps(nextProps) {
        // set value
        const { defaultValue, invalidMessage, requiredMessage } = nextProps;
        const isValidDate = validateDateTimeStringByMoment(defaultValue);

        if (hasStringValue(invalidMessage)) {
            // show message
            this.showError(invalidMessage);
        } else if (hasStringValue(requiredMessage)) {
            // show message
            this.showError(requiredMessage, true);
        } else if (isValidDate || defaultValue === "") {
            this.refs.controlValue.value = defaultValue;
            this.showError("");

            if (defaultValue === "") {
                $($(`#${this.state.controlWrapperId}`).find("label")[0]).removeClass("active");
                $(`#${this.state.controlValueId}`).removeClass("valid");
            }
        }
    }

    componentDidMount() {
        this.bindingControl(true);
    }

    componentDidUpdate() {
        this.bindingControl();
    }

    initTimePicker(config) {
        const { controlTimeId } = this.state;
        const timeConfig = {
            onSelect: (e) => this.handleOnSelect(e),
            container: "body",
            twelveHour: true,
            ...config
        };
        $(`#${controlTimeId}`).timepicker(timeConfig);
    }

    initDatePicker() {
        const { controlDateId } = this.state;

        $(`#${controlDateId}`).datepicker({
            onSelect: (e) => this.handleOnSelect(e),
            container: "body"
        });
    }

    triggerDatePicker() {
        // eslint-disable-next-line
        const date = M.Datepicker.getInstance($(`#${this.state.controlDateId}`)); // get instance of date

        date.open();
    }

    triggerTimePicker() {
        // eslint-disable-next-line
        const time = M.Timepicker.getInstance($(`#${this.state.controlTimeId}`)); // get instance of time

        if (time) {
            time.open();
        }
    }

    bindingControl(isMounted) {
        const { className } = this.props;
        const { controlTimeId, controlDateId } = this.state;

        if (className && className !== "") {
            const classes = className.split(" ");

            for (let i = 0; i < classes.length; i++) {
                $(`#${controlTimeId}`).addClass(classes[i]);
                $(`#${controlDateId}`).addClass(classes[i]);
            }
        }

        if (isMounted) {

            this.initTimePicker({});
            this.initDatePicker();

            $(`#${controlDateId}`).change((e) => this.handleOnChange(e));
            $(`#${controlTimeId}`).change((e) => this.handleOnChange(e));
        }
    }

    componentWillUnmount() {
        $(`#${this.state.controlDateId}`).datepicker("destroy");
        $(`#${this.state.controlTimeId}`).timepicker("destroy");
    }

    handleTriggerOnClick() {
        this.triggerDatePicker();
        // this.triggerTimePicker();
    }

    handleOnSelect() {
        // set defaultSelect to false
        if (this.isSetDefaultValue) {
            this.isSetDefaultValue = false;
        }
    }

    handleOnBlur(e) {
        const { onBlur } = this.props;
        const { controlValueId, controlWrapperId } = this.state;

        // set value for datepicker
        const value = $(`#${controlValueId}`).val();

        if (value && value !== "") {
            const isValidDate = validateDateTimeStringByMoment(value);

            if (isValidDate) {
                this.showError("");
                this.setDate(new Date(value)); // set date
                this.setTime(value); // set time
            } else {
                this.showError("Date and time is not valid");
            }
        } else {
            $($(`#${controlWrapperId}`).find("label")[0]).removeClass("active");
            $(`#${controlValueId}`).removeClass("valid");
        }

        if (onBlur) onBlur(e.target.value);
    }

    handleOnChange(e) {
        const { controlValueId } = this.state;
        const { onBlur } = this.props;
        const isDatePicker = $(e.target).hasClass("datepicker");
        const hasValue = e.target.value && e.target.value !== "";
        let value = "";

        // check if this is a timepicker or not
        if (isDatePicker) {
            // datepicker
            if (!this.isSetDefaultValue && validateDateByMoment(new Date(e.target.value))) {
                value = parseDateToString(new Date(e.target.value));
            }
        }

        if (!isDatePicker) {
            // timepicker
            if (!this.isSetDefaultValue && validateTime(e.target.value)) {
                value = parseDateTimeToString(e.target.value, this.selectedDateValue);
            }
        }

        // bind value
        if (!isDatePicker || !hasValue) {
            this.refs.controlValue.setInputValue(value);
        } else {
            this.selectedDateValue = value;
        }

        // open the time picker
        if (isDatePicker && hasValue) {
            this.triggerTimePicker();
        }

        // clear value
        if (!isDatePicker || !hasValue) {
            $(`#${controlValueId}`).focus();
            updateTextFields();

            if (onBlur) onBlur(value);
        }
    }

    render() {
        const { controlDateId, controlTimeId, triggerId, controlValueId, controlWrapperId } = this.state;
        const { labelText, disabled, isRequiredField, placeholder } = this.props;

        const mask = "22/22/2222 22:22 56";
        const formatChars = {
            "1": "[0-1]",
            "2": "[0-9]",
            "3": "[0-5]",
            "5": "[A, P, a, p]",
            "6": "[M, m]"
        };

        return (
            <div id={controlWrapperId} className={`input-field suffixinput ${isRequiredField ? "required" : ""}`}>
                <label htmlFor={controlValueId}>{labelText}</label>
                <input type="hidden" id={controlDateId} className="datepicker" />
                <input type="hidden" id={controlTimeId} className="timepicker" />
                <InputMask
                    type="text"
                    id={controlValueId}
                    className="validate"
                    mask={mask}
                    formatChars={formatChars}
                    onBlur={(e) => this.handleOnBlur(e)}
                    ref="controlValue"
                    placeholder={placeholder || ""}
                    {...{ disabled }}
                />
                <span className="suffix-text cursor-pointer" style={{ zIndex: "100" }} id={triggerId} onClick={(e) => this.handleTriggerOnClick(e)}><i className="material-icons">event</i></span>
            </div>
        );
    }
}

DateTimePicker.propTypes = {
    id: PropTypes.string,
    onBlur: PropTypes.func,
    className: PropTypes.string,
    message: PropTypes.string,
    labelText: PropTypes.string,
    defaultValue: PropTypes.string,
    requiredMessage: PropTypes.string,
    invalidMessage: PropTypes.string,
    disabled: PropTypes.bool,
    placeholder: PropTypes.string,
    isRequiredField: PropTypes.bool
};

export default DateTimePicker;