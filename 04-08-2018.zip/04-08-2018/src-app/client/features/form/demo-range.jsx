import React, {Component} from "react";
import Range from "./range";

class DemoRange extends Component {
    handleOnChange(values, index) {
        const value = values[index];

        this.refs.valueInput.value = value;
    }

    render() {
        return (
            <div>
                <h1 className="center-align">Demo Range</h1>
                <div className="row">
                    <div className="col s4">
                        <Range
                            min={1}
                            max={31}
                            connect={[true, false]}
                            onChange={(values, handle) => this.handleOnChange(values, handle)}
                            tooltips={[true]}
                        />
                    </div>
                </div>
                <div className="row">
                    <label>Value:</label>
                    <input type="text" ref="valueInput"/>
                </div>
            </div>
        );
    }
}

export default DemoRange;