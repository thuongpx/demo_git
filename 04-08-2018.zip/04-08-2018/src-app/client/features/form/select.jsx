import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";

import { guid } from "./../../helpers/crypto-helper";
import { compareArrays } from "./../../helpers/common-helper";
import { updateSelectField } from "./../../helpers/theme-helper";

class Select extends Component {
    constructor(props) {
        super(props);

        const { id, disabled } = this.props;

        this.selectId = id || `select_${guid()}`;
        this.currentValue = "";
        this.currentStatus = disabled;
        this.currentDataSource = [];
        this.selectContentId = `select_content_${guid()}`;
        this.ulSelectOptionId = "";
    }

    componentWillReceiveProps(nextProps) {
        const { dataSource } = nextProps;

        if (!dataSource) nextProps.dataSource = [];
    }

    needToReload(isMounted) {
        const { dataSource, value, disabled } = this.props;

        const hasValueChanged = this.currentValue !== value;
        const hasDisabledChanged = this.currentStatus !== disabled;
        const hasSourceChanged = !compareArrays(this.currentDataSource, dataSource);

        return hasSourceChanged || hasValueChanged || hasDisabledChanged || isMounted;
    }

    bindingOption(isMounted) {
        const { className, dataSource, value, disabled } = this.props;

        // check if this select has binded
        if (this.needToReload(isMounted)) {
            this.currentValue = value;
            this.currentStatus = disabled;
            this.currentDataSource = dataSource;
            $(`#${this.selectId}`).formSelect({ classes: className, dropdownOptions: { container: document.body } });
            $(".select-wrapper").each((i, obj) => {
                if ($(obj).find(".custome-style-select").length !== 0 && $(obj).find(".caret.updown").length === 0) {
                    $(obj).find("svg").remove();
                    $(obj).append("<span class=\"caret updown\"></span>");
                }
            });
            $(`#${this.selectContentId}>div.select-wrapper`).each((i, obj) => {
                if ($(obj).find(".select-dropdown.dropdown-trigger").length !== 0) {
                    this.ulSelectOptionId = $(`#${this.selectContentId}>div.select-wrapper>input.select-dropdown.dropdown-trigger`).attr("data-target");
                }
            });
            updateSelectField(this.selectId); // update label
        }
    }

    componentDidMount() {
        this.bindingOption(true);
    }

    componentDidUpdate() {
        this.bindingOption();
    }

    componentWillUnmount() {
        if ($(`#${this.selectId}`)) $(`#${this.selectId}`).formSelect("destroy");
    }

    handleOnChange(e) {
        const selectedValue = e.target.value;
        const { onChange } = this.props;

        if (onChange) {
            onChange(selectedValue, e);
        }

        $(`#${this.selectId}`).parent().find(">:first-child")[0].focus();

        this.value = selectedValue;
        this.selectedText = e.target.multiple ? "" : e.target.selectedOptions[0].text;
    }

    getSelectOptionsId() {
        return this.ulSelectOptionId;
    }

    render() {
        const { dataSource, value, style, mapDataToRenderOptions, optionDefaultLabel, disabled } = this.props;
        const renderOption = dataSource.map((item, index) => {
            let labelStr = ``;
            if (mapDataToRenderOptions) {
                if (Array.isArray(mapDataToRenderOptions.label)) {
                    mapDataToRenderOptions.label.forEach((itemLabel) => {
                        if (item[itemLabel]) labelStr = labelStr === `` ? `${item[itemLabel]}` : `${labelStr} ${mapDataToRenderOptions.dividerChar || "|"} ${item[itemLabel]}`;
                    });
                } else {
                    labelStr = item[mapDataToRenderOptions.label];
                }
                return (
                    <option key={index} value={item[mapDataToRenderOptions.value]}>{labelStr}</option>
                );
            } else {
                return (
                    <option key={index} value={item}>{item}</option>
                );
            }
        });

        return (
            <div id={this.selectContentId}>
                <select
                    tabIndex={-1}
                    id={this.selectId}
                    value={value}
                    onChange={(e) => this.handleOnChange(e)}
                    style={style}
                    ref="selectRef"
                    disabled={disabled}
                    className="icons w-100 custome-style-select validate"
                >
                    {optionDefaultLabel && <option value="">{optionDefaultLabel}</option>}
                    {renderOption}
                </select>
            </div>
        );
    }
}

Select.defaultProps = {
    dataSource: [],
    value: "",
    style: {},
    className: "",
    optionDefaultLabel: "",
    selectedText: ""
};

Select.propTypes = {
    dataSource: PropTypes.array,
    value: PropTypes.any,
    onChange: PropTypes.func,
    id: PropTypes.string,
    style: PropTypes.object,
    className: PropTypes.string,
    mapDataToRenderOptions: PropTypes.object,
    optionDefaultLabel: PropTypes.string,
    disabled: PropTypes.bool,
    selectedText: PropTypes.string
};

export default Select;