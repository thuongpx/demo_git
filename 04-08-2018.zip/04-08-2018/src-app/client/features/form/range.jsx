import React, { Component } from "react";
// import noUiSlider from "./noui-slider";
import { guid } from "../../helpers/crypto-helper";
import PropTypes from "prop-types";

class Range extends Component {
    constructor(props) {
        super(props);

        this.id = `range-${guid()}`;

        this.componentPropNames = [
            "min",
            "max",
            "onChange",
            "onBlur"
        ];
    }

    initRange() {
        const options = {...this.props};
        const { onChange } = this.props;
        this.element = document.getElementById(this.id);

        options.range = {
            min: options.min,
            max: options.max
        };

        options.format = {
            to: (value) => {
                return Math.floor(+value);
            },
            from: (value) => {
                return Math.floor(+value);
            }
        };

        // delete component props to get noUiSlider props
        this.componentPropNames.forEach(propName => {
            if (options[propName] !== undefined) {
                delete options[propName];
            }
        });

        // eslint-disable-next-line
        noUiSlider.create(this.element, options);

        this.element.noUiSlider.on("change", (values, handle) => {
            this.values = values;
            if (onChange) onChange(values, handle);
        });

        // todo
        this.addKeyboardSupport();
    }

    componentDidUpdate() {
        const { values } = this.props;

        if (values !== this.values) {
            this.element.noUiSlider.set(values);
        }
    }

    addKeyboardSupport() {
        const { step } = this.props;

        const handle = this.element.querySelector(".noUi-handle");

        handle.addEventListener("keydown", (e) => {

            const value = Number(this.element.noUiSlider.get());

            if (e.which === 37) {
                this.element.noUiSlider.set(value - step);
            }

            if (e.which === 39) {
                this.element.noUiSlider.set(value + step);
            }
        });
    }

    componentDidMount() {
        this.initRange();
    }

    render() {
        const { showTooltips, min, max, showMinMaxTooltips, disabled } = this.props;

        const attributes = {
            id: this.id,
            className: showTooltips ? "show-tooltips" : "",
            disabled
        };

        return (
            <div {...attributes}>
                {showMinMaxTooltips &&
                    <div className="noUi-handle tooltips-mark noUi-active">
                        <div className="noUi-tooltip grey"><span>{min}</span></div>
                    </div>
                }
                {showMinMaxTooltips &&
                    <div className="noUi-handle tooltips-mark max noUi-active">
                        <div className="noUi-tooltip grey"><span>{max}</span></div>
                    </div>
                }
            </div>
        );
    }
}

Range.defaultProps = {
    step: 1,
    start: 0,
    tooltips: true,
    showTooltips: true,
    showMinMaxTooltips: true
};

Range.propTypes = {
    orientation: PropTypes.oneOf(["horizontal", "vertical"]),
    direction: PropTypes.oneOf(["ltr", "rtl"]),
    min: PropTypes.number.isRequired,
    max: PropTypes.number.isRequired,
    step: PropTypes.number,
    start: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.array
    ]),
    connect: PropTypes.oneOfType([
        PropTypes.bool,
        PropTypes.array
    ]),
    margin: PropTypes.number,
    padding: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.array
    ]),
    limit: PropTypes.number,
    tooltips: PropTypes.oneOfType([
        PropTypes.bool,
        PropTypes.array
    ]),
    animate: PropTypes.bool,
    animationDuration: PropTypes.number,
    onChange: PropTypes.func,
    onBlur: PropTypes.func,
    showTooltips: PropTypes.bool,
    showMinMaxTooltips: PropTypes.bool,
    disabled: PropTypes.bool,
    values: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.array
    ])
};

export default Range;