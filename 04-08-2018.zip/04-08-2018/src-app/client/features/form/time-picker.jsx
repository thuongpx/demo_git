import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";

import InputMask from "react-input-mask";

import { guid } from "./../../helpers/crypto-helper";
import { parseTimeToString, hasStringValue } from "./../../helpers/common-helper";
import { validateDateByMoment, validateTime } from "./../../helpers/validation-helper";
import { updateTextFields } from "./../../helpers/theme-helper";

class TimePicker extends Component {
    constructor(props) {
        super(props);

        const controlId = this.props.id || `time-picker-${guid()}`;
        this.isSetDefaultValue = false;
        this.isInvalid = false;

        this.state = {
            controlId,
            triggerId: `${controlId}-trigger`,
            controlValueId: `${controlId}-value`,
            controlMessageId: `${controlId}-message`,
            controlWrapperId: `${controlId}-wrapper`
        };
    }

    initTimePicker(config) {
        const { controlId } = this.state;
        const defaultConfig = {
            onSelect: (e) => this.handleOnSelect(e),
            onOpen: (e) => this.handleOnOpen(e),
            onClose: (e) => this.handleOnClose(e),
            onDraw: (e) => this.handleOnDraw(e),
            container: "body",
            twelveHour: true, // format 24h,
            defaultTime: "now"
        };

        $(`#${controlId}`).timepicker({
            ...defaultConfig,
            ...config
        });
    }

    setTime(timeStr) {
        // destroy the current instance
        // eslint-disable-next-line
        const instance = M.Timepicker.getInstance($(`#${this.state.controlId}`));

        // const timeText = `${timeStr} ${getAmPmFromTimeStr(timeStr, ":")}`;
        const timeText = `${timeStr}`;

        $(`#${this.state.controlId}`).val(timeText);
        // $(`#${this.state.controlId}`).val(`${timeStr}`);
    }

    showError(message, isRequired) {
        const { controlValueId, controlWrapperId, triggerId } = this.state;
        const colorTextClass = !isRequired ? "red-text" : "yellow-text";

        if (isRequired && this.isInvalid) return;

        $(`#${triggerId}`).removeClass("yellow-text");
        $(`#${triggerId}`).removeClass("red-text");

        if (isRequired) {
            $(`#${triggerId}`).addClass(colorTextClass);
        } else if (message && message !== "") {
            this.isInvalid = true;
            $(`#${controlWrapperId}`).addClass("has-error");
            $(`#${controlValueId}`).addClass("invalid");
            $(`#${controlValueId}`).removeClass("valid");
            $(`#${triggerId}`).addClass(colorTextClass);
        } else {
            this.isInvalid = false;
            $(`#${controlWrapperId}`).removeClass("has-error");
            $(`#${controlValueId}`).addClass("valid");
            $(`#${controlValueId}`).removeClass("invalid");
        }

        $(`#${triggerId}`).prop("title", message);
        $(`#${controlValueId}`).prop("title", message);
    }

    componentWillReceiveProps(nextProps) {
        this.renderValue(nextProps);
    }

    componentDidMount() {
        this.bindingControl(true);
    }

    componentDidUpdate() {
        this.bindingControl();
    }

    componentWillUnmount() {
        $(`#${this.state.controlId}`).timepicker("destroy");
    }

    renderValue(props) {
        // set value
        const { defaultValue, requiredMessage, invalidMessage } = props;
        const isValidDate = validateDateByMoment(defaultValue ? `01/01/2000 ${defaultValue}` : "Invalid time");

        if (hasStringValue(invalidMessage)) {
            // show message
            this.showError(invalidMessage);
        } else if (hasStringValue(requiredMessage)) {
            // show message
            this.showError(requiredMessage, true);
        } else if (isValidDate || defaultValue === "") {
            this.setTime(parseTimeToString(defaultValue));
            this.refs.controlValue.setInputValue(parseTimeToString(defaultValue));
            this.showError("");

            if (defaultValue === "") {
                $($(`#${this.state.controlWrapperId}`).find("label")[0]).removeClass("active");
                $(`#${this.state.controlValueId}`).removeClass("valid");
            }
        }
    }

    bindingControl(isMounted) {
        const { className } = this.props;
        const { controlId } = this.state;

        if (className && className !== "") {
            const classes = className.split(" ");

            for (let i = 0; i < classes.length; i++) {
                $(`#${controlId}`).addClass(classes[i]);
            }
        }

        if (isMounted) {
            // init
            this.initTimePicker();

            $(`#${controlId}`).change((e) => this.handleOnChange(e));

            this.renderValue(this.props);
        }
    }

    handleTriggerOnClick() {
        // eslint-disable-next-line
        const instance = M.Timepicker.getInstance($(`#${this.state.controlId}`));

        instance.open();
    }

    handleOnSelect() {
        // set defaultSelect to false
        if (this.isSetDefaultValue) {
            this.isSetDefaultValue = false;
        }
    }

    handleOnBlur(e) {
        const { onBlur } = this.props;
        const { controlValueId, controlWrapperId } = this.state;

        // set value for timepicker
        const value = $(`#${controlValueId}`).val();

        if (value && value !== "") {
            const isValidDate = validateTime(value);

            if (isValidDate) {
                this.showError("");
                this.setTime(parseTimeToString(value));
            } else {
                this.showError("Time format is not valid");
            }
        } else {
            this.showError("");
            $($(`#${controlWrapperId}`).find("label")[0]).removeClass("active");
            $(`#${controlValueId}`).removeClass("valid");
        }

        if (onBlur) onBlur(e.target.value);
    }

    handleOnChange(e) {
        const { controlValueId } = this.state;
        const { onBlur } = this.props;
        let timeValue = "";

        if (!this.isSetDefaultValue && validateTime(e.target.value)) {
            timeValue = parseTimeToString(e.target.value);
        }

        this.refs.controlValue.setInputValue(timeValue);

        $(`#${controlValueId}`).focus();
        updateTextFields();

        if (onBlur) onBlur(timeValue);
    }

    render() {
        const { controlId, triggerId, controlValueId, controlWrapperId } = this.state;
        const { labelText, disabled, placeholder, isRequiredField } = this.props;

        const mask = "22:22 56";
        const formatChars = {
            "1": "[0-1]",
            "2": "[0-9]",
            "3": "[0-5]",
            "5": "[A, P, a, p]",
            "6": "[M, m]"
        };

        return (
            <div id={controlWrapperId} className={`input-field suffixinput ${isRequiredField ? "required" : ""}`}>
                <label htmlFor={controlId}>{labelText}</label>
                <input type="hidden" id={controlId} className="timepicker" />
                <InputMask
                    type="text"
                    id={controlValueId}
                    className="validate"
                    mask={mask}
                    formatChars={formatChars}
                    onBlur={(e) => this.handleOnBlur(e)}
                    ref="controlValue"
                    placeholder={placeholder || ""}
                    {...{ disabled }}
                />
                <span className="suffix-text cursor-pointer" style={{ zIndex: "100", marginRight: `${isRequiredField ? "12px" : "0"}` }} {...{ disabled }} id={triggerId} onClick={(e) => this.handleTriggerOnClick(e)}><i className="material-icons">access_time</i></span>
            </div>
        );
    }
}

TimePicker.propTypes = {
    id: PropTypes.string,
    onBlur: PropTypes.func,
    className: PropTypes.string,
    message: PropTypes.string,
    labelText: PropTypes.string,
    defaultValue: PropTypes.string,
    disabled: PropTypes.bool,
    placeholder: PropTypes.string,
    isRequiredField: PropTypes.bool,
    requiredMessage: PropTypes.string,
    invalidMessage: PropTypes.string
};

export default TimePicker;