import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";

import InputMask from "react-input-mask";

import { guid } from "./../../helpers/crypto-helper";
import moment from "moment";
import { validateDateStringByMoment, validateDateByMoment, hasStringValue } from "./../../helpers/validation-helper";
import { updateTextFields } from "./../../helpers/theme-helper";

class DatePicker extends Component {
    constructor(props) {
        super(props);

        const controlId = this.props.id || `date-picker-${guid()}`;

        this.tempValue = "";
        this.isInvalid = false;
        this.state = {
            controlId,
            triggerId: `${controlId}-trigger`,
            controlValueId: `${controlId}-value`,
            controlMessageId: `${controlId}-message`,
            controlWrapperId: `${controlId}-wrapper`,
            controlValue: ""
        };
    }

    setDate(value) {
        // eslint-disable-next-line
        const instance = M.Datepicker.getInstance($(`#${this.state.controlId}`));

        this.isSetDefaultValue = true; // to make this component not to re-render
        instance.setDate(new Date(value));
    }

    showError(message, isRequired) {
        const { controlValueId, controlWrapperId, triggerId } = this.state;
        const colorTextClass = !isRequired ? "red-text" : "yellow-text";

        if (isRequired && this.isInvalid) return;

        $(`#${triggerId}`).removeClass("yellow-text");
        $(`#${triggerId}`).removeClass("red-text");

        if (isRequired) {
            $(`#${triggerId}`).addClass(colorTextClass);
        } else if (message && message !== "") {
            this.isInvalid = true;
            $(`#${controlWrapperId}`).addClass("has-error");
            $(`#${controlValueId}`).addClass("invalid");
            $(`#${controlValueId}`).removeClass("valid");
            $(`#${triggerId}`).addClass(colorTextClass);
        } else {
            this.isInvalid = false;
            $(`#${controlWrapperId}`).removeClass("has-error");
            $(`#${controlValueId}`).addClass("valid");
            $(`#${controlValueId}`).removeClass("invalid");
        }

        $(`#${triggerId}`).prop("title", message);
        $(`#${controlValueId}`).prop("title", message);
    }

    componentWillReceiveProps(nextProps) {
        this.renderValue(nextProps);
    }

    componentDidMount() {
        this.bindingControl(true);
    }

    componentDidUpdate() {
        const { defaultValue } = this.props;

        this.bindingControl();
        if (defaultValue !== "") {
            updateTextFields();
        }
    }

    componentWillUnmount() {
        // eslint-disable-next-line
        const instance = M.Datepicker.getInstance($(`#${this.state.controlId}`));
        if (instance) instance.destroy();
    }

    renderValue(props) {
        // set value
        const { defaultValue, requiredMessage, invalidMessage } = props;
        const isValidDate = validateDateStringByMoment(defaultValue);

        if (!isValidDate && hasStringValue(defaultValue)) {
            this.showError("Date is not valid");
        } else if (hasStringValue(invalidMessage)) {
            // show message
            this.showError(invalidMessage);
        } else if (hasStringValue(requiredMessage)) {
            // show message
            this.showError(requiredMessage, true);
        } else {
            this.showError("");
        }

        if (hasStringValue(defaultValue)) {
            this.refs.controlValue.setInputValue(defaultValue);
            $($(`#${this.state.controlWrapperId}`).find("label")[0]).addClass("active");
            $(`#${this.state.controlValueId}`).addClass("valid");
        } else {
            $($(`#${this.state.controlWrapperId}`).find("label")[0]).removeClass("active");
            $(`#${this.state.controlValueId}`).removeClass("valid");
        }
    }

    bindingControl(isMounted) {
        const { className } = this.props;
        const { controlId } = this.state;

        if (className && className !== "") {
            const classes = className.split(" ");

            for (let i = 0; i < classes.length; i++) {
                $(`#${controlId}`).addClass(classes[i]);
            }
        }

        if (isMounted) {
            $(`#${controlId}`).datepicker({
                onSelect: (e) => this.handleOnSelect(e),
                onOpen: (e) => this.handleOnOpen(e),
                onClose: (e) => this.handleOnClose(e),
                onDraw: (e) => this.handleOnDraw(e),
                container: "body"
            });

            $(`#${controlId}`).change((e) => this.handleOnChange(e));

            this.renderValue(this.props);
        }
    }

    handleTriggerOnClick() {
        // eslint-disable-next-line
        const instance = M.Datepicker.getInstance($(`#${this.state.controlId}`));

        instance.open();
    }

    handleOnSelect(dateValue) {
        const { onSelect } = this.props;

        // set defaultSelect to false
        if (this.isSetDefaultValue) {
            this.isSetDefaultValue = false;
        }

        if (onSelect) onSelect(dateValue);
    }

    handleOnOpen(e) {
        const { onOpen } = this.props;

        if (onOpen) onOpen(e);
    }

    handleOnClose() {
        const { onClose } = this.props;

        if (onClose) onClose();
    }

    handleOnDraw(e) {
        const { onDraw } = this.props;

        if (onDraw) onDraw(e);
    }

    handleOnBlur(e) {
        const { onBlur } = this.props;
        const { controlValueId, controlWrapperId } = this.state;

        // set value for datepicker
        const value = $(`#${controlValueId}`).val();

        if (value && value !== "") {
            const isValidDate = validateDateStringByMoment(value);

            if (isValidDate) {
                this.showError("");
                this.setDate(new Date(value));
            } else {
                this.showError("Date is not valid");
            }
        } else {
            this.showError("");
            $($(`#${controlWrapperId}`).find("label")[0]).removeClass("active");
            $(`#${controlValueId}`).removeClass("valid");
        }

        if (onBlur) onBlur(e.target.value);
    }

    handleOnChange(e) {
        const { controlValueId } = this.state;
        const { onBlur } = this.props;
        let dateValue = "";

        if (!this.isSetDefaultValue && validateDateByMoment(new Date(e.target.value))) {
            dateValue = moment(new Date(e.target.value)).format("MM/DD/YYYY").toString();
        }

        this.refs.controlValue.setInputValue(dateValue);

        $(`#${controlValueId}`).focus();
        updateTextFields();

        if (onBlur) onBlur(dateValue);
    }

    render() {
        const { controlId, triggerId, controlValueId, controlWrapperId } = this.state;
        const { labelText, disabled, placeholder, isRequiredField, readOnly } = this.props;

        return (
            <div id={controlWrapperId} className={`input-field suffixinput ${isRequiredField ? "required" : ""}`}>
                <label htmlFor={controlValueId}>{labelText}</label>
                <input type="hidden" id={controlId} className="datepicker" />
                <InputMask
                    type="text"
                    id={controlValueId}
                    className="validate"
                    mask="99/99/9999"
                    onBlur={(e) => this.handleOnBlur(e)}
                    ref="controlValue"
                    placeholder={placeholder || ""}
                    {...{ disabled, readOnly }}
                />
                <span className={`suffix-text cursor-pointer ${disabled || readOnly ? "gray-color" : ""}`} style={{ zIndex: "100", marginRight: `${isRequiredField ? "12px" : "0"}` }} id={triggerId} title="" onClick={(e) => (!disabled && !readOnly) && this.handleTriggerOnClick(e)}><i className="material-icons">today</i></span>
            </div>
        );
    }
}

DatePicker.propTypes = {
    id: PropTypes.string,
    onSelect: PropTypes.func,
    onOpen: PropTypes.func,
    onClose: PropTypes.func,
    onDraw: PropTypes.func,
    onChange: PropTypes.func,
    onBlur: PropTypes.func,
    className: PropTypes.string,
    message: PropTypes.string,
    labelText: PropTypes.string,
    defaultValue: PropTypes.string,
    disabled: PropTypes.bool,
    placeholder: PropTypes.string,
    isRequiredField: PropTypes.bool,
    requiredMessage: PropTypes.string,
    invalidMessage: PropTypes.string,
    readOnly: PropTypes.bool
};

export default DatePicker;