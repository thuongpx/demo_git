import React from "react";
import ReactTooltip from "react-tooltip";
import { Component } from "react";
import PropTypes from "prop-types";

export class PasswordPopover extends Component {
    render() {
        const { classNameAdded } = this.props;
        return (
            <span className={`suffix-text ${classNameAdded}`}>
                <span data-tip data-for="password-instruction"><i className="ti-help-alt"></i></span>
                <ReactTooltip id="password-instruction" aria-haspopup="true" role="example">
                    <p>Notes:</p>
                    <p>1. Be at least eight characters in length</p>
                    <p>2. Contain characters from three of the following four categories:</p>
                    <ul>
                        <li>a. English uppercase characters (A through Z)</li>
                        <li>b. English lowercase characters (a through z)</li>
                        <li>c. Base 10 digits (0 through 9)</li>
                        <li>d. Non-alphabetic characters</li>
                        <li>(e.g : ` ~ ! @ # $ % ^ & * ( ) _ + - = {`{ }`} | \ " ; ' {`< >`} ? , . /)</li>
                    </ul>
                </ReactTooltip>
            </span>
        );
    }
}

PasswordPopover.propTypes = {
    classNameAdded: PropTypes.string
};

export default PasswordPopover;