import React from "react";
import { MultiSelect } from "react-selectize";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { Component } from "react";

import { showError } from "../../screens/main-layout/actions";

import { getAxiosSource, axiosGet, axiosPost, axiosCancel, isCancel } from "../../helpers/axios-helper";
import { guid } from "../../helpers/crypto-helper";
import { INPUT_MISSING_1X_IMAGE_URL } from "../../config/img.config";
import { requireComboBoxMessage } from "../../helpers/validation-helper";

class MultiSelectWrapper extends Component {
    constructor(props) {
        super(props);

        const numberOptionsDisplay = props.numberOptionsDisplay || 150;
        const loadMoreAt = Math.floor(numberOptionsDisplay * 0.7);

        this.state = {
            numberOptionsDisplay,
            loadMoreAt,
            searchText: "",
            loadMoreSearchText: "",
            isHaveMoreResult: true,
            options: [],
            refKey: `multiselect-${guid()}`,
            minTextLength: props.minTextLength || 1
        };
    }

    componentWillMount() {
        const { sourceApiUrl, options, formatOptions } = this.props;
        const isLoadRemoteData = sourceApiUrl !== undefined;
        const newState = {
            isLoadRemoteData
        };

        if (isLoadRemoteData) {
            newState.options = formatOptions ? options : formatOptions(options);
        }

        this.setState(newState);
    }

    handleValuesChange(selectedOptions) {

        const { maxValues, onValuesChange } = this.props;
        const { loadMoreAt, options, loadMoreSearchText, isHaveMoreResult } = this.state;

        // if don't need load remote data on search
        if (!this.state.isLoadRemoteData) {
            if (onValuesChange) onValuesChange(selectedOptions);
            return;
        }

        if (selectedOptions.length === maxValues) {
            this.setState({
                searchText: "",
                options: []
            });
        }

        if (Array.isArray(options)) {
            const values = selectedOptions.map(option => option.value);
            const filteredOptions = options.filter((option) => {
                return values.indexOf(option.value) === -1;
            });

            if (filteredOptions.length < loadMoreAt
                && isHaveMoreResult
                && options.length !== 0
                && this.currentTimeOut === undefined
                && this.axiosSource === undefined
            ) {
                this.requestSources(loadMoreSearchText);
            }
        }

        onValuesChange(selectedOptions);
    }

    handleSearchTextChange(searchText) {

        // if don't need load remote data on search
        if (!this.state.isLoadRemoteData) {
            return;
        }

        searchText = searchText ? searchText.trim() : "";

        const { maxValues, values } = this.props;
        const { minTextLength, loadMoreSearchText, isHaveMoreResult } = this.state;

        if (values.length === maxValues // don't request if reach max number option
            || searchText.length < minTextLength // or searchText's length < minText
            || searchText === this.state.searchText // or searchText equal with previous in state (spaces were entered)
        ) {
            this.setState({
                searchText,
                loadMoreSearchText: this.state.searchText ? this.state.searchText : loadMoreSearchText,
                isHaveMoreResult: this.state.searchText ? true : isHaveMoreResult
            });
            return;
        }

        // abort previous request if existed
        if (this.axiosSource) {
            axiosCancel(this.axiosSource);
        }

        // clear and delete timeout if existed
        if (this.currentTimeOut) {
            clearTimeout(this.currentTimeOut);
            delete this.currentTimeOut;
        }

        // searchText is empty, stop handle
        if (searchText.length < minTextLength) {
            return;
        }

        this.requestSources(searchText);

        // reset options in state to get loading or no result message
        this.setState({
            options: [],
            searchText
        });
    }

    requestSources(searchText) {
        const { values, sourceApiUrl, formatOptions, requestMethod, additionalData } = this.props;
        const { refKey, numberOptionsDisplay } = this.state;

        this.currentTimeOut = setTimeout(() => {
            this.axiosSource = getAxiosSource();

            // join on values by comma to exclude them from database result
            const valuesStr = () => {
                const result = values.map(option => {
                    return option.value;
                });

                return result.join(",");
            };

            const requestFunc = requestMethod === "GET" ? axiosGet : axiosPost;

            requestFunc(sourceApiUrl, { searchText, limit: numberOptionsDisplay, values: valuesStr(), additionalData }, false, this.axiosSource.token)
                .then((result) => {
                    delete this.axiosSource; // delete source

                    const options = formatOptions(result.data.sources);

                    this.setState({
                        options,
                        isHaveMoreResult: options.length >= numberOptionsDisplay
                    }, () => {
                        this.refs[refKey].highlightFirstSelectableOption();
                    });
                })
                .catch(err => {
                    delete this.axiosSource; // delete source

                    if (!isCancel(err)) {
                        const { dispatch } = this.props;

                        dispatch(showError(err.message));
                    }
                });

            delete this.currentTimeOut; // delete timeout
        }, 1000);
    }

    removeItem(item) {
        const { values } = this.props;

        const selectedOptions = values.filter(option => option.value !== item.value);

        this.handleValuesChange(selectedOptions);

        this.focus();
    }

    focus() {
        const { refKey } = this.state;
        this.refs[refKey].focus();
    }

    renderValue(item) {
        return (
            <div
                className="chip"
                onClick={() => {
                    this.focus();
                }}
            >
                {item.label}
                <i className="material-icons close" onClick={() => this.removeItem(item)}>close</i>
            </div>
        );
    }

    renderNoResultsFound(value, searchText) {
        searchText = searchText ? searchText.trim() : "";
        let message = "No results found";

        const { maxValues, values } = this.props;
        const { minTextLength, isLoadRemoteData } = this.state;

        if (values.length === maxValues) {
            //Max select option
            message = `${maxValues}/${maxValues} options selected!`;
        } else if (isLoadRemoteData && this.req === undefined && searchText.length < minTextLength) {
            // no request existed and searchText is empty
            message = `Type ${minTextLength} or more characters to get suggestion`;
        } else if (isLoadRemoteData && this.req !== undefined || this.currentTimeOut !== undefined) {
            // request or timeout is existed
            message = "Loading...";
        }

        return (
            <div className="no-results-found" style={{ fontSize: 13 }}>
                {message}
            </div>
        );
    }

    onFocus() {
        const { refKey } = this.state;

        $(`#label-${refKey}`).addClass("active focused-label");

        this.isFocus = true;
    }

    onBlur() {
        const { refKey, isLoadRemoteData } = this.state;
        const { values, placeholder } = this.props;

        if (isLoadRemoteData) {
            this.setState({
                options: []
            });
        }

        if (this.props.onBlur) this.props.onBlur();
        $(`#label-${refKey}`).removeClass("focused-label");
        delete this.isFocus;

        if ((Array.isArray(values) && values.length > 0) || placeholder !== undefined) {
            return;
        }

        $(`#label-${refKey}`).removeClass("active");
    }

    render() {
        const { refKey, isLoadRemoteData } = this.state;
        const { values, maxValues, placeholder, label, formatOptions, disabled, requiredMess, isFromReport } = this.props;
        let options = this.state.options;

        if (!isLoadRemoteData) {
            options = formatOptions ? formatOptions(this.props.options) : this.props.options;
        }

        const labelClass = (Array.isArray(values) && values.length > 0) || this.isFocus || placeholder !== undefined ? "active " : "";
        const multiselectClass = Array.isArray(values) && values.length > 0 ? `pt-1 ${isFromReport ? "multiselect-report" : ""}` : "";

        // if (isFromReport) {
        //     multiselectClass += "multiselect-report ";
        // }

        return (
            <div>
                {values &&
                    <div className={`input-field suffixinput ${requiredMess ? "required-field" : ""}`} id={`wrapper-${refKey}`}
                        onClick={() => this.focus()}
                    >
                        {label &&
                            <label
                                htmlFor={refKey}
                                id={`label-${refKey}`}
                                className={labelClass}
                                onClick={() => {
                                    this.focus();
                                }}
                            >{label}</label>
                        }
                        <MultiSelect
                            ref={refKey}
                            id={refKey}
                            theme="material"
                            transitionEnter
                            style={{ width: "100%" }}
                            options={options}
                            values={values}
                            maxValues={maxValues + 1}
                            placeholder={placeholder}
                            onValuesChange={selectedOptions => this.handleValuesChange(selectedOptions)}
                            onSearchChange={(searchText) => this.handleSearchTextChange(searchText)}
                            renderValue={(item) => this.renderValue(item)}
                            renderNoResultsFound={(value, searchText) => this.renderNoResultsFound(value, searchText)}
                            onBlur={() => this.onBlur()}
                            onFocus={() => this.onFocus()}
                            disabled={disabled}
                            className={multiselectClass}
                            anchor
                        />
                        {requiredMess && <span className={`suffix-text`} style={{ top: 10 }}>
                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireComboBoxMessage(requiredMess)} />
                        </span>}
                    </div>
                }
            </div>
        );
    }
}

MultiSelectWrapper.defaultProps = {
    disabled: false,
    requestMethod: "GET"
};

MultiSelectWrapper.propTypes = {
    onValuesChange: PropTypes.func,
    dispatch: PropTypes.func,
    sourceApiUrl: PropTypes.string,
    formatOptions: PropTypes.func,
    values: PropTypes.array,
    maxValues: PropTypes.number,
    placeholder: PropTypes.string,
    label: PropTypes.string,
    minTextLength: PropTypes.number,
    numberOptionsDisplay: PropTypes.number,
    options: PropTypes.array,
    onBlur: PropTypes.func,
    disabled: PropTypes.bool,
    requestMethod: PropTypes.string,
    additionalData: PropTypes.any,
    requiredMess: PropTypes.string,
    isFromReport: PropTypes.bool
};

export default connect(null, null, null, { withRef: true })(MultiSelectWrapper);

