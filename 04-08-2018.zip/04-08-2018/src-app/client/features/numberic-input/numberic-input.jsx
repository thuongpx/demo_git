import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";

class NumbericInput extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: this.props.value
        };
    }

    handleValueChanged() {
        if (this.props.onChange) this.props.onChange(this.refs.numberic.value.trim());
    }

    handleBlur() {
        if (this.props.onBlur) this.props.onBlur(this.refs.numberic.value.trim());
    }

    handleKeyDown(e) {
        const { maxValue } = this.props;
        if (e.shiftKey && e.keyCode !== 9) e.preventDefault();
        if (!((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 8 || e.keyCode === 9)) {
            e.preventDefault();
        } else {
            const key = e.key;
            const currentValue = parseInt(`${this.refs.numberic.value.trim()}${key}`);

            if (maxValue !== null) {
                if (currentValue > maxValue) {
                    e.preventDefault();
                }
            }
        }
    }

    render() {

        const { value, className, maxLength, id, disabled } = this.props;

        return (
            <input disabled={disabled} className={className} id={id} onBlur={() => this.handleBlur()} maxLength={maxLength} type="text" ref="numberic" value={value} onKeyUp={this.handleValueChanged.bind(this)} onChange={this.handleValueChanged.bind(this)} onKeyDown={this.handleKeyDown.bind(this)} />
        );
    }

}

NumbericInput.propTypes = {
    onChange: PropTypes.func,
    value: PropTypes.string,
    className: PropTypes.string,
    maxLength: PropTypes.string,
    maxValue: PropTypes.number,
    onBlur: PropTypes.func,
    id: PropTypes.string,
    disabled: PropTypes.bool
};
NumbericInput.defaultProps = {
    maxValue: null
};

export default NumbericInput;
