import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";

class ModalBody extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        const { children, className, style } = this.props;

        return (
            <div className={`modal-content ${className}`} style={style || {}}>
                {children}
            </div>
        );
    }
}

ModalBody.propTypes = {
    className: PropTypes.string,
    style: PropTypes.object
};

export default ModalBody;