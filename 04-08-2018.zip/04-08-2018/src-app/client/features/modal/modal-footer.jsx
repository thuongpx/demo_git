import React from "react";
import { Component } from "react";

class ModalFooter extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        const { children } = this.props;

        return (
            <div className="modal-footer" style={{height: "auto"}}>
                {children}
            </div>
        );
    }
}

export default ModalFooter;