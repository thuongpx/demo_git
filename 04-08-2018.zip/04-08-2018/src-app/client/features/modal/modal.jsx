import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { guid } from "./../../helpers/crypto-helper";

class Modal extends Component {
    constructor(props) {
        super(props);

        this.state = {
            modalId: `modal_${guid()}`
        };
    }

    toggleModal(isOpen) {
        if (isOpen) {
            $(`#${this.state.modalId}`).modal("open");
            // scroll to top of page
            $(`#${this.state.modalId} .tab-content`).animate({ scrollTop: 0 });
        } else {
            $(`#${this.state.modalId}`).modal("close");
            // change overflow of body to auto
            $("body").css({ "overflow": "auto" });
        }
    }

    componentDidMount() {
        const { modalOptions } = this.props;
        modalOptions.dismissible = false;
        $(`#${this.state.modalId}`).modal(modalOptions);

        this.toggleModal(this.props.isOpen);
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.isOpen !== this.props.isOpen) {
            this.toggleModal(nextProps.isOpen);
        }
    }

    componentWillUnmount() {
        $(`#${this.state.modalId}`).modal("destroy");
    }

    render() {
        const { children, fixedFooter, bottomsheet, style, addClass } = this.props;

        const renderClass = () => {
            let className = `modal custome-modal`;
            if (fixedFooter) className = `${className} modal-fixed-footer`;
            if (bottomsheet) className = `${className} bottom-sheet`;
            if (addClass !== "" && addClass !== undefined && addClass !== null) {
                className = `${className} ${addClass}`;
            }

            return className;
        };

        const renderStyle = {
            ...style,
            "width": style.width ? `${style.width}` : "55%"
        };

        return (
            <div key={this.state.modalId} id={this.state.modalId} className={renderClass()} style={renderStyle}>
                {children}
            </div>
        );
    }
}

Modal.propTypes = {
    isOpen: PropTypes.bool,
    fixedFooter: PropTypes.bool,
    bottomsheet: PropTypes.bool,
    style: PropTypes.object,
    addClass: PropTypes.string,
    modalOptions: PropTypes.shape({
        /*
         * Modal can be dismissed by clicking outside of the modal
         */
        dismissible: PropTypes.bool,
        /*
         * Opacity of modal background ( from 0 to 1 )
         */
        opacity: PropTypes.number,
        /*
         * Transition in duration
         */
        inDuration: PropTypes.number,
        /*
         * Transition out duration
         */
        outDuration: PropTypes.number,
        /*
         * Starting top style attribute
         */
        startingTop: PropTypes.string,
        /*
         * Ending top style attribute
         */
        endingTop: PropTypes.string,
        /*
         * Callback for Modal open. Modal and trigger parameters available.
         */
        ready: PropTypes.func,
        /*
         * Callback function called after modal is opened.
         */
        onOpenEnd: PropTypes.func,
        /*
         *  Callback for Modal close
         */
        complete: PropTypes.func
    })
};

Modal.defaultProps = {
    isOpen: false,
    fixedFooter: true,
    bottomsheet: false,
    modalOptions: { dismissible: false },
    style: {}
};

export default Modal;