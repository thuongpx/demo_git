import Modal from "./modal";
import ModalBody from "./modal-body";
import ModalFooter from "./modal-footer";
import ModalTitle from "./modal-title";

export {
    Modal,
    ModalBody,
    ModalFooter,
    ModalTitle
};