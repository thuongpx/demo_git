import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";

class ModalTitle extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        const { children, onClickClose, centerAlign } = this.props;

        return (
            <div className={`header-title-modal ${centerAlign ? "center-align" : null}`}><span>{children}</span>
                {onClickClose &&
                    <a role="button" onClick={() => onClickClose()} className="close">
                        <span>×</span>
                    </a>
                }
            </div>
        );
    }
}


ModalTitle.propTypes = {
    onClickClose: PropTypes.func,
    centerAlign: PropTypes.bool
};

export default ModalTitle;