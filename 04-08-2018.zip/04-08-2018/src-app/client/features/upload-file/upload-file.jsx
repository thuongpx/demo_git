import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import uploadFileStyle from "Styles/uploadfile.css";
import { showError } from "../../screens/main-layout/actions";

export class UploadFile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            fileName: "",
            file: null
        };

        this.handleUpload = this.handleUpload.bind(this);
    }

    clearFile() {
        this.setState({
            fileName: "",
            file: null
        });
        this.refs.file.value = null;
    }

    handleDrop(e) {
        e.preventDefault();
        let files;
        if (e.dataTransfer) {
            files = e.dataTransfer.files;
        } else if (e.target) {
            files = e.target.files;
        }

        if (files.length > 0) {
            if (!this.props.isUseStartToUpload) {
                this.setState({ files });
                this.handleUpload(files);
            }
        }
    }

    handleUpload(files) {
        let isValidFile = false;
        if (files.length > 0) {
            let fileName = "";
            const formData = new FormData();
            Array.from(files).forEach(file => {
                const fileToUpload = file;
                if (fileToUpload !== null) {
                    const fileExtension = fileToUpload.name.split(".")[fileToUpload.name.split(".").length - 1];
                    const accept = this.props.accept.split(",").map(acceptItem => { return acceptItem.replace(".", ""); });
                    if (accept.indexOf(fileExtension.toLowerCase()) > -1) {
                        isValidFile = true;
                        this.setState({
                            fileName: file.name
                        });
                        fileName = file.name;
                        formData.append("file", fileToUpload);
                    } else if (!this.props.isMultiple) {
                        this.props.dispatch(showError(`ERROR: Invalid File Extension ${fileExtension} - No Action Taken.`));
                    }
                }
            });
            if (isValidFile) {
                fileName = this.props.isMultiple ? "multiple" : fileName;
                this.props.onUploadFile(formData, fileName);
            }
        }
    }

    render() {
        const self = this;
        const { isMultiple, accept, uploadButtonName, isUseStartToUpload } = this.props;
        const renderStartToUpload = function () {
            if (isUseStartToUpload) {
                return (<div>
                    <button className="waves-effect waves-light btn blue darken-1" style={{ display: "inlineBlock", "marginRight": "10px" }} onClick={
                        self.handleUpload(self.files)
                    }
                    >Start Upload</button>
                    <span>{self.state.fileName}</span>
                </div>);
            }
            return null;
        };
        return (
            <div>
                <div className={uploadFileStyle["file-upload-container"]} onDragOver={(e) => e.preventDefault()} onDrop={this.handleDrop.bind(this)}>

                    {this.state.fileName && !isMultiple ? this.state.fileName :
                        <span><b className="green-color mr-1">DROP FILE HERE </b> OR</span>}
                    <label className="btn btn-small success-color" style={{ marginLeft: "1rem" }}>
                        <input multiple={isMultiple ? "multiple" : ""} ref="file" type="file" style={{ display: "none" }} accept={accept} onChange={this.handleDrop.bind(this)} />
                        {uploadButtonName}
                    </label>
                </div >
                {renderStartToUpload()}
            </div >
        );
    }
}

UploadFile.defaultProps = {
    accept: "*",
    uploadButtonName: "Browse for files",
    isUseStartToUpload: false,
    isMultiple: false
};

UploadFile.propTypes = {
    accept: PropTypes.string,
    uploadButtonName: PropTypes.string,
    onUploadFile: PropTypes.func.isRequired,
    isUseStartToUpload: PropTypes.bool,
    isMultiple: PropTypes.bool,
    dispatch: PropTypes.func
};

export default connect(null, null, null, { withRef: true })(UploadFile);