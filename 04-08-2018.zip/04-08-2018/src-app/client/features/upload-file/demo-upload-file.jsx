import React from "react";
import { Component } from "react";
import UploadFile from "./upload-file";

export class DemoUploadFile extends Component {
    render() {
        return (
            <div style={{ width: "80%", margin: "20px auto" }}>
                <UploadFile
                    accept={".jpg"}
                    onUploadFile={this.handleUpload.bind(this)}
                    isUseStartToUpload={false} //Remove when use button start to upload
                />
                <br />
            </div>
        );
    }
}

export default DemoUploadFile;