# Archetype: Electrode React App (Development Part)

[![NPM version][npm-image]][npm-url] [![Dependency Status][daviddm-image]][daviddm-url] [![devDependency Status][daviddm-dev-image]][daviddm-dev-url] [![npm downloads][npm-downloads-image]][npm-downloads-url]

A Walmart Labs flavored react app archetype.

[npm-image]: https://badge.fury.io/js/electrode-archetype-react-app-dev.svg
[npm-url]: https://npmjs.org/package/electrode-archetype-react-app-dev
[daviddm-image]: https://david-dm.org/electrode-io/electrode/status.svg?path=packages/electrode-archetype-react-app-dev
[daviddm-url]: https://david-dm.org/electrode-io/electrode?path=packages/electrode-archetype-react-app-dev
[daviddm-dev-image]:https://david-dm.org/electrode-io/electrode/dev-status.svg?path=packages/electrode-archetype-react-app-dev
[daviddm-dev-url]:https://david-dm.org/electrode-io/electrode?path=packages/electrode-archetype-react-app-dev?type-dev
[npm-downloads-image]:https://img.shields.io/npm/dm/electrode-archetype-react-app-dev.svg
[npm-downloads-url]:https://www.npmjs.com/package/electrode-archetype-react-app-dev
