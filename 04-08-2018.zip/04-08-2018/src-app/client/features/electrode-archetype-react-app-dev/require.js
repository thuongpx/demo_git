// Archetype-based require.
/*eslint-disable strict, global-require*/
module.exports = require;
