"use strict";

module.exports = {
  output: {
    path: process.cwd(),
    filename: "bundle.js",
    publicPath: "/assets/"
  }
};
