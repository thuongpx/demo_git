"use strict";

const webpack = require("webpack")

module.exports = function () {
    return {
        plugins: [
            new webpack.optimize.CommonsChunkPlugin({
                name: 'vendor',
            }),
            new webpack.optimize.AggressiveMergingPlugin(),
            new webpack.optimize.OccurrenceOrderPlugin(),
            new webpack.optimize.ModuleConcatenationPlugin()
        ]
    };
};
