"use strict";

module.exports = function() {
  return {
    devtool: "inline-source-map"
  };
};
