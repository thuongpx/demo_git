"use strict";

const webpack = require("webpack");

module.exports = function() {
  return {
    plugins: [
        new webpack.IgnorePlugin(/^\.\/locale$/, /moment$/),
        new webpack.NoEmitOnErrorsPlugin()
    ]
  };
};
