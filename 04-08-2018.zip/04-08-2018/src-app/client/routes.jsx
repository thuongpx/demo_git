import React from "react";
import { Route, IndexRoute } from "react-router";
import { guid } from "./helpers/crypto-helper";
import { hasStringValue } from "./helpers/common-helper";
import MasterPage from "Screens/main-layout/containers/master-page";
import { routeMap } from "./routes.register";
import customFilter from "CustomFilter";

import "core-js/fn/array/find";

export const renderRoutes = () => {
        const renderRouteList = routeMap.map((item) => {
                if (hasStringValue(item.path)) {
                        return (
                                <Route
                                        path={item.path}
                                        component={customFilter(item.path, item.portal, item.isPublic)}
                                        key={guid()}
                                />);
                }

                return "";
        });

        const renderIndexRoute = () => {
                const indexRoute = routeMap.find(i => i.isIndexRoute && hasStringValue(i.path));

                if (indexRoute) {
                        return (
                                <IndexRoute
                                        component={customFilter(routeMap[0].path, routeMap[0].portal, routeMap[0].isPublic)}
                                        key={guid()}
                                />);
                } else {
                        const availabeRoute = routeMap.find(i => hasStringValue(i.path));

                        return (
                                <IndexRoute
                                        component={customFilter(availabeRoute[0].path, availabeRoute[0].portal, availabeRoute[0].isPublic)}
                                        key={guid()}
                                />);
                }
        };

        return (
                <Route path="/" component={MasterPage}>
                        {renderIndexRoute()}
                        {renderRouteList}
                </Route>
        );
};

export const routes = renderRoutes();
