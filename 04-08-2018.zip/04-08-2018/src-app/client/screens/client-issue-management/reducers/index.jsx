import { ORDER_PROBLEM_SET_CRITERIA, REQUEST_ORDER_PROBLEM, RECEIVE_ORDER_PROBLEM } from "./../actions/index";
import moment from "moment";

const initState = {
    criteria: {
        sortColumn: "date",
        sortDirection: false,
        page: 1,
        itemPerPage: 25,
        dateFrom: moment().subtract(1, "year").format("MM/DD/YYYY"),
        dateTo: moment().format("MM/DD/YYYY")
    },
    datasources: [],
    status: [],
    types: [],
    totalRecords: 0
};

export default function clientIssueManagementReducer(state = initState, action) {
    switch (action.type) {
        case ORDER_PROBLEM_SET_CRITERIA:
            return {
                ...state,
                isFetching: action.isFetching,
                criteria: action.criteria
            };
        case REQUEST_ORDER_PROBLEM:
            return {
                ...state,
                isFetching: action.isFetching
            };
        case RECEIVE_ORDER_PROBLEM:
            return {
                ...state,
                isFetching: action.isFetching,
                datasources: action.datasources,
                totalRecords: action.totalRecords,
                criteria: action.criteria,
                status: action.status,
                types: action.types
            };
        default:
            return state;
    }
}