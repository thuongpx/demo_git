import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";

import CommonModal from "CommonModal";
import GridView from "GridView";
import { showError, showSuccess } from "../../../screens/main-layout/actions";
import { SUCCESSFULLY_DELETED_MESSAGE } from "Constants";

import { apiDeleteIssue } from "Api/issue-api";

class ProblemManagementGridView extends Component {
    handleActionClick(action, identifier) {
        const { onReviewProblem } = this.props;
        switch (action) {
            case "delete":
                this.handleDelete(identifier);
                break;
            case "review":
                onReviewProblem(identifier);
                break;
        }
    }

    handleDelete(problemId) {
        const { dispatch, onReLoadGrid, criteria } = this.props;

        this.commonModal.showModal({
            type: "confirm",
            message: `Are you sure you would like to delete this problem?`
        }, () => {
            apiDeleteIssue(problemId, () => {
                onReLoadGrid(criteria);
                dispatch(showSuccess(SUCCESSFULLY_DELETED_MESSAGE));
            }, (error) => {
                dispatch(showError(error.message));
            });
        });

    }
    handleGridViewReload(nextCriteria) {
        const { onReLoadGrid, criteria } = this.props;

        onReLoadGrid({
            ...criteria,
            ...nextCriteria
        });
    }

    render() {
        const { columns, datasources, totalRecords, criteria } = this.props;

        return (
            <div className="wrap-result-search">
                <GridView
                    criteria={criteria}
                    totalRecords={totalRecords}
                    datasources={datasources} //Pass datasources
                    columns={columns} //Pass columns array
                    identifier={"problemId"} //Identifier for grid row
                    actions={["review", "delete"]} //Remove if no action needed
                    onGridViewReload={(e) => this.handleGridViewReload(e)} //Paginate changed => need reload datasource base on criteria
                    onActionClick={(action, identifier) => this.handleActionClick(action, identifier)}
                    onCorrectionRequestClick={(identifier) => this.handleActionClick("review", identifier)}
                />
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }

}

ProblemManagementGridView.defaultProps = {
    columns: [
        {
            title: "OrderID",
            data: "orderId",
            type: "orderDetailLink",
            id: "orderId"
        },
        {
            title: "Correction Requests ID",
            data: "problemId",
            type: "correctionRequest"
        },
        {
            title: "Type",
            data: "problemType"
        },
        {
            title: "Date",
            data: "date",
            type: "datetime"
        },
        {
            title: "Vendor Last Name",
            data: "vendorLastName",
            type: "signerLink",
            id: "signerId"
        },
        {
            title: "Created By",
            data: "createBy"
        },
        {
            title: "Vendor Mistake?",
            data: "vendorMistake"
        },
        {
            title: "Status",
            data: "status"
        }
    ]
};

ProblemManagementGridView.propTypes = {
    columns: PropTypes.array,
    datasources: PropTypes.array,
    totalRecords: PropTypes.number,
    criteria: PropTypes.object,
    dispatch: PropTypes.func,
    onReLoadGrid: PropTypes.func,
    onReviewProblem: PropTypes.func
};

export default connect()(ProblemManagementGridView);