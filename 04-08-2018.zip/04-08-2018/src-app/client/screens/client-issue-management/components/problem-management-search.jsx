import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";

import NumbericInput from "NumbericInput";
import Select from "Select";
import DatePicker from "DatePicker";
import moment from "moment";

class ProblemManagementSearch extends Component {
    constructor(props) {
        super(props);

        const { isAgent } = props;

        this.state = {
            problemTypeSelected: "",
            statusSelected: !isAgent ? 3 : "",
            invalidField: {},
            inputs: {
                dateFrom: props.criteria.dateFrom,
                dateTo: props.criteria.dateTo
            }
        };
    }

    handleSearch() {
        const { criteria, onSearch } = this.props;
        const { problemTypeSelected, statusSelected, inputs, invalidField } = this.state;
        const newCriteria = {
            ...criteria,
            orderId: this.refs.orderId.refs.numberic.value,
            typeId: problemTypeSelected,
            statusId: statusSelected,
            vendorLastName: this.refs.vendorLastName.value.trim(),
            dateFrom: inputs.dateFrom,
            dateTo: inputs.dateTo
        };

        let justInvalidField = Object.keys(invalidField);
        let check = false;
        if (justInvalidField.length > 0) {
            justInvalidField = justInvalidField.filter(item => invalidField[item]);
            check = justInvalidField.length > 0;
        }
        if (!check) {
            onSearch(newCriteria);
        }
    }

    handleReset() {
        const { onSearch, isAgent, defaultCriteria } = this.props;

        const newCriteria = {
            ...defaultCriteria,
            statusId: !isAgent ? 3 : ""
        };

        this.refs.orderId.refs.numberic.value = "";
        this.refs.vendorLastName.value = "";
        this.setState({
            inputs: {
                dateFrom: defaultCriteria.dateFrom,
                dateTo: defaultCriteria.dateTo
            },
            problemTypeSelected: "",
            statusSelected: !isAgent ? 3 : "",
            invalidField: {
                dateFrom: false,
                dateTo: false
            }
        });

        onSearch(newCriteria);
    }

    setValidFieldFromTo(FromField, ToField, value = false) {
        const { invalidField } = this.state;
        invalidField[FromField] = value;
        invalidField[ToField] = value;
        this.setState({ invalidField });
    }

    handleOnChanged(value, fieldName) {
        const { inputs } = this.state;

        switch (fieldName) {
            case "dateTo":
                if (value === "" || value === "Invalid date") {
                    value = "";
                    this.setValidFieldFromTo("dateFrom", "dateTo", false);
                }
                if (inputs.dateTo !== "" || inputs.dateTo !== "Invalid date") {
                    if (moment(value) < moment(inputs.dateFrom)) {
                        this.setValidFieldFromTo("dateFrom", "dateTo", true);
                    } else {
                        this.setValidFieldFromTo("dateFrom", "dateTo", false);
                    }
                }
                break;
            case "dateFrom":
                if (value === "" || value === "Invalid date") {
                    value = "";
                    this.setValidFieldFromTo("dateFrom", "dateTo", false);
                }
                if (inputs.dateFrom !== "" || inputs.dateFrom !== "Invalid date") {
                    if (moment(value) > moment(inputs.dateTo)) {
                        this.setValidFieldFromTo("dateFrom", "dateTo", true);
                    } else {
                        this.setValidFieldFromTo("dateFrom", "dateTo", false);
                    }
                }
                break;
        }

        inputs[fieldName] = value;

        this.setState({ inputs });
    }

    render() {
        const { types, status, mapDataToRender } = this.props;
        const { problemTypeSelected, statusSelected, inputs } = this.state;

        return (
            <div className="wrap-search-form">
                <div className="row">
                    <div className="input-field col s12 m6 l4">
                        <NumbericInput id="orderId" ref="orderId" className="validate" maxValue={2147483647} />
                        <label htmlFor="orderId">Order ID</label>
                    </div>
                    <div className="input-field col s12 m6 l4">
                        <Select
                            dataSource={types}
                            mapDataToRenderOptions={mapDataToRender}
                            id="problemType"
                            value={problemTypeSelected}
                            optionDefaultLabel="Select..."
                            onChange={(value) => this.setState({ problemTypeSelected: value })}
                        />
                        <label htmlFor="problemType">Correction Requests Type</label>
                    </div>
                    <div className="col s12 m6 l2">
                        <DatePicker
                            id="dateFrom"
                            labelText="Date From"
                            defaultValue={inputs.dateFrom || ""}
                            onBlur={e => this.handleOnChanged(moment(e).format("MM/DD/YYYY").toString(), "dateFrom")}
                            invalidMessage={this.state.invalidField.dateFrom ? "From date cannot be greater than To date. Please re-select!" : ""}
                        />
                    </div>
                    <div className="col s12 m6 l2">
                        <DatePicker
                            id="dateTo"
                            labelText="Date To"
                            defaultValue={inputs.dateTo || ""}
                            onBlur={e => this.handleOnChanged(moment(e).format("MM/DD/YYYY").toString(), "dateTo")}
                            invalidMessage={this.state.invalidField.dateTo ? "From date cannot be greater than To date. Please re-select!" : ""}
                        />
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12 m4">
                        <Select
                            dataSource={status}
                            mapDataToRenderOptions={mapDataToRender}
                            id="status"
                            value={statusSelected}
                            optionDefaultLabel="Select..."
                            onChange={(value) => this.setState({ statusSelected: value })}
                        />
                        <label htmlFor="state">Status</label>
                    </div>
                    <div className="input-field col s12 m4">
                        <input id="vendorLastName" type="text" ref="vendorLastName" className="validate" maxLength="25" />
                        <label htmlFor="vendorLastName">Vendor Last Name</label>
                    </div>

                </div>
                <div className="row mb-0">
                    <div className="col s12 m6">
                        <p className="left red-color">Insert criteria to search for specific Correction Requests</p>
                    </div>
                    <div className="col s12 m6">
                        <div className="right center-btn-mobile" >
                            <button type="button" className="btn btn-small reload-btn btn-primary" style={{ marginRight: "5px" }} onClick={() => this.handleReset()}>
                                <i className="lnr lnr-redo"></i>
                            </button>
                            <button onClick={() => this.handleSearch()} className="btn success-color action-btn" >Search</button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

ProblemManagementSearch.defaultProps = {
    mapDataToRender: {
        value: "Id",
        label: "Description"
    },
    defaultCriteria: {
        sortColumn: "date",
        sortDirection: false,
        page: 1,
        itemPerPage: 25,
        dateFrom: moment().subtract(1, "year").format("MM/DD/YYYY"),
        dateTo: moment().format("MM/DD/YYYY")
    }
};

ProblemManagementSearch.propTypes = {
    dispatch: PropTypes.func,
    types: PropTypes.array,
    status: PropTypes.array,
    mapDataToRender: PropTypes.object,
    onSearch: PropTypes.func,
    criteria: PropTypes.object,
    isAgent: PropTypes.object,
    defaultCriteria: PropTypes.object
};

export default connect()(ProblemManagementSearch);