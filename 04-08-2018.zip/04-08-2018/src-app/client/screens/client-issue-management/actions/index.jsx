import { apiGetOrderProblem } from "Api/order-problem-api";
import { handleApiError } from "ErrorHandler";

export const ORDER_PROBLEM_SET_CRITERIA = "ORDER_PROBLEM_SET_CRITERIA";
export const REQUEST_ORDER_PROBLEM = "REQUEST_ORDER_PROBLEM";
export const RECEIVE_ORDER_PROBLEM = "RECEIVE_ORDER_PROBLEM";

export const setOrderProblemCriteria = (criteria) => {
    return {
        type: ORDER_PROBLEM_SET_CRITERIA,
        criteria
    };
};

export const requestOrderProblem = () => {
    return {
        type: REQUEST_ORDER_PROBLEM,
        isFetching: true
    };
};

export const receiveOrderProblem = (datasources, totalRecords, criteria, status, types) => {
    return {
        type: RECEIVE_ORDER_PROBLEM,
        isFetching: false,
        datasources,
        totalRecords,
        criteria,
        status,
        types
    };
};

export const getOrderProblem = (criteria) => {
    return dispatch => {
        dispatch(requestOrderProblem());
        dispatch(setOrderProblemCriteria(criteria));

        return apiGetOrderProblem(criteria, (result) => {
            if (result !== null) {
                const { datasources } = result.data;
                const { totalRecords } = result.data;
                const { status } = result.data;
                const { types } = result.data;
                dispatch(receiveOrderProblem(datasources, totalRecords, criteria, status, types));
            }
        }, (error) => handleApiError(dispatch, error));
    };
};