import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";

import ProblemManagementSearch from "../components/problem-management-search";
import ProblemManagementGridView from "../components/problem-management-grid";
import { getOrderProblem } from "../actions/index";
import OrderIssueDetailModal from "../../order-issue/components/order-issue-detail-modal";

class ProblemManagement extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        const { criteria, isAgent } = this.props;

        this.reload({
            ...criteria,
            statusId: !isAgent ? 3 : ""
        });
    }

    reload(criteria) {
        const { dispatch, isAgent, userId } = this.props;

        dispatch(getOrderProblem({
            ...criteria,
            brokerId: !isAgent ? userId : null,
            agentId: isAgent ? userId : null
        }));
    }

    handleUpdateIssue() {
        const { criteria } = this.props;

        this.reload(criteria);
    }

    handleReviewProblem(problemId) {
        this.issueDetailModal.show(problemId);
    }

    render() {
        const { datasources, totalRecords, criteria, dispatch, status, types, isAgent } = this.props;

        return (
            <div className="place-section">
                <div className="row">
                    <div className="col s12">
                        <h3 className="title-page-detail">Correction Requests</h3>
                    </div>
                </div>

                <ProblemManagementSearch onSearch={(searchCriteria) => this.reload(searchCriteria)} dispatch={dispatch} criteria={criteria} status={status} types={types} isAgent={isAgent} />
                <div className="row mb-0"><div className="col s12 m12"><p><b>Search Results</b></p></div></div>
                <ProblemManagementGridView datasources={datasources} totalRecords={totalRecords} criteria={criteria} dispatch={dispatch} onReLoadGrid={(searchCriteria) => this.reload(searchCriteria)}
                    onReviewProblem={(problemId) => this.handleReviewProblem(problemId)}
                />

                <div className="col s12">
                    <OrderIssueDetailModal onUpdateIssue={() => this.handleUpdateIssue()} ref={(issueDetailModal) => {
                        if (issueDetailModal && issueDetailModal.getWrappedInstance) {
                            this.issueDetailModal = issueDetailModal.getWrappedInstance();
                        }
                    }}
                    />
                </div>
            </div>
        );
    }
}

ProblemManagement.propTypes = {
    dispatch: PropTypes.func,
    datasources: PropTypes.array,
    totalRecords: PropTypes.number,
    criteria: PropTypes.object,
    userId: PropTypes.number,
    status: PropTypes.array,
    types: PropTypes.array,
    isAgent: PropTypes.object
};

const mapStateToProps = (state) => {
    const { clientIssueManagement, authentication } = state;
    const { datasources, totalRecords, criteria, status, types } = clientIssueManagement;
    const { userId } = authentication;
    const { roleNames } = authentication.role;
    const isAgent = roleNames.find(i => {
        return i === "Agent";
    });

    return {
        datasources,
        totalRecords,
        criteria,
        status,
        types,
        isAgent,
        userId
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(ProblemManagement);