import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router";

import LeftPanelAssignedAgent from "../components/left-panel-assigned-agent";
import LeftPanelAssignedScheduler from "../components/left-panel-assigned-scheduler";
import LeftPanelCustomer from "../components/left-panel-customer";
import LeftPanelClient from "../components/left-panel-client";
import LeftPanelFees from "../components/left-panel-fees";
import LeftPanelShipping from "../components/left-panel-shipping";
import LeftPanelTheClosingExchange from "../components/left-panel-the-closing-exchange";
import LeftPanelDates from "../components/left-panel-dates";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class OrderDetailLeftPanel extends Component {
    constructor(props) {
        super(props);
        const tabs = [
            { title: "Fees", isActive: true },
            { title: "Shipping", isActive: false }
        ];

        // set tab default if there is not any tab matches value in cookies
        const activeTabs = tabs.filter((item) => {
            return item.isActive;
        });

        if (activeTabs.length === 0) tabs[0].isActive = true;

        this.state = {
            isOpenMobile: false,
            progressId: null,
            tabs
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    handleTabClick(tab) {
        const tabs = this.state.tabs;
        const isFirstTab = false;

        //validate current form
        for (const index in tabs) {
            const item = tabs[index];
            if (item.isActive && item.title !== tab.title) {
                switch (item.title) {
                    case "Fees":
                        break;
                    default:
                        break;
                }

            }
        }

        if (!isFirstTab) {
            this.setActiveTab(tab);
        }
    }

    setActiveTab(tab) {
        const { tabs } = this.state;

        tabs.map(item => {
            if (item.title === tab.title) {
                item.isActive = true;
            } else item.isActive = false;
            return item;
        });
        this.setState({ tabs });
    }
    /* toggle mobile */
    openLeftPanel() {
        const currentState = this.state.isOpenMobile;
        this.setState({ isOpenMobile: !currentState });
    }
    render() {
        const {
            orderId, roleType
        } = this.props;

        const renderTabs = () => {
            return this.state.tabs.map((tab, key) => {
                const classNameActive = tab.isActive ? "active" : "";

                return (
                    <li className={`tab col ${classNameActive}`} key={key} onClick={() => this.handleTabClick(tab)}>
                        <a style={{ cursor: "pointer" }}>{tab.title}</a>
                    </li>
                );
            });
        };

        const renderTabContent = () => {
            return this.state.tabs.map((tab) => {
                if (tab.isActive) {
                    switch (tab.title) {
                        case "Fees":
                            return (
                                <div key="fee" id="fee" className="col s12 tab-content">
                                    <LeftPanelFees orderId={orderId} />
                                </div>
                            );
                        default:
                            return (
                                <div key="shipping" id="shipping" className="col s12 tab-content">
                                    <LeftPanelShipping orderId={orderId} />
                                </div>
                            );
                    }
                }
                return null;
            });
        };

        return (
            <div className={`col s3 left-panel-order-section ${this.state.isOpenMobile ? "open" : ""}`}>
                <div className={`bg-show-on-small toggle-left ${this.state.isOpenMobile ? "open" : ""}`} onClick={() => this.openLeftPanel()}> <span className="lnr lnr-text-align-left"></span></div>
                <div className="toggle-right-close" onClick={() => this.openLeftPanel()}><span className="lnr lnr-cross"></span></div>
                <div className="row">
                    <div className="col s5">
                        <Link className="order-back" to={"/view-orders"}><i className="ti-arrow-circle-left"></i> All Orders</Link>
                    </div>
                    <div className="col s7 pos-rel right-align">
                        <span className="bold-title">Order:</span> <span className="font-13 font-weight-600">{this.props.orderId}</span>
                    </div>

                    <div className="clear"></div>
                    <br />

                    {roleType === "Staff" ? <LeftPanelAssignedScheduler orderId={orderId} /> : <LeftPanelAssignedAgent orderId={orderId} />}

                    <LeftPanelCustomer orderId={orderId} />

                    {roleType === "Staff" && <LeftPanelClient orderId={orderId} />}

                    <LeftPanelTheClosingExchange orderId={orderId} />

                    <div className="tab-wrap st2 panel-order-detail row box-shadow-st2 p-0 mt-2 pb-2">
                        <div className="col s12 p-0">
                            <ul className="tabs">
                                {renderTabs()}
                            </ul>
                        </div>
                        <div className="col s12 p-0">
                            {renderTabContent()}
                        </div>
                    </div>

                    {roleType === "Staff" && <LeftPanelDates orderId={orderId} />}

                </div>
            </div>
        );
    }
}

OrderDetailLeftPanel.propTypes = {
    orderId: PropTypes.number,
    roleType: PropTypes.string
};

OrderDetailLeftPanel.defaultProps = {
    tabs: [
        { title: "Fees", isActive: true },
        { title: "Shipping", isActive: false }
    ]
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { role } = authentication;
    const { roleType, roleNames } = role;

    return {
        roleType,
        roleNames
    };
};

export default connect(mapStateToProps)(OrderDetailLeftPanel);