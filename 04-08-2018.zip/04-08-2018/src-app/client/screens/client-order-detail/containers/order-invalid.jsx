import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { Link } from "react-router";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class OrderInvalid extends Component {
    constructor(props) {
        super(props);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {

        const { orderId } = this.props;

        return (
            <div className="row">
                <div className="col s12 m5 offset-m4">
                    <div className="card mt-5 p-2 style-2">
                        <div className="card-content p-0">
                            <h4 className="bold-5 font-31 title-dark-style">
                                Order {orderId} is invalid!
                            </h4>
                            <h5 className="bold-5 font-17 main-header-dark-style">
                                Sorry but we cannot find the Order {orderId}, please go back to the order list and try again.
                                </h5>
                            <div className="clear"></div>
                            <div className="row mt-3">
                                <div className="input-field col s6 center-align">
                                </div>
                                <div className="input-field col s6">
                                    <Link to={"/view-orders"}><button type="button" className="btn success-color w-100 height-5-btn">Back to All Orders</button></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}


OrderInvalid.propTypes = {
    orderId: PropTypes.number
};

export default OrderInvalid;