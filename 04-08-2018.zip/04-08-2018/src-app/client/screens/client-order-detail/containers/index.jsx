import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { handleApiError } from "ErrorHandler";
import { connect } from "react-redux";

import LeftPanel from "./order-detail-left-panel";
import MainPanel from "./order-detail-main-panel";
import RightPanel from "./order-detail-right-panel";
import FindAVendor from "../../vendor-manage/containers/find-a-vendor";
import OrderInvalid from "./order-invalid";

import { checkInOrderRoom, checkOutOrderRoom } from "../../../socket/orders";

import { apiCheckValidOrderId } from "../../../api/orders-api";

import Loader from "../../../features/loader";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { getOrderDetailLeftPanelFeeInitData } from "../actions/left-panel-actions";

class ClientOrderDetail extends Component {
    constructor(props) {
        super(props);

        const { params } = this.props;
        const { orderId } = params;
        this.state = {
            isStarting: true,
            isValidOrderId: false,
            orderId: Number(orderId.replace("#", "")),
            isShowAssignVendor: false
        };
    }

    handleAssignAVendor(value) {
        this.setState({
            isShowAssignVendor: value
        }, () => {
            if (!value) {
                this.props.dispatch(getOrderDetailLeftPanelFeeInitData(this.state.orderId));
            }
        });
    }

    checkValidOrder(orderId, roleName, userId) {
        const { dispatch } = this.props;

        apiCheckValidOrderId(orderId, roleName, userId, (result) => {
            this.setState({
                isValidOrderId: result.data.isValid === true,
                isStarting: false
            });
        }, (error) => handleApiError(dispatch, error));
    }

    componentDidMount() {
        const { orderId } = this.props.params;
        const { authentication } = this.props;

        // check in order room socket
        checkInOrderRoom(orderId);

        // check if order is valid
        this.checkValidOrder(orderId, authentication.role.roleNames[0], authentication.userId);
    }

    componentWillUnmount() {
        const { orderId } = this.props.params;

        checkOutOrderRoom(orderId);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {
        const { orderId, isStarting, isValidOrderId } = this.state;
        const { order } = this.props;

        if (isStarting) {
            return <Loader isShow />;
        }

        if (isValidOrderId) {
            return (
                <div className="place-section" style={{ position: "relative" }}>
                    <div className="row">
                        <div className="col s12 hide-on-small">
                            <div className="clear mt-3"></div>
                        </div>
                        <LeftPanel orderId={orderId} />
                        <MainPanel orderId={orderId} onAssignAVendor={(value) => this.handleAssignAVendor(value)} />
                        <RightPanel orderId={orderId} onAssignAVendor={(value) => this.handleAssignAVendor(value)} />
                        <FindAVendor
                            isOpen={this.state.isShowAssignVendor}
                            orderId={orderId}
                            onAssignAVendor={(value) => this.handleAssignAVendor(value)}
                            orderData={order}
                        />

                    </div>
                </div >
            );
        } else {
            return (
                <OrderInvalid />
            );
        }
    }
}

ClientOrderDetail.propTypes = {
    dispatch: PropTypes.func,
    params: PropTypes.object,
    authentication: PropTypes.object
};

const mapStateToProps = (state) => {
    const { authentication, clientOrderDetail } = state;
    const { accountId } = authentication;

    const { leftPanelFee } = clientOrderDetail;
    const { fee } = leftPanelFee;
    const { order } = fee;

    return {
        authentication,
        accountId,
        order
    };
};

export default connect(mapStateToProps)(ClientOrderDetail);