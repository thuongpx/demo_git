import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import moment from "moment";

import { ACTION } from "../../../constant/progress-log-constants";
import { CLIENT_SUB_ROLE } from "Constants";
import DocsTab from "../components/right-panel-docs-tab";
import ArchiveTab from "../components/right-panel-archive-tab";
import { shareAllDocs } from "../actions/right-panel-actions";
import RightPanelAppointment from "../components/right-panel-appointment";
import RightPanelOtherDetail from "../components/right-panel-other-detail";
import ClientOrderDetailVendorAssignLog from "./../containers/vendor-assign-log";
import CustomerFeedbackRightPanel from "../components/right-panel-customer-feedback";

import { apiDownloadOrderDoc } from "Api/order-docs-api";
import { handleApiError } from "ErrorHandler";
import SignedDocsTab from "./../components/right-panel-signed-docs-tab";
import { apiAddNewOrderProgress } from "Api/order-progress-api";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { apiSubmitCustomerFeedback } from "Api/orders-api";
import { showSuccess } from "../../main-layout/actions";
import { getCustomerFeedback } from "../actions/right-panel-actions";

class OrderDetailRightPanel extends Component {
    constructor(props) {
        super(props);

        const tabs = [
            { title: "DOCS TO BE SIGNED", isActive: true },
            { title: "SIGNED DOCS", isActive: false },
            { title: "ARCHIVED DOCS", isActive: false }
        ];
        const activeTabs = tabs.filter((item) => {
            return item.isActive;
        });

        if (activeTabs.length === 0) tabs[0].isActive = true;

        this.state = {
            isOpenMobile: false,
            data: {},
            validator: {},
            tabs,
            showAlertCountDown: 0
        };
    }

    componentDidMount() {
        const { dispatch, orderId } = this.props;

        if (orderId) {
            dispatch(getCustomerFeedback(orderId));
        }
    }

    handleTabClick(tab) {
        const tabs = this.state.tabs;
        const isFirstTab = false;

        for (const index in tabs) {
            const item = tabs[index];
            if (item.isActive && item.title !== tab.title) {
                switch (item.title) {
                    case "DOCS TO BE SIGNED":
                        break;
                    case "SIGNED DOCS":
                        break;
                    default:
                        break;
                }
            }
        }

        if (!isFirstTab) {
            this.setActiveTab(tab);
        }
    }

    setActiveTab(tab) {
        const { tabs } = this.state;

        tabs.map(item => {
            if (item.title === tab.title) {
                item.isActive = true;
            } else item.isActive = false;
            return item;
        });
        this.setState({ tabs });
    }

    shareAllDocs() {
        const { dispatch, orderId, accountId, userName } = this.props;
        // const notSharedDocsNames = orderDocs.filter(doc => !doc.shared);
        // const notSharedDocsNamesStr = notSharedDocsNames.map(doc => doc.description).join(", ");

        const log = {
            orderId,
            activity: `${userName} shared documents`,
            usersId: accountId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            progressType: ACTION
        };

        dispatch(shareAllDocs(orderId, log, () => this.countDownToHideAlert()));

        return false;
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    countDownToHideAlert() {
        let { showAlertCountDown } = this.state;

        showAlertCountDown--;

        showAlertCountDown = showAlertCountDown === -1 ? 2 : showAlertCountDown;
        const callback = showAlertCountDown === 0 ? undefined : () => {
            setTimeout(() => this.countDownToHideAlert(), 1000);
        };

        this.setState({
            showAlertCountDown
        }, callback);
    }

    handleDownloadDocument(docId, docType, fileName) {
        const { dispatch, orderId, userName, accountId } = this.props;

        apiDownloadOrderDoc({ docId, docType }, fileName, () => {
            const log = {
                OrderId: orderId,
                Activity: `${userName} downloaded documents ${fileName}`,
                UsersId: accountId,
                DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                ProgressType: ACTION
            };

            //add activity log
            apiAddNewOrderProgress(log,
                () => {

                },
                (error) => handleApiError(error)
            );
        }, (error) => handleApiError(dispatch, error));
    }

    renderTabContent() {
        const { tabs } = this.state;
        const { orderId, roleType } = this.props;

        return tabs.map((tab, index) => {

            if (tab.isActive) {
                switch (tab.title) {
                    case "DOCS TO BE SIGNED":
                        return (
                            <DocsTab key={index}
                                orderId={orderId}
                                handleDownloadDocument={(docId, docType, docName) => this.handleDownloadDocument(docId, docType, docName)}
                            />
                        );
                    case "SIGNED DOCS":
                        return (
                            <SignedDocsTab
                                key={index}
                                orderId={orderId}
                                handleDownloadDocument={(docId, docType, docName) => this.handleDownloadDocument(docId, docType, docName)}
                                roleType={roleType}
                            />
                        );
                    default:
                        return (
                            <ArchiveTab key={index}
                                orderId={orderId}
                                handleDownloadDocument={(docId, docType, docName) => this.handleDownloadDocument(docId, docType, docName)}
                            />
                        );
                }
            }
            return null;
        });
    }

    renderTabs() {
        const { tabs } = this.state;
        const { orderDocs, subRoleType, roleType } = this.props;
        // render tabs
        let isDocsTabActive = false;
        const result = tabs.map((tab, key) => {

            // archive tab only visible to admin client
            if (tab.title === "ARCHIVED DOCS" && ((!subRoleType || subRoleType !== CLIENT_SUB_ROLE.CLIENT) && roleType !== "Staff")) {
                return undefined;
            }

            // check doc tab is active to show share all button
            const classNameActive = tab.isActive ? "active" : "";
            if (tab.isActive) {
                isDocsTabActive = tab.title === "DOCS TO BE SIGNED" ? true : false;
            }

            return (
                <li className={`tab col ${classNameActive}`} key={key} onClick={() => this.handleTabClick(tab)}>
                    <a style={{ cursor: "pointer" }}>{tab.title}</a>
                </li>
            );
        });

        // check there is at least one document is uploaded AND not shared
        let hasNotShareDoc = false;
        if (orderDocs) {
            for (let i = 0; i < orderDocs.length; i++) {
                const doc = orderDocs[i];
                if (!doc.shared && (doc.archive === null || !doc.archive)) {
                    hasNotShareDoc = true;
                    break;
                }
            }
        }

        // is doc tab: display share all button
        if (isDocsTabActive) {
            result.push(
                <li key="shareAllButton" className="tab col right mr-1">
                    <button className="btn btn-small success-color"
                        {...{ disabled: !hasNotShareDoc || undefined }}
                        onClick={() => this.shareAllDocs()}
                    >Share all</button>
                </li>
            );
        }

        return result;
    }
    /* toggle mobile */
    openRightPanel() {
        const currentState = this.state.isOpenMobile;
        this.setState({ isOpenMobile: !currentState });
    }

    // AnNV2: Update UCC12 - Customer feedback
    handleSaveCustomerFb(feedback, cb) {
        const { orderId, dispatch, customerFeedback } = this.props;

        feedback.orderId = orderId;
        feedback.isClosingCompleted = customerFeedback.orderDetail.isClosingCompleted || false;

        apiSubmitCustomerFeedback(feedback, () => {
            dispatch(showSuccess("Saved successfully!"));
            dispatch(getCustomerFeedback(orderId));
            cb();

            // if order is closing completed, need to recalculate vendor rating
            if (customerFeedback.orderDetail.isClosingCompleted) {
                // calculate vendor rating
            }
        }, (err) => {
            handleApiError(dispatch, err);
        })
        return true;
    }

    render() {
        const { orderId, onAssignAVendor, isRenderVendorLog } = this.props;
        const { showAlertCountDown } = this.state;
        const { customerFeedback, userId, userName, progressId } = this.props;
        const { orderDetail } = customerFeedback;

        return (
            <div className={`col s3 order-infor-owner right-panel-order-section ${this.state.isOpenMobile ? "open" : ""}`} >
                <div className={`bg-show-on-small toggle-right ${this.state.isOpenMobile ? "open" : ""}`} onClick={() => this.openRightPanel()}> <span className="lnr lnr-text-align-right"></span></div>
                <div className="toggle-right-close  right" onClick={() => this.openRightPanel()}><span className="lnr lnr-cross"></span></div>
                <div className="clear"></div>
                <RightPanelAppointment orderId={orderId} />
                <CustomerFeedbackRightPanel
                    orderId={orderId}
                    userId={userId}
                    userName={userName}
                    customerFeedbackData={customerFeedback}
                    onSaveFeedback={(data, cb) => this.handleSaveCustomerFb(data, cb)}
                />
                <RightPanelOtherDetail orderId={orderId} />
                {isRenderVendorLog ?
                    <ClientOrderDetailVendorAssignLog
                        orderId={orderId}
                        onAssignAVendor={() => onAssignAVendor(true)}
                        isSelfService={orderDetail.isSelfService}
                        progressId={progressId}
                    /> : null
                }

                <div className="tab-wrap st2 panel-order-detail row box-shadow-st2 p-1 pb-0 border-dash rounded mt-2 p-relative">
                    <div className="row mb-0">
                        <div className="col s12">
                            <ul className="tabs">
                                {this.renderTabs()}
                            </ul>
                        </div>
                    </div>

                    {this.renderTabContent()}

                    <div className={`alert-success-share-all white center-align valign-wrapper ${showAlertCountDown ? "active" : ""}`}>
                        <div className="centered">
                            <i className="material-icons large green-color">check_circle</i>
                            <h5>Shared Document</h5>
                            <p className="gray-color">closing in {showAlertCountDown}...</p>
                        </div>
                    </div>
                </div>
            </div >
        );
    }
}

OrderDetailRightPanel.propTypes = {
    params: PropTypes.object,
    router: PropTypes.object,
    dispatch: PropTypes.func,
    accountId: PropTypes.number,
    orderId: PropTypes.number,
    brokerId: PropTypes.number,
    docDelivery: PropTypes.array,
    onAssignAVendor: PropTypes.func,
    orderDocs: PropTypes.array,
    userName: PropTypes.string.isRequired,
    isRenderVendorLog: PropTypes.bool,
    subRoleType: PropTypes.string,
    roleType: PropTypes.string
};

const mapStateToProps = (state) => {
    const { authentication, clientOrderDetail } = state;
    const { accountId, profile, role } = authentication;
    const { userName, subRoleType, userId } = profile;
    const { roleType } = role;
    const { rightPanel, leftPanel } = clientOrderDetail;
    const { isRenderVendorLog } = rightPanel;
    const { orderDocs, customerFeedback } = rightPanel;

    const { orderInfo } = leftPanel;
    const { progressId } = orderInfo;

    return {
        accountId,
        orderDocs,
        userName,
        isRenderVendorLog,
        subRoleType,
        roleType,
        customerFeedback,
        userId,
        progressId
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(OrderDetailRightPanel);