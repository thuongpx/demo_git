import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";

import MainPanelStageBar from "./../components/main-panel-stage-bar";
import AllActivity from "../components/main-panel-all-activities";
import OrderRequestedFees from "../components/main-panel-fee-request-for-client";
import OrderDetailCommunication from "../components/main-panel-communication";
import OrderDetailStaffCommunication from "../components/main-panel-staff-communication";
import VendorManage from "../components/main-panel-vendor-manage";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
//ucs26
import StaffOrderRequestedFees from "../../staff-order-detail/components/main-panel-fee-request-for-staff";

class OrderDetailMainPanel extends Component {
    constructor(props) {
        super(props);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    setActiveTab(tab) {
        this.odc.setActiveTab(tab);
    }

    onAssignAVendor(value) {
        this.props.onAssignAVendor(value);
    }

    render() {
        const { orderId, shownModule, roleType, userId, accountId } = this.props;
        // ucs26
        const renderRequestFee = () => {
            if (roleType === "Staff") {
                return (
                    (shownModule === "FEE") && <StaffOrderRequestedFees orderId={orderId} />
                );
            } else {
                return (
                    (shownModule === "FEE") && <OrderRequestedFees orderId={orderId} />
                );
            }
        };

        return (
            <div className="col s6 center-panel-order-section">
                <MainPanelStageBar
                    orderId={orderId}
                    onAssignAVendor={this.props.onAssignAVendor}
                />

                {((shownModule === "COM") && (roleType !== "Staff")) &&
                    <OrderDetailCommunication
                        ref={instance => {
                            if (instance && instance.getWrappedInstance) {
                                this.odc = instance.getWrappedInstance();
                            }
                        }}
                        orderId={orderId}
                    />}
                {((shownModule === "COM") && (roleType === "Staff")) &&
                    <OrderDetailStaffCommunication
                        ref={instance => {
                            if (instance && instance.getWrappedInstance) {
                                this.odc = instance.getWrappedInstance();
                            }
                        }}
                        orderId={orderId}
                    />}
                {renderRequestFee()}

                {(shownModule === "VEN") && <VendorManage orderId={orderId} />}

                <AllActivity
                    orderId={this.props.orderId}
                    setActiveTab={(tab) => this.setActiveTab(tab)}
                    onAssignAVendor={(value) => this.onAssignAVendor(value)}
                />
            </div>
        );
    }
}


OrderDetailMainPanel.propTypes = {
    orderId: PropTypes.number,
    onAutoAssignRunned: PropTypes.func,
    onAssignAVendor: PropTypes.func,
    shownModule: PropTypes.string,
    roleType: PropTypes.string,
    userId: PropTypes.number
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { accountId, role, userId } = authentication;
    const { clientOrderDetail } = state;
    const { mainPanelReducer } = clientOrderDetail;
    const { shownModule } = mainPanelReducer;
    //ucs26
    const { roleNames, roleType } = role;
    return {
        accountId,
        shownModule,
        roleNames,
        roleType,
        userId
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(OrderDetailMainPanel);