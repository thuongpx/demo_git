import { apiSendEmailCloseRequestForOrder } from "../../../api/orders-api";
import { showSuccess, showError } from "./../../main-layout/actions/index";

export const UPDATE_PROGRESS_MANUALLY_REQUEST = "UPDATE_PROGRESS_MANUALLY_REQUEST";
export const UPDATE_PROGRESS_MANUALLY_RECEIVE = "UPDATE_PROGRESS_MANUALLY_RECEIVE";
import { SUCCESSFULLY_SAVED_MESSAGE } from "Constants";

export const requestUpdateProgressManually = () => {
    return {
        type: UPDATE_PROGRESS_MANUALLY_REQUEST,
        isFetching: true
    };
};

export const receiveUpdateProgressManually = () => {
    return {
        type: UPDATE_PROGRESS_MANUALLY_RECEIVE,
        isFetching: false
    };
};

export const sendEmailCloseRequestForOrder = (dataProgressManually) => {
    return dispatch => {
        apiSendEmailCloseRequestForOrder(dataProgressManually.orderId, (sendEmailResult) => {
            if (sendEmailResult.data.isSuccess) {
                dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
            } else {
                dispatch(showError("SEND EMAIL FAILED"));
            }
        });
    };
};