import { apiGetOrderRequestedFee, apiGetOrderRequestedFeeType } from "Api/order-fee-api";
import { handleApiError } from "ErrorHandler";

export const GET_REQUESTED_FEE_REQUEST = "GET_REQUESTED_FEE_REQUEST";
export const GET_REQUESTED_FEE_RECEIVE = "GET_REQUESTED_FEE_RECEIVE";
export const GET_REQUESTED_FEE_TYPE_RECEIVE = "GET_REQUESTED_FEE_TYPE_RECEIVE";

export const requestRequestedFees = () => {
    return {
        type: GET_REQUESTED_FEE_REQUEST
    };
};

export const receivRequestedFees = (data) => {
    return {
        type: GET_REQUESTED_FEE_RECEIVE,
        data
    };
};

export const receivRequestedFeesType = (data) => {
    return {
        type: GET_REQUESTED_FEE_TYPE_RECEIVE,
        data
    };
};

export const getOrderRequestedFee = (orderId) => {
    return dispatch => {
        dispatch(requestRequestedFees());

        return apiGetOrderRequestedFee(orderId, (result) => {
            dispatch(receivRequestedFees(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};
