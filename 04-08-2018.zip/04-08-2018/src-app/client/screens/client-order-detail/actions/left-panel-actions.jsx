import { apiGetOrderDetailLeftPanelInitData, apiGetOrderDetailLeftPanelFeeInitData, apiGetOrderDetailLeftPanelShippingInitData, apiSaveLeftPanelFees, apiUpdateLeftPanel } from "../../../api/orders-api";
import { apiSendFaxcover, apiSendMailReport, apiSendConfirmation, apiSendAptScheduled, apiSendClosing, apiSendInvoice } from "../../../api/report-order-api";
import { handleApiError } from "ErrorHandler";
import { showError, showSuccess } from "../../main-layout/actions";
import { apiAddNewOrderProgress } from "Api/order-progress-api";
export const DONE_GET_ORDER_DETAIL_LEFT_PANEL_INIT_DATA = "DONE_GET_ORDER_DETAIL_LEFT_PANEL_INIT_DATA";
export const START_GET_ORDER_DETAIL_LEFT_PANEL_INIT_DATA = "START_GET_ORDER_DETAIL_LEFT_PANEL_INIT_DATA";
export const DONE_GET_ORDER_DETAIL_LEFT_PANEL_FEE_INIT_DATA = "DONE_GET_ORDER_DETAIL_LEFT_PANEL_FEE_INIT_DATA";
export const START_GET_ORDER_DETAIL_LEFT_PANEL_FEE_INIT_DATA = "START_GET_ORDER_DETAIL_LEFT_PANEL_FEE_INIT_DATA";
export const DONE_GET_ORDER_DETAIL_LEFT_PANEL_SHIPPING_INIT_DATA = "DONE_GET_ORDER_DETAIL_LEFT_PANEL_SHIPPING_INIT_DATA";
export const START_GET_ORDER_DETAIL_LEFT_PANEL_SHIPPING_INIT_DATA = "START_GET_ORDER_DETAIL_LEFT_PANEL_SHIPPING_INIT_DATA";
export const DONE_SAVE_LEFT_PANEL_FEES = "DONE_SAVE_LEFT_PANEL_FEES";
export const START_SAVE_LEFT_PANEL_FEES = "START_SAVE_LEFT_PANEL_FEES";
export const RESET_SAVE_LEFT_PANEL_FEES_STATUS = "RESET_SAVE_LEFT_PANEL_FEES_STATUS";

export const DONE_UPDATE_LEFT_PANEL = "DONE_UPDATE_LEFT_PANEL";
export const START_UPDATE_LEFT_PANEL = "START_UPDATE_LEFT_PANEL";
export const SHOW_POPUP_SEND_MAIL = "SHOW_POPUP_SEND_MAIL";
export const RECEIVE_MAIL_OPTION = "RECEIVE_MAIL_OPTION";

export const doneGetOrderDetailLeftPanelInitData = (data) => {
    return {
        type: DONE_GET_ORDER_DETAIL_LEFT_PANEL_INIT_DATA,
        data
    };
};

export const startGetOrderDetailLeftPanelInitData = () => {
    return {
        type: START_GET_ORDER_DETAIL_LEFT_PANEL_INIT_DATA
    };
};

export const getOrderDetailLeftPanelInitData = (data) => {
    return dispatch => {
        dispatch(startGetOrderDetailLeftPanelInitData());

        return apiGetOrderDetailLeftPanelInitData(data, (result) => {
            dispatch(doneGetOrderDetailLeftPanelInitData(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const doneGetOrderDetailLeftPanelFeeInitData = (data) => {
    return {
        type: DONE_GET_ORDER_DETAIL_LEFT_PANEL_FEE_INIT_DATA,
        ...data
    };
};

export const startOrderDetailLeftPanelFeeInitData = () => {
    return {
        type: START_GET_ORDER_DETAIL_LEFT_PANEL_FEE_INIT_DATA
    };
};

export const getOrderDetailLeftPanelFeeInitData = (orderId) => {
    return dispatch => {
        dispatch(startOrderDetailLeftPanelFeeInitData());

        return apiGetOrderDetailLeftPanelFeeInitData(orderId, (result) => {
            dispatch(doneGetOrderDetailLeftPanelFeeInitData(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const doneGetOrderDetailLeftPanelShippingInitData = (data) => {
    return {
        type: DONE_GET_ORDER_DETAIL_LEFT_PANEL_SHIPPING_INIT_DATA,
        ...data
    };
};

export const startOrderDetailLeftPanelShippingInitData = () => {
    return {
        type: START_GET_ORDER_DETAIL_LEFT_PANEL_SHIPPING_INIT_DATA
    };
};

export const getOrderDetailLeftPanelShippingInitData = (orderId) => {
    return dispatch => {
        dispatch(startOrderDetailLeftPanelShippingInitData());

        return apiGetOrderDetailLeftPanelShippingInitData(orderId, (result) => {
            dispatch(doneGetOrderDetailLeftPanelShippingInitData(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const doneSaveLeftPanelFees = (data) => {
    return {
        type: DONE_SAVE_LEFT_PANEL_FEES,
        ...data
    };
};

export const startSaveLeftPanelFees = () => {
    return {
        type: START_SAVE_LEFT_PANEL_FEES
    };
};

export const doneUpdateLeftPanel = (data) => {
    return {
        type: DONE_UPDATE_LEFT_PANEL,
        ...data
    };
};

export const startUpdateLeftPanel = () => {
    return {
        type: START_UPDATE_LEFT_PANEL
    };
};

export const saveLeftPanelFees = (data, log) => {
    return dispatch => {
        dispatch(startSaveLeftPanelFees());

        return apiSaveLeftPanelFees(data, (result) => {

            if (result.data.isSuccess && (!result.data.status || result.data.status === "UPDATE")) {
                apiAddNewOrderProgress(log,
                    () => {
                    },
                    (error) => handleApiError(error)
                );
            }

            dispatch(doneSaveLeftPanelFees(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const updateLeftPanel = (data, cb) => {
    return dispatch => {
        dispatch(startUpdateLeftPanel);

        return apiUpdateLeftPanel(data, (result) => {
            dispatch(doneUpdateLeftPanel(result));
            if (typeof cb === "function") cb(result.data);
        }, (error) => handleApiError(dispatch, error));
    };
};

export const resetLeftPanelFeeStatus = () => {
    return {
        type: RESET_SAVE_LEFT_PANEL_FEES_STATUS
    };
};

export const showPopupSendMail = (isOpen, selectSendMailOption) => {
    return {
        type: SHOW_POPUP_SEND_MAIL,
        isOpen,
        selectSendMailOption
    };
};

export const receiveMailOption = (mailOptions) => {
    return {
        type: RECEIVE_MAIL_OPTION,
        mailOptions
    };
};

export const sendFaxcover = (orderID, selectSendMailOption) => {
    return dispatch => {
        return apiSendFaxcover(orderID, selectSendMailOption, (result) => {
            dispatch(showPopupSendMail(true, selectSendMailOption));
            dispatch(receiveMailOption(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const sendMailFaxcover = (mailOptions) => {
    return dispatch => {
        return apiSendMailReport(mailOptions, (result) => {
            dispatch(showPopupSendMail(false));
            if (result.data.isSuccess) {
                dispatch(showSuccess("Report Sent"));
            } else {
                dispatch(showError("Error Sending Report"));
            }
        }, (error) => handleApiError(dispatch, error));
    };
};

export const sendConfirmation = (orderID, selectSendMailOption) => {
    return dispatch => {
        return apiSendConfirmation(orderID, selectSendMailOption, (result) => {
            dispatch(showPopupSendMail(true, selectSendMailOption));
            dispatch(receiveMailOption(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const sendAptScheduled = (orderID, selectSendMailOption) => {
    return dispatch => {
        return apiSendAptScheduled(orderID, selectSendMailOption, (result) => {
            dispatch(showPopupSendMail(true, selectSendMailOption));
            dispatch(receiveMailOption(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const sendClosing = (orderID, selectSendMailOption) => {
    return dispatch => {
        return apiSendClosing(orderID, selectSendMailOption, (result) => {
            dispatch(showPopupSendMail(true, selectSendMailOption));
            dispatch(receiveMailOption(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const sendInvoice = (orderID, selectSendMailOption) => {
    return dispatch => {
        return apiSendInvoice(orderID, selectSendMailOption, (result) => {
            dispatch(showPopupSendMail(true, selectSendMailOption));
            dispatch(receiveMailOption(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};
