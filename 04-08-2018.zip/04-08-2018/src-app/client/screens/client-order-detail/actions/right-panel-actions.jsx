import { apiGetRightPanelDocsData } from "../../../api/orders-api";
import { apiUpdateOrderDoc, apiDeleteOrderDoc, apiShareAllDocsByOrderId, apiChangeStatusOnFirstDocUploaded, apiGetDocGrid, apiGetListDocRejectReason, apiSendEmailRejectSignedDoc, apiGetListOrderDocComments, apiArchiveOrderDoc, apiAddOrderDocAdditionalComment } from "../../../api/order-docs-api";
import { apigetOtherDetailsData, apiUpdatePreCall, apiUpdateDocsReview } from "../../../api/orders-api";
import { apiAddNewOrderProgress, apiAddMultiProgressLog } from "Api/order-progress-api";
import { apiGetOrderCustomerFeedback } from "Api/orders-api";
import { handleApiError } from "ErrorHandler";

export const ORDER_DETAIL_RIGHT_PANEL_DATA_REQUEST = "ORDER_DETAIL_RIGHT_PANEL_DATA_REQUEST";
export const ORDER_DETAIL_RIGHT_PANEL_DATA_RECEIVE = "ORDER_DETAIL_RIGHT_PANEL_DATA_RECEIVE";
export const ORDER_DETAIL_RIGHT_PANEL_DOCS_REQUEST = "ORDER_DETAIL_RIGHT_PANEL_DOCS_REQUEST";
export const ORDER_DETAIL_RIGHT_PANEL_DOCS_RECEIVE = "ORDER_DETAIL_RIGHT_PANEL_DOCS_RECEIVE";
export const ORDER_DETAIL_RIGHT_PANEL_DOC_UPDATE_REQUEST = "ORDER_DETAIL_RIGHT_PANEL_DOC_UPDATE_REQUEST"; //For share, revoke share, archive doc
export const ORDER_DETAIL_RIGHT_PANEL_DOC_UPDATE_RECEIVE = "ORDER_DETAIL_RIGHT_PANEL_DOC_UPDATE_RECEIVE";
export const ORDER_DETAIL_ADD_PROGRESS_LOG_REQUEST = "ORDER_DETAIL_ADD_PROGRESS_LOG_REQUEST";
export const ORDER_DETAIL_ADD_PROGRESS_LOG_RECEIVE = "ORDER_DETAIL_ADD_PROGRESS_LOG_RECEIVE";
export const ORDER_DETAIL_DOC_DELETE_REQUEST = "ORDER_DETAIL_DOC_DELETE_REQUEST"; // delete doc permanantly
export const ORDER_DETAIL_DOC_DELETE_RECEIVE = "ORDER_DETAIL_DOC_DELETE_RECEIVE";
export const ORDER_DETAIL_SHARE_ALL_REQUEST = "ORDER_DETAIL_SHARE_ALL_REQUEST";
export const ORDER_DETAIL_SHARE_ALL_RECEIVE = "ORDER_DETAIL_SHARE_ALL_RECEIVE";
export const ORDER_DETAIL_ALERT_SUCCESS_HIDE = "ORDER_DETAIL_ALERT_SUCCESS_HIDE";
export const SET_IS_RENDER_VENDOR_LOG = "SET_IS_RENDER_VENDOR_LOG";
export const SET_ORDER_DOCDELMETHOD = "SET_ORDER_DOCDELMETHOD";
export const ORDER_DETAIL_RIGHT_PANEL_SIGNED_DOCS_INIT_DATA_RECEIVE = "ORDER_DETAIL_RIGHT_PANEL_SIGNED_DOCS_INIT_DATA_RECEIVE";
export const ORDER_DETAIL_RIGHT_PANEL_SIGNED_DOCS_UPDATE_DATA = "ORDER_DETAIL_RIGHT_PANEL_SIGNED_DOCS_UPDATE_DATA";
export const ORDER_DETAIL_RIGHT_PANEL_DATA_STOP_FETCHING = "ORDER_DETAIL_RIGHT_PANEL_DATA_STOP_FETCHING";
export const SET_OTHER_DETAILS_DATA = "SET_OTHER_DETAILS_DATA";
export const UPDATE_CHECKBOX_RECEIVE = "UPDATE_CHECKBOX_RECEIVE";

// AnNV2: Update UCC12 - Customer feedback
export const ORDER_DETAIL_RIGHT_PANEL_CUSTOMER_FEEDBACK_REQUEST = "ORDER_DETAIL_RIGHT_PANEL_CUSTOMER_FEEDBACK_REQUEST";
export const ORDER_DETAIL_RIGHT_PANEL_CUSTOMER_FEEDBACK_RECEIVE = "ORDER_DETAIL_RIGHT_PANEL_CUSTOMER_FEEDBACK_RECEIVE";

// import { emitHaveNewActivity } from "../../../socket/orders";

export const getRightPanelDataRequest = () => {
    return {
        type: ORDER_DETAIL_RIGHT_PANEL_DATA_REQUEST
    };
};

export const stopFetchingApi = () => {
    return {
        type: ORDER_DETAIL_RIGHT_PANEL_DATA_STOP_FETCHING
    };
};

export const getRightPanelDataReceive = (data) => {
    return {
        type: ORDER_DETAIL_RIGHT_PANEL_DATA_RECEIVE,
        data
    };
};

export const setIsRenderVendorLog = (isRenderVendorLog) => {
    return {
        type: SET_IS_RENDER_VENDOR_LOG,
        isRenderVendorLog
    };
};

export const setDocDelMethod = (docDelMethod) => {
    return {
        type: SET_ORDER_DOCDELMETHOD,
        docDelMethod
    };
};

export const getRightPanelData = (orderId) => {
    return dispatch => {
        dispatch(getRightPanelDataRequest());

        return apiGetRightPanelDocsData(orderId, (result) => {
            dispatch(getRightPanelDataReceive(result.data));
        }, (error) => {
            dispatch(getRightPanelDataReceive({}));
            handleApiError(dispatch, error);
        });
    };
};

export const getOrderDocsRequest = () => {
    return {
        type: ORDER_DETAIL_RIGHT_PANEL_DOCS_REQUEST
    };
};

export const getOrderDocsReceive = (orderDocs) => {
    return {
        type: ORDER_DETAIL_RIGHT_PANEL_DOCS_RECEIVE,
        orderDocs
    };
};

export const getOrderDocs = (orderId) => {
    return dispatch => {
        dispatch(getOrderDocsRequest(orderId));

        return apiAddNewOrderProgress;
    };
};

export const addProgressLogRequest = () => {
    return {
        type: ORDER_DETAIL_ADD_PROGRESS_LOG_REQUEST
    };
};

export const addProgressLogReceive = () => {
    return {
        type: ORDER_DETAIL_ADD_PROGRESS_LOG_RECEIVE
    };
};

export const addProgressLog = (log) => {
    return dispatch => {
        dispatch(addProgressLogRequest());

        return apiAddNewOrderProgress(log, () => {
            dispatch(addProgressLogReceive());
            // Send notification to reload order activities
            // emitHaveNewActivity(log.orderId);
        }, error => {
            dispatch(addProgressLogReceive());
            handleApiError(dispatch, error);
        });
    };
};

export const addMultiProgressLogRequest = () => {
    return {
        type: ORDER_DETAIL_ADD_PROGRESS_LOG_REQUEST
    };
};

export const addMultiProgressLogReceive = () => {
    return {
        type: ORDER_DETAIL_ADD_PROGRESS_LOG_RECEIVE
    };
};

export const addMultiProgressLog = (logs) => {
    return dispatch => {
        dispatch(addMultiProgressLogRequest());

        return apiAddMultiProgressLog({ logs }, () => {
            dispatch(addMultiProgressLogReceive());
            // Send notification to reload order activities
            // emitHaveNewActivity(logs[0].orderId);
        }, error => {
            dispatch(addMultiProgressLogReceive());
            handleApiError(dispatch, error);
        });
    };
};

export const updateDocRequest = (docData) => {
    return {
        type: ORDER_DETAIL_RIGHT_PANEL_DOC_UPDATE_REQUEST,
        docData
    };
};

export const updateDocReceive = (docData) => {
    return {
        type: ORDER_DETAIL_RIGHT_PANEL_DOC_UPDATE_RECEIVE,
        docData
    };
};

export const archiveDoc = (docData, log) => {
    return dispatch => {
        dispatch(updateDocRequest(docData));

        return apiArchiveOrderDoc(docData.DocId, () => {
            dispatch(updateDocReceive(docData));

            if (log && log.orderId) {
                dispatch(addProgressLog(log));

                dispatch(getRightPanelData(log.orderId));
            }

        }, error => {
            dispatch(updateDocReceive({}));
            handleApiError(dispatch, error);
        });
    };
};

export const updateDoc = (docData, log) => {
    return dispatch => {
        dispatch(updateDocRequest(docData));

        return apiUpdateOrderDoc(docData, () => {
            dispatch(updateDocReceive(docData));

            if (log && log.orderId) {
                dispatch(addProgressLog(log));

                dispatch(getRightPanelData(log.orderId));
            }

        }, error => {
            dispatch(updateDocReceive({}));
            handleApiError(dispatch, error);
        });
    };
};

export const updateListSignedDocs = (docData) => {
    return {
        type: ORDER_DETAIL_RIGHT_PANEL_SIGNED_DOCS_UPDATE_DATA,
        docData
    };
};

export const updateSignedDocsStatus = (docData, cb) => {
    return dispatch => {
        dispatch(getRightPanelDataRequest());

        return apiUpdateOrderDoc(docData, () => {
            if (docData.userName) docData.ReviewedBy = docData.userName;
            dispatch(updateListSignedDocs(docData));
            if (docData.Status === "R") {
                apiSendEmailRejectSignedDoc({ docId: docData.DocId, orderId: docData.OrderId }, () => { }, () => { });
            }
            cb();
        }, error => {
            handleApiError(dispatch, error);
        });
    };
};

export const deleteDocRequest = () => {
    return {
        type: ORDER_DETAIL_DOC_DELETE_REQUEST
    };
};

export const deleteDocReceive = () => {
    return {
        type: ORDER_DETAIL_DOC_DELETE_RECEIVE
    };
};

export const deleteDoc = (docId, log) => {
    return dispatch => {
        dispatch(updateDocRequest({ DocId: docId }));

        return apiDeleteOrderDoc(docId, () => {
            dispatch(deleteDocReceive());

            dispatch(addProgressLog(log));

            dispatch(getRightPanelData(log.orderId));

        }, error => {
            dispatch(deleteDocReceive());
            handleApiError(dispatch, error);
        });
    };
};

export const shareAllDocsRequest = () => {
    return {
        type: ORDER_DETAIL_SHARE_ALL_REQUEST
    };
};

export const shareAllDocsReceive = (data) => {
    return {
        type: ORDER_DETAIL_SHARE_ALL_RECEIVE,
        data
    };
};

export const shareAllDocs = (orderId, log, callback) => {
    return dispatch => {
        dispatch(shareAllDocsRequest());

        return apiShareAllDocsByOrderId(orderId, result => {

            if (result.data.isSuccess) {

                dispatch(shareAllDocsReceive({ showAlertSuccess: true }));

                dispatch(addProgressLog(log));

                dispatch(getRightPanelData(log.orderId));

                if (callback) callback();

                return;
            }

            dispatch(shareAllDocsReceive());
        }, error => {
            dispatch(shareAllDocsReceive());
            handleApiError(dispatch, error);
        });
    };
};

export const hideAlertSuccess = () => {
    return {
        type: ORDER_DETAIL_ALERT_SUCCESS_HIDE
    };
};

export const changeStatusOnFirstDocUploadedRequest = () => {
    return {
        type: ORDER_DETAIL_ADD_PROGRESS_LOG_REQUEST
    };
};

export const changeStatusOnFirstDocUploadedReceive = () => {
    return {
        type: ORDER_DETAIL_ADD_PROGRESS_LOG_RECEIVE
    };
};

export const changeStatusOnFirstDocUploaded = (orderId) => {
    return dispatch => {
        dispatch(changeStatusOnFirstDocUploadedRequest());

        return apiChangeStatusOnFirstDocUploaded({ orderId },
            () => {
                dispatch(changeStatusOnFirstDocUploadedReceive());
            },
            (error) => {
                dispatch(changeStatusOnFirstDocUploadedReceive());
                handleApiError(dispatch, error);
            }
        );
    };
};

export const receiveSignedDocsInitData = (result) => {
    return {
        type: ORDER_DETAIL_RIGHT_PANEL_SIGNED_DOCS_INIT_DATA_RECEIVE,
        result
    };
};

export const getSignedDocsInitData = (inputs) => {
    return dispatch => {
        dispatch(getRightPanelDataRequest());

        apiGetDocGrid(inputs, (result) => {
            apiGetListDocRejectReason(listReject => {
                dispatch(receiveSignedDocsInitData({ ...result.data, ...listReject.data }));
            }, err => {
                handleApiError(dispatch, err);
            });
        }, error => {
            handleApiError(dispatch, error);
        });
    };
};

export const getListSignedDocsComments = (inputs, cb) => {
    return dispatch => {
        dispatch(getRightPanelDataRequest());
        apiGetListOrderDocComments(inputs, result => {
            dispatch(stopFetchingApi());
            cb(result.data);
        }, err => {
            handleApiError(dispatch, err);
        });
    };
};

export const addOrderDocsAdditionalComment = (inputs, cb) => {
    return dispatch => {
        dispatch(getRightPanelDataRequest());
        apiAddOrderDocAdditionalComment(inputs, () => {
            dispatch(stopFetchingApi());
            cb();
        }, err => {
            handleApiError(dispatch, err);
        });
    };
};

export const setOtherDetailsData = (OtherDetailsData) => {
    return {
        type: SET_OTHER_DETAILS_DATA,
        OtherDetailsData
    };
};

export const getOtherDetails = (orderId) => {
    return dispatch => {
        return apigetOtherDetailsData(orderId, (result) => {
            dispatch(setOtherDetailsData(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const receiveUpdateCheckBox = (isSuccess) => {
    return {
        type: UPDATE_CHECKBOX_RECEIVE,
        isSuccess
    };
};

export const updatePreCall = (data, cb) => {
    return dispatch => {
        return apiUpdatePreCall(data, (result) => {
            dispatch(receiveUpdateCheckBox(result.data));
            if (typeof cb === "function") cb(result.data);
        }, (error) => handleApiError(dispatch, error));
    };
};

export const updateDocsReview = (data, cb) => {
    return dispatch => {
        return apiUpdateDocsReview(data, (result) => {
            dispatch(receiveUpdateCheckBox(result.data));
            if (typeof cb === "function") cb(result.data);
        }, (error) => handleApiError(dispatch, error));
    };
};

export const getCustomerFeedbackRequest = () => {
    return {
        type: ORDER_DETAIL_RIGHT_PANEL_CUSTOMER_FEEDBACK_REQUEST
    };
}

export const getCustomerFeedbackReceive = (data) => {
    return {
        type: ORDER_DETAIL_RIGHT_PANEL_CUSTOMER_FEEDBACK_RECEIVE,
        data
    };
}

export const getCustomerFeedback = (orderId) => {
    return dispatch => {
        dispatch(getCustomerFeedbackRequest());
        return apiGetOrderCustomerFeedback(orderId, (result) => {
            dispatch(getCustomerFeedbackReceive(result.data));
        }, (error) => handleApiError(dispatch, error));
    }
}