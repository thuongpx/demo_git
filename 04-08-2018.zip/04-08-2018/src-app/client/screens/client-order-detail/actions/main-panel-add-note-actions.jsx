import { apiGetOrderCommentWithUserData, apiAddComment } from "../../../api/comment-api";
import { handleApiError } from "ErrorHandler";
import { COMMENT_TYPE } from "Constants";

export const CLIENT_ORDER_DETAILS_GET_NOTES_DATA_REQUEST = "CLIENT_ORDER_DETAILS_GET_NOTES_DATA_REQUEST";
export const CLIENT_ORDER_DETAILS_GET_NOTES_DATA_SUCCESS = "CLIENT_ORDER_DETAILS_GET_NOTES_DATA_SUCCESS";
export const CLIENT_ORDER_DETAILS_GET_NOTES_DATA_FAILURE = "CLIENT_ORDER_DETAILS_GET_NOTES_DATA_FAILURE";

export const getNotesDataRequest = () => {
    return {
        type: CLIENT_ORDER_DETAILS_GET_NOTES_DATA_REQUEST
    };
};

export const getNotesDataSuccess = (orderComments) => {
    return {
        type: CLIENT_ORDER_DETAILS_GET_NOTES_DATA_SUCCESS,
        orderComments
    };
};

export const getNotesDataFailure = () => {
    return {
        type: CLIENT_ORDER_DETAILS_GET_NOTES_DATA_FAILURE
    };
};

export const getNotesData = (orderId) => {
    return dispatch => {
        const conditions = {
            typeId: COMMENT_TYPE.OrderCommentType,
            ownerId: orderId
        };

        dispatch(getNotesDataRequest());

        return apiGetOrderCommentWithUserData(conditions, (result) => {
            dispatch(getNotesDataSuccess(result.data.orderComments));
        }, (error) => {
            dispatch(getNotesDataFailure());
            handleApiError(dispatch, error);
        });
    };
};

export const saveNote = (note, callback) => {
    return dispatch => {
        return apiAddComment(note, () => {
            callback();
        }, (error) => handleApiError(dispatch, error));
    };
};