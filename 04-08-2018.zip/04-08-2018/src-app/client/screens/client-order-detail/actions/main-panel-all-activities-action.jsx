import { apiGetOrderProgressLogById } from "../../../api/order-progress-api";
import { handleApiError } from "ErrorHandler";

export const GET_ALL_ACTIVITY_REQUEST = "GET_ALL_ACTIVITY_REQUEST";
export const GET_ALL_ACTIVITY_RECEIVE = "GET_ALL_ACTIVITY_RECEIVE";

export const requestGetAllActivity = () => {
    return {
        type: GET_ALL_ACTIVITY_REQUEST
    };
};

export const receiveGetAllActivity = (data) => {
    return {
        type: GET_ALL_ACTIVITY_RECEIVE,
        data
    };
};

export const getAllActivity = (orderId) => {
    return dispatch => {
        dispatch(requestGetAllActivity());

        return apiGetOrderProgressLogById(orderId, (result) => {
            dispatch(receiveGetAllActivity(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};