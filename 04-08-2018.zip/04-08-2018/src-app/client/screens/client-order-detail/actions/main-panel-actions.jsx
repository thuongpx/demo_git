import { apiGetInitOrderDetailData } from "../../../api/orders-api";
import {
    apiGetOrderProblemsByOrder
} from "../../../api/order-problem-api";
import { apiGetVendorHistory } from "Api/vendor-history-api";
import { apiGetVendorSentOffer } from "Api/vendor-sent-offer-api";
import { showSuccess } from "./../../main-layout/actions/index";
import { handleApiError } from "ErrorHandler";
import { apiGetSignersApproval, apiUpdateSignerApproval, apiCheckValidApproval, apiGetSignersApprovalById } from "Api/signers-approval-api";

export const START_GET_INIT_ORDER_DETAIL_DATA = "START_GET_INIT_ORDER_DETAIL_DATA";
export const DONE_GET_INIT_ORDER_DETAIL_DATA = "START_GET_INIT_ORDER_DETAIL_DATA";
export const RECEIVE_VENDOR_HISTORY_DATA = "RECEIVE_VENDOR_HISTORY_DATA";

export const VENDOR_REQUEST_DATA = "VENDOR_REQUEST_DATA";
export const VENDOR_REQUESTS_GET_GRIDVIEW_DATA_SUCCESS = "VENDOR_REQUESTS_GET_GRIDVIEW_DATA_SUCCESS";
export const VENDOR_REQUESTS_GET_GRIDVIEW_DATA_FAILURE = "VENDOR_REQUESTS_GET_GRIDVIEW_DATA_FAILURE";
export const VENDOR_REQUESTS_BY_ID_GET_GRIDVIEW_DATA_SUCCESS = "VENDOR_REQUESTS_BY_ID_GET_GRIDVIEW_DATA_SUCCESS";
export const VENDOR_REQUESTS_SAVE_VENDOR_APPROVAL_REQUEST = "VENDOR_REQUESTS_SAVE_VENDOR_APPROVAL_REQUEST";
export const VENDOR_REQUESTS_SAVE_VENDOR_APPROVAL_SUCCESS = "VENDOR_REQUESTS_SAVE_VENDOR_APPROVAL_SUCCESS";
export const VENDOR_REQUESTS_SAVE_VENDOR_APPROVAL_FAILURE = "VENDOR_REQUESTS_SAVE_VENDOR_APPROVAL_FAILURE";
export const RECEIVE_VENDOR_SENT_OFFER_DATA = "RECEIVE_VENDOR_SENT_OFFER_DATA";
export const SWITCH_MODULE_ON_MAIN_PANEL = "SWITCH_MODULE_ON_MAIN_PANEL";

export const CHANGE_PROBLEM_CRITERIA = "CHANGE_PROBLEM_CRITERIA";
export const INIT_ORDER_PROBLEMS = "INIT_ORDER_PROBLEMS";

import { emitHaveNewActivity } from "../../../socket/orders";

export const startGetInitOrderDetailData = () => {
    return {
        type: START_GET_INIT_ORDER_DETAIL_DATA
    };
};

export const doneGetInitOrderDetailData = (data) => {
    return {
        type: DONE_GET_INIT_ORDER_DETAIL_DATA,
        data
    };
};

export const initOrderProblems = (data) => {
    return {
        type: INIT_ORDER_PROBLEMS,
        data
    };
};

export const changeGridCriteria = (data) => {
    return {
        type: CHANGE_PROBLEM_CRITERIA,
        data
    };
};

export const getOrderProblemsByOrder = (gridCriteria) => {
    return dispatch => {
        return apiGetOrderProblemsByOrder(gridCriteria, (result) => {
            dispatch(initOrderProblems(result.data));
        });
    };
};

export const getInitOrderDetailData = (query) => {
    return dispatch => {
        dispatch(startGetInitOrderDetailData());

        return apiGetInitOrderDetailData(query, (result) => {
            dispatch(doneGetInitOrderDetailData(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

//  Start Action Vendor Sent Offer-List

export const receiveVendorSentOfferList = (result) => {

    return {
        type: RECEIVE_VENDOR_SENT_OFFER_DATA,
        listDataVendorSentOffer: result
    };
};

export const getVendorSentOfferList = (gridCriteria, orderId) => {

    return dispatch => {
        const criteria = { ...gridCriteria, orderId };
        return apiGetVendorSentOffer(criteria, (result) => {
            dispatch(receiveVendorSentOfferList(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};
//  End Action Vendor Sent Offer-List

//  Start Action Vendor History
export const receivegetVendorHistory = (result) => {

    return {
        type: RECEIVE_VENDOR_HISTORY_DATA,
        listDataVendorHistory: result
    };
};

export const getVendorHistory = (gridCriteria, orderId) => {

    return dispatch => {
        const criteria = { ...gridCriteria, orderId };
        return apiGetVendorHistory(criteria, (result) => {
            dispatch(receivegetVendorHistory(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};
// End Action Vendor History

//  Start Action Vendor Request

export const getVendorRequestsGridViewDataRequest = () => {
    return {
        type: VENDOR_REQUEST_DATA
    };
};

export const getVendorRequestsGridViewDataSuccess = (datasources, totalRecords, countOpen) => {
    return {
        type: VENDOR_REQUESTS_GET_GRIDVIEW_DATA_SUCCESS,
        datasources,
        totalRecords,
        countOpen
    };
};

export const getVendorRequestsByIdGridViewDataSuccess = (dataVendorRequestsById) => {
    return {
        type: VENDOR_REQUESTS_BY_ID_GET_GRIDVIEW_DATA_SUCCESS,
        dataVendorRequestsById
    };
};
export const getVendorRequestsGridViewDataFailure = () => {
    return {
        type: VENDOR_REQUESTS_GET_GRIDVIEW_DATA_FAILURE
    };
};

export const getVendorRequestsGridViewData = (searchValues, criteria) => {
    return dispatch => {
        const conditions = { ...criteria, ...searchValues };

        dispatch(getVendorRequestsGridViewDataRequest());

        return apiGetSignersApproval(conditions, (result) => {

            dispatch(getVendorRequestsGridViewDataSuccess(result.data[0], result.data[1][0].TotalRecords, result.data[2][0].CountOpen));
        }, (error) => {
            dispatch(getVendorRequestsGridViewDataFailure());
            handleApiError(dispatch, error);
        });
    };
};

export const saveVendorApprovalRequest = () => {
    return {
        type: VENDOR_REQUESTS_SAVE_VENDOR_APPROVAL_REQUEST
    };
};

export const saveVendorApprovalFailure = () => {
    return {
        type: VENDOR_REQUESTS_SAVE_VENDOR_APPROVAL_FAILURE
    };
};

export const saveVendorApprovalValidate = (checkData, callback) => {
    return dispatch => {
        dispatch(saveVendorApprovalRequest());

        return apiCheckValidApproval(checkData, (result) => {
            callback(result.data.case);
        }, (error) => {
            dispatch(saveVendorApprovalFailure());
            handleApiError(dispatch, error);
        });
    };
};

export const saveVendorApproval = (approvalData, callback) => {
    return dispatch => {
        dispatch(saveVendorApprovalRequest());

        return apiUpdateSignerApproval(approvalData, () => {
            dispatch(showSuccess(approvalData.status === "Approved" ? "Vendor Assigned Successfully" : "This request has been rejected"));
            emitHaveNewActivity(approvalData.orderId);
            callback();
        }, (error) => {
            dispatch(saveVendorApprovalFailure());
            handleApiError(dispatch, error);
            callback();
        });
    };
};

export const getVendorApprovalById = (criteriaComment, identifier) => {
    return dispatch => {
        const criteria = { ...criteriaComment, identifier };
        return apiGetSignersApprovalById(criteria, (result) => {

            dispatch(getVendorRequestsByIdGridViewDataSuccess(result.data[0]));
        }, (error) => {
            dispatch(getVendorRequestsGridViewDataFailure());
            handleApiError(dispatch, error);
        });
    };
};

/**
 * Module values:
 * COM: Communication module
 * FEE: Fee request module
 * VEN: Vendor management module
 */

export const switchModuleOnMainPanel = (module) => {
    return {
        type: SWITCH_MODULE_ON_MAIN_PANEL,
        module
    };
};

// End Action Vendor Request
