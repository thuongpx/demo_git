import { apiGetParticipantInOrder } from "Api/orders-api";
// import { showError } from "./../../main-layout/actions/index";
import { handleApiError } from "ErrorHandler";

export const RECEIVE_ORDER_DATA_PARTICIPANT = "RECEIVE_ORDER_DATA_PARTICIPANT";
export const CLIENT_ORDER_DETAIL_VENDOR_INFO_SET_ISAUTOASSIGNED = "CLIENT_ORDER_DETAIL_VENDOR_INFO_SET_ISAUTOASSIGNED";
export const CLIENT_ORDER_DETAIL_ORDER_INFO_SET_PROGRESSID = "CLIENT_ORDER_DETAIL_ORDER_INFO_SET_PROGRESSID";

export const receiveOrderParticipant = (data) => {
    return {
        type: RECEIVE_ORDER_DATA_PARTICIPANT,
        data
    };
};

export const setIsAutoAssigned = (data) => {
    return {
        type: CLIENT_ORDER_DETAIL_VENDOR_INFO_SET_ISAUTOASSIGNED,
        data
    };
};

export const setOrderProgressId = (progressId) => {
    return {
        type: CLIENT_ORDER_DETAIL_ORDER_INFO_SET_PROGRESSID,
        progressId
    };
};

export const getParticipantInOrder = (orderId) => {
    return dispatch => {
        return apiGetParticipantInOrder(orderId, (result) => {
            dispatch(receiveOrderParticipant(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};