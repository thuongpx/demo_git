import { apiGetAppointmentDetailsInitData, apiUpdateAppointment } from "../../../api/orders-api";
import { handleApiError } from "ErrorHandler";

export const GET_APPOINTMENT_REQUEST = "GET_APPOINTMENT_REQUEST";
export const GET_APPOINTMENT_RECEIVE = "GET_APPOINTMENT_RECEIVE";
export const START_UPDATE_APPOINTMENT = "START_UPDATE_APPOINTMENT";
export const DONE_UPDATE_APPOINTMENT = "DONE_UPDATE_APPOINTMENT";

export const requestGetAppointment = () => {
    return {
        type: GET_APPOINTMENT_REQUEST
    };
};

export const receiveGetAppointment = (data) => {
    return {
        type: GET_APPOINTMENT_RECEIVE,
        data
    };
};

export const startUpdateAppointment = () => {
    return {
        type: START_UPDATE_APPOINTMENT
    };
};

export const doneUpdateAppointment = (data) => {
    return {
        type: DONE_UPDATE_APPOINTMENT,
        ...data
    };
};

export const getAppointment = (orderId) => {
    return dispatch => {
        dispatch(requestGetAppointment());

        return apiGetAppointmentDetailsInitData(orderId, (result) => {
            dispatch(receiveGetAppointment(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const updateAppointment = (data, cb) => {
    return dispatch => {
        dispatch(startUpdateAppointment());

        return apiUpdateAppointment(data, (result) => {
            dispatch(doneUpdateAppointment(result));
            if (typeof cb === "function") cb(result.data);
        }, (error) => handleApiError(dispatch, error));
    };
};