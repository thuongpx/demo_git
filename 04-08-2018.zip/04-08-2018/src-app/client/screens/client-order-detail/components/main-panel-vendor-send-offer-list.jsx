import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Component } from "react";
import GridView from "GridView";
import CommonModal from "CommonModal";
import { getVendorSentOfferList } from "../actions/main-panel-actions";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class SentOfferList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            gridCriteria: {
                sortColumn: "SentDate",
                sortDirection: false,
                page: 1,
                itemPerPage: 25
            }
        };
    }

    componentDidMount() {
        const { gridCriteria } = this.state;
        const { dispatch, orderId } = this.props;
        dispatch(getVendorSentOfferList(gridCriteria, orderId));
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    handleGridViewReload(criteria) {
        this.setState({ gridCriteria: criteria });
        const { dispatch, orderId } = this.props;
        dispatch(getVendorSentOfferList(criteria, orderId));
    }

    render() {

        const { columns, listDataVendorSentOffer, totalRecords } = this.props;
        const { gridCriteria } = this.state;

        return (
            <div>
                <GridView
                    criteria={gridCriteria}
                    totalRecords={totalRecords}
                    datasources={listDataVendorSentOffer}
                    defaultSortColumn={"SentDate"}
                    columns={columns}
                    identifier={"OfferID"}
                    onGridViewReload={this.handleGridViewReload.bind(this)}
                />
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

SentOfferList.defaultProps = {
    columns: [
        {
            title: "Offer ID",
            data: "OfferID"
        },
        {
            title: "Offer Amt",
            data: "OfferAmount",
            type: "money"
        },
        {
            title: "Last Name",
            data: "LastName"
        },
        {
            title: "First Name",
            data: "FirstName"
        },
        {
            title: "Status",
            data: "OfferStatus"
        },
        {
            title: "Sent By",
            data: "RepId"
        },
        {
            title: "Offer Sent Date",
            data: "SentDate",
            type: "datetime"
        },
        {
            title: "Offer Res Date",
            data: "ResponseDate",
            type: "datetime"
        },
        {
            title: "Text Sent",
            data: "Sent"
        }
    ]
};

SentOfferList.propTypes = {
    dispatch: PropTypes.func,
    columns: PropTypes.array,
    listDataVendorSentOffer: PropTypes.array,
    totalRecords: PropTypes.number,
    orderId: PropTypes.number
};

const mapStateToProps = (state) => {
    const { vendorSentOfferReducer } = state;
    const { listDataVendorSentOffer, needReload, totalRecords } = vendorSentOfferReducer;

    return {
        listDataVendorSentOffer,
        needReload,
        totalRecords
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(SentOfferList);
