import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { getAllActivity } from "../actions/main-panel-all-activities-action";
import { MESSAGE_SENT, MESSAGE_RECEIVE, FEE_SUBMIT } from "../../../constant/progress-log-constants";
import moment from "moment";
import Select from "Select";
import activityImg from "../../../public/images/activity.svg";
import mailRec from "../../../public/images/mail-receive.svg";
import mailSent from "../../../public/images/mail-sent.svg";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { listenHaveNewActivity, stopListenHaveNewActivity } from "../../../socket/orders";
import { listenOnSubmitFeeRequest, stopListenOnSubmitFeeRequest } from "../../../socket/orders";
import UserInfoTooltip from "../../client-order-detail/components/user-info-tooltip";
import ReactTooltip from "react-tooltip";
import { USER_TYPE } from "Constants";

class AllActivity extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isShowDetailMessage: {},
            currentProgressType: 0
        };
    }

    componentDidMount() {
        const { dispatch, orderId } = this.props;

        listenHaveNewActivity(() => {
            dispatch(getAllActivity(orderId));
        });

        listenOnSubmitFeeRequest(() => {
            dispatch(getAllActivity(orderId));
        });

        dispatch(getAllActivity(orderId));
    }

    handleToggleAssignAVendor() {
        this.props.onAssignAVendor(true);
    }

    componentWillUnmount() {
        stopListenHaveNewActivity();
        stopListenOnSubmitFeeRequest();
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {
        const { dataProgressLog, accountId, roleType } = this.props;
        const { currentProgressType } = this.state;

        const listDataProgressLog = dataProgressLog.filter(progressLog => {
            let isPass = true;
            if (parseInt(currentProgressType) !== 0) {
                isPass = parseInt(progressLog.progressType) === parseInt(currentProgressType);
            }
            return isPass;
        }).map((item, index) => {
            switch (item.progressType) {
                case MESSAGE_SENT:
                    return (
                        <div key={index}>
                            {accountId === item.usersId ?
                                <div>
                                    <div className="activity-record">
                                        <img src={mailSent} alt="" style={{ width: "15px", marginRight: "5px", verticalAlign: "middle" }} />
                                        <small className="right prefix-sm">{moment(item.dateLog).format("MMM D YYYY [at] h:mm A")}</small>
                                        <span className="font-weight-500 ml-detail-message">{item.activity}</span>
                                        <br />
                                        {!this.state.isShowDetailMessage[index] ? <a role="button" className="ml-2" onClick={() => {
                                            const isShowDetailMessage = this.state.isShowDetailMessage;
                                            isShowDetailMessage[index] = true;
                                            this.setState({ isShowDetailMessage });
                                        }}><small>See details...</small></a> :
                                            <div className="ml-2">
                                                <small>
                                                    <p>{item.message}</p>
                                                    <a role="button" onClick={() => {
                                                        const isShowDetailMessage = this.state.isShowDetailMessage;
                                                        isShowDetailMessage[index] = false;
                                                        this.setState({ isShowDetailMessage });
                                                    }}>Hide Details...</a>
                                                </small>
                                            </div>
                                        }
                                        <div className="clear"></div>
                                    </div>
                                    <div className="divider"></div>
                                </div> : null}
                        </div>

                    );
                case MESSAGE_RECEIVE:
                    return (
                        <div key={index}>
                            {accountId !== item.usersId ?
                                <div>
                                    <div className="activity-record">
                                        <img src={mailRec} alt="" style={{ width: "15px", marginRight: "15px" }} />
                                        <button
                                            className="btn btn-s-small default-color mr-1"
                                            onClick={() => {
                                                if (item.roleType === USER_TYPE.Vendor) {
                                                    this.props.setActiveTab({ title: "Vendor Communications" });
                                                } else if (roleType !== "Staff") {
                                                    this.props.setActiveTab({ title: "TCE Communications" });
                                                } else {
                                                    this.props.setActiveTab({ title: "Client Communications" });
                                                }
                                            }}
                                        >REPLY
                                </button>
                                        <small className="right prefix-sm">{moment(item.dateLog).format("MMM D YYYY [at] h:mm A")}</small>
                                        {item.roleType === USER_TYPE.Vendor ? <span className="font-weight-500 vendor-tooltip-user">{item.activity.slice(0, 21)}<a role="button" data-tip data-for={`vendor-tooltip-id:${index}`}>{item.activity.slice(21)}</a>
                                            <ReactTooltip ref={(node) => { this.FilterTooltip = node; }} className="p-0" event="click" place="right" id={`vendor-tooltip-id:${index}`} aria-haspopup="true" role="example" allow>
                                                <UserInfoTooltip
                                                    afterShow={() => this.handleTooltip()}
                                                    onAssignVendor={() => {
                                                        this.handleToggleAssignAVendor();
                                                        this.FilterTooltip.hideTooltip();
                                                    }}
                                                    onSendMessage={() => {
                                                        this.props.setActiveTab({ title: "Vendor Communications" });
                                                        this.FilterTooltip.hideTooltip();
                                                    }}
                                                    key={`vendor-tooltip-key:${index}:${Math.random()}`}
                                                    vendorId={item.mappingUserId}
                                                />
                                            </ReactTooltip>
                                        </span> : <span className="font-weight-500">{item.activity}</span>}
                                        <br />
                                        {!this.state.isShowDetailMessage[index] ? <a role="button" className="ml-detail-message-receive" onClick={() => {
                                            const isShowDetailMessage = this.state.isShowDetailMessage;
                                            isShowDetailMessage[index] = true;
                                            this.setState({ isShowDetailMessage });
                                        }}><small>See details...</small></a> :
                                            <div className="ml-detail-message-receive">
                                                <small>
                                                    <p>{item.message}</p>
                                                    <a role="button" onClick={() => {
                                                        const isShowDetailMessage = this.state.isShowDetailMessage;
                                                        isShowDetailMessage[index] = false;
                                                        this.setState({ isShowDetailMessage });
                                                    }}>Hide Details...</a>
                                                </small>
                                            </div>
                                        }
                                        <div className="clear"></div>
                                    </div>
                                    <div className="divider"></div>
                                </div> : null}
                        </div>
                    );
                case FEE_SUBMIT:
                    return (
                        <div key={index}>
                            <div className="activity-record">
                                <img src={activityImg} alt="" style={{ width: "15px", marginRight: "5px" }} />
                                <span className="font-weight-500">{item.activity}</span>
                                <small className="right prefix-sm">{moment(item.dateLog).format("MMM D YYYY [at] h:mm A")}</small>
                                <div className="clear"></div>
                            </div>
                            <div className="divider"></div>
                        </div >

                    );
                default:
                    return (
                        <div key={index}>
                            <div className="activity-record">
                                <img src={activityImg} alt="" style={{ width: "15px", marginRight: "5px" }} />
                                <span className="font-weight-500">{item.activity}</span>
                                <small className="right prefix-sm">{moment(item.dateLog).format("MMM D YYYY [at] h:mm A")}</small>
                                <div className="clear"></div>
                            </div>
                            <div className="divider"></div>
                        </div >
                    );
            }

        });

        const displayList = [{ value: 0, label: "ALL ACTIVITY" }, { value: 1, label: "ACTION" }, { value: 2, label: "MESSAGE SENT" }, { value: 3, label: "MESSAGE RECEIVE" }];

        const displayListDataProgressLog = () => {

            // if (progressTypeCondition) {
            return (
                <div className="tab-wrap st2 panel-order-detail row p-0">
                    <div className="col s12 p-0">
                        Displaying
                        <div className="input-field inline custome-st-inline ml-1">
                            <Select
                                dataSource={displayList}
                                mapDataToRenderOptions={{ value: "value", label: "label" }}
                                value={currentProgressType}
                                onChange={(value) => {
                                    this.setState({
                                        currentProgressType: value
                                    });
                                }}
                            />
                        </div>
                    </div>
                    <div className="clear"></div>
                    <div className="divider" style={{ height: "2px", margin: "10px", marginTop: 0 }}></div>
                    {listDataProgressLog.length >= 1 ? <div className="pos-rel activity-box" style={{ paddingRight: "10px" }}>
                        {listDataProgressLog}
                    </div> : <div className="center-align">{"There are no records to show."}</div>}
                </div >
            );
            // }
            // return "";
        };

        return (
            <div>
                {displayListDataProgressLog()}
            </div >
        );
    }
}

AllActivity.propTypes = {
    dispatch: PropTypes.func,
    orderId: PropTypes.number,
    dataProgressLog: PropTypes.array,
    setActiveTab: PropTypes.func,
    onAssignAVendor: PropTypes.func,
    accountId: PropTypes.number,
    roleType: PropTypes.string
};

const mapStateToProps = (state) => {
    const { clientOrderDetail, authentication } = state;
    const { mainPanelAllActivitiesReducer } = clientOrderDetail;
    const { dataProgressLog } = mainPanelAllActivitiesReducer;
    const { accountId, role } = authentication;
    const { roleType } = role;

    return {
        dataProgressLog,
        accountId,
        roleType
    };
};

export default connect(mapStateToProps)(AllActivity);
