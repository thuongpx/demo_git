import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";

import moment from "moment";

import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { getCustomerFeedback } from "../actions/right-panel-actions";
import { CUSTOMER_FEEDBACK_VALUES } from "Constants";
import CommonModal from "../../../features/common-modal/common-modal";

class CustomerFeedbackRightPanel extends Component {
    constructor(props) {
        super(props);

        this.state = {
            editMode: false,
            feedbackOption: "",
            feedbackComments: [],
            inputs: {
                feedbackText: ""
            }
        };
    }

    // shouldComponentUpdate(nextProps, nextState) {
    //     return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    // }

    // componentDidMount() {
    //     const { dispatch, orderId } = this.props;

    //     if (orderId) {
    //         dispatch(getCustomerFeedback(orderId));
    //     }
    // }

    componentWillReceiveProps(nextProps) {
        const { customerFeedbackData } = nextProps;

        if (!customerFeedbackData) return;

        this.setState({
            feedbackOption: customerFeedbackData.feedbackOption || CUSTOMER_FEEDBACK_VALUES.NEUTRAL,
            feedbackComments: customerFeedbackData.feedbackComments
        });
    }

    handleEditCustomerFeedback() {
        this.setState({
            editMode: true
        }, () => {
            this.refs.customerFeedbackContent.focus();
        });
    }

    handlerInputsOnchange(key, value) {
        if (key === "feedbackText") {
            this.setState({
                inputs: {
                    feedbackText: value
                }
            });
        }

        if (key === "feedbackOption") {
            this.setState({
                feedbackOption: value
            });
        }
    }

    addFeeback() {
        const { orderId, userId, userName } = this.props;
        const { inputs, feedbackComments } = this.state;

        const feedback = {
            feedbackId: -9999,
            orderId,
            comment: inputs.feedbackText,
            createdBy: userId,
            userName: userName,
            createdDate: moment().format("YYYY-MM-DD HH:mm:ss")
        }

        feedbackComments.push(feedback);

        inputs.feedbackText = "";

        this.setState({
            feedbackComments,
            inputs
        });
    }

    handleSaveCustomerFb() {
        const { onSaveFeedback } = this.props;
        const { feedbackComments, feedbackOption } = this.state;

        const comments = [];
        feedbackComments.map((item) => {
            if (item.feedbackId !== -9999) return;

            comments.push({
                orderId: item.orderId,
                comment: item.comment,
                createdBy: item.createdBy,
                createdDate: item.createdDate
            });
        });


        const data = {
            feedbackOption: feedbackOption,
            feedbackComments: comments
        };

        onSaveFeedback(data, () => {
            this.setState({
                editMode: false,
                inputs: {
                    feedbackText: ""
                }
            });
        });
    }

    handleCancelCustomerFb() {
        const { customerFeedbackData } = this.props;

        this.commonModal.showModal({
            type: "confirm",
            message: "Are you sure you would like to cancel adding customer’s feedback and comments?"
        }, () => {
            this.setState({
                editMode: false,
                feedbackOption: customerFeedbackData.feedbackOption || "E",
                feedbackComments: customerFeedbackData.feedbackComments,
                inputs: {
                    feedbackText: ""
                }
            });
        }, () => {
            //this.refs.customerFeedbackContent.focus();
        });
    }

    renderFeedback(feedbackComments) {
        if (!feedbackComments || feedbackComments.length === 0) {
            return (<div></div>);
        }

        return (
            <div className="col s12 mt-1" style={{ maxHeight: "200px", overflowY: "scroll" }}>
                <div className="termdata">
                    <ul style={{ marginLeft: 15 }}>

                        {feedbackComments.map((item, index) => {
                            return (
                                <li key={index} style={{ marginBottom: 5 }}>
                                    {item.comment}
                                    <span style={{
                                        display: "block", fontSize: "9pt", color: "#948d8d", paddingLeft: "15px"
                                    }}>
                                        -{item.userName}- {moment(item.createdDate).format("MM/DD/YY @ h:mm A")}
                                    </span>
                                </li>
                            );
                        })}
                    </ul>
                </div>
            </div>
        );
    }

    render() {
        const { feedbackComments, inputs, editMode } = this.state;
        const { customerFeedbackData } = this.props;

        if (!customerFeedbackData) {
            return (<div></div>);
        }

        if (!customerFeedbackData.orderDetail) {
            return (<div></div>);
        }

        if (!customerFeedbackData.orderDetail.hasClosedByVendor || !customerFeedbackData.orderDetail.hasCustomer) {
            return (<div></div>);
        }

        return (
            <div>
                <div className="tab-wrap st2 panel-order-detail row box-shadow-st2 p-0 mt-0">
                    <ul className="tabs">
                        <li className="tab col s8 truncate active ml-0">
                            <a role="button">CUSTOMER FEEDBACK</a>
                        </li>

                        {!editMode && <li className="col s4 right pt-1 pr-1">
                            <span className="cursor-pointer right order-edit" onClick={() => this.handleEditCustomerFeedback()}>
                                <i className="lnr lnr-pencil"></i>
                            </span>
                        </li>}
                    </ul>
                    <div className="tab-content p-0">
                        <div className="row mt-1">
                            <div className="col s12">
                                <div className="col s4">
                                    <label>
                                        <input
                                            className="with-gap"
                                            name="feedbackOptionGroup"
                                            type="radio"
                                            checked={this.state.feedbackOption === CUSTOMER_FEEDBACK_VALUES.NEUTRAL}
                                            onChange={() => this.handlerInputsOnchange("feedbackOption", CUSTOMER_FEEDBACK_VALUES.NEUTRAL)}
                                            disabled={!editMode}
                                        />
                                        <span>Neutral</span>
                                    </label>
                                </div>

                                <div className="col s4">
                                    <label>
                                        <input
                                            className="with-gap"
                                            name="feedbackOptionGroup"
                                            type="radio"
                                            checked={this.state.feedbackOption === CUSTOMER_FEEDBACK_VALUES.POSITIVE}
                                            onChange={() => this.handlerInputsOnchange("feedbackOption", CUSTOMER_FEEDBACK_VALUES.POSITIVE)}
                                            disabled={!editMode}
                                        />
                                        <span>Positive</span>
                                    </label>
                                </div>

                                <div className="col s4">
                                    <label>
                                        <input
                                            className="with-gap"
                                            name="feedbackOptionGroup"
                                            type="radio"
                                            checked={this.state.feedbackOption === CUSTOMER_FEEDBACK_VALUES.NEGATIVE}
                                            onChange={() => this.handlerInputsOnchange("feedbackOption", CUSTOMER_FEEDBACK_VALUES.NEGATIVE)}
                                            disabled={!editMode}
                                        />
                                        <span>Negative</span>
                                    </label>
                                </div>
                            </div>

                            {this.renderFeedback(feedbackComments)}

                            {editMode && <div className="col s12">
                                <div className="input-field col s12">
                                    <input type="text"
                                        ref="customerFeedbackContent"
                                        id="customerFeedbackContent"
                                        maxLength="250"
                                        value={inputs.feedbackText}
                                        onChange={(e) => this.handlerInputsOnchange("feedbackText", e.target.value)}
                                    />
                                    <label htmlFor="customerFeedbackContent" className={`active`}>Enter customer's comment here</label>
                                </div>
                            </div>}

                            {editMode && <div className="col s12 right-align">
                                <div className="col s12">
                                    <button
                                        type="button"
                                        className="btn btn-small success-color"
                                        onClick={() => this.addFeeback()}
                                        disabled={inputs.feedbackText.length === 0}
                                    >Add</button>
                                </div>
                                <div className="col s12 mt-1"><div className="col s12 p-0"><div className="divider"></div></div></div>
                            </div>}
                        </div>

                        {editMode && <div className="row">
                            <div className="col s12">
                                <div className="col m6">
                                    <button className="btn btn-small white w-100" onClick={() => this.handleCancelCustomerFb()}>Cancel</button>
                                </div>
                                <div className="col m6">
                                    <button className="btn btn-small success-color w-100" onClick={() => this.handleSaveCustomerFb()}>Save</button>
                                </div>
                            </div>
                        </div>}
                    </div>
                </div>

                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

CustomerFeedbackRightPanel.propTypes = {
    customerFeedbackData: PropTypes.object,
    onSaveFeedback: PropTypes.func,
    userId: PropTypes.number,
    userName: PropTypes.string
}

export default CustomerFeedbackRightPanel;