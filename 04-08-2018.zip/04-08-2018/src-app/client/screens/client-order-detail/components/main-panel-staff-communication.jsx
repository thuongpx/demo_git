import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";

import MainPanelVendorCommunication from "./main-panel-vendor-communication";
import MainPanelAddNote from "../components/main-panel-add-note";
import MainPanelClientCommunication from "../../vendor-order-detail/components/main-panel-client-communications";
import MainPanelProblem from "./main-panel-problem";
import MainPanelSpecifics from "./main-panel-specifics";

import { handleApiError } from "ErrorHandler";
import { apiCheckIsSelfSerivce, apiCheckAssignVendor } from "../../../api/orders-api";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class OrderDetailStaffCommunication extends Component {
    constructor(props) {
        super(props);

        const tabs = [
            { title: "Add a Note", isActive: true },
            { title: "Vendor Communications", isActive: false },
            { title: "Client Communications", isActive: false },
            { title: "Correction Requests", isActive: false },
            { title: "Specifics", isActive: false }
        ];

        // set tab default if there is not any tab matches value in cookies
        const activeTabs = tabs.filter((item) => {
            return item.isActive;
        });

        if (activeTabs.length === 0) tabs[0].isActive = true;

        this.state = {
            tabs,
            vendorName: ""
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    async componentDidMount() {
        const { dispatch } = this.props;
        const { orderId } = this.props;

        await apiCheckIsSelfSerivce(orderId, (result) => {
            this.handleIsSelfService(result.data.isSelfService);
        }, (error) => handleApiError(dispatch, error));

        await apiCheckAssignVendor(orderId, (result) => {
            this.handleAssignVendor(result.data.isAssignVendor);
            //eslint-disable-next-line
            this.setState({ vendorName: result.data.vendorName });
        }, (error) => handleApiError(dispatch, error));
    }

    handleIsSelfService(bool) {
        if (bool) {
            this.setState({
                tabs: [
                    { title: "Add a Note", isActive: true },
                    { title: "Vendor Communications", isActive: false },
                    { title: "Correction Requests", isActive: false },
                    { title: "Specifics", isActive: false }
                ]
            });
        }
    }

    handleAssignVendor(bool) {
        if (!bool) {
            this.setState({
                tabs: [
                    { title: "Add a Note", isActive: true },
                    { title: "Client Communications", isActive: false },
                    { title: "Correction Requests", isActive: false },
                    { title: "Specifics", isActive: false }
                ]
            });
        } else {
            this.setState({
                tabs: [
                    { title: "Add a Note", isActive: true },
                    { title: "Vendor Communications", isActive: false },
                    { title: "Client Communications", isActive: false },
                    { title: "Correction Requests", isActive: false },
                    { title: "Specifics", isActive: false }
                ]
            });
        }
    }

    handleTabClick(tab) {
        const tabs = this.state.tabs;
        const isFirstTab = false;

        //validate current form
        for (const index in tabs) {
            const item = tabs[index];
            if (item.isActive && item.title !== tab.title) {
                switch (item.title) {
                    case "Vendor Communications":
                        break;
                    case "Client Communications":
                        break;
                    case "Correction Requests":
                        break;
                    case "Specifics":
                        break;
                    default:
                        break;
                }

            }
        }

        if (!isFirstTab) {
            this.setActiveTab(tab);
        }
    }

    setActiveTab(tab) {
        const { tabs } = this.state;

        tabs.map(item => {
            if (item.title === tab.title) {
                item.isActive = true;
            } else item.isActive = false;
            return item;
        });
        this.setState({ tabs });
    }
    render() {

        const { orderId } = this.props;
        const { vendorName } = this.state;

        const renderTabs = () => {
            return this.state.tabs.map((tab) => {
                const classNameActive = tab.isActive ? "active" : "";

                return (
                    <li className={`tab col ${classNameActive}`} key={tab.title} onClick={() => this.handleTabClick(tab)}>
                        <a style={{ cursor: "pointer" }}>{tab.title}</a>
                    </li>
                );
            });
        };

        const renderTabContent = () => {

            return this.state.tabs.map((tab) => {

                if (tab.isActive) {
                    switch (tab.title) {
                        case "Vendor Communications":
                            return (
                                <div id="vendor" key={tab.title} className="col s12 tab-content">
                                    <MainPanelVendorCommunication orderId={orderId} vendorName={vendorName} />
                                </div>
                            );
                        case "Client Communications":
                            return (
                                <div id="client" key={tab.title} className="col s12 tab-content">
                                    <MainPanelClientCommunication orderId={orderId} />
                                </div>
                            );
                        case "Correction Requests":
                            return (
                                <div id="problem" key={tab.title} className="col s12 tab-content">
                                    <MainPanelProblem orderId={orderId} />
                                </div>
                            );
                        case "Specifics":
                            return (
                                <div id="specifics" key={tab.title} className="col s12 tab-content right">
                                    <MainPanelSpecifics orderId={orderId} />
                                </div>
                            );
                        default:
                            return (
                                <div id="note" key={tab.title} className="col s12 tab-content p-0">
                                    <MainPanelAddNote orderId={orderId} />
                                </div>
                            );
                    }
                }
                return null;
            });
        };

        return (
            <div className="col s12">
                <div className="tab-wrap st2 panel-order-detail row p-0">
                    <div className="col s12 mt-2 p-0">
                        <ul className="tabs">
                            {renderTabs()}
                        </ul>
                    </div>
                    {renderTabContent()}
                </div>
            </div>
        );
    }
}


OrderDetailStaffCommunication.propTypes = {
    accountId: PropTypes.number,
    orderId: PropTypes.number,
    onAutoAssignRunned: PropTypes.func,
    onAssignAVendor: PropTypes.func,
    dispatch: PropTypes.func
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { accountId } = authentication;

    return {
        accountId
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(OrderDetailStaffCommunication);