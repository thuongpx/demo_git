import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";
import { updateTextFields } from "../../../helpers/theme-helper";
import moment from "moment";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class OrderVendorRequestsReviewModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            validator: {
                isDescriptionInvalid: false
            },
            disabled: true
        };
    }

    handleCloseForm() {
        const { onClose } = this.props;
        onClose();
        this.refs.addComment.value = "";
        this.setState({ disabled: true });
    }

    handleActionClicked(event, status) {
        event.preventDefault();
        const { onChangeStatus, approvalModal, onClose } = this.props;
        const vendorRequestation = approvalModal.approvalDetail;
        const approvalData = {
            status,
            approvalId: vendorRequestation.ApprovalID,
            email: vendorRequestation.Email,
            orderId: vendorRequestation.OrderId,
            signerId: vendorRequestation.SignerId,
            mgrReason: vendorRequestation.MgrReason,
            loanType: vendorRequestation.LoanType,
            distance: vendorRequestation.Distance,
            offerAmount: vendorRequestation.OfferAmount,
            firstName: vendorRequestation.FirstName,
            lastName: vendorRequestation.LastName,
            city: vendorRequestation.City,
            reason: vendorRequestation.Reason,
            vendorName: vendorRequestation.VendorName,
            fullNameAgent: vendorRequestation.FullName,
            userName: vendorRequestation.UserName
        };
        onClose();
        onChangeStatus(approvalData);
    }

    handleAddComment() {
        const { onSaveComments, approvalModal } = this.props;
        const vendorRequestation = approvalModal.approvalDetail;
        const inputs = {
            Description: this.refs.addComment.value,
            SetPrivateComment: false,
            OwnerID: vendorRequestation.ApprovalID,
            CreatedDate: moment().utc().format("YYYY-MM-DD @ HH:mm:ss"),
            RequestedBy: vendorRequestation.UserName
        };
        onSaveComments({
            inputs
        });

        approvalModal.description.push(inputs);
        this.refs.addComment.value = "";
        this.setState({ disabled: true });
    }

    //internal handler -- react handler
    handleInputChange(event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    componentDidUpdate() {
        updateTextFields();
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    handleKeyPress(e) {
        if (e.key === "Enter") {
            this.handleAddComment();
        }
    }

    render() {
        const { isOpen, approvalModal, roleNames } = this.props;
        const vendorRequestation = approvalModal.approvalDetail;
        let isStaff = false;
        roleNames.map((item) => {
            if (item === "Branch" || item === "Client" || item === "Admin" || item === "Content Manager" || item === "Training Manager" || item === "Accounting Manager" || item === "Operational Manager") {
                isStaff = true;
            }
        });
        return (
            <div>
                <Modal isOpen={isOpen} addClass="no-tab">
                    <ModalBody>
                        <ModalTitle onClickClose={() => { this.handleCloseForm(false); }}>Vendor Approval Request Details</ModalTitle>
                        <div className="tab-content">
                            <div className="row">
                                <div className="input-field col s6">
                                    <b>Order ID: <label style={{ margin: 10 }}>{vendorRequestation && vendorRequestation.OrderId ? vendorRequestation.OrderId : ""}</label></b>
                                </div>
                                <div className="input-field col s6">
                                    <b>Approval Status : <label style={{ margin: 10 }}>{vendorRequestation && vendorRequestation.Status ? vendorRequestation.Status : ""}</label></b>
                                </div>
                            </div>
                            <div className="row">
                                <div className="input-field col s6">
                                    <b>Requested By : <label style={{ margin: 10 }}>{vendorRequestation && vendorRequestation.UserName ? vendorRequestation.UserName : ""}</label></b>
                                </div>
                                <div className="input-field col s6">
                                    <b>Vendor Name : <label style={{ margin: 10 }}>{vendorRequestation && vendorRequestation.VendorName ? vendorRequestation.VendorName : ""}</label></b>
                                </div>
                            </div>

                            <div className="row">
                                <div className="input-field col s12">
                                    <p className="mb-1"><b>Description</b></p>
                                    <div className="letter_agree" style={{ maxHeight: 150, marginTop: 0 }}>
                                        <div className="termdata">
                                            <ul style={{ margin: 0 }}>
                                                {approvalModal.description !== undefined &&
                                                    approvalModal.description.map((data, index) => {
                                                        return (
                                                            <li key={index} style={{ marginBottom: 5 }}>
                                                                {data.Description}
                                                                <span style={{
                                                                    display: "block", fontSize: "9pt", color: "#948d8d", paddingLeft: "15px"
                                                                }}>-{vendorRequestation.UserName}- {moment(data.CreatedDate).format("MM/DD/YY h:mm:ss A")}</span>
                                                            </li>
                                                        );
                                                    }
                                                    )
                                                }
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="input-field col s10">
                                    <input type="text" id="addComment" maxLength="250" ref="addComment" className="validate" onChange={() => this.setState({ ...this.state, disabled: this.refs.addComment.value === "" ? true : false })} onKeyPress={(e) => this.handleKeyPress(e)}></input>
                                    <label htmlFor="addComment">Add Comment</label>
                                </div>
                                <div className="input-field col s2">
                                    <button className="btn success-color w-100" disabled={this.state.disabled} onClick={() => this.handleAddComment()}>Enter</button>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        {
                            vendorRequestation && vendorRequestation.Status === "Pending" && isStaff ? (
                                <div className="row m-0">
                                    <div className="col m4">
                                        <button className="btn white w-100" onClick={() => this.handleCloseForm(false)}>Cancel</button>
                                    </div>
                                    <div className="col m4">
                                        <button className="btn success-color w-100" onClick={(e) => this.handleActionClicked(e, "Approved")}>
                                            Approve
                                        </button>
                                    </div>
                                    <div className="col m4">
                                        <button className="btn error-color w-100" onClick={(e) => this.handleActionClicked(e, "Rejected")}>
                                            Decline
                                        </button>
                                    </div>
                                </div>) : (
                                    <div className="row m-0">
                                        <div className="col s12">
                                            <button className="btn white w-100" onMouseDown={(e) => this.handleCloseForm(e)}>
                                                Close
                                        </button>
                                        </div>
                                    </div>)
                        }
                    </ModalFooter>
                </Modal>
            </div>
        );
    }
}

OrderVendorRequestsReviewModal.propTypes = {
    isOpen: PropTypes.bool.isRequired,
    onClose: PropTypes.func,
    approvalModal: PropTypes.object,
    onChangeStatus: PropTypes.func,
    onSaveComments: PropTypes.func,
    onGetDataVendorApprovalById: PropTypes.func,
    roleNames: PropTypes.array
};

export default OrderVendorRequestsReviewModal;