import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { ACTION } from "../../../constant/progress-log-constants";

import { deleteDoc } from "../actions/right-panel-actions";
import moment from "moment";
// import {} from "Constants/progress-log-constants";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class ArchiveTab extends Component {
    constructor(props) {
        super(props);
    }

    deleteDoc(doc) {
        const { dispatch, orderId, accountId, userName } = this.props;

        const log = {
            orderId,
            activity: `${userName} deleted permanently document ${doc.description}`,
            usersId: accountId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            progressType: ACTION
        };

        dispatch(deleteDoc(doc.docId, log));
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    renderListDocs() {
        const { orderDocs, handleDownloadDocument } = this.props;

        const docArchived = orderDocs.filter(doc => doc.archive);

        return !Array.isArray(docArchived) || docArchived.length === 0 ? <div className="center-align p-3">There are no records to show.</div>
            : docArchived.map((doc, key) => {

                return (
                    <div key={key} className="row mb-0 valign-wrapper border-bottom">
                        <div className="col s11 truncate pt-1 pb-1 cursor-pointer" title={doc.description} onClick={() => handleDownloadDocument(doc.docId, 1, doc.description)}> {doc.description}</div>
                        <div className="col s1 center-align">
                            <span onClick={() => this.deleteDoc(doc)} className="red-color cursor-pointer">
                                <i className="lnr lnr-trash"></i>
                            </span>
                        </div>
                    </div>
                );
            });
    }

    render() {

        return (
            <div id="DocsArchive" className="col s12 scroll-box list-docs mb-1">
                {this.renderListDocs()}
            </div>
        );
    }
}

ArchiveTab.propTypes = {
    dispatch: PropTypes.func,
    accountId: PropTypes.number,
    orderId: PropTypes.number,
    orderDocs: PropTypes.array,
    userName: PropTypes.string.isRequired,
    handleDownloadDocument: PropTypes.func
};

const mapStateToProps = (state) => {
    const { authentication, clientOrderDetail } = state;
    const { accountId, profile } = authentication;
    const { userName } = profile;
    const { rightPanel } = clientOrderDetail;
    const { orderDocs } = rightPanel;

    return {
        accountId,
        orderDocs,
        userName
    };
};

export default connect(mapStateToProps)(ArchiveTab);