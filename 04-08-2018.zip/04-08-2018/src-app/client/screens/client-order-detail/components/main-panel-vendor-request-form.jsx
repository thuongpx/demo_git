import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";
import moment from "moment";

import { requireMessage, validateRequired } from "Helpers/validation-helper";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class VendorRequestForm extends Component {
    constructor(props) {
        super(props);

        this.state = {
            isEnable: false,
            comments: [],
            validator: {}
        };
    }

    checkCommentAvailable() {
        const comment = this.refs.addComment.value;

        this.setState({
            isEnable: !!comment
        });
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    handleEnterComment() {
        this.setState({
            comments: [
                ...this.state.comments,
                {
                    content: `${this.refs.addComment.value}`,
                    time: `- ${this.props.fullName} - ${moment().format("MM/DD/YY @ h:mm A").toString()}`
                }
            ]
        });
    }

    handleValidateComment() {
        const isCommentRequiredInvalid = !validateRequired(this.refs.addComment.value);
        this.setState({ validator: { ...this.state.validator, isCommentRequiredInvalid } });
        return isCommentRequiredInvalid;
    }

    handleSend() {
        if (!this.handleValidateComment()) return;
    }

    handleCancel() {
        const { onShowVendorRequest } = this.props;

        onShowVendorRequest(false);
    }

    render() {
        const { fullName, vendorName, isOpen } = this.props;
        const { comments } = this.state;

        const commentList = comments.map((item, index) => {
            return (
                <div key={index}>
                    <p>{item.content}</p>
                    <label>
                        {item.time}
                    </label>
                </div>
            );
        });

        return (
            <Modal isOpen={isOpen}>
                <ModalBody>
                    <ModalTitle onClickClose={() => { this.handleCancel(); }}>Vendor Request</ModalTitle>
                    <div className="tab-content">
                        <div className="row">
                            <div className="col s2">
                                <p>Requested By:</p>
                            </div>
                            <div className="col s4">
                                <input type="text" id="" className="validate" value={fullName} disabled />
                            </div>
                            <div className="col s2">
                                <p>Vendor Name:</p>
                            </div>
                            <div className="col s4">
                                <input type="text" id="" className="validate" value={vendorName} disabled />
                            </div>
                        </div>
                        <div className="row">
                            <p>Description</p>
                        </div>
                        <div className="row">
                            <ul>
                                {commentList}
                            </ul>
                        </div>
                        <div className="row">
                            <div className="input-field required col s10 suffixinput">
                                <input type="text" ref="question"
                                    onChange={() => this.checkCommentAvailable()}
                                    onBlur={() => this.handleValidateComment()}
                                    id="addComment" className="validate"
                                    ref="addComment"
                                />
                                <label htmlFor="addComment">Question</label>
                                <span className={`suffix-text ${this.state.validator.isCommentRequiredInvalid ? "" : "hide"}`}>
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Add Comment Field")} />
                                </span>
                            </div>
                            <div className="col s2">
                                <button type="button" className="btn success-color action-btn mr-1" disabled={!this.state.isEnable} onClick={() => this.handleEnterComment()}>Enter</button>
                            </div>
                        </div>
                    </div>

                </ModalBody>
                <ModalFooter>
                    <div className="row">
                        <div className="col m6 s6 ">
                            <button className="btn w-100 white" onMouseDown={() => this.handleCancel()}>Cancel</button>
                        </div>
                        <div className="col m6 s6">
                            <button className="btn success-color w-100" onMouseDown={() => { this.handleSend(); }} >Send</button>
                        </div>
                    </div>
                </ModalFooter>
            </Modal>
        );
    }

}

VendorRequestForm.propTypes = {
    fullName: PropTypes.string,
    vendorName: PropTypes.string,
    onShowVendorRequest: PropTypes.func,
    isOpen: PropTypes.bool
};

export default VendorRequestForm;