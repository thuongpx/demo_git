import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { getOrderDetailLeftPanelInitData, updateLeftPanel } from "./../actions/left-panel-actions";
import { hasStringValue, convert2PhoneWithFormat } from "Helpers/common-helper";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "../../../features/modal";
import { ORDER_DETAIL_PROGRESS } from "../../../constant/order-detail-constants";
import { handleApiError } from "ErrorHandler";
import { apiAddNewOrderProgress } from "Api/order-progress-api";
// import { apiUpdateLeftPanel } from "../../../api/orders-api";
import moment from "moment";
import { ACTION } from "../../../constant/progress-log-constants";
import { showSuccess } from "../../main-layout/actions";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import CustomerInformationFilter from "../../client-place-an-order/components/customer-information-filter";

class LeftPanelCustomer extends Component {
    constructor(props) {
        super(props);

        this.state = {
            customerEditing: false,
            refEditing: {
                isSaving: false,
                isEditing: false,
                value: "",
                name: "refNumber"
            },
            openCancellationModal: false,
            newProgressId: 0
        };

        this.dataToSendMail = {};
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    getProgressDescription(progressId) {
        const { listProgresses } = this.props;

        const result = listProgresses.find((element) => {
            return element.ProgressId.toString() === progressId.toString();
        }).ProgressDescription;

        return result;
    }

    addNewOrderProgress(input, cb) {
        const newProgress = this.getProgressDescription(input.newProgress);
        const oldProgress = this.getProgressDescription(input.oldProgress);
        const reasonProgress = input.reasonProgress;

        const log = {
            OrderId: input.orderId,
            Activity: reasonProgress === undefined ? `Order status changed from ${newProgress} to ${oldProgress}` : `Order status changed from ${newProgress} to ${oldProgress}. \nReason: ${reasonProgress}`,
            UsersId: input.accountId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            ProgressType: ACTION
        };

        //add activity log
        apiAddNewOrderProgress(log,
            () => {
                if (typeof cb === "function") cb();
            },
            (error) => handleApiError(error)
        );
    }

    handleEditCustomer() {
        this.customerInformationFilter.componentWillMount();
        this.customerInformationFilter.validateForm();
        this.setState({
            customerEditing: true
        });
    }
    handleCancelEditCustomer() {
        this.setState({
            customerEditing: false
        });
    }
    handleSaveEditCustomer() {
        const { dispatch, roleType } = this.props;
        if (this.customerInformationFilter.validateForm()) {
            this.customerInformationFilter.saveChanges(false, (newOrderId) => {
                dispatch(getOrderDetailLeftPanelInitData({ orderId: newOrderId, portal: roleType }));
                dispatch(showSuccess(`Saved successfully.`));
            });
            this.setState({
                customerEditing: false
            });
        }
    }
    setDataToSendMail(data) {
        this.dataToSendMail = { ...this.dataToSendMail, ...data };
    }

    handleCancel(obj) {
        switch (obj.name) {
            case "refNumber":
                this.setState({
                    refEditing: {
                        ...this.state.refEditing,
                        isEditing: false,
                        value: ""
                    }
                });
                break;
        }
    }
    handleSave(obj) {
        const { dispatch, orderId } = this.props;
        const { refEditing } = this.state;
        let rawData = {};
        switch (obj.name) {
            case "refNumber":
                rawData = {
                    type: obj.name,
                    BrokerIdNum: refEditing.value,
                    OrderId: orderId
                };
                dispatch(updateLeftPanel(rawData, (result) => {
                    if (!result.isSuccess) {
                        handleApiError(this.props.dispatch, result.error);

                        this.setState({
                            refEditing: {
                                ...this.state.refEditing,
                                isEditing: true,
                                value: refEditing.value
                            }
                        });
                    } else {
                        this.setState({
                            refEditing: {
                                ...this.state.refEditing,
                                isEditing: false,
                                value: refEditing.value
                            }
                        }, () => { dispatch(showSuccess(`Saved successfully.`)); });
                    }
                }, (error) => {
                    handleApiError(this.props.dispatch, error);
                }));
                break;
        }
    }

    render() {
        const { coCustomer, customer, orderInfo } = this.props;
        const { dispatch, orderId, profile, roleType } = this.props;

        const { customerEditing, refEditing } = this.state;

        const hasCustomer = customer && (hasStringValue(customer.FirstName) || hasStringValue(customer.LastName));
        const hasCoCustomer = coCustomer && (hasStringValue(coCustomer.CoFirstName) || hasStringValue(customer.CoLastName));
        const referenceNumber = orderInfo ? orderInfo.referenceNumber : "";

        const renderLenderName = () => {
            if (!orderInfo) {
                return "";
            }

            let lenderName = `${orderInfo.brokerCompanyName || ""}`;

            if (hasStringValue(orderInfo.gid)) {
                lenderName = `${orderInfo.gidCompanyName || ""}/${lenderName}`;
            }

            return lenderName;
        };

        const renderEditCustomerButton = () => {
            if (orderInfo.progressId !== undefined) {
                if (ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closing Completed" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending QC Review" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending Review/PC Resolution") {
                    return "";
                }
            }
            return (
                <span className="cursor-pointer right order-edit" onClick={() => this.handleEditCustomer()} >
                    <i className="lnr lnr-pencil"></i>
                </span>
            );
        };

        const renderEditButton = (obj, editHanlder, isSwitch) => {
            const { isEditing, isSaving } = obj;
            if (orderInfo.progressId !== undefined) {
                if (ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closing Completed" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending QC Review" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending Review/PC Resolution") {
                    return "";
                }
            }

            if (isEditing) {
                if (isSwitch) {
                    return (
                        <div>
                            <button disabled={isSaving ? "disabled" : ""} className="btn btn-s-small success-color mr-1" onClick={() => this.handleSave(obj)}>
                                <span className="lnr lnr-checkmark-circle"></span>
                            </button>
                            <button disabled={isSaving ? "disabled" : ""} className="btn btn-s-small error-color mr-1" onClick={() => this.handleCancel(obj)}>
                                <span className="lnr lnr-cross-circle"></span>
                            </button>
                        </div>
                    );
                } else {
                    return (
                        <span className="cursor-pointer right order-edit" disabled><i className="lnr lnr-pencil"></i></span>
                    );
                }
            } else {
                return (
                    <span className="cursor-pointer right order-edit" onClick={(e) => editHanlder(e, obj)}>
                        <i className="lnr lnr-pencil"></i>
                    </span>
                );
            }
        };

        return (
            <div>
                <div className="panel-order-detail row box-shadow-st2 mt-1 pb-2">
                    {hasCustomer && <div>
                        <div className="col s12 mt-2 pos-rel">
                            <label>
                                <span className="small-heading">Signer</span>
                            </label>
                            <div className="right-abs-btn">
                                {renderEditCustomerButton(customerEditing)}
                            </div>
                        </div>
                        <div className="col s12 mt-1">
                            <span className="bold-title truncate" title={[customer.FirstName || "", customer.LastName || ""]}>{customer.FirstName || ""} {customer.LastName || ""}
                                <small className="prefix-sm-custom">{customer.Language || ""}</small>
                            </span>
                            {hasStringValue(customer.HomePhone) &&
                                <p className="font-weight-500">
                                    <i className="lnr lnr-phone-handset"></i> {convert2PhoneWithFormat(customer.HomePhone) || ""}
                                </p>
                            }
                            {hasStringValue(customer.WorkPhone) &&
                                <p className="font-weight-500">
                                    <i className="lnr lnr-smartphone"></i> {convert2PhoneWithFormat(customer.WorkPhone) || ""}
                                </p>
                            }
                            {hasStringValue(customer.Email) &&
                                <p className="font-weight-500 truncate" title={customer.Email || ""}>
                                    <a href={`mailTo:${customer.Email}`} target="_top" className="color-2"><i className="lnr lnr-envelope"></i> {customer.Email || ""}</a>
                                </p>
                            }
                        </div></div>}

                    {hasCoCustomer && <div className="col s12">
                        <span className="bold-title truncate mb-1" title={[coCustomer.CoFirstName || "", coCustomer.CoLastName || ""]}>{coCustomer.CoFirstName || ""}  {coCustomer.CoLastName || ""}
                            <small className="prefix-sm-custom">{coCustomer.CoLanguage || ""}</small>
                        </span>
                        {hasStringValue(coCustomer.CoHomePhone) &&
                            <p className="font-weight-500">
                                <i className="lnr lnr-phone-handset"></i> {convert2PhoneWithFormat(coCustomer.CoHomePhone) || ""}
                            </p>
                        }
                        {hasStringValue(coCustomer.CoWorkPhone) &&
                            <p className="font-weight-500">
                                <i className="lnr lnr-smartphone"></i> {convert2PhoneWithFormat(coCustomer.CoWorkPhone) || ""}
                            </p>
                        }
                        {hasStringValue(coCustomer.CoEmail) &&
                            <p className="font-weight-500 truncate" title={coCustomer.CoEmail || ""}>
                                <a href={`mailTo:${coCustomer.CoEmail}`} target="_top" className="color-2"><i className="lnr lnr-envelope"></i> {coCustomer.CoEmail || ""}</a>
                            </p>
                        }
                    </div>}

                    <div className="row col s12">
                        <div className="divider"></div>
                    </div>
                    <div className="col s6">{roleType !== "Staff" && <span className="font-11 left">Client/Branch</span>}</div>
                    <div className="col s6 right-align pos-rel" style={{ paddingRight: "35px" }}>
                        {!refEditing.isEditing &&
                            <span className="font-weight-500 font-11 truncate" title={referenceNumber || ""}>Ref # {referenceNumber || ""}</span>
                        }
                        {refEditing.isEditing &&
                            <input
                                type="text"
                                className="form-control" name="refNumber" id="refNumber"
                                onBlur={(e) => this.setState({
                                    refEditing: {
                                        ...this.state.refEditing,
                                        originValue: this.state.refEditing.value,
                                        value: e.target.value
                                    },
                                    requestedFee: e.target.value
                                })}
                                maxLength="50"
                                ref="refNumber" defaultValue={referenceNumber}
                            />
                        }
                        <div className="right-abs-btn">
                            {renderEditButton(refEditing, () => {
                                this.setState({
                                    refEditing: {
                                        ...this.state.refEditing,
                                        isEditing: true
                                    }
                                });
                            }, true)}
                        </div>
                    </div>

                    {roleType !== "Staff" && <div className="col s12 mt-1">
                        <span className="font-10 font-weight-500 truncate" title={renderLenderName()}>{renderLenderName()}</span>
                    </div>}
                </div>

                <Modal isOpen={customerEditing}>
                    <ModalBody>
                        <ModalTitle onClickClose={() => this.handleCancelEditCustomer()}>Edit Signer's information</ModalTitle>
                        <div className="col s12 p-0">
                            <CustomerInformationFilter
                                orderId={orderId}
                                ref={instance => { this.customerInformationFilter = instance; }}
                                dispatch={dispatch}
                                setDataToSendMail={data => this.setDataToSendMail(data)}
                                profile={profile}
                            />
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col m6">
                                <button type="button" className="btn w-100 white" onClick={() => this.handleCancelEditCustomer()}>Cancel</button>
                            </div>
                            <div className="col m6">
                                <button type="button" className="btn success-color w-100" onClick={() => this.handleSaveEditCustomer()} >Save</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
            </div>
        );
    }
}

LeftPanelCustomer.propTypes = {
    agents: PropTypes.array,
    owner: PropTypes.object,
    isFetching: PropTypes.bool,
    progressId: PropTypes.number,
    listProgresses: PropTypes.array,
    customer: PropTypes.object,
    coCustomer: PropTypes.object,
    orderInfo: PropTypes.object,
    dispatch: PropTypes.func,
    orderId: PropTypes.number,
    agentId: PropTypes.number,
    profile: PropTypes.object,
    roleType: PropTypes.string,
    // setDataToSendMail: PropTypes.func,
    accountId: PropTypes.number
};

const mapStateToProps = (state) => {
    const { clientOrderDetail, authentication } = state;
    const { leftPanel } = clientOrderDetail;
    const {
        coCustomer,
        customer,
        isFetching,
        orderInfo
    } = leftPanel;
    const { accountId, profile, role } = authentication;
    const { roleType } = role;

    return {
        coCustomer,
        customer,
        isFetching,
        orderInfo,
        profile,
        roleType,
        accountId
    };
};

export default connect(mapStateToProps)(LeftPanelCustomer);