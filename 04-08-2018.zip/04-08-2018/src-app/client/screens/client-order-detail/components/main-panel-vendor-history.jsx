import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Component } from "react";
import GridView from "GridView";
import CommonModal from "CommonModal";
import { getVendorHistory } from "../actions/main-panel-actions";
import { listenHaveNewActivity, stopListenHaveNewActivity } from "../../../socket/orders";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class VendorHistory extends Component {
    constructor(props) {
        super(props);
        this.state = {
            gridCriteria: {
                sortColumn: "HistoryDate",
                sortDirection: false,
                page: 1,
                itemPerPage: 25
            }
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentDidMount() {
        const { gridCriteria } = this.state;
        const { dispatch, orderId } = this.props;
        dispatch(getVendorHistory(gridCriteria, orderId));

        listenHaveNewActivity(() => {
            dispatch(getVendorHistory(gridCriteria, orderId));
        });

    }

    componentWillUnmount() {
        stopListenHaveNewActivity();
    }

    handleGridViewReload(criteria) {

        this.setState({ gridCriteria: criteria });

        const { dispatch, orderId } = this.props;

        dispatch(getVendorHistory(criteria, orderId));

    }

    render() {

        const { columns, listDataVendorHistory, totalRecords } = this.props;
        const { gridCriteria } = this.state;

        return (
            <div>
                <GridView
                    criteria={gridCriteria}
                    totalRecords={totalRecords}
                    datasources={listDataVendorHistory}
                    defaultSortColumn={"HistoryDate"}
                    columns={columns}
                    onGridViewReload={this.handleGridViewReload.bind(this)} //Paginate changed => need reload datasource base on criteria
                />
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

VendorHistory.defaultProps = {
    columns: [
        {
            title: "Date",
            data: "HistoryDate",
            type: "datetime"
        },
        {
            title: "Vendor ID",
            data: "SignerId"
        },
        {
            title: "Vendor Name",
            data: "SignerName",
            type: "vendorLink"
        },
        {
            title: "Status",
            data: "Status"
        }
    ]
};

VendorHistory.propTypes = {
    dispatch: PropTypes.func,
    columns: PropTypes.array,
    listDataVendorHistory: PropTypes.array,
    totalRecords: PropTypes.number,
    orderId: PropTypes.number
};

const mapStateToProps = (state) => {
    const { vendorHistoryReducer } = state;
    const { listDataVendorHistory, needReload, totalRecords } = vendorHistoryReducer;

    return {
        listDataVendorHistory,
        needReload,
        totalRecords
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(VendorHistory);