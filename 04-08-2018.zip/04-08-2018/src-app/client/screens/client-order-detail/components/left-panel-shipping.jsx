import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";
import Select from "Select";

import { handleApiError } from "ErrorHandler";
import { ORDER_DETAIL_PROGRESS } from "../../../constant/order-detail-constants";
import { getOrderDetailLeftPanelShippingInitData, updateLeftPanel, doneGetOrderDetailLeftPanelShippingInitData } from "../actions/left-panel-actions";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class LeftPanelShipping extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isShowModal: false,
            courierEditing: {
                isSaving: false,
                isEditing: false,
                value: "",
                name: "courier"
            },
            CourierAcntNumber: {
                isEditing: false,
                value: "",
                name: "CourierAcntNumber"
            },
            TrackingNumber: {
                isEditing: false,
                value: "",
                name: "TrackingNumber"
            },
            TrackingNumber2: {
                isEditing: false,
                value: "",
                name: "TrackingNumber2"
            }
        };
    }

    componentDidMount() {
        const { dispatch, orderId } = this.props;
        dispatch(getOrderDetailLeftPanelShippingInitData(orderId));
    }

    defaultCourier(listCouriers) {
        const def = listCouriers.length > 0 ? listCouriers[0].CourierID : "";
        return def;
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            courierEditing: {
                ...this.state.courierEditing,
                value: (nextProps.shipping.CourierID !== null && nextProps.shipping.CourierID !== undefined) ? nextProps.shipping.CourierID : this.defaultCourier(nextProps.listCouriers)
            }
        });
    }

    handleEditCourier() {
        this.setState({
            isShowModal: true
        });
    }

    handleCourierChange(value) {
        this.setState({
            courierEditing: {
                ...this.state.courierEditing,
                value
            }
        });
    }

    handleCourierSave() {
        this.setState({
            orderInfo: {
                ...this.state.orderInfo,
                courierId: this.state.courierIdSelect
            },
            isShowModal: false
        });
    }

    handleCloseModal() {
        this.setState({
            isShowModal: false
        });
    }

    handleEdit(value) {
        switch (value) {
            case "courierAccountNuber":
                this.setState({
                    courierAccountNumberEdit: true
                });
                break;
        }
    }

    handleCancelEdit(value) {
        switch (value) {
            case "courierAccountNuber":
                this.setState({
                    orderInfo: {
                        ...this.state.orderInfo,
                        courierAccountNuber: "cancel"
                    },
                    courierAccountNumberEdit: false
                });
                break;
        }

        this.setState({
            orderInfo: {
                ...this.state.orderInfo,
                courierAccountNuber: "cancel"
            },
            courierAccountNumberEdit: false
        });
    }

    handleOnChangeEdit(name, value) {
        this.setState({
            orderInfo: {
                ...this.state.orderInfo,
                [name]: value
            }
        });
    }

    handleSaveEdit(value) {
        switch (value) {
            case "courierAccountNuber":
                this.setState({
                    orderInfo: {
                        ...this.state.orderInfo,
                        courierAccountNuber: this.refs.courierAccountNuber.value
                    }
                });
                break;
        }
    }

    handleSave(obj) {
        const { dispatch, orderId, shipping, listCouriers } = this.props;
        const { courierEditing, CourierAcntNumber, TrackingNumber, TrackingNumber2 } = this.state;
        const rawData = {
            type: obj.name,
            OrderId: orderId
        };
        switch (obj.name) {
            case "courier":
                rawData.CourierID = obj.value;
                dispatch(updateLeftPanel(rawData, () => {
                    this.setState({
                        courierEditing: {
                            ...courierEditing,
                            isEditing: false,
                            value: obj.value
                        },
                        isShowModal: false
                    });
                    dispatch(doneGetOrderDetailLeftPanelShippingInitData({ shipping: { ...shipping, CourierID: parseInt(obj.value) }, listCouriers }));
                }, (error) => {
                    handleApiError(this.props.dispatch, error);
                }));
                break;
            case "CourierAcntNumber":
                rawData.CourierAcntNumber = obj.value;
                dispatch(updateLeftPanel(rawData, () => {
                    this.setState({
                        CourierAcntNumber: {
                            ...CourierAcntNumber,
                            isEditing: false,
                            value: obj.value
                        },
                        isShowModal: false
                    });
                    dispatch(doneGetOrderDetailLeftPanelShippingInitData({ shipping: { ...shipping, CourierAcntNumber: obj.value }, listCouriers }));
                }, (error) => {
                    handleApiError(this.props.dispatch, error);
                }));
                break;
            case "TrackingNumber":
                rawData.TrackingNumber = obj.value;
                dispatch(updateLeftPanel(rawData, () => {
                    this.setState({
                        TrackingNumber: {
                            ...TrackingNumber,
                            isEditing: false,
                            value: obj.value
                        },
                        isShowModal: false
                    });
                    dispatch(doneGetOrderDetailLeftPanelShippingInitData({ shipping: { ...shipping, TrackingNumber: obj.value }, listCouriers }));
                }, (error) => {
                    handleApiError(this.props.dispatch, error);
                }));
                break;
            case "TrackingNumber2":
                rawData.TrackingNumber2 = obj.value;
                dispatch(updateLeftPanel(rawData, () => {
                    this.setState({
                        TrackingNumber2: {
                            ...TrackingNumber2,
                            isEditing: false,
                            value: obj.value
                        },
                        isShowModal: false
                    });
                    dispatch(doneGetOrderDetailLeftPanelShippingInitData({ shipping: { ...shipping, TrackingNumber2: obj.value }, listCouriers }));
                }, (error) => {
                    handleApiError(this.props.dispatch, error);
                }));
                break;
        }
    }

    handleCancel(obj) {
        switch (obj.name) {
            case "courier":
                this.setState({
                    courierEditing: {
                        ...this.state.courierEditing,
                        isEditing: false,
                        value: ""
                    }
                });
                break;
            case "CourierAcntNumber":
                this.setState({
                    CourierAcntNumber: {
                        ...this.state.CourierAcntNumber,
                        isEditing: false,
                        value: ""
                    }
                });
                break;
            case "TrackingNumber":
                this.setState({
                    TrackingNumber: {
                        ...this.state.TrackingNumber,
                        isEditing: false,
                        value: ""
                    }
                });
                break;
            case "TrackingNumber2":
                this.setState({
                    TrackingNumber2: {
                        ...this.state.TrackingNumber2,
                        isEditing: false,
                        value: ""
                    }
                });
                break;
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {
        const { shipping, listCouriers, orderInfo } = this.props;
        const { courierEditing, CourierAcntNumber, TrackingNumber, TrackingNumber2 } = this.state;

        let currentCourier;
        if (shipping.CourierID !== undefined && shipping.CourierID !== null && shipping.CourierID !== "" && listCouriers.length > 0) {
            listCouriers.forEach(item => {
                if (shipping.CourierID === item.CourierID) {
                    currentCourier = item;
                }
            });
        }

        const renderEditButton = (obj, editHanlder, isSwitch) => {
            const { isEditing, isSaving } = obj;
            if (orderInfo.progressId !== undefined) {
                if (ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closing Completed" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending QC Review" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending Review/PC Resolution") {
                    return "";
                }
            }

            if (isEditing) {
                if (isSwitch) {
                    return (
                        <div>
                            <button disabled={isSaving ? "disabled" : ""} className="btn btn-s-small success-color mr-1" onClick={() => this.handleSave(obj)}>
                                <span className="lnr lnr-checkmark-circle"></span>
                            </button>
                            <button disabled={isSaving ? "disabled" : ""} className="btn btn-s-small error-color mr-1" onClick={() => this.handleCancel(obj)}>
                                <span className="lnr lnr-cross-circle"></span>
                            </button>
                        </div>
                    );
                } else {
                    return (
                        <span className="cursor-pointer right order-edit" disabled><i className="lnr lnr-pencil"></i></span>
                    );
                }
            } else {
                return (
                    <span className="cursor-pointer right order-edit" onClick={(e) => editHanlder(e, obj)}>
                        <i className="lnr lnr-pencil"></i>
                    </span>
                );
            }
        };

        const renderTracking = (courier, trNumber) => {
            let link = "";
            if (trNumber === null || trNumber === undefined) return "---";

            if (courier !== null && courier !== undefined) {
                switch (courier.Courier) {
                    case "FedEx":
                        link = `https://www.fedex.com/apps/fedextrack/?action=track&tracknumbers=${trNumber}`;
                        break;
                    case "UPS":
                        link = `https://wwwapps.ups.com/tracking/tracking.cgi?tracknum=${trNumber}`;
                        break;
                }
            }
            return (link !== "") ? (
                <strong>
                    <a href={link} target="_blank" >{trNumber}</a>
                </strong>
            ) : `${trNumber}`;
        };

        const renderEditCourierButton = () => {
            if (orderInfo.progressId !== undefined) {
                if (ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closing Completed" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending QC Review" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending Review/PC Resolution") {
                    return "";
                }
            }
            return (
                <div className="col m2">
                    <a className="right order-edit" onClick={() => this.handleEditCourier()}>
                        <i className="lnr lnr-pencil"></i>
                    </a>
                </div>
            );
        };

        return (
            <div>
                <div className="row mt-1">
                    <div className="col m5 left-align">
                        <span className="left">Courier</span>
                    </div>
                    <div className="col m5">
                        <span className="left"><strong>{currentCourier ? currentCourier.Courier : "---"}</strong></span>
                    </div>
                    {renderEditCourierButton()}
                </div>
                <div className="clear"></div>

                <div className="row">
                    <div className="col m5 left-align">
                        <span className="left">Account Number</span>
                    </div>
                    <div className="col m5">
                        {!CourierAcntNumber.isEditing &&
                            <span className="truncate"><strong>{(shipping.CourierAcntNumber) ? shipping.CourierAcntNumber : "---"}</strong></span>
                        }
                        {CourierAcntNumber.isEditing &&
                            <input
                                type="text"
                                className="form-control" name="CourierAcntNumber" id="CourierAcntNumber"
                                onBlur={(e) => this.setState({
                                    CourierAcntNumber: {
                                        ...this.state.CourierAcntNumber,
                                        originValue: this.state.CourierAcntNumber.value,
                                        value: e.target.value
                                    }
                                })}
                                maxLength="30"
                                ref="refNumber" defaultValue={shipping.CourierAcntNumber}
                            />
                        }
                        {/* {this.state.courierAccountNumberEdit ? <span className="left"><input type="text" ref="courierAccountNumber" onChange={(event) => this.handleOnChangeEdit("courierAccountNumber", event.target.value)} value={shipping.CourierAcntNumber || ""} /></span> : <span className="left"><strong>{shipping.CourierAcntNumber || "283742837"}</strong></span>} */}
                    </div>
                    <div className="col m2">
                        {renderEditButton(CourierAcntNumber, () => {
                            this.setState({
                                CourierAcntNumber: {
                                    ...CourierAcntNumber,
                                    isEditing: true
                                }
                            });
                        }, true)}
                    </div>
                </div>
                <div className="clear"></div>

                <div className="row">
                    <div className="col m5 left-align">
                        <span className="left">Tracking #</span>
                    </div>
                    <div className="col m5">
                        {!TrackingNumber.isEditing &&
                            <span className="primary-color truncate"><strong>{renderTracking(currentCourier, shipping.TrackingNumber)}</strong></span>
                        }
                        {TrackingNumber.isEditing &&
                            <input
                                type="text"
                                className="form-control" name="TrackingNumber" id="TrackingNumber"
                                onBlur={(e) => this.setState({
                                    TrackingNumber: {
                                        ...this.state.TrackingNumber,
                                        originValue: this.state.TrackingNumber.value,
                                        value: e.target.value
                                    }
                                })}
                                maxLength="50"
                                ref="refNumber" defaultValue={shipping.TrackingNumber}
                            />
                        }
                    </div>
                    <div className="col m2">{(currentCourier) &&
                        renderEditButton(TrackingNumber, () => {
                            this.setState({
                                TrackingNumber: {
                                    ...TrackingNumber,
                                    isEditing: true
                                }
                            });
                        }, true)}
                    </div>
                </div>
                <div className="clear"></div>

                <div className="row">
                    <div className="col m5 left-align">
                        <span className="left">Additional Tracking #</span>
                    </div>
                    <div className="col m5">
                        {!TrackingNumber2.isEditing &&
                            <span className="primary-color truncate">{renderTracking(currentCourier, shipping.TrackingNumber2)}</span>
                        }
                        {TrackingNumber2.isEditing &&
                            <input
                                type="text"
                                className="form-control" name="TrackingNumber2" id="TrackingNumber2"
                                onBlur={(e) => this.setState({
                                    TrackingNumber2: {
                                        ...this.state.TrackingNumber2,
                                        originValue: this.state.TrackingNumber2.value,
                                        value: e.target.value
                                    }
                                })}
                                maxLength="50"
                                ref="refNumber" defaultValue={shipping.TrackingNumber2}
                            />
                        }
                    </div>
                    <div className="col m2">{(currentCourier) &&
                        renderEditButton(TrackingNumber2, () => {
                            this.setState({
                                TrackingNumber2: {
                                    ...TrackingNumber2,
                                    isEditing: true
                                }
                            });
                        }, true)}
                    </div>
                </div>

                <Modal isOpen={this.state.isShowModal} fixedFooter={false} addClass="modal-small">
                    <ModalBody>
                        <ModalTitle onClickClose={() => { this.handleCloseModal(); }}>Select Courier</ModalTitle>
                        <div className="col s12 p-0">
                            <div className="card box-shadow-none">
                                <div className="card-content p-0">
                                    <div className="row">
                                        <div className="col s12">
                                            <Select
                                                dataSource={listCouriers}
                                                mapDataToRenderOptions={{ value: "CourierID", label: "Courier" }}
                                                value={(shipping.CourierID !== null && shipping.CourierID !== undefined) ? shipping.CourierID : ""}
                                                onChange={(value) => this.handleCourierChange(value)}
                                                id="courierId"
                                                ref="courierId"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col m6">
                                <button className="btn white w-100" onClick={() => this.handleCloseModal()}>Cancel</button>
                            </div>
                            <div className="col m6">
                                <button className="btn success-color w-100" onClick={() => this.handleSave(courierEditing)}>Save</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
            </div>
        );
    }
}

LeftPanelShipping.propTypes = {
    dispatch: PropTypes.func,
    orderId: PropTypes.number,
    orderInfo: PropTypes.object,
    isFetching: PropTypes.bool,
    shipping: PropTypes.object,
    listCouriers: PropTypes.array
};

const mapStateToProps = (state) => {
    const { clientOrderDetail } = state;
    const { leftPanelShipping, leftPanel } = clientOrderDetail;
    const { isFetching, shipping, listCouriers } = leftPanelShipping;
    const { orderInfo } = leftPanel;

    return { isFetching, shipping, listCouriers, orderInfo };
};

export default connect(mapStateToProps)(LeftPanelShipping);