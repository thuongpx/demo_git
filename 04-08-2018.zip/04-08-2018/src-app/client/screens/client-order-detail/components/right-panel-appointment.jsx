import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { getAppointment, updateAppointment } from "../actions/right-panel-appointment-action";
import { handleApiError } from "ErrorHandler";
// import Select from "Select";
import moment from "moment";
import DatePicker from "./../../../features/form/date-picker";
import TimePicker from "../../../features/form/time-picker";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "../../../features/modal";
import CommonModal from "../../../features/common-modal/common-modal";
import { requireMessage } from "Helpers/validation-helper";
import { LIST_TIMEZONE_US } from "../../../constant/constants";
import { ACTION } from "../../../constant/progress-log-constants";
import { ORDER_DETAIL_PROGRESS } from "../../../constant/order-detail-constants";
import { showSuccess } from "../../main-layout/actions";
import { apiAddNewOrderProgress } from "Api/order-progress-api";
import { getOrderDetailLeftPanelInitData } from "../actions/left-panel-actions";
import { hasStringValue, displayIntervalTime } from "../../../helpers/common-helper";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import RightPanelAppointmentLocationModal from "./right-panel-appointment-location-modal";

class RightPanelAppointment extends Component {
    constructor(props) {
        super(props);
        this.state = {
            // isShowModal: false,
            inputs: {
                isVenOrCEDefineADT: false,
                aptDate: "",
                aptTime: ""
            },
            invalidField: {},
            Appointment: {
                // isVenOrCEDefineADT: false,
                isEditing: false,
                value: "",
                name: "Appointment"
            },
            SigningLocation: {
                isEditing: false,
                value: "",
                name: "SigningLocation"
            }
        };
    }

    componentDidMount() {
        const { dispatch, orderId } = this.props;

        dispatch(getAppointment(orderId));
    }

    componentWillUpdate(nextProps) {
        if (nextProps.data !== this.props.data) {
            const { data } = nextProps;
            this.setState({
                inputs: {
                    isVenOrCEDefineADT: data.IsVenOrCEDefineADT,
                    aptDate: data.aptDateTime !== null ? moment(data.aptDateTime).utc().format("MM/DD/YYYY") : "",
                    aptTime: data.aptDateTime !== null ? moment(data.aptDateTime).utc().format("h:mm:ss A") : ""
                }
            });
        }
    }


    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    handleSave(obj) {
        const { dispatch, orderId, userName, accountId, roleType } = this.props;
        const { inputs, Appointment } = this.state;
        let rawData = {
            type: obj.name,
            OrderId: orderId
        };
        let validData = true;
        switch (obj.name) {
            case "Appointment":
                validData = this.validateForm();
                // check = Object.keys(invalidField)[0];
                if (validData) {
                    rawData = { ...rawData, ...inputs, isVenOrCEDefineADT: false };
                    if (!hasStringValue(inputs.aptDate) || inputs.aptDate === "Invalid date") rawData = { ...rawData, aptDate: null };
                    if (!hasStringValue(inputs.aptTime) || inputs.aptTime === "Invalid date") rawData = { ...rawData, aptTime: null };

                    dispatch(updateAppointment(rawData, () => {
                        this.setState({
                            Appointment: {
                                ...Appointment,
                                isEditing: false
                            },
                            isShowModal: false
                        });
                        dispatch(getAppointment(orderId));
                        const log = {
                            OrderId: orderId,
                            Activity: `${userName} updated the appointment`,
                            UsersId: accountId,
                            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                            ProgressType: ACTION
                        };
                        //add activity log
                        apiAddNewOrderProgress(log,
                            () => {
                                dispatch(showSuccess(`${userName} updated the appointment.`));
                            }, (error) => handleApiError(dispatch, error)
                        );
                        dispatch(getOrderDetailLeftPanelInitData({ orderId, portal: roleType }));
                    }, (error) => {
                        handleApiError(this.props.dispatch, error);
                    }));
                }
                break;
        }
    }

    handleCancel(obj) {
        switch (obj.name) {
            case "Appointment":
                this.setState({
                    Appointment: {
                        ...this.state.Appointment,
                        isEditing: false,
                        value: ""
                    }
                });
                break;
            case "SigningLocation":
                this.setState({
                    SigningLocation: {
                        ...this.state.SigningLocation,
                        isEditing: false,
                        value: ""
                    }
                });
                break;
        }
    }
    validateForm() {
        const { inputs } = this.state;
        const invalidField = {};

        if (!inputs.isVenOrCEDefineADT) {
            if (!hasStringValue(inputs.aptDate) || inputs.aptDate === "Invalid date") invalidField.aptDate = true;
            if (!hasStringValue(inputs.aptTime) || inputs.aptTime === "Invalid date") invalidField.aptTime = true;
            this.handleOnBlurDateAndTime(inputs.aptDate, "aptDate");
            if (this.state.invalidField.aptDateData) invalidField.aptDateData = true;
            this.handleOnBlurDateAndTime(inputs.aptTime, "aptTime");
            if (this.state.invalidField.aptTimeData) invalidField.aptTimeData = true;
        }
        const check = Object.keys(invalidField)[0];
        if (check) {
            if (check === "aptDateData" || check === "aptTimeData") {
                $(`#client-place-order-${check.replace("Data", "")}-value`).focus();
            } else {
                $(`#client-place-order-${(check === "aptDate" || check === "aptTime") ? `${check}-value` : check.replace("Data", "")}`).focus();
            }
            return false;
        } else {
            return true;
        }
    }
    handleOnBlurDateAndTime(value, fieldName) {
        const { invalidField, inputs } = this.state;
        const currentDate = moment().format("MM/DD/YYYY").toString();
        const currentTime = moment().format("h:mm:ss A").toString();

        if (value === "" || value === "Invalid date") {
            invalidField[fieldName] = true;
        } else {
            invalidField[fieldName] = false;
        }

        if (fieldName === "aptDate") {
            if (moment(value) < moment(currentDate)) {
                invalidField.aptDateData = true;
                invalidField.aptTimeData = false;
            } else if (value === currentDate && this.state.inputs.aptTime !== "" && moment(`${value} ${this.state.inputs.aptTime}`) < moment(`${value} ${currentTime}`)) {
                invalidField.aptDateData = false;
                invalidField.aptTimeData = true;
            } else {
                invalidField.aptDateData = false;
                invalidField.aptTimeData = false;
            }
        }

        if (fieldName === "aptTime" && this.state.inputs.aptDate !== "" && this.state.inputs.aptTime !== "") {
            if (this.state.inputs.aptDate === currentDate && moment(`${currentDate} ${value}`) < moment(`${currentDate} ${currentTime}`)) {
                invalidField.aptTimeData = true;
            } else {
                invalidField.aptTimeData = false;
            }
        }

        inputs[fieldName] = value;

        this.setState({ invalidField, inputs });
    }

    handleOnchangeField(value, fieldName) {
        const { inputs, invalidField } = this.state;

        inputs[fieldName] = value;

        if (fieldName === "isVenOrCEDefineADT") {
            inputs.aptDate = "";
            inputs.aptTime = "";
            inputs.timezone = "";
            setTimeout(() => {
                $(`#isVenOrCEDefineADT`).focus();
                $(`#isVenOrCEDefineADT`).attr("class", "tabbed");
            }, 200);
        }
        this.setState({ inputs, invalidField });
        // this.props.getDirty(this.getDirty());
    }

    handleEditSigningLocation() {
        this.SigningLocation.orderDetail = this.props.data;
        this.setState({
            SigningLocation: {
                ...this.state.SigningLocation,
                isEditing: true
            }
        });
    }
    handleCancelEditSigningLocation() {
        this.SigningLocation.handleCancle();
        this.setState({
            SigningLocation: {
                ...this.state.SigningLocation,
                isEditing: false
            }
        });
        this.componentDidMount();
    }

    handleSaveEditSigningLocation() {
        this.SigningLocation.saveChanges(false, () => {
            this.setState({
                SigningLocation: {
                    ...this.state.SigningLocation,
                    isEditing: false
                }
            });
            this.componentDidMount();
        });
    }

    render() {
        const { data, orderId, orderInfo, dispatch } = this.props;
        const {
            timezone, aptDateTime, address, suite, city, state, zip, utcAptDateTime,
            propCity, propAddress, propSuite, propState, propZip
        } = data;
        const { Appointment, SigningLocation, inputs, invalidField } = this.state;

        const timeZoneAbv = LIST_TIMEZONE_US.map((item, index) => {
            if (timezone && item.UTC === timezone.toString()) {
                return (
                    <span key={index}>{item.abv}</span>
                );
            }
            return (
                <span key={index}></span>
            );
        });

        const date = moment(aptDateTime).utc();
        const dateString = `${date.isValid() ? `${date.format("MMM D YYYY, h:mm A")}` : ""}`;
        // Appointment.isVenOrCEDefineADT = !hasStringValue(dateString);

        const renderPropertyAddress = () => {
            const propCityStateZip = () => {
                if (hasStringValue(propCity) && (hasStringValue(propState) || hasStringValue(propZip))) {
                    return (
                        <span style={{ fontSize: "10pt", fontWeight: 600 }}>{hasStringValue(propCity) ? propCity : ""}, {hasStringValue(propState) ? propState : ""} {hasStringValue(propZip) ? propZip : ""}</span>
                    );
                }

                if (hasStringValue(propCity)) {
                    return (
                        <span style={{ fontSize: "10pt", fontWeight: 600 }}>{hasStringValue(propCity) ? propCity : ""}</span>
                    );
                }

                if (hasStringValue(propState) || hasStringValue(propZip)) {
                    return (
                        <span style={{ fontSize: "10pt", fontWeight: 600 }}>{hasStringValue(propState) ? propState : ""} {hasStringValue(propZip) ? propZip : ""}</span>
                    );
                }

                return "";
            };

            if (!hasStringValue(propAddress) &&
                !hasStringValue(propSuite) &&
                !hasStringValue(propCity) &&
                !hasStringValue(propState) &&
                !hasStringValue(propZip)) return "";

            return (
                <div>
                    <div className="col s12"><div className="divider mb-1"></div></div>
                    <div className="col s12"><span style={{ color: "#808181", fontSize: "11pt", fontWeight: 500 }}>Property address</span></div>
                    <div className="col s12"><span style={{ fontSize: "10pt", fontWeight: 600 }} className="truncate" title={hasStringValue(propAddress) ? propAddress : ""}>{hasStringValue(propAddress) ? propAddress : ""}</span></div>
                    <div className="col s12"><span style={{ fontSize: "10pt", fontWeight: 600 }} className="truncate" title={hasStringValue(propSuite) ? propSuite : ""}>{hasStringValue(propSuite) ? propSuite : ""}</span></div>
                    <div className="col s12"><span style={{ fontSize: "10pt", fontWeight: 600 }} className="truncate" title={propCityStateZip()}>{propCityStateZip()}</span></div>
                </div>
            );
        };

        const renderEditSigningLocationButton = () => {
            if (orderInfo.progressId !== undefined) {
                if (ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closing Completed" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending QC Review" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending Review/PC Resolution") {
                    return "";
                }
            }
            return (
                <span className="cursor-pointer right order-edit" onClick={() => this.handleEditSigningLocation()} >
                    <i className="lnr lnr-pencil"></i>
                </span>
            );
        };

        const renderEditButton = (obj, editHanlder, isSwitch) => {
            const { isEditing, isSaving } = obj;
            if (orderInfo.progressId !== undefined) {
                if (ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closing Completed" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending QC Review" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending Review/PC Resolution") {
                    return "";
                }
            }

            if (isEditing) {
                if (isSwitch) {
                    return (
                        <div>
                            <button disabled={isSaving ? "disabled" : ""} className="btn btn-s-small success-color mr-1" onClick={() => this.handleSave(obj)}>
                                <span className="lnr lnr-checkmark-circle"></span>
                            </button>
                            <button disabled={isSaving ? "disabled" : ""} className="btn btn-s-small error-color mr-1" onClick={() => this.handleCancel(obj)}>
                                <span className="lnr lnr-cross-circle"></span>
                            </button>
                        </div>
                    );
                } else {
                    return (
                        <span className="cursor-pointer right order-edit" disabled><i className="lnr lnr-pencil"></i></span>
                    );
                }
            } else {
                return (
                    <span className="cursor-pointer right order-edit" onClick={(e) => editHanlder(e, obj)}>
                        <i className="lnr lnr-pencil"></i>
                    </span>
                );
            }
        };
        const checkDateAppointment = () => {

            return (
                <div>
                    <div className="col s12"><span style={{ color: "#808181", fontSize: "11pt", fontWeight: 500 }}>Appointment</span></div>
                    <div className="col s12 mb-1">
                        {(!Appointment.isEditing && hasStringValue(dateString)) &&
                            <span style={{ fontSize: "13pt", fontWeight: 300, float: "left", maxWidth: "79%" }}>{dateString} {timeZoneAbv}</span>
                        }
                        {(!Appointment.isEditing && !hasStringValue(dateString)) &&
                            <span style={{ fontSize: "13pt", fontWeight: 300, float: "left", maxWidth: "79%" }}>TCE/Vendor to determine</span>
                        }
                        {Appointment.isEditing &&
                            <div>
                                <div className="row">
                                    <div className="col s12">
                                        <div className="mt-1" style={{ marginLeft: "10px" }}>
                                            <label>
                                                <input
                                                    type="checkbox"
                                                    id="isVenOrCEDefineADT"
                                                    checked={inputs.isVenOrCEDefineADT}
                                                    onChange={e => this.handleOnchangeField(e.target.checked, "isVenOrCEDefineADT")}
                                                />
                                                <span>Vendor/ TCE to determine</span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                {!inputs.isVenOrCEDefineADT &&
                                    <div className="row">
                                        <div className={`col s6 m6 required ${invalidField.aptDate ? "required-field" : ""} ${invalidField.aptDateData ? "has-error" : ""}`}>
                                            <DatePicker
                                                onBlur={e => this.handleOnBlurDateAndTime(moment(e).format("MM/DD/YYYY").toString(), "aptDate")}
                                                defaultValue={inputs.aptDate}
                                                placeholder="Select Date"
                                                id="client-edit-order-aptDate"
                                                isRequiredField
                                                requiredMessage={invalidField.aptDateData ? requireMessage("Appointment Date") : ""}
                                                invalidMessage={invalidField.aptDateData ? "Appointment Date should not be in the past." : ""}
                                            />
                                        </div>

                                        <div className={`col s6 m6 required ${invalidField.aptTime ? "required-field" : ""} ${invalidField.aptTimeData ? "has-error" : ""}`}>
                                            <TimePicker
                                                defaultValue={inputs.aptTime}
                                                onBlur={e => this.handleOnBlurDateAndTime(moment(e ? `01/01/2000 ${e}` : "").format("h:mm:ss A").toString(), "aptTime")}
                                                placeholder="At Time"
                                                id="client-edit-order-aptTime"
                                                isRequiredField
                                                requiredMessage={invalidField.aptTimeData ? requireMessage("Appointment Time") : ""}
                                                invalidMessage={invalidField.aptTimeData ? "Appointment Time should not be in the past." : ""}
                                            />
                                        </div>
                                    </div>
                                }
                            </div>
                        }
                        {renderEditButton(Appointment, () => {
                            this.setState({
                                Appointment: {
                                    ...Appointment,
                                    isEditing: true
                                }
                            });
                        }, true)}
                    </div>
                    {/* <div className="col s1">

                    </div> */}
                    <div className="col s12"><span style={{ fontSize: "10pt", fontWeight: 600 }}>{displayIntervalTime(utcAptDateTime || "", timezone)}</span></div>
                </div >
            );
        };

        const renderSigningLocation = () => {
            const signingCityStateZip = () => {
                if (hasStringValue(city) && (hasStringValue(state) || hasStringValue(zip))) {
                    return (
                        <span style={{ fontSize: "10pt", fontWeight: 600 }}>{hasStringValue(city) ? city : ""}, {hasStringValue(state) ? state : ""} {hasStringValue(zip) ? zip : ""}</span>
                    );
                }

                if (hasStringValue(city)) {
                    return (
                        <span style={{ fontSize: "10pt", fontWeight: 600 }}>{hasStringValue(city) ? city : ""}</span>
                    );
                }

                if (hasStringValue(state) || hasStringValue(zip)) {
                    return (
                        <span style={{ fontSize: "10pt", fontWeight: 600 }}>{hasStringValue(state) ? state : ""} {hasStringValue(zip) ? zip : ""}</span>
                    );
                }

                return "";
            };

            if (!hasStringValue(address) &&
                !hasStringValue(suite) &&
                !hasStringValue(city) &&
                !hasStringValue(state) &&
                !hasStringValue(zip)) return "";

            return (
                <div>
                    <div className="col s12"><div className="divider mb-1"></div></div>
                    <div className="col s12"><span style={{ color: "#808181", fontSize: "11pt", fontWeight: 500, float: "left", maxWidth: "79%" }}>Signing Location</span> {renderEditSigningLocationButton()}</div>
                    {/* <div className="col s1"></div> */}
                    <div className="col s12"><span style={{ fontSize: "10pt", fontWeight: 600 }} className="truncate" title={hasStringValue(address) ? address : ""}>{hasStringValue(address) ? address : ""}</span></div>
                    <div className="col s12"><span style={{ fontSize: "10pt", fontWeight: 600 }} className="truncate" title={hasStringValue(suite) ? suite : ""}>{hasStringValue(suite) ? suite : ""}</span></div>
                    <div className="col s12"><span style={{ fontSize: "10pt", fontWeight: 600 }} className="truncate" title={signingCityStateZip()}>{signingCityStateZip()}</span></div>
                </div>
            );
        };

        return (
            <div className="tab-wrap st2 panel-order-detail row box-shadow-st2 p-1 mt-0">

                {checkDateAppointment()}

                <div className="clear"></div>

                {renderSigningLocation()}

                {renderPropertyAddress()}

                <div className="clear"></div>

                <Modal isOpen={SigningLocation.isEditing}>
                    <ModalBody>
                        <ModalTitle onClickClose={() => this.handleCancelEditSigningLocation()}>Edit Signing Location</ModalTitle>
                        <div className="col s12 p-0">
                            <RightPanelAppointmentLocationModal
                                orderDetail={data} orderId={orderId}
                                showConfirmModal={(mess, cbYes, cbNo, isJsx) => this.commonModal.showModal(mess, cbYes, cbNo, isJsx)}
                                ref={instance => { this.SigningLocation = instance; }}
                                dispatch={(action) => dispatch(action)}
                            />
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col m6">
                                <button type="button" className="btn w-100 white" onClick={() => this.handleCancelEditSigningLocation()}>Cancel</button>
                            </div>
                            <div className="col m6">
                                <button type="button" className="btn success-color w-100" onClick={() => this.handleSaveEditSigningLocation()} >Save</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>

                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

RightPanelAppointment.propTypes = {
    dispatch: PropTypes.func,
    data: PropTypes.object,
    orderId: PropTypes.number,
    orderInfo: PropTypes.object,
    profile: PropTypes.object,
    accountId: PropTypes.number,
    roleType: PropTypes.string,
    userName: PropTypes.string
};

const mapStateToProps = (state) => {
    const { clientOrderDetail, authentication } = state;
    const { accountId, profile, role } = authentication;
    const { rightPanelAppointment, leftPanel } = clientOrderDetail;
    const { data } = rightPanelAppointment;
    const { userName } = profile;
    const { orderInfo } = leftPanel;
    const { roleType } = role;

    return {
        data,
        profile,
        userName,
        orderInfo,
        accountId,
        roleType
    };
};

export default connect(mapStateToProps)(RightPanelAppointment);