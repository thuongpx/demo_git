import React from "react";
import { connect } from "react-redux";
import { Component } from "react";
import PropTypes from "prop-types";
import moment from "moment";

import { COMMENT_TYPE } from "Constants";
import noAvatarImg from "./../../../public/images/no-avatar.png";
import { getNotesData, saveNote } from "../actions/main-panel-add-note-actions";
import { handleApiError } from "ErrorHandler";
import { apiAddNewOrderProgress } from "../../../api/order-progress-api";
import { ACTION } from "../../../constant/progress-log-constants";
import { getOrderDetailLeftPanelInitData } from "../actions/left-panel-actions";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { listenHaveNewActivity } from "../../../socket/orders";
import { emitReloadAlert } from "../../../socket/notification";

class MainPanelAddNote extends Component {
    constructor(props) {
        super(props);
        this.state = {
            noteText: "",
            isPrivateNote: false
        };
    }

    handleInputsChange(field, value) {
        if (field === "noteText") {
            this.setState({
                noteText: value,
                isEnabledButton: value && value.trim()
            });
        } else {
            this.setState({
                [field]: value
            });
        }
    }

    handleReset() {
        this.setState({
            noteText: "",
            isEnabledButton: false,
            isPrivateNote: false
        });
    }


    handleSave() {
        const { dispatch, accountId, orderId, userName, roleType, profile } = this.props;
        const role = roleType;
        const userId = profile.id;
        const note = {
            Description: this.state.noteText,
            CreatedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            CreatedBy: accountId,
            TypeID: COMMENT_TYPE.OrderCommentType,
            OwnerID: orderId,
            IsPrivate: this.state.isPrivateNote
        };
        this.handleReset();

        dispatch(saveNote(note, () => {
            this.refreshNotesData();

            const log = {
                OrderId: orderId,
                Activity: `${userName} add a note`,
                UsersId: accountId,
                DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                ProgressType: ACTION,
                Message: note.Description
            };

            //add activity log
            apiAddNewOrderProgress(log,
                () => {
                    emitReloadAlert({ userId, role });
                },
                (error) => handleApiError(error)
            );
            dispatch(getOrderDetailLeftPanelInitData({ orderId, portal: roleType }));
        }));
    }

    refreshNotesData() {
        const { dispatch, orderId } = this.props;

        dispatch(getNotesData(orderId)).then(() => {
            $("#notePanel").scrollTop(9999);
        });
    }

    componentDidMount() {
        this.refreshNotesData();

        listenHaveNewActivity(() => {
            this.refreshNotesData();
        });
    }

    renderNotes() {
        const { orderComments, accountId, img } = this.props;

        if (orderComments.length > 0) {
            return (
                <div>
                    <ol id="notePanel" className="notelist" style={{ maxHeight: "500px", overflowY: "scroll" }}>
                        {orderComments.map((item) => {
                            if (item.usersId !== accountId) {
                                return (
                                    <li className="your-note" key={item.commentID}>
                                        <div className="avt-note">
                                            <img alt="" title={item.fullName} className="responsive-img circle" src={(item.img === "" || item.img === undefined) ? noAvatarImg : item.img} />
                                        </div>
                                        <div className="chat-content" >
                                            <p style={{ wordBreak: "break-word" }}>{item.description}</p>
                                            <small>{moment(item.createdDate).format("MMM D YYYY [at] h:mm A")}</small>
                                        </div>
                                    </li>
                                );
                            }
                            return (
                                <li className="other-note" key={item.commentID}>
                                    <div className="chat-content">
                                        <p style={{ wordBreak: "break-word" }}>{item.description}</p>
                                        <div className="avt-note">
                                            <img alt="" title={item.fullName} className="responsive-img circle" src={(item.img === "" || item.img === undefined) ? noAvatarImg : item.img} />
                                        </div>
                                        <small>{moment(item.createdDate).format("MMM D YYYY [at] h:mm A")}</small>
                                    </div>
                                </li>
                            );
                        })}
                    </ol>
                </div>
            );
        }
        return "";
    }

    renderInputNote() {
        return (
            <div>
                <div className="input-field">
                    <input type="text"
                        ref="noteText" id="noteText"
                        maxLength="250"
                        value={this.state.noteText || ""}
                        onChange={(e) => this.handleInputsChange("noteText", e.target.value)}
                    />
                    <label htmlFor="noteText" className={this.state.noteText === "" ? null : `active`}>Enter a note for this Order</label>
                </div>

                <div className="row">
                    <div className="col s6 left-align">
                        <label>
                            <input type="checkbox" ref="isPrivateNote" id="isPrivateNote"
                                checked={this.state.isPrivateNote}
                                onChange={(e) => this.handleInputsChange("isPrivateNote", e.target.checked)}
                            />
                            <span>Make Private</span>&nbsp;<span className="lnr lnr-question-circle" style={{ color: "#0F52BA" }} title="Checking this field means this note will be seen by you only"></span>
                        </label>
                    </div>
                    <div className="col s6 right-align">
                        <button type="button" className="btn white action-btn"
                            disabled={!this.state.isEnabledButton}
                            onClick={() => this.handleReset()}
                        >
                            RESET
                        </button>
                        <button type="button" className="btn btn-primary action-btn" id="addnotebtn"
                            onClick={() => this.handleSave()}
                            disabled={!this.state.isEnabledButton}
                        >
                            ADD NOTE
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {
        return (
            <div>
                {this.renderNotes()}
                {this.renderInputNote()}
            </div>
        );
    }
}

MainPanelAddNote.defaultProps = {
};

MainPanelAddNote.propTypes = {
    dispatch: PropTypes.func,
    orderId: PropTypes.number,
    orderComments: PropTypes.array,
    accountId: PropTypes.number,
    userName: PropTypes.string,
    img: PropTypes.string,
    roleType: PropTypes.string,
    subRoleType: PropTypes.string,
    profile: PropTypes.object
};

const mapStateToProps = (state) => {
    const { authentication, clientOrderDetail } = state;
    const { mainPanelAddNoteReducers } = clientOrderDetail;
    const { orderComments } = mainPanelAddNoteReducers;
    const { accountId, profile, role } = authentication;
    const { userName, img, subRoleType } = profile;
    const { roleType } = role;

    return {
        accountId,
        orderComments,
        userName,
        img,
        roleType,
        subRoleType,
        profile
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(MainPanelAddNote);