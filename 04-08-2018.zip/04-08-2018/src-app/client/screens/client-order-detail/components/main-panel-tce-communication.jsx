import React from "react";
import { Component } from "react";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import moment from "moment";
import { hasStringValueTrim } from "../../../helpers/common-helper";
import { apiAddNewOrderProgress } from "Api/order-progress-api";
import { MESSAGE_SENT, MESSAGE_RECEIVE } from "../../../constant/progress-log-constants";
import { showSuccess } from "../../main-layout/actions";
import { handleApiError } from "ErrorHandler";
import { apiSendEmailToTCECommunication } from "Api/email-api.js";

class MainPanelTceCommunication extends Component {
    constructor(props) {
        super(props);
        this.state = ({
            message: ""
        });
    }

    componentDidMount() {
        this.refs.message.focus();
    }

    handleReset() {
        this.setState({ message: "" });
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    handleInputChanged(key, value) {
        this.setState({
            ...this.state,
            [key]: value
        });
    }

    async handleSubmit() {
        const { dispatch, accountId, orderId, userName } = this.props;
        const message = this.state.message;

        await apiSendEmailToTCECommunication({ message, usersId: accountId, orderId },
            () => {

            }, (error) => handleApiError(dispatch, error)
        );

        //log sent
        const log = {
            OrderId: orderId,
            Activity: `Message sent to TCE`,
            UsersId: accountId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            ProgressType: MESSAGE_SENT,
            Message: message
        };

        //add activity log sent
        await apiAddNewOrderProgress(log,
            () => {
                dispatch(showSuccess(`Message sent to ${userName}.`));
            }, (error) => handleApiError(dispatch, error)
        );

        //log receive
        const logReceive = {
            OrderId: orderId,
            Activity: `Message receive from ${userName}`,
            UsersId: accountId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            ProgressType: MESSAGE_RECEIVE,
            Message: message
        };
        //add activity log receive
        await apiAddNewOrderProgress(logReceive,
            () => {

            }, (error) => handleApiError(dispatch, error)
        );

        this.handleReset();
    }

    isSubmitResetEnabled() {
        return hasStringValueTrim(this.state.message);
    }

    render() {
        return (
            <div className="row">
                <textarea ref="message" className="materialize-textarea" placeholder="Enter a message" style={{ height: "90px" }}
                    onChange={(event) => this.handleInputChanged("message", event.target.value)} value={this.state.message}
                />
                <div className="col m7 right">
                    <button className="btn success-color action-btn right" disabled={!this.isSubmitResetEnabled()} onClick={() => this.handleSubmit()} >SEND MESSAGE</button>
                    <button className="btn white action-btn right" disabled={!this.isSubmitResetEnabled()} onClick={() => this.handleReset()}>RESET</button>
                </div>
            </div>
        );
    }
}

MainPanelTceCommunication.propTypes = {
    dispatch: PropTypes.func.isRequired,
    accountId: PropTypes.number,
    orderId: PropTypes.number,
    userName: PropTypes.string
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { accountId, profile } = authentication;
    const { userName } = profile;

    return {
        accountId,
        userName
    };
};

export default connect(mapStateToProps)(MainPanelTceCommunication);