import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { getOtherDetails, updatePreCall, updateDocsReview } from "../actions/right-panel-actions";
import { connect } from "react-redux";
import { handleApiError } from "ErrorHandler";


class RightPanelOtherDetail extends Component {

    componentDidMount() {
        const { dispatch, orderId } = this.props;

        dispatch(getOtherDetails(orderId));
    }

    handlePreCallOnchange(event) {
        const { dispatch, orderId } = this.props;
        const value = Number(event.target.checked);
        const input = {
            orderID: orderId,
            isNeedPreCall: value
        };

        dispatch(updatePreCall(input, () => {
            dispatch(getOtherDetails(orderId));
        }, (error) => {
            handleApiError(this.props.dispatch, error);
        }));
    }

    handleReviewOnchange(event) {
        const { dispatch, orderId } = this.props;
        const value = Number(event.target.checked);
        const input = {
            orderID: orderId,
            NeedReviewPCResolution: value
        };

        dispatch(updateDocsReview(input, () => {
            dispatch(getOtherDetails(orderId));
        }, (error) => {
            handleApiError(this.props.dispatch, error);
        }));
    }

    render() {
        const { OtherDetailsData } = this.props;
        const { NeedReviewPCResolution, IsNeedPreCall } = OtherDetailsData;
        return (
            <div>
                <div className="panel-order-detail row box-shadow-st2 mt-1 pb-2">
                    <div className="col s12" style={{ marginTop: "10px" }}>
                        <label>
                            <span style={{ color: "#808181", fontSize: "11pt", fontWeight: 500 }}>Other Details</span>
                        </label>
                    </div>
                    <div className="col s12">
                        <label htmlFor="preCallCheckBox">
                            <input
                                type="checkbox"
                                id="preCallCheckBox"
                                ref="preCallCheckBox"
                                onChange={(event) => this.handlePreCallOnchange(event)}
                                checked={IsNeedPreCall}
                            />
                            <span>Need Pre-Call Made</span>
                        </label>
                    </div>
                    <div className="col s12">
                        <label htmlFor="reviewResolutionCheckBox">
                            <input
                                type="checkbox"
                                id="reviewResolutionCheckBox"
                                ref="reviewResolutionCheckBox"
                                onChange={(event) => this.handleReviewOnchange(event)}
                                checked={NeedReviewPCResolution}
                            />
                            <span>Need Review/PC Resolution</span>
                        </label>
                    </div>
                </div>
            </div>
        );
    }
}

RightPanelOtherDetail.propTypes = {
    dispatch: PropTypes.func,
    orderId: PropTypes.number,
    OtherDetailsData: PropTypes.object
};

const mapStateToProps = (state) => {
    const { clientOrderDetail } = state;
    const { rightPanel } = clientOrderDetail;
    const { OtherDetailsData } = rightPanel;
    return {
        OtherDetailsData
    };
};


export default connect(mapStateToProps)(RightPanelOtherDetail);
