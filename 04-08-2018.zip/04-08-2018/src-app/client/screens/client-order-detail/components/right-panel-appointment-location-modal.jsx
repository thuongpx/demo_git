import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
// import { handleApiError } from "ErrorHandler";
// import Select from "Select";
import InputMask from "react-input-mask";
import Select from "Select";
import { LIST_TIMEZONE_US } from "../../../constant/constants";
import { handleApiError } from "ErrorHandler";
import { apiGetTimeZoneByZip } from "Api/zip-api";
import { apiGetAppointmentDetailsInitData, apiUpdateAppointmentDetailsData } from "Api/orders-api";
import moment from "moment";
import { hasStringValue } from "Helpers/common-helper";
import { requireMessage } from "Helpers/validation-helper";
import { getStateCodeAndCityFromZip } from "Helpers/location-helper";
import { validateZip, invalidMessage, requireComboBoxMessage } from "Helpers/validation-helper";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import { INPUT_ERROR_1X_IMAGE_URL } from "ImageConfig";
import { showError } from "../../main-layout/actions/index";
import { deepClone } from "../../../helpers/common-helper";

class RightPanelAppointmentLocationModal extends Component {
    constructor(props) {
        super(props);

        const { dispatch } = this.props;
        this.state = {
            inputs: {
                isPropAddress: false,
                address: "",
                propAddress: "",
                suite: "",
                propSuite: "",
                city: "",
                zip: "",
                propCity: "",
                propZip: "",
                state: "",
                propState: "",
                timezone: ""
            },
            listStates: [],
            invalidField: {},
            isDirty: false
        };
        this.showError = (mess) => {
            dispatch(showError(mess));
        };
        this.isDirty = false;
        this.needSetFocus = true;
    }

    componentWillMount() {
        const { orderId } = this.props;

        apiGetAppointmentDetailsInitData(orderId, result => {
            const { defaultData, listStates } = result.data;
            const inputs = { ...this.state.inputs, ...defaultData };
            const aptDateTime = moment(defaultData.aptDateTime).utc();

            inputs.aptTime = defaultData.aptDateTime ? aptDateTime.format("h:mm:ss A").toString() : "";
            inputs.aptDate = defaultData.aptDateTime ? aptDateTime.format("MM/DD/YYYY").toString() : "";
            delete inputs.aptDateTime;

            if (inputs.timezone === null || inputs.timezone === undefined || inputs.timezone === "") {
                const d = new Date();
                const n = -(d.getTimezoneOffset() / 60);
                inputs.timezone = `${n < 0 ? `${n}` : `+${n}`}`;
            }

            this.setState({ inputs, listStates });
        }, (error) => handleApiError(this.props.dispatch, error));
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.orderDetail !== this.props.orderDetail) {
            const rawInputs = {
                ...this.state.inputs,
                address: nextProps.orderDetail.address,
                propAddress: nextProps.orderDetail.propAddress,
                suite: nextProps.orderDetail.suite,
                propSuite: nextProps.orderDetail.propSuite,
                city: nextProps.orderDetail.city,
                zip: nextProps.orderDetail.zip,
                propCity: nextProps.orderDetail.propCity,
                propZip: nextProps.orderDetail.propZip,
                state: nextProps.orderDetail.state,
                propState: nextProps.orderDetail.propState,
                timezone: nextProps.orderDetail.timezone
            };
            this.handleOnBlurZipCode(this.refs.clientPlaceOrderZip.value, "zip");

            this.setState({
                ...this.state,
                inputs: deepClone(rawInputs),
                defaultInputs: rawInputs
            });
        }
    }

    setAppointmentTimezone(zip) {
        apiGetTimeZoneByZip(zip, (result) => {
            if (result && result !== "") {
                this.handleOnchangeField(result.data.utc, "timezone");
            }
        }, (error) => handleApiError(this.props.dispatch, error));
    }

    validateForm() {
        const { inputs } = this.state;
        const invalidField = {};

        if (!inputs.isVenOrCEDefineADT) {
            if (!hasStringValue(inputs.timezone)) {
                invalidField.timezone = true;
            } else {
                const checkTimeZoneUS = LIST_TIMEZONE_US.find(item => item.UTC === `${inputs.timezone}`);
                if (!checkTimeZoneUS) invalidField.timezone = true;
            }
        }

        if (!hasStringValue(inputs.address)) invalidField.address = true;
        // if (!hasStringValue(inputs.propAddress)) invalidField.propAddress = true;
        if (!hasStringValue(inputs.city)) invalidField.city = true;
        if (!inputs.zip || inputs.zip === "_____") {
            invalidField.zip = true;
        } else if (!validateZip(inputs.zip)) {
            invalidField.zipData = true;
        }
        if (inputs.propZip && inputs.propZip !== "_____" && !validateZip(inputs.propZip)) invalidField.propZipData = true;
        if (!hasStringValue(inputs.state)) invalidField.state = true;

        // if (!this.props.isAgreeTerms) invalidField.isAgreeTerms = true;

        this.setState({ invalidField });

        const check = Object.keys(invalidField)[0];

        if (check) {
            return false;
        } else {
            return true;
        }
    }

    handleOnchangeField(value, fieldName) {
        const { inputs, invalidField } = this.state;

        inputs[fieldName] = value;

        if (fieldName === "state" || fieldName === "city") {
            inputs.zip = ""; //set zip to empty if change state or city
            if (fieldName === "state") {
                if (value) {
                    invalidField.state = false;
                    if (inputs.isPropAddress) {
                        inputs.propState = inputs.state;
                    }
                } else {
                    invalidField.state = true;
                }
            } else if (inputs.isPropAddress) {
                inputs.propCity = inputs.city;
            }
        } else if (fieldName === "propState" || fieldName === "propCity") {
            inputs.propZip = ""; //set zip to empty if change property state or city
        } else if (fieldName === "isPropAddress") {
            if (value) {
                inputs.propAddress = inputs.address;
                inputs.propState = inputs.state;
                inputs.propCity = inputs.city;
                inputs.propSuite = inputs.suite;
                inputs.propZip = inputs.zip;
            } else {
                inputs.propAddress = "";
                inputs.propState = "";
                inputs.propCity = "";
                inputs.propSuite = "";
                inputs.propZip = "";
            }
        } else if (fieldName === "address" || fieldName === "propAddress") {
            if (inputs.isPropAddress) {
                inputs.propAddress = inputs.address;
            }
        } else if (fieldName === "suite" || fieldName === "propSuite") {
            if (inputs.isPropAddress) {
                inputs.propSuite = inputs.suite;
            }
        } else if (fieldName === "zip" || fieldName === "propZip") {
            if (inputs.isPropAddress) {
                inputs.propZip = inputs.zip;
            }
        }

        this.setState({ inputs, invalidField });
    }

    handleOnBlurInput(value, fieldName, isRequiredField = true) {
        const { invalidField, inputs } = this.state;

        if (hasStringValue(value)) {
            invalidField[fieldName] = false;
            if (inputs.isPropAddress) {
                switch (fieldName) {
                    case "address":
                        invalidField.propAddress = false;
                        break;
                }
            }
        } else if (isRequiredField) {
            invalidField[fieldName] = true;
        }

        this.setState({ invalidField });
    }

    handleOnBlurZipCode(value, fieldName) {
        const { invalidField, inputs } = this.state;
        const { showConfirmModal } = this.props;

        //validate zip code
        if (fieldName === "zip") {
            if (value.trim() === "" || value === "_____") {
                invalidField[fieldName] = true;
                invalidField[`${fieldName}Data`] = false;
            } else {
                invalidField[fieldName] = false;
                if (validateZip(value)) {
                    invalidField[`${fieldName}Data`] = false;
                } else {
                    invalidField[`${fieldName}Data`] = true;
                }
            }
        } else if (value !== "" && value !== "_____" && !validateZip(value)) {
            invalidField[`${fieldName}Data`] = true;
        } else {
            invalidField[`${fieldName}Data`] = false;
        }

        if (!invalidField[fieldName] && !invalidField[`${fieldName}Data`]) { //if Zip code is valid then check it must be US Zip code.
            getStateCodeAndCityFromZip(value, (zipString) => {
                if (zipString !== "Invalid Zip Code") {
                    if (zipString.country !== "United States") {
                        inputs[fieldName] = "";
                        invalidField[`${fieldName}Data`] = false;

                        (this.showError("Your inputted Zip is not a valid US Zip Code. Please try again."));
                        this.setState({ invalidField, inputs });
                        $(`#client-place-order-${fieldName}`).focus();

                        return;
                    }

                    let strCity = "city";
                    let strState = "state";
                    let strZip = "zip";

                    if (fieldName === "propZip") {
                        strCity = "propCity";
                        strState = "propState";
                        strZip = "propZip";
                    }

                    //compare City and State user inputted with City and State get from Zip code
                    if ((hasStringValue(this.state.inputs[strCity]) && zipString.city !== this.state.inputs[strCity]) ||
                        (hasStringValue(this.state.inputs[strState]) && zipString.state !== this.state.inputs[strState])) {

                        const zipNotMatchMess = (
                            <div>
                                <div>The City and/or State do not match the Zip entered.</div>
                                <div>Do you mean the signing address as follows?</div>
                                <div>[{zipString.city} , {zipString.state}, {value}]</div>
                                <div>Click Yes to use that suggested address.</div>
                                <div>Click No to re-enter the correct address.</div>
                            </div>
                        );

                        showConfirmModal({ type: "warning", message: zipNotMatchMess }, () => {
                            invalidField[strCity] = false;
                            invalidField[strState] = false;
                            inputs[strCity] = zipString.city;
                            inputs[strState] = zipString.state;
                            this.setAppointmentTimezone(value);
                            this.setState({ inputs, invalidField });
                        }, () => {
                            invalidField[strCity] = false;
                            invalidField[strState] = false;
                            invalidField[strZip] = false;
                            invalidField[`${strZip}Data`] = false;
                            inputs[strCity] = "";
                            inputs[strState] = "";
                            inputs[strZip] = "";

                            this.setState({ invalidField, inputs });

                            $(`#client-place-order-${strZip}`).focus();
                        }, true);
                    } else {
                        invalidField[strCity] = false;
                        invalidField[strState] = false;
                        inputs[strCity] = zipString.city;
                        inputs[strState] = zipString.state;
                        this.setAppointmentTimezone(value);
                        this.setState({ inputs, invalidField });
                    }

                } else {
                    this.showError("Your inputted Zip is not a valid US Zip Code. Please try again.");

                    let strZip = "zip";

                    if (fieldName === "propZip") {
                        strZip = "propZip";
                    }

                    inputs[strZip] = "";

                    this.setState({ inputs });
                    $(`#client-place-order-${strZip}`).focus();
                }
            });
        } else {
            this.setState({ invalidField, inputs });
        }
    }

    validateFormData() {
        const { inputs } = this.state;
        const invalidField = {};

        if (!hasStringValue(inputs.address)) invalidField.address = true;
        // if (!hasStringValue(inputs.propAddress)) invalidField.propAddress = true;
        // if (!hasStringValue(inputs.suite)) invalidField.suite = true;
        if (!hasStringValue(inputs.city)) invalidField.city = true;
        if (!inputs.zip || inputs.zip === "_____") {
            invalidField.zip = true;
        } else if (!validateZip(inputs.zip)) {
            invalidField.zipData = true;
        }
        if (inputs.propZip && inputs.propZip !== "_____" && !validateZip(inputs.propZip)) invalidField.propZipData = true;
        if (!hasStringValue(inputs.state)) invalidField.state = true;

        // if (!this.props.isAgreeTerms) invalidField.isAgreeTerms = true;

        return invalidField;
    }

    saveChanges(isShowNoti, cbSetNewOrderId) {
        const { orderId } = this.props;
        const { inputs } = this.state;
        let rawData = { ...inputs };
        rawData.orderId = orderId;

        if (!hasStringValue(inputs.aptDate) || inputs.aptDate === "Invalid date") rawData = { ...rawData, aptDate: null };
        if (!hasStringValue(inputs.aptTime) || inputs.aptTime === "Invalid date") rawData = { ...rawData, aptTime: null };

        if (this.validateForm()) {
            if (orderId) {
                //already has a record in DB so just update data
                apiUpdateAppointmentDetailsData(rawData, () => {
                    if (isShowNoti) this.showSuccess(`Order ${orderId} updated successfully`);
                    cbSetNewOrderId(orderId);
                }, (error) => handleApiError(this.props.dispatch, error));
            }
        }
    }

    handleCancle() {
        this.setState({
            inputs: this.state.defaultInputs
        });
    }

    render() {
        const { inputs } = this.state;
        return (
            <div>
                <div className="row" style={{ marginBottom: "0px" }} >
                    <div className="col s6 m6">
                        <label htmlFor="" className="font-12 bold-6 primary-color">
                            <strong>Appointment Address</strong>
                        </label>
                    </div>
                    <div className="col s6 m6">
                        <label htmlFor="" className="font-12 bold-6 primary-color">
                            <strong>Property Address</strong>
                        </label>
                        <label>
                            <input
                                type="checkbox"
                                id="isPropAddress"
                                checked={inputs.isPropAddress}
                                onChange={e => this.handleOnchangeField(e.target.checked, "isPropAddress")}
                            />
                            <span>Same as Appointment Address</span>
                        </label>
                    </div>
                </div>
                <div className="row mb-0">
                    <div className="col s12 m6">
                        <div className="row">
                            <div className={`input-field col s12 m12 suffixinput required ${this.state.invalidField.address ? "required-field" : ""}`}>
                                <input
                                    type="text"
                                    placeholder="Street # and Address"
                                    id="client-place-order-address"
                                    className="validate"
                                    value={inputs.address || ""}
                                    onChange={e => this.handleOnchangeField(e.target.value, "address")}
                                    onBlur={e => this.handleOnBlurInput(e.target.value, "address")}
                                    maxLength={70}
                                />
                                {this.state.invalidField.address && <span className={`suffix-text`}>
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Address")} />
                                </span>}
                            </div>
                            <div className={`input-field col s12 m12 suffixinput`}>
                                <input
                                    type="text"
                                    placeholder="Unit #, Suite #, etc..."
                                    id="client-place-order-suite"
                                    className="validate"
                                    value={inputs.suite || ""}
                                    onChange={e => this.handleOnchangeField(e.target.value, "suite")}
                                    onBlur={e => this.handleOnBlurInput(e.target.value, "suite")}
                                    maxLength={10}
                                />
                            </div>
                            <div className={`input-field col s4 m4 suffixinput required ${this.state.invalidField.zip ? "required-field" : ""} ${this.state.invalidField.zipData ? "has-error" : ""}`}>
                                <InputMask
                                    mask="99999"
                                    type="text"
                                    placeholder="Zip"
                                    id="client-place-order-zip"
                                    ref="clientPlaceOrderZip"
                                    className="validate"
                                    value={inputs.zip || ""}
                                    onChange={e => this.handleOnchangeField(e.target.value, "zip")}
                                    onBlur={e => this.handleOnBlurZipCode(e.target.value, "zip")}
                                />
                                {this.state.invalidField.zip && <span className={`suffix-text`}>
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Zip")} />
                                </span>}
                                {this.state.invalidField.zipData && <span className={`suffix-text`}>
                                    <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Zip")} />
                                </span>}
                            </div>
                            <div className={`input-field col s8 m8 suffixinput required ${this.state.invalidField.city ? "required-field" : ""}`}>
                                <input
                                    type="text"
                                    placeholder="City"
                                    id="client-place-order-city"
                                    className="validate"
                                    value={inputs.city || ""}
                                    onChange={e => this.handleOnchangeField(e.target.value, "city")}
                                    onBlur={e => this.handleOnBlurInput(e.target.value, "city")}
                                    maxLength={50}
                                />
                                {this.state.invalidField.city && <span className={`suffix-text`}>
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("City")} />
                                </span>}
                            </div>
                            <div className="col s12 m12">
                                <div className={`input-field suffixinput required ${this.state.invalidField.state ? "required-field" : ""}`}>
                                    <Select
                                        dataSource={this.state.listStates}
                                        mapDataToRenderOptions={{ value: "Code", label: "Description" }}
                                        id="right-panel-apt-location-state"
                                        optionDefaultLabel="Select a State"
                                        value={inputs.state || ""}
                                        onChange={value => this.handleOnchangeField(value, "state")}
                                    />
                                    <span className={`suffix-text ${this.state.invalidField.state ? "" : "hide"}`} style={{ right: "22px" }}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireComboBoxMessage("State")} />
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col s12 m6">
                        <div className="row">
                            <div className={`input-field col s12 m12 suffixinput`}>
                                <input
                                    type="text"
                                    placeholder="Street # and Address"
                                    id="propAddress"
                                    className="validate"
                                    disabled={inputs.isPropAddress}
                                    value={inputs.isPropAddress === true ? inputs.address : inputs.propAddress || ""}
                                    onChange={e => this.handleOnchangeField(e.target.value, "propAddress")}
                                    onBlur={e => this.handleOnBlurInput(e.target.value, "propAddress")}
                                    maxLength={100}
                                />
                            </div>
                            <div className="input-field col s12 m12 suffixinput">
                                <input
                                    type="text"
                                    placeholder="Unit #, Suite #, etc..."
                                    id="propSuite"
                                    className="validate"
                                    disabled={inputs.isPropAddress}
                                    value={inputs.isPropAddress === true ? inputs.suite : inputs.propSuite || ""}
                                    onChange={e => this.handleOnchangeField(e.target.value, "propSuite")}
                                    onBlur={e => this.handleOnBlurInput(e.target.value, "propSuite")}
                                    maxLength={10}
                                />
                            </div>
                            <div className={`input-field col s4 m4 suffixinput ${this.state.invalidField.propZipData ? "has-error" : ""}`}>
                                <InputMask
                                    mask="99999"
                                    type="text"
                                    placeholder="Zip"
                                    id="client-place-order-propZip"
                                    className="validate"
                                    disabled={inputs.isPropAddress}
                                    value={inputs.isPropAddress === true ? inputs.zip : inputs.propZip}
                                    onChange={e => this.handleOnchangeField(e.target.value, "propZip")}
                                    onBlur={e => this.handleOnBlurZipCode(e.target.value, "propZip")}
                                />
                                {this.state.invalidField.propZipData && <span className={`suffix-text`}>
                                    <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Zip")} />
                                </span>}
                            </div>
                            <div className="input-field col s8 m8 suffixinput">
                                <input
                                    type="text"
                                    placeholder="City"
                                    id="propCity"
                                    className="validate"
                                    disabled={inputs.isPropAddress}
                                    value={inputs.isPropAddress === true ? inputs.city : inputs.propCity}
                                    onChange={e => this.handleOnchangeField(e.target.value, "propCity")}
                                    onBlur={e => this.handleOnBlurInput(e.target.value, "propCity")}
                                    maxLength={50}
                                />
                            </div>
                            <div className="input-field col s12 m12 select-input">
                                <Select
                                    dataSource={this.state.listStates}
                                    mapDataToRenderOptions={{ value: "Code", label: "Description" }}
                                    id="right-panel-apt-location-propState"
                                    optionDefaultLabel="Select a State"
                                    disabled={inputs.isPropAddress}
                                    value={inputs.isPropAddress === true ? inputs.state : inputs.propState}
                                    onChange={value => this.handleOnchangeField(value, "propState")}
                                />
                            </div>
                            <div style={{ display: "none" }}>
                                <Select
                                    dataSource={LIST_TIMEZONE_US}
                                    mapDataToRenderOptions={{ value: "UTC", label: "zone" }}
                                    value={`${this.state.inputs.timezone}`}
                                    optionDefaultLabel="Select Timezone"
                                    onChange={(value) => this.handleOnchangeField(value, "timezone")}
                                    id="right-panel-apt-location-timezone"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

RightPanelAppointmentLocationModal.propTypes = {
    dispatch: PropTypes.func,
    showConfirmModal: PropTypes.func,
    setDataToSendMail: PropTypes.func,
    data: PropTypes.object,
    orderId: PropTypes.number,
    orderDetail: PropTypes.object,
    profile: PropTypes.object,
    accountId: PropTypes.number,
    userName: PropTypes.string
};

export default RightPanelAppointmentLocationModal;