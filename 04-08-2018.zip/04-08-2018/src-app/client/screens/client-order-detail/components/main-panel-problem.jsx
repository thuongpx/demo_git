import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { Component } from "react";
import GridView from "GridView";
import { SUCCESSFULLY_SAVED_MESSAGE, SUCCESSFULLY_DELETED_MESSAGE } from "Constants";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";
import Select from "Select";
import CommonModal from "CommonModal";
import { showSuccess, showError } from "../../main-layout/actions";
import { handleApiError } from "ErrorHandler";
import { apiGetAllProblemTypes, apiGetProblemSubtypeById } from "../../../api/orders-api";
import { apiRemoveProblem, apiAddOrderProblem } from "../../../api/order-problem-api";
import { apiAddNewOrderProgress } from "Api/order-progress-api";
import { hasStringValue } from "../../../helpers/common-helper";
import moment from "moment";

import { COMMENT_TYPE } from "Constants";
import { ACTION } from "../../../constant/progress-log-constants";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import { getCommentByType } from "Api/comment-api";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { changeGridCriteria, getOrderProblemsByOrder } from "../actions/main-panel-actions";
import noAvatarImg from "./../../../public/images/no-avatar.png";
import OrderIssueDetailModal from "../../order-issue/components/order-issue-detail-modal";

class MainPanelProblem extends Component {
    constructor(props) {
        super(props);
        this.state = {
            inputs: this.getDefaultInputs(),
            invalidField: {},
            isShowModal: false,
            issue: {},
            listIssueType: [],
            description: "",
            dataArray: [],
            comments: [],
            dataIssueType: [],
            isDisabledAddCommentButton: true,
            listIssueSubType: []
        };
    }

    getDefaultInputs() {
        return {
            type: "",
            subType: "",
            groupVendorMistake: false,
            groupGenerateEmail: false,
            comment: ""
        };
    }

    getCommments(problemId) {
        const filter = {
            typeId: COMMENT_TYPE.OrderIssueCommentType,
            ownerId: problemId
        };
        getCommentByType(filter,
            (result) => {
                this.setState({
                    comments: result.data,
                    isDisabledAddCommentButton: true
                });
            }, (error) => handleApiError(this.props.dispatch, error));
    }

    componentWillMount() {
        const { dispatch } = this.props;

        apiGetAllProblemTypes((result) => {
            this.setState({
                listIssueType: result.data
            });
        }, (error) => handleApiError(dispatch, error));
    }

    componentDidMount() {
        const { dispatch, orderId, defaultCriteria } = this.props;

        dispatch(getOrderProblemsByOrder({ orderId, ...defaultCriteria }));
    }

    handleOnchangeField(value, name) {
        const { inputs, invalidField } = this.state;

        inputs[name] = value;

        if (name === "type") {
            invalidField.typeData = value === "";
            apiGetProblemSubtypeById(value, (result) => {
                this.setState({
                    inputs,
                    invalidField,
                    listIssueSubType: result.data
                });
            }, (error) => handleApiError(this.props.dispatch, error));
        } else {
            this.setState({ inputs, invalidField });
        }

        console.log(value);
        console.log("--------------");
        console.log(name);
        // apiGetProblemSubtypeById(value, (result) => {
        //     this.setState({
        //         inputs,
        //         invalidField,
        //         listIssueSubType: result.data
        //     });
        // }, (error) => handleApiError(this.props.dispatch, error));

        // this.setState({ inputs, invalidField });
    }

    handleCloseAddProblem() {
        this.setState({
            isShowModal: false,
            comments: [],
            inputs: this.getDefaultInputs()
        });
    }

    onClickAddProblem() {
        this.setState({
            isShowModal: true,
            issue: { problemId: -1 }
        });
    }

    getProblemType(key, listIssueType) {
        let ret = "";
        if (listIssueType) {
            listIssueType.forEach(item => {
                if (item.Id === parseInt(key)) {
                    ret = item.Description;
                }
            });
        }
        return ret;
    }

    onUpdateIssue() {
        const { defaultCriteria } = this.props;
        this.handleGridViewReload(defaultCriteria);
        this.handleCloseAddProblem();
    }

    onClickSave() {
        const { dispatch, orderId, accountId, order, defaultCriteria, userName } = this.props;
        const { inputs, comments, listIssueType } = this.state;

        if (this.validateForm()) {
            apiAddOrderProblem({
                OrderId: orderId,
                Type: inputs.type,
                SubType: inputs.subType,
                CreatedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                Mistake: inputs.groupVendorMistake,
                EnteredBy: accountId,
                SignerId: order.signerId,
                isGenerateEmail: inputs.groupGenerateEmail,
                comments,
                VendorFirstName: order.VendorFirstName,
                VendorLastName: order.VendorLastName,
                VendorEmail: order.VendorEmail,
                AgentFullName: order.AgentFullName,
                AgentEmail: order.AgentEmail,
                TCEFirstName: order.TCEFirstName,
                TCELastName: order.TCELastName,
                TCEEmail: order.TCEEmail,
                ProblemType: this.getProblemType(inputs.type, listIssueType),
                ProblemSubType: this.getProblemType(inputs.subType, listIssueType)
            }, () => {
                const log = {
                    OrderId: orderId,
                    Activity: `${userName} add a problem`,
                    UsersId: accountId,
                    DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                    ProgressType: ACTION
                };
                //add activity log
                apiAddNewOrderProgress(log,
                    () => {
                    },
                    (error) => handleApiError(error)
                );

                dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
                this.handleGridViewReload(defaultCriteria);
                this.handleCloseAddProblem();
            }, (error) => {
                dispatch(showError(error.message));
            });
        }
    }

    isSubmitEnabled() {
        if (hasStringValue(this.state.descriptionTemp)) {
            if (hasStringValue(this.state.descriptionTemp.trim())) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    handleAddComment() {
        const { accountId, userName, img } = this.props;
        const { comments } = this.state;

        comments.push({
            Description: this.state.inputs.comment,
            createdDate: moment().format("YYYY-MM-DD HH:mm:ss"),
            usersId: accountId,
            UserName: userName,
            img
        });
        this.setState({
            comments,
            inputs: {
                ...this.state.inputs,
                comment: ""
            },
            invalidField: {
                ...this.state.invalidField,
                commentsData: false
            }
        });
    }

    handleResetComment() {
        this.setState({
            inputs: {
                ...this.state.inputs,
                comment: ""
            }
        }, () => { this.refs.addComment.focus(); });
    }

    handleGridViewReload(criteria) {
        const { dispatch, orderId } = this.props;
        dispatch(changeGridCriteria(criteria));
        dispatch(getOrderProblemsByOrder({ orderId, ...criteria }));
    }

    handleClickProblem(action, identifier) {
        const { dispatch, defaultCriteria } = this.props;
        if (action === "Delete") {
            apiRemoveProblem(identifier, () => {
                dispatch(showSuccess(SUCCESSFULLY_DELETED_MESSAGE));
                this.handleGridViewReload(defaultCriteria);
            }, () => {
                dispatch(showError("Delete Error"));
            });
        }
        if (action === "problemLink") {
            this.issueAddModal.show(identifier);
        }
    }

    validateForm() {
        const { inputs, comments } = this.state;
        const invalidField = {};

        if (inputs.type === "") invalidField.typeData = true;
        if (comments.length < 1) invalidField.commentsData = true;

        this.setState({ invalidField });

        const check = Object.keys(invalidField)[0];

        if (check) {
            //focus for first invalid
            if (this.refs[check] !== undefined) {
                this.refs[check].focus();
                window.scrollTo(0, this.refs[check].offsetTop);
            }
            return false;
        } else {
            return true;
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    renderComment() {
        const { accountId, img, userName } = this.props;

        if (this.state.comments.length > 0) {
            return (
                <div>
                    <ol id="notePanel" className="notelist" style={{ maxHeight: "500px", overflowY: "scroll" }}>
                        {this.state.comments.map((item, index) => {
                            if (item.usersId !== accountId) {
                                return (
                                    <li className="your-note" key={index} style={{ marginBottom: "25px" }} >
                                        <div className="avt-note">
                                            <img alt="" title={item.UserName} className="responsive-img circle" src={(item.img === "" || item.img === undefined || item.img === null) ? noAvatarImg : item.img} />
                                        </div>
                                        <div className="chat-content" >
                                            <p style={{ wordBreak: "break-word" }}>{item.Description}</p>
                                            <small>{(item.createdDate !== "" && item.createdDate !== "Invalid date") ? moment(item.createdDate).format("MMM D YYYY [at] h:mm A") : ""}</small>
                                        </div>
                                    </li>
                                );
                            }
                            return (
                                <li className="other-note" key={index} style={{ marginBottom: "25px" }}>
                                    <div className="chat-content">
                                        <p style={{ wordBreak: "break-word" }}>{item.Description}</p>
                                        <div className="avt-note">
                                            <img alt="" title={userName} className="responsive-img circle" src={(img === "" || img === undefined) ? noAvatarImg : img} />
                                        </div>
                                        <small>{(item.createdDate !== "" && item.createdDate !== "Invalid date") ? moment(item.createdDate).format("MMM D YYYY [at] h:mm A") : ""}</small>
                                    </div>
                                </li>
                            );
                        })}
                    </ol>
                </div>
            );
        } else {
            return null;
        }
    }

    render() {
        const { listProblem, columns, defaultCriteria, orderId, order, roleType, roleNames } = this.props;
        const { inputs } = this.state;
        let mode = "Scheduler";
        if (roleType === "Staff") {
            roleNames.map((item) => {
                if (item === "Admin" || item === "Content Manager" || item === "Training Manager" || item === "Accounting Manager" || item === "Operational Manager") {
                    mode = "Admin";
                }
            });
        } else if (roleType === "Client") {
            mode = "Client";
        }

        if (roleType === "Vendor") {
            mode = "Vendor";
        }

        return (
            <div>
                <button className="btn btn-small success-color mt-1 mb-1 right" onClick={() => this.onClickAddProblem()}>Add Correction Request</button>
                <div className="clear"></div>
                <GridView
                    criteria={defaultCriteria}
                    datasources={listProblem} //Pass datasources
                    columns={columns} //Pass columns array
                    identifier={"ProblemId"} //Identifier for grid row
                    onActionClick={this.handleClickProblem.bind(this)}
                    onGridViewReload={this.handleGridViewReload.bind(this)}
                />

                <OrderIssueDetailModal onUpdateIssue={() => this.onUpdateIssue()}
                    ref={(issueAddModal) => {
                        if (issueAddModal && issueAddModal.getWrappedInstance) {
                            this.issueAddModal = issueAddModal.getWrappedInstance();
                        }
                    }}
                />

                <Modal isOpen={this.state.isShowModal} addClass="no-tab">
                    <ModalBody>
                        <ModalTitle onClickClose={() => { this.handleCloseAddProblem(); }}>Report a Correction Request</ModalTitle>
                        <div className="tab-content">
                            <div className="col s12 pr-2 pl-1">
                                <div className="card box-shadow-none">
                                    <div className="card-content p-0">
                                        <div className="row mt-1">
                                            <div className="col s12">
                                                <div className="left">
                                                    Order ID: {orderId}
                                                </div>
                                                {hasStringValue(order.vendorName) &&
                                                    <div className="right">
                                                        Vendor: {order.vendorName}
                                                    </div>
                                                }
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col s6 ">
                                                <div className={`input-field required suffixinput ${this.state.invalidField.typeData ? "required-field" : ""}`}>
                                                    <Select
                                                        dataSource={this.state.listIssueType}
                                                        mapDataToRenderOptions={{ value: "Id", label: "Description" }}
                                                        onChange={(value) => this.handleOnchangeField(value, "type")}
                                                        value={inputs.type}
                                                        optionDefaultLabel="Select Correction Request Type"
                                                    />
                                                    <label>Correction Request Type</label>
                                                    {this.state.invalidField.typeData && <span className={`suffix-text`} style={{ paddingLeft: "15px" }}>
                                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={`Please select a type`} />
                                                    </span>}
                                                </div>
                                            </div>
                                            <div className="col s6">
                                                <div className="input-field">
                                                    <Select
                                                        dataSource={this.state.listIssueSubType}
                                                        mapDataToRenderOptions={{ value: "Id", label: "Description" }}
                                                        onChange={(value) => this.handleOnchangeField(value, "subType")}
                                                        value={inputs.subType}
                                                        optionDefaultLabel="Select Correction Request Sub Type"
                                                        disabled={!inputs.type}
                                                    />
                                                    <label>Correction Request Sub Type</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="wrap-alert" style={{ borderRadius: "10px" }}>
                                                <p className="title-wrap-alert blue-color">Description/Comments</p>
                                                <div className="box-item vendor-wrap-alert">
                                                    <div className="row mb-0">
                                                        {this.renderComment()}
                                                    </div>
                                                    <div className="row">
                                                        <div className="col m12 input-field">
                                                            <input name="addComment"
                                                                ref="addComment"
                                                                id="addComment"
                                                                maxLength="250"
                                                                type="text"
                                                                placeholder="Enter a Description/ Comments for this Correction Request"
                                                                value={inputs.comment}
                                                                onChange={(e) => this.handleOnchangeField(e.target.value, "comment")}
                                                            />
                                                            {/* <label htmlFor="addComment">Enter a Description/ Comments for this Correction Request</label> */}
                                                        </div>
                                                    </div>
                                                    <div className="row">
                                                        <div className="right input-field">
                                                            <button type="button" className="btn white action-btn" disabled={inputs.comment === ""} onClick={() => this.handleResetComment()}>RESET</button>
                                                            <button
                                                                onClick={() => this.handleAddComment()} className="btn btn-primary action-btn"
                                                                disabled={inputs.comment === ""}
                                                            >Add</button>
                                                        </div>
                                                        {this.state.invalidField.commentsData && <span className={`suffix-text`} style={{ paddingLeft: "15px" }}>
                                                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={`Please add a Description/Comment`} />
                                                        </span>}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="row">
                                            <div className="col m6 mb-1">
                                                <div className="col m12">Is this issue a Vendor mistake?</div>
                                                <div className="col m12 ml-2">
                                                    <label>
                                                        <input type="radio" id="groupVendorMistakeYes" className="with-gap" value="Yes" name="groupVendorMistake" ref="groupVendorMistakeYes"
                                                            onChange={() => this.handleOnchangeField(true, "groupVendorMistake")} checked={inputs.groupVendorMistake}
                                                        />
                                                        <span>Yes</span>
                                                    </label>
                                                </div>
                                                <div className="col m12 ml-2">
                                                    <label>
                                                        <input type="radio" id="groupVendorMistakeNo" className="with-gap" value="No" name="groupVendorMistake" ref="groupVendorMistakeNo"
                                                            onChange={() => this.handleOnchangeField(false, "groupVendorMistake")} checked={!inputs.groupVendorMistake}
                                                        />
                                                        <span>No</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div className="col m6 mb-1">
                                                <div className="col m12">If yes generate email to Vendor?</div>
                                                <div className="col m12 ml-2">
                                                    <label>
                                                        <input type="radio" id="groupGenerateEmailYes" className="with-gap" value="Yes" name="groupGenerateEmail" ref="groupGenerateEmailYes"
                                                            disabled={!inputs.groupVendorMistake}
                                                            onChange={() => this.handleOnchangeField(true, "groupGenerateEmail")} checked={inputs.groupGenerateEmail}
                                                        />
                                                        <span>Yes</span>
                                                    </label>
                                                </div>
                                                <div className="col m12 ml-2">
                                                    <label>
                                                        <input type="radio" id="groupGenerateEmailNo" className="with-gap" value="No" name="groupGenerateEmail" ref="groupGenerateEmailNo"
                                                            disabled={!inputs.groupVendorMistake}
                                                            onChange={() => this.handleOnchangeField(false, "groupGenerateEmail")} checked={!inputs.groupGenerateEmail}
                                                        />
                                                        <span>No</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        {mode === "Admin" &&
                                            <div className="row">
                                                <div className="col m6 mb-1">
                                                    <div className="col m12">Has Client been contacted?</div>
                                                    <div className="col m12 ml-2">
                                                        <label>
                                                            <input type="radio" id="groupClientContactedYes" className="with-gap" value="Yes" name="groupClientContacted" ref="groupClientContactedYes"
                                                                onChange={() => this.handleOnchangeField(true, "groupClientContacted")} checked={inputs.groupClientContacted}
                                                            />
                                                            <span>Yes</span>
                                                        </label>
                                                    </div>
                                                    <div className="col m12 ml-2">
                                                        <label>
                                                            <input type="radio" id="groupClientContactedNo" className="with-gap" value="No" name="groupClientContacted" ref="groupClientContactedNo"
                                                                onChange={() => this.handleOnchangeField(false, "groupClientContacted")} checked={!inputs.groupClientContacted}
                                                            />
                                                            <span>No</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div className="col m6 mb-1">
                                                    <div className="col m12">If no, generate email to Client?</div>
                                                    <div className="col m12 ml-2">
                                                        <label>
                                                            <input type="radio" id="groupGenerateEmailToClientYes" className="with-gap" value="Yes" name="groupGenerateEmailToClient" ref="groupGenerateEmailToClientYes"
                                                                disabled={inputs.groupClientContacted}
                                                                onChange={() => this.handleOnchangeField(true, "groupGenerateEmailToClient")} checked={inputs.groupGenerateEmailToClient}
                                                            />
                                                            <span>Yes</span>
                                                        </label>
                                                    </div>
                                                    <div className="col m12 ml-2">
                                                        <label>
                                                            <input type="radio" id="groupGenerateEmailToClientNo" className="with-gap" value="No" name="groupGenerateEmailToClient" ref="groupGenerateEmailToClientNo"
                                                                disabled={inputs.groupClientContacted}
                                                                onChange={() => this.handleOnchangeField(false, "groupGenerateEmailToClient")} checked={!inputs.groupGenerateEmailToClient}
                                                            />
                                                            <span>No</span>
                                                        </label>
                                                    </div>
                                                    <div className="col m12">
                                                        <div className={`input-field`}>
                                                            <input id="emailToClient" maxLength="100" type="text" ref="emailToClient" className="validate" disabled={!inputs.groupClientContacted} />
                                                            <label htmlFor="emailToClient">If yes, who was contacted</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>}

                                    </div>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col m6">
                                <button className="btn white w-100" onClick={() => this.handleCloseAddProblem()}>Cancel</button>
                            </div>
                            <div className="col m6">
                                <button className="btn success-color w-100" onClick={() => this.onClickSave()}>Save</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div >
        );
    }
}

MainPanelProblem.defaultProps = {
    columns: [
        {
            title: "Date",
            data: "Date",
            type: "date"
        },
        {
            title: "Corection Request Type",
            data: "Type",
            type: "problemLink"
        },
        {
            title: "Vendor Error",
            data: "Mistake"
        },
        {
            title: "Status",
            data: "Status"
        },
        {
            title: "",
            type: "client-problem-action"
        }
    ]
};

MainPanelProblem.propTypes = {
    router: PropTypes.object,
    listProblem: PropTypes.array,
    columns: PropTypes.array,
    defaultCriteria: PropTypes.object,
    dispatch: PropTypes.func,
    dataArray: PropTypes.array,
    accountId: PropTypes.number,
    roleType: PropTypes.string,
    roleNames: PropTypes.array,
    img: PropTypes.string,
    userName: PropTypes.string,
    orderId: PropTypes.number,
    firstName: PropTypes.string,
    lastName: PropTypes.string,
    order: PropTypes.object
};
const mapStateToProps = (state) => {
    const { authentication, clientOrderDetail } = state;
    const { accountId, profile } = authentication;
    const { firstName, lastName, userName, img } = profile;
    const { leftPanelFee } = clientOrderDetail;
    const { defaultCriteria, listProblem, totalRecord } = clientOrderDetail.mainPanelReducer;
    const { fee } = leftPanelFee;
    const { order } = fee;
    const { roleType, roleNames } = authentication.role;
    return {
        accountId,
        firstName,
        lastName,
        order,
        userName,
        roleType,
        roleNames,
        img,
        defaultCriteria,
        listProblem,
        totalRecord
    };
};
export default connect(mapStateToProps)(MainPanelProblem);