import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import { hasStringValueTrim } from "Helpers/common-helper";
import { requireMessage } from "Helpers/validation-helper";

class OrderCancellationModal extends Component {
    constructor(props) {
        super(props);

        this.state = {
            invalidReason: false
        };
    }

    componentWillReceiveProps() {
        this.setState({
            invalidReason: false
        });
    }

    handleOpenModalEnd() {
        this.refs.reason.value = "";
        this.refs.reason.focus();
    }

    handleCloseModal() {
        const { closeModal } = this.props;

        closeModal();
    }

    handlerSubmitCancellation() {
        const { submitCancel } = this.props;

        const reason = this.refs.reason.value;

        if (hasStringValueTrim(reason)) {
            submitCancel(this.refs.reason.value);
        } else {
            this.setState({
                invalidReason: true
            });
        }
    }

    render() {
        const { isOpen } = this.props;

        const modalOptions = {
            onOpenEnd: () => this.handleOpenModalEnd()
        };

        return (
            <div>
                <Modal isOpen={isOpen} addClass="no-tab" modalOptions={modalOptions} size={""} fixedFooter={false} style={{ width: "45%" }} addClass="common-popup confirm-com">
                    <ModalTitle onClickClose={() => this.handleCloseModal()} className="text-primary"><span className="fa fa-question-circle"> Confirmation Message</span></ModalTitle>
                    <ModalBody>
                        <div className="row mb-0">
                            <div className="col s12">
                                <div className="row">
                                    <div className="col s12">
                                        <p>Are you sure you would like to cancel this order</p>
                                        <p>If yes, please provide the reason</p>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col s12">
                                        <div className={`input-field suffixinput required ${this.state.invalidReason ? "required-field" : ""}`}>
                                            <textarea
                                                maxLength="250"
                                                ref="reason"
                                                id="reason"
                                                className="materialize-textarea"
                                                placeholder="Enter reason here"
                                                style={{ minHeight: 150 }}
                                            />
                                            {this.state.invalidReason && <span className={`suffix-text`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Reason")} />
                                            </span>}
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col m6">
                                <button className="btn white w-100" onClick={() => this.handleCloseModal()}>Cancel</button>
                            </div>
                            <div className="col m6">
                                <button className="btn success-color w-100" onClick={() => this.handlerSubmitCancellation()}>Yes</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
            </div>
        );
    }
}


OrderCancellationModal.propTypes = {
    isOpen: PropTypes.bool,
    closeModal: PropTypes.func,
    submitCancel: PropTypes.func
};

export default OrderCancellationModal;
