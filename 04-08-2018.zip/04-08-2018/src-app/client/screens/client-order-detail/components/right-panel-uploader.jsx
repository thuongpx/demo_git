import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { FILE_UPLOAD_SIZE, FILE_UPLOAD_EXTENSIONS } from "Config/config";
import { apiCheckDocName } from "../../../api/order-docs-api";
import { renameFile } from "../../../helpers/common-helper";
import { showSuccess } from "../../main-layout/actions/index";
import { handleApiError } from "ErrorHandler";
import { emitUpdateOrderDoc } from "../../../socket/docs";
import DocsUploadDuplicateModal from "../../order-details/components/docs-upload-duplicate-modal";
import DragDropUploader from "./right-panel-drag-drop-uploader";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class Uploader extends Component {
    constructor(props) {
        super(props);
        const orderId = props.orderId;
        const PATH = props.constPath;
        this.state = {
            path: `${PATH + orderId}/`,
            uploadedFiles: [],
            maxSize: FILE_UPLOAD_SIZE, //50MB
            fileExtensions: FILE_UPLOAD_EXTENSIONS,
            isShowDuplicateForm: false,
            newFiles: [],
            isDuplicate: false
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    onRequestDuplicateModal(isShow) {
        this.setState({ isShowDuplicateForm: isShow });
    }

    handleUploadFileSuccess(file, docType) {
        //insert value to db
        const data = {};
        const { accountId, orderId, tenantId, handleUploadNewFile } = this.props;
        data.OrderId = orderId;
        data.TenantId = tenantId;
        data.Description = file.originalName;
        data.DocumentType = docType;
        data.UserId = accountId;
        data.FileSize = file.size;
        handleUploadNewFile(data, false);
        const { uploadedFiles } = this.state;
        uploadedFiles.push(file);
        this.setState({
            uploadedFiles
        });
    }

    showAlert(message) {
        this.commonModal.showModal({
            type: "warning",
            message
        },
            () => {
                // confirm
            }
        );
        return;
    }

    handleFiles(dispatch, files, orderId) {
        const relativeBasicNames = [];
        let isDuplicate = false;
        files.forEach(file => {
            const basicName = file.name.substr(0, file.name.lastIndexOf("."));
            const subBasicName = basicName.substr(0, basicName.lastIndexOf("("));
            const relativeBasicName = subBasicName ? subBasicName : basicName;
            relativeBasicNames.push(relativeBasicName);
        });
        apiCheckDocName(orderId, relativeBasicNames.toString(), this.props.constDocType,
            (result) => {
                const arrayName = result.data.fileName;
                const arraySize = result.data.fileSize;
                const arrayId = result.data.fileId;
                const arrayStatus = result.data.fileStatus;

                const newFiles = files.filter((file, index) => {
                    //rename
                    const ext = file.name.split(".").pop();
                    const basicName = file.name.substr(0, file.name.lastIndexOf("."));
                    let newBasicName = basicName;
                    const subArrayName = arrayName[index];
                    const pos = subArrayName.indexOf(file.name);
                    if (pos > -1) {
                        while (subArrayName.includes(`${newBasicName}.${ext}`)) {
                            newBasicName = renameFile(newBasicName, 1);
                        }
                        files[index].newName = `${newBasicName}.${ext}`;
                        files[index].oldSize = arraySize[index][pos];
                        files[index].docId = arrayId[index][pos];
                        files[index].status = arrayStatus[index][pos];
                        isDuplicate = true;
                    }
                    // return file.type !== ""
                    // && (!Array.isArray(fileExtensions) || fileExtensions.indexOf(ext) !== -1);
                    return true;
                });

                this.setState({ newFiles, isDuplicate });

                if (isDuplicate) {
                    this.onRequestDuplicateModal(isDuplicate);
                } else {
                    this.uploader.upload(newFiles);
                }
            }, (error) => handleApiError(dispatch, error));
    }

    handleValidate(files) {
        const { orderId, dispatch } = this.props;
        const { fileExtensions } = this.state;
        if (files.length === 0) {
            return;
        }

        this.handleFiles(dispatch, files, orderId, fileExtensions);
    }
    onNotification() {
        const { dispatch, orderId } = this.props;
        emitUpdateOrderDoc(this.props.constNotiMessage, orderId);
        dispatch(showSuccess("Sent Successfully"));
    }

    render() {

        const { maxFiles, fileExtensions, path } = this.state;
        const { dispatch, disabled, onAllFileUploaded, disableShareAll } = this.props;
        return (
            <div>
                <DragDropUploader ref={uploader => { this.uploader = uploader; }}
                    path={path}
                    onShareAllClick={() => this.props.onShareAllClick()}
                    isShowShareAllButton={this.props.isShowShareAllButton}
                    fileExtensions={fileExtensions}
                    onUploadFileSuccess={(file) => this.handleUploadFileSuccess(file, this.props.constDocType)}
                    maxFiles={maxFiles}
                    onValidate={(files) => this.handleValidate(files)}
                    onAllFileUploaded={onAllFileUploaded}
                    {...{ disabled }}
                    disableShareAll={disableShareAll}
                />
                <DocsUploadDuplicateModal
                    isShowModal={this.state.isShowDuplicateForm}
                    onCancel={(e) => this.onRequestDuplicateModal(e)}
                    newFiles={this.state.newFiles}
                    dispatch={dispatch}
                    upload={(e) => this.uploader.upload(e)}
                />
            </div>
        );
    }
}

Uploader.defaultProps = {
    isShowShareAllButton: false,
    disableShareAll: false
};

Uploader.propTypes = {
    orderId: PropTypes.number,
    tenantId: PropTypes.number,
    handleUploadNewFile: PropTypes.func,
    listSource: PropTypes.array,
    dispatch: PropTypes.func.isRequired,
    accountId: PropTypes.number,
    constDocType: PropTypes.number,
    constNotiMessage: PropTypes.string,
    constPath: PropTypes.string,
    disabled: PropTypes.bool,
    onAllFileUploaded: PropTypes.func,
    isShowShareAllButton: PropTypes.bool,
    onShareAllClick: PropTypes.func,
    disableShareAll: PropTypes.bool
};
export default Uploader;