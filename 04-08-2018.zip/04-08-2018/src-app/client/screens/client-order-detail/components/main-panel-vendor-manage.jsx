import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import VendorSentOfferList from "./../components/main-panel-vendor-send-offer-list";
import VendorHistory from "./../components/main-panel-vendor-history";
import VendorRequests from "./../components/main-panel-vendor-requests";
import { switchModuleOnMainPanel } from "../actions/main-panel-actions";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class VendorManager extends Component {
    constructor(props) {
        super(props);

        // set active tab by cookies
        this.cookieKey = "ORDER_DETAILS_VENDOR_MANAGE_ACTIVE_TAB";

        const tabs = [
            { title: "Sent-Offer List", isActive: true },
            { title: "Vendor History", isActive: false },
            { title: "Vendor Requests", isActive: false }
        ];
        // set tab default if there is not any tab matches value in cookies
        const activeTabs = tabs.filter((item) => {
            return item.isActive;
        });

        if (activeTabs.length === 0) tabs[0].isActive = true;

        this.state = {
            tabs
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentWillReceiveProps() {
        const tabs = [];

        tabs.push({ title: "Sent-Offer List", isActive: true });
        tabs.push({ title: "Vendor History", isActive: false });
        tabs.push({ title: "Vendor Requests", isActive: false });
        this.setState({
            ...this.state,
            tabs
        });
    }

    handleTabClick(tab) {
        this.setActiveTab(tab);
    }

    setActiveTab(tab) {
        const { tabs } = this.state;

        tabs.map(item => {
            if (item.title === tab.title) {
                item.isActive = true;
            } else item.isActive = false;
            return item;
        });
        this.setState({ tabs });
    }

    handleViewRequestFee(e) {
        e.preventDefault();

        // hide communication module and show fee requests module
        const { dispatch } = this.props;
        dispatch(switchModuleOnMainPanel("COM"));
    }

    render() {
        const renderTabs = () => {

            return this.state.tabs.map((tab, key) => {
                const classNameActive = tab.isActive ? "active" : "";

                return (
                    <li className={`tab col ${classNameActive}`} key={key} onClick={() => this.handleTabClick(tab)}>
                        <a style={{ cursor: "pointer" }}>{tab.title}</a>
                    </li>
                );
            });
        };
        const renderTabContent = () => {
            const { orderId } = this.props;

            return this.state.tabs.map((tab, key) => {

                if (tab.isActive) {
                    switch (tab.title) {
                        case "Sent-Offer List":
                            return (
                                <VendorSentOfferList
                                    key={key}
                                    orderId={orderId}
                                />
                            );
                        case "Vendor History":
                            return (
                                <VendorHistory
                                    key={key}
                                    orderId={orderId}
                                />
                            );
                        case "Vendor Requests":
                            return (
                                <VendorRequests
                                    key={key}
                                    orderId={orderId}
                                />
                            );
                        default:
                            return (
                                <div className="col s12 tab-content p-0">
                                </div>
                            );
                    }
                }
                return null;
            });
        };
        return (
            <div className="col s12">
                <div className="tab-wrap st2 panel-order-detail row p-0">
                    <div className="col s12 mt-2 p-0">
                        <ul className="tabs">
                            {renderTabs()}
                        </ul>
                    </div>
                    {renderTabContent()}
                    <div className="p-0 right">
                        <button
                            className="btn btn-small success-color"
                            onClick={(e) => this.handleViewRequestFee(e)}
                        >EXIT</button>
                    </div>
                </div>
            </div>
        );
    }
}

VendorManager.defaultProps = {
};

VendorManager.propTypes = {
    dispatch: PropTypes.func,
    orderId: PropTypes.number
};

export default connect()(VendorManager);