import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { apiRemoveVendorFromOrder } from "Api/orders-api";
import CommonModal from "CommonModal";
import noAvatarImg from "./../../../public/images/no-avatar.png";
import { setOrderProgressId } from "./../actions/index";
import { ORDER_PROGRESS_ID } from "../../../constant/order-detail-constants";
import { getOrderDetailLeftPanelFeeInitData } from "../actions/left-panel-actions";
import { emitHaveNewActivity } from "../../../socket/orders";

class VendorReAssignModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false,
            vendor: {}
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    show(vendor) {
        this.setState({
            isOpen: true,
            vendor
        });
    }

    handleRemoveCurrentVendor() {
        const { vendor } = this.state;
        this.commonModal.showModal({
            type: "confirm",
            message: `Are you sure you would like to remove this current vendor?`
        }, () => {
            apiRemoveVendorFromOrder({
                orderId: this.props.orderId,
                userName: this.props.userName,
                vendorName: `${vendor.FirstName} ${vendor.LastName}`,
                usersId: this.props.accountId
            }, () => {
                this.setState({ isOpen: false });
                this.props.dispatch(setOrderProgressId(ORDER_PROGRESS_ID.OPEN));
                this.props.dispatch(getOrderDetailLeftPanelFeeInitData(this.props.orderId));
                emitHaveNewActivity(this.props.orderId);
                this.props.onRemoveVendor();
            });
        });
    }

    handleOpenModalEnd() {
        this.cancelButtion.focus();
    }

    render() {
        const { isOpen, vendor } = this.state;

        const modalOptions = {
            onOpenEnd: () => this.handleOpenModalEnd()
        };

        return (
            <div>
                <Modal isOpen={isOpen} addClass="no-tab" modalOptions={modalOptions}>
                    <ModalBody>
                        <ModalTitle onClickClose={() => { this.setState({ isOpen: false }); }}>Assign a Vendor</ModalTitle>
                        <div className="tab-content">
                            <div className="col s12 m5 center-col">
                                <div className="col s12 mt-2">
                                    <div style={{ textAlign: "center" }}>
                                        <p className="bold-5">Currently assigned</p>
                                    </div>
                                    <div className="row vendor-order-info mt-3">
                                        {vendor.ProfilePicture ? <div className="col s4">
                                            <div className="image-wrap">
                                                <img src={vendor.ProfilePicture} alt="" />
                                            </div>
                                        </div> : <div className="col s4">
                                                <div className="image-wrap">
                                                    <img src={noAvatarImg} alt="" />
                                                </div>
                                            </div>}
                                        <div className="col s8">
                                            <div className="vendor-info-1">
                                                <p className="vendorName">{`${vendor.FirstName || ""} ${vendor.LastName || ""}`}</p>
                                                <strong className="vendorRole">{`${vendor.Company || ""}`}</strong>
                                                <small>
                                                    <i className="lnr lnr-map-marker"></i> {`${vendor.WeekdayCity || ""}, ${vendor.WeekdayState || ""} ${vendor.WeekdayZip || ""}`}</small>
                                            </div>
                                        </div>
                                    </div>
                                    <div style={{ textAlign: "center" }}>
                                        <button className="btn btn-small error-color" onClick={() => this.handleRemoveCurrentVendor()}>Remove Current
                                    Vendor</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col s6 m2">
                                <button ref={(cancelButtion) => { this.cancelButtion = cancelButtion; }} className="btn white action-btn w-100"
                                    onClick={() => {
                                        this.setState({ isOpen: false });
                                    }}
                                >CANCEL</button>
                            </div>
                            <div className="col s6 m2">
                                <button disabled className="btn success-color w-100">AUTO ASSIGN</button>
                            </div>
                            <div className="col s6 m2">
                                <button disabled className="btn success-color w-100">SEND OFFER</button>
                            </div>
                            <div className="col s6 m3">
                                <button disabled className="btn success-color w-100">Request Fee Increase</button>
                            </div>
                            <div className="col s6 m3">
                                <button disabled className="btn success-color w-100">ASSIGN VENDOR</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}


VendorReAssignModal.propTypes = {
    orderId: PropTypes.number,
    onRemoveVendor: PropTypes.func,
    dispatch: PropTypes.func,
    userName: PropTypes.string,
    accountId: PropTypes.number
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { accountId } = authentication;
    return {
        accountId,
        userName: authentication.profile.userName
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(VendorReAssignModal);
