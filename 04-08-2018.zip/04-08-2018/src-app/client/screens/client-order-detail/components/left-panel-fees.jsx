import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";

import { getOrderDetailLeftPanelFeeInitData, saveLeftPanelFees, resetLeftPanelFeeStatus } from "../actions/left-panel-actions";
import { switchModuleOnMainPanel } from "../actions/main-panel-actions";
import { getOrderRequestedFee } from "../actions/main-panel-fee-requested-action";

import Select from "Select";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "../../../features/modal";

import CommonModal from "CommonModal";
import ApprovalModal from "./main-panel-approval-modal";

import { CLIENT_SUB_ROLE, ORDER_REQUEST_APPROVE_STATUS, USER_TYPE } from "Constants";
import { ORDER_DETAIL_PROGRESS } from "../../../constant/order-detail-constants";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import { requireMessage } from "Helpers/validation-helper";
import { hasStringValue, thousandSep } from "../../../helpers/common-helper";
import { listenOnSubmitFeeRequest, stopListenOnSubmitFeeRequest } from "../../../socket/orders";
import moment from "moment";
import { ACTION } from "../../../constant/progress-log-constants";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { ROOM_RENTAL_FEE_DESCRIPTION } from "../../../constant/constants";
import NumberFormat from "react-number-format";
///ucs26
import FeeApprovalVendorModal from "../../staff-order-detail/components/fee-approval-request-vendor-fee-modal";
import FeeApprovalClientModal from "../../staff-order-detail/components/fee-approval-request-client-fee-modal";
import { ROLE_NAMES } from "../../../constant/role-constants";

class LeftPanelFees extends Component {
    constructor(props) {
        super(props);

        this.state = {
            productType: {
                isSaving: false,
                isEditing: false,
                value: ""
            },
            additional: {
                isSaving: false,
                isEditing: false,
                value: []
            },
            vendorFees: {
                isSaving: false,
                isEditing: false,
                isShow: false,
                value: ""
            },
            clientFees: {
                isSaving: false,
                isEditing: false,
                isShow: false,
                value: ""
            },
            isOpenConfirmationFee: false,
            isOpenRequestFeeModal: false,
            mainFee: 0,
            roomRentalVendorFee: 0,
            //ucs26
            isOpenFeeStaffModal: false,
            isOpenClientFeeApproval: false,
            isDirtyModal: false
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentWillReceiveProps(nextProps) {
        const { listSelectedAdditionalRequest } = nextProps.fee;
        const { fee } = nextProps;
        const { order } = fee;

        if (this.props.fee.isSaving && !fee.isSaving && fee.isSuccess) {
            this.loadInitData();

            this.setState({
                isOpenConfirmationFee: !fee.isSaving && fee.status === "EXCEED"
            });
        }

        let roomRentalVendorFee = 0.00;
        const roomRentalFees = listSelectedAdditionalRequest.find((item) => {
            return item.FeeDescription.includes(ROOM_RENTAL_FEE_DESCRIPTION);
        });

        if (roomRentalFees) {
            roomRentalVendorFee = roomRentalFees.SignerFee || 0;
        }


        if (this.props.fee !== fee) {
            this.defaultAdditionalRequest = JSON.stringify(listSelectedAdditionalRequest);
            this.defaultLoanType = JSON.stringify(order.loanTypeId);
            this.defaultSignerFee = JSON.stringify(order.signerFee);
            this.defaultBrokerFee = JSON.stringify(order.brokerFee);

            this.setState({
                additional: {
                    ...this.state.additional,
                    isEditing: false,
                    isShow: false,
                    value: listSelectedAdditionalRequest,
                    originValue: listSelectedAdditionalRequest,
                    name: "additional"
                },
                productType: {
                    ...this.state.productType,
                    isEditing: false,
                    isShow: false,
                    value: order.loanTypeId,
                    originValue: order.loanTypeId,
                    name: "productType"
                },
                vendorFees: {
                    ...this.state.vendorFees,
                    isEditing: false,
                    isShow: false,
                    value: order.signerFee,
                    originValue: order.signerFee,
                    name: "vendorFees"
                },
                clientFees: {
                    ...this.state.clientFees,
                    isEditing: false,
                    isShow: false,
                    value: order.brokerFee,
                    originValue: order.brokerFee,
                    name: "clientFees"
                },
                roomRentalVendorFee
            });
        }
    }

    componentDidMount() {
        listenOnSubmitFeeRequest(() => {
            this.loadInitData();
        });

        this.loadInitData();
    }

    componentWillUnmount() {
        stopListenOnSubmitFeeRequest();
    }

    componentDidUpdate() {
        const { fee } = this.props;
        const { status, isSaving } = fee;

        if (!isSaving && status === "EXCEED") {
            // show modal
            this.handleAfterSaveFee();
        }

        if ($("#vendor-fee") && $("#vendor-fee").length > 0) {
            $("#vendor-fee").focus();

            // $("html, body").animate({
            //     scrollTop: $("#vendor-fee").offset().top
            // }, 2000);
        }
    }

    loadInitData() {
        const { dispatch, orderId } = this.props;

        dispatch(getOrderDetailLeftPanelFeeInitData(orderId));
        dispatch(getOrderRequestedFee(orderId));
    }

    handleClickEdit(e, obj) {
        e.preventDefault();
        obj.isEditing = true;

        this.setState({ obj });
    }

    handleClickLoanTypesEdit() {
        const { fee } = this.props;

        this.setState({
            productType: {
                ...this.state.productType,
                value: fee.order.loanTypeId,
                isEditing: true
            }, isDirtyModal: false
        });
    }

    handleClickAdditionalFeesEdit() {
        this.setState({
            additional: {
                ...this.state.additional,
                isEditing: true
            }, isDirtyModal: false
        });
    }

    handleCancel(obj) {
        switch (obj.name) {
            case "additional":
                this.setState({
                    additional: {
                        ...this.state.additional,
                        isEditing: false,
                        value: JSON.parse(this.defaultAdditionalRequest)
                    }
                });
                break;
            case "productType":
                this.setState({
                    productType: {
                        ...this.state.productType,
                        isEditing: false,
                        value: JSON.parse(this.defaultLoanType)
                    }
                });
                break;
            case "vendorFees":
                this.setState({
                    vendorFees: {
                        ...this.state.vendorFees,
                        isEditing: false,
                        value: JSON.parse(this.defaultSignerFee)
                    }
                });
                break;
            case "clientFees":
                this.setState({
                    clientFees: {
                        ...this.state.clientFees,
                        isEditing: false,
                        value: JSON.parse(this.defaultBrokerFee)
                    }
                });
                break;
        }
    }

    handleSave() {
        const { additional, vendorFees, clientFees } = this.state;
        const { roleNames, fee } = this.props;
        const { order } = fee;

        let type = "loanType";

        if (additional.isEditing) type = "additionalRequest";
        if (vendorFees.isEditing) type = "vendorFees";
        if (clientFees.isEditing) type = "clientFees";

        switch (type) {
            case "clientFees": {
                if (Number(this.state.clientFees.value) === Number(this.state.clientFees.originValue)) return;

                // if login user is TCE Admin or TCE Operation Manager, they can change fee
                if (roleNames.includes(ROLE_NAMES.STAFF_ADMIN) || roleNames.includes(ROLE_NAMES.STAFF_OPERATIONAL_MANAGER)) {
                    this.saveFee();
                    return;
                }

                // other tce staff must make a fee request
                this.commonModal.showModal({
                    type: "confirm",
                    message: "Are you sure you would like to submit this change to your Manager for approval?"
                }, () => {
                    this.setState({
                        isOpenClientFeeApproval: true
                    });

                }, () => {
                    this.setState({
                        clientFees: {
                            ...this.state.clientFees,
                            isEditing: false,
                            value: JSON.parse(this.defaultBrokerFee)
                        }
                    });
                    return;
                });

                break;
            }
            default: {
                if (Number(this.state.vendorFees.value) !== Number(order.signerFee) || type === "additionalRequest") {
                    this.saveFee();
                    break;
                }
            }
        }
    }

    saveFee() {
        const { productType, additional, vendorFees, clientFees } = this.state;
        const { dispatch, fee, roleNames, userName, orderId, accountId } = this.props;
        const { order } = fee;

        let type = "loanType";

        if (additional.isEditing) type = "additionalRequest";
        if (vendorFees.isEditing) type = "vendorFees";
        if (clientFees.isEditing) type = "clientFees";

        const fees = [];

        additional.value.map((item) => {
            if (item.FeeDescription.includes(ROOM_RENTAL_FEE_DESCRIPTION)) {
                fees.push({
                    ...item,
                    SignerFee: Number(this.state.roomRentalVendorFee || 0)
                });
            } else {
                fees.push(item);
            }
        });

        const inputs = {
            fees,
            loanTypeId: productType.value,
            vendorFee: vendorFees.value,
            clientFee: clientFees.value,
            brokerId: order.brokerId,
            gid: order.gid,
            orderId: order.orderId,
            type,
            roleNames
        };

        const listLoanTypes = this.props.fee.listLoanTypes;
        const loanType = listLoanTypes.find(x => x.LoanTypeId.toString() === this.state.productType.value.toString());
        let activity = "";
        if (productType.isEditing || additional.isEditing) {
            activity = productType.isEditing ? `${userName} updated product type to ${loanType.LoanType}` : `${userName} updated additional fees`;
        } else {
            activity = `${userName} updated fees`;
        }

        const log = {
            OrderId: orderId,
            Activity: activity,
            UsersId: accountId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            ProgressType: ACTION
        };

        // save the fees
        dispatch(saveLeftPanelFees({ inputs }, log));
    }

    handleOnchangeAdditionalFee(value, ele) {
        const { additional } = this.state;

        if (value) {
            // add the new one
            additional.value.push({
                FeeDescripID: ele.FeeId,
                FeeDescription: ele.FeeDescription,
                SignerFee: ele.VendorFee
            });
        } else {
            // remove the existing one
            additional.value = additional.value.filter((item) => {
                return item.FeeDescripID !== ele.FeeId;
            });
        }

        this.setState({
            additional: {
                ...this.state.additional,
                value: additional.value
            }, isDirtyModal: true
        });
    }

    handleViewRequestFee(e) {
        e.preventDefault();
        // hide communication module and show fee requests module
        const { dispatch, orderId } = this.props;
        dispatch(switchModuleOnMainPanel("FEE"));
    }

    handleAfterSaveFee() {
        const { roleType } = this.props;

        this.commonModal.showModal({
            type: "confirm",
            message: "This fee amount exceeds 10% compared to the original fee. You must get manager's approval - Request Approval?"
        }, () => {
            if (roleType === "Staff") {
                this.setState({
                    isOpenFeeStaffModal: true
                });
            } else {
                this.setState({
                    isOpenRequestFeeModal: true
                });
            }

        }, () => {

        });

        const { dispatch } = this.props;

        dispatch(resetLeftPanelFeeStatus());

        return false;
    }

    handleCloseFeeRequestModal() {
        this.setState({
            isOpenFeeStaffModal: false,
            isOpenClientFeeApproval: false,
            isOpenRequestFeeModal: false
        });
    }

    handleVendorFeeBlur(value) {
        this.setState({
            ...this.state,
            roomRentalVendorFee: value
        });
    }

    render() {
        const { fee, requestedFeeData, clientType, orderInfo, roleType } = this.props;
        const { productType, additional, vendorFees, clientFees, isOpenRequestFeeModal, isOpenFeeStaffModal, isOpenClientFeeApproval } = this.state;
        const { listSelectedAdditionalRequest, listLoanTypes, listAdditionalRequest, order } = fee;

        const mapAdditionalRequests = additional.value.map((item, index) => {
            // AnnV2: in case client logged, if order is self service, only display vendor fee. If order is full service, the client only can see client fee
            return (
                <div key={index}>
                    <strong className="left left-align" style={{ maxWidth: "60%" }}>{item.FeeDescription}</strong>
                    <span>{`$${thousandSep(parseFloat(order.isSelfService ? item.SignerFee || 0 : item.BrokerFee || 0).toFixed(2))}`}</span>
                    <div className="clear"></div>
                </div>);
        });

        const mapAdditionalRequestsStaff = additional.value.map((item, index) => {
            return (
                <div key={index} className="row mb-1">
                    <div className="col s6 m6 left-align"><strong className="left">{item.FeeDescription}</strong></div>
                    <div className="col s3 m3 right-align">{`$${thousandSep(parseFloat(item.SignerFee).toFixed(2))}`}</div>
                    <div className="col s3 m3 right-align">{`$${thousandSep(parseFloat(item.BrokerFee).toFixed(2))}`}</div>
                </div>
            );
        });

        const feeRequests = [
            {
                orderId: order.orderId,
                signerId: order.signerId,
                originalAmount: order.originalSignerFee,
                vendorName: order.vendorName,
                feeDescripId: order.mainFeeDescripId,
                requestedFee: this.state.requestedFee,
                //
                brokerFee: order.brokerFee,
                clientName: order.BrokerCompany,
                vendorFee: order.vendorFee,
                brokerId: order.brokerId,
                signerFee: order.signerFee
            }
        ];

        const currencyFormat = (value) => `$${value || 0}.00`;

        const renderEditButton = (obj, editHanlder, isSwitch) => {
            const { isEditing, isSaving } = obj;
            if (orderInfo.progressId !== undefined) {
                if (ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closing Completed" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending QC Review" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending Review/PC Resolution") {
                    return "";
                }
            }

            if (isEditing) {
                if (isSwitch) {
                    return (
                        <div>
                            <button disabled={isSaving ? "disabled" : ""} className="btn btn-s-small success-color mr-1" onClick={() => this.handleSave()}>
                                <span className="lnr lnr-checkmark-circle"></span>
                            </button>
                            <button disabled={isSaving ? "disabled" : ""} className="btn btn-s-small error-color mr-1" onClick={() => this.handleCancel(obj)}>
                                <span className="lnr lnr-cross-circle"></span>
                            </button>
                        </div>
                    );
                } else {
                    return (
                        <span className="cursor-pointer right order-edit" disabled><i className="lnr lnr-pencil"></i></span>
                    );
                }
            } else {
                return (
                    <span className="cursor-pointer right order-edit ml-1" onClick={(e) => editHanlder(e, obj)}>
                        <i className="lnr lnr-pencil"></i>
                    </span>
                );
            }
        };

        const renderAdditionalRequest = () => {
            return listAdditionalRequest.map((item, index) => {
                if (item.LoanTypeId === order.loanTypeId) {
                    const found = additional.value.find((i) => i.FeeDescripID === item.FeeId);
                    let isCheck = false;

                    if (found) isCheck = true;

                    // AnNV2: Only show room rental vendor fee when order is self service or user is TCE staff
                    const isShowRoomRentalFee = item.FeeDescription.includes(ROOM_RENTAL_FEE_DESCRIPTION) && (order.isSelfService || roleType === USER_TYPE.Staff);

                    return (
                        <div className="row mb-0">
                            <div className={`col ${item.FeeDescription.includes(ROOM_RENTAL_FEE_DESCRIPTION) ? "s6" : "s12"}`}>
                                <p key={index}>
                                    <label>
                                        <input type="checkbox"
                                            checked={isCheck}
                                            onChange={e => this.handleOnchangeAdditionalFee(e.target.checked, item)}
                                        />
                                        <span>{item.FeeDescription}</span>
                                    </label>
                                </p>
                            </div>
                            {isShowRoomRentalFee &&
                                <div className="col s3">
                                    <NumberFormat
                                        id="orderDetailRoomRentalVendorFee"
                                        thousandSeparator
                                        fixedDecimalScale
                                        prefix={"$"}
                                        decimalScale={2}
                                        ref="orderDetailRoomRentalVendorFee"
                                        style={{ height: "1.5rem", marginBottom: "0px" }}
                                        placeholder="Vendor fee"
                                        value={this.state.roomRentalVendorFee}
                                        onBlur={() => this.handleVendorFeeBlur(this.refs.orderDetailRoomRentalVendorFee.state.numAsString)}
                                    />
                                </div>}
                        </div>
                    );
                } else {
                    return "";
                }
            });
        };

        const selectedLoanType = () => {
            // find the default loan type
            const foundLoanType = listLoanTypes.find((i) => {
                return i.LoanTypeId === order.loanTypeId;
            });

            return foundLoanType || {};
        };

        const renderViewFeeRequestAlertBubbleForClient = () => {
            let iAgentRequest = 0;
            let iVendorRequest = 0;

            requestedFeeData.forEach(element => {
                if (element.status === ORDER_REQUEST_APPROVE_STATUS.OPEN) {
                    if (element.requestedByVendor && element.agentId) {
                        iVendorRequest++;
                    } else {
                        iAgentRequest++;
                    }
                }
            }
            );

            if (clientType === CLIENT_SUB_ROLE.AGENT) {
                if (iVendorRequest !== 0) {
                    return (
                        <span className="new badge alert badge-group">{iVendorRequest}</span>
                    );
                } else {
                    return null;
                }
            } else if (iAgentRequest !== 0) {
                return (
                    <span className="new badge alert badge-group">{iAgentRequest}</span>
                );
            } else {
                return null;
            }
        };

        const renderViewFeeRequestAlertBubbleForTce = () => {
            const { requestedFeeData, roleNames } = this.props;

            const vendorFeeRequest = requestedFeeData.filter((fee) => {
                return fee.userType === 'Vendor' && !fee.isClientFee
            });

            const schedulerVendorFeeRequest = requestedFeeData.filter((fee) => {
                return fee.userType === 'Staff' && !fee.isClientFee
            });

            const schedulerClientFeeRequest = requestedFeeData.filter((fee) => {
                return fee.userType === 'Staff' && fee.isClientFee
            });

            let iOpenVendorRequestedVendorFee = 0;
            let iOpenSchedulerRequestedVendorFee = 0;
            let iOpenSchedulerRequestedClientFee = 0;
            let requestedCounter = 0;

            // count open vendor fee request that submitted by Vendor
            vendorFeeRequest.forEach(element => {
                if (element.status === ORDER_REQUEST_APPROVE_STATUS.OPEN) {
                    iOpenVendorRequestedVendorFee++;
                }
            });

            // count open vendor fee request that submitted by TCE Scheduler
            schedulerVendorFeeRequest.forEach(element => {
                if (element.status === ORDER_REQUEST_APPROVE_STATUS.OPEN) {
                    iOpenSchedulerRequestedVendorFee++;
                }
            });

            // count open client fee request that submitted by TCE Scheduler
            schedulerClientFeeRequest.forEach(element => {
                if (element.status === ORDER_REQUEST_APPROVE_STATUS.OPEN) {
                    iOpenSchedulerRequestedClientFee++;
                }
            });

            // if current user is tce scheduler, he can see all requested fees
            // if current user is tce admin, he can see requested fees that submitted from tce scheduler
            if (roleNames.includes(ROLE_NAMES.STAFF_SCHEDULER)) {
                requestedCounter = iOpenVendorRequestedVendorFee + iOpenSchedulerRequestedVendorFee + iOpenSchedulerRequestedClientFee;
            } else {
                requestedCounter = iOpenSchedulerRequestedVendorFee + iOpenSchedulerRequestedClientFee;
            }

            if (requestedCounter !== 0) {
                return (
                    <span className="new badge alert badge-group">{requestedCounter}</span>
                );
            } else {
                return null;
            }
        };

        const rendorForClient = () => {
            // AnnV2: in case client logged, if order is self service, only display vendor fee. If order is full service, the client only can see client fee
            return (
                <div>
                    <div className="row mt-1">
                        <div className="col s4 m4 left-align">
                            <span className="left">Product type</span>
                        </div>
                        <div className="col s8 m8 right-align">
                            <strong style={{ maxWidth: "60%" }} className="left">{selectedLoanType().LoanType}</strong>
                            <span>{`$${thousandSep(parseFloat(order.isSelfService ? order.mainFee || 0 : order.mainBrokerFee || 0).toFixed(2))}`}</span>

                            {/* annv2: if order is full service, client should not see edit fee button */}
                            {order.isSelfService ? renderEditButton(productType, (e, obj) => this.handleClickLoanTypesEdit(e, obj)) : null}
                        </div>
                        {/* <div className="col m1">
                    </div> */}
                    </div>
                    <div className="clear"></div>

                    <div className="row additionnal-fee-panel">
                        <div className="col s4 m4 left-align">
                            <span className="left">Additional</span>
                        </div>
                        <div className="col s8 m8 right-align">
                            {listSelectedAdditionalRequest.length > 0 && mapAdditionalRequests}

                            {/* annv2: if order is full service, client should not see edit fee button */}
                            {order.isSelfService ? renderEditButton(additional, (e, obj) => this.handleClickAdditionalFeesEdit(e, obj)) : null}
                        </div>

                    </div>
                    <div className="clear"></div>

                    {/* annv2: this section only display when order is self service */}
                    {order.isSelfService &&
                        <div>
                            <div className="row">
                                <div className="col s4 m4 left-align">
                                    <span className="left">Vendor fees</span>
                                </div>
                                <div className="col s8 m8 right-align">
                                    {!vendorFees.isEditing &&
                                        <span ><strong>{currencyFormat(order.signerFee)} total</strong></span>
                                    }
                                    {vendorFees.isEditing &&
                                        <input
                                            type="text"
                                            className="form-control" name="vendor-fee" id="vendor-fee"
                                            onBlur={(e) => this.setState({
                                                vendorFees: {
                                                    ...this.state.vendorFees,
                                                    originValue: this.state.vendorFees.value,
                                                    value: e.target.value
                                                },
                                                requestedFee: e.target.value
                                            })}
                                            maxLength="6"
                                            ref="vendorFee" defaultValue={order.signerFee}
                                        />
                                    }

                                    {renderEditButton(vendorFees, () => {
                                        this.setState({
                                            vendorFees: {
                                                ...this.state.vendorFees,
                                                isEditing: true
                                            }
                                        });
                                    }, true)}
                                </div>

                            </div>
                            <div className="clear"></div>

                            <div className="row s12"><div className="divider"></div></div>
                            <div className="center-align">
                                <button
                                    type="button"
                                    className="btn btn-small success-color"
                                    onClick={(e) => (this.handleViewRequestFee(e))}
                                >
                                    <span className="valign-wrapper" style={{ display: "flex" }}>
                                        VIEW FEE REQUESTS
                                    {renderViewFeeRequestAlertBubbleForClient()}
                                    </span>
                                </button>
                            </div>
                        </div>
                    }
                </div>
            );
        };

        const rendorForStaff = () => {
            return (
                <div>
                    <div className="row mt-1 mb-0">
                        <div className="col s11 m11">
                            <div className="row">
                                <div className="col s6 m6 left-align"></div>
                                <div className="col s3 m3 right-align">Vendor</div>
                                <div className="col s3 m3 right-align">Client</div>
                            </div>
                        </div>
                        <div className="col s1 m1"></div>
                        <div className="clear"></div>

                        <div className="col s11 m11">
                            <div className="row">
                                <div className="col s6 m6 left-align"><strong className="left">{selectedLoanType().LoanType}</strong></div>
                                <div className="col s3 m3 right-align">{`$${thousandSep(parseFloat((order).mainFee).toFixed(2))}`}</div>
                                <div className="col s3 m3 right-align">{`$${thousandSep(parseFloat((order).mainBrokerFee).toFixed(2))}`}</div>
                            </div>
                        </div>
                        <div className="col s1 m1"><span>{renderEditButton(productType, (e, obj) => this.handleClickLoanTypesEdit(e, obj))}</span></div>
                        <div className="clear"></div>

                        <div className="col s11 m11">
                            {listSelectedAdditionalRequest.length > 0 && mapAdditionalRequestsStaff}
                            {listSelectedAdditionalRequest.length === 0 && <strong className="left">Additional Fee</strong>}
                        </div>
                        <div className="col s1 m1 right-align"><span>{renderEditButton(additional, (e, obj) => this.handleClickAdditionalFeesEdit(e, obj))}</span></div>
                    </div>

                    <hr />
                    <div className="row">
                        <div className="col s11 m11">
                            <div className="row">
                                <div className="col s6 m6 left-align"><strong className="left">Total</strong></div>
                                <div className="col s3 m3 right-align" onMouseOver={() => { this.setState({ vendorFees: { ...vendorFees, isShow: true } }); }}
                                    onMouseOut={() => { this.setState({ vendorFees: { ...vendorFees, isShow: false } }); }}
                                >
                                    {!vendorFees.isEditing && <strong>{`$${thousandSep(parseFloat(order.signerFee).toFixed(2))}`}</strong>}
                                    <span style={{ display: ((vendorFees.isShow || vendorFees.isEditing) ? "" : "none") }}>{renderEditButton(vendorFees, () => {
                                        if (!clientFees.isEditing) this.setState({ vendorFees: { ...this.state.vendorFees, isEditing: true } });
                                    }, true)}</span>
                                </div>
                                <div className="col s3 m3 right-align" onMouseOver={() => { this.setState({ clientFees: { ...clientFees, isShow: true } }); }}
                                    onMouseOut={() => { this.setState({ clientFees: { ...clientFees, isShow: false } }); }}
                                >
                                    {!clientFees.isEditing && <strong>{`$${thousandSep(parseFloat(order.brokerFee).toFixed(2))}`}</strong>}
                                    <span style={{ display: ((clientFees.isShow || clientFees.isEditing) ? "" : "none") }}>{renderEditButton(clientFees, () => {
                                        if (!vendorFees.isEditing) this.setState({ clientFees: { ...this.state.clientFees, isEditing: true } });
                                    }, true)}</span>
                                </div>
                                {(vendorFees.isEditing) &&
                                    <div className="col s12">
                                        <input
                                            type="text"
                                            className="form-control" name="vendor-fee" id="vendor-fee"
                                            onBlur={(e) => this.setState({
                                                vendorFees: {
                                                    ...this.state.vendorFees,
                                                    originValue: this.state.vendorFees.value,
                                                    value: e.target.value
                                                },
                                                requestedFee: e.target.value
                                            })}
                                            maxLength="6"
                                            ref="vendorFee" defaultValue={order.signerFee}
                                        />
                                    </div>
                                }
                                {(clientFees.isEditing) &&
                                    <div className="col s12">
                                        <input
                                            type="text"
                                            className="form-control" name="client-fee" id="client-fee"
                                            onBlur={(e) => this.setState({
                                                clientFees: {
                                                    ...this.state.clientFees,
                                                    originValue: this.state.clientFees.value,
                                                    value: e.target.value
                                                },
                                                requestedFee: e.target.value
                                            })}
                                            maxLength="6"
                                            ref="clientFee" defaultValue={order.brokerFee}
                                        />
                                    </div>
                                }
                            </div>
                        </div>

                    </div>
                    <div className="clear"></div>

                    <div className="row s12"><div className="divider"></div></div>
                    <div className="center-align">
                        <button
                            type="button"
                            className="btn btn-small success-color"
                            onClick={(e) => (this.handleViewRequestFee(e))}
                        >
                            <span className="valign-wrapper">
                                VIEW FEE REQUESTS
                            {renderViewFeeRequestAlertBubbleForTce()}
                            </span>
                        </button>
                    </div>
                </div>
            );
        };

        return (
            <div>
                {/* Render fee request for client - order self service*/}
                {roleType === "Client" && rendorForClient()}
                {/* Render fee request for staff - order full service*/}
                {roleType === "Staff" && rendorForStaff()}

                {/* {isOpenRequestFeeModal && */}
                <ApprovalModal
                    isShow={isOpenRequestFeeModal}
                    mode="FEE_REQUETS"
                    feeRequests={feeRequests}
                    onClose={() => this.handleCloseFeeRequestModal()}
                    fromFeeTab
                />
                {/* } */}

                {/* UCS26: modal for vendor fee request */}
                <FeeApprovalVendorModal
                    isShow={isOpenFeeStaffModal}
                    mode="FEE_REQUETS"
                    feeRequests={feeRequests}
                    onClose={() => this.handleCloseFeeRequestModal()}
                    fromFeeTab
                />
                {/* UCS26: modal for client fee request */}
                <FeeApprovalClientModal
                    isShow={isOpenClientFeeApproval}
                    mode="FEE_REQUETS"
                    feeRequests={feeRequests}
                    onClose={() => this.handleCloseFeeRequestModal()}
                />

                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />

                <Modal id="update-fee-modal" isOpen={productType.isEditing || additional.isEditing} fixedFooter={false} addClass="modal-small">
                    <ModalBody>
                        <ModalTitle>{productType.isEditing ? "Select Product Type" : "Select Additional Requests"}</ModalTitle>
                        <div className="col s12 p-0">
                            <div className="card box-shadow-none">
                                <div className="card-content p-0">
                                    <div className="row">
                                        <div className={`input-field col s12 pl-1 suffixinput ${!hasStringValue(this.state.productType.value) ? `required-field` : null}`}>
                                            {productType.isEditing &&
                                                <div>
                                                    <Select
                                                        dataSource={listLoanTypes}
                                                        optionDefaultLabel={"Select..."}
                                                        mapDataToRenderOptions={{ value: "LoanTypeId", label: "LoanType" }}
                                                        id="fee-loan-type-select"
                                                        value={productType.value}
                                                        onChange={(val) => {
                                                            this.setState({
                                                                productType: {
                                                                    ...this.state.productType,
                                                                    value: val
                                                                }, isDirtyModal: true
                                                            });
                                                        }}
                                                    />
                                                    <span className={`suffix-text mr-1 ${!hasStringValue(this.state.productType.value) ? "" : "hide"}`}>
                                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Product Type")} />
                                                    </span>
                                                </div>
                                            }
                                            {additional.isEditing &&
                                                <div>
                                                    {renderAdditionalRequest()}
                                                </div>
                                            }
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col m6">
                                <button type="button" className="btn w-100 white" onClick={() => this.handleCancel(productType.isEditing ? productType : additional)}>Cancel</button>
                            </div>
                            <div className="col m6">
                                <button type="button" className="btn success-color w-100" onClick={() => this.handleSave()} disabled={(!hasStringValue(this.state.productType.value) && productType.isEditing) || !this.state.isDirtyModal}>Save</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
            </div >
        );
    }
}

LeftPanelFees.propTypes = {
    fee: PropTypes.object,
    isFetching: PropTypes.bool,
    dispatch: PropTypes.func,
    orderId: PropTypes.number,
    orderInfo: PropTypes.object,
    roleNames: PropTypes.array,
    roleType: PropTypes.string,
    requestedFeeData: PropTypes.array,
    clientType: PropTypes.string,
    userName: PropTypes.string,
    accountId: PropTypes.number
};

const mapStateToProps = (state) => {
    const { clientOrderDetail, authentication } = state;
    const { leftPanelFee, leftPanel } = clientOrderDetail;

    const { role, profile, accountId } = authentication;
    const { roleNames, roleType } = role;
    const clientType = authentication.profile.subRoleType;

    const {
        fee
    } = leftPanelFee;

    const { orderInfo } = leftPanel;
    const { mainPanelFeeRequestReducers } = clientOrderDetail;
    const { requestedFeeData } = mainPanelFeeRequestReducers;
    const { userName } = profile;
    return {
        fee,
        roleNames,
        roleType,
        requestedFeeData,
        clientType,
        userName,
        accountId,
        orderInfo
    };
};

export default connect(mapStateToProps)(LeftPanelFees);