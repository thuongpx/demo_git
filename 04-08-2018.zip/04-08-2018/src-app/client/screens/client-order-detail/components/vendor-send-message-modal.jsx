import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import flyImg from "./../../../public/images/fly.svg";
import {
    Modal,
    ModalBody,
    ModalTitle
} from "Modal";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class VendorSendMessageModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false,
            vendorName: this.props.vendorName
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    show() {
        this.setState({ isOpen: true });
        this.refs.message.value = "";
    }

    hide() {
        this.setState({ isOpen: false });
    }

    handleOpenModalEnd() {
        this.refs.message.focus();
    }

    render() {
        const { isOpen, vendorName } = this.state;

        const modalOptions = {
            onOpenEnd: () => this.handleOpenModalEnd()
        };

        return (
            <div id="vendorSendMessage">
                <Modal isOpen={isOpen} modalOptions={modalOptions}>
                    <ModalBody>
                        <ModalTitle onClickClose={() => { this.hide(); }}>Assign a Vendor</ModalTitle>
                        <div style={{ color: "black" }}>
                            <div className="row">
                                <div className="col s1 p-0">
                                    <strong>To:</strong>
                                </div>
                                <div className="col s11">
                                    <span>{vendorName}</span>
                                </div>
                            </div>
                            <hr />
                            <div className="row">
                                <div className="col s10 p-0">
                                    <div className="input-field col s12 p-0">
                                        <textarea
                                            ref="message"
                                            style={{ minHeight: 135 }}
                                            type="text"
                                            id="contactNotes"
                                            className="validate materialize-textarea"
                                            placeholder="Enter Message"
                                        ></textarea>
                                    </div>
                                </div>
                                <div className="col s2">
                                    <br />
                                    <div className="row">
                                        <button style={{ position: "relative", top: "-10px" }} className="btn white w-100" onClick={() => this.hide()}>Cancel</button>
                                    </div>
                                    <div className="row blue-text" style={{ textAlign: "center" }}>
                                        <button style={{ position: "relative", top: "-30px" }} className="button-custom-style" onClick={() => this.hide()}><img src={flyImg} /></button>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </ModalBody>
                </Modal>
            </div>
        );
    }
}


VendorSendMessageModal.propTypes = {
    params: PropTypes.object,
    router: PropTypes.object,
    dispatch: PropTypes.func,
    vendorName: PropTypes.string
};

export default connect(null, null, null, { withRef: true })(VendorSendMessageModal);