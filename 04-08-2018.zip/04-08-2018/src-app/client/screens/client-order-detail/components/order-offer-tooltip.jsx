import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import GridView from "GridView";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class OrderOfferTooltip extends Component {
    constructor(props) {
        super(props);
        this.state = {
            datasources: [
                {
                    orderId: 1,
                    type: "Full Purchase",
                    aptDateTime: "2018-03-31 16:00 AM",
                    city: "Dallas",
                    zip: "75287",
                    distance: "10 miles",
                    faxBack: "Yes"
                }
            ]
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {
        return (
            <div className="orderOfferTooltip">
                <GridView
                    criteria={{}}
                    totalRecords={0}
                    datasources={this.state.datasources}
                    columns={this.props.columns}
                    identifier={"OfferID"}
                    allowPaging={false}
                    allowSorting={false}
                />
            </div>
        );
    }
}

OrderOfferTooltip.defaultProps = {
    columns: [
        {
            title: "Order ID",
            data: "orderId"
        },
        {
            title: "Type",
            data: "type"
        },
        {
            title: "Appt. Date and Time ",
            data: "aptDateTime"
        },
        {
            title: "City",
            data: "city"
        },
        {
            title: "Zip",
            data: "zip"
        },
        {
            title: "Distance",
            data: "distance"
        },
        {
            title: "Fax Back?",
            data: "faxBack"
        }
    ]
};

OrderOfferTooltip.propTypes = {
    dispatch: PropTypes.func,
    vendorId: PropTypes.number,
    isShowButton: PropTypes.bool,
    onSendMessage: PropTypes.func,
    orderId: PropTypes.number,
    aptDateTime: PropTypes.string,
    columns: PropTypes.array,
    onAssignVendor: PropTypes.func
};

export default OrderOfferTooltip;