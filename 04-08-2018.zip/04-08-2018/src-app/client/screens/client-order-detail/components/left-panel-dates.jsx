import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import moment from "moment";
import { showSuccess } from "../../main-layout/actions";
import { handleApiError } from "ErrorHandler";
import { updateLeftPanel } from "../actions/left-panel-actions";
import { LIST_TIMEZONE_US } from "../../../constant/constants";

class LeftPanelDates extends Component {
    constructor(props) {
        super(props);

        this.state = {
            inputs: {
                droppedDate: "",
                droppedTime: ""
            },
            droppedEditing: {
                isSaving: false,
                isEditing: false,
                value: "",
                name: "droppedDateTime"
            },
            invalidField: {}
        };
    }

    handleChange(field, value) {
        const { dispatch, orderId } = this.props;
        const rawData = {
            OrderId: orderId,
            type: field
        };
        switch (field) {
            case "Status Representative":
                rawData.StatusID = parseInt(value);
                break;
            case "Quality Control":
                rawData.QCID = parseInt(value);
                break;
        }

        dispatch(updateLeftPanel(rawData, () => {
            dispatch(showSuccess(`Updated ${field}.`));
        }, (error) => {
            handleApiError(dispatch, error);
        }));
    }

    isTCEAdminManager() {
        const { roleNames } = this.props;
        let ret = false;
        if (roleNames.length > 0) {
            roleNames.forEach(item => {
                if (item === "Admin" || item === "Operational Manager") {
                    ret = true;
                }
            });
        }
        return ret;
    }

    getEmployeeName(list, value) {
        let ret = "";
        if (list.length > 0) {
            list.forEach(item => {
                if (item.RepId === value) ret = item.FullName;
            });
        }
        return ret;
    }

    render() {
        const { orderInfo } = this.props;

        let timeZoneAbv = "";
        LIST_TIMEZONE_US.map((item) => {
            if (orderInfo.aptUTC && item.UTC === orderInfo.aptUTC.toString()) {
                timeZoneAbv = item.abv;
            }
            return item;
        });

        const d = new Date();
        const n = -(d.getTimezoneOffset() / 60);
        const currentTimezone = `${n < 0 ? `${n}` : `+${n}`}`;
        let currentTimeZoneAbv = "";
        LIST_TIMEZONE_US.map((item) => {
            if (item.UTC === currentTimezone) {
                currentTimeZoneAbv = item.abv;
            }
            return item;
        });

        const date = moment(orderInfo.aptDateTime).utc();
        const aptDateTime = `${date.isValid() ? `${date.format("MM/DD/YYYY @ h:mm A")}` : ""}`;

        return (
            <div className="row">
                <div className="tab-wrap st2 panel-order-detail row box-shadow-st2 p-0 mt-2 pb-2">
                    <div className="col s12 p-0">
                        <ul className="tabs">
                            <li className={`tab col active`} >
                                <a style={{ cursor: "pointer" }}>DATES</a>
                            </li>
                        </ul>
                    </div>
                    <div className="col s12 p-0">
                        <div className="row tab-content">
                            <div className="col s5 mt-1">Order Date</div>
                            <div className="col s7 mt-1">{orderInfo.orderDate ? moment(orderInfo.orderDate).format("MM/DD/YYYY @ h:mm A") : "---"}</div>
                            <div className="col s12 smaller-text">Date and Time the order was entered into the system</div>
                            <div className="clear"></div>

                            <div className="col s5 mt-1">Filled Date</div>
                            <div className="col s7 mt-1">{orderInfo.filledDate ? moment(orderInfo.filledDate).format("MM/DD/YYYY @ h:mm A") : "---"}</div>
                            <div className="col s12 smaller-text">Date and Time a vendor is assigned or reassigned to the file</div>
                            <div className="clear"></div>

                            <div className="col s5 mt-1">Appointment Date</div>
                            <div className="col s7 mt-1">{orderInfo.aptDateTime ? `${aptDateTime} ${timeZoneAbv}` : "---"}</div>
                            <div className="clear"></div>

                            <div className="col s5 mt-1">Local Appointment Date</div>
                            <div className="col s7 mt-1">{orderInfo.localAptDate ? `${moment(orderInfo.localAptDate).format("MM/DD/YYYY @ h:mm A")} ${currentTimeZoneAbv}` : "---"}</div>
                            <div className="clear"></div>

                            <div className="col s5 mt-1">Original Date</div>
                            <div className="col s7 mt-1">{orderInfo.originalOrderDate ? moment(orderInfo.originalOrderDate).format("MM/DD/YYYY @ h:mm A") : "---"}</div>
                            <div className="clear"></div>

                            <div className="col s5 mt-1">Closed Date</div>
                            <div className="col s7 mt-1">{orderInfo.closedDate ? moment(orderInfo.closedDate).format("MM/DD/YYYY @ h:mm A") : "---"}</div>
                            <div className="clear"></div>

                            <div className="col s5 mt-1">Last Comment</div>
                            <div className="col s7 mt-1">{orderInfo.lastComment ? moment(orderInfo.lastComment).format("MM/DD/YYYY @ h:mm A") : "---"}</div>
                            <div className="col s12 smaller-text">The date when the last comment was entered</div>
                            <div className="clear"></div>

                            <div className="col s5 mt-1">Dropped for Shipping on</div>
                            <div className="col s7 mt-1">{orderInfo.dropDate ? moment(orderInfo.dropDate).format("MM/DD/YYYY @ h:mm A") : "---"}</div>

                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

LeftPanelDates.propTypes = {
    dispatch: PropTypes.func,
    orderInfo: PropTypes.object,
    orderId: PropTypes.number,
    roleType: PropTypes.string,
    roleNames: PropTypes.array
};

const mapStateToProps = (state) => {
    const { clientOrderDetail, authentication } = state;
    const { leftPanel } = clientOrderDetail;
    const { role } = authentication;
    const { roleType, roleNames } = role;
    const {
        orderInfo
    } = leftPanel;

    return {
        orderInfo,
        roleType,
        roleNames
    };
};

export default connect(mapStateToProps)(LeftPanelDates);