import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Component } from "react";
import GridView from "GridView";

import ApprovalModal from "./main-panel-approval-modal";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class FeeRequestGrid extends Component {
    constructor(props) {
        super(props);
        this.state = {
            approvalModal: {
                isShow: false,
                mode: this.props.modalMode,
                comment: [],
                feeApproval: {
                }
            }

        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    //Handle actions
    handleGridViewActionClick(action, identifier) {
        const { requestedFees } = this.props;

        if (identifier !== undefined && identifier !== null) {
            const feeId = Number(identifier);

            switch (action) {
                case "review": {
                    for (let i = 0; i < requestedFees.length; i++) {
                        if (requestedFees[i].feeApprovalId === feeId) {
                            const { approvalModal } = this.state;

                            approvalModal.isShow = true;
                            approvalModal.mode = this.props.modalMode;
                            approvalModal.feeApproval = {
                                approvalId: requestedFees[i].feeApprovalId,
                                orderId: requestedFees[i].orderId,
                                requestAmount: requestedFees[i].proposedVendorFee,
                                signerId: requestedFees[i].vendorId,
                                feeDescripId: requestedFees[i].feeDescripId,
                                status: requestedFees[i].status,
                                originalAmount: requestedFees[i].proposedVendorFee,
                                reason: requestedFees[i].reason,
                                vendorName: requestedFees[i].vendorName,
                                offerId: requestedFees[i].offerId,
                                signerFee: requestedFees[i].feeRequestAmount,
                                requestedBy: requestedFees[i].requestedBy,
                                requestedByVendor: requestedFees[i].requestedByVendor
                            };

                            this.setState({
                                approvalModal
                            });
                            return;
                        }
                    }

                    break;
                }
                default:
                    return;
            }
        }
    }

    handleCloseModal(needReload) {
        if (needReload) {
            // const { dispatch, orderId } = this.props;
            // dispatch(getOrderRequestedFee(orderId));
        }

        const { approvalModal } = this.state;

        // approvalModal.feeApproval = {};
        approvalModal.isShow = false;

        this.setState({
            approvalModal
        });
    }

    render() {
        const { defaultCriteria, columns, requestedFees } = this.props;
        const { approvalModal } = this.state;

        return (
            <div>
                <div className="row">
                    <div className="col s12">
                        <h5>Existing Fee Request</h5>
                    </div>
                </div>
                <div className="row">
                    <div className="col s12">
                        <GridView
                            criteria={defaultCriteria}
                            columns={columns} //Pass columns array
                            datasources={requestedFees} //Pass datasources
                            totalRecords={0}
                            identifier={"feeApprovalId"} //Identifier for grid row
                            allowSorting={false}
                            allowPaging={false}
                            actions={["review"]} //Remove if no action needed
                            onActionClick={(action, identifier) => this.handleGridViewActionClick(action, identifier)}
                        />
                    </div>
                </div>

                <ApprovalModal
                    isShow={approvalModal.isShow}
                    mode={approvalModal.mode}
                    feeApproval={approvalModal.feeApproval}
                    onClose={(needReload) => this.handleCloseModal(needReload)}
                />
            </div>
        );
    }
}

FeeRequestGrid.propTypes = {
    dispatch: PropTypes.func,
    defaultCriteria: PropTypes.object,
    columns: PropTypes.array,
    orderId: PropTypes.number,
    requestedFees: PropTypes.array,
    modalMode: PropTypes.string
};

FeeRequestGrid.defaultProps = {
    defaultCriteria: {
        sortColumn: "dateStamp",
        sortDirection: false,
        page: 1,
        itemPerPage: 100
    }
};

export default connect()(FeeRequestGrid);
