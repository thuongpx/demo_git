import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import Select from "Select";
import { showSuccess } from "../../main-layout/actions";
import { handleApiError } from "ErrorHandler";
import { updateLeftPanel } from "../actions/left-panel-actions";

class LeftPanelTheClosingExchange extends Component {

    handleChange(field, value) {
        const { dispatch, orderId } = this.props;
        const rawData = {
            OrderId: orderId,
            type: field
        };
        switch (field) {
            case "Status Representative":
                rawData.StatusID = parseInt(value);
                break;
            case "Quality Control":
                rawData.QCID = parseInt(value);
                break;
        }

        dispatch(updateLeftPanel(rawData, () => {
            dispatch(showSuccess(`Updated ${field}.`));
        }, (error) => {
            handleApiError(dispatch, error);
        }));
    }

    isTCEAdminManager() {
        const { roleNames } = this.props;
        let ret = false;
        if (roleNames.length > 0) {
            roleNames.forEach(item => {
                if (item === "Admin" || item === "Operational Manager") {
                    ret = true;
                }
            });
        }
        return ret;
    }

    getEmployeeName(list, value) {
        let ret = "---";

        if (list && list.length > 0) {
            const obj = list.find(item => item.RepId === value);

            if (obj) {
                ret = obj.FullName;
            }
        }

        return ret;
    }

    render() {
        const { orderInfo } = this.props;

        // AnNV2: This section is only displayed in case of full-service order. If order is self service => do not display
        if (orderInfo.isSelfService) {
            return (<div></div>);
        }

        return (
            <div>
                <div className="panel-order-detail row box-shadow-st2 mt-1 pb-2">
                    <div className="col s11 mt-2">
                        <label>
                            <span className="small-heading">The Closing Exchange</span>
                        </label>
                    </div>
                    <div className="col s4 mt-1">
                        Filled by
                    </div>
                    <div className="col s8 mt-1">
                        {orderInfo.filledBy || "---"}
                    </div>

                    <div className="col s12 mt-1">
                        {this.isTCEAdminManager() && <div className="input-field ">
                            <Select
                                dataSource={orderInfo.listStatusRepresentative}
                                optionDefaultLabel={"Select Status Representative"}
                                onChange={(value) => this.handleChange("Status Representative", value)}
                                mapDataToRenderOptions={{ value: "RepId", label: "FullName" }}
                                id="listStatusRepresentative"
                                value={orderInfo.statusId || ""}
                            />
                            <label htmlFor="listStatusRepresentative">Status Representative</label>
                        </div>}
                        {!this.isTCEAdminManager() && <div >
                            <div style={{ color: "#9e9e9e" }}>Status Representative</div>
                            <div>
                                {this.getEmployeeName(orderInfo.listStatusRepresentative, orderInfo.statusId)}
                            </div>
                        </div>}

                    </div>

                    <div className="col s12 mt-1">
                        {this.isTCEAdminManager() && <div className="input-field ">
                            <Select
                                dataSource={orderInfo.listQualityControl}
                                optionDefaultLabel={"Select Quality Control"}
                                onChange={(value) => this.handleChange("Quality Control", value)}
                                mapDataToRenderOptions={{ value: "RepId", label: "FullName" }}
                                id="listQualityControl"
                                value={orderInfo.qcId || ""}
                            />
                            <label htmlFor="listQualityControl">Quality Control</label>
                        </div>}
                        {!this.isTCEAdminManager() && <div >
                            <div style={{ color: "#9e9e9e" }}>Quality Control</div>
                            <div>
                                {this.getEmployeeName(orderInfo.listQualityControl, orderInfo.qcId)}
                            </div>
                        </div>}
                    </div>
                </div>
            </div>
        );
    }
}

LeftPanelTheClosingExchange.propTypes = {
    dispatch: PropTypes.func,
    orderInfo: PropTypes.object,
    orderId: PropTypes.number,
    roleType: PropTypes.string,
    roleNames: PropTypes.array
};

const mapStateToProps = (state) => {
    const { clientOrderDetail, authentication } = state;
    const { leftPanel } = clientOrderDetail;
    const { role } = authentication;
    const { roleType, roleNames } = role;
    const {
        orderInfo
    } = leftPanel;

    return {
        orderInfo,
        roleType,
        roleNames
    };
};

export default connect(mapStateToProps)(LeftPanelTheClosingExchange);