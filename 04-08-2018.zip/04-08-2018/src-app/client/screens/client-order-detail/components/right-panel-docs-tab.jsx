import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { ACTION } from "../../../constant/progress-log-constants";

import { insertOrderDocData } from "../../order-details/actions/order-docs";
import Uploader from "./right-panel-uploader";
import Select from "Select";
import { getRightPanelData, updateDoc, archiveDoc, addProgressLog, changeStatusOnFirstDocUploaded, setDocDelMethod } from "../actions/right-panel-actions";
import moment from "moment";
import { apiUpdateOrder } from "Api/orders-api";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class DocsTab extends Component {

    constructor(props) {
        super(props);

        this.state = {
            data: {}
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentDidMount() {
        const { dispatch, orderId } = this.props;

        if (orderId) {
            dispatch(getRightPanelData(orderId));
        }
    }

    handleUploadNewFile(data, isShowMessage) {
        const { dispatch, orderId, accountId, userName, orderDocs } = this.props;

        dispatch(insertOrderDocData(data, isShowMessage, () => {

            dispatch(getRightPanelData(orderId));

            const log = {
                orderId,
                activity: `${userName} uploaded documents`,
                usersId: accountId,
                dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                progressType: ACTION
            };

            dispatch(addProgressLog(log));

            if (orderDocs.length === 0) {
                dispatch(changeStatusOnFirstDocUploaded(orderId));
            }

        }));
    }

    updateDocShareState(doc) {
        const { dispatch, orderId, accountId, userName } = this.props;

        const newDoc = {
            DocId: doc.docId,
            Shared: !doc.shared
        };

        const log = {
            orderId,
            activity: doc.shared ? `${userName} unshared documents` : `${userName} shared documents`,
            usersId: accountId,
            dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            progressType: ACTION
        };

        dispatch(updateDoc(newDoc, log));
    }

    archiveDoc(doc) {
        const { dispatch, orderId, accountId, userName } = this.props;

        const newDoc = {
            DocId: doc.docId,
            Archive: 1
        };

        const log = {
            orderId,
            activity: `${userName} archived documents`,
            usersId: accountId,
            dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            progressType: ACTION
        };

        dispatch(archiveDoc(newDoc, log));

        return false;
    }

    renderListDocs() {
        const { orderDocs, handleDownloadDocument, updatingDocIds } = this.props;

        return !Array.isArray(orderDocs) ? "" : orderDocs.map((doc, key) => {
            if (doc.archive) {
                return "";
            }

            const isUpdating = updatingDocIds.indexOf(doc.docId) > -1;

            return (
                <div key={key} className="mb-0 valign-wrapper border-bottom">
                    <div className="col s8 truncate pt-1 pb-1 cursor-pointer" title={doc.description} onClick={() => handleDownloadDocument(doc.docId, 1, doc.description)}> {doc.description}</div>
                    <div className="col s3 center-align pl-0">
                        <button
                            type="button"
                            onClick={() => this.updateDocShareState(doc)}
                            className={`btn btn-small pl-1 pr-1 ${doc.shared ? "default-color" : "success-color"}`}
                            {...{ disabled: isUpdating ? true : undefined }}
                        >{doc.shared ? "Shared" : "Share"}</button>
                    </div>
                    <div className="col s1 center-align">
                        <span onClick={() => this.archiveDoc(doc)} className="red-color cursor-pointer" {...{ disabled: isUpdating ? true : undefined }}>
                            <i className="lnr lnr-trash"></i>
                        </span>
                    </div>
                </div>
            );
        });
    }

    render() {
        const { dispatch, accountId, orderId, docDelivery, tenantId, orderDetail, docDeliveryEdocs, listSelectedAdditionalRequest } = this.props;

        let hasEdocs = false;

        listSelectedAdditionalRequest.map(feeItem => {
            if (feeItem.FeeDescription === "Edocs") {
                hasEdocs = true;
            }
        });

        return (
            <div id="Docs" className="col s12" >
                <div className="row valign-wrapper" id="upload-inline">
                    <div className="col s6 p-0" id="text-upload-inline">Document Delivery</div>
                    <div className="col s6 p-0">
                        <div className="select-wrapper">
                            <div className="input-field mt-0" >
                                <Select
                                    dataSource={hasEdocs ? docDeliveryEdocs : docDelivery}
                                    onChange={
                                        (value) => {
                                            this.props.dispatch(setDocDelMethod(value));
                                            apiUpdateOrder({ orderId: this.props.orderId, docDelMethod: value });
                                        }
                                    }
                                    mapDataToRenderOptions={{ value: "key", label: "value" }}
                                    ref="docDelivery"
                                    id="docDelivery"
                                    value={orderDetail.docDelMethod !== null ? orderDetail.docDelMethod : ""}
                                    optionDefaultLabel="Select..."
                                />
                            </div>
                            <span className="caret updown"></span>
                        </div>
                    </div>
                </div>
                <div className="row scroll-box list-docs">
                    {this.renderListDocs()}
                </div>
                <div className="row mt-1 mb-1">
                    <div className="col s12">
                        <Uploader
                            accountId={accountId}
                            orderId={orderId}
                            tenantId={tenantId}
                            handleUploadNewFile={(dt) => { this.handleUploadNewFile(dt, false); }}
                            dispatch={dispatch}
                            constDocType={1}
                            constNotiMessage={"UPLOADEDDOC1"}
                            constPath={"/orderDocs/uploadedDocs/"}
                            {...{ disabled: (+orderDetail.docDelMethod !== 1 && +orderDetail.docDelMethod !== 8) || undefined }}
                        />
                    </div>
                </div>

            </div>
        );
    }
}

DocsTab.propTypes = {
    params: PropTypes.object,
    router: PropTypes.object,
    dispatch: PropTypes.func,
    accountId: PropTypes.number,
    userName: PropTypes.string,
    orderId: PropTypes.number,
    brokerId: PropTypes.number,
    docDelivery: PropTypes.array,
    tenantId: PropTypes.number,
    orderDetail: PropTypes.object,
    orderDocs: PropTypes.array,
    handleDownloadDocument: PropTypes.func,
    updatingDocIds: PropTypes.array,
    listSelectedAdditionalRequest: PropTypes.array,
    docDeliveryEdocs: PropTypes.array
};

DocsTab.defaultProps = {
    tenantId: 1,
    docDelivery: [
        {
            key: 1,
            value: "Upload"
        },
        {
            key: 2,
            value: "Emailed directly to Vendor"
        },
        {
            key: 3,
            value: "Overnight - To  Customer"
        },
        {
            key: 4,
            value: "Overnight  - To Vendor"
        },
        {
            key: 5,
            value: "Overnight/Courier to Closing Location"
        },
        {
            key: 6,
            value: "Printed at Closing Location"
        },
        {
            key: 7,
            value: "Customer has Documents"
        },
        {
            key: 8,
            value: "E-sign"
        }
    ],
    docDeliveryEdocs: [
        {
            key: 1,
            value: "Upload"
        },
        {
            key: 8,
            value: "E-sign"
        }
    ]
};

const mapStateToProps = (state) => {
    const { authentication, clientOrderDetail } = state;
    const { accountId, profile } = authentication;
    const { userName } = profile;
    const { rightPanel } = clientOrderDetail;
    const { orderDetail, orderDocs, updatingDocIds } = rightPanel;
    const { leftPanelFee } = clientOrderDetail;
    const { fee } = leftPanelFee;
    const { listSelectedAdditionalRequest } = fee;


    return {
        accountId,
        orderDetail,
        orderDocs,
        userName,
        updatingDocIds,
        listSelectedAdditionalRequest
    };
};

export default connect(mapStateToProps)(DocsTab);