import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import moment from "moment";
import { showError } from "../../main-layout/actions";
import CommonModal from "CommonModal";
import { getVendorRequestsGridViewData, saveVendorApproval, saveVendorApprovalValidate, getVendorApprovalById } from "../actions/main-panel-actions";
import VendorRequestsGrid from "./main-panel-vendor-requests-grid";
import VendorRequestsReviewModal from "./main-panel-vendor-requests-review-modal";
import { ORDER_PROGRESS_LOG_ACTIVITIES } from "Constants";
import { addComment } from "../../order-details/actions/order-comment";
import { getCommentByType } from "Api/comment-api";
import { COMMENT_TYPE } from "Constants";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class VendorRequest extends Component {
    constructor(props) {
        super(props);
        this.initialState = {
            searchValues: {
                orderId: this.props.orderId,
                status: "All",
                requesterName: ""
            },
            criteria: {
                sortColumn: "RequestDate",
                sortDirection: false,
                page: 1,
                itemPerPage: 25
            },
            criteriaComment: {
                sortColumn: "CreatedDate",
                sortDirection: true
            },
            filters: [
                { column: "Status", columnTitle: "Select Status", type: "FilterSelect" }
            ],
            approvalModal: {
                approvalDetail: {}
            }
        };

        this.state = {
            selectedVendorRequestation: {},
            isReviewModalOpen: false,
            searchValues: {
                ...this.initialState.searchValues
            },
            criteria: {
                ...this.initialState.criteria
            },
            criteriaComment: {
                ...this.initialState.criteriaComment
            },
            filters: [
                ...this.initialState.filters
            ],
            approvalModal: {
                ...this.initialState.approvalModal
            }
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentDidMount() {
        this.refreshDatasource();
    }

    refreshDatasource() {
        const { dispatch } = this.props;
        const { searchValues, criteria } = this.state;

        dispatch(getVendorRequestsGridViewData(searchValues, criteria));
    }

    //when manager approve or reject vendor approvals
    handleChangeStatus(modalData) {
        const { approvedBy, usersId } = this.props;
        const approvalData = {
            usersId,
            approvedBy,
            email: modalData.email,
            loanType: modalData.loanType,
            approvalId: modalData.approvalId,
            orderId: modalData.orderId,
            signerId: modalData.signerId,
            distance: modalData.distance,
            offerAmount: modalData.offerAmount,
            firstName: modalData.firstName,
            lastName: modalData.lastName,
            vendorName: modalData.vendorName,
            city: modalData.city,
            status: modalData.status,
            reason: modalData.reason,
            mgrReason: modalData.mgrReason,
            fullNameAgent: modalData.fullNameAgent,
            approvedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            userName: modalData.userName
        };

        if (approvalData.status === "Approved") {
            this.makeValidApprovalData(approvalData);
        } else {
            this.saveApprovalData(approvalData);
        }
    }

    makeValidApprovalData(approvalData) {
        const { dispatch } = this.props;
        const checkData = {
            orderId: approvalData.orderId,
            signerId: approvalData.signerId
        };

        dispatch(saveVendorApprovalValidate(checkData, (caseMessage) => {
            switch (caseMessage) {
                case "SUCCESS": {
                    this.saveApprovalData(approvalData);
                    break;
                }
                case "SIGNER_ALREADY": {
                    this.commonModal.showModal({
                        type: "confirm",
                        message: "Another Vendor has been assigned to this order. Do you want to replace that Vendor?"
                    }, () => {
                        this.saveApprovalData(approvalData);
                    }, () => {
                        approvalData.status = "Rejected";
                        this.saveApprovalData(approvalData);
                    });
                    break;
                }
                case "ADT_DUPLICATED": {
                    dispatch(showError("This Vendor has already assigned to another order having the same Appointment Date time", () => {
                        approvalData.status = "Rejected";
                        this.saveApprovalData(approvalData);
                    }));
                    break;
                }
                case "CLOSED_ORDER": {
                    dispatch(showError("This Order has already closed", () => {
                        approvalData.status = "Rejected";
                        this.saveApprovalData(approvalData);
                    }));
                    break;
                }
            }
        }));
    }

    saveApprovalData(approvalData) {
        const { dispatch } = this.props;

        dispatch(saveVendorApproval(approvalData, () => this.refreshDatasource()));
    }

    //close modal
    handleCloseReviewModal() {
        this.setState({
            isReviewModalOpen: false
        });
        this.refreshDatasource();
    }

    //open modal
    handleOpenReviewModal(identifier) {
        const { datasources } = this.props;

        datasources.filter((approval) => {
            if (approval.ApprovalID === identifier) {
                const filter = {
                    typeId: COMMENT_TYPE.VendorApprovalCommentType,
                    ownerId: approval.ApprovalID
                };
                getCommentByType(filter, (response) => {
                    const description = response.data ? response.data : "";
                    const approvalModal = {
                        approvalDetail: approval,
                        mod: "vendor",
                        description
                    };

                    this.setState({
                        isReviewModalOpen: true,
                        approvalModal
                    });
                });

            }
        });
    }

    //open modal
    onGetDataVendorApprovalById(approvalId) {
        const { dispatch } = this.props;
        const { criteriaComment } = this.state;
        dispatch(getVendorApprovalById(criteriaComment, approvalId));
    }

    handleInputsChange(field, value) {
        const { dispatch } = this.props;

        this.setState({
            [field]: value
        });

        if (field === "criteria") {
            dispatch(getVendorRequestsGridViewData(this.state.searchValues, value));
        }
    }

    onSaveComment(inputs) {
        const { dispatch, orderId, profile } = this.props;
        // AnNV2: Update - create a new comment
        const comment = {
            Description: inputs.inputs.Description,
            IsPrivate: inputs.inputs.SetPrivateComment,
            CreatedBy: profile.userId, // userId
            ParentID: null, // parent if any
            TypeID: 4,
            OwnerID: inputs.inputs.OwnerID,
            CreatedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        };

        const log = {
            OrderId: orderId,
            Activity: ORDER_PROGRESS_LOG_ACTIVITIES.COMMENT_ADDED,
            UsersId: profile.userId, // need change when logging is applyed
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            IsPrivate: inputs.inputs.SetPrivateComment
        };

        dispatch(addComment(comment, log));
    }
    render() {
        const { datasources, totalRecords, roleType, roleNames } = this.props;
        const { filters, approvalModal } = this.state;

        return (
            <div>
                <VendorRequestsGrid
                    totalRecords={totalRecords}
                    datasources={datasources}
                    criteria={this.state.criteria}
                    filters={filters}
                    onChange={(field, value) => this.handleInputsChange(field, value)}
                    onReview={(identifier) => this.handleOpenReviewModal(identifier)}
                />
                <VendorRequestsReviewModal
                    isOpen={this.state.isReviewModalOpen}
                    roleType={roleType}
                    roleNames={roleNames}
                    onClose={() => this.handleCloseReviewModal()}
                    onChangeStatus={(modalData) => this.handleChangeStatus(modalData)}
                    approvalModal={approvalModal}
                    onSaveComments={(description) => this.onSaveComment(description)}
                    onGetDataVendorApprovalById={(approvalId) => this.onGetDataVendorApprovalById(approvalId)}
                />
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

VendorRequest.propTypes = {
    dispatch: PropTypes.func,
    datasources: PropTypes.array,
    criteria: PropTypes.object,
    searchValues: PropTypes.object,
    totalRecords: PropTypes.number,
    countOpen: PropTypes.number,
    approvedBy: PropTypes.number,
    usersId: PropTypes.number,
    orderId: PropTypes.number,
    profile: PropTypes.object,
    filters: PropTypes.array,
    roleType: PropTypes.string,
    roleNames: PropTypes.array,
    approvalModal: PropTypes.object,
    dataVendorRequestsById: PropTypes.array
};

const mapStateToProps = (state) => {
    const { vendorRequestsReducers, authentication } = state;
    const { approvalModal, isFetching, datasources, totalRecords, countOpen, dataVendorRequestsById } = vendorRequestsReducers;
    const approvedBy = authentication.profile.id;
    const usersId = authentication.accountId;
    const { profile } = authentication;

    return {
        isFetching,
        approvalModal,
        datasources,
        totalRecords,
        countOpen,
        approvedBy,
        usersId,
        dataVendorRequestsById,
        profile,
        roleType: state.authentication.role.roleType,
        roleNames: state.authentication.role.roleNames
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(VendorRequest);