import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";
//import InputMask from "react-input-mask";
import CKEditor from "react-ckeditor-component";
import { showPopupSendMail, sendMailFaxcover } from "./../actions/left-panel-actions";
import { updateTextFields } from "../../../helpers/theme-helper";

class SendMailModal extends Component {
    constructor(props) {
        super(props);
    }

    componentDidUpdate() {
        updateTextFields();
    }

    handleSendMail() {
        const { dispatch, mailOptions, profile, selectSendMailOption } = this.props;
        mailOptions.userId = profile.userId;
        mailOptions.userName = profile.userName;
        mailOptions.selectSendMailOption = selectSendMailOption;
        dispatch(sendMailFaxcover(mailOptions));
    }

    render() {
        const { isOpen, dispatch, mailOptions } = this.props;

        const renderButton = (
            <div className="row m-0">
                <div className="col s12 m6">
                    <button className="btn white w-100" onMouseDown={
                        () => {
                            dispatch(showPopupSendMail(false));
                        }
                    }> Cancel </button>
                </div>
                <div className="col s12 m6">
                    <button className="btn success-color w-100" onClick={
                        () => {
                            this.handleSendMail();
                        }
                    }> Send </button>
                </div>
            </div>
        );

        return (
            <div>
                <Modal isOpen={this.props.isOpen} addClass="no-tab" style={{ height: "75%" }}>
                    <ModalBody>
                        <ModalTitle onClickClose={() => dispatch(showPopupSendMail(false))}>Send Mail</ModalTitle>
                        <div className="tab-content">
                            <div className="row">
                                <div className={`input-field col m12 suffixinput`}>
                                    <input
                                        disabled
                                        id="fromEmail"
                                        maxLength="100"
                                        type="text"
                                        ref="fromMail"
                                        value={mailOptions.from}
                                    />
                                    <label htmlFor="fromMail">From</label>
                                </div>
                            </div>
                            <div className="row">
                                <div className={`input-field col m12 suffixinput`}>
                                    <input
                                        disabled
                                        id="toEmail"
                                        maxLength="100"
                                        type="text"
                                        ref="toEmail"
                                        value={mailOptions.to}
                                    />
                                    <label htmlFor="fromMail">To</label>
                                </div>
                            </div>
                            <div className="row">
                                <div className={`input-field col m12 suffixinput`}>
                                    <input
                                        disabled
                                        id="ccMail"
                                        maxLength="100"
                                        type="text"
                                        ref="ccMail"
                                        value={mailOptions.cc}
                                    />
                                    <label htmlFor="ccMail">Cc</label>
                                </div>
                            </div>
                            <div className="row">
                                <div className={`input-field col m12 suffixinput`}>
                                    <input
                                        disabled
                                        id="attachEmail"
                                        maxLength="100"
                                        type="text"
                                        ref="attachEmail"
                                        value={mailOptions.attachmentNames}
                                    />
                                    <label htmlFor="attachEmail">Attached</label>
                                </div>
                            </div>
                            <div className="row">
                                <div className={`input-field col m12 suffixinput`}>
                                    <input
                                        disabled
                                        id="subject"
                                        maxLength="100"
                                        type="text"
                                        ref="subject"
                                        value={mailOptions.subject}
                                    />
                                    <label htmlFor="subject">Subject</label>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col m12">
                                    <label htmlFor="message" >Message</label>
                                    <div style={{ marginTop: "10px" }}>
                                        {isOpen ?
                                            <CKEditor
                                                disabled
                                                activeClass="p10"
                                                content={mailOptions.html}
                                                ref="editor"
                                            /> : null}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        {renderButton}
                    </ModalFooter>
                </Modal>
            </div>
        );
    }
}

SendMailModal.propTypes = {
    dispatch: PropTypes.func.isRequired,
    isOpen: PropTypes.bool,
    mailOptions: PropTypes.object,
    profile: PropTypes.object,
    selectSendMailOption: PropTypes.string
};

const mapStateToProps = (state) => {
    const { clientOrderDetail, authentication } = state;
    const { leftPanel } = clientOrderDetail;
    const { isOpen, mailOptions, selectSendMailOption } = leftPanel;
    const { profile } = authentication;
    return {
        isOpen,
        mailOptions,
        profile,
        selectSendMailOption
    };
};

export default connect(mapStateToProps)(SendMailModal);