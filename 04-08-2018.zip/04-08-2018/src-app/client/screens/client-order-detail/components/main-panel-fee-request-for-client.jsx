import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { getOrderRequestedFee } from "../actions/main-panel-fee-requested-action";
import VendorFeeRequest from "./main-panel-fee-request-vendor";
import AgentFeeRequest from "./main-panel-fee-request-agent";
import AllOrderRequestedFee from "./main-panel-fee-request-all";
import { switchModuleOnMainPanel } from "../actions/main-panel-actions";
import { CLIENT_SUB_ROLE } from "Constants";
import { listenOnSubmitFeeRequest, stopListenOnSubmitFeeRequest } from "../../../socket/orders";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { ORDER_REQUEST_APPROVE_STATUS } from "../../../constant/constants";

class OrderRequestedFees extends Component {
    constructor(props) {
        super(props);

        const tabs = [
            { title: "Fee Requests - Agent", isActive: true, isVisible: true },
            { title: "Fee Requests - Vendor/Auto", isActive: false, isVisible: props.orderInfo.agentId > 0 && props.clientType === CLIENT_SUB_ROLE.AGENT }
        ];

        // set tab default if there is not any tab matches value in cookies
        const activeTabs = tabs.filter((item) => {
            return item.isActive;
        });

        if (activeTabs.length === 0) tabs[0].isActive = true;

        this.state = {
            tabs
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.orderInfo.agentId !== this.props.orderInfo.agentId) {
            const tabs = [
                { title: "Fee Requests - Agent", isActive: true, isVisible: true },
                { title: "Fee Requests - Vendor/Auto", isActive: false, isVisible: nextProps.orderInfo.agentId > 0 && nextProps.clientType === CLIENT_SUB_ROLE.AGENT }
            ];
            this.setState({ tabs });
        }
    }

    componentDidMount() {
        const { dispatch, orderId } = this.props;

        listenOnSubmitFeeRequest(() => {
            dispatch(getOrderRequestedFee(orderId));
        });

        //dispatch(getOrderRequestedFee(orderId));
    }

    componentWillUnmount() {
        stopListenOnSubmitFeeRequest();
    }

    handleTabClick(tab) {
        this.setActiveTab(tab);
    }

    setActiveTab(tab) {
        const { tabs } = this.state;

        tabs.map(item => {
            if (item.title === tab.title) {
                item.isActive = true;
            } else item.isActive = false;
            return item;
        });
        this.setState({ tabs });
    }

    handleViewRequestFee(e) {
        e.preventDefault();

        // hide communication module and show fee requests module
        const { dispatch } = this.props;
        dispatch(switchModuleOnMainPanel("COM"));
    }

    render() {
        const { requestedFeeData, clientType, orderInfo } = this.props;

        let iAgentRequest = 0;
        let iVendorRequest = 0;

        requestedFeeData.forEach(element => {
            if (element.status === ORDER_REQUEST_APPROVE_STATUS.OPEN) {
                if (element.requestedByVendor) {
                    iVendorRequest++;
                } else {
                    iAgentRequest++;
                }
            }
        });

        const renderTabs = () => {
            const renderAlert = (tab) => {
                switch (tab.title) {
                    case "Fee Requests - Agent":
                        if (iAgentRequest !== 0 && clientType !== CLIENT_SUB_ROLE.AGENT) {
                            return (
                                <span className="new badge alert badge-group">{iAgentRequest}</span>
                            );
                        } else {
                            return null;
                        }
                    case "Fee Requests - Vendor/Auto":
                        if (iVendorRequest !== 0) {
                            return (
                                <span className="new badge alert badge-group">{iVendorRequest}</span>
                            );
                        } else {
                            return null;
                        }
                    default:
                        return null;
                }
            };

            return this.state.tabs.map((tab, key) => {
                const classNameActive = tab.isActive ? "active" : "";
                const renderTitle = () => {
                    let title = tab.title;
                    if (tab.title === "Fee Requests - Agent") {
                        title = orderInfo.agentId > 0 ? "Fee Requests - Agent" : "Fee Requests";
                    }

                    return title;
                };

                if (!tab.isVisible) {
                    return null;
                }

                return (
                    <li className={`tab col ${classNameActive}`} key={key} onClick={() => this.handleTabClick(tab)}>
                        <a style={{ cursor: "pointer" }}>
                            <span className="valign-wrapper">
                                {renderTitle()}
                                {renderAlert(tab)}
                            </span>
                        </a>
                    </li>
                );
            });
        };

        const renderTabContent = () => {
            const { orderId } = this.props;

            return this.state.tabs.map((tab, key) => {

                if (tab.isActive) {
                    switch (tab.title) {
                        case "Fee Requests - Agent":
                            return (
                                <AgentFeeRequest
                                    key={key}
                                    orderId={orderId}
                                    requestedFeeData={requestedFeeData}
                                />
                            );
                        case "Fee Requests - Vendor/Auto":
                            return (
                                <VendorFeeRequest
                                    key={key}
                                    orderId={orderId}
                                    requestedFeeData={requestedFeeData}
                                />
                            );
                        case "Fee Requests": {
                            return (
                                <AllOrderRequestedFee
                                    key={key}
                                    orderId={orderId}
                                    requestedFeeData={requestedFeeData}
                                />
                            );
                        }
                        default:
                            return (
                                <div className="col s12 tab-content p-0">
                                </div>
                            );
                    }
                }
                return null;
            });
        };

        return (
            <div className="col s12">
                <div className="tab-wrap st2 panel-order-detail row p-0">
                    <div className="col s12 mt-2 p-0">
                        <ul className="tabs">
                            {renderTabs()}
                        </ul>
                    </div>
                    {renderTabContent()}
                    <div className="p-0 right">
                        <button
                            className="btn btn-small success-color"
                            onClick={(e) => this.handleViewRequestFee(e)}
                        >EXIT</button>
                    </div>
                </div>
            </div>
        );
    }
}


OrderRequestedFees.propTypes = {
    dispatch: PropTypes.func,
    orderId: PropTypes.number,
    requestedFeeData: PropTypes.array,
    clientType: PropTypes.string,
    orderInfo: PropTypes.object
};

const mapStateToProps = (state) => {
    const { clientOrderDetail } = state;
    const { mainPanelFeeRequestReducers, leftPanel } = clientOrderDetail;
    const { requestedFeeData } = mainPanelFeeRequestReducers;
    const { orderInfo } = leftPanel;
    const { authentication } = state;
    const { profile } = authentication;
    const clientType = profile.subRoleType;

    return {
        requestedFeeData,
        clientType,
        agentId: orderInfo.agentId,
        orderInfo
    };
};

export default connect(mapStateToProps)(OrderRequestedFees);