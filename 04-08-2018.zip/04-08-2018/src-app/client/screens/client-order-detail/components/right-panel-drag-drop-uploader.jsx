import React, { Component } from "react";
import PropTypes from "prop-types";
import { API_URL, FILE_UPLOAD_SIZE } from "Config/config";
import defaultStyles from "../../../features/drag-drop-uploader/styles";
import UploadingModal from "../../../features/drag-drop-uploader/uploading-modal";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class DragDropUploader extends Component {
    constructor(props) {
        super(props);
        this.state = { items: [], styles: { ...defaultStyles, ...props.styles } };
        this.activeDrag = 0;
        this.xhrs = [];
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    // Open file browser when click dropzone
    onClick() {
        this.fileInput.click();
    }

    // Handle file(s) after select file from file browser
    handleFileSelect() {

        if (!this.fileInput.files) {
            return;
        }

        // get and reset file input
        const files = Array.prototype.slice.call(this.fileInput.files).slice(0, this.fileInput.files.length);
        this.fileInput.value = "";

        this.prepareFileForUpload(files);
    }

    // Set dropzone state to active to get another style
    onDragEnter() {
        this.activeDrag += 1;
        this.setState({ isActive: this.activeDrag > 0 });
    }

    // Handle drag over
    onDragOver(e) {
        if (e) {
            e.preventDefault();
        }
        return false;
    }

    // Set dropzone state to inactive to get another style
    onDragLeave() {
        this.activeDrag -= 1;
        if (this.activeDrag === 0) {
            this.setState({ isActive: false });
        }
    }

    // Handle droped file(s)
    onDrop(e) {
        if (!e) {
            return;
        }

        e.preventDefault();
        this.activeDrag = 0;

        const droppedFiles = e.dataTransfer ?
            Array.prototype.slice.call(e.dataTransfer.files).slice(0, e.dataTransfer.files.length)
            : [];

        // reset state of dropzone
        this.resetUploader();

        this.prepareFileForUpload(droppedFiles);

    }

    // reset file input value and state of dropzone
    resetUploader() {
        this.fileInput.value = "";

        this.setState({
            isActive: false,
            items: []
        });
    }

    // Upload file when click upload button
    onUploadButtonClick() {
        this.upload();
    }

    // prepare file and call to custom validate
    prepareFileForUpload(files) {
        if (files.length === 0) {
            return;
        }

        // remove insvalid file type
        files = files.filter(file => {
            return file.type !== "";
        });

        if (this.props.onValidate) {
            this.props.onValidate(files);
        }

    }

    // format each file to an object for upload
    filesToItems(files) {
        const { fileExtensions } = this.props;
        const listExtensions = fileExtensions.map(item => item.toUpperCase()).join(",");
        const invalidExtensionMessage = `Invalid extension. Only “${listExtensions}” are supported`;
        const fileTooBigMessage = `Document is too big. Max size: ${FILE_UPLOAD_SIZE / (1024 * 1024)} MB`;

        if (!Array.isArray(files) && files.length) {
            files = Array.prototype.slice.call(files).slice(0, files.length);
        }

        if (!Array.isArray(files)) {
            return [];
        }

        const items = files.map((f, i) => {
            f.extension = f.name.split(".").pop();
            const item = { file: f, index: i, progress: 0, cancelled: false, isCompleted: false, needUpload: true };

            if (Array.isArray(fileExtensions) && fileExtensions.indexOf(f.extension.toLowerCase()) === -1) {
                item.needUpload = false;
                item.error = invalidExtensionMessage;
            } else if (f.size > FILE_UPLOAD_SIZE) {
                item.needUpload = false;
                item.error = fileTooBigMessage;
            }

            return item;
        });

        return items;
    }

    // Update file upload progress to show in progress bar
    updateFileProgress(index, fileAttributes) {
        const { onAllFileUploaded } = this.props;
        const newItems = [...this.state.items];
        newItems[index] = Object.assign({}, this.state.items[index], { ...fileAttributes });
        if (onAllFileUploaded) {
            const itemIncompleted = newItems.find(item => {
                return item.needUpload && !item.cancelled && !item.isCompleted && !item.error;
            });
            if (!itemIncompleted) {
                onAllFileUploaded(newItems);
            }
        }
        this.setState({ items: newItems });
    }

    // Cancel upload file (if upload progress still incomplete)
    cancelFile(index) {
        const newItems = [...this.state.items];
        newItems[index] = { ...this.state.items[index], cancelled: true };
        if (this.xhrs[index]) {
            this.xhrs[index].upload.removeEventListener("progress");
            this.xhrs[index].removeEventListener("load");
            this.xhrs[index].abort();
        }
        this.setState({ items: newItems });
    }

    // start upload file in state
    upload(files) {
        if (!Array.isArray(files) || files.length === 0) {
            return;
        }

        const items = this.filesToItems(files);

        this.setState({
            items
        }, () => {
            this.uploadingModal.toggleModal(this.props.isShowUploadingModal);

            if (items) {
                const itemsNeedUpload = items.filter(item => item.needUpload && !item.cancelled && !item.isCompleted && !item.error);
                itemsNeedUpload.forEach(item => {
                    this.uploadFile(item.file, (fileAttributes) => this.updateFileProgress(item.index, fileAttributes));
                });
            }
        });
    }

    // upload a file
    uploadFile(file, progressCallback) {
        const { path } = this.props;

        if (file) {
            const formData = new FormData();
            const xhr = new XMLHttpRequest();

            formData.append(this.props.fieldName, file, file.newName || file.name);
            if (path) {
                formData.append("path", path);
            }

            // handle result after request done
            xhr.onload = () => {
                const status = xhr.status;
                let isSuccess = true;
                const data = JSON.parse(xhr.responseText);
                if (status === 200) {
                    isSuccess = data.isSuccess;
                } else {
                    isSuccess = false;
                }

                if (isSuccess) {
                    progressCallback({
                        progress: 100,
                        isCompleted: true
                    });
                    this.props.onUploadFileSuccess(data.file);
                } else {
                    let erroMessage = data.message;
                    if (data.statusCode === 413) {
                        const limitSize = Number.parseInt(data.message.split(" ").pop() / 1048576);
                        erroMessage = `Document is too big. Max size: ${limitSize}MB`;
                    }
                    progressCallback({
                        progress: 100,
                        isCompleted: false,
                        error: `Error: ${erroMessage}`
                    });
                }
            };

            // handle error
            xhr.onerror = () => {
                progressCallback({
                    progress: 100,
                    isCompleted: false,
                    error: `Upload error: Can not connect to server`
                });
            };

            // update progress
            xhr.upload.onprogress = e => {
                if (e.lengthComputable) {
                    progressCallback({
                        progress: e.loaded / e.total * 100
                    });
                }
            };

            // open and send request
            xhr.open(this.props.method, this.props.url, true);
            xhr.send(formData);
            this.xhrs[file.index] = xhr;
        }
    }

    renderDropTarget() {
        const { disabled, isShowShareAllButton, disableShareAll } = this.props;
        const { isActive } = this.state;

        let dragDropAttributes = {};
        if (!disabled) {
            dragDropAttributes = {
                onDragEnter: () => this.onDragEnter(),
                onDragOver: (e) => this.onDragOver(e),
                onDragLeave: () => this.onDragLeave(),
                onDrop: (e) => this.onDrop(e)
            };
        }

        return (
            <div>
                {!isShowShareAllButton && <div
                    data-test-id="dropTarget"
                    className={`uploadfile__file-upload-container___2e2ey docs-management ${disabled ? "disabled" : ""} ${isActive ? "active" : ""}`}
                    {...dragDropAttributes}
                    style={{ cursor: "pointer" }}
                >
                    <span>
                        <b className={`mr-1 ${disabled ? "gray-color" : "green-color"}`}>{this.props.dropzoneLabel}</b> OR
                </span>
                    <button className="btn btn-small success-color ml-1" style={{ marginTop: "5px" }}
                        onClick={() => this.onClick()}
                        {...{ disabled }}
                    >
                        UPLOAD
                </button>
                </div >}
                {isShowShareAllButton && <div
                    data-test-id="dropTarget"
                    className={`uploadfile__file-upload-container___2e2ey  docs-management ${disabled ? "disabled" : ""} ${isActive ? "active" : ""}`}
                    {...dragDropAttributes}
                    style={{ cursor: "pointer" }}
                >
                    <span>
                        <b style={{ marginRight: "7px" }} className={`${disabled ? "gray-color" : "green-color"}`}>{this.props.dropzoneLabel}</b> OR
                </span>
                    <button className="btn btn-small success-color" style={{ marginTop: "5px", marginLeft: "10px", display: "inline" }}
                        onClick={() => this.onClick()}
                        {...{ disabled }}
                    >
                        UPLOAD
                </button>
                    <button disabled={disableShareAll} className="btn btn-small success-color" style={{ marginTop: "5px", marginLeft: "5px" }}
                        onClick={() => this.props.onShareAllClick()}
                    >
                        SHARE ALL
                </button>
                </div >}
            </div>
        );
    }

    renderInput() {
        const { isMultiple, fileExtensions, disabled } = this.props;
        const attributes = {
            accept: fileExtensions ? fileExtensions.map(item => `.${item}`).join(",") : undefined,
            disabled
        };

        return (
            <input
                style={{ display: "none" }}
                multiple={isMultiple}
                type="file"
                ref={c => {
                    if (c) {
                        this.fileInput = c;
                    }
                }}
                onChange={() => this.handleFileSelect()}
                {...attributes}
            />
        );
    }

    render() {
        const { items } = this.state;
        const { auto, buttonLabel } = this.props;

        return (
            <div>
                {this.renderDropTarget()}
                {this.renderInput()}
                <UploadingModal
                    ref={(uploadingModal) => { this.uploadingModal = uploadingModal; }}
                    items={items}
                    onCancelFile={(index) => this.cancelFile(index)}
                    onToggle={(isOpen) => isOpen ? "" : this.resetUploader()}
                    displayUploadButton={!auto}
                    buttonLabel={buttonLabel}
                    onUploadButtonClick={() => this.onUploadButtonClick()}
                />
            </div>
        );
    }
}

DragDropUploader.propTypes = {
    url: PropTypes.string,
    onUploadFileSuccess: PropTypes.func.isRequired,
    method: PropTypes.string,
    auto: PropTypes.bool,
    fieldName: PropTypes.string,
    buttonLabel: PropTypes.string,
    dropzoneLabel: PropTypes.string,
    fileExtensions: PropTypes.array,
    isMultiple: PropTypes.bool,
    styles: PropTypes.shape({}),
    cancelIconClass: PropTypes.string,
    completeIconClass: PropTypes.string,
    uploadIconClass: PropTypes.string,
    progressClass: PropTypes.string,
    onValidate: PropTypes.func,
    path: PropTypes.string,
    disabled: PropTypes.bool,
    onAllFileUploaded: PropTypes.func,
    isShowShareAllButton: PropTypes.bool,
    onShareAllClick: PropTypes.func,
    disableShareAll: PropTypes.bool,
    isShowUploadingModal: PropTypes.bool
};

DragDropUploader.defaultProps = {
    method: "POST",
    url: `${API_URL}/file/uploadFile`,
    auto: true,
    fieldName: "file",
    buttonLabel: "Upload",
    dropzoneLabel: "DROP FILE HERE",
    isMultiple: true,
    cancelIconClass: "lnr lnr-cross-circle",
    completeIconClass: "lnr lnr-checkmark-circle",
    uploadIconClass: "lnr lnr-upload",
    isShowShareAllButton: false,
    isShowUploadingModal: true
};

export default DragDropUploader;