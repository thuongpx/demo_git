import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { getSignedDocsInitData, updateSignedDocsStatus, addProgressLog } from "../actions/right-panel-actions";
import { SIGNED_DOC_STATUS } from "../../../constant/constants";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import SignedDocsCommentModal from "./right-panel-signed-docs-comment-modal";
import { showSuccess } from "../../main-layout/actions";
import moment from "moment";
import Uploader from "./right-panel-uploader";
import { ACTION } from "../../../constant/progress-log-constants";
import { insertOrderDocData } from "../../order-details/actions/order-docs";

class SignedDocsTab extends Component {
    constructor(props) {
        super(props);

        this.signedDocType = 2; //docType of signed document

        this.docSignedCriteria = {
            sortColumn: "Description",
            sortDirection: true,
            page: 1,
            itemPerPage: 2500,
            orderId: this.props.orderId,
            docType: this.signedDocType
        };

        this.FilterTooltip = {};
        this.hasTooltipShowing = false;

        this.state = {
            isOpen: false,
            commentInfo: {
                docData: {}
            }
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentDidMount() {
        $("#list-document-signed-data").scroll(() => {
            if (this.hasTooltipShowing) {
                this.closeAllToolTip();
                this.hasTooltipShowing = false;
            }
        });

        this.reloadListSignedDocs();
    }

    reloadListSignedDocs() {
        const { dispatch } = this.props;
        dispatch(getSignedDocsInitData(this.docSignedCriteria));
    }

    convertStatusCode(code = "") {
        let returnStatus = "";

        if (!code) return SIGNED_DOC_STATUS.OPEN.description;

        switch (code.toUpperCase()) {
            case "A":
                returnStatus = SIGNED_DOC_STATUS.APPROVED;
                break;
            case "O":
                returnStatus = SIGNED_DOC_STATUS.OPEN;
                break;
            case "R":
                returnStatus = SIGNED_DOC_STATUS.REJECTED;
                break;
            default:
                returnStatus = "";
                break;
        }

        return returnStatus.description || "";
    }

    closeTooltip(tooltipRefId = "") {
        this.FilterTooltip[tooltipRefId].hideTooltip();
    }

    closeAllToolTip(exceptToolTip = "") {
        this.hasTooltipShowing = true;
        Object.keys(this.FilterTooltip).forEach(item => {
            if (item !== exceptToolTip) this.closeTooltip(item);
        });
    }

    handleToggleCommentModal(docData = {}) {
        if (this.state.isOpen) {
            this.setState({
                isOpen: false,
                commentInfo: {
                    docData: {}
                }
            });
        } else {
            this.setState({ isOpen: true, commentInfo: { docData: { ...docData, orderId: this.props.orderId } } });
        }
    }

    reloadDataForReviewModal(docId) {
        const newDocData = this.findDocument(docId);

        this.setState({ commentInfo: { docData: { ...newDocData, orderId: this.props.orderId } } });
    }

    findDocument(docId) {
        const { signedDocs } = this.props;
        const doc = signedDocs.data.find(item => Number(item.DocId) === Number(docId));

        if (doc) return doc;

        return {};
    }

    handleReviewDocument(docId) {
        const currentDoc = this.findDocument(docId);

        this.handleToggleCommentModal(currentDoc);
    }

    handleDownloadDocToView(docId, docType, fileName) {
        const { handleDownloadDocument, dispatch } = this.props;

        handleDownloadDocument(docId, docType, fileName);

        const newDocStatus = {
            DocId: docId,
            Viewed: true,
            DownloadDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        };

        dispatch(updateSignedDocsStatus(newDocStatus, () => { }));
    }

    handleUploadNewFile(data, isShowMessage) {
        const { dispatch, orderId, accountId, userName } = this.props;

        dispatch(insertOrderDocData(data, isShowMessage, () => {
            const log = {
                orderId,
                activity: `${userName} uploaded documents`,
                usersId: accountId,
                dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                progressType: ACTION
            };

            dispatch(addProgressLog(log));
            this.reloadListSignedDocs();
        }));
    }

    render() {
        const { signedDocs, dispatch, accountId, profile, userName } = this.props;

        const renderListSignedDocs = () => {
            if (!signedDocs.totalRecords) {
                return <div className="center-align p-3">There are no records to show.</div>;
            }

            return (
                signedDocs.data.map((doc, index) => {
                    const docStatus = this.convertStatusCode(doc.Status);
                    const docViewed = doc.Viewed ? "Viewed" : "";

                    return (
                        <div key={index} className="row mb-0 valign-wrapper border-bottom">
                            <div className="col s7 truncate pt-1 pb-1 cursor-pointer" title={doc.Description} onClick={() => this.handleDownloadDocToView(doc.DocId, this.signedDocType, doc.Description)}><a href="#"> {doc.Description}</a></div>
                            <div className="col s2 truncate pt-1 pb-1" title={docStatus}>{docStatus}</div>
                            <div className="col s2 truncate pt-1 pb-1" title={docViewed}>{docViewed}</div>
                            <div className="col s1 center-align">
                                <span className="filter-tooltip">
                                    <i
                                        className={`lnr lnr-eye cursor-pointer blue-color`}
                                        title="Review Documents"
                                        onClick={() => this.handleReviewDocument(doc.DocId)}
                                    ></i>
                                </span>
                            </div>
                        </div>
                    );
                })
            );
        };

        return (
            <div>
                <div id="list-document-signed-data" className="col s12 scroll-box list-docs mb-1">
                    {renderListSignedDocs()}
                </div>
                <div className="clearfix"></div>
                {this.props.roleType === "Staff" && <div className="col s12 mb-1">
                    <Uploader
                        accountId={accountId}
                        orderId={this.props.orderId}
                        tenantId={1}
                        handleUploadNewFile={(dt) => { this.handleUploadNewFile(dt, false); }}
                        dispatch={dispatch}
                        constDocType={2}
                        constNotiMessage={"UPLOADEDDOC1"}
                        constPath={"/orderDocs/signedDocs/"}
                    />
                </div>}
                <SignedDocsCommentModal
                    isOpen={this.state.isOpen}
                    commentInfo={this.state.commentInfo}
                    toggleModal={(isAddComment = false) => this.handleToggleCommentModal(isAddComment)}
                    listRejectCode={signedDocs.listReject}
                    ref={instance => { this.signedDocModal = instance; }}
                    updateSignedDoc={(newDoc, actionMess) => this.updateSignedDoc(newDoc, () => dispatch(showSuccess(actionMess)))}
                    accountId={accountId}
                    profile={profile}
                    dispatch={(action) => dispatch(action)}
                    reloadData={docId => this.reloadDataForReviewModal(docId)}
                    userName={userName}
                />
            </div>
        );
    }
}

SignedDocsTab.propTypes = {
    dispatch: PropTypes.func,
    orderId: PropTypes.number,
    signedDocs: PropTypes.object,
    handleDownloadDocument: PropTypes.func,
    accountId: PropTypes.number,
    profile: PropTypes.object,
    roleType: PropTypes.string,
    userName: PropTypes.string
};
const mapStateToProps = (state) => {
    const { authentication, clientOrderDetail } = state;
    const { accountId, profile } = authentication;
    const { userName } = profile;
    const { rightPanel } = clientOrderDetail;
    const { signedDocs } = rightPanel;

    return {
        signedDocs,
        accountId,
        profile,
        userName
    };
};

export default connect(mapStateToProps)(SignedDocsTab);