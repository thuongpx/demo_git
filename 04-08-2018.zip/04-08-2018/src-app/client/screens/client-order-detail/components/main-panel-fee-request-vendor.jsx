import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import FeeRequestGrid from "./main-panel-fee-request-grid";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class VendorFeeRequest extends Component {
    constructor(props) {
        super(props);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {
        const { columns, requestedFeeData, orderId } = this.props;

        const vendorRequestedFee = requestedFeeData.filter((fee) => {
            return fee.requestedByVendor;
        });

        return (
            <FeeRequestGrid
                orderId={orderId}
                requestedFees={vendorRequestedFee}
                columns={columns}
                modalMode={"AUTO_FEE_APPROVAL"}
            />
        );
    }
}

VendorFeeRequest.propTypes = {
    columns: PropTypes.array,
    orderId: PropTypes.number,
    requestedFeeData: PropTypes.array
};

VendorFeeRequest.defaultProps = {
    columns: [
        {
            title: "Date",
            data: "dateStamp",
            type: "date"
        }, {
            title: "From",
            data: "requestedFrom"
        }, {
            title: "Reason",
            data: "reason"
        }, {
            title: "Vendor",
            data: "vendorName",
            type: "vendorLink",
            id: "vendorId"
        }, {
            title: "Fee Requested",
            data: "ProposedVendorFee",
            type: "money"
        }, {
            title: "Status",
            data: "status"
        }
    ]
};

export default VendorFeeRequest;
