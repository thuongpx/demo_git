import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import FeeRequestGrid from "./main-panel-fee-request-grid";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class AgentFeeRequest extends Component {
    constructor(props) {
        super(props);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {
        const { columns, requestedFeeData, orderId } = this.props;

        const agentRequestedFee = requestedFeeData.filter((fee) => {
            return !fee.requestedByVendor;
        });

        return (
            <FeeRequestGrid
                orderId={orderId}
                requestedFees={agentRequestedFee}
                columns={columns}
                modalMode={"FEE_APPROVAL"}
            />
        );
    }
}

AgentFeeRequest.propTypes = {
    columns: PropTypes.array,
    orderId: PropTypes.number,
    requestedFeeData: PropTypes.array
};

AgentFeeRequest.defaultProps = {
    columns: [
        {
            title: "Date",
            data: "dateStamp",
            type: "date"
        }, {
            title: "Reason",
            data: "reason"
        }, {
            title: "Vendor",
            data: "vendorName",
            type: "vendorLink",
            id: "vendorId"
        }, {
            title: "Fee Requested",
            data: "proposedVendorFee",
            type: "money"
        }, {
            title: "Status",
            data: "status"
        }
    ]
};

export default AgentFeeRequest;
