import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { apiGetSignerById } from "Api/signer-api";
import { handleApiError } from "ErrorHandler";
import { convert2PhoneWithFormat } from "Helpers/common-helper";
import noAvatarImg from "./../../../public/images/no-avatar.png";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class UserInfoTooltip extends Component {
    constructor(props) {
        super(props);
        this.state = {
            vendor: {},
            vendorId: this.props.vendorId
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentDidMount() {
        this.getSignerInfor();
    }

    getSignerInfor() {
        apiGetSignerById(this.state.vendorId, (vendorResponse) => {
            this.setState({ vendor: vendorResponse.data.signer });
        }, (error) => handleApiError(this.props.dispatch, error));
    }

    handleAssignVendor() {
        this.props.onAssignVendor();
    }

    handleSendMessage() {
        this.props.onSendMessage();
    }

    render() {
        const { vendor } = this.state;

        return (
            <div>
                <div className="row mr-0 ml-0 vendor-order-info mt-2" style={{ width: "330px" }}>
                    {vendor.ProfilePicture ? <div className="col s3">
                        <div className="image-wrap">
                            <img src={vendor.ProfilePicture} alt="" />
                        </div>
                    </div> : <div className="col s3">
                            <div className="image-wrap">
                                <img src={noAvatarImg} alt="" />
                            </div>
                        </div>}
                    <div className="col s9">
                        <div className="vendor-info-1 w-100">
                            <p style={{ marginRight: "6px", display: "inline-block" }} className="vendorName">{`${vendor.LastName || ""} ${vendor.FirstName || ""}`}</p>
                            <strong className="vendorRole">{`${vendor.Company || ""}`}</strong>
                            <small>
                                <i className="lnr lnr-map-marker"></i> {`${vendor.WeekdayCity || ""}, ${vendor.WeekdayState || ""} ${vendor.WeekdayZip || ""}`}</small>
                            <div className="clear"></div>
                            {vendor.Email ? <p><i className="lnr lnr-envelope"> {vendor.Email}</i></p> : null}
                            {vendor.HomePhone ? <p><i className="lnr lnr-phone-handset"> {`${convert2PhoneWithFormat(vendor.HomePhone)}`}
                            </i></p> : null}
                            {vendor.Mobile ? <p><i className="lnr lnr-smartphone"> {`${convert2PhoneWithFormat(vendor.Mobile)}`}
                            </i> </p> : null}

                            <div className="row">
                                {vendor.isSignerHasNNA ? <div className="col s6 pr-0"><span className="certi" style={{ fontSize: "11px" }}>
                                    <i className="lnr lnr-checkmark-circle"></i> NNA Certified</span></div> : null}
                                {vendor.isSignerTceCertificate ? <div className="col s6 pr-0"><span className="certi" style={{ fontSize: "11px" }}>
                                    <a href={`/vendor-certificate?vendorId=${this.state.vendorId}`} target="_blank">
                                        TCE CERTIFICATION</a></span></div> : null}
                                {vendor.isSignerHasComission ? <div className="col s6 pr-0"><span className="certi" style={{ fontSize: "11px" }}>Commission</span></div> : null}
                                {vendor.isSignerHasBackground ? <div className="col s6 pr-0"><span className="certi" style={{ fontSize: "11px" }}>Background</span></div> : null}
                                {vendor.isSignerHasHELOC ? <div className="col s6 pr-0"><span className="certi" style={{ fontSize: "11px" }}>HELOC</span></div> : null}
                            </div>
                        </div>
                    </div>
                    <div>
                        <div style={{ textAlign: "center" }}>
                            <button style={{ width: "90%" }} className="btn btn-primary action-btn mb-1" onClick={() => this.handleSendMessage()}>MESSAGE</button>
                        </div>
                        <div style={{ textAlign: "center" }}>
                            <button style={{ width: "90%" }} className="btn success-color action-btn" onClick={() => this.handleAssignVendor()}>ASSIGN</button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}


UserInfoTooltip.propTypes = {
    dispatch: PropTypes.func,
    vendorId: PropTypes.number,
    onSendMessage: PropTypes.func,
    orderId: PropTypes.number,
    aptDateTime: PropTypes.string,
    signerUnAcknowledged: PropTypes.array,
    onAssignVendor: PropTypes.func
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { accountId } = authentication;
    const { aptDateTime, signerUnAcknowledged } = state.vendorManage.findAVendor;
    const { orderId } = state.clientOrderDetail.leftPanel.orderInfo;
    return {
        aptDateTime,
        accountId,
        orderId,
        signerUnAcknowledged
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(UserInfoTooltip);