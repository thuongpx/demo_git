import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { apiCancelAutoAssign, apiGetOrderAutoProgress, apiUpdateOrderService } from "Api/orders-api";
import { apiGetSignerById } from "Api/signer-api";
import { handleApiError } from "ErrorHandler";
import { setIsAutoAssigned, setOrderProgressId } from "./../actions/index";
import { convert2PhoneWithFormat } from "Helpers/common-helper";
import VendorReAssignModal from "./vendor-reassign-modal";
import noAvatarImg from "./../../../public/images/no-avatar.png";
import { ORDER_PROGRESS_ID } from "../../../constant/order-detail-constants";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { getCustomerFeedback } from "../actions/right-panel-actions";
import { showSuccess } from "../../main-layout/actions";

class ClientOrderDetailVendorInfo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isHasVendor: false,
            vendor: {},
            isInitial: false
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentWillUnmount() {
        clearInterval(this.checkVendorInterval);
    }

    componentWillMount() {
        this.getOrderAutoProgress();
        this.checkVendorInterval = setInterval(() => {
            this.getOrderAutoProgress();
        }, 10000);
    }

    getOrderAutoProgress() {
        apiGetOrderAutoProgress(this.props.orderId, (response) => {
            const order = response.data.order;
            this.props.dispatch(setIsAutoAssigned(!(!order.autoProgress || order.autoProgress === "D")));
            this.props.dispatch(setOrderProgressId(order.progressId));
            if (order.signerId > 0) {
                apiGetSignerById(order.signerId, (vendorResponse) => {
                    this.setState({ isInitial: true });
                    this.setState({ vendor: vendorResponse.data.signer });
                });
            } else {
                this.setState({ isInitial: true });
            }
            this.setState({ isHasVendor: order.signerId > 0 });
        }, () => this.setState({ isInitial: true }));
    }

    cancelAutoAssign() {
        apiCancelAutoAssign(this.props.orderId, () => {
            this.props.dispatch(setIsAutoAssigned(false));
            this.props.dispatch(setOrderProgressId(ORDER_PROGRESS_ID.OPEN));
        }, (error) => handleApiError(this.props.dispatch, error));
    }

    handleReAssignVendor() {
        this.vendorReAssignModal.show(this.state.vendor);
    }

    handleAssignAVendor() {
        this.props.onAssignAVendor(true);
    }

    handleAssignToTce() {
        const { orderId, dispatch } = this.props;

        const data = {
            orderId,
            isSelfService: false
        };

        apiUpdateOrderService(data, () => {
            dispatch(showSuccess("Assign to TCE successfully!"));
            dispatch(getCustomerFeedback(orderId));
        }, (error) => {
            handleApiError(dispatch, error);
        });
    }

    render() {
        const { vendor, isHasVendor, isInitial } = this.state;
        const { roleType, isSelfService, progressId } = this.props;

        const isClosingOrder = progressId === ORDER_PROGRESS_ID.CLOSING_COMPLETED || progressId === ORDER_PROGRESS_ID.CLOSED_PENDING_QC_REVIEW || progressId === ORDER_PROGRESS_ID.CLOSED_PENDING_REVIEW_PC_RESOLUTION;

        const renderVendor = () => {
            if (isHasVendor) {
                return (
                    <div>
                        {isInitial ? <div className="row vendor-order-info p-1">
                            {vendor.ProfilePicture ? <div className="col s3">
                                <div className="image-wrap">
                                    <img src={vendor.ProfilePicture} alt="" />
                                </div>
                            </div> : <div className="col s3">
                                    <div className="image-wrap">
                                        <img src={noAvatarImg} alt="" />
                                    </div>
                                </div>}
                            <div className="col s9">
                                <div className="vendor-info-1">
                                    <p style={{ marginRight: "6px", display: "inline-block", fontSize: "15pt", fontWeight: 500 }} className="vendorName">{`${vendor.FirstName || ""} ${vendor.LastName || ""}`}</p>
                                    {!isClosingOrder && <button onClick={() => this.handleReAssignVendor()} type="button" className="btn btn-small default-color modal-trigger" data-target="modalReassign">UNASSIGN</button>}
                                    <strong className="vendorRole">{`${vendor.Company || ""}`}</strong>
                                    <small style={{ fontSize: "9pt", color: "#9b9b9b" }}>
                                        <i className="lnr lnr-map-marker"></i> {`${vendor.WeekdayCity || ""}, ${vendor.WeekdayState || ""} ${vendor.WeekdayZip || ""}`}</small>
                                    <div className="clear"></div>
                                    {vendor.HomePhone ? <strong className="phone-primary mt-1">{`${convert2PhoneWithFormat(vendor.HomePhone)}`}
                                        <small className="prefix-sm">Home</small>
                                    </strong> : null}
                                    {vendor.Mobile ? <strong className="mobile-primary">{`${convert2PhoneWithFormat(vendor.Mobile)}`}
                                        <small className="prefix-sm">Mobile</small>
                                    </strong> : null}
                                    {vendor.isSignerHasNNA ? <p className="certi">
                                        <i className="lnr lnr-checkmark-circle"></i> NNA Certified</p> : null}
                                    <div className="clear"></div>
                                    <div className="row">
                                        {vendor.isSignerHasAttorneyBarCard ? <div className="col s6"><p className="certi truncate mt-0 mb-0" title="Attorney Bar Card">Attorney Bar Card</p></div> : null}
                                        {vendor.isSignerHasBackground ? <div className="col s6"><p className="certi truncate mt-0 mb-0" title="Background Check">Background Check</p></div> : null}
                                        {vendor.isSignerHasBond ? <div className="col s6"><p className="certi truncate mt-0 mb-0" title="Bond">Bond</p></div> : null}
                                        {vendor.isSignerHasChosingAgentLicense ? <div className="col s6"><p className="certi truncate mt-0 mb-0" title="Chosing Agent License">Chosing Agent License</p></div> : null}
                                        {vendor.isSignerHasComission ? <div className="col s6"><p className="certi truncate mt-0 mb-0" title="Commission">Commission</p></div> : null}
                                        {vendor.isSignerHasErrorAndOmissionInsurance ? <div className="col s6"><p className="certi truncate mt-0 mb-0" title="Errors & Omission Insurance">E & O Insurance</p></div> : null}
                                        {vendor.isSignerHasLicenseTitleProducer ? <div className="col s6"><p className="certi truncate mt-0 mb-0" title="License Title Producer">License Title Producer</p></div> : null}
                                        {vendor.isSignerHasPassedBasicTest ? <div className="col s6"><p className="certi truncate mt-0 mb-0" title="Must Pass Basice Notary Test">Must Pass Basice Notary Test</p></div> : null}
                                    </div>
                                </div>
                            </div>
                        </div> : null}
                    </div>

                );
            } else if (this.props.isAutoAssigned) {
                return (
                    <div className="row vendor-order-info mt-2 center-align">
                        <div className="col s12">
                            <p>VENDOR AUTO ASSIGN IN-PROGRESS...</p>
                            <a className="btn btn-small default-color" onClick={() => this.cancelAutoAssign()}>CANCEL</a>
                        </div>
                    </div>
                );
            } else {
                return (
                    <div className="vendor-order-info center-align">
                        {roleType !== "Staff" ? <div className="col s12 p-1">
                            <div>
                                <button className="btn btn-small success-color w-100" onClick={() => this.handleAssignAVendor()}>ASSIGN A VENDOR</button>
                            </div>
                            {/* AnNV2: Only show this button if the order is self service */}
                            {isSelfService && <div>
                                <div><span style={{ fontSize: "9pt", color: "#9b9b9b", display: "block", marginBottom: ".5rem", marginTop: ".5rem" }}>OR</span></div>

                                <div>
                                    <button className="btn btn-small default-color w-100" onClick={() => this.handleAssignToTce()}>HAVE TCE FULFILL ORDER</button>
                                </div>
                            </div>}
                        </div> :
                            <div className="col s12 p-1">
                                <div>
                                    <button className="btn btn-small success-color w-100" onClick={() => this.handleAssignAVendor()}>ASSIGN A VENDOR</button>
                                </div>
                            </div>
                        }
                    </div>
                );
            }
        };

        return (
            <div>
                {renderVendor()}
                <VendorReAssignModal onRemoveVendor={() => {
                    this.setState({ isHasVendor: false });
                    this.props.dispatch(setIsAutoAssigned(false));
                }} orderId={this.props.orderId} ref={(vendorReAssignModal) => {
                    if (vendorReAssignModal && vendorReAssignModal.getWrappedInstance) {
                        this.vendorReAssignModal = vendorReAssignModal.getWrappedInstance();
                    }
                }}
                />
            </div>
        );
    }
}


ClientOrderDetailVendorInfo.propTypes = {
    params: PropTypes.object,
    router: PropTypes.object,
    dispatch: PropTypes.func,
    accountId: PropTypes.number,
    brokerId: PropTypes.number,
    orderId: PropTypes.number,
    isAutoAssigned: PropTypes.bool,
    onAssignAVendor: PropTypes.func,
    roleType: PropTypes.string,
    isSelfService: PropTypes.bool,
    progressId: PropTypes.number
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { accountId, role } = authentication;
    const { roleType } = role;
    const { isAutoAssigned } = state.clientOrderDetail.vendorInfo;
    return {
        accountId,
        isAutoAssigned,
        roleType
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(ClientOrderDetailVendorInfo);