import React from "react";
import { connect } from "react-redux";
import { Component } from "react";
import PropTypes from "prop-types";
import moment from "moment";
import NumberFormat from "react-number-format";

import { handleApiError } from "ErrorHandler";
import { Modal, ModalBody, ModalTitle, ModalFooter } from "Modal";
import CommonModal from "CommonModal";
import Select from "Select";

import { guid } from "Helpers/crypto-helper";
import { thousandSep, hasStringValue } from "Helpers/common-helper";
import { validateRequired, requireMessage, requireComboBoxMessage } from "Helpers/validation-helper";
import { showSuccess, showError } from "../../main-layout/actions";

import { apiAddComment, getCommentByType, apiAddMultiComment } from "Api/comment-api";
import { apiAddNewOrderProgress } from "Api/order-progress-api";
import { apiGetOrderFeeApprovalReasonStaff } from "Api/order-fee-approve-api";
import { apiAddNewRequestFee } from "Api/order-fee-api";
import {
    apiCheckVendorAssignConditionsOfOrder,
    apiApproveFeeRequest,
    apiSubmitFeeRequestToMgr,
    apiSubmitFeeRequestToMgrSendMail
} from "Api/order-request-approval-api";

import { FEE_SUBMIT } from "../../../constant/progress-log-constants";
import { COMMENT_TYPE, CLIENT_SUB_ROLE, ORDER_REQUEST_APPROVE_STATUS } from "Constants";
import { ACTION } from "../../../constant/progress-log-constants";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";

import { emitOnSubmitFeeRequest } from "../../../socket/orders";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

export class ApprovalModal extends Component {
    constructor(props) {
        super(props);

        this.modalId = guid();

        this.state = {
            commentText: "",
            isCommentDisable: true,

            isApproveDisable: true,
            isDeclineDisable: true,
            isSubmitDisable: true,

            comments: [],

            // list fee request state
            currentFeeRequestIndex: 0,
            reason: {
                value: "",
                message: ""
            },
            requestAmount: {
                value: "",
                message: ""
            },

            reasonSelectList: [
            ]
        };
    }

    componentWillReceiveProps(nextProps) {
        const { isShow, dispatch, profile } = this.props;
        //init data when change mode
        if (!isShow && nextProps.isShow) {
            if (nextProps.mode === "FEE_APPROVAL") {
                const status = nextProps.feeApproval.status;
                const isApproveDisable = status !== ORDER_REQUEST_APPROVE_STATUS.OPEN || profile.subRoleType === CLIENT_SUB_ROLE.AGENT;
                const isDeclineDisable = status !== ORDER_REQUEST_APPROVE_STATUS.OPEN || profile.subRoleType === CLIENT_SUB_ROLE.AGENT;

                this.setState({
                    isApproveDisable,
                    isDeclineDisable
                });
                this.getAprrovalsComments(nextProps);
            }
            if (nextProps.mode === "AUTO_FEE_APPROVAL") {
                const { status, originalAmount, requestAmount } = nextProps.feeApproval;
                const isApproveDisable = status !== ORDER_REQUEST_APPROVE_STATUS.OPEN || originalAmount * 1.1 < requestAmount;
                const isDeclineDisable = status !== ORDER_REQUEST_APPROVE_STATUS.OPEN;
                const isSubmitDisable = status !== ORDER_REQUEST_APPROVE_STATUS.OPEN;

                this.setState({
                    isApproveDisable,
                    isDeclineDisable,
                    isSubmitDisable
                });
                this.getAprrovalsComments(nextProps);
            }
            if (nextProps.mode === "FEE_REQUETS") {
                apiGetOrderFeeApprovalReasonStaff((result) => {
                    this.setState({
                        reasonSelectList: result.data.result
                    });
                }, (error) => handleApiError(dispatch, error));
                this.setState({
                    comments: [],
                    currentFeeRequestIndex: 0,
                    reason: {
                        value: "",
                        message: ""
                    },
                    requestAmount: {
                        value: nextProps.feeRequests[0].requestedFee,
                        message: ""
                    },
                    isRequestedFeeEditable: nextProps.feeRequests[0].requestedFee === undefined
                });
            }
        }
    }

    getAprrovalsComments(props) {
        const { mode, feeApproval, dispatch } = props;
        const filter = {};

        if (mode === "FEE_APPROVAL" || mode === "AUTO_FEE_APPROVAL") {
            filter.typeId = COMMENT_TYPE.RequestFeeCommentType;
            filter.ownerId = feeApproval.approvalId;
        }

        getCommentByType(filter, (result) => {
            const comments = result.data ? result.data : [];

            this.setState({
                comments
            });
        }, (error) => handleApiError(dispatch, error));
    }

    handleAddComment() {
        const { mode, feeApproval, profile, dispatch } = this.props;
        const comment = {
            Description: this.state.commentText,
            ParentID: null,
            CreatedBy: profile.userId,
            CreatedDate: moment().format("YYYY-MM-DD HH:mm:ss")
        };

        if (mode === "FEE_APPROVAL" || mode === "AUTO_FEE_APPROVAL") {
            comment.TypeID = COMMENT_TYPE.RequestFeeCommentType;
            comment.OwnerID = feeApproval.approvalId;
        }

        this.setState({
            commentText: "",
            isCommentDisable: true
        });

        if (mode === "FEE_REQUETS") {
            comment.TypeID = COMMENT_TYPE.RequestFeeCommentType;
            comment.UserName = profile.userName;
            this.state.comments.splice(0, 0, comment);
            this.setState({
            });
            return;
        }

        apiAddComment(comment, (response) => {
            if (response.data.isSuccess) {
                this.getAprrovalsComments(this.props);
            }
        }, (error) => handleApiError(dispatch, error));
    }

    handleInputsChange(field, value) {
        if (field === "commentText") {
            this.setState({
                commentText: value,
                isCommentDisable: !(value && value.trim())
            });
        }
        if (field === "reason") {
            this.setState({
                [field]: {
                    value,
                    isDirty: true
                }
            }, this.validateInputsFeeRequest);
        } else if (field === "requestAmount") {
            if (value.length <= 9) {
                this.setState({
                    [field]: {
                        value,
                        isDirty: true
                    }
                }, this.validateInputsFeeRequest);
            } else {
                this.setState({
                    [field]: {
                        value: this.state.requestAmount.value,
                        isDirty: true
                    }
                }, this.validateInputsFeeRequest);
            }
        } else {
            this.setState({
                [field]: value
            });
        }
    }

    handleClose(needReload) {
        this.props.onClose(needReload);
        this.setState({
            commentText: "",
            isCommentDisable: true
        });
    }

    // FEE APPROVE START
    updateFeeApproval(isApprove) {
        const { feeApproval, profile, dispatch } = this.props;
        const { orderId } = this.props.feeApproval;
        const approvalData = {
            feeApprovalId: feeApproval.approvalId,
            orderId: feeApproval.orderId,
            signerId: feeApproval.signerId,
            usersId: profile.userId,
            isApprove,
            feeApprovalDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            requestAmount: feeApproval.requestAmount,
            originalAmount: feeApproval.originalAmount,
            feeDescripId: feeApproval.feeDescripId,
            activity: `${profile.userName} ${isApprove ? `approved` : `declined`} the fee request ${feeApproval.vendorName !== "" ? `for ${feeApproval.vendorName}` : ``}`,
            progressType: ACTION,
            offerId: feeApproval.offerId,
            signerFee: feeApproval.signerFee,
            reason: feeApproval.reason,
            requestedBy: feeApproval.requestedBy,
            requestedByVendor: feeApproval.requestedByVendor
        };

        const updateFeeApproval = () => {
            apiApproveFeeRequest(approvalData, () => {
                this.handleClose(true);
                dispatch(showSuccess(isApprove ? "Approved Successfully" : "This request has been rejected"));
                emitOnSubmitFeeRequest(orderId);
            }, (error) => {
                if (error.response !== undefined) {
                    if (error.response.data.message === "No Rows Updated") {
                        dispatch(showError("Save conflict!"));
                        emitOnSubmitFeeRequest(orderId);
                    } else {
                        dispatch(showError(error.response.data.message));
                    }
                } else {
                    dispatch(showError(`Unable to connect ${error.config.url}`));
                }
                this.handleClose(true);
            });
        };

        if (isApprove) {
            this.commonModal.showModal({
                type: "confirm",
                message: "Approving this fee request means all other fee requests for this order will be rejected. Are you sure you would like to approve this fee request?"
            }, () => {
                updateFeeApproval();
            }, () => {
                this.handleClose(false);
            });
        } else {
            updateFeeApproval();
        }
    }

    handleFeeApprove(isApprove) {
        const { feeApproval, dispatch } = this.props;

        const checkData = {
            orderId: feeApproval.orderId,
            signerId: feeApproval.signerId
        };

        if (!isApprove) {
            this.updateFeeApproval(false);
        } else {
            apiCheckVendorAssignConditionsOfOrder(checkData, (result) => {
                switch (result.data.case) {
                    case "SUCCESS": {
                        this.updateFeeApproval(true);
                        break;
                    }
                    case "SIGNER_ALREADY": {
                        this.commonModal.showModal({
                            type: "confirm",
                            message: "Another Vendor has been assigned to this order. Do you want to replace that Vendor?"
                        }, () => {
                            this.updateFeeApproval(true);
                        }, () => {
                            this.updateFeeApproval(false);
                        });
                        break;
                    }
                    case "ADT_DUPLICATED": {
                        dispatch(showError("This Vendor has already assigned to another order having the same Appointment Date time.", () => {
                            this.updateFeeApproval(false);
                        }));
                        break;
                    }
                    case "CLOSED_ORDER": {
                        dispatch(showError("This Order has already closed", () => {
                            this.updateFeeApproval(false);
                        }));
                        break;
                    }
                }
            }, (error) => handleApiError(dispatch, error));
        }
    }

    handleSubmitFeeApproveToMgr() {
        const { feeApproval, profile, dispatch } = this.props;
        const { orderId } = feeApproval;
        const approvalData = {
            feeApprovalId: feeApproval.approvalId,
            usersId: profile.userId
        };
        const mailData = {
            orderId: feeApproval.orderId,
            signerId: feeApproval.signerId,
            requestAmount: feeApproval.requestAmount,
            originalAmount: feeApproval.originalAmount,
            reason: feeApproval.reason,
            vendorName: feeApproval.vendorName
        };

        const log = {
            OrderId: orderId,
            Activity: `${profile.userName} submitted a fee request.`,
            UsersId: profile.userId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            ProgressType: ACTION
        };

        apiSubmitFeeRequestToMgr(approvalData, () => {
            this.handleClose(true);
            apiAddNewOrderProgress(log,
                () => {
                },
                (error) => handleApiError(error)
            );
            dispatch(showSuccess("Submit Successfully"));
            emitOnSubmitFeeRequest(orderId);
            apiSubmitFeeRequestToMgrSendMail(mailData);
        }, (error) => handleApiError(dispatch, error));

    }

    renderFeeApproval() {
        const { feeApproval } = this.props;

        return (
            <div>
                <div className="row">
                    <div className="col s6">
                        <div className="row valign-wrapper">
                            <div className="col s6">
                                <b>Fee Approval Status:</b>
                            </div>
                            <div className="col s6">
                                {feeApproval.status}
                            </div>
                        </div>
                    </div>
                    <div className="col s6">
                        <div className="row valign-wrapper">
                            <div className="col s6">
                            </div>
                            <div className="col s6">
                            </div>
                        </div>
                    </div>
                </div>

                <div className="row">
                    <div className="col s6">
                        <div className="row valign-wrapper">
                            <div className="col s6">
                                <b>Original Fee to Vendor:</b>
                            </div>
                            <div className="col s6">
                                ${thousandSep(parseFloat(feeApproval.originalAmount ? feeApproval.originalAmount : 0).toFixed(2))}
                            </div>
                        </div>
                    </div>
                    <div className="col s6">
                        <div className="row valign-wrapper">
                            <div className="col s6">
                                <b>Requested Fee to Vendor:</b>
                            </div>
                            <div className="col s6">
                                ${thousandSep(parseFloat(feeApproval.requestAmount ? feeApproval.requestAmount : 0).toFixed(2))}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col s6">
                        <div className="row valign-wrapper">
                            <div className="col s6">
                                <b>Status Reason:</b>
                            </div>
                            <div className="col s6">
                                {feeApproval.reason}
                            </div>
                        </div>
                    </div>
                    <div className="col s6">
                        <div className="row valign-wrapper">
                            <div className="col s6">
                                <b>Vendor Name:</b>
                            </div>
                            <div className="col s6">
                                {feeApproval.vendorName}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
    // FEE APPROVE END

    // FEE REQUEST START
    saveFeeRequest(obj) {
        const { dispatch, profile, feeRequests } = this.props;
        const { currentFeeRequestIndex } = this.state;
        const orderId = feeRequests[currentFeeRequestIndex].orderId;
        const { requestAmount, reason, reasonSelectList } = this.state;


        const log = {
            OrderId: feeRequests[currentFeeRequestIndex].orderId,
            Activity: `${profile.userName} submitted a fee request.`,
            UsersId: profile.userId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            ProgressType: FEE_SUBMIT
        };

        const currentReason = reasonSelectList.find((item) => {
            return (item.ReasonCode.toString() === reason.value.toString());
        });

        const mailData = {
            orderId,
            signerId: feeRequests[currentFeeRequestIndex].signerId,
            requestAmount: requestAmount.value,
            originalAmount: feeRequests[currentFeeRequestIndex].originalAmount,
            reason: currentReason ? currentReason.ReasonDescription : null,
            vendorName: feeRequests[currentFeeRequestIndex].vendorName
        };

        apiAddNewRequestFee(obj,
            (result) => {
                const commentList = obj.comments.filter((item) => {
                    delete item.UserName;
                    item.OwnerID = result.data.feeApprovalId;
                    return item;
                });
                apiSubmitFeeRequestToMgrSendMail(mailData);
                apiAddMultiComment(commentList, () => {
                    apiAddNewOrderProgress(log,
                        () => {
                            emitOnSubmitFeeRequest(orderId);
                            dispatch(showSuccess("Saved successfully!"));
                        }, (error) => handleApiError(dispatch, error)
                    );
                }, (error) => handleApiError(dispatch, error));
            }, (error) => handleApiError(dispatch, error));
    }

    validateInputsFeeRequest() {
        const { reason, requestAmount } = this.state;

        if (reason.isDirty && !validateRequired(reason.value)) {
            reason.message = requireComboBoxMessage("Status Reason");
            reason.messageType = "required-field";
        }

        if (requestAmount.isDirty && !validateRequired(requestAmount.value)) {
            requestAmount.message = requireMessage("Requested Fee to Vendor");
            requestAmount.messageType = "required-field";
        }

        this.setState({
            reason,
            requestAmount
        });
        return (!(hasStringValue(reason.messageType) || hasStringValue(requestAmount.messageType)));
    }

    validateFormFeeRequest() {
        const { reason, requestAmount } = this.state;

        reason.isDirty = true;
        requestAmount.isDirty = true;
        return this.validateInputsFeeRequest();
    }

    handleNextFeeRequest() {
        const { feeRequests, profile, dispatch } = this.props;
        const { comments, reason, requestAmount, reasonSelectList } = this.state;
        let { currentFeeRequestIndex } = this.state;

        if (!this.validateFormFeeRequest()) {
            if (hasStringValue(requestAmount.message)) {
                this.requestAmountRef.focus();
                return;
            }
            if (hasStringValue(reason.message)) {
                //focus select field
            }
            return;
        }


        if (reason.value.toString() === reasonSelectList.find(item => item.ReasonDescription === "Other (Must add comments)").ReasonCode.toString() && comments.length === 0) {
            dispatch(showError(`You should add comment before submitting the request.`));
            return;
        }

        const saveObj = {
            userId: profile.userId,
            orderId: feeRequests[currentFeeRequestIndex].orderId,
            signerId: feeRequests[currentFeeRequestIndex].signerId,
            originalAmount: feeRequests[currentFeeRequestIndex].originalAmount,
            vendorName: feeRequests[currentFeeRequestIndex].vendorName,
            comments,
            reasonCode: reason.value,
            proposedFee: requestAmount.value,
            feeDescripId: feeRequests[currentFeeRequestIndex].feeDescripId,
            description: "", // hard code because of DB changed
            status: ORDER_REQUEST_APPROVE_STATUS.OPEN
        };

        this.saveFeeRequest(saveObj);

        if (feeRequests.length - 1 > currentFeeRequestIndex) {
            this.setState({
                currentFeeRequestIndex: ++currentFeeRequestIndex,
                reason: {
                    value: "",
                    message: ""
                },
                requestAmount: {
                    value: "",
                    message: ""
                },
                comments: []
            });
        } else {
            this.handleClose(false);
        }
    }

    renderFeeRequest() {
        const { feeRequests } = this.props;
        const { requestAmount, reason, currentFeeRequestIndex } = this.state;
        const feeRequest = feeRequests[currentFeeRequestIndex];

        return (
            <div>
                <div className="row">
                    <div className="col s6">
                        <b>Submit for Fee Approval</b>
                    </div>
                    <div className="col s6">
                    </div>
                </div>

                <div className="row valign-wrapper">
                    <div className="col s6">
                        <div className="row valign-wrapper">
                            <div className="col s6">
                                <b>Original Fee to Vendor:</b>
                            </div>
                            <div className="col s6">
                                ${thousandSep(parseFloat(feeRequest.originalAmount ? feeRequest.originalAmount : 0).toFixed(2))}
                            </div>
                        </div>
                    </div>
                    <div className="col s6">
                        <div className="row valign-wrapper">
                            <div className="col s6">
                                <b>Requested Fee to Vendor:</b>
                            </div>
                            {this.state.isRequestedFeeEditable ? <div className={`col s6 input-field required suffixinput ${requestAmount.messageType ? requestAmount.messageType : ""}`}>
                                <NumberFormat
                                    id={`${this.modalId}-requestAmount`}
                                    ref="requestAmount"
                                    thousandSeparator
                                    fixedDecimalScale
                                    prefix={"$"}
                                    decimalScale={2}
                                    value={requestAmount.value || ""}
                                    onValueChange={(values) => this.handleInputsChange("requestAmount", values.value)}
                                    getInputRef={(elm) => (this.requestAmountRef = elm)}
                                />
                                <label htmlFor="requestAmount"></label>
                                <span className={`suffix-text ${requestAmount.messageType === "required-field" ? "" : "hide"}`}>
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requestAmount.message} />
                                </span>
                            </div> :
                                <div className="col s6">
                                    ${thousandSep(parseFloat(requestAmount.value ? requestAmount.value : 0).toFixed(2))}
                                </div>}
                        </div>
                    </div>
                </div>
                <div className="row valign-wrapper">
                    <div className={`${this.props.fromFeeTab ? `col s12` : `col s6`}`}>
                        <div className="row valign-wrapper">
                            <div className={`${this.props.fromFeeTab ? `col s2` : `col s6`}`}>
                                <span><b>Status Reason: </b></span>
                            </div>
                            <div className={`${this.props.fromFeeTab ? `col s10` : `col s6`}`}>
                                <div
                                    className={`input-field required suffixinput
                                ${reason.messageType ? reason.messageType : ""}`}
                                >
                                    <Select
                                        ref="reason" id={`${this.modalId}-reason`}
                                        dataSource={this.state.reasonSelectList}
                                        onChange={(value) => { this.handleInputsChange("reason", value); }}
                                        mapDataToRenderOptions={{ value: "ReasonCode", label: ["ReasonDescription"] }}
                                        value={reason.value}
                                        optionDefaultLabel={"Select..."}
                                    />
                                    <label htmlFor={`${this.modalId}-reason`}></label>

                                    <span className={`suffix-text ${reason.messageType === "required-field" ? "" : "hide"}`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={reason.message} />
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    {this.props.fromFeeTab ? null : <div className="col s6">
                        <div className="row valign-wrapper">
                            <div className="col s6">
                                <b>Vendor Name:</b>
                            </div>
                            <div className="col s6">
                                {feeRequest.vendorName}
                            </div>
                        </div>
                    </div>}
                </div>
            </div>
        );
    }
    // FEE REQUEST END

    renderComments() {
        const { comments } = this.state;

        return (
            <div>
                <div className="row">
                    <div className="col s12">
                        <p><b>Description</b></p>
                        <div className="letter_agree" style={{ maxHeight: 150, marginTop: 0 }}>
                            <div className="termdata">
                                <ul style={{ margin: 0 }}>
                                    {comments !== undefined &&
                                        comments.map((data, index) => {
                                            if (hasStringValue(data.Description)) {
                                                return (
                                                    <li key={index} style={{ marginBottom: 5 }}>
                                                        {data.Description}
                                                        <span style={{
                                                            display: "block", fontSize: "9pt", color: "#948d8d", paddingLeft: "15px"
                                                        }}>
                                                            -{data.UserName}- {moment(data.CreatedDate).format("MM/DD/YY @ h:mm A")}
                                                        </span>
                                                    </li>
                                                );
                                            } else {
                                                return "";
                                            }
                                        }
                                        )
                                    }
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <form onSubmit={(e) => {
                    e.preventDefault();
                    this.handleAddComment();
                }}>
                    <div className="row">
                        <div className="input-field col s10 mt-0">
                            <input type="text" id={`${this.modalId}-commentText`} ref="commentText" className="validate"
                                maxLength="250"
                                value={this.state.commentText}
                                onChange={(e) => this.handleInputsChange("commentText", e.target.value)}
                            ></input>
                            <label htmlFor={`${this.modalId}-commentText`}>Add Comment</label>
                        </div>

                        <div className="col s2">
                            <button className="btn success-color w-100"
                                disabled={this.state.isCommentDisable}
                            >Enter</button>
                        </div>
                    </div>
                </form>
            </div>
        );
    }

    renderContent() {
        const { mode } = this.props;

        switch (mode) {
            case "FEE_APPROVAL": {
                return (
                    <div className="tab-content" style={{ padding: "5px" }}>
                        {this.renderFeeApproval()}
                        {this.renderComments()}
                    </div>
                );
            }
            case "AUTO_FEE_APPROVAL": {
                return (
                    <div className="tab-content" style={{ padding: "5px" }}>
                        {this.renderFeeApproval()}
                        {this.renderComments()}
                    </div>
                );
            }
            case "FEE_REQUETS": {
                return (
                    <div className="tab-content" style={{ padding: "5px" }}>
                        {this.renderFeeRequest()}
                        {this.renderComments()}
                    </div>
                );
            }
            default:
                return "";
        }
    }

    renderButton() {
        const { mode } = this.props;

        switch (mode) {
            case "FEE_APPROVAL": {
                return (
                    <div className="row m-0">
                        <div className="col m4">
                            <button className="btn white w-100" onClick={() => this.handleClose(false)}>Cancel</button>
                        </div>
                        <div className="col m4">
                            <button className="btn success-color w-100"
                                onClick={() => { this.handleFeeApprove(true); }}
                                disabled={this.state.isApproveDisable}
                            >Approve</button>
                        </div>
                        <div className="col m4">
                            <button className="btn error-color w-100"
                                onClick={() => { this.handleFeeApprove(false); }}
                                disabled={this.state.isDeclineDisable}
                            >Decline</button>
                        </div>
                    </div>
                );
            }
            case "AUTO_FEE_APPROVAL": {
                return (
                    <div className="row m-0">
                        <div className="col m3">
                            <button className="btn white w-100" onClick={() => this.handleClose(false)}>Cancel</button>
                        </div>
                        <div className="col m3">
                            <button className="btn success-color w-100"
                                onClick={() => { this.handleFeeApprove(true); }}
                                disabled={this.state.isApproveDisable}
                            >Approve</button>
                        </div>
                        <div className="col m3">
                            <button className="btn error-color w-100" onClick={() => { this.handleFeeApprove(false); }}
                                disabled={this.state.isDeclineDisable}
                            >Decline</button>
                        </div>
                        <div className="col m3">
                            <button className="btn success-color w-100" onClick={() => { this.handleSubmitFeeApproveToMgr(); }}
                                disabled={this.state.isSubmitDisable}
                            >Submit to Mgr</button>
                        </div>
                    </div>
                );
            }
            case "FEE_REQUETS":
                return (
                    <div className="row m-0">
                        <div className="col m6">
                            <button className="btn white w-100" onClick={() => this.handleClose(false)}>Cancel</button>
                        </div>
                        <div className="col m6">
                            <button className="btn success-color w-100" onClick={() => this.handleNextFeeRequest()}>Submit to Mgr</button>
                        </div>
                    </div>
                );
            default:
                return "";
        }
    }

    renderTitle() {
        const { mode } = this.props;

        switch (mode) {
            case "FEE_APPROVAL": {
                return (
                    <div>
                        <ModalTitle onClickClose={() => this.handleClose(false)}>Fee Approval Request Details</ModalTitle>
                    </div>
                );
            }
            case "AUTO_FEE_APPROVAL": {
                return (
                    <div>
                        <ModalTitle onClickClose={() => this.handleClose(false)}>Fee Approval Request Details</ModalTitle>
                    </div>
                );
            }
            case "FEE_REQUETS": {
                return (
                    <ModalTitle onClickClose={() => this.handleClose(false)}>
                        <div style={{ width: "95%", display: "inline-block" }}>
                            Fee Approval Request Details
                            {this.props.fromFeeTab ? null : <small className="right">{`Request ${this.state.currentFeeRequestIndex + 1} of ${this.props.feeRequests.length}`}</small>}
                        </div>
                    </ModalTitle>
                );
            }
            default:
                return "";
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {
        const { isShow } = this.props;

        return (
            <div>
                <Modal size={""} isOpen={isShow} addClass="no-tab">
                    <ModalBody>
                        {this.renderTitle()}
                        {this.renderContent()}
                    </ModalBody>
                    <ModalFooter>
                        {this.renderButton()}
                    </ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

ApprovalModal.defaultProps = {
    feeRequests: []
};

ApprovalModal.propTypes = {
    dispatch: PropTypes.func,
    isShow: PropTypes.bool,
    mode: PropTypes.string,
    feeApproval: PropTypes.object,
    onClose: PropTypes.func,
    profile: PropTypes.object,
    feeRequests: PropTypes.array,
    fromFeeTab: PropTypes.bool
};

const mapStateToProps = (state) => {
    return {
        profile: state.authentication.profile
    };
};

export default connect(mapStateToProps)(ApprovalModal);