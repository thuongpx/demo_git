import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import Select from "Select";
import { hasStringValue, hasStringValueTrim } from "../../../helpers/common-helper";
import moment from "moment";
import { showSuccess } from "../../main-layout/actions";
import { handleApiError } from "ErrorHandler";
import { apiAddNewOrderProgress } from "Api/order-progress-api";
import { apiGetRecentVendorData } from "Api/orders-api";
import { MESSAGE_SENT, MESSAGE_RECEIVE } from "../../../constant/progress-log-constants";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { apiSendMailToVendorCommunication, apiSendSmsToVendorCommunication } from "Api/email-api.js";

class MainPanelVendorCommunication extends Component {
    constructor(props) {
        super(props);
        this.state = {
            listRecentVendor: [],
            email: true,
            sms: false
        };
    }

    componentDidMount() {
        this.refs.message.focus();
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentWillMount() {
        const { dispatch, orderId } = this.props;

        apiGetRecentVendorData(orderId, (result) => {
            this.setState({
                listRecentVendor: result.data
            });
        }, (error) => handleApiError(dispatch, error));
    }

    isSubmitEnabled() {
        return (hasStringValueTrim(this.state.message) && (this.state.email || this.state.sms));
    }

    isResetEnabled() {
        return (hasStringValue(this.state.recentVendor) || hasStringValue(this.state.message));
    }

    handleInputChanged(key, value) {
        this.setState({
            ...this.state,
            [key]: value
        });

    }

    handleCheckboxChanged(checkbox) {
        if (checkbox === "email") {
            this.setState({
                ...this.state,
                email: !this.state.email
            });
        } else {
            this.setState({
                ...this.state,
                sms: !this.state.sms
            });
        }
    }

    handleReset() {
        this.setState({
            recentVendor: "",
            message: "",
            email: true,
            sms: false
        });
    }

    async handleSubmit() {
        const { dispatch, accountId, orderId, userName, vendorName, roleType } = this.props;
        const recentVendorSelected = this.state.listRecentVendor.find(item => item.id.toString() === this.state.recentVendor);
        const VendorName = (roleType !== "Staff" ? recentVendorSelected.name : vendorName);
        const message = this.state.message;

        if (this.state.email) {
            await apiSendMailToVendorCommunication({ message, usersId: accountId, orderId },
                () => {

                }, (error) => handleApiError(dispatch, error)
            );
        }

        if (this.state.sms) {
            await apiSendSmsToVendorCommunication({ message, orderId },
                () => {

                }, (error) => handleApiError(dispatch, error)
            );
        }

        //log sent
        const log = {
            OrderId: orderId,
            Activity: `Message sent to ${VendorName}`,
            UsersId: accountId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            ProgressType: MESSAGE_SENT,
            Message: message
        };

        //add activity log
        await apiAddNewOrderProgress(log,
            () => {
                dispatch(showSuccess(`Message sent to ${VendorName}.`));
            }, (error) => handleApiError(dispatch, error)
        );

        //log receive
        const logReceive = {
            OrderId: orderId,
            Activity: `Message receive from ${userName}`,
            UsersId: accountId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            ProgressType: MESSAGE_RECEIVE,
            Message: message
        };
        //add activity log receive
        await apiAddNewOrderProgress(logReceive,
            () => {

            }, (error) => handleApiError(dispatch, error)
        );

        this.handleReset();
    }

    render() {
        const { roleType } = this.props;

        return (
            <div className="row mt-1">

                {roleType !== "Staff" ? <div className="col s12 m12 input-field">
                    <Select
                        dataSource={this.state.listRecentVendor}
                        mapDataToRenderOptions={{ value: "id", label: "name" }}
                        onChange={(value) => this.handleInputChanged("recentVendor", value)}
                        value={this.state.recentVendor}
                        optionDefaultLabel="Select recent vendor"
                        ref="recentVendor"
                        id="recentVendor"
                    />
                    <label htmlFor="recentVendor">To:</label>
                </div> : ""}
                <div className="col s12 m12">
                    <textarea ref="message" className="materialize-textarea" placeholder="Enter a message" style={{ height: "90px" }}
                        onChange={(event) => this.handleInputChanged("message", event.target.value)} value={this.state.message}
                    />
                </div>

                <div className="col m2 s6">
                    <label>
                        <input type="checkbox" defaultChecked={this.state.email} onClick={() => this.handleCheckboxChanged("email")} />
                        <span>Email</span>
                    </label>
                </div>
                <div className="col m2 s6">
                    <label>
                        <input type="checkbox" defaultChecked={this.state.sms} onClick={() => this.handleCheckboxChanged("sms")} />
                        <span>SMS</span>
                    </label>
                </div>
                <div className="clear bg-show-on-small mt-1 mb-1"></div>
                <div className="right">
                    <button className="btn success-color action-btn right" disabled={!this.isSubmitEnabled()} onClick={() => this.handleSubmit()}>SEND MESSAGE</button>
                    <button className="btn white action-btn right" disabled={!this.isResetEnabled()} onClick={() => this.handleReset()}>RESET</button>
                </div>
            </div>
        );
    }
}

MainPanelVendorCommunication.propTypes = {
    dispatch: PropTypes.func.isRequired,
    accountId: PropTypes.number,
    orderId: PropTypes.number,
    userName: PropTypes.string,
    roleType: PropTypes.string,
    vendorName: PropTypes.string
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { accountId, profile, role } = authentication;
    const { userName } = profile;
    const { roleType } = role;
    return {
        accountId,
        userName,
        roleType
    };
};

export default connect(mapStateToProps)(MainPanelVendorCommunication);