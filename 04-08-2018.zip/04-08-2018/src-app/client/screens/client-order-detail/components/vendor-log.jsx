import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { apiGetVendorLog } from "Api/orders-api";
import { handleApiError } from "ErrorHandler";
import { switchModuleOnMainPanel } from "../actions/main-panel-actions";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class VendorLog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            vendorLog: {}
        };
    }

    componentWillMount() {
        apiGetVendorLog(this.props.orderId, (response) => {
            this.setState({ vendorLog: response.data });
        }, (error) => handleApiError(this.props.dispatch, error));
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    handleViewRequestFee(e) {
        e.preventDefault();

        // hide communication module and show fee requests module
        const { dispatch } = this.props;
        dispatch(switchModuleOnMainPanel("VEN"));
    }

    render() {
        const { vendorLog } = this.state;
        return (
            <div className="row">
                <div className="col s12 tab-content mt-1">
                    <p className="">Sent-Offer List <span className="new badge" data-badge-caption=""><strong>{vendorLog.sentOffer}</strong></span></p>
                    <p className="">Vendor History<span className="new badge" data-badge-caption=""><strong>{vendorLog.history}</strong></span></p>
                    <p className="">Vendor Request<span className="new badge" data-badge-caption=""><strong>{vendorLog.request}</strong></span></p>
                    <div className="clear"></div>
                    <div className="row mb-0">
                        <div className="col s12 right-align mt-1">
                            <button
                                className="btn btn-small success-color"
                                onClick={(e) => this.handleViewRequestFee(e)}
                            >View Details</button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}


VendorLog.propTypes = {
    params: PropTypes.object,
    router: PropTypes.object,
    dispatch: PropTypes.func,
    accountId: PropTypes.number,
    brokerId: PropTypes.number,
    orderId: PropTypes.number,
    isAutoAssigned: PropTypes.bool
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { accountId } = authentication;
    const { isAutoAssigned } = state.clientOrderDetail.vendorInfo;
    return {
        accountId,
        isAutoAssigned
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(VendorLog);