import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { getOrderDetailLeftPanelInitData, updateLeftPanel, sendFaxcover, sendConfirmation, sendAptScheduled, sendClosing, sendInvoice } from "./../actions/left-panel-actions";
import { hasStringValue, convert2PhoneWithFormat } from "Helpers/common-helper";
import SendMailModal from "../components/send-mail-modal";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "../../../features/modal";
import Select from "Select";
import { GridView } from "GridView";
import { ORDER_DETAIL_PROGRESS } from "../../../constant/order-detail-constants";
import { handleApiError } from "ErrorHandler";
import { apiGetAllAgents } from "Api/agent-api";
import { apiAddNewOrderProgress } from "Api/order-progress-api";
// import { apiUpdateLeftPanel } from "../../../api/orders-api";
import { getClientDataById, loadListBranchAndProductType, reloadListCustomer, reloadListAgent, getListClient } from "../../staff-add-an-order/actions/order-details";
import { showError } from "../../main-layout/actions";
import moment from "moment";
import { ACTION } from "../../../constant/progress-log-constants";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class LeftPanelClient extends Component {
    constructor(props) {
        super(props);

        this.state = {
            clientEditing: false,
            refEditing: {
                isSaving: false,
                isEditing: false,
                value: "",
                name: "refNumber"
            },
            openCancellationModal: false,
            newProgressId: 0,
            selectSend: [
                { value: "0", label: "Send Order Form" },
                { value: "1", label: "Order Form as PDF" },
                { value: "2", label: "Send Confirmation" },
                { value: "3", label: "Email Confirmation as PDF" },
                { value: "4", label: "Send Apt Schedule" },
                { value: "5", label: "Send Closing" },
                { value: "6", label: "Send Invoice" },
                { value: "7", label: "Email Invoice as PDF" }
            ],
            initData: {
                listClient: [],
                listBranch: [],
                listCustomer: []
            },
            agentInputs: {
                clientId: this.props.orderInfo.BrokerId || "",
                branchId: "",
                customerId: "",
                agentId: "",
                searchText: ""
            },
            agentColumns: [
                { title: "", type: "radioChange", id: "AgentId", data: "checked" },
                { title: "Agent Name", data: "FullName" },
                { title: "Direct", data: "Direct" },
                { title: "Ext", data: "Ext" },
                { title: "Fax", data: "Fax" },
                { title: "Email", data: "Email" }
            ],
            gridCriteria: this.getDefaultGridCriteria(),
            allAgents: [],
            selectSendMailOption: "0",
            totalRecord: 0
        };

        this.dataToSendMail = {};
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    getDefaultGridCriteria() {
        return {
            searchString: "",
            sortColumn: "FullName",
            sortDirection: true,
            page: 1,
            itemPerPage: 25
        };
    }

    getProgressDescription(progressId) {
        const { listProgresses } = this.props;

        const result = listProgresses.find((element) => {
            return element.ProgressId.toString() === progressId.toString();
        }).ProgressDescription;

        return result;
    }

    addNewOrderProgress(input, cb) {
        const newProgress = this.getProgressDescription(input.newProgress);
        const oldProgress = this.getProgressDescription(input.oldProgress);
        const reasonProgress = input.reasonProgress;

        const log = {
            OrderId: input.orderId,
            Activity: reasonProgress === undefined ? `Order status changed from ${newProgress} to ${oldProgress}` : `Order status changed from ${newProgress} to ${oldProgress}. \nReason: ${reasonProgress}`,
            UsersId: input.accountId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            ProgressType: ACTION
        };

        //add activity log
        apiAddNewOrderProgress(log,
            () => {
                if (typeof cb === "function") cb();
            },
            (error) => handleApiError(error)
        );
    }

    reloadListBranch(brokerId) {
        const { dispatch } = this.props;

        loadListBranchAndProductType(brokerId, listData => {
            const listBranch = listData.data.initData.listClientBranch;
            this.setState({
                initData: {
                    ...this.state.initData,
                    listBranch
                }
            });
        }, dispatch);
    }

    reloadListCustomerAndAgent(clientId, GID) {
        const { dispatch, agentInfo } = this.props;

        if (!clientId) return;

        reloadListCustomer(clientId || GID, (resultCustomer) => {
            const dataToGetListAgent = {
                clientId: clientId,
                branchId: GID || 0,
                searchString: this.state.agentInputs.searchText || "",
                sortColumn: "FullName",
                sortDirection: true,
                page: 1,
                itemPerPage: 25
            };

            reloadListAgent(dataToGetListAgent, resultAgent => {
                const newAgents = resultAgent.data.agents.map(item => {
                    item.checked = (item.AgentId === agentInfo.AgentId);
                    return item;
                });
                this.setState({
                    allAgents: newAgents,
                    totalRecord: resultAgent.data.totalRecords,
                    initData: {
                        ...this.state.initData,
                        listCustomer: resultCustomer.data.data
                    }
                });
            }, dispatch);
        }, dispatch);
    }

    async handleEditClient() {
        const { dispatch, orderInfo } = this.props;
        let listClient = [];
        let clientIdRaw = "";
        let branchIdRaw = "";
        await new Promise((resolve, reject) => getListClient(resultListClient => {
            listClient = resultListClient || [];
            resolve();
        }, dispatch, reject));

        if (orderInfo.brokerId) {
            await new Promise(async (resolve, reject) => getClientDataById({ brokerId: orderInfo.brokerId, listColumns: ["BrokerID", "GID"] }, selectedClient => {
                if (selectedClient) {
                    clientIdRaw = selectedClient.GID ? selectedClient.GID : selectedClient.BrokerID;
                    branchIdRaw = selectedClient.GID ? selectedClient.BrokerID : "";
                    this.reloadListBranch(clientIdRaw);
                    this.reloadListCustomerAndAgent(selectedClient.BrokerID, selectedClient.GID || 0);
                }
                resolve();
            }, dispatch, reject));
        }
        this.setState({
            clientEditing: true,
            gridCriteria: this.getDefaultGridCriteria(),
            agentInputs: {
                clientId: clientIdRaw,
                branchId: branchIdRaw,
                customerId: orderInfo.customerId
            },
            initData: {
                ...this.state.initData,
                listClient
            }
        });
    }

    handleCancelEditClient() {
        this.setState({
            clientEditing: false
        });
    }

    handleSaveEditClient() {
        const { dispatch, orderId, roleType } = this.props;
        const { agentInputs } = this.state;
        if (this.validFormChange()) {
            const rawData = {
                ...agentInputs,
                type: "UpdateClient",
                OrderId: orderId
            };
            this.setState({
                clientEditing: false
            });
            dispatch(updateLeftPanel(rawData, (result) => {
                if (!result.isSuccess) {
                    handleApiError(this.props.dispatch, result.error);
                } else {
                    dispatch(getOrderDetailLeftPanelInitData({ orderId, portal: roleType }));
                }
            }, (error) => {
                handleApiError(this.props.dispatch, error);
            }));
        } else {
            dispatch(showError("Any Client and Agent must be selected"));
        }
    }

    handelCheckboxChange(identifier, value, column) {
        const { allAgents, agentInputs } = this.state;
        if (identifier && column === "checked") {
            allAgents.map(item => {
                item.checked = (item.AgentId === value);
                return item;
            });
            this.setState({
                allAgents,
                agentInputs: {
                    ...agentInputs,
                    agentId: value
                }
            });
        }
    }

    handleGridViewReload(nextCriteria) {
        const { dispatch, agentInfo } = this.props;

        const newCriteria = {
            searchString: this.state.agentInputs.searchText || "",
            sortColumn: nextCriteria.sortColumn,
            sortDirection: nextCriteria.sortDirection,
            page: nextCriteria.page,
            itemPerPage: nextCriteria.itemPerPage
        };

        this.setState({
            gridCriteria: newCriteria
        }, () => {
            const searchCriteria = {
                ...newCriteria,
                clientId: this.state.agentInputs.clientId,
                branchId: this.state.agentInputs.branchId
            };

            reloadListAgent(searchCriteria, resultAgent => {
                const newAgents = resultAgent.data.agents.map(item => {
                    item.checked = (item.AgentId === agentInfo.AgentId);
                    return item;
                });
                this.setState({
                    allAgents: newAgents,
                    totalRecord: resultAgent.data.totalRecords
                });
            }, dispatch);

            // apiGetAllAgents({ ...nextCriteria, brokerId: this.state.agentInputs.clientId }, (result) => {
            //     this.setState({
            //         allAgents: result.data.data,
            //         totalRecord: result.data.totalRecords
            //     });
            // }, (error) => handleApiError(dispatch, error));
        });
    }

    handleKeyPress(e) {
        const { agentInputs } = this.state;
        if (e.key === "Enter") {
            const newCriteria = {
                ...this.state.gridCriteria,
                searchString: agentInputs.searchText
            };
            this.setState({
                gridCriteria: newCriteria
            }, () => {
                this.reloadListCustomerAndAgent(agentInputs.branchId, agentInputs.clientId);
            });
        }
    }

    handleOnChangeField(value, fieldName) {
        // const { dispatch } = this.props;
        const { agentInputs } = this.state;

        agentInputs[fieldName] = value;

        if (fieldName === "clientId") {
            const rawValue = value === "" ? -1 : value;
            this.reloadListBranch(rawValue);
            this.reloadListCustomerAndAgent(rawValue, 0);
        } else if (fieldName === "branchId") {
            const rawValue = value === "" ? -1 : value;
            this.reloadListCustomerAndAgent(rawValue, agentInputs.clientId);
        } else if (fieldName === "searchText") {
            this.reloadListCustomerAndAgent(agentInputs.clientId, agentInputs.branchId);
        }

        this.setState({ agentInputs });
    }

    validFormChange() {
        const { agentInputs } = this.state;
        return (agentInputs.clientId !== "" && agentInputs.agentId !== "");
    }

    onClickSendMail() {
        const { dispatch, orderInfo } = this.props;
        const { selectSendMailOption } = this.state;

        switch (selectSendMailOption) {
            case "0":
                return dispatch(sendFaxcover(orderInfo.orderId, selectSendMailOption));
            case "1":
                return dispatch(sendFaxcover(orderInfo.orderId, selectSendMailOption));
            case "2":
                return dispatch(sendConfirmation(orderInfo.orderId, selectSendMailOption));
            case "3":
                return dispatch(sendConfirmation(orderInfo.orderId, selectSendMailOption));
            case "4":
                return dispatch(sendAptScheduled(orderInfo.orderId, selectSendMailOption));
            case "5":
                return dispatch(sendClosing(orderInfo.orderId, selectSendMailOption));
            case "6":
                return dispatch(sendInvoice(orderInfo.orderId, selectSendMailOption));
            case "7":
                return dispatch(sendInvoice(orderInfo.orderId, selectSendMailOption));
            default:
                return 0;
        }
    }

    render() {
        const { orderInfo, agentInfo } = this.props;
        const { agentColumns, allAgents, totalRecord, gridCriteria, selectSendMailOption, initData } = this.state;

        const { clientEditing, agentInputs } = this.state;

        const renderEditClientButton = () => {
            if (orderInfo.progressId !== undefined) {
                if (ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closing Completed" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending QC Review" || ORDER_DETAIL_PROGRESS[orderInfo.progressId].name === "Closed Pending Review/PC Resolution") {
                    return "";
                }
            }
            return (
                <span className="cursor-pointer right order-edit" onClick={() => this.handleEditClient()} >
                    <i className="lnr lnr-pencil"></i>
                </span>
            );
        };

        return (
            <div>
                <div className="panel-order-detail row box-shadow-st2 mt-1 pb-2">
                    <div className="col s12 mt-2 pos-rel">
                        <label>
                            <span className="small-heading">Client</span>
                            <div className="right-abs-btn">
                                {renderEditClientButton(clientEditing)}
                            </div>
                        </label>
                    </div>

                    <div className="col s6 mt-1">Client/Branch</div><div className="col s6 mt-1">Customer</div>
                    <div className="col s6">
                        <span className="bold-title truncate" title={`${hasStringValue(orderInfo.gidCompanyName) ? `${orderInfo.gidCompanyName}/ ` : ""}${orderInfo.brokerCompanyName}`}>{`${hasStringValue(orderInfo.gidCompanyName) ? `${orderInfo.gidCompanyName}/ ` : ""}${orderInfo.brokerCompanyName}`}</span>
                    </div>
                    <div className="col s6">
                        <span className="bold-title truncate" title={orderInfo.customerName || ""}>{orderInfo.customerName || ""}</span>
                    </div>

                    <div className="col s12 mt-2">
                        <label>
                            <span className="small-heading">Agent</span>
                        </label>
                    </div>
                    <div className="col s12 mt-1">
                        <span className="bold-title truncate" title={agentInfo.FullName || ""}>{agentInfo.FullName || ""}</span>
                        <p className="font-weight-500 truncate">
                            <i title="Phone" className="lnr lnr-phone-handset"></i> {convert2PhoneWithFormat(agentInfo.Phone) || "---"}
                            <span className="ml-2">Ext {agentInfo.Ext || "---"}</span>
                        </p>
                        <p className="font-weight-500 truncate">
                            <i title="Fax" className="lnr lnr-printer"></i> {convert2PhoneWithFormat(agentInfo.Fax) || "---"}
                        </p>
                        <p className="font-weight-500 truncate" title={agentInfo.Email || ""}>
                            {hasStringValue(agentInfo.Email) ?
                                <a href={`mailTo:${agentInfo.Email}`} target="_top" className="color-2"><i title="Email" className="lnr lnr-envelope"></i> {agentInfo.Email}</a> :
                                <a className="color-2"><i className="lnr lnr-envelope"></i> ---</a>
                            }
                        </p>
                    </div>
                    <div className="col s9">
                        <Select
                            dataSource={this.state.selectSend}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="selectSend"
                            value={selectSendMailOption}
                            onChange={(value) => this.setState({ selectSendMailOption: value })}
                        />
                    </div>
                    <div className="col s3">
                        <button
                            type="button"
                            className="btn btn-small success-color input-field"
                            onClick={() => this.onClickSendMail()}
                        >SEND</button>
                    </div>

                </div>

                <Modal isOpen={clientEditing} style={{ width: "80%" }} addClass="no-tab" >
                    <ModalBody>
                        <ModalTitle onClickClose={() => this.handleCancelEditClient()}>Update Client</ModalTitle>
                        <div className="tab-content">
                            <div className="row">
                                <div className="col s4 input-field">
                                    <Select
                                        dataSource={initData.listClient}
                                        onChange={(value) => {
                                            this.handleOnChangeField(value, "clientId");
                                        }}
                                        mapDataToRenderOptions={{ value: "brokerID", label: ["company", "city", "state"] }}
                                        optionDefaultLabel="Select Client"
                                        value={agentInputs.clientId || ""}
                                        // defaultValue={orderInfo.BrokerId}
                                        id="order-detail-select-clientId"
                                    />
                                    <label htmlFor="order-detail-select-clientId">Select Client</label>
                                </div>
                                <div className="col s4 input-field">
                                    <Select
                                        dataSource={initData.listBranch}
                                        onChange={(value) => {
                                            this.handleOnChangeField(value, "branchId");
                                        }}
                                        mapDataToRenderOptions={{ value: "BrokerID", label: ["Company", "City", "State"] }}
                                        ref="selectBranch"
                                        optionDefaultLabel="Select Branch"
                                        value={agentInputs.branchId || ""}
                                    />
                                    <label htmlFor="order-detail-select-clientId">Select Branch</label>
                                </div>
                                <div className="col s4 input-field">
                                    <Select
                                        dataSource={initData.listCustomer}
                                        onChange={(value) => {
                                            this.handleOnChangeField(value, "customerId");
                                        }}
                                        mapDataToRenderOptions={{ value: "CustomerId", label: "Name" }}
                                        ref="selectCustomer"
                                        optionDefaultLabel="Select Customer"
                                        value={agentInputs.customerId || ""}
                                    />
                                    <label htmlFor="order-detail-select-clientId">Select Customer</label>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col s4 input-field">Select Agent</div>
                                <div className="col s8 m8 input-field"><input ref="searchAgent" name="searchAgent" id="searchAgent" type="text" value={agentInputs.searchText} onChange={(e) => this.handleOnChangeField(e.target.value, "searchText")} onKeyPress={(e) => this.handleKeyPress(e)} /><label htmlFor="searchAgent">Enter Name/Email to search</label></div>
                            </div>

                            <div className="row">
                                <div className="col s12 wrap-result-search">
                                    <GridView
                                        criteria={gridCriteria}
                                        totalRecords={totalRecord}
                                        datasources={allAgents}
                                        columns={agentColumns}
                                        identifier={"AgentId"}
                                        onCheckboxClick={(value, identifier, column) => this.handelCheckboxChange(identifier, value, column)}
                                        onGridViewReload={(e) => this.handleGridViewReload(e)}
                                    // onGridViewReload={this.handleGridViewReload.bind(this)}
                                    // onActionClick={this.handleGridViewActionClick.bind(this)}
                                    />
                                </div>
                            </div>
                            <div className="row"></div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col m6">
                                <button type="button" className="btn w-100 white" onClick={() => this.handleCancelEditClient()}>Cancel</button>
                            </div>
                            <div className="col m6">
                                <button type="button" className="btn success-color w-100" onClick={() => this.handleSaveEditClient()} >Save</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
                <SendMailModal />
            </div>
        );
    }
}

LeftPanelClient.propTypes = {
    agents: PropTypes.array,
    owner: PropTypes.object,
    isFetching: PropTypes.bool,
    progressId: PropTypes.number,
    listProgresses: PropTypes.array,
    customer: PropTypes.object,
    coCustomer: PropTypes.object,
    orderInfo: PropTypes.object,
    agentInfo: PropTypes.object,
    dispatch: PropTypes.func,
    orderId: PropTypes.number,
    agentId: PropTypes.number,
    profile: PropTypes.object,
    roleType: PropTypes.string,
    // setDataToSendMail: PropTypes.func,
    accountId: PropTypes.number
};

const mapStateToProps = (state) => {
    const { clientOrderDetail, authentication } = state;
    const { leftPanel } = clientOrderDetail;
    const {
        coCustomer,
        customer,
        isFetching,
        orderInfo,
        agentInfo
    } = leftPanel;
    const { accountId, profile, role } = authentication;
    const { roleType } = role;

    return {
        coCustomer,
        customer,
        isFetching,
        orderInfo,
        agentInfo,
        profile,
        roleType,
        accountId
    };
};

export default connect(mapStateToProps)(LeftPanelClient);