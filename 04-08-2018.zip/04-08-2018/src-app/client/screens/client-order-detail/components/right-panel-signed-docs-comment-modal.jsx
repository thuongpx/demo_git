import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";
import Select from "Select";
import { INPUT_MISSING_1X_IMAGE_URL } from "./../../../config/img.config";
import { requireComboBoxMessage } from "../../../helpers/validation-helper";
import { hasStringValue } from "Helpers/common-helper";
import { updateTextFields } from "Helpers/theme-helper";
import CommonModal from "../../../features/common-modal/common-modal";
import { SIGNED_DOC_STATUS } from "../../../constant/constants";
import moment from "moment";
import { getListSignedDocsComments, addOrderDocsAdditionalComment, updateSignedDocsStatus, addProgressLog } from "../actions/right-panel-actions";
import { showSuccess } from "../../main-layout/actions";
import { ACTION } from "../../../constant/progress-log-constants";
import { shallowCompareState, shallowCompareProps } from "../../../helpers/common-helper";

class SignedDocsCommentModal extends Component {
    constructor(props) {
        super(props);

        this.state = {
            inputs: {
                rejectCode: "",
                additionalComment: ""
            },
            listSignedDocComment: [],
            invalidField: {}
        };

        this.needScrollToBottomOfListComment = false;
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentWillReceiveProps(nextProps) {
        const { isOpen, commentInfo, dispatch } = nextProps;
        const { docData } = commentInfo;

        if (!isOpen || isOpen === this.props.isOpen) return;

        dispatch(getListSignedDocsComments({ docId: docData.DocId }, result => {
            this.setState({
                inputs: {
                    rejectCode: docData.RejectReason || ""
                },
                listSignedDocComment: result.listComments
            });
        }));

    }

    validateForm() {
        const { inputs } = this.state;
        const invalidField = {};

        if (!hasStringValue(inputs.rejectCode)) invalidField.rejectCode = true;

        this.setState({ invalidField });

        const check = Object.keys(invalidField)[0];

        if (check) {
            $("#signed-doc-rejected-code").focus();
            return false;
        }

        return true;
    }

    componentDidUpdate() {
        updateTextFields();

        if (this.needScrollToBottomOfListComment) {
            this.needScrollToBottomOfListComment = false;
            $("#list-order-doc-comments").animate({ scrollTop: $("#list-order-doc-comments").prop("scrollHeight") }, 1000);
        }
    }

    handleOnchangeField(value, fieldName) {
        const { inputs, invalidField } = this.state;

        inputs[fieldName] = value;

        if (hasStringValue(value)) {
            invalidField[fieldName] = false;
        }

        this.setState({ inputs, invalidField });
    }

    handleRejectSignedDoc() {
        if (!this.validateForm()) return;

        this.commonModal.showModal({ type: "confirm", message: "Are you sure that you would like to reject this signed document?" },
            () => {
                const { commentInfo, accountId, dispatch, reloadData, profile } = this.props;
                const newDoc = {
                    DocId: commentInfo.docData.DocId,
                    ReviewedBy: accountId,
                    ReviewDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                    OrderId: commentInfo.docData.OrderId
                };

                newDoc.RejectReason = this.state.inputs.rejectCode;
                newDoc.Status = SIGNED_DOC_STATUS.REJECTED.code;

                this.updateSignedDoc(newDoc, () => {
                    const log = {
                        OrderId: commentInfo.docData.orderId,
                        activity: `${profile.userName} rejected document ${commentInfo.docData.Description}`,
                        usersId: accountId,
                        dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                        progressType: ACTION
                    };

                    dispatch(showSuccess("Rejected Successfully"));
                    reloadData(commentInfo.docData.DocId);
                    this.handleAddProgressLog(log);
                });
            },
            () => { },
            false, "Yes", "No"
        );
    }

    handleAddAdditionalComment() {
        const { inputs, listSignedDocComment } = this.state;
        const { commentInfo, accountId, profile, dispatch } = this.props;

        if (!inputs.additionalComment.trim()) return;

        const newComment = {
            DocId: commentInfo.docData.DocId,
            CommentBy: accountId,
            Comment: inputs.additionalComment || "",
            CommentDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        };

        dispatch(addOrderDocsAdditionalComment(newComment, () => {
            newComment.UserName = profile.userName;
            newComment.FullName = `${profile.firstName} ${profile.lastName}`;
            inputs.additionalComment = "";
            newComment.CommentDate = moment.utc(newComment.CommentDate).local().format("YYYY-MM-DD HH:mm:ss");
            listSignedDocComment.push(newComment);

            this.needScrollToBottomOfListComment = true;
            this.setState({ inputs, listSignedDocComment });
        }));

    }

    handleResetAdditionalComment() {
        const { inputs } = this.state;

        inputs.additionalComment = "";

        this.setState({ inputs });
    }

    resetState() {
        this.setState({
            inputs: {
                rejectCode: "",
                additionalComment: ""
            },
            listSignedDocComment: [],
            invalidField: {}
        });
    }

    handleCancel() {

        this.commonModal.showModal({ type: "confirm", message: "Are you sure you would like to cancel reviewing this document?" },
            () => {
                const { toggleModal } = this.props;

                toggleModal();
                this.resetState();
            },
            () => { },
            false, "Yes", "No"
        );
    }

    convertStatusCode(code = "") {
        let returnStatus = "";

        if (!code) return SIGNED_DOC_STATUS.OPEN.description;

        switch (code.toUpperCase()) {
            case "A":
                returnStatus = SIGNED_DOC_STATUS.APPROVED;
                break;
            case "O":
                returnStatus = SIGNED_DOC_STATUS.OPEN;
                break;
            case "R":
                returnStatus = SIGNED_DOC_STATUS.REJECTED;
                break;
            default:
                returnStatus = "";
                break;
        }

        return returnStatus.description || "";
    }

    handleAddProgressLog(log) {
        const { dispatch } = this.props;

        dispatch(addProgressLog(log));
    }

    updateSignedDoc(newDoc, cb = () => { }) {
        const { dispatch, profile } = this.props;
        newDoc.userName = profile.userName;

        dispatch(updateSignedDocsStatus(newDoc, cb));
    }

    handleApprovalSignedDoc() {
        this.commonModal.showModal({ type: "confirm", message: "Are you sure that you would like to approve this signed document?" },
            () => {
                const { dispatch, accountId, commentInfo, profile, reloadData } = this.props;
                const newDoc = {
                    DocId: commentInfo.docData.DocId,
                    Status: SIGNED_DOC_STATUS.APPROVED.code,
                    ReviewedBy: accountId,
                    ReviewDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
                };

                const log = {
                    OrderId: commentInfo.docData.orderId,
                    activity: `${profile.userName} approved document ${commentInfo.docData.Description}`,
                    usersId: accountId,
                    dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                    progressType: ACTION
                };

                this.updateSignedDoc(newDoc, () => {
                    dispatch(showSuccess("Approved Successfully"));
                    reloadData(commentInfo.docData.DocId);
                    this.handleAddProgressLog(log);
                });
            },
            () => { },
            false, "Yes", "No"
        );

    }

    render() {
        const { isOpen, commentInfo, listRejectCode, userName } = this.props;
        const { docData } = commentInfo;
        const status = this.convertStatusCode(docData.Status);

        const renderButton = () => {
            return (
                <div className="row m-0 mr-1">
                    <div className="col m3">
                        <button className="btn white w-100" onClick={() => this.handleCancel()}>Cancel</button>
                    </div>
                    <div className="col m3">
                        <button className="btn red w-100" id="signed-doc-btn-reject" onClick={() => this.handleRejectSignedDoc()} disabled={status !== SIGNED_DOC_STATUS.OPEN.description}>Reject</button>
                    </div>
                    <div className="col m3">
                        <button className="btn success-color w-100" id="signed-doc-btn-approve" onClick={() => this.handleApprovalSignedDoc()} disabled={status !== SIGNED_DOC_STATUS.OPEN.description}>Approve</button>
                    </div>
                    <div className="col m3">
                        <button className="btn blue w-100" id="signed-doc-btn-approve-with-condi" onClick={() => this.handleApprovalSignedDoc()} disabled={status !== SIGNED_DOC_STATUS.OPEN.description}>Approve with Condition</button>
                    </div>
                </div>
            );
        };

        return (
            <div id="signed-docs-comment-popup">
                <Modal isOpen={isOpen}>
                    <ModalBody className="pb-0">
                        <ModalTitle onClickClose={() => this.handleCancel()}><span className="tab active">Review Documents</span></ModalTitle>
                        <div className="tab-content pb-0">
                            <div className="row">
                                <div className="col s10 offset-s1">
                                    <div className="row">
                                        <div className="input-field col s6">
                                            <input type="text" id="signed-doc-review-name" readOnly value={docData.Description || ""} />
                                            <label htmlFor="signed-doc-review-name">Document Name</label>
                                        </div>
                                        <div className="input-field col s6">
                                            <input type="text" id="signed-doc-review-status" readOnly value={status} />
                                            <label htmlFor="signed-doc-review-status">Status</label>
                                        </div>

                                        <div className="clearfix"></div>

                                        <div className="input-field col s6">
                                            <input type="text" id="signed-doc-review-uploaded-date" readOnly value={docData.UploadedDate ? moment(docData.UploadedDate).format("MM/DD/YYYY HH:mm:ss A") : ""} />
                                            <label htmlFor="signed-doc-review-uploaded-date">Uploaded Date</label>
                                        </div>
                                        <div className="input-field col s6">
                                            <input type="text" id="signed-doc-review-uploaded-by" readOnly value={docData.UploadedBy || ""} />
                                            <label htmlFor="signed-doc-review-uploaded-by">Uploaded By</label>
                                        </div>

                                        <div className="clearfix"></div>

                                        <div className="input-field col s6">
                                            <input type="text" id="signed-doc-review-review-date" readOnly value={docData.ReviewDate && moment(docData.ReviewDate).toString() !== "Invalid date" ? moment.utc(docData.ReviewDate).local().format("MM/DD/YYYY HH:mm:ss A") : ""} />
                                            <label htmlFor="signed-doc-review-review-date">Review Date</label>
                                        </div>
                                        <div className="input-field col s6">
                                            <input type="text" id="signed-doc-review-reviewed-by" readOnly value={docData.ReviewedBy || ""} />
                                            <label htmlFor="signed-doc-review-reviewed-by">Reviewed By</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col s10 offset-s1">
                                    <div className={`input-field suffixinput required ${this.state.invalidField.rejectCode ? "required-field" : ""}`}>
                                        <Select
                                            dataSource={listRejectCode}
                                            mapDataToRenderOptions={{ value: "ReasonID", label: "ReasonCode" }}
                                            value={this.state.inputs.rejectCode ? Number(this.state.inputs.rejectCode) : ""}
                                            optionDefaultLabel="Select..."
                                            onChange={(value) => this.handleOnchangeField(value, "rejectCode")}
                                            id="signed-doc-rejected-code"
                                            disabled={status !== SIGNED_DOC_STATUS.OPEN.description}
                                        />
                                        <label htmlFor="signed-doc-rejected-code">Reason Code</label>
                                        <span className={`suffix-text ${this.state.invalidField.rejectCode ? "" : "hide"}`} style={{ right: "22px" }}>
                                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireComboBoxMessage("Reason Code")} />
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div className="row">
                                <div className="input-field col s10 offset-s1" style={{ border: "1pt solid #d6d6d6" }}>
                                    <p className="m-1"><span className="blue-color" style={{ fontWeight: 300, fontSize: "large" }}>Additional Comment</span></p>

                                    <div className="divider"></div>

                                    <div className="row p-1">
                                        <div className="col s12 tab-content p-0" id="list-order-doc-comments">
                                            <div className="termdata">
                                                <ol className="notelist" style={{ maxHeight: "300px" }}>
                                                    {
                                                        this.state.listSignedDocComment.map((data, index) => {
                                                            return (
                                                                <li className="other-note" key={index}>
                                                                    <div className={`chat-content${data.UserName !== userName ? "-left" : ""}`}>
                                                                        <p style={{ wordBreak: "break-word;" }}>{data.Comment}</p>
                                                                        <div className={`avt-note${data.UserName !== userName ? "-left" : ""}`}>
                                                                            <img alt="" title={data.FullName} className="responsive-img circle" src={data.ProfilePicture || "/images/no-avatar.png"} />
                                                                        </div>
                                                                        <small>{moment(data.CommentDate).format("MMM DD YYYY [at] h:mm A")}</small>
                                                                    </div>
                                                                </li>
                                                            );
                                                        }
                                                        )
                                                    }
                                                </ol>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="divider"></div>

                                    <div className="row">
                                        <div className="input-field col s12">
                                            <input
                                                type="text"
                                                id="signed-doc-comment"
                                                maxLength="250"
                                                className="validate"
                                                value={this.state.inputs.additionalComment}
                                                onChange={(e) => this.handleOnchangeField(e.target.value, "additionalComment")}
                                            />
                                            <label htmlFor="signed-doc-comment">Enter additional comment here</label>
                                        </div>
                                        <div className="clearfix"></div>
                                        <div className="col s3 offset-s9">
                                            <div className="row">
                                                <div className="input-field col s6 m-0">
                                                    <button className="btn btn-small white w-100" onClick={() => this.handleResetAdditionalComment()}>Reset</button>
                                                </div>
                                                <div className="input-field col s6 m-0">
                                                    <button className="btn-small blue w-100" onClick={() => this.handleAddAdditionalComment()}>Add</button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>{renderButton()}</ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

SignedDocsCommentModal.defaultProps = {
    rejectCode: "",
    additionalComment: ""
};

SignedDocsCommentModal.propTypes = {
    isOpen: PropTypes.bool,
    commentInfo: PropTypes.object,
    toggleModal: PropTypes.func,
    listRejectCode: PropTypes.array,
    updateSignedDoc: PropTypes.func,
    accountId: PropTypes.number,
    profile: PropTypes.object,
    dispatch: PropTypes.func,
    reloadData: PropTypes.func,
    userName: PropTypes.string
};

export default SignedDocsCommentModal;