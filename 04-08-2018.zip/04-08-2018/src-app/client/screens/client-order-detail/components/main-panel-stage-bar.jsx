import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";

import { connect } from "react-redux";
import { showError } from "./../../main-layout/actions";
import { handleApiError } from "ErrorHandler";

import { ORDER_DETAIL_STAGE, ORDER_DETAIL_PROGRESS, ORDER_PROGRESS_ID } from "./../../../constant/order-detail-constants";

import { apiAutoAssign } from "Api/orders-api";
import { setIsAutoAssigned } from "./../actions";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class MainPanelStageBar extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isHelperShow: true
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentWillReceiveProps(nextProps) {
        const { progressId } = nextProps;

        if (progressId !== ORDER_PROGRESS_ID.OPEN && progressId !== ORDER_PROGRESS_ID.ASSIGNED_TO_VENDOR) {
            this.setState({
                isHelperShow: false
            });
        } else {
            this.setState({
                isHelperShow: true
            });
        }
    }

    handleHideShowHelper() {
        this.setState({
            isHelperShow: !this.state.isHelperShow
        });
    }

    handleAutoAssign() {
        apiAutoAssign(this.props.orderId, this.props.userId, (response) => {
            if (response.data.isValidToAutoAssign) {
                this.props.dispatch(setIsAutoAssigned(true));
            } else {
                this.props.dispatch(showError("Unfortunately, your order is not eligible to assign vendor automatically. Please click ‘Assign a Vendor’ button to find the most suitable vendor for your order"));
            }
        }, (error) => handleApiError(this.props.dispatch, error));
    }

    handleAssignAVendor() {
        this.props.onAssignAVendor(true);
    }

    renderStageBar() {
        const { progressId } = this.props;

        if (!progressId) {
            return null;
        }

        const stageId = ORDER_DETAIL_PROGRESS[progressId].stageId;

        return (
            <ol className="arrows">
                {
                    ORDER_DETAIL_STAGE.map((item, index) => {
                        if (index < stageId) {
                            return (
                                <li key={index}>
                                    <span>
                                        {item.name}
                                        <p><strong>{ORDER_DETAIL_PROGRESS[item.lastProgressId].name}</strong></p>
                                    </span>
                                </li>
                            );
                        }
                        if (index === stageId) {
                            return (
                                <li className="current" key={index}>
                                    <span>
                                        {item.name}
                                        <p><strong>{ORDER_DETAIL_PROGRESS[progressId].name}</strong></p>
                                    </span>
                                </li>
                            );
                        }
                        return (
                            <li key={index}>
                                <span>
                                    {item.name}
                                    <p><strong></strong></p>
                                </span>
                            </li>
                        );
                    })
                }
                <li></li>
            </ol>
        );
    }

    renderHelperContent() {
        const { progressId } = this.props;

        switch (progressId) {
            // // open
            case ORDER_PROGRESS_ID.OPEN: {
                return (<p>Do you want to <a role="button" onClick={() => this.handleAutoAssign()}>Auto Assign a Vendor</a> or <a role="button" onClick={() => this.handleAssignAVendor()}>Assign a Vendor Manually.</a>?</p>);
            }
            // // auto assign
            // case 2: {
            //     return (<p>Do you want to <a>Auto Assign a Vendor</a> or <a>Assign a Vendor Manually.</a>?</p>);
            // }
            // // assigned
            case ORDER_PROGRESS_ID.ASSIGNED_TO_VENDOR: {
                return (<p>The appointment needs to be confirmed with customer by the assigned Vendor</p>);
            }
            default: {
                return (<p></p>);
            }
        }
    }

    renderHelper() {
        return this.state.isHelperShow
            ? (
                <div className="helper-order panel-order-detail row box-shadow-st2">
                    <strong>NEXT STEPS</strong>
                    <a role="button" className="hide-helper right"
                        onClick={() => this.handleHideShowHelper()}
                    >
                        HIDE HELPERS
                    </a>
                    {this.renderHelperContent()}
                </div>
            ) : (
                <div>
                </div>
            );
    }

    render() {
        return (
            <div>
                {this.renderStageBar()}
                {this.renderHelper()}
            </div>
        );
    }
}

MainPanelStageBar.defaultProps = {
};

MainPanelStageBar.propTypes = {
    progressId: PropTypes.number,
    dispatch: PropTypes.func,
    orderId: PropTypes.number,
    onAssignAVendor: PropTypes.func,
    userId: PropTypes.number
};

const mapStateToProps = (state) => {
    const { clientOrderDetail, authentication } = state;
    const { accountId } = authentication;
    const { leftPanel } = clientOrderDetail;
    const { orderInfo } = leftPanel;
    const { progressId } = orderInfo;

    return {
        progressId,
        userId: accountId
    };
};

export default connect(mapStateToProps)(MainPanelStageBar);