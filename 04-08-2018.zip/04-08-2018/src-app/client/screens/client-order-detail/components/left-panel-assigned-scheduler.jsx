import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import Select from "Select";
import { connect } from "react-redux";
import { getOrderDetailLeftPanelInitData, updateLeftPanel } from "./../actions/left-panel-actions";
import { sendEmailCloseRequestForOrder } from "./../actions/left-panel-update-manually-actions";
import { apiSetOrderProgress, apiValidateOrderBeforeChangeStatus } from "Api/orders-api";
import CommonModal from "CommonModal";
import { ORDER_PROGRESS_ID } from "../../../constant/order-detail-constants";
import { handleApiError } from "ErrorHandler";
import { apiAddNewOrderProgress } from "Api/order-progress-api";
// import { apiUpdateLeftPanel } from "../../../api/orders-api";
import moment from "moment";
import { ACTION } from "../../../constant/progress-log-constants";
import { shallowCompareProps, shallowCompareState, getOrderStatusError } from "../../../helpers/common-helper";
import OrderCancellationModal from "./left-panel-cancellation-modal";
import { hasStringValue } from "../../../helpers/validation-helper";
import { emitNeedReloadStage } from "../../../socket/orders";
import { getCustomerFeedback } from "../actions/right-panel-actions";

class LeftPanelAssignedScheduler extends Component {
    constructor(props) {
        super(props);

        this.state = {
            openCancellationModal: false,
            newProgressId: 0
        };

    }

    componentDidMount() {
        const { dispatch, orderId } = this.props;

        // get list of tce
        dispatch(getOrderDetailLeftPanelInitData({ orderId, portal: "Staff" }));
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    getProgressDescription(progressId) {
        const { listProgresses } = this.props;

        const result = listProgresses.find((element) => {
            return element.ProgressId.toString() === progressId.toString();
        }).ProgressDescription;

        return result;
    }

    addNewOrderProgress(input, cb) {
        const newProgress = this.getProgressDescription(input.newProgress);
        const oldProgress = this.getProgressDescription(input.oldProgress);
        const reasonProgress = input.reasonProgress;

        const log = {
            OrderId: input.orderId,
            Activity: reasonProgress === undefined ? `Order status changed from ${newProgress} to ${oldProgress}` : `Order status changed from ${newProgress} to ${oldProgress}. \nReason: ${reasonProgress}`,
            UsersId: input.accountId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            ProgressType: ACTION
        };

        //add activity log
        apiAddNewOrderProgress(log,
            () => {
                if (typeof cb === "function") cb();
            },
            (error) => handleApiError(error)
        );
    }


    handleChangeStatus(progressId) {
        const { dispatch, orderId, accountId, orderInfo } = this.props;
        const oldProgressId = this.props.progressId;
        const iProgressId = parseInt(progressId);

        if (iProgressId === oldProgressId) return;

        /**AnNV2: Update UCS3.1
         * Role to change order status
         */

        apiValidateOrderBeforeChangeStatus({ orderId, newStatus: iProgressId }, (result) => {
            const { errorCode } = result.data;

            // can change order's status
            if (errorCode === 0) {
                if (iProgressId === ORDER_PROGRESS_ID.CANCELED) {
                    this.setState({
                        openCancellationModal: true,
                        newProgressId: progressId
                    });

                    return;
                }

                apiSetOrderProgress({
                    orderId,
                    progressId,
                    cancellationReason: null,
                    requiredPreCall: orderInfo.requiredPreCall
                }, () => {
                    // AnNV2: If order's status is changed to "Closing ...", need to show customer feedback section
                    if (iProgressId === ORDER_PROGRESS_ID.UNSUCCESSFUL || iProgressId === ORDER_PROGRESS_ID.CLOSED_PENDING_QC_REVIEW
                        || iProgressId === ORDER_PROGRESS_ID.CLOSED_PENDING_REVIEW_PC_RESOLUTION) {
                        dispatch(getCustomerFeedback(orderId));
                    }

                    if (iProgressId === ORDER_PROGRESS_ID.CLOSING_COMPLETED) {
                        // AnNV2: Update UCC12: Do not send mail any more
                        // dispatch(sendEmailCloseRequestForOrder({ progressId, orderId }));
                        emitNeedReloadStage(orderId);
                    }

                    this.addNewOrderProgress({
                        orderId,
                        accountId,
                        newProgress: oldProgressId,
                        oldProgress: progressId
                    }, dispatch(getOrderDetailLeftPanelInitData({ orderId, portal: "Staff" })));
                });

                return;
            }

            // user cannot change order's status
            const errorMessage = getOrderStatusError(errorCode);

            // show error message
            this.commonModal.showModal({
                type: "error",
                message: errorMessage
            });

            // rollback status
            this.refs.progress.value = oldProgressId;
            this.refs.progress.bindingOption(true);

        }, dispatch(getOrderDetailLeftPanelInitData({ orderId, portal: "Staff" })));

    }

    handleChangeScheduler(repId) {
        const { dispatch, orderId, orderInfo } = this.props;
        const oldSchedulerId = orderInfo.repId;

        if (parseInt(repId) === oldSchedulerId || !hasStringValue(repId)) return;

        const rawData = {
            type: "UpdateScheduler",
            OrderId: orderId,
            repId
        };
        dispatch(updateLeftPanel(rawData, (result) => {
            if (!result.isSuccess) {
                handleApiError(this.props.dispatch, result.error);
            } else {
                dispatch(getOrderDetailLeftPanelInitData({ orderId, portal: "Staff" }));
            }
        }, (error) => {
            handleApiError(this.props.dispatch, error);
        }));
    }


    closeModal() {
        this.refs.progress.value = this.props.progressId;
        this.refs.progress.bindingOption(true);

        this.setState({
            openCancellationModal: false
        });
    }

    submitCancel(reason) {
        const { dispatch, orderId, accountId, orderInfo } = this.props;
        const oldProgressId = this.props.progressId;

        apiSetOrderProgress({
            orderId,
            progressId: this.state.newProgressId,
            cancellationReason: reason,
            requiredPreCall: orderInfo.requiredPreCall
        }, () => {
            this.addNewOrderProgress({
                orderId,
                accountId,
                newProgress: oldProgressId,
                oldProgress: this.state.newProgressId,
                reasonProgress: reason
            }, dispatch(getOrderDetailLeftPanelInitData({ orderId, portal: "Staff" })));
        }, () => {
            // this.refs.progress.value = this.props.progressId;
            // this.refs.progress.bindingOption(true);
        });

        this.setState({
            openCancellationModal: false
        });
    }

    render() {
        const { progressId, listProgresses } = this.props;
        const { orderInfo } = this.props;

        return (
            <div>
                <div className="col s6">
                    <div className="input-field required suffixinput">
                        <Select
                            dataSource={orderInfo.listTCESchedulers}
                            optionDefaultLabel={"Select..."}
                            onChange={(value) => this.handleChangeScheduler(value)}
                            mapDataToRenderOptions={{ value: "RepId", label: "FullName" }}
                            id="schedulerAssign"
                            value={orderInfo.repId || ""}
                        />
                        <label htmlFor="agentAssign">RepID</label>
                    </div>
                </div>
                <div className="col s6">
                    <div className="input-field required suffixinput">
                        <Select
                            dataSource={listProgresses}
                            optionDefaultLabel={"Select..."}
                            value={progressId}
                            onChange={(value) => this.handleChangeStatus(value)}
                            mapDataToRenderOptions={{ value: "ProgressId", label: "ProgressDescription" }}
                            ref="progress"
                            id="progress"
                        />
                        <label htmlFor="progress">Status</label>
                    </div>
                </div>
                <div className="clear"></div>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
                <OrderCancellationModal
                    isOpen={this.state.openCancellationModal}
                    closeModal={() => this.closeModal()}
                    submitCancel={(reason) => this.submitCancel(reason)}
                />

            </div>
        );
    }
}

LeftPanelAssignedScheduler.propTypes = {
    owner: PropTypes.object,
    isFetching: PropTypes.bool,
    progressId: PropTypes.number,
    listProgresses: PropTypes.array,
    customer: PropTypes.object,
    coCustomer: PropTypes.object,
    orderInfo: PropTypes.object,
    dispatch: PropTypes.func,
    orderId: PropTypes.number,
    agentId: PropTypes.number,
    profile: PropTypes.object,
    // setDataToSendMail: PropTypes.func,
    accountId: PropTypes.number
};

const mapStateToProps = (state) => {
    const { clientOrderDetail, authentication } = state;
    const { leftPanel } = clientOrderDetail;
    const {
        agents,
        coCustomer,
        customer,
        isFetching,
        orderInfo,
        owner
    } = leftPanel;
    const { listProgresses, progressId, agentId } = orderInfo;
    const { accountId, profile } = authentication;

    return {
        agents,
        coCustomer,
        customer,
        isFetching,
        orderInfo,
        agentId,
        owner,
        listProgresses,
        progressId,
        profile,
        accountId
    };
};

export default connect(mapStateToProps)(LeftPanelAssignedScheduler);