import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import GridView from "GridView";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";

class OrderVendorRequestsGrid extends Component {

    //Handle actions such as edit,delete
    handleGridViewActionClick(action, identifier) {
        const { onReview } = this.props;
        switch (action) {
            case "review":
                onReview(identifier);
                return;
        }
    }

    handleGridViewReload(criteria) {
        const { onChange } = this.props;
        onChange("criteria", criteria);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {
        const { datasources, columns, criteria, totalRecords, filters } = this.props;

        return (
            <div>
                <GridView
                    criteria={criteria}
                    totalRecords={totalRecords}
                    filters={filters}
                    datasources={datasources} //Pass datasources
                    columns={columns} //Pass columns array
                    identifier={"ApprovalID"} //Identifier for grid row
                    defaultSortColumn={"RequestDate"} //Default sort column
                    actions={["review"]} //Remove if no action needed
                    onGridViewReload={this.handleGridViewReload.bind(this)} //Paginate changed => need reload datasource base on criteria
                    onActionClick={this.handleGridViewActionClick.bind(this)} //Handle actions
                />
            </div>
        );
    }
}

OrderVendorRequestsGrid.defaultProps = {
    columns: [
        {
            title: "Date",
            data: "RequestDate",
            type: "datetime"
        },
        {
            title: "Vendor Name",
            data: "VendorName",
            type: "vendorLink",
            id: "SignerId"
        },
        {
            title: "Requested By",
            data: "UserName"
        },
        {
            title: "Approved By",
            data: "ApprovedBy"
        }, {
            title: "Description",
            data: "Description"
        }, {
            title: "Status",
            data: "Status"
        }
    ]
};

OrderVendorRequestsGrid.propTypes = {
    onChange: PropTypes.func,
    datasources: PropTypes.array,
    columns: PropTypes.array,
    criteria: PropTypes.object,
    totalRecords: PropTypes.number,
    onReview: PropTypes.func,
    filters: PropTypes.array
};

export default OrderVendorRequestsGrid;