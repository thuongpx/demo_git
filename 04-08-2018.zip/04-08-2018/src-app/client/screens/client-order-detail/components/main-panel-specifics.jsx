import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { Component } from "react";
import Select from "Select";
import InputMask from "react-input-mask";
import { getOrderSpecificsData, updateOrderSpecificsData } from "../../order-details/actions/order-spec";
import { hasStringValue, compareArrays, deepClone } from "../../../helpers/common-helper";
import { validateZip, validationMessage, invalidMessage, requireMessage, getValidationCssClass, validateMultipleEmail } from "../../../helpers/validation-helper";
import { getStateCodeAndCityFromZip } from "../../../helpers/location-helper";
import CommonModal from "CommonModal";
import { showError } from "../../main-layout/actions";
import { updateTextFields } from "../../../helpers/theme-helper";

class MainPanelSpecifics extends Component {
    constructor(props) {
        super(props);
        this.state = {
            inputs: {
                emailInvCC: {},
                emailCC: {},
                alwaysCCEmail: {},
                returnAddr: {},
                lenderSpecifics: {},
                location: {},
                city: {},
                state: {},
                zip: {},
                rbOther: {},
                Collect1: {},
                Collect2: {},
                Collect3: {},
                Collect4: {},
                Collect5: {},
                Collect6: {},
                Collect7: {},
                Collect8: {},
                Collect9: {},
                Collect10: {},
                Instructions1: {},
                Instructions2: {},
                Instructions3: {},
                Instructions4: {},
                Instructions5: {},
                Instructions6: {},
                Instructions7: {},
                Instructions8: {},
                Instructions9: {},
                Instructions10: {}
            },
            Specifics: {
                isEditing: false
            },
            validation: {}
        };
    }

    componentWillReceiveProps(nextProps) {
        // update to information
        const { orderSpecificData } = nextProps;
        const rawInputs = {
            ...this.state.inputs,
            Collect1: {
                value: orderSpecificData.Collect1
            },
            Collect2: {
                value: orderSpecificData.Collect2
            },
            Collect3: {
                value: orderSpecificData.Collect3
            },
            Collect4: {
                value: orderSpecificData.Collect4
            },
            Collect5: {
                value: orderSpecificData.Collect5
            },
            Collect6: {
                value: orderSpecificData.Collect6
            },
            Collect7: {
                value: orderSpecificData.Collect7
            },
            Collect8: {
                value: orderSpecificData.Collect8
            },
            Collect9: {
                value: orderSpecificData.Collect9
            },
            Collect10: {
                value: orderSpecificData.Collect10
            },
            Instructions1: {
                value: orderSpecificData.Instructions1 || ""
            },
            Instructions2: {
                value: orderSpecificData.Instructions2 || ""
            },
            Instructions3: {
                value: orderSpecificData.Instructions3 || ""
            },
            Instructions4: {
                value: orderSpecificData.Instructions4 || ""
            },
            Instructions5: {
                value: orderSpecificData.Instructions5 || ""
            },
            Instructions6: {
                value: orderSpecificData.Instructions6 || ""
            },
            Instructions7: {
                value: orderSpecificData.Instructions7 || ""
            },
            Instructions8: {
                value: orderSpecificData.Instructions8 || ""
            },
            Instructions9: {
                value: orderSpecificData.Instructions9 || ""
            },
            Instructions10: {
                value: orderSpecificData.Instructions10 || ""
            },
            emailInvCC: {
                value: orderSpecificData.CCInvEmail || ""
            },
            emailCC: {
                value: orderSpecificData.EmailCC || ""
            },
            alwaysCCEmail: {
                value: orderSpecificData.AlwaysCC
            },
            returnAddr: {
                value: orderSpecificData.ReturnAddress || ""
            },
            lenderSpecifics: {
                value: orderSpecificData.LenderSpecific
            },
            location: {
                value: ""
            },
            city: {
                value: ""
            },
            state: {
                value: ""
            },
            zip: {
                value: ""
            },
            rbOther: {
                value: false
            }
        };

        this.setState({
            ...this.state,
            inputs: deepClone(rawInputs),
            defaultInputs: rawInputs
        });
    }

    componentDidMount() {
        const { orderId } = this.props;

        this.reload(orderId);
    }

    componentDidUpdate() {
        updateTextFields();
    }

    reload(orderId) {
        // load all default data from DATABASE
        const { dispatch } = this.props;

        dispatch(getOrderSpecificsData(orderId));
    }

    handleInputBlur(obj) {
        const inputs = {
            ...this.state.inputs,
            ...obj
        };

        this.validateInputs(inputs);
    }

    validateInputs(inputs) {
        const { alwaysCCEmail, zip, location, city, state, rbOther } = inputs;
        const newAddress = rbOther.value;

        // required fields
        alwaysCCEmail.message = hasStringValue(alwaysCCEmail.value) && validateMultipleEmail(alwaysCCEmail.value) && alwaysCCEmail.isDirty ? invalidMessage("Always CC Email") : "";

        if (newAddress) {
            if (hasStringValue(zip.value) && !validateZip(zip.value) && zip.isDirty) {
                zip.message = invalidMessage("Zip");
            }

            if (!hasStringValue(zip.value) && zip.isDirty) {
                zip.message = requireMessage("Zip");
            }

            if (!hasStringValue(location.value) && location.isDirty) {
                location.message = requireMessage("Location Name");
            }

            if (!hasStringValue(city.value) && city.isDirty) {
                city.message = requireMessage("City");
            }

            if (!hasStringValue(state.value) && state.isDirty) {
                state.message = requireMessage("State");
            }

        } else {
            zip.message = "";
            location.message = "";
            city.message = "";
            state.message = "";
        }

        this.setState({
            ...this.state,
            inputs
        });
    }

    setFocus(fieldId) {
        $(`#${fieldId}`).focus();
    }

    verifyAddress(zip) {
        const { dispatch } = this.props;
        const { inputs } = this.state;

        getStateCodeAndCityFromZip(zip, result => {
            // invalid
            if (result === "Invalid Zip Code") {
                dispatch(showError("Your inputted Zip is not a valid US Zip Code. Please try again.", () => {
                    inputs.zip.value = "";
                    this.setFocus("zip");
                    this.setState({ inputs });
                }));
                return;
            }

            // valid
            if ((hasStringValue(inputs.state.value) && inputs.state.value !== result.state) ||
                (hasStringValue(inputs.state.value) && inputs.city.value !== result.city)) {
                // show confirmation modal

                this.commonModal.showModal({
                    type: "warning",
                    message: `The City ${result.state !== inputs.state.value && result.city.toLowerCase() !== inputs.city.value.toLowerCase() ? "and" : "or"} State do not match the Zip entered. Do you mean the signing address as follows? [${result.city}, ${result.state}, ${zip}]. Click Yes to use that suggested address. Click No to re-enter the correct address.`
                }, () => {
                    inputs.state.value = result.state;
                    inputs.city.value = result.city;

                    this.setState({ inputs });
                }, () => {
                    inputs.zip.value = "";

                    this.setFocus("zip");
                    this.setState({ inputs });
                });
                return;
            }

            // finally
            inputs.state.value = result.state;
            inputs.city.value = result.city;

            this.setState({ inputs });

        });
    }

    handleOnBlur(input, fieldName) {
        const { inputs, validation } = this.state;

        Object.keys(input).forEach((item) => {
            const value = input[item].value;
            switch (fieldName) {
                case "city":
                case "state":
                    inputs.zip.value = "";
                    break;
                case "zip":
                    if (!hasStringValue(value)) {
                        validation[fieldName] = true;
                        validation[`${fieldName}Data`] = false;
                    } else {
                        validation[fieldName] = false;
                        if (validateZip(value)) {
                            validation[`${fieldName}Data`] = false;
                            this.verifyAddress(value);
                        } else {
                            validation[`${fieldName}Data`] = true;
                        }
                    }
                    break;
            }
        });
        const newInputs = {
            ...this.state.inputs,
            ...input
        };
        this.validateInputs(newInputs);
    }

    handleOnChange(value, fieldName) {
        const { inputs } = this.state;

        inputs[fieldName].value = value;

        this.setState({
            ...this.state,
            inputs: {
                ...this.state.inputs
            }
        });
    }

    handleEditClick() {
        const { Specifics } = this.state;
        this.setState({
            Specifics: {
                ...Specifics,
                isEditing: true
            }
        });
    }

    convertInputToPayLoad() {
        const { inputs } = this.state;
        const { orderSpecificData } = this.props;

        // build return address
        const newAddress = inputs.rbOther.value;
        let addNewAddress = false;

        let returnAddress = inputs.returnAddr.value;
        const location = inputs.location.value;
        const addr = inputs.location.value.trim();
        const city = inputs.city.value.trim();
        const state = inputs.state.value;
        const zip = inputs.zip.value.trim();

        // if return address is not selected form Return Addr list, check entered info to build new address
        if (newAddress && addr !== "" && city !== "" && state !== "" && zip !== "") {
            returnAddress = `${location}, ${city}, ${state} ${zip}`;

            const { returnAddressList } = this.props;
            addNewAddress = true;

            // if the address is existing, do not need to create
            for (let i = 0; i < returnAddressList.length; i++) {
                if (returnAddressList[i].ReturnAddr === returnAddress) {
                    addNewAddress = false;
                    break;
                }
            }
        }

        const instructionInfo = {
            Instructions1: inputs.Instructions1.value,
            Instructions2: inputs.Instructions2.value,
            Instructions3: inputs.Instructions3.value,
            Instructions4: inputs.Instructions4.value,
            Instructions5: inputs.Instructions5.value,
            Instructions6: inputs.Instructions6.value,
            Instructions7: inputs.Instructions7.value,
            Instructions8: inputs.Instructions8.value,
            Instructions9: inputs.Instructions9.value,
            Instructions10: inputs.Instructions10.value
        };

        const orderSpecInfo = {
            AlwaysCC: inputs.alwaysCCEmail.value,
            EmailCC: inputs.emailCC.value,
            CCInvEmail: inputs.emailInvCC.value,
            Collect1: inputs.Collect1.value,
            Collect2: inputs.Collect2.value,
            Collect3: inputs.Collect3.value,
            Collect4: inputs.Collect4.value,
            Collect5: inputs.Collect5.value,
            Collect6: inputs.Collect6.value,
            Collect7: inputs.Collect7.value,
            Collect8: inputs.Collect8.value,
            Collect9: inputs.Collect9.value,
            Collect10: inputs.Collect10.value,
            ReturnAddress: returnAddress,
            BrokerId: orderSpecificData.BrokerId,
            OrderId: orderSpecificData.OrderId
        };

        const brokerSpecificInfo = {
            LenderSpecific: inputs.lenderSpecifics.value
        };

        const address = {
            IsNewAddress: addNewAddress,
            Address: addr,
            City: city,
            State: state,
            Zip: zip,
            BrokerId: orderSpecificData.BrokerId,
            DefaultAddr: "N",
            BranchId: 1 // default branch
        };

        const payload = {
            instructionInfo,
            orderSpecInfo,
            brokerSpecificInfo,
            address
        };

        return payload;
    }

    hasChanges() {
        const { inputs, defaultInputs } = this.state;

        const newInput = [];

        Object.keys(inputs).map((item) => {
            const prop = inputs[item];

            newInput.push(prop.value);
        });

        const oldInput = [];

        Object.keys(defaultInputs).map((item) => {
            const prop = defaultInputs[item];

            oldInput.push(prop.value);
        });

        const result = !compareArrays(oldInput, newInput);
        return result;
    }

    validateForm() {
        // check validation
        const { inputs } = this.state;

        let isInvalid = false;

        // validate first
        Object.keys(inputs).forEach((item) => {
            const prop = inputs[item];

            if (prop.message !== undefined && prop.message !== null && prop.message !== "") {
                isInvalid = true;
                return;
            }
        });

        return !isInvalid;
    }

    handleSave() {
        // if user not change any thing on the form, do not need to save changes
        if (!this.hasChanges()) return;

        // validate first
        if (this.validateForm()) {
            const { dispatch } = this.props;

            const payload = this.convertInputToPayLoad();
            if (payload !== null) {
                dispatch(updateOrderSpecificsData(payload, true, () => {
                    this.setState({
                        ...this.state,
                        defaultInputs: this.state.inputs,
                        Specifics: {
                            isEditing: false
                        }
                    });
                }));
            }
        }
    }

    handleCancel() {
        this.commonModal.showModal({
            type: "confirm",
            message: "Any unsaved changes will be lost. Are you sure you would like to cancel updating this screen?"
        }, () => {
            //handle callback yes click here
            this.setState({
                ...this.state,
                inputs: this.state.defaultInputs,
                Specifics: {
                    isEditing: false
                }
            });
        }, () => {
        });
    }

    render() {
        const { Specifics, inputs, validation } = this.state;
        const { ccEmailsList, ccInvEmailsList, returnAddressList, stateList } = this.props;
        const { location, zip, state, city, alwaysCCEmail } = inputs;
        const checkSpecHidden = (index) => {
            if (inputs[`Instructions${index - 1}`].value) return true;
            for (let i = index - 1; i < 10; i++) {
                if (inputs[`Instructions${i + 1}`].value) return true;
            }

            return false;
        };

        const checkItemHidden = (index) => {
            if (inputs[`Collect${index - 1}`].value) return true;
            for (let i = index - 1; i < 10; i++) {
                if (inputs[`Collect${i + 1}`].value) return true;
            }

            return false;
        };

        const renderButtons = () => {
            return (
                <div className="row">
                    <div className="col s6 m6">
                        <button type="button" className="btn btn-small w-100 white" onClick={() => this.handleCancel()}>Cancel</button>
                    </div>
                    <div className="col s6 m6">
                        <button type="button" className="btn btn-small success-color w-100" onClick={() => { if (this.validateForm()) this.handleSave(); }}>Save</button>
                    </div>
                </div>
            );
        };

        return (
            <div>
                <div className="row mb-0">
                    <div className="col s12 m7">
                        <p className="left"><strong>Please return executed documents to the following address</strong></p>
                    </div>
                    {!Specifics.isEditing ? <div className="col s12 m5">
                        <button className="btn btn-s-small success-color mt-1 mb-1 right" onClick={() => this.handleEditClick()}><span className="lnr lnr-pencil"></span></button>
                    </div> : ""}
                </div>
                <div className="row mb-0">
                    <div className="col s12 m6" style={{ marginTop: "25px" }}>
                        <label htmlFor="existingAddress">
                            <input
                                type="radio"
                                id="existingAddress"
                                name="address"
                                className="with-gap"
                                onChange={(e) => this.handleInputBlur({ rbOther: { value: !e.target.checked, isDirty: true, message: "" } })}
                                value={!this.state.inputs.rbOther.value}
                                disabled={!Specifics.isEditing ? "disabled" : ""}
                            />
                            <span>Existing address</span>
                        </label>
                    </div>
                    <div className="col s12 m6">
                        <Select
                            dataSource={ccEmailsList}
                            mapDataToRenderOptions={{ value: "Email", label: "Email" }}
                            id="emailCC"
                            ref="emailCC"
                            value={this.state.inputs.emailCC.value}
                            onChange={(value) => this.handleInputBlur({ emailCC: { value, isDirty: true, message: "" } })}
                            optionDefaultLabel="Send an additional copy of invoice to:"
                            disabled={!Specifics.isEditing ? true : false}
                        />
                    </div>
                </div>
                <div className="row mb-0">
                    <div className="col s12 m6 pl-2 pr-2">
                        <Select
                            dataSource={returnAddressList}
                            mapDataToRenderOptions={{ value: "ReturnAddr", label: "ReturnAddr" }}
                            id="address"
                            ref="address"
                            value={this.state.inputs.returnAddr.value}
                            onChange={(value) => this.handleInputBlur({ returnAddr: { value, isDirty: true, message: "" } })}
                            optionDefaultLabel="Select Return Address"
                            disabled={this.state.inputs.rbOther.value || !Specifics.isEditing ? true : false}
                        />
                    </div>
                    <div className="col s12 m6">
                        <p className="left"><strong>Send copies of all emails to:</strong></p>
                    </div>
                </div>
                <div className="row mb-0">
                    <div className="col s12 m6" style={{ marginTop: "25px" }}>
                        <label htmlFor="other">
                            <input
                                type="radio"
                                id="other"
                                name="address"
                                className="with-gap"
                                value={this.state.inputs.rbOther.value}
                                onChange={(e) => this.handleInputBlur({ rbOther: { value: e.target.checked, isDirty: true, message: "" } })}
                                disabled={!Specifics.isEditing ? "disable" : ""}
                            />
                            <span>Other</span>
                        </label>
                    </div>
                    <div className="col s12 m6">
                        <Select
                            dataSource={ccInvEmailsList}
                            mapDataToRenderOptions={{ value: "Email", label: "Email" }}
                            id="emailInvCC"
                            ref="emailInvCC"
                            value={this.state.inputs.emailInvCC.value}
                            onChange={(value) => this.handleInputBlur({ emailInvCC: { value, isDirty: true, message: "" } })}
                            optionDefaultLabel="Select Email"
                            disabled={!Specifics.isEditing ? true : false}
                        />
                    </div>
                </div>
                <div className="row mb-0">
                    <div className="input-field col s12 m6 pl-2 pr-2">
                        <input
                            type="text"
                            id="location"
                            ref="location"
                            maxLength="250"
                            value={location.value || ""}
                            disabled={!this.state.inputs.rbOther.value || !Specifics.isEditing ? "disabled" : ""}
                            onChange={() => this.handleInputBlur({ location: { value: this.refs.location.value, isDirty: true, message: "" } })}
                        />
                        <label style={{ marginLeft: "20px" }} htmlFor="location">Address</label>
                    </div>
                    <div className={`input-field col s12 m6 suffixinput ${getValidationCssClass(alwaysCCEmail.message)}`}>
                        <input id="alwaysEmail" type="text" ref="alwaysCCEmail" maxLength={100} disabled={!Specifics.isEditing ? "disable" : ""}
                            onChange={(e) => this.handleInputBlur({ alwaysCCEmail: { value: e.target.value, isDirty: true, message: "" } })}
                            value={alwaysCCEmail.value || ""}
                        />
                        <label htmlFor="alwaysEmail">Always CC</label>
                        {hasStringValue(alwaysCCEmail.message) && validationMessage(alwaysCCEmail.message, "alwaysEmail", 0)}
                    </div>
                </div>
                <div className="row">
                    <div className="col s12 m6 pl-specific pr-specific">
                        <div className={`input-field col s12 m4 suffixinput ${validation.zipData && !city.value ? "has-error" : ""}`}>
                            <InputMask
                                type="text"
                                id="zip"
                                mask="99999"
                                ref="zip"
                                value={zip.value || ""}
                                onChange={e => {
                                    this.handleOnBlur({
                                        zip: {
                                            value: e.target.value,
                                            message: ""
                                        }
                                    });
                                }}
                                onBlur={e => {
                                    this.handleOnBlur({
                                        zip: {
                                            value: e.target.value,
                                            message: ""
                                        }
                                    }, "zip");
                                }}
                                disabled={!this.state.inputs.rbOther.value || !Specifics.isEditing ? "disabled" : ""}
                            />
                            <label htmlFor="zip">Zip</label>
                            {validation.zipData && !city.value && validationMessage(invalidMessage("Zip"))}
                        </div>
                        <div className="input-field col s12 m4">
                            <input
                                id="city"
                                ref="city"
                                maxLength="50"
                                type="text"
                                className="validate"
                                value={city.value || ""}
                                onChange={e => {
                                    e.preventDefault();
                                    this.handleOnBlur({
                                        city: {
                                            value: this.refs.city.value,
                                            message: ""
                                        }
                                    }, "city");
                                }}
                                disabled={!this.state.inputs.rbOther.value || !Specifics.isEditing ? "disabled" : ""}
                            />
                            <label htmlFor="city">City</label>
                        </div>
                        <div className="input-field col s12 m4">
                            <Select
                                dataSource={stateList}
                                optionDefaultLabel="State"
                                mapDataToRenderOptions={{ value: "Code", label: "Description" }}
                                id="state"
                                ref="state"
                                value={state.value || ""}
                                onChange={e => {
                                    this.handleOnBlur({
                                        state: {
                                            value: e,
                                            message: ""
                                        }
                                    }, "state");
                                }}
                                disabled={!this.state.inputs.rbOther.value || !Specifics.isEditing ? true : false}
                            />
                            <label htmlFor="state">State</label>
                        </div>
                    </div>
                </div>
                <div className="row mb-0">
                    <div className="col s12 m6">
                        <p><strong>Vendor to pick up the following</strong></p>
                    </div>
                    <div className="col s12 m6">
                        <p><strong>Special instruction</strong></p>
                    </div>
                </div>
                <div className="row mb-0">
                    <div className="col s12 m6 p-0">
                        <div className="input-field col s12 suffixinput m-0">
                            <input type="text" className="validate" id="Item1" maxLength={100} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Collect1.value || ""} onChange={e => this.handleOnChange(e.target.value, "Collect1")} />
                            <label htmlFor="Item1">Item #1</label>
                        </div>
                        <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Item2" maxLength={100} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Collect2.value || ""} onChange={e => this.handleOnChange(e.target.value, "Collect2")} />
                            <label htmlFor="Item2">Item #2</label>
                        </div>
                        <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Item3" maxLength={100} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Collect3.value || ""} onChange={e => this.handleOnChange(e.target.value, "Collect3")} />
                            <label htmlFor="Item3">Item #3</label>
                        </div>
                        {checkItemHidden(4) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Item4" maxLength={100} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Collect4.value || ""} onChange={e => this.handleOnChange(e.target.value, "Collect4")} />
                            <label htmlFor="Item4">Item #4</label>
                        </div>}
                        {checkItemHidden(5) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Item5" maxLength={100} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Collect5.value || ""} onChange={e => this.handleOnChange(e.target.value, "Collect5")} />
                            <label htmlFor="Item5">Item #5</label>
                        </div>}
                        {checkItemHidden(6) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Item6" maxLength={100} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Collect6.value || ""} onChange={e => this.handleOnChange(e.target.value, "Collect6")} />
                            <label htmlFor="Item6">Item #6</label>
                        </div>}
                        {checkItemHidden(7) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Item7" maxLength={100} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Collect7.value || ""} onChange={e => this.handleOnChange(e.target.value, "Collect7")} />
                            <label htmlFor="Item7">Item #7</label>
                        </div>}
                        {checkItemHidden(8) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Item8" maxLength={100} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Collect8.value || ""} onChange={e => this.handleOnChange(e.target.value, "Collect8")} />
                            <label htmlFor="Item8">Item #8</label>
                        </div>}
                        {checkItemHidden(9) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Item9" maxLength={100} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Collect9.value || ""} onChange={e => this.handleOnChange(e.target.value, "Collect9")} />
                            <label htmlFor="Item9">Item #9</label>
                        </div>}
                        {checkItemHidden(10) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Item10" maxLength={100} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Collect10.value || ""} onChange={e => this.handleOnChange(e.target.value, "Collect10")} />
                            <label htmlFor="Item10">Item #10</label>
                        </div>}
                    </div>
                    <div className="col s12 m6 p-0">
                        <div className="input-field col s12 suffixinput m-0">
                            <input type="text" className="validate" id="Instruction1" maxLength={250} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Instructions1.value || ""} onChange={e => this.handleOnChange(e.target.value, "Instructions1")} />
                            <label htmlFor="Instruction1">Instruction #1</label>
                        </div>
                        <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Instruction2" maxLength={250} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Instructions2.value || ""} onChange={e => this.handleOnChange(e.target.value, "Instructions2")} />
                            <label htmlFor="Instruction2">Instruction #2</label>
                        </div>
                        <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Instruction3" maxLength={250} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Instructions3.value || ""} onChange={e => this.handleOnChange(e.target.value, "Instructions3")} />
                            <label htmlFor="Instruction3">Instruction #3</label>
                        </div>

                        {checkSpecHidden(4) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Instruction4" maxLength={250} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Instructions4.value || ""} onChange={e => this.handleOnChange(e.target.value, "Instructions4")} />
                            <label htmlFor="Instruction4">Instruction #4</label>
                        </div>}

                        {checkSpecHidden(5) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Instruction5" maxLength={250} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Instructions5.value || ""} onChange={e => this.handleOnChange(e.target.value, "Instructions5")} />
                            <label htmlFor="Instruction5">Instruction #5</label>
                        </div>}

                        {checkSpecHidden(6) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Instruction6" maxLength={250} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Instructions6.value || ""} onChange={e => this.handleOnChange(e.target.value, "Instructions6")} />
                            <label htmlFor="Instruction6">Instruction #6</label>
                        </div>}

                        {checkSpecHidden(7) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Instruction7" maxLength={250} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Instructions7.value || ""} onChange={e => this.handleOnChange(e.target.value, "Instructions7")} />
                            <label htmlFor="Instruction7">Instruction #7</label>
                        </div>}

                        {checkSpecHidden(8) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Instruction8" maxLength={250} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Instructions8.value || ""} onChange={e => this.handleOnChange(e.target.value, "Instructions8")} />
                            <label htmlFor="Instruction8">Instruction #8</label>
                        </div>}

                        {checkSpecHidden(9) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Instruction9" maxLength={250} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Instructions9.value || ""} onChange={e => this.handleOnChange(e.target.value, "Instructions9")} />
                            <label htmlFor="Instruction9">Instruction #9</label>
                        </div>}

                        {checkSpecHidden(10) && <div className="input-field col s12 suffixinput">
                            <input type="text" className="validate" id="Instruction10" maxLength={250} disabled={!Specifics.isEditing ? "disabled" : ""} value={this.state.inputs.Instructions10.value || ""} onChange={e => this.handleOnChange(e.target.value, "Instructions10")}
                                disabled={!Specifics.isEditing ? "disabled" : ""}
                            />
                            <label htmlFor="Instruction10">Instruction #10</label>
                        </div>}
                    </div>
                </div>
                <div className="row mb-0">
                    <div className="input-field col s12 m12">
                        <textarea
                            type="text"
                            id="lenderSpecifics"
                            ref="lenderSpecifics"
                            maxLength={2000}
                            className="materialize-textarea"
                            value={this.state.inputs.lenderSpecifics.value || ""}
                            onChange={(e) => this.handleInputBlur({ lenderSpecifics: { value: e.target.value, isDirty: true, message: "" } })}
                            disabled={!Specifics.isEditing ? "disabled" : ""}
                        ></textarea>
                        <label htmlFor="lenderSpecifics">Lender Specifics</label>
                    </div>
                </div>
                {Specifics.isEditing ? renderButtons() : ""}
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

MainPanelSpecifics.propTypes = {
    dispatch: PropTypes.func,
    orderId: PropTypes.number,
    orderSpecificData: PropTypes.object,
    orderInstructions: PropTypes.object,
    ccEmailsList: PropTypes.array,
    ccInvEmailsList: PropTypes.array,
    returnAddressList: PropTypes.array,
    stateList: PropTypes.array
};
const mapStateToProps = (state) => {
    const { authentication, orderDetailReducers } = state;
    const { orderSpecReducers } = orderDetailReducers;
    const { orderSpecificData, orderInstructions, ccEmailsList, ccInvEmailsList, returnAddressList, stateList } = orderSpecReducers;
    const { accountId } = authentication;
    return {
        accountId,
        orderSpecificData,
        orderInstructions,
        ccEmailsList,
        ccInvEmailsList,
        returnAddressList,
        stateList
    };
};
export default connect(mapStateToProps)(MainPanelSpecifics);