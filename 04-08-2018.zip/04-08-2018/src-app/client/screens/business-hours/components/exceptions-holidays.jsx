import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";

import DatePicker from "DatePicker";
import moment from "moment";
import TimePicker from "../../../features/form/time-picker";
import GridView from "GridView";
import CommonModal from "CommonModal";

import { SUCCESSFULLY_DELETED_MESSAGE, SUCCESSFULLY_CREATED_MESSAGE } from "Constants";
import { showSuccess } from "../../../screens/main-layout/actions";
import { handleApiError } from "ErrorHandler";
import { validateRequired, requireMessage } from "Helpers/validation-helper";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";

import { getBizHoursExcept } from "../actions/index";
import { apiDeleteBizHoursExcept, addBizHoursExcept } from "Api/business-hours-api";

class ExceptionsHolidays extends Component {
    constructor(props) {
        super(props);

        this.state = {
            validator: {},
            inputs: {
                fromDate: "",
                toDate: "",
                startTime: "",
                endTime: "",
                description: "",
                closed: true
            },
            criteria: props.defaultCriteria
        };
    }

    componentDidMount() {
        const { criteria } = this.state;
        this.reload(criteria);
    }

    reload(criteria) {
        const { dispatch } = this.props;

        this.setState({ criteria });

        dispatch(getBizHoursExcept(criteria));
    }

    handleGridViewReload(criteria) {
        this.reload(criteria);
    }

    handleActionClick(action, identifier) {
        const { dispatch } = this.props;
        const { criteria } = this.state;

        this.commonModal.showModal({
            type: "confirm",
            message: `Are you sure you would like to delete this exception/holidays?`
        }, () => {
            apiDeleteBizHoursExcept(identifier, () => {
                this.reload(criteria);
                dispatch(showSuccess(SUCCESSFULLY_DELETED_MESSAGE));
            }, (error) => handleApiError(dispatch, error));
        });
    }

    handleAddBizHoursExcept() {
        const { inputs, criteria } = this.state;
        const { dispatch } = this.props;

        if (!this.validateForm()) {
            return;
        }

        addBizHoursExcept(inputs, () => {
            this.reload(criteria);
            this.setState({
                inputs: {},
                validator: {}
            });
            dispatch(showSuccess(SUCCESSFULLY_CREATED_MESSAGE));
        }, (error) => handleApiError(dispatch, error));
    }

    handleBlurStartTime(value) {
        const { inputs, validator } = this.state;
        const currentDate = moment().format("MM/DD/YYYY").toString();
        let temEndTime = "";
        let isRequiredStartTime = false;
        let isFormatStartTime = false;
        let isFormatEndTime = false;

        if (inputs.endTime !== "" && inputs.endTime !== "Invalid date") {
            temEndTime = inputs.endTime;
            isRequiredStartTime = this.validateRequiredDateTime(value);

            if (moment(`${currentDate} ${temEndTime}`) < moment(`${currentDate} ${value}`)) {
                if (value !== "" && value !== "Invalid date") {
                    isFormatStartTime = true;
                    isFormatEndTime = true;
                }
            }
        } else {
            temEndTime = (value !== "Invalid date") ? value : "";
        }
        this.setState({
            inputs: {
                ...inputs,
                startTime: value,
                endTime: temEndTime
            },
            validator: {
                ...validator,
                isRequiredStartTime,
                isRequiredEndTime: false,
                isFormatStartTime,
                isFormatEndTime
            }
        });
    }

    handleBlurEndTime(value) {
        const { inputs, validator } = this.state;
        const currentDate = moment().format("MM/DD/YYYY").toString();
        let isRequiredEndTime = false;
        let isFormatStartTime = false;
        let isFormatEndTime = false;

        if (inputs.startTime !== "" && inputs.startTime !== "Invalid date") {
            isRequiredEndTime = this.validateRequiredDateTime(value);
            if (moment(`${currentDate} ${value}`) < moment(`${currentDate} ${inputs.startTime}`)) {
                isFormatStartTime = true;
                isFormatEndTime = true;
            }
        }

        this.setState({
            inputs: {
                ...inputs,
                endTime: value
            },
            validator: {
                ...validator,
                isRequiredEndTime,
                isFormatStartTime,
                isFormatEndTime
            }
        });
    }

    handleBlurFromDate(value) {
        const { inputs, validator } = this.state;
        const isRequiredFromDate = this.validateRequiredDateTime(value);
        let tempToDate = "";
        let isFormatToDate = false;
        let isFormatFromDate = false;

        if (inputs.toDate !== "" && inputs.toDate !== "Invalid date") {

            tempToDate = inputs.toDate;
            if (moment(inputs.toDate) < moment(value)) {
                if (value !== "" && value !== "Invalid date") {
                    isFormatToDate = true;
                    isFormatFromDate = true;
                }
            }
        } else {
            tempToDate = (value !== "Invalid date") ? value : "";
        }

        this.setState({
            inputs: {
                ...inputs,
                fromDate: value,
                toDate: tempToDate
            },
            validator: {
                ...validator,
                isRequiredFromDate,
                isRequiredToDate: false,
                isFormatToDate,
                isFormatFromDate
            }
        });
    }

    handleBlurToDate(value) {
        const { inputs, validator } = this.state;
        const isRequiredToDate = this.validateRequiredDateTime(value);
        let isFormatToDate = false;
        let isFormatFromDate = false;

        if (inputs.fromDate !== "" && inputs.fromDate !== "Invalid date") {
            if (moment(value) < moment(inputs.fromDate)) {
                isFormatToDate = true;
                isFormatFromDate = true;
            }
        }

        this.setState({
            inputs: {
                ...inputs,
                toDate: value
            },
            validator: {
                ...validator,
                isRequiredToDate,
                isFormatToDate,
                isFormatFromDate
            }
        });
    }

    validateRequiredDateTime(value) {
        if (value !== "" && value !== "Invalid date" && value !== undefined && value !== null) {
            return false;
        }

        return true;
    }

    validateDescription() {
        const isRequiredDescription = !validateRequired(this.refs.desciption.value);

        return isRequiredDescription;
    }

    handleValidateDescription() {
        const isRequiredDescription = this.validateDescription();

        this.setState({
            validator: {
                ...this.state.validator,
                isRequiredDescription
            }
        });
        return isRequiredDescription;
    }

    validateForm() {
        const { validator, inputs } = this.state;
        const isRequiredDescription = this.validateDescription();
        const isRequiredFromDate = this.validateRequiredDateTime(inputs.fromDate);
        const isRequiredToDate = this.validateRequiredDateTime(inputs.toDate);
        let isRequiredEndTime = false;
        let isRequiredStartTime = false;

        if ((inputs.startTime !== "" && inputs.startTime !== "Invalid date") || (inputs.endTime !== "" && inputs.endTime !== "Invalid date")) {
            isRequiredEndTime = this.validateRequiredDateTime(inputs.endTime);
            isRequiredStartTime = this.validateRequiredDateTime(inputs.startTime);
        }

        const newValidator = {
            ...validator,
            isRequiredDescription,
            isRequiredFromDate,
            isRequiredToDate,
            isRequiredEndTime,
            isRequiredStartTime
        };

        this.setState({
            validator: newValidator
        });

        for (const key in newValidator) {
            if (newValidator[key]) {
                return false;
            }
        }
        return true;
    }

    render() {
        const { inputs, validator, criteria } = this.state;
        const { bizHoursExcept, columns, totalRecords } = this.props;
        const isTimePickerRequired = (inputs.startTime !== "" && inputs.startTime !== "Invalid date" && inputs.startTime !== undefined) ||
            (inputs.endTime !== "" && inputs.endTime !== "Invalid date" && inputs.endTime !== undefined);

        return (
            <div>
                <div className="row">
                    <div className={`input-field col s12 m4 l2 suffixinput required ${validator.isRequiredDescription ? "required-field" : ""}`}>
                        <input
                            id="desciption" type="text" ref="desciption" className="validate" value={inputs.description || ""} maxLength="100"
                            onChange={() => this.setState({
                                inputs: {
                                    ...inputs,
                                    description: this.refs.desciption.value
                                }
                            })}
                            onBlur={() => this.handleValidateDescription()}
                        />
                        <label htmlFor="desciption">Description</label>
                        <span className={`suffix-text ${validator.isRequiredDescription ? "" : "hide"}`}>
                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Description")} />
                        </span>
                    </div>
                    <div className="col s12 m4 l2">
                        <DatePicker
                            defaultValue={inputs.fromDate || ""}
                            labelText="From Date"
                            onBlur={e => this.handleBlurFromDate(moment(e).format("MM/DD/YYYY").toString())}
                            invalidMessage={validator.isFormatFromDate ? "From date cannot be greater than To Date" : ""}
                            isRequiredField
                            requiredMessage={validator.isRequiredFromDate ? requireMessage("From Date") : ""}
                        />
                    </div>
                    <div className="col s12 m4 l2">
                        <DatePicker
                            defaultValue={inputs.toDate || ""}
                            labelText="To Date"
                            onBlur={e => this.handleBlurToDate(moment(e).format("MM/DD/YYYY").toString())}
                            invalidMessage={validator.isFormatToDate ? "From date cannot be greater than To Date" : ""}
                            isRequiredField
                            requiredMessage={validator.isRequiredToDate ? requireMessage("To Date") : ""}
                        />
                    </div>
                    <div className="col s12 m12 l6">
                        <div className="row">
                            <div className="col s12 m3 l3">
                                <div className={(inputs.closed || !(inputs.toDate !== "" && inputs.toDate !== "Invalid date" && inputs.toDate !== undefined)) ? "disable-field" : ""}>
                                    <TimePicker
                                        defaultValue={inputs.startTime || ""}
                                        labelText="Start Time"
                                        onBlur={e => this.handleBlurStartTime(moment(e ? `01/01/2000 ${e}` : "").format("h:mm:ss A").toString())}
                                        disabled={inputs.closed || !(inputs.toDate !== "" && inputs.toDate !== "Invalid date" && inputs.toDate !== undefined)}
                                        isRequiredField={isTimePickerRequired}
                                        requiredMessage={validator.isRequiredStartTime ? requireMessage("Start Time") : ""}
                                        invalidMessage={validator.isFormatStartTime ? "Start time cannot be greater than End Time" : ""}
                                    />
                                </div>
                            </div>
                            <div className="col s12 m3 l3">
                                <div className={(inputs.closed || !(inputs.toDate !== "" && inputs.toDate !== "Invalid date" && inputs.toDate !== undefined)) ? "disable-field" : ""}>
                                    <TimePicker
                                        defaultValue={inputs.endTime || ""}
                                        labelText="End Time"
                                        onBlur={e => this.handleBlurEndTime(moment(e ? `01/01/2000 ${e}` : "").format("h:mm:ss A").toString())}
                                        disabled={inputs.closed || !(inputs.toDate !== "" && inputs.toDate !== "Invalid date" && inputs.toDate !== undefined)}
                                        isRequiredField={isTimePickerRequired}
                                        requiredMessage={validator.isRequiredEndTime ? requireMessage("EndTime") : ""}
                                        invalidMessage={validator.isFormatEndTime ? "Start time cannot be greater than End Time" : ""}
                                    />
                                </div>
                            </div>
                            <div className="input-field col s12 m3 l3">
                                <label>
                                    <input
                                        type="checkbox" defaultChecked ref="status"
                                        checked={inputs.closed}
                                        onChange={(e) => this.setState({
                                            inputs: {
                                                ...inputs,
                                                closed: e.target.checked
                                            }
                                        })}
                                    />
                                    <span>Close</span>
                                </label>
                            </div>
                            <div className="input-field col s12 m3 l3">
                                <button className="btn success-color action-btn w-100" onClick={() => this.handleAddBizHoursExcept()}>Add</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col s12 m12">
                        <div className="wrap-result-search">
                            <GridView
                                criteria={criteria}
                                totalRecords={totalRecords}
                                datasources={bizHoursExcept} //Pass datasources
                                columns={columns} //Pass columns array
                                identifier={"exceptId"} //Identifier for grid row
                                actions={["delete"]} //Remove if no action needed
                                onGridViewReload={(e) => this.handleGridViewReload(e)} //Paginate changed => need reload datasource base on criteria
                                onActionClick={(action, identifier) => this.handleActionClick(action, identifier)}
                            />
                        </div>
                    </div>
                </div>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

ExceptionsHolidays.defaultProps = {
    columns: [
        {
            title: "#",
            data: "index",
            type: "no-sorting-action"
        },
        {
            title: "Description",
            data: "description"
        },
        {
            title: "From Date",
            data: "startDate",
            type: "date"
        },
        {
            title: "To Date",
            data: "endDate",
            type: "date"
        }, {
            title: "Start Time",
            data: "openTime",
            type: "time"
        }, {
            title: "End Time",
            data: "closeTime",
            type: "time"
        }, {
            title: "Status",
            data: "closed",
            type: "checkboxClosed"
        }
    ],
    defaultCriteria: {
        sortColumn: "",
        sortDirection: true,
        page: 1,
        itemPerPage: 25
    }
};

ExceptionsHolidays.propTypes = {
    dispatch: PropTypes.func,
    bizHoursExcept: PropTypes.array,
    defaultCriteria: PropTypes.object,
    columns: PropTypes.array,
    totalRecords: PropTypes.number
};

const mapStateToProps = (state) => {
    const { businessHoursReducers } = state;
    const { bizHoursExcept, totalRecords } = businessHoursReducers;
    return {
        bizHoursExcept,
        totalRecords
    };
};

export default connect(mapStateToProps)(ExceptionsHolidays);