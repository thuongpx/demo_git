import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";

import { handleApiError } from "ErrorHandler";
import TimePicker from "../../../features/form/time-picker";
import moment from "moment";
import { getBusinessHours } from "../actions/index";
import { shallowCompareState, shallowCompareProps } from "../../../helpers/common-helper";
import { apiUpdateBusinessHours } from "Api/business-hours-api";
import { showSuccess } from "../../../screens/main-layout/actions";
import { SUCCESSFULLY_SAVED_MESSAGE } from "Constants";
import { requireMessage } from "Helpers/validation-helper";

class HoursOperation extends Component {
    constructor(props) {
        super(props);

        this.state = {
            businessHours: props.defaultBusinessHours
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentDidMount() {
        const { dispatch } = this.props;

        dispatch(getBusinessHours());
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            businessHours: nextProps.businessHours
        });
    }

    handleChangeInput(value, key) {
        const { businessHours } = this.state;
        const currentDate = moment().format("MM/DD/YYYY").toString();
        const newBusinessHours = businessHours.map((item, index) => {
            if (index === key) {
                let { isRequiredStartTime } = item;
                let { isRequiredEndTime } = item;
                let { isFormatStartTime } = item;
                let { isFormatEndTime } = item;
                if (value.openTime !== undefined) {
                    isRequiredStartTime = this.validateRequiredDateTime(value.openTime);
                    if (moment(`${currentDate} ${item.closeTime}`) < moment(`${currentDate} ${value.openTime}`)) {
                        if (value !== "" && value !== "Invalid date") {
                            isFormatStartTime = true;
                            isFormatEndTime = true;
                        }
                    } else {
                        isFormatStartTime = false;
                        isFormatEndTime = false;
                    }
                }
                if (value.closeTime !== undefined) {
                    isRequiredEndTime = this.validateRequiredDateTime(value.closeTime);
                    if (moment(`${currentDate} ${value.closeTime}`) < moment(`${currentDate} ${item.openTime}`)) {
                        isFormatStartTime = true;
                        isFormatEndTime = true;
                    } else {
                        isFormatStartTime = false;
                        isFormatEndTime = false;
                    }
                }

                if (isRequiredStartTime || isRequiredEndTime) {
                    isFormatStartTime = false;
                    isFormatEndTime = false;
                }

                return {
                    ...item,
                    ...value,
                    isRequiredStartTime,
                    isRequiredEndTime,
                    isFormatStartTime,
                    isFormatEndTime
                };
            } else {
                return item;
            }
        });

        this.setState({ businessHours: newBusinessHours });
    }

    validateRequiredDateTime(value) {
        if (value !== "" && value !== "Invalid date" && value !== undefined && value !== null) {
            return false;
        }

        return true;
    }

    saveChanges() {
        const { businessHours } = this.state;
        const { dispatch } = this.props;
        let isUpdate = true;

        businessHours.map(item => {
            if (item.isRequiredStartTime
                || item.isRequiredEndTime
                || item.isFormatStartTime
                || item.isFormatEndTime) {
                isUpdate = false;
            }
        });

        if (isUpdate) {
            apiUpdateBusinessHours(businessHours, () => {
                dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
            }, (error) => handleApiError(dispatch, error));
        }
    }

    render() {
        const { businessHours } = this.state;
        const renderCell = businessHours.map((item, key) => {
            return (
                <tr key={key}>
                    <td style={{ paddingTop: "0px", paddingBottom: "0px" }}>
                        <span>{item.day}</span>
                    </td>
                    <td style={{ paddingTop: "0px", paddingBottom: "0px" }}>
                        <label><input type="checkbox" checked={item.isClose} onChange={() => this.handleChangeInput({ isClose: !item.isClose }, key)} /> <span>Closed</span></label>
                    </td>
                    <td style={{ paddingTop: "0px", paddingBottom: "0px" }} className={(item.isClose ? "disable-field" : "")}>
                        <TimePicker
                            defaultValue={item.openTime || "04:00 AM"}
                            onBlur={e => this.handleChangeInput({ openTime: moment(e ? `01/01/2000 ${e}` : "").format("h:mm A").toString() }, key)}
                            disabled={item.isClose} isRequiredField
                            requiredMessage={item.isRequiredStartTime ? requireMessage("Start Time") : ""}
                            invalidMessage={item.isFormatStartTime ? "Start time cannot be greater than End Time" : ""}
                        />
                    </td>
                    <td style={{ paddingTop: "0px", paddingBottom: "0px" }} className={(item.isClose ? "disable-field" : "")}>
                        <TimePicker
                            defaultValue={item.closeTime || "06:30 PM"}
                            onBlur={e => this.handleChangeInput({ closeTime: moment(e ? `01/01/2000 ${e}` : "").format("h:mm A").toString() }, key)}
                            disabled={item.isClose}
                            isRequiredField
                            requiredMessage={item.isRequiredEndTime ? requireMessage("EndTime") : ""}
                            invalidMessage={item.isFormatEndTime ? "Start time cannot be greater than End Time" : ""}
                        />
                    </td>
                </tr>
            );
        });

        return (
            <div className="row">
                <div className="col s12">
                    <div className="wrap-result-search">
                        <table className="striped responsive-table">
                            <thead>
                                <tr>
                                    <th>Day</th>
                                    <th>Status</th>
                                    <th>Start Time</th>
                                    <th>End Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                {renderCell}
                            </tbody>
                        </table>
                    </div>
                </div>

                <div className="col s12 p-0 center-align">
                    <button type="button" style={{ marginTop: "50px", width: "150px" }} className="btn success-color action-btn" onClick={() => this.saveChanges()}>Save</button>
                </div>
            </div>
        );
    }
}

HoursOperation.propTypes = {
    dispatch: PropTypes.func,
    businessHours: PropTypes.array,
    defaultBusinessHours: PropTypes.array
};

HoursOperation.defaultProps = {
    defaultBusinessHours: [
        {
            bussinessHoursId: 10,
            day: "Monday",
            openTime: "4:00 AM",
            closeTime: "6:30 PM"
        },
        {
            bussinessHoursId: 11,
            day: "Tuesday",
            closeTime: "6:30 PM"
        },
        {
            bussinessHoursId: 11,
            day: "Wednesday",
            closeTime: "6:30 PM"
        },
        {
            bussinessHoursId: 11,
            day: "Thursday",
            closeTime: "6:30 PM"
        },
        {
            bussinessHoursId: 11,
            day: "Friday",
            closeTime: "6:30 PM"
        },
        {
            bussinessHoursId: 11,
            day: "Saturday",
            closeTime: "6:30 PM"
        },
        {
            bussinessHoursId: 11,
            day: "Sunday",
            closeTime: "6:30 PM"
        }
    ]
};

const mapStateToProps = (state) => {
    const { businessHoursReducers } = state;
    const { businessHours } = businessHoursReducers;
    return {
        businessHours
    };
};

export default connect(mapStateToProps)(HoursOperation);