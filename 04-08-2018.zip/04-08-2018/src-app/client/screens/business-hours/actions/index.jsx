import { handleApiError } from "ErrorHandler";
import { apiGetBusinessHours, apiGetBizHoursExcept } from "Api/business-hours-api";

export const REQUEST_BUSINESS_HOURS = "REQUEST_BUSINESS_HOURS";
export const RECEIVE_BUSINESS_HOURS = "RECEIVE_BUSINESS_HOURS";
export const REQUEST_BIZ_HOURS_EXCEPT = "REQUEST_BIZ_HOURS_EXCEPT";
export const RECEIVE_BIZ_HOURS_EXCEPT = "RECEIVE_BIZ_HOURS_EXCEPT";

export const requestBusinessHours = () => {
    return {
        type: REQUEST_BUSINESS_HOURS
    };
};

export const receiveBusinessHours = (businessHours) => {
    return {
        type: RECEIVE_BUSINESS_HOURS,
        businessHours
    };
};

export const getBusinessHours = () => {
    return dispatch => {
        dispatch(requestBusinessHours());

        return apiGetBusinessHours((result) => {
            dispatch(receiveBusinessHours(result.data.businessHours));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const requestBizHoursExcept = () => {
    return {
        type: REQUEST_BIZ_HOURS_EXCEPT
    };
};

export const receiveBizHoursExcept = (data) => {
    return {
        type: RECEIVE_BIZ_HOURS_EXCEPT,
        bizHoursExcept: data.bizHoursExcept,
        totalRecords: data.totalRecords
    };
};

export const getBizHoursExcept = (criteria) => {
    return dispatch => {
        dispatch(requestBizHoursExcept());

        return apiGetBizHoursExcept(criteria, result => {
            dispatch(receiveBizHoursExcept(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};