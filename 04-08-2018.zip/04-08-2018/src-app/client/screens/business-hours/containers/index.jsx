import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";

import ExceptionsHolidays from "../components/exceptions-holidays";
import HoursOperation from "../components/hours-operation";

class BusinessHours extends Component {
    constructor(props) {
        super(props);

        const tabs = [...props.tabs];

        this.state = {
            tabs
        };
        this.handleTabClick = this.handleTabClick.bind(this);
    }

    handleTabClick(tab) {
        this.setActiveTab(tab);
    }

    setActiveTab(tab) {
        const { tabs } = this.state;

        tabs.map(item => {
            if (item.title === tab.title) {
                item.isActive = true;
            } else item.isActive = false;
            return item;
        });

        this.setState({ tabs });
    }

    render() {
        const activeTab = this.state.tabs.find(tab => tab.isActive);
        const renderTabs = () => {
            return this.state.tabs.map((tab, key) => {
                const classNameActive = tab.isActive ? "active" : "";
                return (
                    <li onClick={() => {
                        this.handleTabClick(tab);
                    }} key={key} className="tab col"
                    ><a style={{ paddingLeft: "0px" }} className={classNameActive} role="button" key={key}>{tab.title}</a></li>
                );
            });
        };
        const renderTabContent = () => {
            if (activeTab) {
                switch (activeTab.title) {
                    case "Hours of Operation":
                        return (
                            <div>
                                <HoursOperation />
                            </div>
                        );
                    case "Exceptions/ Holidays":
                        return (
                            <div>
                                <ExceptionsHolidays />
                            </div>
                        );
                    default:
                        return (
                            <div></div>
                        );
                }
            }
            return (<div></div>);
        };

        return (
            <div className="col s12 custome-modal">
                <div className="row">
                    <div className="col m12">
                        <h3 className="title-page-detail">{"Business Hours"}</h3>
                    </div>
                </div>
                <div className="place-section">
                    <ul className="tabs">
                        {renderTabs()}
                    </ul>
                    <div className="tab-content">
                        {renderTabContent()}
                    </div>
                </div>
            </div>
        );
    }
}

BusinessHours.defaultProps = {
    tabs: [
        { title: "Hours of Operation", isActive: true },
        { title: "Exceptions/ Holidays", isActive: false }
    ]
};

BusinessHours.propTypes = {
    tabs: PropTypes.array
};
export default connect()(BusinessHours);