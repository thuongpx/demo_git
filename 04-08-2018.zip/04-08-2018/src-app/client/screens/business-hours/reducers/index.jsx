import { REQUEST_BUSINESS_HOURS, RECEIVE_BUSINESS_HOURS, REQUEST_BIZ_HOURS_EXCEPT, RECEIVE_BIZ_HOURS_EXCEPT } from "../actions/index";

const initState = {
    businessHours: [],
    bizHoursExcept: [],
    totalRecords: 0,
    isFetching: false
};

export default function businessHoursReducers(state = initState, action) {
    switch (action.type) {
        case REQUEST_BUSINESS_HOURS:
        case REQUEST_BIZ_HOURS_EXCEPT:
            return {
                ...state,
                isFetching: true
            };
        case RECEIVE_BUSINESS_HOURS:
            return {
                ...state,
                businessHours: action.businessHours,
                isFetching: false
            };
        case RECEIVE_BIZ_HOURS_EXCEPT:
            return {
                ...state,
                bizHoursExcept: action.bizHoursExcept,
                totalRecords: action.totalRecords,
                isFetching: false
            };
        default:
            return state;
    }
}