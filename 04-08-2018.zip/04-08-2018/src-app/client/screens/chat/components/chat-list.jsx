import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";

import { getClientsUserByRole } from "../actions";
import { roleNameFinal, shallowCompareState, shallowCompareProps } from "../../../helpers/common-helper";
import { USER_TYPE, USER_STATUS } from "../../../constant/constants";
import Loader from "../../../features/loader";
import noAvatarImg from "./../../../public/images/no-avatar.png";
class ChatList extends Component {
    constructor(props) {
        super(props);
    }

    componentWillUnmount() {
        // const { profile, roleNames, roleType } = this.props;
        // const roleName = roleNameFinal(roleNames);

        // if (roleType === USER_TYPE.Client) {
        //     stopListenClientChangeStatus();

        //     if (roleName === CLIENT_SUBTYPE_DISPLAY.CLIENT) {
        //         stopAdminListenClientChangeStatus(profile.id);
        //     } else if (roleName === CLIENT_SUBTYPE_DISPLAY.BRANCH) {
        //         stopBranchListenClientChangeStatus(profile.id);
        //     }
        // }
    }

    getColorByStatus(status) {
        switch (status) {
            case USER_STATUS.DO_NOT_DISTURB:
                return "red-text";
            case USER_STATUS.ONLINE:
                return "green-text";
            default:
                return "";
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentDidMount() {
        $("#chatList").sidenav({
            edge: "right",
            inDuration: 300,
            outDuration: 300,
            onOpenEnd: () => {
                $("body").css({
                    overflow: "auto"
                });
            },
            onOpenStart: () => {
                const { dispatch, profile, roleNames, roleType } = this.props;

                if (roleType === USER_TYPE.Client) {
                    // get the list of available users which the current user could connect
                    dispatch(getClientsUserByRole({ role: roleNameFinal(roleNames), clientId: profile.id }));
                }
            }
        });
    }

    render() {
        const { isFetching, users } = this.props;

        const renderUsers = () => {
            if (users.length > 0) {
                return users.map(user => {
                    const statusClass = this.getColorByStatus(user.Status);

                    return (
                        <div className="user" key={user.UsersId}>
                            <img src={noAvatarImg} alt="Felecia Castro" className="circle photo" />
                            <div className="name">{user.RoleId === 7 ? user.FullName : user.Company}</div>
                            <div className="online"><i className={`${statusClass} fa fa-circle`}></i></div>
                        </div>
                    );
                });
            }

            return <div></div>;
        };

        return (
            <div id="chatList" className="sidenav">
                <a className="sidenav-close" role="button"><span className="lnr lnr-cross"></span></a>
                <div className="nano-content">
                    {isFetching &&
                        <Loader onlyIcon={false} isShow />
                    }
                    {!isFetching &&
                        renderUsers()
                    }
                </div>
            </div>
        );
    }
}

ChatList.propTypes = {
    dispatch: PropTypes.func.isRequired,
    users: PropTypes.array,
    profile: PropTypes.object,
    roleType: PropTypes.string,
    roleNames: PropTypes.array,
    onlineUsers: PropTypes.array,
    isFetching: PropTypes.bool
};

const mapStateToProps = state => {
    const { authentication, chat } = state;
    const { profile, role } = authentication;
    const { users, onlineUsers, isFetching } = chat;

    return {
        profile,
        roleType: role ? role.roleType : null,
        roleNames: role ? role.roleNames : [],
        users,
        onlineUsers,
        isFetching
    };
};

export default connect(mapStateToProps)(ChatList);