import { DONE_GET_CLIENTS_USER_BY_ROLE, START_GET_CLIENTS_USER_BY_ROLE, UPDATE_USER_STATUS } from "../actions";
import { USER_STATUS } from "../../../constant/constants";

export default function chatReducer(state = {
    users: [],
    isFetching: true,
    status: USER_STATUS.ONLINE
}, action) {
    switch (action.type) {
        case DONE_GET_CLIENTS_USER_BY_ROLE:
            return {
                ...state,
                users: action.users,
                isFetching: false
            };
        case START_GET_CLIENTS_USER_BY_ROLE:
            return {
                ...state,
                isFetching: true
            };
        case UPDATE_USER_STATUS:
            return {
                ...state,
                users: state.users.map((item) => {
                    if (item.UsersId === action.id) {
                        item.Status = action.status;
                    }

                    return item;
                })
            };
        default:
            return state;
    }
}