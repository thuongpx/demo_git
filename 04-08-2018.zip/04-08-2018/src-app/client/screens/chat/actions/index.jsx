import { apiGetClientsUserByRole } from "../../../api/user-api";

export const START_GET_CLIENTS_USER_BY_ROLE = "START_GET_CLIENTS_USER_BY_ROLE";
export const DONE_GET_CLIENTS_USER_BY_ROLE = "DONE_GET_CLIENTS_USER_BY_ROLE";
export const ONLINE_USERS_RECEIVE = "ONLINE_USERS_RECEIVE";

export const UPDATE_USER_STATUS = "UPDATE_USER_STATUS";

export const startGetClientsUserByRole = () => {
    return {
        type: START_GET_CLIENTS_USER_BY_ROLE
    };
};

export const doneGetClientsUserByRole = (data) => {
    return {
        type: DONE_GET_CLIENTS_USER_BY_ROLE,
        users: data
    };
};

export const getClientsUserByRole = (userData) => {
    return (dispatch) => {
        dispatch(startGetClientsUserByRole());

        return apiGetClientsUserByRole(userData, (result) => {
            setTimeout(() => {
                dispatch(doneGetClientsUserByRole(result.data));
            }, 5000);
        });
    };
};

export const updateUserStatus = (inputs) => {
    return {
        type: UPDATE_USER_STATUS,
        id: inputs.usersId,
        status: inputs.status
    };
};