import {
    DO_NOT_USE_SET_GRID,
    DO_NOT_USE_SET_CRITERIA,
    DO_NOT_USE_SET_GRID_2,
    DO_NOT_USE_SET_CRITERIA_2,
    DO_NOT_USE_SET_BLACKLIST,
    DO_NOT_USE_LIST
} from "./../actions/client-do-not-use-actions";

export default function doNotUseReducer(state = {
    //grid view 1
    datasources:
    {
        data: [],
        totalRecords: 0
    },
    isShowModal: false,
    criteria:
    {
        sortColumn: "SignerId",
        sortDirection: true,
        page: 1,
        itemPerPage: 999999999,
        whereText: "",
        allowRowSelect: true
    },
    doNotUse: {},
    //grid view 2
    datasources2:
    {
        data: [],
        totalRecords: 0
    },
    criteria2:
    {
        sortColumn: "SignerId",
        sortDirection: true,
        page: 1,
        itemPerPage: 999999999,
        whereText: "",
        allowRowSelect: true
    },
    doNotUse2: {},
    //black list
    blackList: {}
}, action) {
    switch (action.type) {
        //grid view 1
        case DO_NOT_USE_SET_GRID:
            return {
                ...state,
                datasources: action.doNotUse
            };
        case DO_NOT_USE_SET_CRITERIA:
            return {
                ...state,
                criteria: action.criteria
            };
        //grid view 2
        case DO_NOT_USE_SET_GRID_2:
            return {
                ...state,
                datasources2: action.doNotUse2
            };
        case DO_NOT_USE_SET_CRITERIA_2:
            return {
                ...state,
                criteria2: action.criteria2
            };
        //update black list
        case DO_NOT_USE_SET_BLACKLIST:
            return {
                ...state,
                blackList: action.blackList
            };
        case DO_NOT_USE_LIST:
            return {
                ...state,
                datasources: action.doNotUse,
                datasources2: action.doNotUse2
            };
        default:
            return state;
    }
}