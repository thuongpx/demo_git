import { GET_CLIENT_SPECIFICS_RECEIVE, GET_CLIENT_SPECIFICS_REQUEST } from "./../actions/client-specifics-actions";

export default function clientSpecificsReducer(state = {
    isFetching: false,
    specifics: {},
    validators: {}
}, action) {
    switch (action.type) {
        case GET_CLIENT_SPECIFICS_RECEIVE:
            return {
                ...state,
                isFetching: action.isFetching,
                specifics: action.specifics
            };
        case GET_CLIENT_SPECIFICS_REQUEST:
            return {
                ...state,
                isFetching: action.isFetching
            };
        default:
            return state;
    }
}