import { SET_CLIENT_STATE, CLIENT_RECEIVE, SET_CLIENT_VALIDATOR, SET_NOTARY_SHOW_MODAL, SET_USER_NAME, SET_STATE_EXIST_SEC_ANSWER, UPDATE_RAW_DATA_CLIENT_DETAIL_GENERAL } from "./../actions/client-details-actions";

export default function clientDetailsReducer(state = {
    isFetching: false,
    username: null,
    clients: {},
    listClients: [],
    listStates: [],
    listCourier: [],
    listEmployees: [],
    listSalesRep: [],
    validator: {},
    listIndustry: [],
    isShowModal: false,
    rawDataBeforeUpdate: {}
}, action) {
    switch (action.type) {
        case SET_CLIENT_STATE:
            return {
                ...state,
                clients: action.client
            };
        case SET_USER_NAME:
            return {
                ...state,
                ...action.username
            };
        case SET_CLIENT_VALIDATOR:
            return {
                ...state,
                validator: action.validator
            };
        case CLIENT_RECEIVE:
            return {
                ...state,
                username: action.username,
                isExistOrderOpen: action.isExistOrderOpen,
                isExistSecAnswer: action.isExistSecAnswer,
                isFetching: false,
                clients: action.clients,
                rawDataBeforeUpdate: action.clients,
                listClients: action.listClients,
                listIndustry: action.listIndustry,
                listStates: action.listStates,
                listCourier: action.listCourier,
                listEmployees: action.listEmployees,
                listSalesRep: action.listSalesRep,
                userId: Number(action.userId),
                validator: {}
            };
        case SET_NOTARY_SHOW_MODAL:
            return {
                ...state,
                isShowModal: action.isShowModal
            };
        case SET_STATE_EXIST_SEC_ANSWER:
            return {
                ...state,
                isExistSecAnswer: action.isExistSecAnswer
            };
        case UPDATE_RAW_DATA_CLIENT_DETAIL_GENERAL:
            return {
                ...state,
                rawDataBeforeUpdate: state.clients
            };
        default:
            return state;
    }
}