import { RECENT_ORDER_SET_GRID, RECENT_ORDER_SET_CRITERIA } from "./../actions/client-recent-orders-actions";

export default function recentOrdersReducer(state = {
    datasources:
        {
            data: [],
            totalRecords: 0
        },
    isShowModal: false,
    criteria:
        {
            sortColumn: "RowNumber",
            sortDirection: true,
            page: 1,
            itemPerPage: 25,
            recentDay: 30
        },
    recentOrders: {}
}, action) {
    switch (action.type) {
        case RECENT_ORDER_SET_GRID:
            return {
                ...state,
                datasources: action.recentOrders
            };
        case RECENT_ORDER_SET_CRITERIA:
            return {
                ...state,
                criteria: action.criteria
            };
        default:
            return state;
    }
}