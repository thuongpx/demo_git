import { combineReducers } from "redux";
import clientSearchReducer from "./client-search-reducers";
import clientAgentReducer from "./client-agent-reducer";
import clientSpecificsReducer from "./client-specifics-reducers";
import clientDetailsReducer from "./client-details-reducers";
import recentOrdersReducer from "./client-recent-orders-reducer";
import doNotUseReducer from "./client-do-not-use-reducer";

const clientManagementReducers = combineReducers({
    clientSearch: clientSearchReducer,
    agent: clientAgentReducer,
    clientSpecifics: clientSpecificsReducer,
    clientDetails: clientDetailsReducer,
    recentOrders: recentOrdersReducer,
    doNotUse: doNotUseReducer
});

export default clientManagementReducers;
