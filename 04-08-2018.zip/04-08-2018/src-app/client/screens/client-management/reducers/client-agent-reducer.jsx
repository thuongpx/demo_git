export default function clientAgentReducer(state = {
    datasources:
        {
            data: [],
            totalRecords: 0
        },
    isShowModal: false,
    agentId: 0,
    criteria:
        {
            sortColumn: "AgentId",
            sortDirection: true,
            page: 1,
            itemPerPage: 25
        },
    agent: {},
    user: {},
    branches: [],
    validator: {}
}, action) {
    switch (action.type) {
        case "AGENT_SET_AGENTS":
            return {
                ...state,
                datasources: action.agents
            };
        case "AGENT_SET_AGENT":
            return {
                ...state,
                agent: action.agent
            };
        case "AGENT_SET_BRANCHES":
            return {
                ...state,
                branches: action.branches
            };
        case "AGENT_SET_VALIDATOR":
            return {
                ...state,
                validator: action.validator
            };
        case "AGENT_TOGGLE_UPSERTMODAL":
            return {
                ...state,
                agentId: action.agentId,
                agent: action.agent,
                isShowModal: action.isShowModal
            };
        case "AGENT_SET_CRITERIA":
            return {
                ...state,
                criteria: action.criteria
            };
        case "AGENT_SET_USER":
            return {
                ...state,
                user: action.user
            };
        default:
            return state;
    }
}