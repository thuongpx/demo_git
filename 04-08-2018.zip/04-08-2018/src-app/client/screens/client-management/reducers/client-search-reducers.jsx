import { CLIENTS_SEARCH_RECEIVE, LIST_CLIENT_MANAGEMENT, STATUS_CLIENT_RECEIVE, CLIENTS_SET_FILTER } from "./../actions/client-search-actions";

export default function clientSearchReducer(state = {
    isFetching: false,
    listClients: {},
    states: [],
    brokerId: 0,
    filter: {
        sortColumn: "BrokerID",
        sortDirection: false,
        page: 1,
        itemPerPage: 25,
        clientID: "",
        clientName: "",
        address: "",
        city: "",
        state: "",
        inactive: false
    }
}, action) {
    switch (action.type) {
        case CLIENTS_SET_FILTER:
            return {
                ...state,
                filter: action.filter
            };
        case CLIENTS_SEARCH_RECEIVE:
            return {
                ...state,
                isFetching: false,
                listClients: action.listClients
            };
        case LIST_CLIENT_MANAGEMENT:
            return {
                ...state,
                isFetching: false,
                listClients: action.listClients,
                states: action.listStates
            };
        case STATUS_CLIENT_RECEIVE:
            return {
                ...state,
                isFetching: false,
                isSuccess: action.isSuccess,
                brokerId: action.brokerId
            };
        default:
            return state;
    }
}