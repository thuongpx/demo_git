import { apiGetAvailableSigner } from "Api/client-detail-api";
import { apiGetBlackListSigner } from "../../../api/client-detail-api";
import { apiUpdateBlackListSigner } from "../../../api/client-detail-api";
import { apiUpdateWhiteListSigner } from "../../../api/client-detail-api";

export const DO_NOT_USE_SET_CRITERIA = "DO_NOT_USE_SET_CRITERIA";
export const DO_NOT_USE_SET_GRID = "DO_NOT_USE_SET_GRID";
export const DO_NOT_USE_SET_CRITERIA_2 = "DO_NOT_USE_SET_CRITERIA_2";
export const DO_NOT_USE_SET_GRID_2 = "DO_NOT_USE_SET_GRID_2";
export const DO_NOT_USE_SET_BLACKLIST = "DO_NOT_USE_SET_BLACKLIST";
//grid view 1
export const setDoNotUseCriteria = (criteria) => {
    return {
        type: DO_NOT_USE_SET_CRITERIA,
        criteria
    };
};

export const setDoNotUse = (doNotUse) => {
    return {
        type: DO_NOT_USE_SET_GRID,
        doNotUse
    };
};

export const startSetDoNotUse = () => {
    return (dispatch, getState) => {
        apiGetAvailableSigner(getState().clientManagement.doNotUse.criteria, (response) => {
            dispatch(setDoNotUse(response.data));
        });
    };
};
//grid view 2
export const setDoNotUseCriteria2 = (criteria2) => {
    return {
        type: DO_NOT_USE_SET_CRITERIA_2,
        criteria2
    };
};

export const setDoNotUse2 = (doNotUse2) => {
    doNotUse2.data = doNotUse2.data.map(v => {
        return { ...v, ...{ "Note": "View" } };
    });
    return {
        type: DO_NOT_USE_SET_GRID_2,
        doNotUse2
    };
};
//movement action
export const startSetDoNotUse2 = () => {
    return (dispatch, getState) => {
        apiGetBlackListSigner(getState().clientManagement.doNotUse.criteria2, (response) => {
            dispatch(setDoNotUse2(response.data));
        });
    };
};

export const setDoNotUseBlackList = (brokerId, blackList) => {
    return (dispatch) => {
        apiUpdateBlackListSigner(brokerId, blackList, () => {
            dispatch(startSetDoNotUse2());
            dispatch(startSetDoNotUse());
        });
    };
};

export const setDoNotUseWhiteList = (brokerId, whiteList) => {
    return (dispatch) => {
        apiUpdateWhiteListSigner(brokerId, whiteList, () => {
            dispatch(startSetDoNotUse2());
            dispatch(startSetDoNotUse());
        });
    };
};