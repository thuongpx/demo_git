import { apiAddClient, apiGetClientById, apiUpdateClient } from "Api/clients-api";
import { apiResetPassword, apiGenerateDefaultLogin } from "Api/user-api";
import { apiDeleteSecAnswers } from "Api/sec-api";
import { apiAddNotaryLoop } from "Api/notary-loop-api";
import { showSuccess } from "../../main-layout/actions";
import { handleApiError } from "ErrorHandler";
import { SUCCESSFULLY_RESET_PASSWORD, SUCCESSFULLY_RE_VALIDATE_AUTHENTICATION } from "../../../constant/constants";

export const SET_CLIENT_STATE = "SET_CLIENT_STATE";
export const SET_CLIENT_VALIDATOR = "SET_CLIENT_VALIDATOR";
export const CLIENT_RECEIVE = "CLIENT_RECEIVE";
export const SET_NOTARY_SHOW_MODAL = "SET_NOTARY_SHOW_MODAL";
export const SET_USER_NAME = "SET_USER_NAME";
export const SET_STATE_EXIST_SEC_ANSWER = "SET_STATE_EXIST_SEC_ANSWER";
export const UPDATE_RAW_DATA_CLIENT_DETAIL_GENERAL = "UPDATE_RAW_DATA_CLIENT_DETAIL_GENERAL";

export const setClientState = (client) => {
    return {
        type: SET_CLIENT_STATE,
        client
    };
};

export const setStateExistSecAnswer = (isExistSecAnswer) => {
    return {
        type: SET_STATE_EXIST_SEC_ANSWER,
        isExistSecAnswer
    };
};

export const setUserName = (username) => {
    return {
        type: SET_USER_NAME,
        username
    };
};

export const setClientValidator = (validator) => {
    return {
        type: SET_CLIENT_VALIDATOR,
        validator
    };
};

export const setNotaryShowModal = (isShowModal) => {
    return {
        type: SET_NOTARY_SHOW_MODAL,
        isShowModal
    };
};

export const receiveClient = (clients) => {
    return {
        type: CLIENT_RECEIVE,
        clients: clients.clientDetails,
        listClients: clients.listClients ? clients.listClients[0] : null,
        listStates: clients.listStates,
        listCourier: clients.listCourier,
        listEmployees: clients.listEmployees,
        listSalesRep: clients.listSalesRep,
        listIndustry: clients.listIndustry,
        username: clients.username,
        userId: clients.userId,
        isExistSecAnswer: clients.isExistSecAnswer,
        isExistOrderOpen: clients.isExistOrderOpen
    };
};

export const getClientById = (brokerId, callback) => {
    return (dispatch) => {
        return apiGetClientById(brokerId, (response) => {
            if (response.data.clientDetails === undefined) {
                response.data.clientDetails = {};
                response.data.clientDetails.TenantId = 1;
                response.data.clientDetails.TermsAccept = 1;
                response.data.clientDetails.AutoOrders = 1;
                response.data.clientDetails.Inactive = 0;
            } else {
                if (response.data.clientDetails.AutoOrders) {
                    response.data.clientDetails.AutoOrders = response.data.clientDetails.AutoOrders.data[0] === 1 ? 1 : 0;
                } else response.data.clientDetails.AutoOrders = false;
                if (response.data.clientDetails.TermsAccept) {
                    response.data.clientDetails.TermsAccept = response.data.clientDetails.TermsAccept.data[0] === 1 ? true : false;
                } else response.data.clientDetails.TermsAccept = false;
                if (response.data.clientDetails.Inactive) {
                    response.data.clientDetails.Inactive = response.data.clientDetails.Inactive.data[0] === 1 ? 1 : 0;
                } else response.data.clientDetails.Inactive = false;
            }

            response.data.listEmployees.map((item) => {
                item.Employees = item.FirstName.concat(" ", item.LastName);
            });

            response.data.listSalesRep.map((item) => {
                item.SalesRep = item.FirstName.concat(" ", item.LastName);
            });

            dispatch(receiveClient(response.data));
            callback(`${response.data.clientDetails.Company} - ${response.data.clientDetails.BrokerID}`);

        }, (error) => handleApiError(dispatch, error));
    };
};

export const updateRawDataClient = () => {
    return {
        type: UPDATE_RAW_DATA_CLIENT_DETAIL_GENERAL
    };
};

export const saveChanges = (callback) => {
    return (dispatch, getState) => {
        const clients = getState().clientManagement.clientDetails.clients;
        if (clients.GID === "") {
            clients.GID = null;
        }

        if (clients.BrokerID !== 0 && clients.BrokerID !== undefined) {
            return apiUpdateClient(clients, () => {
                callback(clients.BrokerID, clients.Company);
            }, (error) => handleApiError(dispatch, error));
        } else {
            return apiAddClient(clients, (response) => {
                callback(response.data.brokerId, clients.Company);
            }, (error) => handleApiError(dispatch, error));
        }
    };
};

export const resetPassword = (id) => {
    return (dispatch) => {
        return apiResetPassword({ mappingUserId: id, roleName: "Client", roleType: "Client" }, () => {
            dispatch(showSuccess(SUCCESSFULLY_RESET_PASSWORD));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const generateDefaultLogin = (callback) => {
    return (dispatch, getState) => {
        const clients = getState().clientManagement.clientDetails.clients;
        return apiGenerateDefaultLogin({ userName: `CLIENT${clients.BrokerID}`, mappingUserId: clients.BrokerID, roleName: "Client", type: "Client" }, (response) => {
            callback(response.data);
            dispatch(showSuccess(SUCCESSFULLY_RESET_PASSWORD));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const addNotaryLoop = (notaryLoop, callback) => {
    return dispatch => {
        return apiAddNotaryLoop(notaryLoop, () => {
            dispatch(setNotaryShowModal(false));
            callback();
        }, (error) => handleApiError(dispatch, error));
    };
};

export const deleteSecAnswers = (username) => {
    return dispatch => {
        return apiDeleteSecAnswers(username, () => {
            dispatch(setStateExistSecAnswer(false));
            dispatch(showSuccess(SUCCESSFULLY_RE_VALIDATE_AUTHENTICATION));
        }, (error) => handleApiError(dispatch, error));
    };
};