import { apiGetAgentsByBrokerId, apiGetAgent, apiAddAgent, apiUpdateAgent } from "Api/agent-api";
import { apiGetBranchesByBrokerId } from "Api/clients-api";
import { showSuccess } from "../../main-layout/actions";
import {
    SUCCESSFULLY_UPDATE_MESSAGE,
    SUCCESSFULLY_CREATED_MESSAGE
} from "Constants";

import { handleApiError } from "ErrorHandler";

export const setAgentCriteria = (criteria) => {
    return {
        type: "AGENT_SET_CRITERIA",
        criteria
    };
};

export const setBranches = (branches) => {
    return {
        type: "AGENT_SET_BRANCHES",
        branches
    };
};

export const setAgent = (agent) => {
    return {
        type: "AGENT_SET_AGENT",
        agent
    };
};

export const setvalidator = (validator) => {
    return {
        type: "AGENT_SET_VALIDATOR",
        validator
    };
};

export const setUser = (user) => {
    return {
        type: "AGENT_SET_USER",
        user
    };
};

export const toggleAgentUpSertModal = (isShowModal, agentId, agent) => {
    return {
        type: "AGENT_TOGGLE_UPSERTMODAL",
        agentId,
        agent,
        isShowModal
    };
};

export const setAgents = (agents) => {
    return {
        type: "AGENT_SET_AGENTS",
        agents
    };
};

export const startToggleAgentUpSertModal = (isShowModal, agentId, brokerId) => {
    return (dispatch) => {
        if (brokerId) {
            apiGetBranchesByBrokerId(brokerId, (branches) => {
                dispatch(setBranches(branches.data));
            });
        }
        if (agentId > 0) {
            apiGetAgent(agentId, (response) => {
                response.data.BranchID = response.data.BrokerId;
                dispatch(toggleAgentUpSertModal(isShowModal, agentId, response.data));
            }, (error) => handleApiError(dispatch, error));
        } else {
            dispatch(toggleAgentUpSertModal(isShowModal, 0, {
                TenantId: 1,
                Ext: "",
                Fax: "",
                Email: "",
                AfterhoursPhone: "",
                Inactive: false,
                BranchID: 0,
                Direct: "",
                ViewAll: null,
                BrokerId: brokerId,
                FullName: ""
            }));
            dispatch(setUser({
                Username: "",
                Password: "",
                ConfirmPassword: ""
            }));
            dispatch(setvalidator({}));
        }
    };
};

export const startSetAgents = () => {
    return (dispatch, getState) => {
        apiGetAgentsByBrokerId(getState().clientManagement.agent.criteria, (response) => {
            dispatch(setAgents(response.data));
        }, error => handleApiError(dispatch, error));
    };
};

export const updateAgent = (brokerId) => {
    return (dispatch, getState) => {
        const agent = getState().clientManagement.agent.agent;
        if (agent.BrokerId && agent.BrokerId.toString() === "0") {
            agent.BrokerId = brokerId;
        }
        apiUpdateAgent(agent, () => {
            dispatch(showSuccess(SUCCESSFULLY_UPDATE_MESSAGE));
            dispatch(startSetAgents());
        }, (error) => handleApiError(dispatch, error));
    };
};

export const addAgent = (brokerId) => {
    return (dispatch, getState) => {
        const agent = getState().clientManagement.agent.agent;
        if (agent.BrokerId && agent.BrokerId.toString() === "0") {
            agent.BrokerId = brokerId;
        }
        apiAddAgent(agent, getState().clientManagement.agent.user, () => {
            dispatch(showSuccess(SUCCESSFULLY_CREATED_MESSAGE));
            dispatch(startSetAgents());
        }, (error) => handleApiError(dispatch, error));
    };
};

