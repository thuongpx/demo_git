import { apiUpdateClientSpecifics, apiUploadLendorSpecifics, apiGetClientSpecifics } from "Api/client-detail-api";
import { showSuccess } from "../../main-layout/actions";
import { SUCCESSFULLY_SAVED_MESSAGE } from "../../../constant/constants";
import { handleApiError } from "ErrorHandler";
import { showError } from "../../main-layout/actions";

export const GET_CLIENT_SPECIFICS_RECEIVE = "GET_CLIENT_SPECIFICS_RECEIVE";
export const GET_CLIENT_SPECIFICS_REQUEST = "GET_CLIENT_SPECIFICS_REQUEST";
export const UPDATE_CLIENT_SPECIFICS_RECEIVE = "UPDATE_CLIENT_SPECIFICS_RECEIVE";
export const UPDATE_CLIENT_SPECIFICS_REQUEST = "UPDATE_CLIENT_SPECIFICS_REQUEST";

//1_store data: response from db
export const receiveGetSpecifics = (specifics) => {
    return {
        type: GET_CLIENT_SPECIFICS_RECEIVE,
        isFetching: false,
        specifics
    };
};
//1_store data: show loading
export const requestGetSpecifics = () => {
    return {
        type: GET_CLIENT_SPECIFICS_REQUEST,
        isFetching: true
    };
};
//1_dispatch show loading to redux
//1_call api to retrive data then_dispatch new data response to redux
export const getSpecifics = (brokerId, tenantId) => {
    return (dispatch) => {
        dispatch(requestGetSpecifics());
        return apiGetClientSpecifics(brokerId, tenantId, (reponse) => {
            dispatch(receiveGetSpecifics(reponse.data));
        });
    };
};

//2_store data: response from db
export const receiveUpdateSpecifics = (specifics) => {
    return {
        type: UPDATE_CLIENT_SPECIFICS_RECEIVE,
        isFetching: false,
        specifics
    };
};

//2_store data: show loading
export const requestUpdateSpecifics = () => {
    return {
        type: UPDATE_CLIENT_SPECIFICS_REQUEST,
        isFetching: true
    };
};

//2_dispatch show loading to redux
//2_call api to retrive data then_dispatch new data response to redux
export const updateSpecifics = (specifics, status) => {
    return (dispatch) => {
        dispatch(requestUpdateSpecifics());
        return apiUpdateClientSpecifics(specifics, () => {
            dispatch(getSpecifics(specifics.BrokerId, 1));
            if (status === false) {
                dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
            }
        }, (error) => handleApiError(dispatch, error));
    };
};

// Save document
export const saveDocumentFile = (data, callback) => {
    return (dispatch) => {
        const file = new FormData();
        file.append("document", data.documentFile);
        if (data.documentFile.size > 20971520) {
            dispatch(showError("Document is too big. Max size: 20 MB"));
        }

        for (const key in data) {
            file.append(key, data[key]);
        }

        return apiUploadLendorSpecifics(file, (response) => {
            callback(response.data);
        }, (error) => handleApiError(dispatch, error));

    };
};
