import { apiGetRecentOrders } from "Api/client-detail-api";

export const RECENT_ORDER_SET_CRITERIA = "RECENT_ORDER_SET_CRITERIA";
export const RECENT_ORDER_SET_GRID = "RECENT_ORDER_SET_GRID";

export const setRecentOrdersCriteria = (criteria) => {
    return {
        type: RECENT_ORDER_SET_CRITERIA,
        criteria
    };
};

export const setRecentOrders = (recentOrders) => {
    return {
        type: RECENT_ORDER_SET_GRID,
        recentOrders
    };
};

export const startSetRecentOrders = () => {
    return (dispatch, getState) => {
        apiGetRecentOrders(getState().clientManagement.recentOrders.criteria, (response) => {
            dispatch(setRecentOrders(response.data));
        });
    };
};
