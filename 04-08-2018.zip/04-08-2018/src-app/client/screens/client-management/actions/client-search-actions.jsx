import { apiGetClients, apiGetClientManagement, apiChangeStatusClient } from "Api/clients-api";
import { handleApiError } from "ErrorHandler";

export const CLIENTS_SEARCH_RECEIVE = "CLIENTS_SEARCH_RECEIVE";
export const LIST_CLIENT_MANAGEMENT = "LIST_CLIENT_MANAGEMENT";
export const STATUS_CLIENT_RECEIVE = "STATUS_CLIENT_RECEIVE";
export const EDIT_CLIENT_RECEIVE = "EDIT_CLIENT_RECEIVE";
export const CLIENTS_SET_FILTER = "CLIENTS_SET_FILTER";

export const setClientFilter = (filter) => {
    return {
        type: CLIENTS_SET_FILTER,
        filter
    };
};

export const receiveChangStatusClient = (isSuccess) => {
    return {
        type: STATUS_CLIENT_RECEIVE,
        isSuccess
    };
};

export const receiveEditClient = (isSuccess) => {
    return {
        type: EDIT_CLIENT_RECEIVE,
        isSuccess
    };
};

export const receiveClients = (listClients) => {
    return {
        type: CLIENTS_SEARCH_RECEIVE,
        listClients
    };
};

export const receiveListClients = (listClients, listStates) => {
    return {
        type: LIST_CLIENT_MANAGEMENT,
        listClients,
        listStates
    };
};

export const searchClients = (filter) => {
    return (dispatch) => {
        dispatch(setClientFilter(filter));

        return apiGetClients(filter, (response) => {
            response.data.listClient.clients.map((item, key) => {
                if (item.Inactive) {
                    response.data.listClient.clients[key].Inactive = response.data.listClient.clients[key].Inactive.data[0] === 1 ? 1 : 0;
                } else response.data.listClient.clients[key].Inactive = false;
            });

            dispatch(receiveClients(response.data.listClient));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const getClientManagement = (filter) => {
    return (dispatch) => {
        dispatch(setClientFilter(filter));

        return apiGetClientManagement(filter, (response) => {
            response.data.listClient.clients.map((item, key) => {
                if (item.Inactive) {
                    response.data.listClient.clients[key].Inactive = response.data.listClient.clients[key].Inactive.data[0] === 1 ? 1 : 0;
                } else response.data.listClient.clients[key].Inactive = false;
            });

            dispatch(receiveListClients(response.data.listClient, response.data.listState));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const changeStatusClient = (brokerID, callback) => {
    return dispatch => {
        return apiChangeStatusClient(brokerID, (response) => {

            dispatch(receiveChangStatusClient(response.data));
            callback(true);
        }, (error) => handleApiError(dispatch, error));
    };
};