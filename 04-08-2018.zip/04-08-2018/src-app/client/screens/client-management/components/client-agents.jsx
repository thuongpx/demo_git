import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import GridView from "GridView";
import AgentUpSertModal from "./client-agent-upsert-modal";
import { startSetAgents, setAgentCriteria, startToggleAgentUpSertModal } from "../actions/client-agent-actions";
import CommonModal from "CommonModal";
import { apiDeactivateAgent } from "Api/agent-api";
import { showError, showSuccess } from "../../main-layout/actions";

export class ClientAgents extends Component {
    constructor(props) {
        super(props);
    }

    getAgents(brokerId) {
        this.props.dispatch(setAgentCriteria({
            ...this.props.criteria,
            brokerId
        }));
        this.props.dispatch(startSetAgents());
    }

    componentWillMount() {
        this.getAgents(this.props.brokerId);
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.brokerId !== this.props.brokerId) {
            this.getAgents(nextProps.brokerId);
        }
    }

    //Reload datasource by criteria here
    handleGridViewReload(criteria) {
        this.props.dispatch(setAgentCriteria({ brokerId: this.props.criteria.brokerId, ...criteria }));
        this.props.dispatch(startSetAgents());
    }

    handleGridViewActionClick(action, identifier) {
        switch (action) {
            case "update":
                this.props.dispatch(startToggleAgentUpSertModal(true, identifier, this.props.brokerId));
                break;
        }
    }

    handleInactiveCheckboxChanged(id, value) {
        this.commonModal.showModal({
            type: "confirm",
            message: `Are you sure you would like to ${value ? "deactivate" : "activate"} this Agent?`
        }, () => {
            apiDeactivateAgent({ agentId: id, inActive: value }, () => {
                this.props.dispatch(startSetAgents());
                if (value) {
                    this.props.dispatch(showSuccess("Deactivated Successfully"));
                } else {
                    this.props.dispatch(showSuccess("Activated Successfully"));
                }
            }, error => this.props.dispatch(showError(error.message)));
        });
    }

    render() {

        const { dispatch, columns, agents, criteria, brokerId } = this.props;

        return (
            <div className="row">
                <div className="right">
                    <button type="button" className="btn success-color action-btn" onClick={() => {
                        dispatch(startToggleAgentUpSertModal(true, 0, this.props.brokerId));
                    }}
                    >Add Agent</button>
                </div>
                <div className="col s12 m12">
                    <GridView
                        criteria={criteria}
                        totalRecords={agents.totalRecords}
                        datasources={agents.data} //Pass datasources
                        columns={columns} //Pass columns array
                        identifier={"AgentId"} //Identifier for grid row
                        onGridViewReload={this.handleGridViewReload.bind(this)} //Paginate changed => need reload datasource base on criteria
                        onActionClick={this.handleGridViewActionClick.bind(this)} //Handle actions
                        onCheckboxClick={(id, value) => { this.handleInactiveCheckboxChanged(id, value); }}
                    />
                    <AgentUpSertModal brokerId={brokerId} />
                    <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
                </div>
            </div>)
            ;
    }
}

ClientAgents.propTypes = {
    columns: PropTypes.array
};

ClientAgents.defaultProps = {
    columns: [
        {
            title: "AgentId",
            data: "AgentId"
        },
        {
            title: "Full Name",
            data: "FullName",
            type: "link",
            action: "update"
        },
        {
            title: "Phone #",
            data: "Direct",
            type: "phone"
        },
        {
            title: "Phone Ext",
            data: "Ext"
        },
        {
            title: "Fax #",
            data: "Fax",
            type: "phone"
        },
        {
            title: "Email",
            data: "Email"
        },
        {
            title: "After Hours Phone #",
            data: "AfterhoursPhone",
            type: "phone"
        },
        {
            title: "Inactive",
            data: "InActive",
            type: "checkboxChange"
        }
    ]
};

ClientAgents.propTypes = {
    dispatch: PropTypes.func,
    agents: PropTypes.object,
    criteria: PropTypes.object,
    columns: PropTypes.array,
    brokerId: PropTypes.string
};

export default connect(
    (state) => {
        return {
            agents: state.clientManagement.agent.datasources,
            criteria: state.clientManagement.agent.criteria
        };
    }
)(ClientAgents);