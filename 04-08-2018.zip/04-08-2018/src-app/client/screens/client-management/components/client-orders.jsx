import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { apiGetClientOrderByClientId } from "Api/clients-api";
import moment from "moment";
import { updateTextFields } from "../../../helpers/theme-helper";

export class ClientOrders extends Component {

    constructor(props) {
        super(props);
        this.state = {
            orders: {},
            brokerId: this.props.brokerId
        };
    }

    getClientOrder(brokerId) {
        apiGetClientOrderByClientId(brokerId, (response) => {
            this.setState({ orders: response.data });
        });
    }

    componentWillMount() {
        this.getClientOrder(this.state.brokerId);
    }

    componentDidUpdate() {
        updateTextFields();
    }

    componentWillReceiveProps(props) {
        this.getClientOrder(props.brokerId);
    }

    render() {
        return (
            <div>
                <div className="row" style={{ marginBottom: "auto" }}>
                    <div className="col s6">
                        <div className="row">
                            <div className="col s3">
                                <p style={{ textAlign: "right" }}>First Contact Date</p>
                            </div>
                            <div className="col s8">
                                <input
                                    value={this.state.orders.firstContactDate ? moment(this.state.orders.firstContactDate).format("MM/DD/YYYY").toString() : ""}
                                    id="firstContactDate"
                                    type="text"
                                    className="validate"
                                    style={{ textAlign: "right" }}
                                    disabled
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col s6">
                        <p>This date is updated when a comment is entered</p>
                    </div>
                </div>
                <div className="row">
                    <div className="col s6">
                        <div className="row">
                            <div className="col s3">
                                <p style={{ textAlign: "right" }}>Last Contact Date</p>
                            </div>
                            <div className="col s8">
                                <input
                                    value={this.state.orders.lastContactDate ? moment(this.state.orders.lastContactDate).format("MM/DD/YYYY").toString() : ""}
                                    id="lastContactDate"
                                    type="text"
                                    className="validate"
                                    style={{ textAlign: "right" }}
                                    disabled
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col s6">
                        <p>This date is updated when a comment is entered</p>
                    </div>
                </div>
                <div className="row" style={{ marginBottom: "auto" }}>
                    <div className="col s6">
                        <div className="row">
                            <div className="col s3">
                                <p style={{ textAlign: "right" }}>First Order Date</p>
                            </div>
                            <div className="col s8">
                                <input
                                    value={this.state.orders.firstOrderDate ? moment(this.state.orders.firstOrderDate).format("MM/DD/YYYY").toString() : ""}
                                    id="firstOrderDate"
                                    type="text"
                                    className="validate"
                                    style={{ textAlign: "right" }}
                                    disabled
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col s6">
                        <div className="row">
                            <div className="col s3">
                                <p style={{ textAlign: "right" }}>Last Order Date</p>
                            </div>
                            <div className="col s8">
                                <input
                                    value={this.state.orders.lastOrderDate ? moment(this.state.orders.lastOrderDate).format("MM/DD/YYYY").toString() : ""}
                                    id="lastOrderDate"
                                    type="text"
                                    className="validate"
                                    style={{ textAlign: "right" }}
                                    disabled
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row" style={{ marginBottom: "auto" }}>
                    <div className="col s6">
                        <div className="row">
                            <div className="col s3">
                                <p style={{ textAlign: "right" }}>YTD Orders</p>
                            </div>
                            <div className="col s8">
                                <input
                                    value={this.state.orders.ytdOrders}
                                    id="yTDOrders"
                                    type="text"
                                    className="validate"
                                    style={{ textAlign: "right" }}
                                    disabled
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col s6">
                        <p>These numbers are updated nightly</p>
                    </div>
                </div>
                <div className="row" style={{ marginBottom: "auto" }}>
                    <div className="col s6">
                        <div className="row">
                            <div className="col s3">
                                <p style={{ textAlign: "right" }}>MTD Orders</p>
                            </div>
                            <div className="col s8">
                                <input
                                    value={this.state.orders.mtdOrders}
                                    id="mTDOrders"
                                    type="text"
                                    className="validate"
                                    style={{ textAlign: "right" }}
                                    disabled
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col s6">
                        <p>These numbers are updated nightly</p>
                    </div>
                </div>
                <div className="row">
                    <div className="col s6">
                        <div className="row">
                            <div className="col s3">
                                <p style={{ textAlign: "right" }}>Total Orders</p>
                            </div>
                            <div className="col s8">
                                <input
                                    value={this.state.orders.totalOrders}
                                    id="totalOrders"
                                    type="text"
                                    className="validate"
                                    style={{ textAlign: "right" }}
                                    disabled
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col s6">
                        <p>These numbers are updated nightly</p>
                    </div>
                </div>
            </div >
        );
    }
}

ClientOrders.propTypes = {
    dispatch: PropTypes.func,
    brokerId: PropTypes.string
};

export default ClientOrders;