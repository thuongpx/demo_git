import React from "react";
import PropTypes from "prop-types";
import { handleApiError } from "ErrorHandler";
import { Component } from "react";
import { connect } from "react-redux";
import InputMask from "react-input-mask";
import { getClientById, setUserName, setClientState, saveChanges, setClientValidator, resetPassword, generateDefaultLogin, setNotaryShowModal, deleteSecAnswers, updateRawDataClient } from "../actions/client-details-actions";
import { changeStatusClient } from "../actions/client-search-actions";
import { validateEmail, validateComboboxRequired, requireComboBoxMessage, validateRequired, validatePhone, requireMessage, invalidMessage, validateZip } from "Helpers/validation-helper";
import NotaryLoop from "./client-notary-loop-modal";
import { getStateCodeAndCityFromZip } from "Helpers/location-helper";
import CommonModal from "CommonModal";
import { showSuccess } from "../../main-layout/actions";
import { SUCCESSFULLY_SAVED_MESSAGE } from "Constants";
import { API_URL } from "Config/config";
import { updateTextFields } from "../../../helpers/theme-helper";
import { convertToPhoneNumber } from "Helpers/common-helper";

import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import { INPUT_ERROR_1X_IMAGE_URL } from "ImageConfig";
import { axiosDownload } from "../../../helpers/axios-helper";
import moment from "moment";
import { loginAsAnotherUser } from "../../authentication/actions";
import { hasStringValue } from "../../../helpers/common-helper";
import Select from "../../../features/form/select";
import { createAccount } from "../../../api/account-api";
import { gpwd } from "../../../helpers/crypto-helper";

export class ClientDetails extends Component {
    constructor(props) {
        super(props);

        this.listIndustrySort = [];
    }

    isAddMode() {
        if (Number(this.props.brokerId) === 0 || this.props.brokerId === undefined) {
            return true;
        } else {
            return false;
        }
    }
    isEnableButton() {
        if ((this.props.roleNames === null || this.props.roleNames === undefined)) {
            return false;
        } else {
            const checkRole = this.props.roleNames.some(item => item.toLowerCase().indexOf("admin") !== -1 || item.toLowerCase().indexOf("manager") !== -1);
            if (checkRole) return true;
            return false;
        }
    }
    componentDidMount() {
        const { dispatch } = this.props;
        const self = this;
        dispatch(getClientById(this.props.brokerId, (clientName) => {
            if (Number(this.props.brokerId) !== 0) {
                self.props.onClientNameUpdated(this.props.brokerId, clientName);
            }
            if ($("#lenderSpecifics").length > 0) {
                //eslint-disable-next-line
                M.textareaAutoResize($("#lenderSpecifics"));
            }
        }));
    }

    componentDidUpdate() {
        updateTextFields();
        const groupOptionId = this.industrySelect.getSelectOptionsId();
        for (let i = 0; i < this.listIndustrySort.length; i++) {
            const industry = this.listIndustrySort[i];
            if (hasStringValue(industry.parentId) && Number(industry.parentId) > 0) {
                $(`#${groupOptionId}${i + 1}>span`).css({ paddingLeft: "3em" });
            }
        }
    }

    handleNotaryLoopPopup() {
        const { dispatch } = this.props;
        dispatch(setNotaryShowModal(true));
    }

    handleReValidateAuthentication() {
        const { dispatch } = this.props;
        dispatch(deleteSecAnswers(this.props.username));
    }

    handleClientStatusReport() {
        const downLoadUrl = `${API_URL}/client/getClientStatusReport?clientId=${this.props.clients.BrokerID}`;
        axiosDownload(downLoadUrl, {}, `ReportStatus-${moment().format("YYYYMMDDHHmmss")}.pdf`).catch((error) => handleApiError(this.props.dispatch, error));
    }

    saveChanges(isChangeTab, callBack) {
        if (this.validateForm()) {
            const self = this;
            const { dispatch } = this.props;
            dispatch(saveChanges((brokerId, clientName) => {
                clientName = `${clientName} - ${brokerId}`;
                if (this.isAddMode()) {
                    dispatch(setClientState({ ...this.props.clients, BrokerID: brokerId }));
                    const generateUsername = `CLIENT${brokerId}`;
                    const generatePass = gpwd();
                    createAccount({
                        username: generateUsername,
                        password: generatePass,
                        mappingUserId: brokerId,
                        roleId: 5
                    }, () => { }, err => handleApiError(dispatch, err));
                } else if (!this.props.inAddMode) {
                    this.props.sendMailChangeInfo(this.props.rawDataBeforeUpdate, this.props.clients);
                }
                dispatch(updateRawDataClient());
                if (!isChangeTab) {
                    dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
                }
                if (callBack) {
                    callBack();
                }
                self.props.onClientNameUpdated(brokerId, clientName);
            }));
        }
    }

    handleResetPassword() {
        const { dispatch } = this.props;
        dispatch(resetPassword(this.props.brokerId));
    }

    generateDefaultLogin() {
        const { dispatch } = this.props;
        dispatch(generateDefaultLogin((result) => {
            dispatch(setUserName({ username: result.username }));
        }));
    }

    handleShowConfirm(identifier) {
        const { dispatch, clients, isExistOrderOpen } = this.props;
        if (clients.Inactive) {
            dispatch(changeStatusClient(identifier, () => {
                dispatch(setClientState({ ...clients, Inactive: !clients.Inactive }));
                dispatch(showSuccess("Activated Successfully"));
            }));
        } else {
            this.commonModal.showModal({
                type: "confirm",
                message: isExistOrderOpen ? `This Client is associated to open order(s). Are you sure you would like to deactivate this client?
                Deactivate this client means all its associated branches and agents will be disabled as well.` : "Deactivate this client means all its associated branches and agents will be disabled as well. Would you like to continue?"
            }, () => {
                const self = this;
                dispatch(changeStatusClient(identifier, () => {
                    dispatch(setClientState({ ...clients, Inactive: !clients.Inactive }));
                    setTimeout(() => {
                        self.props.onBackClientSearch();
                    }, 1000);

                    dispatch(showSuccess("Deactivated Successfully"));
                }));
            });
        }
    }

    handleValidatePhone() {
        const { dispatch } = this.props;
        const isRequirePhoneField = this.handleValidatePhoneRequired();
        const isPhoneFormatInvalid = this.handleValidatePhoneFormat();
        dispatch(setClientValidator({ ...this.props.validator, isRequirePhoneField, isPhoneFormatInvalid }));
    }

    handleValidatePhoneRequired() {
        const { dispatch } = this.props;
        const isRequirePhoneField = !validateRequired(this.refs.phone.value);
        dispatch(setClientValidator({ ...this.props.validator, isRequirePhoneField }));
        return isRequirePhoneField;
    }

    handleValidatePhoneFormat() {
        const { dispatch } = this.props;
        const isPhoneFormatInvalid = !validatePhone(this.refs.phone.value);
        dispatch(setClientValidator({ ...this.props.validator, isPhoneFormatInvalid }));
        return isPhoneFormatInvalid;
    }

    handleValidateName() {
        const { dispatch } = this.props;
        const isRequireNameField = !validateRequired(this.refs.name.value);
        dispatch(setClientValidator({ ...this.props.validator, isRequireNameField }));
        return isRequireNameField;
    }

    handleValidateAddress() {
        const { dispatch } = this.props;
        const isRequireAddressField = !validateRequired(this.refs.address.value);
        dispatch(setClientValidator({ ...this.props.validator, isRequireAddressField }));
        return isRequireAddressField;
    }

    handleValidateCity() {
        const { dispatch } = this.props;
        const isRequireCityField = !validateRequired(this.refs.city.value);
        dispatch(setClientValidator({ ...this.props.validator, isRequireCityField }));
        return isRequireCityField;
    }

    handleValidateZip() {
        const { dispatch, clients } = this.props;
        const isRequireZipField = this.handleValidateZipRequired();
        const isZipFormatInvalid = this.handleValidateZipFormat();
        dispatch(setClientValidator({ ...this.props.validator, isRequireZipField, isZipFormatInvalid }));
        if (!isZipFormatInvalid) {

            getStateCodeAndCityFromZip(this.refs.zip.value, (zipString) => {
                if ((clients.State !== undefined && clients.State !== "" && clients.State !== zipString.state) || (this.refs.city.value.trim() !== "" && this.refs.city.value.trim() !== zipString.city)) {
                    const zipNotMatchMess = (
                        `The City and/or State do not match the Zip Code Entered.
                        Do you mean the signing address as follows?
                        [${zipString.city}, ${zipString.state}]
                        If yes, click Yes to use that suggested address.
                        If no, please click No to re-enter the correct address.`
                    );
                    if (clients.State === "" && this.refs.city.value === zipString.city) {
                        dispatch(setClientState({ ...this.props.clients, State: zipString.state }));
                    } else if (this.refs.city.value === "" && this.refs.state.value === zipString.state) {
                        dispatch(setClientState({ ...this.props.clients, City: zipString.city }));
                    } else {
                        this.commonModal.showModal({ type: "warning", message: zipNotMatchMess }, () => {
                            dispatch(setClientState({ ...this.props.clients, State: zipString.state, City: zipString.city }));
                        });
                    }
                    this.handleValidateCity();
                    this.handleValidateStateRequired();
                } else {
                    dispatch(setClientState({ ...this.props.clients, State: zipString.state, City: zipString.city }));

                }
                this.handleValidateCity();
                this.handleValidateStateRequired();
            });
        }
    }

    handleValidateZipRequired() {
        const { dispatch } = this.props;
        const isRequireZipField = !validateRequired(this.refs.zip.value);
        dispatch(setClientValidator({ ...this.props.validator, isRequireZipField }));
        return isRequireZipField;
    }

    handleValidateZipFormat() {
        const { dispatch } = this.props;
        const isZipFormatInvalid = !validateZip(this.refs.zip.value);
        dispatch(setClientValidator({ ...this.props.validator, isZipFormatInvalid }));
        return isZipFormatInvalid;
    }

    handleValidateEmail() {
        const { dispatch } = this.props;
        const isRequirePrimaryEmailField = this.handleValidateEmailRequired();
        const isEmailFormatInvalid = !validateEmail(this.refs.primaryEmail.value);
        dispatch(setClientValidator({ ...this.props.validator, isRequirePrimaryEmailField, isEmailFormatInvalid }));
    }

    handleValidateEmailRequired() {
        const { dispatch } = this.props;
        const isRequirePrimaryEmailField = !validateRequired(this.refs.primaryEmail.value);
        dispatch(setClientValidator({ ...this.props.validator, isRequirePrimaryEmailField }));
        return isRequirePrimaryEmailField;
    }

    handleValidateEmailFormat() {
        const { dispatch } = this.props;
        const isEmailFormatInvalid = !validateEmail(this.refs.primaryEmail.value);
        dispatch(setClientValidator({ ...this.props.validator, isEmailFormatInvalid }));
        return isEmailFormatInvalid;
    }

    handleValidateCCEmailFormat() {
        const { dispatch } = this.props;
        const isCCEmailFormatInvalid = !validateEmail(this.refs.ccEmail.value);
        dispatch(setClientValidator({ ...this.props.validator, isCCEmailFormatInvalid }));
        return isCCEmailFormatInvalid;
    }

    handleValidateInvoiceEmailFormat() {
        const { dispatch } = this.props;
        const isInvoiceEmailFormatInvalid = !validateEmail(this.refs.invoiceOnlyEmail.value);
        dispatch(setClientValidator({ ...this.props.validator, isInvoiceEmailFormatInvalid }));
        return isInvoiceEmailFormatInvalid;
    }

    handleValidateStateRequired() {
        const { dispatch, clients } = this.props;
        const isRequireStateField = !validateComboboxRequired(clients.State);
        dispatch(setClientValidator({ ...this.props.validator, isRequireStateField }));
        return isRequireStateField;
    }

    handleValidateIndustryRequired() {
        const { dispatch, clients } = this.props;

        const isRequireIndustryField = !validateComboboxRequired(clients.industryId);
        dispatch(setClientValidator({ ...this.props.validator, isRequireIndustryField }));
        return isRequireIndustryField;
    }

    handleValidatePaymentTerms() {
        const { dispatch, clients } = this.props;

        const isPaymentRequired = !validateComboboxRequired(clients.ApTermsFullService);
        dispatch(setClientValidator({ ...this.props.validator, isPaymentRequired }));
        return isPaymentRequired;
    }


    validateForm() {
        const { dispatch } = this.props;
        const isPhoneFormatInvalid = this.handleValidatePhoneFormat();
        const isRequireNameField = this.handleValidateName();
        const isRequireAddressField = this.handleValidateAddress();
        const isRequirePhoneField = this.handleValidatePhoneRequired();
        const isRequireCityField = this.handleValidateCity();
        const isRequirePrimaryEmailField = this.handleValidateEmailRequired();
        const isRequireZipField = this.handleValidateZipRequired();
        const isZipFormatInvalid = this.handleValidateZipFormat();
        const isEmailFormatInvalid = this.handleValidateEmailFormat();
        const isCCEmailFormatInvalid = this.handleValidateCCEmailFormat();
        const isInvoiceEmailFormatInvalid = this.handleValidateInvoiceEmailFormat();
        const isRequireStateField = this.handleValidateStateRequired();
        const isRequireIndustryField = this.handleValidateIndustryRequired();
        const isPaymentRequired = this.handleValidatePaymentTerms();

        const validator = {
            isPhoneFormatInvalid,
            isRequireNameField,
            isRequireAddressField,
            isRequirePhoneField,
            isRequireCityField,
            isRequirePrimaryEmailField,
            isRequireZipField,
            isZipFormatInvalid,
            isEmailFormatInvalid,
            isCCEmailFormatInvalid,
            isInvoiceEmailFormatInvalid,
            isRequireStateField,
            isRequireIndustryField,
            isPaymentRequired
        };
        dispatch(setClientValidator(validator));
        for (const key in validator) {
            if (validator[key]) {
                return false;
            }
        }

        return true;
    }

    handleClientView() {
        const { dispatch } = this.props;
        dispatch(loginAsAnotherUser(this.props.userId, this.props.router, this.props.clients.BrokerID));
    }

    render() {
        const { validator, clients, listClients, listCourier, listStates, listEmployees, listSalesRep, listIndustry, dispatch, isExistSecAnswer, paymentTermSource } = this.props;

        const renderSalesRepCommission = listSalesRep.map((item, key) => {
            if (clients.SalesRepId !== null && clients.SalesRepId !== undefined) {
                if (item.SalesRepId.toString() === clients.SalesRepId.toString()) {
                    const commissionPercent = item.CommissionPercent ? `${item.CommissionPercent}%` : "";
                    const commissionAmount = item.CommissionAmount ? `$${item.CommissionAmount}` : "";
                    let commission = "";
                    if (commissionPercent !== "" && commissionAmount !== "") {
                        commission = `${commissionPercent} or ${commissionAmount}`;
                    } else if (commissionPercent !== "") {
                        commission = commissionPercent;
                    } else if (commissionAmount !== "") {
                        commission = commissionAmount;
                    }
                    return (
                        <div key={key} className="col s12">
                            <span ref="salesRepCommission" id={key} >{commission}</span>
                        </div>
                    );
                }
            }
            return "";
        });

        const sortListIndustry = () => {
            const listParent = listIndustry.filter(item => !hasStringValue(item.parentId) || Number(item.parentId) === 0);
            const listChildrent = listIndustry.filter(item => hasStringValue(item.parentId) && Number(item.parentId) > 0);
            let returnList = [];
            listParent.forEach(item => {
                returnList.push(item);
                const findChild = listChildrent.filter(child => Number(child.parentId) === Number(item.industryId));
                returnList = returnList.concat(findChild);
            });

            this.listIndustrySort = returnList;
            return returnList;
        };

        const renderButtonResetPassword = () => {
            if (!this.isAddMode()) {
                return (
                    <div className="col s12 m6" style={{ marginTop: "5px" }}>
                        <button className="btn btn-small success-color w-100" onClick={this.handleResetPassword.bind(this)} disabled={clients.Inactive}>Reset Password</button>
                    </div>
                );
            }
            return "";
        };

        const renderButtonReValidateAuthentication = () => {
            if (!this.isAddMode()) {
                return (
                    <div className={`col s12 m6 ${!isExistSecAnswer ? "hidden" : ""}`} style={{ marginTop: "5px" }}>
                        <button className={`btn btn-small success-color w-100`} disabled={clients.Inactive} onClick={() => this.handleReValidateAuthentication()}>Re-Validate Authentication</button>
                    </div>
                );
            }
            return "";
        };

        const renderButtonClientView = () => {
            if (!this.isAddMode()) {
                return (
                    <div className="col s12 m6" style={{ marginTop: "5px" }}>
                        <button className="btn btn-small success-color w-100" disabled={!this.isEnableButton()} onClick={() => this.handleClientView()}>Client View</button>
                    </div>
                );
            }
            return "";
        };

        const renderButtonInActiveClient = () => {
            if (!this.isAddMode()) {
                return (
                    <div className="col s12 m6" style={{ marginTop: "5px" }}>
                        <button className="btn btn-small error-color w-100" onClick={() => this.handleShowConfirm(clients.BrokerID)}>{clients.Inactive ? "Activate this Client" : "Deactivate  this Client"}</button>
                    </div>
                );
            }
            return "";
        };

        return (
            <div>
                <div className="row">
                    <div className="col s12 m6">
                        <div className="row">
                            <div className="col s12 m12">
                                <label htmlFor="" className="font-12 bold-6 primary-color">
                                    <strong>Main Information</strong>
                                </label>
                            </div>
                        </div>
                        <div className="row">
                            <div className={`input-field col s12 m6 suffixinput select-input required ${validator.isRequireIndustryField ? "required-field" : ""}`}>
                                <Select
                                    dataSource={sortListIndustry()}
                                    mapDataToRenderOptions={{ value: "industryId", label: "description" }}
                                    onChange={(industryId) => dispatch(setClientState({ ...clients, industryId }))}
                                    onBlur={this.handleValidateIndustryRequired.bind(this)}
                                    ref="industry"
                                    id="industry"
                                    style={{ marginLeft: "2em" }}
                                    value={clients.industryId || ""}
                                    optionDefaultLabel="Select Industry"
                                    ref={instance => { this.industrySelect = instance; }}
                                />
                                <label htmlFor="industry">Industry</label>
                                {validator.isRequireIndustryField && <span className={`suffix-text`}><img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireComboBoxMessage("Industry")} /></span>}
                            </div>
                            <div className={`input-field col s12 m6 suffixinput required ${validator.isRequireNameField ? "required-field" : ""}`}>
                                <input id="name" maxLength="50" type="text" ref="name" className="validate" value={clients.Company || ""} onChange={() => dispatch(setClientState({ ...clients, Company: this.refs.name.value }))} onBlur={this.handleValidateName.bind(this)} />
                                <label htmlFor="name">Name</label>
                                {validator.isRequireNameField && <span className={`suffix-text`}><img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Name")} /></span>}
                            </div>
                        </div>
                        <div className="row">
                            <div className="input-field col s12 m6 suffixinput select-input">
                                <Select
                                    dataSource={listClients}
                                    mapDataToRenderOptions={{ value: "BrokerID", label: "Company" }}
                                    onChange={(GID) => dispatch(setClientState({ ...clients, GID }))}
                                    ref="branchOf"
                                    id="branchOf"
                                    value={clients.GID || ""}
                                    optionDefaultLabel="Select Client"
                                />
                                <label htmlFor="branchOf">Branch of</label>
                            </div>
                            <div className="input-field col s12 m6">
                                <label htmlFor="clientBranchID" className="active">Client/Branch ID</label>
                                <input id="clientBranchID" ref="clientBranchID" value={clients.BrokerID || ""} className="bold-6" readOnly />
                            </div>
                        </div>

                        <div className="row">
                            <div className="col s12 m12">
                                <label htmlFor="" className="font-12 bold-6 primary-color">
                                    <strong>Address Information</strong>
                                </label>
                            </div>
                        </div>

                        <div className="row">
                            <div className={`input-field col s12 m6 suffixinput required ${validator.isRequireAddressField ? "required-field" : ""}`}>
                                <input id="address" maxLength="50" type="text" ref="address" className="validate" value={clients.Address || ""} onChange={() => dispatch(setClientState({ ...clients, Address: this.refs.address.value }))} onBlur={this.handleValidateAddress.bind(this)} />
                                <label htmlFor="address">Address</label>
                                {validator.isRequireAddressField && <span className={`suffix-text`}><img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Address")} /></span>}
                            </div>

                            <div className="input-field col s12 m6">
                                <input id="suite" maxLength="50" type="text" ref="suite" className="validate" value={clients.Suite || ""} onChange={() => dispatch(setClientState({ ...clients, Suite: this.refs.suite.value }))} />
                                <label htmlFor="suite">Suite</label>
                            </div>
                        </div>
                        <div className="row">
                            <div className={`input-field col s12 m4 suffixinput required ${validator.isRequireZipField ? "required-field" : ""} ${validator.isZipFormatInvalid ? "has-error" : ""}`}>
                                <InputMask id="zip" type="text" ref="zip" className="validate" value={clients.Zip || ""} onChange={() => dispatch(setClientState({ ...clients, Zip: this.refs.zip.value }))} mask="99999" onBlur={this.handleValidateZip.bind(this)} />
                                <label htmlFor="zip">Zip</label>
                                {validator.isRequireZipField && <span className={`suffix-text`}><img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Zip")} /></span>}
                                {validator.isZipFormatInvalid && <span className={`suffix-text`}><img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Zip")} /></span>}
                            </div>

                            <div className="col s12 m4">
                                <div className={`input-field suffixinput required ${validator.isRequireStateField ? "required-field" : ""}`}>
                                    <Select
                                        dataSource={listStates}
                                        mapDataToRenderOptions={{ value: "Code", label: "Code" }}
                                        value={clients.State || ""}
                                        onChange={(State) => dispatch(setClientState({ ...clients, State }))}
                                        onBlur={this.handleValidateStateRequired.bind(this)}
                                        ref="state"
                                        id="state"
                                        value={clients.State || ""}
                                        optionDefaultLabel="Select State"
                                    />
                                    <label htmlFor="state">State</label>
                                    {validator.isRequireStateField && <span className={`suffix-text`}><img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireComboBoxMessage("State")} /></span>}
                                </div>
                            </div>

                            <div className={`input-field col s12 m4 suffixinput required ${validator.isRequireCityField ? "required-field" : ""}`}>
                                <input id="city" maxLength="20" type="text" ref="city" className="validate" value={clients.City || ""} onChange={() => dispatch(setClientState({ ...clients, City: this.refs.city.value }))} onBlur={this.handleValidateCity.bind(this)} />
                                <label htmlFor="city">City</label>
                                {validator.isRequireCityField && <span className={`suffix-text`}><img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("City")} /></span>}
                            </div>
                        </div>
                        <div className="row">
                            <div className="input-field col s12 m4">
                                <Select
                                    dataSource={listCourier}
                                    mapDataToRenderOptions={{ value: "CourierID", label: "Courier" }}
                                    onChange={(value) => dispatch(setClientState({ ...clients, DefaultCourierID: value === "" ? null : value }))}
                                    ref="courier"
                                    id="courier"
                                    value={clients.DefaultCourierID || null}
                                    optionDefaultLabel="Select Courier"
                                />
                                <label htmlFor="courier">Courier</label>
                            </div>
                            <div className="input-field col s12 m4">
                                <input id="accountNumber" maxLength="30" type="text" ref="accountNumber" className="validate" value={clients.DefaultCourierAcnt || ""} onChange={() => dispatch(setClientState({ ...clients, DefaultCourierAcnt: this.refs.accountNumber.value }))} />
                                <label htmlFor="accountNumber">Account Number</label>
                            </div>
                            <div className="input-field col s12 m4">
                                <Select
                                    dataSource={[{ code: 1, label: "Yes" }, { code: 0, label: "No" }]}
                                    mapDataToRenderOptions={{ value: "code", label: "label" }}
                                    onChange={(TermsAccept) => dispatch(setClientState({ ...clients, TermsAccept: parseInt(TermsAccept) }))}
                                    ref="termAccepted"
                                    id="termAccepted"
                                    value={clients.TermsAccept || 1}
                                />
                                <label htmlFor="termAccepted">Term Accepted</label>
                            </div>
                        </div>
                        <div className="input-field col s12 m12">
                            <textarea id="lenderSpecifics" maxLength="3000" className="materialize-textarea" ref="lenderSpecifics" value={clients.LenderSpecific || ""} onChange={() => dispatch(setClientState({ ...clients, LenderSpecific: this.refs.lenderSpecifics.value }))}></textarea>
                            <label htmlFor="lenderSpecifics">Lender Specifics</label>
                        </div>
                    </div>
                    <div className="col s12 m6">
                        <div className="row">
                            <div className="col s12 m12">
                                <label htmlFor="" className="font-12 bold-6 primary-color">
                                    <strong>Account Information</strong>
                                </label>
                            </div>
                        </div>

                        <div className="row">
                            <div className={`input-field col s12 m6 suffixinput required ${validator.isRequirePhoneField ? "required-field" : ""} ${validator.isPhoneFormatInvalid ? "has-error" : ""}`}>
                                <InputMask id="phone" type="text" ref="phone" className="validate" value={clients.Phone || ""} onChange={() => dispatch(setClientState({ ...clients, Phone: convertToPhoneNumber(this.refs.phone.value) }))} mask="(999) 999-9999" onBlur={this.handleValidatePhone.bind(this)} />
                                <label htmlFor="phone">Phone</label>
                                {validator.isRequirePhoneField && <span className={`suffix-text`}><img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Phone")} /></span>}
                                {validator.isPhoneFormatInvalid && <span className={`suffix-text`}><img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Phone")} /></span>}
                            </div>

                            <div className={`input-field col s12 m6 suffixinput required ${validator.isRequirePrimaryEmailField ? "required-field" : ""} ${validator.isEmailFormatInvalid ? "has-error" : ""}`}>
                                <input id="primaryEmail" maxLength="70" type="text" ref="primaryEmail" className="validate" value={clients.Email || ""} onChange={() => dispatch(setClientState({ ...clients, Email: this.refs.primaryEmail.value }))} onBlur={this.handleValidateEmail.bind(this)} />
                                <label htmlFor="primaryEmail">Primary Email</label>
                                {validator.isRequirePrimaryEmailField && <span className={`suffix-text`}><img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Primary Email")} /></span>}
                                {validator.isEmailFormatInvalid && <span className={`suffix-text`}><img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Primary Email")} /></span>}
                            </div>
                        </div>

                        <div className="row">
                            <div className={`input-field col s12 m6 suffixinput ${validator.isInvoiceEmailFormatInvalid ? "has-error" : ""}`}>
                                <input id="invoiceOnlyEmail" type="text" ref="invoiceOnlyEmail" className="validate" value={clients.InvoiceOnly || ""} onChange={() => dispatch(setClientState({ ...clients, InvoiceOnly: this.refs.invoiceOnlyEmail.value }))} onBlur={this.handleValidateInvoiceEmailFormat.bind(this)} />
                                <label htmlFor="invoiceOnlyEmail">Invoice Only Email</label>
                                {validator.isInvoiceEmailFormatInvalid && <span className={`suffix-text`}><img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Invoice Only Email")} /></span>}
                            </div>

                            <div className={`input-field col s12 m6 suffixinput ${validator.isCCEmailFormatInvalid ? "has-error" : ""}`}>
                                <input id="ccEmail" maxLength="200" type="text" ref="ccEmail" className="validate" value={clients.Ccemail || ""} onChange={() => dispatch(setClientState({ ...clients, Ccemail: this.refs.ccEmail.value }))} onBlur={this.handleValidateCCEmailFormat.bind(this)} />
                                <label htmlFor="ccEmail">CC Email</label>
                                {validator.isCCEmailFormatInvalid && <span className={`suffix-text`}><img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("CC Email")} /></span>}
                            </div>
                        </div>

                        <div className="row">
                            <div className={`input-field col s12 m6 suffixinput select-input required ${validator.isPaymentRequired ? "required-field" : ""}`}>
                                <Select
                                    dataSource={paymentTermSource}
                                    mapDataToRenderOptions={{ value: "value", label: "label" }}
                                    onChange={(apTermsFullService) => dispatch(setClientState({ ...clients, ApTermsFullService: apTermsFullService }))}
                                    onBlur={() => this.handleValidatePaymentTerms()}
                                    ref="payment"
                                    id="payment"
                                    value={clients.ApTermsFullService || ""}
                                    optionDefaultLabel="Select Payment Terms"
                                    ref={instance => { this.paymentSelect = instance; }}
                                />
                                <label htmlFor="payment">Payment Terms</label>
                                {validator.isPaymentRequired && <span className={`suffix-text`}><img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireComboBoxMessage("Payment Terms")} /></span>}
                            </div>
                            <div className="input-field col s12 m6">
                                <label>
                                    <input
                                        type="checkbox" defaultChecked ref="invoiceGeneration"
                                        checked={clients.IsIncludeSpreadsheetFullService || false}
                                        onChange={(e) => dispatch(setClientState({ ...clients, IsIncludeSpreadsheetFullService: e.target.checked }))}
                                    />
                                    <span>Include spreadsheet when generating invoice</span>
                                </label>
                            </div>
                        </div>

                        <div className="row">
                            <div className="col s12 m12">
                                <label htmlFor="" className="font-12 bold-6 primary-color">
                                    <strong>TCE Information</strong>
                                </label>
                            </div>
                        </div>

                        <div className="row">
                            <div className="input-field col s12 m6">
                                <Select
                                    dataSource={listEmployees}
                                    mapDataToRenderOptions={{ value: "RepId", label: "Employees" }}
                                    onChange={(RepId) => dispatch(setClientState({ ...clients, RepId: RepId === "" ? null : RepId }))}
                                    ref="repId"
                                    id="repId"
                                    value={clients.RepId || ""}
                                    optionDefaultLabel="Select TCE Sales Rep"
                                />
                                <label htmlFor="repId">TCE Sales Rep</label>
                            </div>
                        </div>
                        <div className="row">
                            <div className="input-field col s12 m6">
                                <Select
                                    dataSource={listSalesRep}
                                    mapDataToRenderOptions={{ value: "SalesRepId", label: "SalesRep" }}
                                    onChange={(SalesRepId) => dispatch(setClientState({ ...clients, SalesRepId: SalesRepId === "" ? null : SalesRepId }))}
                                    ref="salesRep"
                                    id="salesRep"
                                    value={clients.SalesRepId || ""}
                                    optionDefaultLabel="Select Sales Rep"
                                />
                                <label htmlFor="salesRep">Sales Rep</label>
                            </div>

                            <div className="col s12 m6">
                                <label className="active">Sales Rep Commission</label>
                                {renderSalesRepCommission}
                            </div>
                        </div>

                        <div className="row">
                            <div className="col s12 m12">
                                {!this.isAddMode() && <label htmlFor="">
                                    <span ref="websiteUsername" ><strong className="font-12 bold-6 primary-color">Website Username </strong> <strong className="font-15 bold-6">{this.props.username || ""}</strong> </span>
                                </label>}
                            </div>
                        </div>

                        <div className="row">
                            {renderButtonResetPassword()}
                            {renderButtonClientView()}
                            <div className="clearfix"></div>
                            {renderButtonReValidateAuthentication()}
                            <div className="col s12 m12 l6" style={{ marginTop: "5px" }}>
                                <button className="btn btn-small success-color w-100" style={{ display: this.isAddMode() ? "none" : "block" }} onClick={() => this.handleClientStatusReport()}>Client Report Status</button>
                            </div>
                            <div className="clearfix"></div>
                            {renderButtonInActiveClient()}
                            <div className="col s12 m12 l6" style={{ marginTop: "5px" }}>
                                <button className="btn btn-small success-color w-100" style={{ display: this.isAddMode() ? "none" : "block" }} onClick={this.handleNotaryLoopPopup.bind(this)}>Notary Loop</button>
                            </div>
                        </div>
                    </div>
                    <NotaryLoop />
                    <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
                </div>
            </div >
        );
    }
}

ClientDetails.defaultProps = {
    paymentTermSource: [
        {
            value: "Per file",
            label: "Per file"
        },
        {
            value: "Weekly",
            label: "Weekly"
        },
        {
            value: "Bi-weekly",
            label: "Bi-weekly"
        },
        {
            value: "Monthly",
            label: "Monthly"
        }
    ]
};

ClientDetails.propTypes = {
    router: PropTypes.object,
    dispatch: PropTypes.func.isRequired,
    clients: PropTypes.object,
    listClients: PropTypes.array,
    listStates: PropTypes.array,
    listCourier: PropTypes.array,
    listEmployees: PropTypes.array,
    listSalesRep: PropTypes.array,
    listIndustry: PropTypes.array,
    brokerId: PropTypes.string,
    clientName: PropTypes.string,
    validator: PropTypes.object,
    username: PropTypes.string,
    isExistOrderOpen: PropTypes.bool,
    isExistSecAnswer: PropTypes.bool,
    roleNames: PropTypes.array,
    userId: PropTypes.number,
    sendMailChangeInfo: PropTypes.func,
    rawDataBeforeUpdate: PropTypes.object,
    inAddMode: PropTypes.bool,
    paymentTermSource: PropTypes.array
};


const mapStateToProps = (state) => {
    const { clients, rawDataBeforeUpdate, listClients, listStates, listIndustry, listCourier, listEmployees, listSalesRep, validator, username, isExistOrderOpen, isExistSecAnswer, userId } = state.clientManagement.clientDetails;
    const { authentication } = state;
    const { role } = authentication;
    const { roleNames } = role;

    return {
        clients,
        listClients,
        listStates,
        listCourier,
        listEmployees,
        listSalesRep,
        validator,
        username,
        isExistOrderOpen,
        isExistSecAnswer,
        roleNames,
        userId,
        listIndustry,
        rawDataBeforeUpdate
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(ClientDetails);