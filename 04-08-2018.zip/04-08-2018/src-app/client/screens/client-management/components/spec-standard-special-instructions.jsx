import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { updateTextFields } from "../../../helpers/theme-helper";

class StandardSpecs extends Component {
    componentDidUpdate() {
        updateTextFields();
    }

    handleInputChange(obj) {
        const { onInputChange } = this.props;

        onInputChange(obj);
    }

    render() {
        const { dataSource } = this.props;

        return (
            <div>
                <div className="row">
                    <strong className="col">Standard special instruction?</strong>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <label htmlFor="SpecialInstruction1">Instruction #1</label>
                        <input className="validate" type="text" value={dataSource.SpecialInstruction1}
                            ref="SpecialInstruction1" id="SpecialInstruction1"
                            onChange={() => this.handleInputChange({ SpecialInstruction1: this.refs.SpecialInstruction1.value })}
                        />
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <label htmlFor="SpecialInstruction2">Instruction #2</label>
                        <input className="validate" type="text" value={dataSource.SpecialInstruction2}
                            ref="SpecialInstruction2" id="SpecialInstruction2"
                            onChange={() => this.handleInputChange({ SpecialInstruction2: this.refs.SpecialInstruction2.value })}
                        />
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <label htmlFor="SpecialInstruction3">Instruction #3</label>
                        <input className="validate" type="text" value={dataSource.SpecialInstruction3}
                            ref="SpecialInstruction3" id="SpecialInstruction3"
                            onChange={() => this.handleInputChange({ SpecialInstruction3: this.refs.SpecialInstruction3.value })}
                        />
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <label htmlFor="SpecialInstruction4">Instruction #4</label>
                        <input className="validate" type="text" value={dataSource.SpecialInstruction4}
                            ref="SpecialInstruction4" id="SpecialInstruction4"
                            onChange={() => this.handleInputChange({ SpecialInstruction4: this.refs.SpecialInstruction4.value })}
                        />
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <label htmlFor="SpecialInstruction5">Instruction #5</label>
                        <input className="validate" type="text" value={dataSource.SpecialInstruction5}
                            ref="SpecialInstruction5" id="SpecialInstruction5"
                            onChange={() => this.handleInputChange({ SpecialInstruction5: this.refs.SpecialInstruction5.value })}
                        />
                    </div>
                </div>
                {(dataSource.SpecialInstruction6 || dataSource.SpecialInstruction5) ?
                    <div className="row">
                        <div className="input-field col s12">
                            <label htmlFor="SpecialInstruction6">Instruction #6</label>
                            <input className="validate" type="text" value={dataSource.SpecialInstruction6}
                                ref="SpecialInstruction6" id="SpecialInstruction6"
                                onChange={() => this.handleInputChange({ SpecialInstruction6: this.refs.SpecialInstruction6.value })}
                            />
                        </div>
                    </div>
                    : null}
                {(dataSource.SpecialInstruction7 || dataSource.SpecialInstruction6) ?
                    <div className="row">
                        <div className="input-field col s12">
                            <label htmlFor="SpecialInstruction7">Instruction #7</label>
                            <input className="validate" type="text" value={dataSource.SpecialInstruction7}
                                ref="SpecialInstruction7" id="SpecialInstruction7"
                                onChange={() => this.handleInputChange({ SpecialInstruction7: this.refs.SpecialInstruction7.value })}
                            />
                        </div>
                    </div>
                    : null}
                {(dataSource.SpecialInstruction8 || dataSource.SpecialInstruction7) ?
                    <div className="row">
                        <div className="input-field col s12">
                            <label htmlFor="SpecialInstruction8">Instruction #8</label>
                            <input className="validate" type="text" value={dataSource.SpecialInstruction8}
                                ref="SpecialInstruction8" id="SpecialInstruction8"
                                onChange={() => this.handleInputChange({ SpecialInstruction8: this.refs.SpecialInstruction8.value })}
                            />
                        </div>
                    </div>
                    : null}
                {(dataSource.SpecialInstruction9 || dataSource.SpecialInstruction8) ?
                    <div className="row">
                        <div className="input-field col s12">
                            <label htmlFor="SpecialInstruction9">Instruction #9</label>
                            <input className="validate" type="text" value={dataSource.SpecialInstruction9}
                                ref="SpecialInstruction9" id="SpecialInstruction9"
                                onChange={() => this.handleInputChange({ SpecialInstruction9: this.refs.SpecialInstruction9.value })}
                            />
                        </div>
                    </div>
                    : null}
                {(dataSource.SpecialInstruction10 || dataSource.SpecialInstruction9) ?
                    <div className="row">
                        <div className="input-field col s12">
                            <label htmlFor="SpecialInstruction10">Instruction #10</label>
                            <input className="validate" type="text" value={dataSource.SpecialInstruction10}
                                ref="SpecialInstruction10" id="SpecialInstruction10"
                                onChange={() => this.handleInputChange({ SpecialInstruction10: this.refs.SpecialInstruction10.value })}
                            />
                        </div>
                    </div>
                    : null}
                <div className="mt-2 col m12" style={{ height: "20px" }}></div>
                <div className="row">
                    <div className="input-field col s12">
                        <div className="row">
                            <div className="col s4 m4 l2">
                                <p>Updated by</p>
                            </div>
                            <div className="col s8 m8 l10">
                                <input disabled className="validate" type="text" value={dataSource.Completedby}
                                    ref="Completedby" id="Completedby"
                                    style={{ textAlign: "right" }}
                                    onChange={() => this.handleInputChange({ Completedby: this.refs.Completedby.value })}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <div className="row">
                            <div className="col s4 m4 l2">
                                <p>Date Updated</p>
                            </div>
                            <div className="col s8 m8 l10">
                                <input disabled className="form-control" type="text" value={dataSource.DateCompleted}
                                    ref="DateCompleted" id="DateCompleted"
                                    style={{ textAlign: "right" }}
                                    onChange={() => this.handleInputChange({ DateCompleted: this.refs.DateCompleted.value })}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="mt-2 col m12" style={{ height: "20px" }}></div>
            </div>
        );
    }
}

StandardSpecs.propTypes = {
    disabled: PropTypes.bool,
    dataSource: PropTypes.object,
    onInputChange: PropTypes.func
};

export default StandardSpecs;