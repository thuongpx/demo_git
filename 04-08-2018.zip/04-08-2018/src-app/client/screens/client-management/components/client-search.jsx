import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { searchClients, getClientManagement, changeStatusClient, setClientFilter } from "../actions/client-search-actions";
import GridView from "GridView";
import CommonModal from "CommonModal";
import NumbericInput from "NumbericInput";
import Select from "Select";
import { apiCheckExistOrderOpenByBrokerId } from "Api/orders-api";
import { updateTextFields } from "../../../helpers/theme-helper";
import { showSuccess } from "../../main-layout/actions";
import { APP_URL } from "Config/config";
import { openNewTab } from "../../../helpers/common-helper";

class ClientSearch extends Component {

    handleSearchClick() {
        const { dispatch, filter } = this.props;
        dispatch(setClientFilter({ ...filter, page: 1 }));
        dispatch(searchClients({ ...filter, page: 1 }));
    }

    handleGridViewReload(criteria) {
        const { dispatch } = this.props;
        const filter = {
            ...this.props.filter,
            ...criteria
        };
        dispatch(searchClients(filter));
    }

    handleReset(e) {
        e.preventDefault();
        const { dispatch } = this.props;
        const filter = {
            ...this.props.filter,
            clientID: "",
            page: 1,
            clientName: "",
            address: "",
            city: "",
            state: "",
            inactive: false
        };
        dispatch(setClientFilter(filter));
        dispatch(searchClients(filter));
    }

    handleShowConfirm(identifier) {
        const { dispatch, listClients, filter } = this.props;
        let inactive = false;

        listClients.clients.map((item, key) => {
            if (listClients.clients[key].BrokerID === identifier && item.Inactive === 0) {
                inactive = true;
            }
        });
        apiCheckExistOrderOpenByBrokerId(identifier, (result) => {
            const messageActive = "Are you sure you would like to activate this Client?";
            const messageInactive = result.data ? `This Client is associated to open order(s). Are you sure you would like to deactivate this client?
                  Deactivate this client means all its associated branches and agents will be disabled as well.` : "Deactivate this client means all its associated branches and agents will be deactivated as well. Would you like to continue?";
            this.commonModal.showModal({
                type: "confirm",
                message: inactive ? messageInactive : messageActive
            }, () => {
                dispatch(changeStatusClient(identifier, () => {
                    dispatch(searchClients(filter));
                    dispatch(showSuccess(inactive ? "Deactivated Successfully" : "Activated Successfully"));
                }));
            });
        });
    }

    handleGridViewActionClick(action, identifier) {
        switch (action) {
            case "edit":
                openNewTab(`${APP_URL}/client-detail/${identifier}`);
                break;
            case "changeStatus":
                this.handleShowConfirm(identifier);
                break;
        }
    }

    handleAddClient(e) {
        e.preventDefault();
        openNewTab(`${APP_URL}/client-detail/0`);
    }

    componentDidMount() {
        const { dispatch } = this.props;
        const filter = {
            ...this.props.filter,
            clientID: "",
            clientName: "",
            address: "",
            city: "",
            state: "",
            inactive: false
        };
        $(`#clientID`).focus();
        dispatch(getClientManagement(filter));
    }

    componentDidUpdate() {
        updateTextFields();
        //setTimeout(() => {
        //$(`#clientID`).focus();
        //}, 2000);
    }

    handleClientIDChanged(value) {
        const { dispatch } = this.props;
        dispatch(setClientFilter({ ...this.props.filter, clientID: value }));
    }

    render() {
        const { listClients, states, filter, columns, dispatch } = this.props;

        return (
            <div className="place-section">
                <div className="row">
                    <div className="col m12">
                        <h3 className="title-page-detail">Client Management</h3>
                    </div>
                </div>
                <div className="wrap-search-form">
                    <div className="row">
                        <div className="input-field col s12 m4">
                            <NumbericInput id="clientID" value={filter.clientID} ref="clientID" maxValue={2147483647} className="validate" onChange={this.handleClientIDChanged.bind(this)} />
                            <label htmlFor="clientID">Client/Branch ID</label>
                        </div>

                        <div className="input-field col s12 m4">
                            <input id="clientName" type="text" value={filter.clientName} ref="clientName" className="validate" onChange={() => dispatch(setClientFilter({ ...filter, clientName: this.refs.clientName.value }))} maxLength={50} />
                            <label htmlFor="clientName">Company/Branch Name</label>
                        </div>

                        <div className="input-field col s12 m4">
                            <Select
                                dataSource={[{ Code: false, Description: "Active" }, { Code: true, Description: "Inactive" }]}
                                mapDataToRenderOptions={{ value: "Code", label: "Description" }}
                                id="active"
                                className="validate"
                                value={filter.inactive}
                                onChange={(inactive) => dispatch(setClientFilter({ ...filter, inactive }))}
                                optionDefaultLabel="All"
                            />
                            <label htmlFor="active">Client</label>
                        </div>

                    </div>
                    <div className="row">

                        <div className="input-field col s12 m4">
                            <input id="address" type="text" value={filter.address} ref="address" className="validate" onChange={() => dispatch(setClientFilter({ ...filter, address: this.refs.address.value }))} maxLength={100} />
                            <label htmlFor="address">Address</label>
                        </div>

                        <div className="input-field col s8 m4">
                            <input id="city" type="text" value={filter.city} ref="city" className="validate" onChange={() => dispatch(setClientFilter({ ...filter, city: this.refs.city.value }))} maxLength={50} />
                            <label htmlFor="city">City</label>
                        </div>

                        <div className="input-field col s4 m4">
                            <Select
                                dataSource={states}
                                mapDataToRenderOptions={{ value: "Code", label: "Code" }}
                                onChange={(state) => dispatch(setClientFilter({ ...filter, state }))}
                                id="state"
                                value={filter.state}
                                optionDefaultLabel="All"
                            />
                            <label htmlFor="state">State</label>
                        </div>
                    </div>

                    <div className="row mb-0">

                        <div className="col s12 m6">
                            <p className="left red-color">Insert criteria to search for specific client</p>
                        </div>

                        <div className="right center-btn-mobile">
                            <button type="button" className="btn btn-small reload-btn btn-primary" style={{ marginRight: "5px" }} onClick={(e) => this.handleReset(e)}>
                                <i className="lnr lnr-redo"></i>
                            </button>
                            <button onClick={(e) => this.handleSearchClick(e)} className="btn action-btn success-color" >Search</button>
                        </div>
                    </div>
                </div>

                <div className="row mb-0">
                    <div className="col s12 m6">
                        <p className="left" style={{ margin: "2.111111rem 0px" }}><strong>Search Results</strong></p>
                    </div>
                    <div className="col s12 m6">
                        <div className="right center-btn-mobile" style={{ margin: "1.5rem 0px" }}>
                            <input type="button" className="btn action-btn success-color right" value="Add Client" onClick={(e) => this.handleAddClient(e)} />
                        </div>
                    </div>
                </div>

                {/* <div className="row">
                    <div className="col s12">
                        <p>
                            <strong>Search Results</strong>
                        </p>
                    </div>
                </div> */}

                <div className="row">
                    <div className="wrap-result-search">
                        <GridView
                            criteria={filter}
                            totalRecords={listClients ? listClients.totalRecords : []}
                            datasources={listClients ? listClients.clients : []}
                            columns={columns}
                            identifier={"BrokerID"}
                            onGridViewReload={(e) => this.handleGridViewReload(e)}
                            onActionClick={this.handleGridViewActionClick.bind(this)}
                        />
                    </div>
                </div>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div >
        );
    }
}

ClientSearch.defaultProps = {
    columns: [
        {
            title: "#",
            data: "RowNumber"
        },
        {
            title: "Client/Branch ID",
            data: "BrokerID"
        },
        {
            title: "Company/Branch Name",
            data: "Company"
        },
        {
            title: "Address",
            data: "Address"
        },
        {
            title: "City",
            data: "City"
        },
        {
            title: "State",
            data: "State"
        },
        {
            title: "Action",
            type: "client-action"
        }
    ]
};

ClientSearch.propTypes = {
    router: PropTypes.object,
    dispatch: PropTypes.func.isRequired,
    listClients: PropTypes.object,
    states: PropTypes.array,
    filter: PropTypes.object,
    columns: PropTypes.array
};

const mapStateToProps = (state) => {
    const { listClients, states, filter } = state.clientManagement.clientSearch;
    return {
        listClients,
        states,
        filter
    };
};

export default connect(mapStateToProps)(ClientSearch);