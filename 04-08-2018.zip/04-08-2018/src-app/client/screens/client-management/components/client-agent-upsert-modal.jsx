import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Modal, ModalBody, ModalFooter, ModalTitle } from "Modal";
import {
    startToggleAgentUpSertModal, updateAgent, addAgent, setUser, setAgent
    , setvalidator
} from "../actions/client-agent-actions";

import InputMask from "react-input-mask";
import NumbericInput from "NumbericInput";
import { validateEmail, validateRequired, validatePhone, validateCompare, validatePassword, requireMessage, invalidMessage, existingUsernameMessage, invalidPasswordMessage, comparePasswordMessage } from "Helpers/validation-helper";

import { convertToPhoneNumber } from "Helpers/common-helper";

import { apiCheckExistUser, apiResetPassword } from "Api/user-api";

import PasswordPopover from "PasswordPopover";
import { showSuccess } from "../../main-layout/actions";
import { SUCCESSFULLY_RESET_PASSWORD } from "Constants";
import CommonModal from "CommonModal";
import { updateTextFields } from "../../../helpers/theme-helper";

import { INPUT_ERROR_1X_IMAGE_URL, INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import { handleApiError } from "ErrorHandler";
import Select from "Select";

export class ClientAgentUpSertModal extends Component {

    componentDidUpdate() {
        updateTextFields();
    }

    handleFirstNameChanged() {
        const { dispatch } = this.props;
        dispatch(setAgent({
            ...this.props.agent,
            FirstName: this.refs.agentFirstName.value,
            FullName: `${this.refs.agentFirstName.value} ${this.refs.agentLastName.value}`
        }));
    }

    handleLastNameChanged() {
        const { dispatch } = this.props;
        dispatch(setAgent({
            ...this.props.agent,
            LastName: this.refs.agentLastName.value,
            FullName: `${this.refs.agentFirstName.value} ${this.refs.agentLastName.value}`
        }));
    }

    handleValidateFirstName() {
        const { dispatch } = this.props;
        const isFirstNameRequiredInvalid = !validateRequired(this.refs.agentFirstName.value);
        dispatch(setvalidator({
            ...this.props.validator, isFirstNameRequiredInvalid
        }));
        return isFirstNameRequiredInvalid;
    }

    handleValidateLastName() {
        const { dispatch } = this.props;
        const isLastNameRequiredInvalid = !validateRequired(this.refs.agentLastName.value);
        dispatch(setvalidator({
            ...this.props.validator, isLastNameRequiredInvalid
        }));
        return isLastNameRequiredInvalid;
    }

    handleEmailChanged() {
        const { dispatch } = this.props;
        dispatch(setAgent({ ...this.props.agent, Email: this.refs.email.value }));
    }

    handlePhoneChanged() {
        const { dispatch } = this.props;
        dispatch(setAgent({ ...this.props.agent, Direct: convertToPhoneNumber(this.refs.direct.value) }));
    }

    handleExtChanged(value) {
        const { dispatch } = this.props;
        dispatch(setAgent({ ...this.props.agent, Ext: value }));
    }

    handleFaxChanged() {
        const { dispatch } = this.props;
        dispatch(setAgent({ ...this.props.agent, Fax: convertToPhoneNumber(this.refs.fax.value) }));
    }

    handleBranchChanged(value) {
        const { dispatch, brokerId } = this.props;
        if (value === undefined || value === "") {
            dispatch(setAgent({ ...this.props.agent, BrokerId: brokerId }));
        } else {
            dispatch(setAgent({ ...this.props.agent, BrokerId: value }));
        }
    }

    handleAfterhoursPhoneChanged() {
        const { dispatch } = this.props;
        dispatch(setAgent({ ...this.props.agent, AfterhoursPhone: convertToPhoneNumber(this.refs.afterhoursPhone.value) }));
    }

    handleViewAllChanged() {
        const { dispatch } = this.props;
        dispatch(setAgent({ ...this.props.agent, ViewAll: !this.props.agent.ViewAll }));
    }

    handleNeedResetPasswordChanged() {
        const { dispatch } = this.props;
        dispatch(setAgent({ ...this.props.agent, NeedResetPassword: !this.props.agent.NeedResetPassword }));
    }

    handleUsernameChanged() {
        const { dispatch } = this.props;
        dispatch(setUser({ ...this.props.user, Username: this.refs.username.value }));
    }

    handlePasswordChanged() {
        const { dispatch } = this.props;
        dispatch(setUser({ ...this.props.user, Password: this.refs.password.value }));
    }

    handleConfirmPasswordChanged() {
        const { dispatch } = this.props;
        dispatch(setUser({ ...this.props.user, ConfirmPassword: this.refs.confirmPassword.value }));
    }

    handleValidateEmail() {
        const { dispatch } = this.props;
        const isEmailFormatInvalid = this.validateEmailFormat();
        const isEmailRequiredInvalid = this.validateEmailRequired();
        dispatch(setvalidator({ ...this.props.validator, isEmailFormatInvalid, isEmailRequiredInvalid }));
    }

    validateEmailFormat() {
        const isEmailFormatInvalid = !validateEmail(this.refs.email.value);
        return isEmailFormatInvalid;
    }

    validateEmailRequired() {
        const isEmailRequiredInvalid = !validateRequired(this.refs.email.value);
        return isEmailRequiredInvalid;
    }

    handleValidatePhone() {
        const { dispatch } = this.props;
        const isPhoneFormatInvalid = !validatePhone(this.refs.direct.value);
        dispatch(setvalidator({ ...this.props.validator, isPhoneFormatInvalid }));
        return isPhoneFormatInvalid;
    }

    handleValidateFax() {
        const { dispatch } = this.props;
        const isFaxFormatInvalid = !validatePhone(this.refs.fax.value);
        dispatch(setvalidator({ ...this.props.validator, isFaxFormatInvalid }));
        return isFaxFormatInvalid;
    }

    handleValidateAfterhoursPhone() {
        const { dispatch } = this.props;
        const isAfterhoursPhoneFormatInvalid = !validatePhone(this.refs.afterhoursPhone.value);
        dispatch(setvalidator({ ...this.props.validator, isAfterhoursPhoneFormatInvalid }));
        return isAfterhoursPhoneFormatInvalid;
    }

    handleValidateUsername() {
        const { dispatch } = this.props;
        const isUsernameRequiredInvalid = this.validateUsernameRequired();
        let isUsernameExistInvalid = false;
        if (!isUsernameRequiredInvalid) {
            apiCheckExistUser(this.refs.username.value, (response) => {
                isUsernameExistInvalid = response.data.isExist;
                dispatch(setvalidator({ ...this.props.validator, isUsernameExistInvalid, isUsernameRequiredInvalid }));
            });
        } else {
            dispatch(setvalidator({ ...this.props.validator, isUsernameRequiredInvalid, isUsernameExistInvalid }));
        }

    }

    validateUsernameRequired() {
        const isUsernameRequiredInvalid = !validateRequired(this.refs.username.value);
        return isUsernameRequiredInvalid;
    }

    handleValidatePassword() {
        const { dispatch } = this.props;
        const isPasswordFormatInvalid = this.validatePasswordFormat();
        const isPasswordRequiredInvalid = this.validatePasswordRequired();
        dispatch(setvalidator({ ...this.props.validator, isPasswordFormatInvalid, isPasswordRequiredInvalid }));
    }

    validatePasswordFormat() {
        const isPasswordFormatInvalid = !validatePassword(this.refs.password.value);
        return isPasswordFormatInvalid;
    }

    validatePasswordRequired() {
        const isPasswordRequiredInvalid = !validateRequired(this.refs.password.value);
        return isPasswordRequiredInvalid;
    }

    handleValidateConfirmPassword() {
        const { dispatch } = this.props;
        const isConfirmPasswordCompareInvalid = this.validateConfirmPasswordCompare();
        const isConfirmPasswordRequiredInvalid = this.validateConfirmPasswordRequired();
        dispatch(setvalidator({ ...this.props.validator, isConfirmPasswordRequiredInvalid, isConfirmPasswordCompareInvalid }));
    }

    validateConfirmPasswordRequired() {
        const isConfirmPasswordRequiredInvalid = !validateRequired(this.refs.confirmPassword.value);
        return isConfirmPasswordRequiredInvalid;
    }

    validateConfirmPasswordCompare() {
        const isConfirmPasswordCompareInvalid = !validateCompare(this.refs.password.value, this.refs.confirmPassword.value);
        return isConfirmPasswordCompareInvalid;
    }

    validateForm() {

        const { dispatch, agentId } = this.props;
        const isEmailFormatInvalid = this.validateEmailFormat();
        const isEmailRequiredInvalid = this.validateEmailRequired();
        const isPhoneFormatInvalid = this.handleValidatePhone();
        const isFaxFormatInvalid = this.handleValidateFax();
        const isAfterhoursPhoneFormatInvalid = this.handleValidateAfterhoursPhone();
        const isFirstNameRequiredInvalid = this.handleValidateFirstName();
        const isLastNameRequiredInvalid = this.handleValidateLastName();

        let validator = {
            isEmailFormatInvalid,
            isEmailRequiredInvalid,
            isFirstNameRequiredInvalid,
            isLastNameRequiredInvalid,
            isPhoneFormatInvalid,
            isFaxFormatInvalid,
            isAfterhoursPhoneFormatInvalid
        };

        if (agentId === 0) {

            const isUsernameRequiredInvalid = this.validateUsernameRequired();
            const isPasswordFormatInvalid = this.validatePasswordFormat();
            const isPasswordRequiredInvalid = this.validatePasswordRequired();
            const isConfirmPasswordCompareInvalid = this.validateConfirmPasswordCompare();
            const isConfirmPasswordRequiredInvalid = this.validateConfirmPasswordRequired();

            validator = {
                ...validator,
                isUsernameRequiredInvalid,
                isPasswordFormatInvalid,
                isPasswordRequiredInvalid,
                isConfirmPasswordCompareInvalid,
                isConfirmPasswordRequiredInvalid
            };
        }

        dispatch(setvalidator(validator));

        for (const key in validator) {
            if (validator[key]) {
                return false;
            }
        }

        return true;
    }

    handleSaveUpdateAgent() {
        if (this.validateForm()) {
            const { dispatch, brokerId } = this.props;
            dispatch(updateAgent(brokerId));
            dispatch(startToggleAgentUpSertModal(false, 0));
        }
    }

    handleSaveAgent(isShowModal) {
        if (this.validateForm()) {
            apiCheckExistUser(this.refs.username.value, (response) => {
                const { dispatch } = this.props;
                const isUsernameExistInvalid = response.data.isExist;
                dispatch(setvalidator({ ...this.props.validator, isUsernameExistInvalid }));
                if (!isUsernameExistInvalid) {
                    dispatch(addAgent(this.props.brokerId));
                    dispatch(startToggleAgentUpSertModal(isShowModal, 0));
                }
            });
        }
    }

    handleSaveAndKeepAgent() {
        this.handleSaveAgent(true);
    }

    handleSaveAndCloseAgent() {
        this.handleSaveAgent(false);
    }

    handleResetPassword() {
        const { dispatch, agentId } = this.props;
        apiResetPassword({ mappingUserId: agentId, roleName: "Agent", roleType: "Client" }, () => {
            dispatch(showSuccess(SUCCESSFULLY_RESET_PASSWORD));
            dispatch(startToggleAgentUpSertModal(false, 0));
        }, (error) => handleApiError(dispatch, error));
    }

    handleCloseModal() {
        const { dispatch } = this.props;
        const addingEditingText = this.props.agentId > 0 ? "editing" : "adding";
        this.commonModal.showModal({
            type: "confirm",
            message: `Are you sure you want to cancel ${addingEditingText} this agent?`
        }, () => {
            dispatch(startToggleAgentUpSertModal(false, 0));
        });
    }

    render() {
        const self = this;
        const { agent, agentId, user, validator, isOpen, branches } = this.props;

        const isUpdate = agentId > 0;

        const renderUsernamePasswordFields = () => {
            if (!isUpdate) {
                return (
                    <div>
                        <div className="row"><div className="col m12"><div className="divider mt-2" style={{ height: "1.5px" }}></div></div></div>
                        <div className="row">
                            <div className={`col m6 input-field required suffixinput ${validator.isUsernameRequiredInvalid ? "required-field" : ""} ${validator.isUsernameExistInvalid ? "has-error" : ""}`}>
                                <input id="username" maxLength="45" type="text" ref="username" value={user.Username} onChange={self.handleUsernameChanged.bind(self)} onBlur={this.handleValidateUsername.bind(this)} className="validate" />
                                <label htmlFor="username">Desired User Name</label>
                                <span className="suffix-text" style={validator.isUsernameRequiredInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Desired User Name")} />
                                </span>
                                <span className="suffix-text" style={validator.isUsernameExistInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={existingUsernameMessage("This Desired User Name")} />
                                </span>
                            </div>
                        </div>
                        <div className="row">
                            <div className={`col m6 input-field required suffixinput ${validator.isPasswordRequiredInvalid ? "required-field" : ""} ${validator.isPasswordFormatInvalid ? "has-error" : ""}`}>
                                <input id="password" maxLength="100" type="password" value={user.Password} ref="password" onChange={self.handlePasswordChanged.bind(self)} onBlur={this.handleValidatePassword.bind(this)} className="validate" />
                                <label htmlFor="password">Password</label>
                                <span className="suffix-text" style={validator.isPasswordRequiredInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Password")} />
                                </span>
                                <span className="suffix-text" style={validator.isPasswordFormatInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidPasswordMessage()} />
                                </span>
                                <PasswordPopover classNameAdded="mr-2" />
                            </div>
                            <div className={`col m6 input-field required suffixinput ${validator.isConfirmPasswordRequiredInvalid ? "required-field" : ""} ${validator.isConfirmPasswordCompareInvalid ? "has-error" : ""}`}>
                                <input id="confirmPassword" maxLength="100" type="password" value={user.ConfirmPassword} onChange={self.handleConfirmPasswordChanged.bind(self)} onBlur={this.handleValidateConfirmPassword.bind(this)} ref="confirmPassword" className="validate" />
                                <label htmlFor="confirmPassword">Verify Password</label>
                                <span className="suffix-text" style={validator.isConfirmPasswordRequiredInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Verify Password")} />
                                </span>
                                <span className="suffix-text" style={validator.isConfirmPasswordCompareInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={comparePasswordMessage("Password", "Verify Password")} />
                                </span>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col m6 inline-label">
                                <div className="inline">
                                    <label>
                                        <input type="checkbox" ref="needResetPassword" checked={agent.NeedResetPassword} onChange={this.handleNeedResetPasswordChanged.bind(this)} className="" />
                                        <span>Require agent to re-set password upon initial log-in</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                );
            } else {
                return null;
            }
        };

        const renderButtons = () => {

            if (isUpdate) {
                return (
                    <div className="row">
                        <div className="col m4 s12 l4">
                            <button className="btn white action-btn w-100" onMouseDown={() => {
                                this.handleCloseModal();
                            }}
                            >Cancel</button>
                        </div>
                        <div className="col m4 s12 l4">
                            <button className="btn success-color action-btn w-100" onMouseDown={this.handleResetPassword.bind(this)}>
                                Reset Password
                            </button>
                        </div>
                        <div className="col m4 s12 l4">
                            <button className="btn success-color action-btn w-100" onClick={self.handleSaveUpdateAgent.bind(self)}>
                                Save Changes
                            </button>
                        </div>
                    </div>
                );
            } else {
                return (
                    <div className="row">
                        <div className="col m4 s12 l4">
                            <button className="btn white action-btn w-100" onMouseDown={() => {
                                this.handleCloseModal();
                            }}
                            >Cancel</button>
                        </div>
                        <div className="col m4 s12 l4">
                            <button className="btn success-color action-btn w-100" onClick={self.handleSaveAndKeepAgent.bind(self)}>
                                Save
                            </button>
                        </div>
                        <div className="col m4 s12 l4">
                            <button className="btn success-color action-btn w-100" onClick={self.handleSaveAndCloseAgent.bind(self)}>
                                Save &amp; Close
                            </button>
                        </div>
                    </div>
                );
            }
        };

        return (
            <div>
                <Modal isOpen={isOpen} modalOptions={{
                    onOpenEnd: () => {
                        this.refs.agentFirstName.focus();
                    }
                }} addClass="no-tab"
                >
                    <ModalBody>
                        <ModalTitle onClickClose={() => { this.handleCloseModal(); }}>{isUpdate ? "Update Agent" : "Add Agent"}</ModalTitle>
                        <div className="tab-content">
                            <div className="row">
                                <div className={`input-field col s6 required suffixinput ${validator.isFirstNameRequiredInvalid ? "required-field" : ""}`}>
                                    <input type="text" maxLength="50" id="agent-first-name" ref="agentFirstName" value={agent.FirstName || ""}
                                        onChange={() => this.handleFirstNameChanged()}
                                        onBlur={() => this.handleValidateFirstName()} className="validate"
                                    />
                                    <label htmlFor="agent-first-name">First Name</label>
                                    <span className={`suffix-text ${validator.isFirstNameRequiredInvalid ? "" : "hide"}`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("First Name")} />
                                    </span>
                                </div>
                                <div className={`input-field col s6 required suffixinput ${validator.isLastNameRequiredInvalid ? "required-field" : ""}`}>
                                    <input type="text" maxLength="50" id="agent-last-name" ref="agentLastName" value={agent.LastName || ""}
                                        onChange={() => this.handleLastNameChanged()}
                                        onBlur={() => this.handleValidateLastName()} className="validate"
                                    />
                                    <label htmlFor="agent-last-name">Last Name</label>
                                    <span className={`suffix-text ${validator.isLastNameRequiredInvalid ? "" : "hide"}`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Last Name")} />
                                    </span>
                                </div>

                            </div>
                            <div className="row">
                                <div className={`col m6 input-field required suffixinput ${validator.isEmailRequiredInvalid ? "required-field" : ""} ${validator.isEmailFormatInvalid ? "has-error" : ""}`}>
                                    <input id="email" maxLength="70" type="text" ref="email" value={agent.Email} onChange={this.handleEmailChanged.bind(this)} onBlur={this.handleValidateEmail.bind(this)} className="validate" />
                                    <label htmlFor="email">Email</label>
                                    <span className="suffix-text" style={validator.isEmailRequiredInvalid ? { display: "block" } : { display: "none" }} >
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Email")} />
                                    </span>
                                    <span className="suffix-text" style={validator.isEmailFormatInvalid ? { display: "block" } : { display: "none" }} >
                                        <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Email")} />
                                    </span>
                                </div>
                                {this.props.client.GID && this.props.client.GID.toString() !== "0" ? <div className="col m6"></div> :
                                    <div className="col m6 input-field">
                                        <Select
                                            dataSource={branches}
                                            onChange={(value) => this.handleBranchChanged(value)}
                                            mapDataToRenderOptions={{ value: "brokerId", label: "company" }}
                                            id="branchID"
                                            value={agent.BrokerId}
                                            optionDefaultLabel="Select..."
                                        />
                                        <label htmlFor="branchID">Branch/Division</label>
                                    </div>
                                }
                            </div>
                            <div className="row">
                                <div className={`col m6 input-field suffixinput ${validator.isPhoneFormatInvalid ? "has-error" : ""} `}>
                                    <InputMask type="text" id="direct" className="validate" ref="direct" value={agent.Direct} onChange={this.handlePhoneChanged.bind(this)} onBlur={this.handleValidatePhone.bind(this)} mask="(999) 999-9999" />
                                    <label htmlFor="direct">Phone #</label>
                                    <span className="suffix-text" style={validator.isPhoneFormatInvalid ? { display: "block" } : { display: "none" }} >
                                        <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Phone #")} />
                                    </span>
                                </div>
                                <div className="col m6 input-field">
                                    <NumbericInput id="ext" maxLength="5" ref="ext" value={agent.Ext} className="validate" onChange={this.handleExtChanged.bind(this)} />
                                    <label htmlFor="ext">Phone Ext</label>
                                </div>
                            </div>
                            <div className="row">
                                <div className={`col m6 input-field suffixinput ${validator.isAfterhoursPhoneFormatInvalid ? "has-error" : ""} `}>
                                    <InputMask type="text" id="afterhoursPhone" className="validate" ref="afterhoursPhone" value={agent.AfterhoursPhone} onChange={this.handleAfterhoursPhoneChanged.bind(this)} onBlur={this.handleValidateAfterhoursPhone.bind(this)} mask="(999) 999-9999" />
                                    <label htmlFor="afterhoursPhone">After Hours Phone #</label>
                                    <span className="suffix-text" style={validator.isAfterhoursPhoneFormatInvalid ? { display: "block" } : { display: "none" }} >
                                        <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("After Hours Phone #")} />
                                    </span>
                                </div>
                                <div className={`col m6 input-field suffixinput ${validator.isFaxFormatInvalid ? "has-error" : ""} `}>
                                    <InputMask type="text" id="fax" className="validate" ref="fax" value={agent.Fax} onChange={this.handleFaxChanged.bind(this)} onBlur={this.handleValidateFax.bind(this)} mask="(999) 999-9999" />
                                    <label htmlFor="fax">Fax Number</label>
                                    <span className="suffix-text" style={validator.isFaxFormatInvalid ? { display: "block" } : { display: "none" }} >
                                        <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Fax Number")} />
                                    </span>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col m12 inline-label">
                                    <div className="inline">
                                        <label>
                                            <input type="checkbox" ref="viewAll" checked={agent.ViewAll} onChange={this.handleViewAllChanged.bind(this)} className="" />
                                            <span>Allow agent to view entire company order pipeline</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            {renderUsernamePasswordFields()}
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        {renderButtons()}
                    </ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

ClientAgentUpSertModal.propTypes = {
    isOpen: PropTypes.bool,
    agentId: PropTypes.number,
    agent: PropTypes.object,
    user: PropTypes.object,
    branches: PropTypes.array,
    validator: PropTypes.object,
    client: PropTypes.object,
    dispatch: PropTypes.func,
    brokerId: PropTypes.string
};

export default connect(
    (state) => {
        return {
            isOpen: state.clientManagement.agent.isShowModal,
            agentId: state.clientManagement.agent.agentId,
            agent: state.clientManagement.agent.agent,
            user: state.clientManagement.agent.user,
            branches: state.clientManagement.agent.branches,
            validator: state.clientManagement.agent.validator,
            client: state.clientManagement.clientDetails.clients
        };
    }
)(ClientAgentUpSertModal);