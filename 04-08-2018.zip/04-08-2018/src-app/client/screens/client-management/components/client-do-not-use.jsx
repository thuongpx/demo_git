import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import GridView from "GridView";
import {
    startSetDoNotUse,
    setDoNotUseCriteria,
    startSetDoNotUse2,
    setDoNotUseCriteria2,
    setDoNotUseBlackList,
    setDoNotUseWhiteList
} from "../actions/client-do-not-use-actions";
import NewCommentModal from "../../customers-management/components/customer-add-comment";
import CommonModal from "CommonModal";

// const BROKERID = 2;
export class ClientDoNotUse extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showCommentForm: false,
            moveType: ""
        };
    }
    getDoNotUse(brokerId) {
        this.props.dispatch(setDoNotUseCriteria({
            ...this.props.criteria,
            brokerId
        }));
        this.props.dispatch(startSetDoNotUse());
    }

    componentWillMount() {
        this.getDoNotUse(this.props.brokerId);
        this.getDoNotUse2(this.props.brokerId);
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.brokerId !== this.props.brokerId) {
            this.getDoNotUse(nextProps.brokerId);
            this.getDoNotUse2(nextProps.brokerId);
        }
    }
    componentDidMount() {
        this.refs.whereText.focus();
    }
    //Reload datasource by criteria here
    handleSearch() {
        this.handleGridViewReload(this.props.criteria);
    }
    handleKeyPress(e) {
        if (e.key === "Enter") {
            this.handleSearch();
        }
    }
    //Reload datasource by criteria here
    handleGridViewReload(criteria) {
        criteria = { ...criteria, ...{ whereText: this.refs.whereText.value.trim(), brokerId: this.props.brokerId } };
        this.props.dispatch(setDoNotUseCriteria(criteria));
        this.props.dispatch(startSetDoNotUse());
    }

    //Row Clicked
    handleOnRowClick(data) {
        const datasources = this.props.datasources.data;
        datasources.map(item => {
            if (item.SignerId === data.SignerId) {
                return data;
            }
            return item;
        });
        this.setState({ datasources });
    }
    getDoNotUse2(brokerId) {
        this.props.dispatch(setDoNotUseCriteria2({
            ...this.props.criteria2,
            brokerId
        }));
        this.props.dispatch(startSetDoNotUse2());
    }

    //Reload datasource by criteria here
    handleGridViewReload2(criteria2) {
        criteria2 = { ...criteria2, ...{ brokerId: this.props.brokerId } };
        this.props.dispatch(setDoNotUseCriteria2(criteria2));
        this.props.dispatch(startSetDoNotUse2());
    }

    //Row Clicked
    handleOnRowClick2(data) {
        const datasources2 = this.props.datasources2.data;
        datasources2.map(item => {
            if (item.SignerId === data.SignerId) {
                return data;
            }
            return item;
        });
        this.setState({ datasources2 });
    }
    //mote to right
    onRequestHide() {
        this.setState({ showCommentForm: false });
    }

    onSetDescription() {
        // not emplement
    }

    onSaveBlackList(description) {
        const { datasources } = this.props;
        const newBlackList = [];
        // const newWhiteList = [];
        switch (this.state.moveType) {
            case "MOVE_RIGHT":
                //Grid 1
                //1_get moveRight list
                datasources.data.forEach((item) => {
                    if (item.isSelected) {
                        const blackObj = {
                            BrokerId: item.BrokerId,
                            SignerId: item.SignerId,
                            Comment: description
                        };
                        newBlackList.push(blackObj);
                    }
                });
                this.props.dispatch(setDoNotUseBlackList(this.props.brokerId, newBlackList));
                break;
            case "MOVE_RIGHT_ALL":
                datasources.data.forEach((item) => {
                    item.isSelected = true;
                    if (item.isSelected) {
                        const blackObj = {
                            BrokerId: item.BrokerId,
                            SignerId: item.SignerId,
                            Comment: description
                        };
                        newBlackList.push(blackObj);
                    }
                });
                this.props.dispatch(setDoNotUseBlackList(this.props.brokerId, newBlackList));
                break;
        }
        this.setState({ showCommentForm: false });
    }


    onSaveWhiteList(moveType) {
        const { datasources2 } = this.props;
        const newWhiteList = [];
        switch (moveType) {
            case "MOVE_LEFT":
                datasources2.data.forEach((item) => {
                    if (item.isSelected) {
                        newWhiteList.push(item.Id);
                    }
                });
                this.props.dispatch(setDoNotUseWhiteList(this.props.brokerId, newWhiteList));
                break;
            case "MOVE_LEFT_ALL":
                datasources2.data.forEach((item) => {
                    item.isSelected = true;
                    if (item.isSelected) {
                        newWhiteList.push(item.Id);
                    }
                });
                this.props.dispatch(setDoNotUseWhiteList(this.props.brokerId, newWhiteList));
                break;
        }
    }

    handleOnMove(moveType) {
        const { datasources, datasources2 } = this.props;
        switch (moveType) {
            case "MOVE_RIGHT":
                //Grid 1
                if (datasources.data.map(x => x.isSelected).indexOf(true) > -1) {
                    //show pop up
                    this.setState({ showCommentForm: true, moveType });
                }
                break;
            case "MOVE_RIGHT_ALL":
                if (datasources.data.length > 0) {
                    this.setState({ showCommentForm: true, moveType });
                }
                break;
            case "MOVE_LEFT":
                if (datasources2.data.map(x => x.isSelected).indexOf(true) > -1) {
                    this.onSaveWhiteList("MOVE_LEFT");
                }
                break;
            case "MOVE_LEFT_ALL":
                if (datasources2.data.length > 0) {
                    this.onSaveWhiteList("MOVE_LEFT_ALL");
                }
                break;
        }
    }

    handleGridViewActionClick(action, identifier) {
        this.showSuccess(identifier);
    }

    showSuccess(message) {
        this.commonModal.showModal({ type: "infor", message });
    }
    render() {

        const { columns, datasources, criteria, columns2, datasources2, criteria2 } = this.props;

        return (
            <div className="scroll-table client-mag">
                <div className="row" style={{ display: "flex", alignItems: "center", flexWrap: "wrap" }}>
                    <div className="col m5 s12">
                        <div className="row">
                            <div className="col m12">
                                <h6>Available Vendors</h6>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col m11 s11">
                                <div className={`input-field`}>
                                    <input maxLength="50"
                                        id="whereText"
                                        type="text"
                                        ref="whereText"
                                        onKeyPress={(e) => this.handleKeyPress(e)}
                                    />
                                    <label htmlFor="whereText"> Search Vendor</label>
                                </div>
                            </div>
                            <div className="col input-field">
                                <i className="ti-search prefix" style={{ lineHeight: "unset" }} onClick={() => this.handleSearch()}></i>
                            </div>
                        </div>
                        <GridView
                            criteria={criteria}
                            totalRecords={datasources.totalRecords}
                            datasources={datasources.data} //Pass datasources
                            columns={columns} //Pass columns array
                            allowPaging={false}
                            onGridViewReload={this.handleGridViewReload.bind(this)} //Paginate changed => need reload datasource base on criteria
                            onRowClick={this.handleOnRowClick.bind(this)}
                            allowRowSelect
                        />
                    </div>
                    <div className="col m1 s12 mt-1 mb-1 form-group">
                        <button className="btn btn-small success-color mb-1 center-block" onClick={() => this.handleOnMove("MOVE_RIGHT_ALL")}><i className="ti ti-angle-double-right"></i></button>
                        <div className="clear"></div>
                        <button className="btn btn-small success-color mb-1 center-block" onClick={() => this.handleOnMove("MOVE_RIGHT")}><i className="ti ti-angle-right"></i></button>
                        <div className="clear"></div>
                        <button className="btn btn-small success-color mb-1 center-block" onClick={() => this.handleOnMove("MOVE_LEFT")}><i className="ti ti-angle-left"></i></button>
                        <div className="clear"></div>
                        <button className="btn btn-small success-color center-block" onClick={() => this.handleOnMove("MOVE_LEFT_ALL")}><i className="ti ti-angle-double-left"></i></button>
                    </div>
                    <div className="col m6 s12">
                        <div className="row">
                            <div className="col m12 s12">
                                <h6>"Do not use" Vendors</h6>
                            </div>
                        </div>
                        <GridView
                            criteria={criteria2}
                            totalRecords={datasources2.totalRecords}
                            datasources={datasources2.data} //Pass datasources
                            columns={columns2} //Pass columns array
                            allowPaging={false}
                            onGridViewReload={this.handleGridViewReload2.bind(this)} //Paginate changed => need reload datasource base on criteria
                            onRowClick={this.handleOnRowClick2.bind(this)}
                            allowRowSelect
                            identifier={"Comment"} //Identifier for grid row
                            onActionClick={this.handleGridViewActionClick.bind(this)} //Handle actions
                        />
                    </div>
                </div>
                <NewCommentModal
                    isShowModal={this.state.showCommentForm}
                    onCancelAddComment={() => this.onRequestHide()}
                    onSaveComments={(description) => this.onSaveBlackList(description)}
                    onSetDescription={() => this.onSetDescription()}
                />
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

ClientDoNotUse.defaultProps = {
    columns: [
        {
            title: "Vendor ID",
            data: "SignerId"
        },
        {
            title: "Name",
            data: "Name"
        },
        {
            title: "City, State",
            data: "CityState"
        }
    ],
    columns2: [
        {
            title: "Vendor ID",
            data: "SignerId"
        },
        {
            title: "Name",
            data: "Name"
        },
        {
            title: "City, State",
            data: "CityState"
        },
        {
            title: "Added Date",
            data: "AddedDate",
            type: "datetime"
        },
        {
            title: "Comment",
            data: "Note",
            type: "link"
        }
    ]
};

ClientDoNotUse.propTypes = {
    dispatch: PropTypes.func,
    datasources: PropTypes.object,
    criteria: PropTypes.object,
    columns: PropTypes.array,
    brokerId: PropTypes.number,
    datasources2: PropTypes.object,
    criteria2: PropTypes.object,
    columns2: PropTypes.array
};

export default connect(
    (state) => {
        return {
            datasources: state.clientManagement.doNotUse.datasources,
            criteria: state.clientManagement.doNotUse.criteria,
            datasources2: state.clientManagement.doNotUse.datasources2,
            criteria2: state.clientManagement.doNotUse.criteria2
        };
    }
)(ClientDoNotUse);