import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import NumbericInput from "NumbericInput";
import InputMask from "react-input-mask";
import { apiUpdateClientContact, apiGetClientContactByClientId } from "Api/clients-api";
import { validateEmail, validateRequired, validatePhone, requireMessage, invalidMessage } from "Helpers/validation-helper";
import { convertToPhoneNumber } from "Helpers/common-helper";
import { showSuccess } from "../../main-layout/actions";
import { SUCCESSFULLY_SAVED_MESSAGE } from "Constants";
import { connect } from "react-redux";

import { INPUT_ERROR_1X_IMAGE_URL, INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";

import { updateTextFields } from "../../../helpers/theme-helper";

import { handleApiError } from "../../../helpers/error-handler";

export class ClientContacts extends Component {

    constructor(props) {
        super(props);
        this.state = {
            contact: {
                BrokerID: this.props.brokerId
            },
            rawContact: {},
            validator: {},
            isFormDirty: false
        };
    }

    componentDidUpdate() {
        updateTextFields();
    }

    handleValidatePrimaryContactFirst() {
        const isPrimaryContactFirstInvalid = !validateRequired(this.refs.primaryContactFirst.value);
        this.setState({ validator: { ...this.state.validator, isPrimaryContactFirstInvalid } });
        return isPrimaryContactFirstInvalid;
    }

    handleValidatePrimaryContactLast() {
        const isPrimaryContactLastInvalid = !validateRequired(this.refs.primaryContactLast.value);
        this.setState({ validator: { ...this.state.validator, isPrimaryContactLastInvalid } });
        return isPrimaryContactLastInvalid;
    }

    handleValidateAdditionalContactEmail() {
        const isAdditionalContactEmailInvalid = !validateEmail(this.refs.additionalContactEmail.value);
        this.setState({ validator: { ...this.state.validator, isAdditionalContactEmailInvalid } });
        return isAdditionalContactEmailInvalid;
    }

    handleValidatePrimaryContactFax() {
        const isPrimaryContactFaxInvalid = !validatePhone(this.refs.primaryContactFax.value);
        this.setState({ validator: { ...this.state.validator, isPrimaryContactFaxInvalid } });
        return isPrimaryContactFaxInvalid;
    }

    handleValidateAdditionalContactPhone() {
        const isAdditionalContactPhoneInvalid = !validatePhone(this.refs.additionalContactPhone.value);
        this.setState({ validator: { ...this.state.validator, isAdditionalContactPhoneInvalid } });
        return isAdditionalContactPhoneInvalid;
    }

    validateForm(isCheckDirty) {

        if (isCheckDirty && !this.state.isFormDirty) {
            return true;
        }

        const isAdditionalContactEmailInvalid = this.handleValidateAdditionalContactEmail();
        const isPrimaryContactFirstInvalid = this.handleValidatePrimaryContactFirst();
        const isPrimaryContactLastInvalid = this.handleValidatePrimaryContactLast();
        const isPrimaryContactFaxInvalid = this.handleValidatePrimaryContactFax();
        const isAdditionalContactPhoneInvalid = this.handleValidateAdditionalContactPhone();

        const validator = {
            isAdditionalContactEmailInvalid,
            isPrimaryContactFirstInvalid,
            isPrimaryContactLastInvalid,
            isPrimaryContactFaxInvalid,
            isAdditionalContactPhoneInvalid
        };

        this.setState({ validator });

        for (const key in validator) {
            if (validator[key]) {
                return false;
            }
        }

        return true;
    }

    saveChanges(isChangeTab) {
        const { dispatch } = this.props;
        if (this.validateForm(false)) {
            apiUpdateClientContact(this.state.contact, () => {
                if (!this.props.inAddMode) {
                    this.props.sendMailChangeInfo(this.state.rawContact, this.state.contact);
                }

                if (!isChangeTab) {
                    dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
                }

                this.setState({ rawContact: this.state.contact });
            }, (error) => handleApiError(dispatch, error));
        }
    }

    getClientContact(brokerId) {
        if (Number(brokerId) !== 0) {
            apiGetClientContactByClientId(brokerId,
                (response) => {
                    this.setState({
                        contact: response.data,
                        rawContact: response.data
                    });
                });
        }
    }

    componentDidMount() {
        this.refs.primaryContactFirst.focus();
        setTimeout(() => {
            if ($("#contactNotes").length > 0) {
                //eslint-disable-next-line
                M.textareaAutoResize($("#contactNotes"));
            }
        }, 200);
    }

    componentWillMount() {
        this.getClientContact(this.state.contact.BrokerID);
    }

    componentWillReceiveProps(props) {
        if (Number(props.brokerId) !== Number(this.state.contact.BrokerID)) {
            this.getClientContact(props.brokerId);
            this.setState({ contact: { ...this.state.contact, BrokerID: props.brokerId } });
        }
    }

    render() {

        return (
            <div>
                <div className="row">
                    <div className="col s12 m6">
                        <div className="row">
                            <div className={`col s12 m6 input-field required suffixinput ${this.state.validator.isPrimaryContactFirstInvalid ? "required-field" : ""} `}>
                                <input
                                    maxLength="50" id="primaryContactFirst" className="validate"
                                    type="text" ref="primaryContactFirst" value={this.state.contact.primaryContactFirst}
                                    onChange={() => this.setState({ contact: { ...this.state.contact, primaryContactFirst: this.refs.primaryContactFirst.value }, isFormDirty: true })}
                                    onBlur={this.handleValidatePrimaryContactFirst.bind(this)}
                                />
                                <label htmlFor="primaryContactFirst">First Name</label>
                                <span className="suffix-text" style={this.state.validator.isPrimaryContactFirstInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("First Name")} />
                                </span>
                            </div>
                            <div className={`col s12 m6 input-field required suffixinput ${this.state.validator.isPrimaryContactLastInvalid ? "required-field" : ""} `}>
                                <input
                                    maxLength="50" id="primaryContactLast" value={this.state.contact.primaryContactLast}
                                    className="validate" type="text" ref="primaryContactLast"
                                    onChange={() => this.setState({ contact: { ...this.state.contact, primaryContactLast: this.refs.primaryContactLast.value }, isFormDirty: true })}
                                    onBlur={this.handleValidatePrimaryContactLast.bind(this)}
                                />
                                <label htmlFor="primaryContactLast">Last Name</label>
                                <span className="suffix-text" style={this.state.validator.isPrimaryContactLastInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Last Name")} />
                                </span>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12 m6 input-field">
                                <NumbericInput
                                    id="primaryContactExt" value={this.state.contact.primaryContactExt}
                                    maxLength="5" className="validate" ref="primaryContactExt"
                                    onChange={(value) => this.setState({ contact: { ...this.state.contact, primaryContactExt: value }, isFormDirty: true })}
                                />
                                <label htmlFor="primaryContactExt">Extension</label>
                            </div>
                            <div className={`input-field col s12 m6 suffixinput ${this.state.validator.isPrimaryContactFaxInvalid ? "has-error" : ""}`}>
                                <InputMask
                                    type="text"
                                    id="primaryContactFax" value={this.state.contact.primaryContactFax}
                                    mask="(999) 999-9999"
                                    className="validate" ref="primaryContactFax"
                                    onChange={() => this.setState({ contact: { ...this.state.contact, primaryContactFax: convertToPhoneNumber(this.refs.primaryContactFax.value) }, isFormDirty: true })}
                                    onBlur={this.handleValidatePrimaryContactFax.bind(this)}
                                />
                                <label htmlFor="primaryContactFax">Fax Number</label>
                                <span className="suffix-text" style={this.state.validator.isPrimaryContactFaxInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Fax Number")} />
                                </span>
                            </div>
                        </div>
                        <div className="row">
                            <div className={`col s12 m6 input-field suffixinput`}>
                                <input
                                    id="additionalContact" maxLength="50" value={this.state.contact.additionalContact}
                                    className="validate" type="text" ref="additionalContact"
                                    onChange={() => this.setState({ contact: { ...this.state.contact, additionalContact: this.refs.additionalContact.value }, isFormDirty: true })}
                                />
                                <label htmlFor="additionalContact">Additional Contact</label>
                            </div>

                            <div className={`col s12 m6 input-field suffixinput ${this.state.validator.isAdditionalContactEmailInvalid ? "has-error" : ""}`}>
                                <input
                                    type="text"
                                    id="additionalContactEmail" maxLength="70" value={this.state.contact.additionalContactEmail}
                                    className="validate" ref="additionalContactEmail"
                                    onChange={() => this.setState({ contact: { ...this.state.contact, additionalContactEmail: this.refs.additionalContactEmail.value }, isFormDirty: true })}
                                    onBlur={this.handleValidateAdditionalContactEmail.bind(this)}
                                />
                                <label htmlFor="additionalContactEmail">Additional Contact Email</label>
                                <span className="suffix-text" style={this.state.validator.isAdditionalContactEmailInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Additional Contact Email")} />
                                </span>
                            </div>
                        </div>
                        <div className="row">
                            <div className={`input-field col s12 m6 suffixinput ${this.state.validator.isAdditionalContactPhoneInvalid ? "has-error" : ""}`}>
                                <InputMask
                                    type="text"
                                    id="additionalContactPhone" value={this.state.contact.additionalContactPhone}
                                    mask="(999) 999-9999"
                                    className="validate" ref="additionalContactPhone"
                                    onChange={() => this.setState({ contact: { ...this.state.contact, additionalContactPhone: convertToPhoneNumber(this.refs.additionalContactPhone.value) }, isFormDirty: true })}
                                    onBlur={this.handleValidateAdditionalContactPhone.bind(this)}
                                />
                                <label htmlFor="additionalContactPhone">Additional Contact Phone Number</label>
                                <span className="suffix-text" style={this.state.validator.isAdditionalContactPhoneInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Additional Contact Phone Number")} />
                                </span>
                            </div>
                            <div className="col s12 m6 input-field">
                                <NumbericInput
                                    id="additionalContactExt" value={this.state.contact.additionalContactExt} maxLength="5"
                                    className="validate" ref="additionalContactExt"
                                    onChange={(value) => this.setState({ contact: { ...this.state.contact, additionalContactExt: value }, isFormDirty: true })}
                                />
                                <label htmlFor="additionalContactExt">Additional Contact Extension</label>
                            </div>
                        </div>
                    </div>
                    <div className="col s12 m6">
                        <div className="row">
                            <div className="input-field col s12">
                                <textarea
                                    type="text"
                                    id="contactNotes" ref="contactNotes"
                                    className="validate materialize-textarea" value={this.state.contact.contactNotes}
                                    onChange={() => this.setState({ contact: { ...this.state.contact, contactNotes: this.refs.contactNotes.value }, isFormDirty: true })}
                                ></textarea>
                                <label htmlFor="contactNotes">Contact Notes</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div >
        );
    }
}

ClientContacts.propTypes = {
    dispatch: PropTypes.func,
    brokerId: PropTypes.string,
    sendMailChangeInfo: PropTypes.func,
    inAddMode: PropTypes.bool
};

export default connect(null, null, null, { withRef: true })(ClientContacts);