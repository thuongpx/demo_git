import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { setNotaryShowModal, addNotaryLoop } from "../actions/client-details-actions";
import { validateRequired, requireComboBoxMessage } from "Helpers/validation-helper";
import Select from "Select";
import { Modal, ModalBody, ModalFooter, ModalTitle } from "Modal";

import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";

class ClientNotaryLoop extends Component {
    constructor(props) {
        super(props);
        this.state = {
            active: 1,
            emailConf: 1,
            client: "",
            isRequireSoftwareField: false
        };
    }

    handleAdd() {
        if (!this.handleValidateSoftwareRequired()) {
            const { dispatch, clients } = this.props;
            const notaryLoop = {
                BrokerID: clients.BrokerID,
                Client: this.state.client,
                Active: this.state.active,
                EmailConf: this.state.emailConf,
                TenantId: 1
            };
            dispatch(addNotaryLoop(notaryLoop, () => {
                this.setState({
                    active: 1,
                    emailConf: 1,
                    client: "",
                    isRequireSoftwareField: false
                });
            }));
        }
    }

    handleValidateSoftwareRequired() {
        const isRequireSoftwareField = !validateRequired(this.state.client);
        this.setState({ ...this.state, isRequireSoftwareField });
        return isRequireSoftwareField;
    }

    render() {
        const { clients, dispatch, isShowModal } = this.props;
        return (
            <Modal isOpen={isShowModal} modalOptions={{
                onOpenEnd: () => {
                    $(`#software`).parent().find(">:first-child")[0].focus();
                }
            }}
            >
                <ModalBody>
                    <ModalTitle onClickClose={() => dispatch(setNotaryShowModal(false))}>Notaryloop Integration</ModalTitle>
                    <div>
                        <div className="row">
                            <div className="col s12"><label className="active" htmlFor="clientID">Client ID</label></div>
                            <div className="col s12">
                                <span><strong>{clients.BrokerID}</strong></span>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12"><label className="active" htmlFor="clientID">Name</label></div>
                            <div className="col s12">
                                <span><strong>{clients.Company}</strong></span>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12">
                                <div className={`input-field suffixinput required ${this.state.isRequireSoftwareField ? "required-field" : ""}`}>
                                    <Select
                                        dataSource={[{ Code: "Resware", Description: "Resware" }, { Code: "Ramquest", Description: "Ramquest" }, { Code: "Softpro", Description: "Softpro" }, { Code: "eClosing", Description: "eClosing" }]}
                                        mapDataToRenderOptions={{ value: "Code", label: "Description" }}
                                        className="validate"
                                        id="software"
                                        ref="software"
                                        value={this.state.client}
                                        onChange={(client) => this.setState({ ...this.state, client })}
                                        onBlur={this.handleValidateSoftwareRequired.bind(this)}
                                        optionDefaultLabel="Select…"
                                    />
                                    <label htmlFor="software">Software</label>
                                    {this.state.isRequireSoftwareField && <span className={`suffix-text`}><img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireComboBoxMessage("Software")} /></span>}
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="input-field col s12">
                                <Select
                                    dataSource={[{ Code: 1, Description: "Yes" }, { Code: 0, Description: "No" }]}
                                    mapDataToRenderOptions={{ value: "Code", label: "Description" }}
                                    className="validate"
                                    id="emailConfirm"
                                    ref="emailConfirm"
                                    value={this.state.emailConf}
                                    onChange={(emailConf) => this.setState({ ...this.state, emailConf })}
                                />
                                <label htmlFor="emailConfirm">Email Confirmation</label>
                            </div>
                        </div>
                        <div className="row">
                            <label><input type="checkbox" key="active" ref="active" checked={this.state.active} onChange={() => this.setState({ ...this.state, active: !this.state.active })} /><span>Active</span></label>
                        </div>
                    </div>
                </ModalBody>
                <ModalFooter>
                    <div className="row m-0">
                        <div className="col m6">
                            <button className="btn white w-100" onMouseDown={() => dispatch(setNotaryShowModal(false))}>Cancel</button>
                        </div>
                        <div className="col m6">
                            <button onMouseDown={(event) => this.handleAdd(event)} className="btn success-color w-100">Add Client to NotaryLoop</button>
                        </div>
                    </div>
                </ModalFooter>
            </Modal >
        );
    }
}
ClientNotaryLoop.propTypes = {
    dispatch: PropTypes.func.isRequired,
    clients: PropTypes.object,
    isShowModal: PropTypes.bool
};
export default connect(
    (state) => {
        return {
            clients: state.clientManagement.clientDetails.clients,
            isShowModal: state.clientManagement.clientDetails.isShowModal
        };
    }
)(ClientNotaryLoop);