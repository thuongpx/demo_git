import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { validateDecimal } from "Helpers/validation-helper";
import { INPUT_ERROR_1X_IMAGE_URL } from "ImageConfig";
import { updateTextFields } from "../../../helpers/theme-helper";
import { invalidMessage } from "Helpers/validation-helper";
import Select from "Select";

class GeneralSpecs extends Component {

    componentDidUpdate() {
        updateTextFields();
    }

    handleInputChange(obj) {
        const { onInputChange } = this.props;
        onInputChange(obj);
    }

    handleValidateChange(obj) {
        const { onValidateChange } = this.props;
        onValidateChange(obj);
    }

    componentDidMount() {
        this.refs.DiifDateOK.focus();
    }

    render() {
        const { dataSource, dataValidate, strikeoutOKs, noConfirmTravels, faxDocsRequireds, inkColors, downloadPrints, dualTrays, timeFlexibles } = this.props;

        return (
            <div>
                <div className="row">
                    <div className="input-field col s12">
                        <input
                            className="validate" value={dataSource.DiifDateOK} type="text" style={{ width: "100%" }}
                            maxLength={255} ref="DiifDateOK" id="diifDateOK"
                            onChange={() => this.handleInputChange({ DiifDateOK: this.refs.DiifDateOK.value })}
                        />
                        <label htmlFor="diifDateOK">Signing date different than date on docs OK?</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <Select
                            dataSource={strikeoutOKs}
                            id="strikeoutOK"
                            onChange={(value) => this.handleInputChange({ StrikeoutOK: value })}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="status"
                            value={dataSource.StrikeoutOK || ""}
                            className="icons w-100 custome-style-select validate"
                        />
                        <label>Strikeouts OK on typo?</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <textarea
                            style={{ minHeight: 80 }} className="validate materialize-textarea" id="" rows="3" value={dataSource.POAVerbiage}
                            maxLength={255} ref="POAVerbiage" id="POAVerbiage"
                            onChange={() => this.handleInputChange({ POAVerbiage: this.refs.POAVerbiage.value })}
                        >
                        </textarea>
                        <label htmlFor="POAVerbiage">POA verbiage?</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <textarea
                            style={{ minHeight: 80 }} className="validate materialize-textarea" id="" rows="3" value={dataSource.TrustVerbiage}
                            maxLength={50} ref="TrustVerbiage" id="TrustVerbiage"
                            onChange={() => this.handleInputChange({ TrustVerbiage: this.refs.TrustVerbiage.value })}
                        >
                        </textarea>
                        <label htmlFor="TrustVerbiage">Trust verbiage?</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <Select
                            dataSource={noConfirmTravels}
                            id="noConfirmTravel"
                            onChange={(value) => this.handleInputChange({ NoConfirmTravel: value })}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="status"
                            value={dataSource.NoConfirmTravel || ""}
                            className="icons w-100 custome-style-select validate"
                        />
                        <label>Go to Appt. even if unconfirmed?</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12 suffixinput">
                        <input type="number" step={0.0001} className="validate" value={dataSource.AmtCashierCheck} style={{ width: "100%" }}
                            ref="AmtCashierCheck" id="AmtCashierCheck"
                            onChange={() => this.handleInputChange({ AmtCashierCheck: this.refs.AmtCashierCheck.value })}
                            onBlur={() => this.handleValidateChange({ AmtCashierCheck: !validateDecimal(this.refs.AmtCashierCheck.value) })}
                        />
                        <label htmlFor="AmtCashierCheck">Cashier check required at what amount?</label>
                        <span className={`suffix-text ${dataValidate.AmtCashierCheck ? "" : "hide"}`}>
                            <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Decimal Number")} />
                        </span>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <input className="validate" type="text" value={dataSource.CheckMadeTo} style={{ width: "100%" }}
                            maxLength={255} ref="CheckMadeTo" id="CheckMadeTo"
                            onChange={() => this.handleInputChange({ CheckMadeTo: this.refs.CheckMadeTo.value })}
                        />
                        <label htmlFor="CheckMadeTo">Cash to close check made out to?</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <Select
                            dataSource={faxDocsRequireds}
                            id="faxDocsRequired"
                            onChange={(value) => this.handleInputChange({ FaxDocsRequired: value })}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="status"
                            value={dataSource.FaxDocsRequired || ""}
                            className="icons w-100 custome-style-select validate"
                        />
                        <label>Scan backs</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <input className="validate" type="text" value={dataSource.StandardPickups} style={{ width: "100%" }}
                            maxLength={255} ref="StandardPickups" id="StandardPickups"
                            onChange={() => this.handleInputChange({ StandardPickups: this.refs.StandardPickups.value })}
                        />
                        <label htmlFor="StandardPickups">Standard items to Collect?</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <Select
                            dataSource={inkColors}
                            id="inkColor"
                            onChange={(value) => this.handleInputChange({ InkColor: value })}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="status"
                            value={dataSource.InkColor || ""}
                            className="icons w-100 custome-style-select validate"
                        />
                        <label>Ink Color?</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <Select
                            dataSource={downloadPrints}
                            id="downloadPrint"
                            onChange={(value) => this.handleInputChange({ DownloadPrint: value })}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="status"
                            value={dataSource.DownloadPrint || ""}
                            className="icons w-100 custome-style-select validate"
                        />
                        <label>Paper Size?</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <Select
                            dataSource={dualTrays}
                            id="dualTray"
                            onChange={(value) => this.handleInputChange({ DualTray: value })}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="status"
                            value={dataSource.DualTray || ""}
                            className="icons w-100 custome-style-select validate"
                        />
                        <label>If no dual tray, legal or letter for all?</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <input className="validate" type="text" value={dataSource.IssueContact} style={{ width: "100%" }}
                            maxLength={50} ref="IssueContact" id="IssueContact"
                            onChange={() => this.handleInputChange({ IssueContact: this.refs.IssueContact.value })}
                        />
                        <label htmlFor="IssueContact">After hour contact name</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <input className="validate" type="text" value={dataSource.AfterHoursPhone} style={{ width: "100%" }}
                            maxLength={20} ref="AfterHoursPhone" id="AfterHoursPhone"
                            onChange={() => this.handleInputChange({ AfterHoursPhone: this.refs.AfterHoursPhone.value })}
                        />
                        <label htmlFor="AfterHoursPhone">After hour contact number</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <Select
                            dataSource={timeFlexibles}
                            id="timeFlexible"
                            onChange={(value) => this.handleInputChange({ TimeFlexible: value })}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="status"
                            value={dataSource.TimeFlexible || ""}
                            className="icons w-100 custome-style-select validate"
                        />
                        <label>Borrower reschedule OK?</label>
                    </div>
                </div>
            </div>
        );
    }
}

GeneralSpecs.defaultProps = {
    strikeoutOKs: [
        {
            value: "",
            label: "Select..."
        },
        {
            value: "Y",
            label: "Yes"
        },
        {
            value: "N",
            label: "No"
        },
        {
            value: "C",
            label: "Check with Lender"
        }
    ],
    noConfirmTravels: [
        {
            value: "",
            label: "Select..."
        },
        {
            value: "Y",
            label: "Yes"
        },
        {
            value: "N",
            label: "No"
        }],
    faxDocsRequireds: [
        {
            value: "",
            label: "Select..."
        },
        {
            value: "No",
            label: "No"
        },
        {
            value: "Always",
            label: "Always"
        },
        {
            value: "Investment Property",
            label: "Investment Property"
        },
        {
            value: "Single Docs",
            label: "Single Docs"
        },
        {
            value: "Upon Request",
            label: "Upon Request"
        }],
    inkColors: [
        {
            value: "",
            label: "Select..."
        },
        {
            value: "Blue",
            label: "Blue"
        },
        {
            value: "Black",
            label: "Black"
        },
        {
            value: "Either",
            label: "Either"
        },
        {
            value: "State Specific",
            label: "State Specific"
        }],
    downloadPrints: [
        {
            value: "",
            label: "Select..."
        },
        {
            value: "Letter",
            label: "Letter"
        },
        {
            value: "Legal",
            label: "Legal"
        },
        {
            value: "Mixed",
            label: "Mixed"
        }],
    dualTrays: [
        {
            value: "",
            label: "Select..."
        },
        {
            value: "Letter",
            label: "Letter"
        },
        {
            value: "Legal",
            label: "Legal"
        },
        {
            value: "Mix required",
            label: "Mix required"
        }],
    timeFlexibles: [
        {
            value: "",
            label: "Select..."
        },
        {
            value: "Y",
            label: "Yes – Date and Time"
        },
        {
            value: "T",
            label: "Yes – Time Only"
        },
        {
            value: "N",
            label: "No"
        },
        {
            value: "C",
            label: "Call Client"
        }]
};

GeneralSpecs.propTypes = {
    disabled: PropTypes.bool,
    dataSource: PropTypes.object,
    onInputChange: PropTypes.func,
    dataValidate: PropTypes.object,
    onValidateChange: PropTypes.func,
    strikeoutOKs: PropTypes.array,
    noConfirmTravels: PropTypes.array,
    faxDocsRequireds: PropTypes.array,
    inkColors: PropTypes.array,
    downloadPrints: PropTypes.array,
    dualTrays: PropTypes.array,
    timeFlexibles: PropTypes.array
};

export default GeneralSpecs;