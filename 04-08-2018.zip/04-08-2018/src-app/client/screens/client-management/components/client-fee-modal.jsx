import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { apiUpdateBrokerFee } from "Api/broker-fee-api";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";

import { validateRequired, requireMessage } from "Helpers/validation-helper";

import NumberFormat from "react-number-format";
import { showSuccess } from "../../main-layout/actions";
import { handleApiError } from "ErrorHandler";
import { SUCCESSFULLY_SAVED_MESSAGE } from "Constants";
import { connect } from "react-redux";
import { updateTextFields } from "../../../helpers/theme-helper";

export class ClientFeeModal extends Component {

    constructor(props) {
        super(props);
        this.state = {
            brokerId: this.props.brokerId,
            isShowModal: false,
            brokerFee: {},
            isBrokerFeeInvalid: false
        };
    }

    componentDidUpdate() {
        setTimeout(() => {
            updateTextFields();
        }, 200);
    }

    show(brokerFee) {
        this.setState({ brokerFee, isShowModal: true, isBrokerFeeInvalid: false });
    }

    handleSaveBrokerFee() {
        const { dispatch } = this.props;
        if (!this.state.isBrokerFeeInvalid) {
            delete this.state.brokerFee.description;
            apiUpdateBrokerFee(this.state.brokerFee, () => {
                this.setState({ isShowModal: false });
                dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
                this.props.onBrokerFeeSaved();
            }, (error) => handleApiError(dispatch, error));
        }
    }

    render() {
        const isShowModal = this.state.isShowModal;
        const brokerFee = this.state.brokerFee;
        return (
            <div>
                <div>
                    <Modal isOpen={isShowModal} fixedFooter={false}>
                        <ModalBody>
                            <ModalTitle onClickClose={() => { this.setState({ isShowModal: false }); }}>{"Edit Client Fee"}</ModalTitle>
                            <div>
                                <div className="row">
                                    <div className="input-field col s12">
                                        <input disabled value={brokerFee.description} id="description" type="text" className="validate" />
                                        <label htmlFor="description">Fee Description</label>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className={`col s12 input-field required suffixinput ${this.state.isBrokerFeeInvalid ? "required-field" : ""} `}>
                                        <NumberFormat id="clientFee" type="text" maxLength="19" thousandSeparator value={brokerFee.brokerFee} prefix={"$"} onValueChange={(values) => {
                                            const { value } = values;
                                            const isBrokerFeeInvalid = !validateRequired(value);
                                            this.setState({ isBrokerFeeInvalid });
                                            this.setState({ brokerFee: { ...this.state.brokerFee, brokerFee: value } });
                                        }} />
                                        <label htmlFor="clientFee">Client Fee</label>
                                        <span className="suffix-text" style={this.state.isBrokerFeeInvalid ? { display: "block" } : { display: "none" }} >
                                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Client Fee")} />
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </ModalBody>
                        <ModalFooter>
                            <div>
                                <div className="col m6 s6">
                                    <button className="modal-action btn w-100 white" onMouseDown={() => this.setState({ isShowModal: false })}>Cancel</button>
                                </div>
                                <div className="col m6 s6">
                                    <button className="modal-action btn success-color w-100" onClick={this.handleSaveBrokerFee.bind(this)}>Save</button>
                                </div>
                            </div>
                        </ModalFooter>
                    </Modal>
                </div>
            </div >
        );
    }
}

ClientFeeModal.propTypes = {
    dispatch: PropTypes.func,
    brokerId: PropTypes.string,
    columns: PropTypes.array,
    onBrokerFeeSaved: PropTypes.func
};

export default connect(null, null, null, { withRef: true })(ClientFeeModal);
