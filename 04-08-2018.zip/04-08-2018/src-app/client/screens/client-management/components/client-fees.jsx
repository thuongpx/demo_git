import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { apiGetBrokerFeeByBrokerId, apiUpdateBrokerFee } from "Api/broker-fee-api";
import GridView from "GridView";
import { showSuccess } from "../../main-layout/actions";
import { handleApiError } from "ErrorHandler";
import { SUCCESSFULLY_SAVED_MESSAGE } from "Constants";
import { connect } from "react-redux";
import { updateTextFields } from "../../../helpers/theme-helper";

import ClientFeeModal from "./client-fee-modal";

export class ClientFees extends Component {

    constructor(props) {
        super(props);
        this.state = {
            brokerFees: {
                listData: [],
                totalRecords: 0
            },
            brokerId: this.props.brokerId,
            isShowModal: false,
            brokerFee: {},
            isBrokerFeeInvalid: false,
            criteria: {
                sortColumn: "description",
                sortDirection: false,
                page: 1,
                itemPerPage: 25
            }
        };
    }

    getFees(brokerId, criteria) {
        const self = this;
        apiGetBrokerFeeByBrokerId({ brokerId, ...criteria }, (response) => {
            self.setState({ brokerFees: response.data });
        });
    }

    componentDidUpdate() {
        updateTextFields();
    }

    componentWillMount() {
        this.getFees(this.state.brokerId, this.state.criteria);
    }

    handleGridViewReload(criteria) {
        this.setState({ criteria });
        this.getFees(this.state.brokerId, criteria);
    }

    componentWillReceiveProps(props) {
        this.getFees(props.brokerId);
        this.setState({ brokerId: props.brokerId });
    }

    handleGridViewActionClick(action, id) {
        switch (action) {
            case "edit":
                this.state.brokerFees.listData.map(brokerFee => {
                    if (brokerFee.feeId === id) {
                        this.clientFeeModal.show(brokerFee);
                    }
                });
        }
    }

    handleSaveBrokerFee() {
        const { dispatch } = this.props;
        if (!this.state.isBrokerFeeInvalid) {
            delete this.state.brokerFee.description;
            apiUpdateBrokerFee(this.state.brokerFee, () => {
                this.setState({ isShowModal: false });
                this.getFees(this.state.brokerId, this.state.criteria);
                dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
            }, (error) => handleApiError(dispatch, error));
        }
    }

    render() {
        const { columns } = this.props;
        return (
            <div className="tab-content">
                <div className="row">
                    <GridView
                        criteria={this.state.criteria}
                        totalRecords={this.state.brokerFees ? this.state.brokerFees.totalRecords : 0}
                        datasources={this.state.brokerFees.listData} //Pass datasources
                        columns={columns} //Pass columns array
                        identifier={"feeId"} //Identifier for grid row
                        actions={["edit"]}
                        onActionClick={this.handleGridViewActionClick.bind(this)} //Handle actions
                        onGridViewReload={(e) => this.handleGridViewReload(e)}
                    />
                    <div>
                        <ClientFeeModal ref={(clientFeeModal) => {
                            if (clientFeeModal && clientFeeModal.getWrappedInstance) {
                                this.clientFeeModal = clientFeeModal.getWrappedInstance();
                            }
                        }} onBrokerFeeSaved={() => this.getFees(this.state.brokerId)} brokerId={this.props.brokerId} />
                    </div>
                </div>
            </div >
        );
    }
}

ClientFees.defaultProps = {
    columns: [
        {
            "title": "#",
            "type": "rownumber"
        },
        {
            "title": "Fee Description",
            "data": "description"
        },
        {
            "title": "Client Fee",
            "data": "brokerFee",
            "type": "money"
        }
    ]
};

ClientFees.propTypes = {
    dispatch: PropTypes.func,
    brokerId: PropTypes.string,
    columns: PropTypes.array
};

export default connect(null, null, null, { withRef: true })(ClientFees);
