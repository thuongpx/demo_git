import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { updateTextFields } from "../../../helpers/theme-helper";
import { shallowCompareState, shallowCompareProps, deepClone } from "../../../helpers/common-helper";
import ReactTooltip from "react-tooltip";
import { INPUT_MISSING_1X_IMAGE_URL } from "../../../config/img.config";
import { apiUpdateClient } from "../../../api/clients-api";
import { handleApiError } from "../../../helpers/error-handler";
import { showSuccess } from "../../main-layout/actions";
import { SUCCESSFULLY_SAVED_MESSAGE } from "../../../constant/constants";
import { apiGetHybridQuestionData } from "../../../api/broker-api";

class ClientHybridTab extends Component {
    constructor(props) {
        super(props);

        this.state = {
            assignOrdersDirectly: false,
            tceFullFill: false,
            isConfirmCorrect: false,
            invalidField: {},
            rawAssign: false,
            rawTCEFull: false
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentDidUpdate() {
        updateTextFields();
    }

    componentWillMount() {
        const { brokerId } = this.props;

        apiGetHybridQuestionData({ brokerId }, (initData) => {
            this.setState({
                assignOrdersDirectly: initData.data.assignOrdersDirectly || false,
                tceFullFill: initData.data.assignOrdersDirectly ? initData.data.tceFullFill || false : false,
                rawAssign: initData.data.assignOrdersDirectly || false,
                rawTCEFull: initData.data.assignOrdersDirectly ? initData.data.tceFullFill || false : false
            });
        }, (err) => handleApiError(this.props.dispatch, err));
    }

    validateForm() {
        const invalidField = {};
        if (!this.state.isConfirmCorrect) invalidField.isConfirmCorrect = true;

        this.setState({ invalidField });

        const check = Object.keys(invalidField)[0];

        if (check) {
            $(`#${check}`).addClass("tabbed");
            $(`#${check}`).focus();
            return false;
        }

        return true;
    }

    saveChanges(isShowNoti = false) {
        if (!this.validateForm()) return;

        const hybridData = deepClone(this.state);
        delete hybridData.isConfirmCorrect;
        delete hybridData.invalidField;
        delete hybridData.rawAssign;
        delete hybridData.rawTCEFull;

        hybridData.BrokerID = this.props.brokerId;

        apiUpdateClient(hybridData, () => {
            if (isShowNoti) {
                this.props.dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
            }

            if (!this.props.inAddMode) {
                this.props.sendMailChangeInfo({ AssignOrdersDirectly: this.state.rawAssign, TCEFullFill: this.state.rawTCEFull }, { AssignOrdersDirectly: this.state.assignOrdersDirectly, TCEFullFill: this.state.tceFullFill });
                this.setState({ rawAssign: this.state.assignOrdersDirectly, rawTCEFull: this.state.tceFullFill });
            }
        }, (err) => handleApiError(this.props.dispatch, err));
    }

    render() {
        const { assignOrdersDirectly, tceFullFill, isConfirmCorrect } = this.state;
        return (
            <div>
                <div className="row">
                    <div className="col s12 m10 offset-m2">
                        <div className="col s12">
                            <label>Are you planning to assign orders directly to vendors through the TCE platform?</label>
                        </div>
                        <div className="clearfix"></div>
                        <div className="col s12">
                            <div className="col s6">
                                <label htmlFor="isAssignOrdersDirectlyN">
                                    <input
                                        className="with-gap"
                                        type="radio"
                                        name="AssignOrdersDirectly"
                                        id="isAssignOrdersDirectlyN"
                                        checked={!assignOrdersDirectly}
                                        onChange={() => { this.setState({ assignOrdersDirectly: false, tceFullFill: false }); }}
                                    />
                                    <span>No</span>
                                </label>
                            </div>
                            <div className="col s12 m12 l12 xl6">
                                <label htmlFor="isAssignOrdersDirectlyY">
                                    <input
                                        className="with-gap"
                                        type="radio"
                                        name="AssignOrdersDirectly"
                                        id="isAssignOrdersDirectlyY"
                                        checked={assignOrdersDirectly}
                                        onChange={() => { this.setState({ assignOrdersDirectly: true }); }}
                                    />
                                    <span>Yes (Process to Step #2)</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="row">
                    <div className="col s12 m10 offset-m2">
                        <div className="col s12">
                            <label>Do you foresee a need to have TCE fullfill any orders based on <u data-tip data-for="underline-volume">volume</u>, <u data-tip data-for="underline-geography">geography</u> or <u data-tip data-for="underline-month">certain times of the month</u>?</label>
                        </div>
                        <div className="clearfix"></div>
                        <div className="col s12">
                            <div className="col s6">
                                <label htmlFor="isFulfillN">
                                    <input
                                        className="with-gap"
                                        type="radio"
                                        name="Fulfill"
                                        id="isFulfillN"
                                        disabled={!assignOrdersDirectly}
                                        checked={!tceFullFill}
                                        onChange={() => { this.setState({ tceFullFill: false }); }}
                                    />
                                    <span>No</span>
                                </label>
                            </div>
                            <div className="col s6">
                                <label htmlFor="isFulfillY">
                                    <input
                                        className="with-gap"
                                        type="radio"
                                        name="Fulfill"
                                        id="isFulfillY"
                                        disabled={!assignOrdersDirectly}
                                        checked={tceFullFill}
                                        onChange={() => { this.setState({ tceFullFill: true }); }}
                                    />
                                    <span>Yes</span>
                                </label>
                            </div>
                        </div>
                    </div>

                </div>

                <div className="row">
                    <div className="col s12 m10 offset-m2 input-field">
                        <label htmlFor="isConfirmCorrect">
                            <input
                                className="with-gap"
                                type="checkbox"
                                id="isConfirmCorrect"
                                checked={isConfirmCorrect}
                                onChange={(e) => {
                                    const rawInvalidField = deepClone(this.state.invalidField);

                                    if (!e.target.checked) {
                                        rawInvalidField.isConfirmCorrect = true;
                                    } else {
                                        rawInvalidField.isConfirmCorrect = false;
                                    }

                                    this.setState({ isConfirmCorrect: e.target.checked, invalidField: rawInvalidField });
                                }}
                            />
                            <span>I have confirmed all these questions with clients. All answers here are correct.<span className="red-color">*</span></span>
                            <span className={`suffix-text ${this.state.invalidField.isConfirmCorrect ? "" : "hide"}`} style={{ position: "relative", top: "3px", left: "4px" }}>
                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title="Please make sure that all these answers here are confirmed with clients before continuing." />
                            </span>
                        </label>
                    </div>

                </div>

                <ReactTooltip id="underline-volume" aria-haspopup="true" role="example">
                    <p>Clients have the ability to determine the number of orders per day that they choose to manage on their own.</p>
                    <p>Please select the maximum number of orders per day that your staff would like to self-service.</p>
                    <p>For example, if your staff can manage up to 20 orders per day, please enter the number ‘20’.</p>
                    <p>Entering 20 means that the first 20 orders entered will be managed by you.</p>
                    <p>Any order beyond order number 20 would be routed to The Closing Exchange to fulfill on your behalf.</p>
                </ReactTooltip>
                <ReactTooltip id="underline-month" aria-haspopup="true" role="example">
                    <p>Clients have the ability to determine what date in the month they will manage orders themselves.</p>
                    <p>Please select the dates on which you would self-service orders.</p>
                </ReactTooltip>
                <ReactTooltip id="underline-geography" aria-haspopup="true" role="example">
                    <p>Clients have the ability to determine in which states they will manage orders themselves.</p>
                    <p>Please select the states in which you would self-service orders.</p>
                    <p>For example, you might select to only schedule your own orders in California, Florida and Texas.</p>
                </ReactTooltip>
                <div className="row"></div>
            </div>
        );
    }
}

ClientHybridTab.propTypes = {
    dispatch: PropTypes.func,
    brokerId: PropTypes.number,
    sendMailChangeInfo: PropTypes.func,
    inAddMode: PropTypes.bool
};

export default ClientHybridTab;