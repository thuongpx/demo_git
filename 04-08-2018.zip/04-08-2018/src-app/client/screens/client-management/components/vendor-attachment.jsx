import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";
import { showSuccess } from "../../main-layout/actions";
import CommonModal from "CommonModal";
import { saveDocumentFile } from "../actions/client-specifics-actions";
import { apiDeleteLendorSpecifics } from "Api/client-detail-api";
import {
    API_URL
} from "Config/config";

class VendorAttachment extends Component {
    constructor(props) {
        super(props);

        this.state = {
            isOpen: false,
            vendorAttachtionFile: "",
            isShowDocument: false
        };
    }

    handleCancel() {
        this.commonModal.showModal({
            type: "confirm",
            message: `Are you sure you would like to cancel uploading client specific file?`
        }, () => {
            // clear source
            this.setState({
                isOpen: false
            });
            // clear input
            this.documentFileName.value = null;
        });
    }

    handleUpload() {
        const { dispatch, brokerId } = this.props;

        dispatch(saveDocumentFile({ documentFile: this.state.document, brokerId }, () => {
            this.refs.documentFileName.value = "";
            dispatch(showSuccess("Uploaded Successfully"));
            this.setState({
                isOpen: false
            });
        }));
    }

    handleDropDocument(e) {
        e.preventDefault();
        let files;
        if (e.dataTransfer) {
            files = e.dataTransfer.files;
        } else if (e.target) {
            files = e.target.files;
        }

        if (files.length > 0) {
            const file = files[0];
            const fileExtension = file.name.split(".")[file.name.split(".").length - 1];
            const acceptDocument = this.props.accept.split(",").map(item => { return item.replace(".", ""); });

            if (acceptDocument.indexOf(fileExtension.toLowerCase()) > -1) {
                const formData = new FormData();
                formData.append("document", file);
                this.refs.documentFileName.value = file.name;
                this.setState({ document: file, isDirty: true });
            }
        }
    }

    handleAddDelete(mode) {
        switch (mode) {
            case "add":
                this.setState({ isOpen: true });
                break;
            case "delete":
                this.commonModal.showModal({
                    type: "confirm",
                    message: `Are you sure you would like to delete this client specific file?`
                }, () => {
                    apiDeleteLendorSpecifics(this.props.brokerId, () => {
                        // success
                        this.props.dispatch(showSuccess("Deleted Successfully"));
                        // clear source
                        this.setState({
                            isOpen: false
                        });
                        // clear input
                        this.documentFileName.value = "";

                    });
                });
                break;
            default:
                break;
        }
    }

    render() {
        const { isAddMode, accept, brokerId } = this.props;
        const { isOpen } = this.state;

        return (
            <div>
                <div className="row">
                    <div className="col s12 m12 mt-1">
                        <p htmlFor="" className="font-14 bold-6">
                            <strong>Vendor Attachment - Management</strong>
                        </p>
                    </div>
                </div>
                <div className="row">
                    <div className="col s12 center-align mt-2">
                        <strong>Use this eature to upload or delete client specific that is attached to all vendor confirmations</strong>
                    </div>
                </div>

                {isAddMode &&
                    <div className="row">
                        <div className="col s12 center-align mt-2 mb-2">
                            <p><strong style={{ fontSize: "30px" }}>NOTE: PDF is the only acceptable file format</strong></p>
                        </div>
                    </div>
                }

                {!isAddMode &&
                    <div className="row">
                        <div className="col s12 center-align mt-2 mb-2">
                            <a style={{ fontSize: "30px" }} href={`${API_URL}/client/Lenderspecifics?brokerId=${brokerId}`} target="_blank">File Exists – Click to Open</a>
                        </div>
                    </div>
                }
                <div className="row">
                    <div className="col s12 center-align">
                        <button className="btn success-color action-btn pl-5 pr-5" onClick={() => this.handleAddDelete(`${isAddMode ? "add" : "delete"}`)}>{`${isAddMode ? "Upload Vendor Attachment File" : "Delete Vendor Attachment File"}`}</button>
                    </div>
                </div>
                <div>
                    <Modal isOpen={isOpen} style={{ width: "35%", height: "40%" }}>
                        <ModalBody>
                            <ModalTitle onClickClose={() => this.handleCancel()}>Upload Client Specific File</ModalTitle>
                            <div className="row">
                                <div className="col s12 center-align">
                                    <p>Please select a File to Upload</p>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col s12">
                                    <div className="file-field input-field">
                                        <div className="btn" style={{ float: "right", marginRight: "20px" }}>
                                            <button className="btn btn-primary action-btn" style={{ height: "3rem" }} onClick={() => {
                                                this.docFileElement.click();
                                            }
                                            }
                                            >Browse</button>
                                        </div>
                                        <div className="file-path-wrapper">
                                            <input type="text" disabled ref="documentFileName" />
                                            <input ref={input => { this.docFileElement = input; }} id="profile-file-input" type="file" style={{ display: "none" }} accept={accept} onChange={this.handleDropDocument.bind(this)} />
                                        </div>
                                        <strong className="pl-1">Accepted Image Formats are:</strong><span> .PDF</span>
                                    </div>
                                </div>
                            </div>
                        </ModalBody>
                        <ModalFooter>
                            <div className="row m-0">
                                <div className="col m6">
                                    <button className="btn white w-100" onClick={() => this.handleCancel()}>Cancel</button>
                                </div>
                                <div className="col m6">
                                    <button className="btn success-color w-100" onClick={() => this.handleUpload()}>OK</button>
                                </div>
                            </div>
                        </ModalFooter>
                    </Modal>
                </div>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div >
        );
    }
}

VendorAttachment.defaultProps = {
    accept: ".pdf"
};

VendorAttachment.propTypes = {
    dispatch: PropTypes.func,
    isAddMode: PropTypes.bool,
    accept: PropTypes.string,
    brokerId: PropTypes.number
};

export default connect(null, null, null, { withRef: true })(VendorAttachment);