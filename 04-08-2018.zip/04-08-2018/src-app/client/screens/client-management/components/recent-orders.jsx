import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import GridView from "GridView";
import { startSetRecentOrders, setRecentOrdersCriteria } from "../actions/client-recent-orders-actions";
import Select from "Select";

export class ClientRecentOrders extends Component {
    constructor(props) {
        super(props);

        this.state = {
            recentDay: "30"
        };
    }

    getRecentOrders(brokerId) {
        this.props.dispatch(setRecentOrdersCriteria({
            ...this.props.criteria,
            brokerId
        }));
        this.props.dispatch(startSetRecentOrders());
    }

    componentWillMount() {
        this.getRecentOrders(this.props.brokerId);
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.brokerId !== this.props.brokerId) {
            this.getRecentOrders(nextProps.brokerId);
        }
    }

    componentDidMount() {
        $(`#deliverTo`).parent().find(">:first-child")[0].focus();
    }

    //Reload datasource by criteria here
    handleGridViewReload(criteria) {
        criteria = { ...criteria, ...{ recentDay: this.state.recentDay, brokerId: this.props.brokerId } };
        this.props.dispatch(setRecentOrdersCriteria(criteria));
        this.props.dispatch(startSetRecentOrders());
    }

    handleChangeState(value) {
        const { criteria } = this.props;
        this.setState({
            recentDay: value
        }, () => {
            this.handleGridViewReload(criteria);
        });
    }

    render() {
        const { columns, recentOrders, criteria, recentDays } = this.props;

        return (
            <div>
                <div className="valign-wrapper">
                    <p>Orders in the last</p>
                    <div style={{ marginLeft: "10px", marginRight: "10px" }}>
                        <Select
                            dataSource={recentDays}
                            id="deliverTo"
                            onChange={(value) => this.handleChangeState(value)}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="status"
                            value=""
                            className="icons w-100 custome-style-select validate"
                        />
                    </div>
                    <span>days</span>
                </div>
                <div className="row">
                    <div className="col s12">
                        <GridView
                            criteria={criteria}
                            totalRecords={recentOrders.totalRecords}
                            datasources={recentOrders.data} //Pass datasources
                            columns={columns} //Pass columns array
                            onGridViewReload={this.handleGridViewReload.bind(this)} //Paginate changed => need reload datasource base on criteria
                        />
                    </div>
                </div>
            </div>)
            ;
    }
}

ClientRecentOrders.propTypes = {
    columns: PropTypes.array
};

ClientRecentOrders.defaultProps = {
    columns: [
        {
            title: "Order Id",
            data: "OrderId"
        },
        {
            title: "Client Last",
            data: "ClientLast"
        },
        {
            title: "VendorLast",
            data: "VendorLast"
        },
        {
            title: "Company",
            data: "Company"
        },
        {
            title: "Progress",
            data: "ProgressDescription"
        },
        {
            title: "Order Date",
            data: "OrderDate",
            type: "datetime"
        },
        {
            title: "Appt. Date",
            data: "AptDateTime",
            type: "datetime"
        }
    ],
    recentDays: [
        {
            value: "30",
            label: "30"
        },
        {
            value: "60",
            label: "60"
        },
        {
            value: "90",
            label: "90"
        }
    ]
};

ClientRecentOrders.propTypes = {
    dispatch: PropTypes.func,
    recentOrders: PropTypes.object,
    criteria: PropTypes.object,
    columns: PropTypes.array,
    brokerId: PropTypes.number,
    recentDays: PropTypes.array
};

export default connect(
    (state) => {
        return {
            recentOrders: state.clientManagement.recentOrders.datasources,
            criteria: state.clientManagement.recentOrders.criteria
        };
    }
)(ClientRecentOrders);