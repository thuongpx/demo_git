import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import Select from "Select";

class DocumentSpecs extends Component {

    handleInputChange(obj) {
        const { onInputChange } = this.props;
        onInputChange(obj);
    }

    render() {
        const { dataSource, deliverTos, morningDeliverys, returnLabels, emailDeliverys } = this.props;

        return (
            <div>
                <div className="row">
                    <div className="input-field col s12">
                        <input className="validate" value={dataSource.DocDelivery} type="text" style={{ width: "100%" }}
                            maxLength={50} ref="DocDelivery" id="DocDelivery"
                            onChange={() => this.handleInputChange({ DocDelivery: this.refs.DocDelivery.value })}
                        />
                        <label htmlFor="DocDelivery">How are docs delivered?</label>
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <label>To whom are the docs delivered?</label>
                        <Select
                            dataSource={deliverTos}
                            id="deliverTo"
                            onChange={(value) => this.handleInputChange({ DeliverTo: value })}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="status"
                            value={dataSource.DeliverTo || ""}
                            className="icons w-100 custome-style-select validate"
                        />
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <label>If overnight, morning delivery?</label>
                        <Select
                            dataSource={morningDeliverys}
                            id="morningDelivery"
                            onChange={(value) => this.handleInputChange({ MorningDelivery: value })}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="status"
                            value={dataSource.MorningDelivery || ""}
                            className="icons w-100 custome-style-select validate"
                        />
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <label>Preprinted label in package?</label>
                        <Select
                            dataSource={returnLabels}
                            id="ReturnLabel"
                            onChange={(value) => this.handleInputChange({ ReturnLabel: value })}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="status"
                            value={dataSource.ReturnLabel || ""}
                            className="icons w-100 custome-style-select validate"
                        />
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <label>Email docs attachment or download?</label>
                        <Select
                            dataSource={emailDeliverys}
                            id="EmailDelivery"
                            onChange={(value) => this.handleInputChange({ EmailDelivery: value })}
                            mapDataToRenderOptions={{ value: "value", label: "label" }}
                            ref="status"
                            value={dataSource.EmailDelivery || ""}
                            className="icons w-100 custome-style-select validate"
                        />
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <label htmlFor="DownloadPassword">Download Password?</label>
                        <input className="validate" ref="" type="text" value={dataSource.DownloadPassword} style={{ width: "100%" }}
                            maxLength={25} ref="DownloadPassword" id="DownloadPassword"
                            onChange={() => this.handleInputChange({ DownloadPassword: this.refs.DownloadPassword.value })}
                        />
                    </div>
                </div>
                <div className="row">
                    <div className="input-field col s12">
                        <label htmlFor="DownloadFormat">Doc format?</label>
                        <input className="form-control" ref="" type="text" value={dataSource.DownloadFormat} style={{ width: "100%" }}
                            maxLength={25} ref="DownloadFormat" id="DownloadFormat"
                            onChange={() => this.handleInputChange({ DownloadFormat: this.refs.DownloadFormat.value })}
                        />
                    </div>
                </div>
            </div>
        );
    }
}

DocumentSpecs.defaultProps = {
    deliverTos: [
        {
            value: "",
            label: "Select..."
        },
        {
            value: "Customer",
            label: "Customer"
        },
        {
            value: "Notary",
            label: "Vendor"
        },
        {
            value: "Other",
            label: "Other"
        }
    ],
    morningDeliverys: [
        {
            value: "",
            label: "Select..."
        },
        {
            value: "Y",
            label: "Yes"
        },
        {
            value: "N",
            label: "No"
        },
        {
            value: "O",
            label: "Order Specific"
        }
    ],
    returnLabels: [
        {
            value: "",
            label: "Select..."
        },
        {
            value: "Y",
            label: "Yes"
        },
        {
            value: "N",
            label: "No"
        }
    ],
    emailDeliverys: [
        {
            value: "",
            label: "Select..."
        },
        {
            value: "Attachment",
            label: "Attachment"
        },
        {
            value: "Download",
            label: "Download"
        }
    ]
};

DocumentSpecs.propTypes = {
    disabled: PropTypes.bool,
    dataSource: PropTypes.object,
    onInputChange: PropTypes.func,
    deliverTos: PropTypes.array,
    morningDeliverys: PropTypes.array,
    returnLabels: PropTypes.array,
    emailDeliverys: PropTypes.array
};

export default DocumentSpecs;