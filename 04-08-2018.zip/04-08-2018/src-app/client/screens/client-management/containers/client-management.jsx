import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import ClientAgents from "../components/client-agents";
import ClientContacts from "../components/client-contacts";
import ClientOrders from "../components/client-orders";
import ClientDetails from "../components/client-details";
import ClientSpecific from "./client-specific";
import ClientRecentOrders from "../components/recent-orders";
import ClientFees from "../components/client-fees";
import ClientDoNotUse from "../components/client-do-not-use";
import CommonModal from "CommonModal";
import { connect } from "react-redux";
import { showSuccess, showError } from "../../main-layout/actions";
import { SUCCESSFULLY_SAVED_MESSAGE, CLIENT_ERROR_REQUIRED_SAVE } from "Constants";
import { apiUpdateClientIsAvailable } from "Api/clients-api";
import ClientHybridTab from "../components/client-hybrid-tab";
import ClientOrderAssignmentConfig from "./../../client-order-assignment-configuration/containers/index";
import { deepClone } from "../../../helpers/common-helper";
import { apiSendMailUpdateInfoClient } from "../../../api/broker-api";
import VendorAttachment from "../components/vendor-attachment";

class ClientManagement extends Component {

    constructor(props) {
        super(props);
        this.state = {
            tabs: [
                { title: "General", isActive: true },
                { title: "Contacts", isActive: false },
                { title: "Agents", isActive: false },
                { title: "Hybrid Questions", isActive: false },
                { title: "Specifics", isActive: false },
                { title: "Recent Orders", isActive: false },
                { title: "Client Fees", isActive: false },
                { title: "Orders", isActive: false },
                { title: "\"Do not Use\" Vendors", isActive: false },
                { title: "Order Assignment Configuration", isActive: false },
                { title: "Vendor Attachment", isActive: false }
            ],
            brokerId: this.props.params.brokerId,
            editModeConfigTab: false
        };

        this.handleTabClick = this.handleTabClick.bind(this);
        this.isAddMode = Number(this.props.params.brokerId) === 0;
        this.nextStep = 1;
    }

    handleShowConfirm() {
        this.commonModal.showModal({
            type: "confirm",
            message: this.state.brokerId !== "0" ? "Are you sure you want to cancel editing this Client?" :
                "Are you sure you want to cancel adding this Client?"
        }, () => {
            this.props.router.push("/client-management/");
        });
    }

    handleTabClick(tab) {
        const tabs = this.state.tabs;
        let isWaitingGeneralTabSaved = false;
        //validate current form
        for (const index in tabs) {
            const item = tabs[index];
            if (item.isActive && item.title !== tab.title) {
                let isActiveFormValid = true;
                switch (item.title) {
                    case "Contacts":
                        isActiveFormValid = this.clientContact.validateForm(true);
                        this.clientContact.saveChanges(true);
                        break;
                    case "General":
                        isActiveFormValid = this.clientDetails.validateForm();
                        isWaitingGeneralTabSaved = true;
                        this.clientDetails.saveChanges(true,
                            //eslint-disable-next-line
                            () => {
                                if (isWaitingGeneralTabSaved) {
                                    this.setActiveTab(tab);
                                }
                            });
                        break;
                    case "Specifics":
                        isActiveFormValid = this.clientSpecific.validateForm();
                        this.clientSpecific.saveChanges(true);
                        break;
                    case "Hybrid Questions":
                        isActiveFormValid = this.hybridQuest.validateForm();
                        this.hybridQuest.saveChanges();
                        break;
                    case "Order Assignment Configuration":
                        isActiveFormValid = this.orderAsmtConfig.ConfigOption.validateForm();
                        this.orderAsmtConfig.ConfigOption.handleSaveChange(false);
                        if (isActiveFormValid) {
                            this.setState({ editModeConfigTab: false });
                        }
                        break;
                }

                if (!isActiveFormValid) {
                    return;
                }
            }
        }
        if (!isWaitingGeneralTabSaved) {
            this.setActiveTab(tab);
        }
    }

    setActiveTab(tab) {
        const tabs = deepClone(this.state.tabs);
        let hasActiveTab = false;

        tabs.map((item, index) => {
            if (!this.isAddMode) {
                if (item.title === tab.title) {
                    item.isActive = true;
                    hasActiveTab = true;
                } else item.isActive = false;
            } else if (item.title === "Vendor Attachment" && item.title === tab.title) {
                item.isActive = true;
                hasActiveTab = true;
            } else if (item.title === tab.title && index <= this.nextStep) {
                item.isActive = true;
                hasActiveTab = true;
                if (index === this.nextStep) this.nextStep++;
            } else item.isActive = false;

            return item;
        });

        if (!hasActiveTab) {
            tabs[this.nextStep].isActive = true;
            this.nextStep++;
        }

        this.setState({ tabs });
    }

    handleSaveChanges() {
        const tabs = this.state.tabs;
        let isDataTab = false;
        tabs.map(item => {
            if (item.isActive) {
                switch (item.title) {
                    case "Contacts":
                        isDataTab = true;
                        this.clientContact.saveChanges(false);
                        break;
                    case "General":
                        isDataTab = true;
                        this.clientDetails.saveChanges(false);
                        break;
                    case "Specifics":
                        isDataTab = true;
                        this.clientSpecific.saveChanges(false);
                        break;
                    case "Hybrid Questions":
                        isDataTab = true;
                        this.hybridQuest.saveChanges(true);
                        break;
                    default:
                        break;
                }
            }
        });
        if (!isDataTab) {
            if (this.isAddMode) {
                apiUpdateClientIsAvailable(this.state.brokerId, (response) => {
                    if (!response.data.isAvailable) {
                        this.props.dispatch(showError(CLIENT_ERROR_REQUIRED_SAVE));
                    } else {
                        this.props.dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
                        this.isAddMode = false;
                        this.setState();
                    }
                }, (error) => this.props.dispatch(showError(error.message)));
            } else {
                this.props.dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
            }
        }
    }

    sendMailChangeInfo(oldData, newData) {
        if (Number(this.state.brokerId) !== 0) {
            apiSendMailUpdateInfoClient({ brokerId: this.state.brokerId, oldData, newData });
        }
    }

    handleClientNameUpdated(brokerId, clientName) {
        this.setState({ brokerId: brokerId.toString(), clientName });
        this.props.router.push(`/client-detail/${brokerId}`);
    }

    handleBackClientSearch() {
        this.props.router.push("/client-management/");
    }

    handleNextTab() {
        this.handleTabClick({ title: "NextTab" });
    }

    render() {
        const brokerId = this.state.brokerId;
        let isActiveConfigTab = false;
        let isVendorAddtachtionTab = false;


        const renderTabs = () => {
            return this.state.tabs.map((tab, key) => {
                if (this.isAddMode && key > 6 && tab.title !== "Vendor Attachment") {
                    return (
                        <li key={key} className="hidden"></li>
                    );
                } else {
                    const classNameActive = tab.isActive ? "active" : "";
                    const required = tab.title === "General" || tab.title === "Contacts" ? <span className="text-danger">*</span> : "";
                    return (
                        <li onClick={() => {
                            this.handleTabClick(tab);
                        }} key={key} className="tab"
                        ><a className={classNameActive} role="button" key={key}>{tab.title}{required}</a></li>
                    );
                }
            });
        };

        const renderTabContent = () => {
            return this.state.tabs.map((tab) => {
                if (tab.isActive) {
                    switch (tab.title) {
                        case "General":
                            return (
                                <ClientDetails brokerId={Number(brokerId || 0)} onClientNameUpdated={this.handleClientNameUpdated.bind(this)} onBackClientSearch={this.handleBackClientSearch.bind(this)} ref={(clientDetails) => {
                                    if (clientDetails && clientDetails.getWrappedInstance) {
                                        this.clientDetails = clientDetails.getWrappedInstance();
                                    }
                                }}
                                    router={this.props.router}
                                    sendMailChangeInfo={(oldData, newData) => this.sendMailChangeInfo(oldData, newData)}
                                    inAddMode={this.isAddMode}
                                />);
                        case "Agents":
                            return (<ClientAgents brokerId={Number(brokerId || 0)} />);
                        case "Contacts":
                            return (
                                <ClientContacts brokerId={Number(brokerId || 0)} ref={(clientContact) => {
                                    if (clientContact && clientContact.getWrappedInstance) {
                                        this.clientContact = clientContact.getWrappedInstance();
                                    }
                                }}
                                    sendMailChangeInfo={(oldData, newData) => this.sendMailChangeInfo(oldData, newData)}
                                    inAddMode={this.isAddMode}
                                />);
                        case "Specifics":
                            return (
                                <ClientSpecific brokerId={Number(brokerId || 0)} ref={(clientSpecific) => {
                                    if (clientSpecific && clientSpecific.getWrappedInstance) {
                                        this.clientSpecific = clientSpecific.getWrappedInstance();
                                    }
                                }}
                                    sendMailChangeInfo={(oldData, newData) => this.sendMailChangeInfo(oldData, newData)}
                                    inAddMode={this.isAddMode}
                                />);
                        case "Recent Orders":
                            return (<ClientRecentOrders brokerId={Number(brokerId || 0)} />);
                        case "Client Fees":
                            return (<ClientFees brokerId={Number(brokerId || 0)} />);

                        case "Vendor Attachment":
                            isVendorAddtachtionTab = true;
                            return (
                                <VendorAttachment
                                    brokerId={Number(brokerId || 0)}
                                    isAddMode={this.isAddMode}
                                    ref={instance => {
                                        if (instance && instance.getWrappedInstance) {
                                            this.vendorAttachment = instance.getWrappedInstance();
                                        }
                                    }}
                                />
                            );
                        case "Orders":
                            return (<ClientOrders brokerId={Number(brokerId || 0)} />);
                        case "\"Do not Use\" Vendors":
                            return (<ClientDoNotUse brokerId={Number(brokerId || 0)} />);
                        case "Hybrid Questions":
                            return (
                                <ClientHybridTab
                                    brokerId={Number(brokerId || 0)}
                                    dispatch={(action) => this.props.dispatch(action)}
                                    ref={hybridQuest => { this.hybridQuest = hybridQuest; }}
                                    sendMailChangeInfo={(oldData, newData) => this.sendMailChangeInfo(oldData, newData)}
                                    inAddMode={this.isAddMode}
                                />
                            );
                        case "Order Assignment Configuration":
                            isActiveConfigTab = true;
                            return (
                                <ClientOrderAssignmentConfig
                                    staffConfigId={Number(brokerId || 0)}
                                    isStaffConfig
                                    ref={configInstance => {
                                        if (configInstance && configInstance.getWrappedInstance) {
                                            this.orderAsmtConfig = configInstance.getWrappedInstance();
                                        }
                                    }}
                                    setEditMode={mode => this.setState({ editModeConfigTab: mode })}
                                />
                            );
                    }
                }
                return null;
            });
        };

        const renderButton = () => {
            if (isVendorAddtachtionTab) {
                return (
                    <div></div>
                );
            } else if (!isActiveConfigTab) {
                return (
                    <div className="row" style={{ textAlign: "center" }}>
                        <div className="col s12 m3 offset-m6">
                            <button className="btn action-btn default-color w-100" onClick={() => this.handleShowConfirm()}>Cancel</button>
                        </div>
                        {!this.isAddMode || this.nextStep >= 7 ?
                            <div className="col s12 m3">
                                <button className="btn action-btn success-color w-100" onClick={this.handleSaveChanges.bind(this)}>Save</button>
                            </div> :
                            <div className="col s12 m3">
                                <button className="btn action-btn success-color w-100" onClick={this.handleNextTab.bind(this)}>Next</button>
                            </div>
                        }
                    </div>
                );
            } else if (this.state.editModeConfigTab) {
                return (
                    <div className="row">
                        <div className="col s12 m3 offset-m3">
                            <button className="btn action-btn default-color w-100" onClick={() => this.handleShowConfirm()}>Cancel</button>
                        </div>
                        <div className="col s12 m3">
                            <button className="btn action-btn default-color w-100" onClick={() => this.orderAsmtConfig.ConfigOption.handleReset()}>Reset</button>
                        </div>
                        <div className="col s12 m3">
                            <button className="btn action-btn success-color w-100" onClick={() => this.orderAsmtConfig.ConfigOption.handleSaveChange()}>Save</button>
                        </div>
                    </div>
                );
            } else {
                return (
                    <div className="row">
                        <div>
                            <div className="col s12 m3 offset-m6">
                                <button className="btn action-btn default-color w-100" onClick={() => this.handleShowConfirm()}>Cancel</button>
                            </div>
                            <div className="col s12 m3">
                                <button className="btn action-btn success-color w-100" onClick={() => this.orderAsmtConfig.ConfigOption.handleActiveEditMode()}>Edit</button>
                            </div>
                        </div>
                    </div>
                );
            }
        };

        return (
            <div className="col s12 custome-modal">
                <div className="row">
                    <div className="col m12">
                        <h3 className="title-page-detail">
                            {this.state.brokerId === "0" ? "Add Client" : `Client Profile – ${this.state.clientName}`}
                        </h3>
                    </div>
                </div>

                <div className="place-section">
                    <ul className="tabs">
                        {renderTabs()}
                    </ul>
                    {/* <h4>{this.state.clientName}</h4> */}
                    <div className="tab-content">
                        {renderTabContent()}
                    </div>
                    {renderButton()}
                </div>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

ClientManagement.propTypes = {
    params: PropTypes.object,
    router: PropTypes.object,
    dispatch: PropTypes.func
};

export default connect()(ClientManagement);