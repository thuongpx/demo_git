import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import GeneralSpecific from "./../components/spec-general";
import DocumentSpecific from "./../components/spec-document";
import StandardSpecialInstruction from "./../components/spec-standard-special-instructions";
import { getSpecifics } from "../actions/client-specifics-actions";
import { updateSpecifics } from "../actions/client-specifics-actions";
class ClientSpecific extends Component {
    constructor(props) {
        super(props);

        this.state = {
            specifics: {},
            validators: {},
            rawSpecifics: {}

        };
    }
    // life cycle
    componentWillReceiveProps(nextProps) {
        const { specifics, dispatch } = nextProps;
        // 3 _ get local specifics data from new props(after step2)
        //      then set it to local state
        //          now we have independence state
        this.setState({ specifics, rawSpecifics: specifics });
        if (nextProps.brokerId !== this.props.brokerId) {
            dispatch(getSpecifics(nextProps.brokerId, 1));
        }
    }

    componentDidMount() {
        const { dispatch } = this.props;
        // 1 _ get specifics data from db then store data in redux
        dispatch(getSpecifics(this.props.brokerId, 1));
    }
    // input event
    saveChanges(status) {
        if (this.validateForm()) {
            const { specifics } = this.state;
            const { dispatch, profile } = this.props;
            specifics.Completedby = profile.userName;
            // save xuong db su dung specifics o component state
            dispatch(updateSpecifics(specifics, status));
            if (!this.props.inAddMode) {
                this.props.sendMailChangeInfo(this.state.rawSpecifics, this.state.specifics);
                this.setState({ rawSpecifics: this.state.specifics });
            }
        }
    }

    handleInputChange(obj) {
        this.setState({ specifics: { ...this.state.specifics, ...obj } });
    }

    handleValidateChange(obj) {
        this.setState({ validators: { ...this.state.validators, ...obj } });
    }

    validateForm() {
        const { validators } = this.state;
        for (const key in validators) {
            if (validators[key]) {
                return false;
            }
        }
        return true;
    }

    //render
    render() {
        const { specifics, validators } = this.state;

        return (
            <div className="row">
                <div className="col s12 m6">
                    <GeneralSpecific dataSource={specifics}
                        onInputChange={(e) => this.handleInputChange(e)}
                        dataValidate={validators}
                        onValidateChange={(e) => this.handleValidateChange(e)}
                    />
                </div>
                <div className="col s12 m6">
                    <DocumentSpecific dataSource={specifics} onInputChange={(e) => this.handleInputChange(e)} />
                    <StandardSpecialInstruction dataSource={specifics} onInputChange={(e) => this.handleInputChange(e)} />
                </div>
            </div>
        );
    }
}

ClientSpecific.propTypes = {
    dispatch: PropTypes.func.isRequired,
    specifics: PropTypes.object,
    brokerId: PropTypes.number,
    sendMailChangeInfo: PropTypes.func,
    inAddMode: PropTypes.bool,
    profile: PropTypes.object
};
// 2 _ get specifics data from redux then store specifics data to this local props
const mapStateToProps = (state) => {
    const { clientManagement } = state;
    const { authentication } = state;
    const { profile } = authentication;
    const { clientSpecifics } = clientManagement;
    const { specifics } = clientSpecifics;
    return {
        specifics,
        profile
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(ClientSpecific);
