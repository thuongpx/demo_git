import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { loginUser, logoutUser, requestLogin } from "../actions";
import { resetAllReducers } from "../../main-layout/actions";
import { hasStringValue } from "../../../helpers/common-helper";

import LogIn from "../components/login";

class Authentication extends Component {
    constructor(props) {
        super(props);

        const { location } = this.props;
        const { query } = location;
        const { redirect } = query;

        this.state = {
            redirect,
            resetPassword: false,
            userIdResetPassword: 0
        };
    }

    handleLogOut() {
        const { dispatch } = this.props;

        dispatch(logoutUser());
    }

    componentDidMount() {
        const { isAuthenticated } = this.props;
        const { redirect } = this.state;

        if (isAuthenticated && hasStringValue(redirect)) {
            setTimeout(() => {
                this.props.router.replace(redirect);
            }, 500);
        }
    }

    handleSignUp() {
        this.props.router.push("/sign-up");
    }

    handleCancelForgotPassword() {
        this.setState({
            resetPassword: false
        });
    }

    render() {
        const { dispatch, isAuthenticated, errorMessage } = this.props;

        const renderComponents = () => {
            if (!isAuthenticated) {
                return (
                    <div>
                        <LogIn
                            redirectSignUp={() => this.handleSignUp()}
                            securityCode={this.props.location.query.code || null}
                            errorMessage={errorMessage}
                            onLoginClick={creds => {
                                dispatch(requestLogin());
                                dispatch(loginUser(creds, this.props.router, this.state.redirect));
                            }}
                            resetAllReducers={() => dispatch(resetAllReducers())}
                        />
                    </div>
                );
            }

            return <div></div>;
        };

        return (
            <div>
                {renderComponents()}
            </div>
        );
    }
}

Authentication.propTypes = {
    dispatch: PropTypes.func.isRequired,
    isAuthenticated: PropTypes.bool.isRequired,
    errorMessage: PropTypes.string,
    profile: PropTypes.object,
    role: PropTypes.object,
    location: PropTypes.object,
    router: PropTypes.object
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { isAuthenticated, errorMessage, profile, role } = authentication;

    return {
        isAuthenticated,
        errorMessage,
        profile,
        role
    };
};

export default connect(mapStateToProps)(Authentication);