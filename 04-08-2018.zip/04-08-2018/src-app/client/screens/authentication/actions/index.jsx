import { setCookies, removeCookies } from "Helpers/cookies-helper";
import { apiLoginUser, apiLoginAsAnotherUser } from "Api/account-api";
import { decodeJwtToken } from "Helpers/jwt-helper";
import { handleApiError } from "ErrorHandler";
import { getCookies } from "../../../helpers/cookies-helper";
import { setFirstShowHideAnnouncementsByUserId } from "../../client-dashboard/actions/client-announcements";

import { COOKIES_KEY } from "../../../constant/constants";
import { hasStringValue } from "../../../helpers/common-helper";

import { TawkToApi } from "../../../helpers/lib-helper";
import { setIsShowAttentions } from "../../main-layout/actions/index";

export const LOGIN_REQUEST = "LOGIN_REQUEST";
export const LOGIN_SUCCESS = "LOGIN_SUCCESS";
export const LOGIN_FAILURE = "LOGIN_FAILURE";
export const LOGOUT_SUCCESS = "LOGOUT_SUCCESS";
export const LOGIN_RECEIVE = "LOGIN_RECEIVE";
export const LOGIN_AS_ANOTHER_USER_REQUEST = "LOGIN_REQUEST";
export const LOGIN_AS_ANOTHER_USER_SUCCESS = "LOGIN_SUCCESS";
export const CANCEL_SUPERVISOR_PROCESS_FAILED = "CANCEL_SUPERVISOR_PROCESS_FAILED";

export const requestLogin = () => {
  return {
    type: LOGIN_REQUEST,
    isFetching: true,
    isAuthenticated: false
  };
};

export const receiveLogin = () => {
  return {
    type: LOGIN_RECEIVE,
    isFetching: false
  };
};

export const finishLogin = (token, scope, supervisor) => {
  if (!supervisor || supervisor.id === 0) {
    supervisor = null;
  }

  setCookies(COOKIES_KEY.CE_AUTHENTICATION_USER, {
    profile: scope.profile,
    role: scope.role,
    accountId: scope.id,
    userId: scope.profile.id,
    tenantId: scope.tenantId,
    supervisor
  });

  // success
  setCookies(COOKIES_KEY.CE_ACCESS_TOKEN, token);

  return {
    type: LOGIN_SUCCESS,
    isFetching: false,
    isAuthenticated: true,
    data: scope
  };
};

export const receiveLoginError = () => {
  return {
    type: LOGIN_FAILURE,
    isFetching: false,
    isAuthenticated: false
  };
};

export const logout = () => {
  return {
    type: LOGOUT_SUCCESS
  };
};

export const logoutUser = () => {
  return () => {
    // remove cookies
    removeCookies(COOKIES_KEY.CE_ACCESS_TOKEN);
    removeCookies(COOKIES_KEY.CE_AUTHENTICATION_USER);

    window.location.href = "/";
  };
};

const doAfterLogin = (result, router, dispatch, redirect, hasRemotedSupervisor, needReload) => {
  if (result.isLogged) {
    let redirectRoute = "/";

    // redirect route
    if (result.response && (result.response.isNeedToResetPassword || result.response.isExpiredPassword)) {
      // user needs to change password
      window._temporaryToken = result.response.tempToken;
      redirectRoute = `/change-password?userId=${result.userId}&isExpired=${result.response.isExpiredPassword}&token=${window._temporaryToken}&isNeedSetSecQuestion=${result.response.isNeedToSetChallengeQuestion}`;
    } else if (result.response && result.response.isNeedToSetChallengeQuestion) {
      // user needs to set security question
      window._temporaryToken = result.response.tempToken;
      redirectRoute = `/challenge-question?userId=${result.userId}&token=${window._temporaryToken}`;
    } else if (result.response && !result.response.isChallengeQuestionConfirmed) {
      window._temporaryToken = result.response.tempToken;
      redirectRoute = `/challenge-question?userId=${result.userId}&token=${window._temporaryToken}&isNeedConfirm=true`;
    } else if (result.response && result.response.isSignerFirstLogin && !result.response.allowVendorLogin) {
      window._temporaryToken = result.response.tempToken;
      redirectRoute = `/sign-up?userId=${result.userId}&token=${window._temporaryToken}&signerId=${result.response.signerId}`;
    } else if (result.isUserFirstLogin) {
      redirectRoute = "/dashboard?firstLogin=true";
    } else if (redirect !== undefined && redirect !== null && redirect !== "") {
      redirectRoute = redirect;
    }

    // update reducers
    dispatch(setIsShowAttentions(result.isShowAttentions));
    dispatch(setFirstShowHideAnnouncementsByUserId(true));
    dispatch(receiveLogin());

    setTimeout(() => {
      if (hasRemotedSupervisor || needReload) {
        window.location.href = redirectRoute;
      } else {
        router.push(redirectRoute);
      }
    }, 500);
  }
};

export const loginUser = (creds, router, redirect, needReload) => {
  return dispatch => {
    // before start a call, notice users that they need to wait
    return apiLoginUser(creds, (result) => {
      const data = result.data;
      let user = null;
      let supervisor = data.supervisor;

      if (hasStringValue(result.data.accessToken)) {
        user = decodeJwtToken(result.data.accessToken);
      }

      if (!supervisor || (Object.keys(supervisor).length === 0 && supervisor.constructor === Object)) {
        supervisor = null;
      }

      // check if this user is remoted by another user
      const hasRemotedSupervisor = (supervisor && supervisor.id > 0);
      // check if user need to answers challenge questions
      const isChallengeQuestionConfirmed = getCookies(`${COOKIES_KEY.CE_CHALLENGE_QUESTION_CONFIRMED}-${(data.usersId || user.scope.id)}`);

      const isSignerFirstLogin = creds.isLoginSuccess === undefined ? data.isSignerFirstLogin : false;

      // build condition of login validation
      const hasProblem = !hasRemotedSupervisor &&
        (data.isNeedToResetPassword || data.isExpiredPassword || data.isNeedToSetChallengeQuestion || !isChallengeQuestionConfirmed || (isSignerFirstLogin && !data.allowVendorLogin));

      if (data !== null) {
        if (hasProblem) {
          doAfterLogin({
            isLogged: true,
            userId: data.usersId || user.scope.id,
            response: {
              isNeedToResetPassword: data.isNeedToResetPassword,
              isExpiredPassword: data.isExpiredPassword,
              isNeedToSetChallengeQuestion: data.isNeedToSetChallengeQuestion,
              isChallengeQuestionConfirmed,
              isSignerFirstLogin,
              allowVendorLogin: data.allowVendorLogin,
              tempToken: data.tempToken,
              signerId: data.signerId
            }
          }, router, dispatch, redirect);
        } else {
          // log in successfully
          switch (user.scope.role.roleType) {
            case "Vendor":
              doAfterLogin({ isLogged: true, isShowAttentions: data.isShowAttentions || false }, router, dispatch, redirect, hasRemotedSupervisor, needReload);
              break;
            case "Client":
              doAfterLogin({ isLogged: true, isUserFirstLogin: data.isFirstLogin }, router, dispatch, redirect, hasRemotedSupervisor, needReload);
              break;
            default:
              doAfterLogin({ isLogged: true, isFirstLogin: false }, router, dispatch, redirect, hasRemotedSupervisor, needReload);
              break;
          }

          dispatch(finishLogin(result.data.accessToken, user.scope, supervisor));
          TawkToApi.setUpTawkToClient(result.data.tawkToHash, user.scope.profile, user.scope.role.roleType);
        }
      } else {
        dispatch(receiveLoginError());
      }
    }, error => {
      handleApiError(dispatch, error);
      dispatch(receiveLoginError());
    });
  };
};

export const startLoginAsAnotherUser = () => {
  return {
    type: LOGIN_AS_ANOTHER_USER_REQUEST
  };
};

export const doneLoginAsAnotherUser = () => {
  return {
    type: LOGIN_AS_ANOTHER_USER_SUCCESS
  };
};

export const loginAsAnotherUser = (targetUserId, router, targetPrimaryId = -1) => {
  return (dispatch, getState) => {
    // dispatch(startLoginAsAnotherUser());

    const { authentication } = getState();
    const { accountId } = authentication;

    return apiLoginAsAnotherUser({ targetUserId, currentUserId: accountId }, result => {
      const { temporaryToken, currentUsername, targetUsername } = result.data;

      // verify and generate a unique token
      // dispatch(doneLoginAsAnotherUser());
      // start a new session for new user
      dispatch(loginUser({
        userId: targetUserId,
        tempToken: temporaryToken,
        isLoginAsAnotherUser: true,
        supervisor: {
          id: accountId,
          username: currentUsername,
          targetUsername,
          targetId: targetUserId,
          targetPrimaryId
        }
      }, router, "/"));
    }, err => handleApiError(dispatch, err));
  };
};

export const cancelSupervisorProcess = (router, redirectRoute) => {
  return (dispatch, getState) => {
    const { authentication } = getState();
    const { supervisor, accountId } = authentication;

    if (supervisor !== null) {
      // login as a normal user and return him to the vendor profile page
      return apiLoginAsAnotherUser({ targetUserId: supervisor.id, currentUserId: accountId }, result => {
        const { temporaryToken } = result.data;

        // verify and generate a unique token
        // start a new session for new user
        dispatch(loginUser({
          userId: supervisor.id,
          tempToken: temporaryToken
        }, router, redirectRoute, true));
      }, err => handleApiError(dispatch, err));
    } else {
      return dispatch({
        type: CANCEL_SUPERVISOR_PROCESS_FAILED
      });
    }

  };
};
