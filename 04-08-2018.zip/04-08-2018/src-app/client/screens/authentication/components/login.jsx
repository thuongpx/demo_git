import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router";
import { updateTextFields } from "../../../helpers/theme-helper";
import { LOGO_2X_IMAGE_URL } from "ImageConfig";
import { INPUT_MISSING_1X_IMAGE_URL } from "../../../config/img.config";
import ForgotPassword from "./forgot-password";
import { requireMessage, validateRequired, hasStringValue } from "../../../helpers/validation-helper";
// import Loader from "../../../features/loader";

class LogIn extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modalForgotPassword: this.props.securityCode !== null && this.props.securityCode !== undefined && this.props.securityCode !== "",
            invalidField: {},
            inputs: {},
            isDirty: false
        };
    }

    handleSubmitLogin(event) {
        event.preventDefault();
        const { onLoginClick, resetAllReducers } = this.props;

        const creds = {
            username: this.refs.username.value.trim(),
            password: this.refs.password.value.trim()
        };

        if (this.validateForm()) {
            // reset all reducers
            resetAllReducers();
            onLoginClick(creds);
        }
    }

    handleSignUpClick(event) {
        event.preventDefault();

        // redirect to another page
    }

    validateForm() {
        const invalidField = {};
        invalidField.username = !validateRequired(this.refs.username.value.trim());
        invalidField.password = !validateRequired(this.refs.password.value);

        this.setState({ invalidField });

        for (const key in invalidField) {
            if (invalidField[key]) {
                return false;
            }
        }

        return true;
    }

    validateField(value, fieldName) {
        const { invalidField, inputs, isDirty } = this.state;

        if (!value.trim() && hasStringValue(fieldName)) {
            invalidField[fieldName] = true;
        } else {
            invalidField[fieldName] = false;
        }

        if (!isDirty && fieldName === "username" && value) {
            setTimeout(() => {
                $("#lblPassword").addClass("active");
            }, 100);
        }

        inputs[fieldName] = value;

        this.setState({ invalidField, inputs, isDirty: true });
    }

    componentDidUpdate() {
        updateTextFields();
    }

    // componentWillReceiveProps(nextProps) {
    //     if (nextProps.isLoginError) {
    //         this.refs.username.value = "";
    //         this.refs.password.value = "";
    //         $("#username").focus();
    //     }

    //     if (nextProps.isLoginIn) {
    //         $("#login-form input").prop("disabled", true);
    //     } else {
    //         $("#login-form input").prop("disabled", false);
    //     }
    // }

    handleEnterPress(e) {
        if (e.key === "Enter") {
            this.handleSubmitLogin(e);
        }
    }

    handleOpenForgotPassword() {
        this.setState({
            modalForgotPassword: true
        });
    }

    handleCancelForgotPassword() {
        this.setState({
            modalForgotPassword: false
        });
    }

    render() {
        const { isLoginIn } = this.props;
        const { invalidField, inputs } = this.state;

        return (
            <div className="login-section">
                <div className="row">
                    <form id="login-form" className="col s12 m5 offset-m4 custome-mg" onSubmit={(event) => this.handleSubmitLogin(event)}>
                        <img src={LOGO_2X_IMAGE_URL} alt="" className="responsive-img" />

                        <div className="card ml-1 mr-1">
                            <div className="card-content">
                                <h4 className="bold-5 font-31 title-dark-style">Login</h4>
                                <h5 className="bold-5 font-17 main-header-dark-style">Let’s schedule an appointment today!</h5>

                                <div className="row">
                                    <div className={`input-field required suffixinput col s12 ${invalidField.username ? "required-field" : ""}`}>
                                        <input value={inputs.username} onChange={(e) => this.validateField(e.target.value, "username")} disabled={isLoginIn} ref="username" type="text" id="username" className="validate" onKeyPress={(e) => this.handleEnterPress(e)} />
                                        <label htmlFor="username">Username</label>
                                        <span className={`suffix-text ${invalidField.username ? "" : "hide"}`}>
                                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Username")} />
                                        </span>
                                    </div>
                                </div>

                                <div className="row">
                                    <div className={`input-field required suffixinput col s12 ${invalidField.password ? "required-field" : ""}`}>
                                        <input value={inputs.password} onChange={(e) => this.validateField(e.target.value, "password")} disabled={isLoginIn} ref="password" type="password" id="password" autoComplete="off" className="validate" onKeyPress={(e) => this.handleEnterPress(e)} />
                                        <label id="lblPassword" htmlFor="password">Password</label>
                                        <span className={`suffix-text ${invalidField.password ? "" : "hide"}`}>
                                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Password")} />
                                        </span>
                                    </div>
                                </div>

                                <div className="control-action">
                                    <div className="row">
                                        <div className="col s6 m6">
                                            <a role="button" className="font-11 line-height-35" disabled={isLoginIn} onClick={() => this.handleOpenForgotPassword()}>Forgot password?</a>
                                        </div>

                                        <div className="col s6 m6">
                                            <button type="button" disabled={isLoginIn} onClick={(event) => this.handleSubmitLogin(event)} className="btn success-color right w-100"> LOGIN</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="row mt-3 ">
                            <div className="col s12">
                                <p className="center-align small-font">New here?</p>
                            </div>
                        </div>

                        <div className="row mt-2 pl-1 pr-1">
                            <div className="col s12">
                                <Link to={"/sign-up"} disabled={isLoginIn}><button className="btn w-100 default-color">SIGN-UP!</button>
                                </Link>
                            </div>
                        </div>
                    </form>

                    <ForgotPassword securityCode={this.props.securityCode || null} isOpen={this.state.modalForgotPassword} handleCancelForgotPassword={() => this.handleCancelForgotPassword()} />
                </div>
            </div >
        );
    }
}

LogIn.propTypes = {
    dispatch: PropTypes.func,
    onLoginClick: PropTypes.func.isRequired,
    errorMessage: PropTypes.string,
    isLoginError: PropTypes.bool,
    isLoginIn: PropTypes.bool,
    securityCode: PropTypes.string,
    resetAllReducers: PropTypes.func
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { isLoginError, isFetching } = authentication;

    return {
        isLoginError,
        isLoginIn: isFetching
    };
};

export default connect(mapStateToProps)(LogIn);