import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";

import { validateRequired, validatePassword, validateCompare, requireMessage, comparePasswordMessage, invalidPasswordMessage } from "Helpers/validation-helper";
import { INPUT_MISSING_1X_IMAGE_URL, INPUT_ERROR_1X_IMAGE_URL } from "ImageConfig";
import CommonModal from "CommonModal";

import { apiResetUserPassword } from "../../../api/user-api";

class ResetPassword extends Component {
    constructor(props) {
        super(props);
        this.state = {
            password: "",
            verifyPassword: "",
            validator: {
                isRequiredPassword: true,
                isValidPassword: true,
                isRequiredVerifyPassword: true,
                isValidVerifyPassword: true
            }
        };
    }

    handleCancel() {
        this.setState({
            password: "",
            verifyPassword: "",
            validator: {
                isRequiredPassword: false,
                isValidPassword: true,
                isRequiredVerifyPassword: false,
                isValidVerifyPassword: true
            }
        });
        this.props.cancel();
    }

    handleInputChange(name, value) {
        if (name === "password") {
            this.setState({
                password: value
            });
        } else {
            this.setState({
                verifyPassword: value
            });
        }
    }

    validatePasswordField() {
        const { password, validator } = this.state;
        let isValidate = true;

        if (!validateRequired(password)) {
            if (!validatePassword(password)) {
                isValidate = false;
            }
        } else {
            isValidate = false;
        }

        this.setState({
            validator: {
                ...validator,
                isRequiredPassword: validateRequired(password),
                isValidPassword: validatePassword(password)
            }
        });
        return isValidate;
    }

    validateVerifyPasswordField() {
        const { password, verifyPassword, validator } = this.state;
        let isValidate = true;

        if (!validateRequired(verifyPassword)) {
            if (!validateCompare(password, verifyPassword)) {
                isValidate = false;
            }
        } else {
            isValidate = false;
        }

        this.setState({
            validator: {
                ...validator,
                isRequiredVerifyPassword: validateRequired(verifyPassword),
                isValidVerifyPassword: validateCompare(password, verifyPassword)
            }
        });
        return isValidate;
    }

    validateForm() {
        this.validatePasswordField();
        this.validateVerifyPasswordField();

        const { validator } = this.state;

        for (const key in validator) {
            if (!validator[key]) {
                return false;
            }
        }

        return true;
    }

    handleChange() {
        if (this.validateForm()) {
            const params = {
                userId: this.props.userId,
                password: this.state.password
            };

            apiResetUserPassword(params, (result) => {
                if (result.data.isSuccess) {
                    this.commonModal.showModal({ message: `Password changed successfully, please do login again.` });
                    this.handleCancel();
                }
            }, () => { });
        }
    }

    render() {
        const { isOpen } = this.props;
        const { password, verifyPassword, validator } = this.state;

        return (
            <div>
                <Modal isOpen={isOpen} fixedFooter={false} addClass="no-tab">
                    <ModalBody>
                        <ModalTitle>Change Password</ModalTitle>
                        <div className="col s12 p-0">
                            <div className="row">
                                <div className="col s12">
                                    Please change your password in order to login to your account.
                                </div>
                            </div>
                            <div className="row">
                                <div className={`input-field col s12 required suffixinput ${!validator.isRequiredPassword ? "required-field" : ""} ${!validator.isValidPassword ? "has-error" : ""}`}>
                                    <input type="password" maxLength="75" id="password" ref="password"
                                        value={password}
                                        onChange={(e) => this.handleInputChange("password", e.target.value)}
                                        onBlur={() => this.validatePasswordField()}
                                    />
                                    <label htmlFor="password">New Password</label>
                                    <span className={`suffix-text ${!validator.isRequiredPassword ? "" : "hide"}`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("New Password")} />
                                    </span>
                                    <span className={`suffix-text ${!validator.isValidPassword ? "" : "hide"}`}>
                                        <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidPasswordMessage("New Password")} />
                                    </span>
                                </div>
                            </div>
                            <div className="row">
                                <div className={`input-field col s12 required suffixinput ${!validator.isRequiredPassword ? "required-field" : ""} ${!validator.isValidVerifyPassword ? "has-error" : ""}`}>
                                    <input type="password" maxLength="75" id="verify-password" ref="verifyPassword"
                                        value={verifyPassword}
                                        onChange={(e) => this.handleInputChange("verifyPassword", e.target.value)}
                                        onBlur={() => this.validateVerifyPasswordField()}
                                    />
                                    <label htmlFor="verify-password">Verify Password</label>
                                    <span className={`suffix-text ${!validator.isRequiredVerifyPassword ? "" : "hide"}`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Verify Password")} />
                                    </span>
                                    <span className={`suffix-text ${!validator.isValidVerifyPassword ? "" : "hide"}`}>
                                        <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={comparePasswordMessage("New Password", "Verify Password")} />
                                    </span>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col m6">
                                <button className="btn white w-100" onClick={() => this.handleCancel()}>Cancel</button>
                            </div>
                            <div className="col m6">
                                <button className="btn success-color w-100" onClick={() => this.handleChange()}>Change Password</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

ResetPassword.propTypes = {
    isOpen: PropTypes.bool,
    cancel: PropTypes.func,
    userId: PropTypes.number
};

export default connect()(ResetPassword);