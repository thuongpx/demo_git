import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";

import { apiCheckUserCreds, apiSendForgotPasswordEmail, apiCheckForgotPasswordSecurityCode, apiChangeUserPassword } from "../../../api/user-api";
import { apiGetSecQuestionsForDropdown, apiGetUserSecQuestion, apiCheckUserSecAnswer } from "../../../api/sec-api";
import { APP_URL } from "../../../config/config";

import { validateRequired, validateEmail, requireMessage, validatePassword, validateCompare } from "Helpers/validation-helper";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import CommonModal from "CommonModal";

import PasswordPopover from "../../../features/password-popover/password-popover";
import { hasStringValue } from "Helpers/common-helper";

import { showSuccess } from "../../main-layout/actions";

class ForgotPassword extends Component {
    constructor(props) {
        super(props);
        this.state = {
            secQuestion: [],
            creds: "",
            securityCode: "",
            isValidated: true,
            isFirstInput: true,
            isSecurityCodeInput: false,
            isQuestionInput: false,
            isPasswordInput: false,
            email: "",
            userId: 0,
            username: "",
            questionId: 0
        };
        if (this.props.securityCode !== null && this.props.securityCode !== undefined && this.props.securityCode !== "") {
            this.state = {
                ...this.state,
                isFirstInput: false,
                isSecurityCodeInput: true,
                isQuestionInput: false,
                isPasswordInput: false,
                securityCode: this.props.securityCode
            };
        }
    }

    componentWillUnmount() {
        this.setState({
            securityCode: ""
        });
    }

    componentDidMount() {
        apiGetSecQuestionsForDropdown((result) => {
            //eslint-disable-next-line
            this.setState({
                secQuestion: result.data
            });
        }, () => { });
    }

    handleInputChange(code, value) {
        if (!code) {
            this.setState({
                creds: value
            });
        } else {
            this.setState({
                securityCode: value
            });
        }
    }

    handleValidateInput() {
        if (validateRequired(this.state.creds.trim())) {
            this.setState({
                isValidated: true
            });
            return true;
        } else {
            this.refs.creds.focus();
            this.setState({
                isValidated: false
            });
            return false;
        }
    }

    handleValidateCode() {
        if (validateRequired(this.state.securityCode.trim())) {
            this.setState({
                isValidated: true
            });
            return true;
        } else {
            this.refs.securityCode.focus();
            this.setState({
                isValidated: false
            });
            return false;
        }
    }

    handleCancel() {
        if (this.state.isSecurityCodeInput) {
            this.setState({
                creds: "",
                securityCode: "",
                isValidated: true,
                isFirstInput: true,
                isSecurityCodeInput: false,
                isQuestionInput: false,
                isPasswordInput: false
            });
        } else if (this.state.isQuestionInput) {
            this.setState({
                creds: "",
                securityCode: "",
                isValidated: true,
                isFirstInput: true,
                isSecurityCodeInput: false,
                isQuestionInput: false,
                isPasswordInput: false
            });
        } else if (this.state.isPasswordInput) {
            this.setState({
                creds: "",
                securityCode: "",
                isValidated: true,
                isFirstInput: true,
                isSecurityCodeInput: false,
                isQuestionInput: false,
                isPasswordInput: false
            });
        } else {
            this.setState({
                creds: "",
                securityCode: "",
                isValidated: true,
                isFirstInput: true,
                isSecurityCodeInput: false,
                isQuestionInput: false,
                isPasswordInput: false
            });
            this.props.handleCancelForgotPassword();
        }
    }

    handleSecurityCodeInput() {
        this.setState({
            creds: "",
            isValidated: true,
            isSecurityCodeInput: true
        });
    }

    handleSearch() {
        if (this.handleValidateInput()) {
            apiCheckUserCreds(this.state.creds, (result) => {
                if (result.data.total === 0) {
                    this.commonModal.showModal({ type: "error", message: "The information provided was not found in our system. Please try using an alternate search criteria." }, null, true);
                } else if (result.data.total === 1) {
                    apiGetUserSecQuestion(result.data.userId, (question) => {
                        if (question.data.id === -1) {
                            this.commonModal.showModal({ type: "error", message: `We found the following Username: ${result.data.username}. However, this user does not have a challenge question, to continue please call us to assist you at: 833-432-4321.` }, null, true);
                        } else {
                            this.setState({
                                isFirstInput: false,
                                isQuestionInput: true,
                                isSecurityCodeInput: false,
                                isPasswordInput: false,
                                userId: result.data.userId,
                                username: result.data.username,
                                email: result.data.email,
                                questionId: question.data.id
                            });
                        }
                    }, () => { });
                } else if (validateEmail(this.state.creds)) {
                    this.commonModal.showModal({ type: "error", message: "There are multiple users with the email address you entered. Please try again using other criteria or call us to assist you at: 833-432-4321." }, null, true);
                } else {
                    this.commonModal.showModal({ type: "error", message: "There are multiple users with the name you entered. Please try again using other criteria or call us to assist you at: 833-432-4321." }, null, true);
                }
            }, () => { });
        }
    }

    handleContinue() {
        if (this.handleValidateCode()) {
            apiCheckForgotPasswordSecurityCode(this.state.securityCode, (result) => {
                if (result.data.isValid) {
                    this.setState({
                        isFirstInput: false,
                        isQuestionInput: false,
                        isSecurityCodeInput: false,
                        isPasswordInput: true,
                        userId: result.data.userId,
                        username: result.data.username
                    });
                } else if (result.data.isExpired) {
                    this.commonModal.showModal({ type: "error", message: "This function Timed Out - Please Start Over." }, null, true);
                } else {
                    this.commonModal.showModal({ type: "error", message: "Invalid Security Code, please enter again." }, null, true);
                }
            }, () => { });
        }
    }

    handleCheckAnswer() {
        if (hasStringValue(this.refs.secAnswer.value)) {
            apiCheckUserSecAnswer(this.state.userId, this.refs.secAnswer.value, (result) => {
                if (result.data.isValid) {
                    const params = {
                        userId: this.state.userId,
                        email: this.state.email,
                        url: APP_URL
                    };
                    apiSendForgotPasswordEmail(params, () => { }, () => { });
                    this.commonModal.showModal({ message: `We have sent an email to ${this.state.email}, read and follow the reset password instruction in that email.` }, null, null, true);

                    this.setState({
                        creds: "",
                        isValidated: true,
                        isFirstInput: false,
                        isQuestionInput: false,
                        isSecurityCodeInput: true,
                        isPasswordInput: false
                    });
                } else {
                    this.commonModal.showModal({ type: "error", message: "You answered incorrectly. Please try again." }, null, true);
                }
            }, () => { });
        } else {
            this.commonModal.showModal({ type: "error", message: "You must answer a question." }, null, true);
        }
    }

    handleSaveChanges() {
        if (hasStringValue(this.refs.password.value) && hasStringValue(this.refs.verifyPassword.value)) {
            if (!validatePassword(this.refs.password.value)) {
                this.commonModal.showModal({ type: "error", message: "Your Password must follow the Password Policy. Please enter again!" }, null, true);
            } else if (!validateCompare(this.refs.password.value, this.refs.verifyPassword.value)) {
                this.commonModal.showModal({ type: "error", message: "The 'Password' and 'Re-type New Password' do not match." }, null, true);
            } else {
                const params = {
                    userId: this.state.userId,
                    password: this.refs.password.value
                };
                apiChangeUserPassword(params, (result) => {
                    if (result) {
                        const { dispatch } = this.props;
                        dispatch(showSuccess("Password Successfully Reset – Please Login."));

                        this.setState({
                            creds: "",
                            isValidated: true,
                            isFirstInput: true,
                            isSecurityCodeInput: false,
                            isQuestionInput: false,
                            isPasswordInput: false
                        });
                        this.props.handleCancelForgotPassword();
                    }
                }, () => { });
            }
        } else {
            this.commonModal.showModal({ type: "error", message: "Please enter password & re-type password field." }, null, true);
        }
    }

    render() {
        const { isOpen } = this.props;
        const { creds, isSecurityCodeInput, isValidated } = this.state;

        const renderInput = () => {
            console.log(isSecurityCodeInput);
            if (isSecurityCodeInput) {
                return (
                    <div className={`input-field col s12 required suffixinput ${isValidated ? "" : "required-field"}`}>
                        <input type="text" maxLength="6" ref="securityCode" value={this.state.securityCode || ""} onChange={(event) => this.handleInputChange(true, event.target.value)} onBlur={() => this.handleValidateCode()} id="securityCode" placeholder="Enter Security Code" />
                        <span className={`suffix-text ${isValidated ? "hide" : ""}`}>
                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Security Code")} />
                        </span>
                    </div>
                );
            } else {
                return (
                    <div className={`input-field col s12 required suffixinput ${isValidated ? "" : "required-field"}`}>
                        <input type="text" ref="creds" value={creds || ""} maxLength={250} onChange={(event) => this.handleInputChange(false, event.target.value)} onBlur={() => this.handleValidateInput()} id="creds" placeholder="Enter Username, Full Name or Email Address" />
                        <span className={`suffix-text ${isValidated ? "hide" : ""}`}>
                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Username, Full Name or Email Address")} />
                        </span>
                    </div>
                );
            }
        };

        if (this.state.isFirstInput || this.state.isSecurityCodeInput) {
            return (
                <div>
                    <Modal isOpen={isOpen} fixedFooter={false} addClass="no-tab">
                        <ModalBody>
                            <ModalTitle>Forgot Password</ModalTitle>
                            <div className="col s12 p-0">
                                <div className="row">
                                    <div className="col s12">
                                        {!isSecurityCodeInput && `Please complete the following form so that we can assist you in accessing your account.`}
                                        {isSecurityCodeInput && `Please enter the Security code listed in the email you received, in order to reset your password.`}
                                    </div>
                                    {renderInput()}
                                    {!isSecurityCodeInput && <div className="col s12 center-align mt-2">
                                        <a href="#" onClick={() => this.handleSecurityCodeInput()}>If you already have a security code, please click here</a>
                                    </div>}
                                </div>
                            </div>
                        </ModalBody>
                        <ModalFooter>
                            <div className="row m-0">
                                <div className="col m6">
                                    <button className="btn white w-100" onClick={() => this.handleCancel()}>Cancel</button>
                                </div>
                                <div className="col m6">
                                    {!isSecurityCodeInput && <button className="btn success-color w-100" onClick={() => this.handleSearch()}>Search</button>}
                                    {isSecurityCodeInput && <button className="btn success-color w-100" onClick={() => this.handleContinue()}>Continue</button>}
                                </div>
                            </div>
                        </ModalFooter>
                    </Modal>
                    <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
                </div>
            );
        } else if (this.state.isQuestionInput) {
            return (
                <div>
                    <Modal isOpen={isOpen} fixedFooter={false} addClass="no-tab">
                        <ModalBody>
                            <ModalTitle>Forgot Password</ModalTitle>
                            <div className="col s12 p-0">
                                <div className="row">
                                    <div className="col s12">
                                        <p>We found the following Username: {this.state.username}.</p>
                                        <p>To ensure your identify, please answer the following Challenge Question.</p>
                                    </div>
                                    <div className="col s10 mt-1 ml-2">
                                        <p><strong>Question</strong></p>
                                        <p>{this.state.secQuestion[this.state.questionId - 1].Question}</p>
                                        <p><strong>Answer</strong></p>
                                        <p><input type="text" ref="secAnswer" placeholder="Enter your answer" /></p>
                                    </div>
                                </div>
                            </div>
                        </ModalBody>
                        <ModalFooter>
                            <div className="row m-0">
                                <div className="col m6">
                                    <button className="btn white w-100" onClick={() => this.handleCancel()}>Cancel</button>
                                </div>
                                <div className="col m6">
                                    <button className="btn success-color w-100" onClick={() => this.handleCheckAnswer()}>Continue</button>
                                </div>
                            </div>
                        </ModalFooter>
                    </Modal>
                    <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
                </div>
            );
        } else {
            return (
                <div>
                    <Modal isOpen={isOpen} fixedFooter={false} addClass="no-tab">
                        <ModalBody>
                            <ModalTitle>Forgot Password</ModalTitle>
                            <div className="col s12 p-0">
                                <div className="row">
                                    <div className="col s12">
                                        <p>Complete the following to reset the password for username: {this.state.username}.</p>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col s6 input-field required suffixinput">
                                        <input id="password" type="password" ref="password" />
                                        <label htmlFor="password">Enter New Password</label>
                                        <PasswordPopover classNameAdded="mr-2" />
                                    </div>
                                    <div className="col s6 input-field required suffixinput">
                                        <input id="verify-password" type="password" ref="verifyPassword" />
                                        <label htmlFor="verify-password">Re-type New Password</label>
                                    </div>
                                </div>
                            </div>
                        </ModalBody>
                        <ModalFooter>
                            <div className="row m-0">
                                <div className="col m6">
                                    <button className="btn white w-100" onClick={() => this.handleCancel()}>Cancel</button>
                                </div>
                                <div className="col m6">
                                    <button className="btn success-color w-100" onClick={() => this.handleSaveChanges()}>Save Changes</button>
                                </div>
                            </div>
                        </ModalFooter>
                    </Modal>
                    <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
                </div>
            );
        }
    }
}

ForgotPassword.propTypes = {
    dispatch: PropTypes.func.isRequired,
    isOpen: PropTypes.bool,
    handleCancelForgotPassword: PropTypes.func,
    securityCode: PropTypes.string
};

export default connect()(ForgotPassword);