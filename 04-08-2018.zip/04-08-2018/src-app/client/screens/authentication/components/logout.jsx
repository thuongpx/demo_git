import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";

class LogOut extends Component {
    render() {
        const { onLogOut } = this.props;

        return (
            <div className="row">
                <button type="button" className="btn success-color action-btn mt-2" onClick={() => onLogOut()}>Log Out</button>
            </div>
        );
    }
}

LogOut.propTypes = {
    onLogOut: PropTypes.func
};

export default LogOut;