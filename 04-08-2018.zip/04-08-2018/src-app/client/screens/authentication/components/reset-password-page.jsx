import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { validateRequired, validatePassword, validateCompare, requireMessage, comparePasswordMessage, invalidPasswordMessage } from "Helpers/validation-helper";
import { INPUT_MISSING_1X_IMAGE_URL, INPUT_ERROR_1X_IMAGE_URL, LOGO_2X_IMAGE_URL } from "ImageConfig";

import { apiChangeUserPassword, apiCheckResetPasswordSecurityCode } from "../../../api/user-api";
import CommonModal from "CommonModal";
import { showError, showSuccess } from "../../main-layout/actions";

class ResetPasswordPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            password: "",
            verifyPassword: "",
            validator: {},
            securityCode: this.props.params.securityCode
        };
    }

    handleValidatePassword() {
        const isPasswordFormatInvalid = this.validatePasswordFormat();
        const isPasswordRequiredInvalid = this.validatePasswordRequired();
        this.setState({ validator: { ...this.state.validator, isPasswordFormatInvalid, isPasswordRequiredInvalid } });
    }

    validatePasswordFormat() {
        const isPasswordFormatInvalid = !validatePassword(this.refs.password.value);
        return isPasswordFormatInvalid;
    }

    validatePasswordRequired() {
        const isPasswordRequiredInvalid = !validateRequired(this.refs.password.value);
        return isPasswordRequiredInvalid;
    }


    handleValidateConfirmPassword() {
        const isConfirmPasswordCompareInvalid = this.validateConfirmPasswordCompare();
        const isConfirmPasswordRequiredInvalid = this.validateConfirmPasswordRequired();
        this.setState({ validator: { ...this.state.validator, isConfirmPasswordRequiredInvalid, isConfirmPasswordCompareInvalid } });
    }

    validateConfirmPasswordRequired() {
        const isConfirmPasswordRequiredInvalid = !validateRequired(this.refs.confirmPassword.value);
        return isConfirmPasswordRequiredInvalid;
    }

    validateConfirmPasswordCompare() {
        const isConfirmPasswordCompareInvalid = !validateCompare(this.refs.password.value, this.refs.confirmPassword.value);
        return isConfirmPasswordCompareInvalid;
    }

    handlePasswordChanged() {
        this.setState({ password: this.refs.password.value });
    }

    handleConfirmPasswordChanged() {
        this.setState({ verifyPassword: this.refs.confirmPassword.value });
    }

    validateForm() {

        const isPasswordFormatInvalid = this.validatePasswordFormat();
        const isPasswordRequiredInvalid = this.validatePasswordRequired();
        const isConfirmPasswordCompareInvalid = this.validateConfirmPasswordCompare();
        const isConfirmPasswordRequiredInvalid = this.validateConfirmPasswordRequired();

        const validator = {
            isPasswordFormatInvalid,
            isPasswordRequiredInvalid,
            isConfirmPasswordCompareInvalid,
            isConfirmPasswordRequiredInvalid
        };

        this.setState({ validator });

        for (const key in validator) {
            if (validator[key]) {
                return false;
            }
        }

        return true;
    }

    componentWillMount() {
        apiCheckResetPasswordSecurityCode({ securityCode: this.state.securityCode }, (response) => {
            if (response.data.isValid) {
                this.setState({ usersId: response.data.usersId, username: response.data.username });
            } else {
                // this.commonModal.showModal({ message: "This link has been expired. Please contact TCE Administrator to get another link.", type: "information" }, () => {
                this.props.dispatch(showError("This link has been expired. Please contact TCE Administrator to get another link."));
                this.props.router.push(`/login`);
                // });
            }
        });
    }

    handleSaveChanges() {
        if (this.validateForm()) {
            apiChangeUserPassword({
                userId: this.state.usersId,
                password: this.state.password
            }, (result) => {
                if (result.data.isSuccess) {
                    // this.commonModal.showModal({ message: `Change Password Successfully.`, type: "information" }, () => {

                    // });
                    this.props.dispatch(showSuccess("Change Password Successfully."));
                    this.props.router.push(`/login`);
                }
            }, () => { });
        }
    }

    render() {
        const { password, verifyPassword, validator, username } = this.state;

        return (
            <div>
                <div className="place-section" style={{ position: "relative" }}>
                    <div className="row">
                        <div className="col s12 m4 offset-m4">
                            <img src={LOGO_2X_IMAGE_URL} alt="" className="responsive-img center-block" />
                        </div>
                    </div>
                    <div style={{ width: "50%", margin: "0 auto" }}>
                        <div className="row">
                            <div className="col s6">
                                <h3 className="title-page-detail">
                                    Reset Password
                         </h3>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12">
                                <p>
                                    Complete the following to reset the password for username: {username}
                                </p>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s2">
                                <strong>Password:</strong>
                            </div>
                            <div className="col s10">
                                1. Be at least eight characters in length<br />
                                2. Contain characters from three of the following four categories:<br />
                                a. English uppercase characters (A through Z)<br />
                                b. English lowercase characters (a through z)<br />
                                c. Base 10 digits (0 through 9)<br />
                                d. Non-alphabetic characters<br />
                                (e.g : ` ~ ! @ # $ % ^ * ( ) _ + - = {`{ }`} | \ " ; ' ? , . /)

                            </div>
                        </div>
                        <div className="row">
                            <div className={`col s12 input-field required suffixinput ${validator.isPasswordRequiredInvalid ? "required-field" : ""} ${validator.isPasswordFormatInvalid ? "has-error" : ""}`}>
                                <input id="password" maxLength="100" type="password" value={password} ref="password" onChange={() => this.handlePasswordChanged()} onBlur={() => this.handleValidatePassword()} className="validate" />
                                <label htmlFor="password">Enter New Password</label>
                                <span className="suffix-text" style={validator.isPasswordRequiredInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Enter New Password")} />
                                </span>
                                <span className="suffix-text" style={validator.isPasswordFormatInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidPasswordMessage()} />
                                </span>
                            </div>

                        </div>
                        <div className="row">
                            <div className={`col s12 input-field required suffixinput ${validator.isConfirmPasswordRequiredInvalid ? "required-field" : ""} ${validator.isConfirmPasswordCompareInvalid ? "has-error" : ""}`}>
                                <input id="confirmPassword" maxLength="100" type="password" value={verifyPassword} onChange={() => this.handleConfirmPasswordChanged()} onBlur={() => this.handleValidateConfirmPassword()} ref="confirmPassword" className="validate" />
                                <label htmlFor="confirmPassword">Re-type New Password</label>
                                <span className="suffix-text" style={validator.isConfirmPasswordRequiredInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Re-type New Password")} />
                                </span>
                                <span className="suffix-text" style={validator.isConfirmPasswordCompareInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={comparePasswordMessage("Enter New Password", "Re-type New Password")} />
                                </span>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col m6">
                                <button className="btn white w-100" onClick={() => this.props.router.push(`/login`)}>Cancel</button>
                            </div>
                            <div className="col m6">
                                <button className="btn success-color w-100" onClick={() => this.handleSaveChanges()}>Save Changes</button>
                            </div>

                        </div>
                    </div>
                </div>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

ResetPasswordPage.propTypes = {
    isOpen: PropTypes.bool,
    cancel: PropTypes.func,
    userId: PropTypes.number,
    params: PropTypes.object,
    router: PropTypes.object,
    dispatch: PropTypes.func
};

export default connect()(ResetPasswordPage);