import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";

class Profile extends Component {
    render() {
        const { role, profile } = this.props;

        const permissionList = role.permissions.map((item, index) => {
            return (
                <li key={index}><span>{item}</span></li>
            );
        });

        const roleNamesList = role.roleNames.map((item, index) => {
            return (
                <li key={index}><span>{item}</span></li>
            );
        });

        return (
            <div className="container-fluid">
                <h2>{profile.firstName} {profile.lastName}</h2>
                <h3>Type: {role.roleType}</h3>
                <ul>
                    {roleNamesList}
                </ul>
                <h3>{"Permissions"}</h3>
                <ul>
                    {permissionList}
                </ul>
            </div>
        );
    }
}

Profile.propTypes = {
    role: PropTypes.object,
    profile: PropTypes.object
};

export default Profile;