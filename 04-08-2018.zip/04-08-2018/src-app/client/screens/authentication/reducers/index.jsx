import { LOGIN_REQUEST, LOGIN_SUCCESS, LOGIN_FAILURE, LOGOUT_SUCCESS, LOGIN_RECEIVE } from "../actions";
import { SET_IS_SHOW_ATTENTION } from "../../main-layout/actions/index";
import { getAuthenticatedUser } from "../../../helpers/common-helper";

export default function authenticationReducer(state, action) {
    const userData = getAuthenticatedUser();

    state = {
        ...state,
        isAuthenticated: userData !== null,
        profile: userData !== null ? userData.profile : {},
        role: userData !== null ? userData.role : {},
        accountId: userData !== null ? userData.accountId : 0,
        userId: userData !== null ? userData.userId : 0,
        tenantId: userData !== null ? userData.tenantId : 0,
        supervisor: userData !== null ? userData.supervisor : null
    };

    switch (action.type) {
        case LOGIN_RECEIVE:
            return {
                ...state,
                isFetching: false
            };
        case LOGIN_REQUEST:
            return {
                ...state,
                isFetching: true,
                isAuthenticated: false
            };
        case LOGIN_SUCCESS:
            return {
                ...state,
                isFetching: false,
                isAuthenticated: true,
                isLoginError: false,
                errorMessage: "",
                profile: action.data.profile,
                role: action.data.role,
                accountId: action.data.id,
                userId: action.data.profile.id,
                tenantId: action.data.tenantId,
                supervisor: action.data.supervisor
            };
        case LOGIN_FAILURE:
            return {
                ...state,
                isFetching: false,
                isAuthenticated: false,
                isLoginError: true,
                errorMessage: action.message
            };
        case LOGOUT_SUCCESS:
            return {
                ...state,
                isFetching: false,
                isAuthenticated: false
            };
        case SET_IS_SHOW_ATTENTION:
            return {
                ...state,
                isShowAttentions: action.isShowAttentions
            };
        default:
            return state;
    }
}