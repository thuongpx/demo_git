import {
    apiFetchAssignedOrderByAgentChartData,
    apiFetchAssignedOrderListGridData,
    apiCountAssignedOrderListGridData,
    apiFetchAssignedOrderBySchedulerForStaffGridData,
    apiFetchAssignedOrderBySchedulerForStaffChartData,
    apiCountAssignedOrderBySchedulerForStaffGridData,
    apiDownloadAssignedOrderBySchedulerGridData
} from "../../../api/canned-report-api";
import { handleApiError } from "ErrorHandler";
import clone from "clone";
// import { endGetCannedReportGridData, startGetCannedReportGridData } from "./index";
import moment from "moment";

import { hasStringValue } from "../../../helpers/common-helper";
import { showSuccess } from "../../main-layout/actions";

export const FETCH_ASSIGNED_ORDER_BY_AGENTS_CHART_DATA = "FETCH_ASSIGNED_ORDER_BY_AGENTS_CHART_DATA";
export const FETCH_ASSIGNED_ORDER_LIST_GRID_DATA = "FETCH_ASSIGNED_ORDER_LIST_GRID_DATA";
export const COUNT_ASSIGNED_ORDER_LIST_GRID_DATA = "COUNT_ASSIGNED_ORDER_LIST_GRID_DATA";
export const FETCH_ASSIGNED_ORDER_LIST_FOR_STAFF_GRID_DATA = "FETCH_ASSIGNED_ORDER_LIST_FOR_STAFF_GRID_DATA";
export const COUNT_ASSIGNED_ORDER_LIST_FOR_STAFF_GRID_DATA = "COUNT_ASSIGNED_ORDER_LIST_FOR_STAFF_GRID_DATA";
export const FETCH_ASSIGNED_ORDER_BY_SCHEDULER_FOR_STAFF_CHART_DATA = "FETCH_ASSIGNED_ORDER_BY_SCHEDULER_FOR_STAFF_CHART_DATA";

export const CLEAR_STAFF_REPORT = "CLEAR_STAFF_REPORT";

export const clearStaffReport = () => {
    return {
        type: CLEAR_STAFF_REPORT
    };
};

const _buildDefaultSearchObjectForAssignedOrder = (searchObject, getState) => {
    const { cannedReport } = getState();
    const { main } = cannedReport;
    const { months } = main;

    // get default months
    const curMonthVal = Number(moment().utc().format("M"));
    const preMonthVal = curMonthVal - 1;
    const preMonthVal2 = curMonthVal - 2;

    // get current month label and previous month label
    const curMonth = months.find(m => Number(m.value) === curMonthVal);
    const preMonth = months.find(m => Number(m.value) === preMonthVal);
    const preMonth2 = months.find(m => Number(m.value) === preMonthVal2);

    // if search object is null or undefinied, assign it as an empty object
    if (!searchObject) searchObject = {};

    // if day from is empty, assign it to 1
    if (!hasStringValue(searchObject.dayFrom)) searchObject.dayFrom = "1";

    // if day to is empty, assign it to the current day
    if (!hasStringValue(searchObject.dayTo)) searchObject.dayTo = `${moment().utc().format("D")}`;

    // if month(s) are not selected, assign it as the current month and the previous month
    if (!hasStringValue(searchObject.month) || (searchObject.month.length === 0)) {
        searchObject.month = [{ ...curMonth }, { ...preMonth }, { ...preMonth2 }];
    }

    // if Agents have value
    if (!hasStringValue(searchObject.agents) || (searchObject.agents.length === 0)) {
        searchObject.showTop10 = true;
    } else {
        searchObject.showTop10 = false;
    }
    // if scheduler have value
    if (!hasStringValue(searchObject.schedulers) || (searchObject.schedulers.length === 0)) {
        searchObject.showTop10 = true;
    } else {
        searchObject.showTop10 = false;
    }

    searchObject.year = Number(moment().utc().format("YYYY"));

    return searchObject;
};

export const fetchAssignedOrderByAgentChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchAssignedOrderByAgentChartData({ searchObject: _buildDefaultSearchObjectForAssignedOrder(searchObject, getState) }, (result) => {
            // add colors
            const colors = getState().cannedReport.main.colors;
            const data = clone(result.data);
            data.datasets = data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });
            dispatch({
                type: FETCH_ASSIGNED_ORDER_BY_AGENTS_CHART_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchAssignedOrderListGridData = (searchObject, options, reduxType) => {
    return (dispatch, getState) => {
        return apiFetchAssignedOrderListGridData({
            searchObject: _buildDefaultSearchObjectForAssignedOrder(searchObject, getState),
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {
                if (item.OrderDate) {
                    item.OrderDate = moment(item.OrderDate).utc().format("MM/DD/YY");
                }
                return item;
            });

            dispatch({
                type: reduxType || FETCH_ASSIGNED_ORDER_LIST_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const countAssignedOrderListGridData = (searchObject, reduxType) => {
    return (dispatch, getState) => {
        return apiCountAssignedOrderListGridData({ searchObject: _buildDefaultSearchObjectForAssignedOrder(searchObject, getState) || {} }, (rs) => {
            dispatch({
                type: reduxType || COUNT_ASSIGNED_ORDER_LIST_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const exportAssignedOrderGridData = (searchObject) => {
    return (dispatch, getState) => {
        return apiDownloadAssignedOrderBySchedulerGridData({ searchObject: _buildDefaultSearchObjectForAssignedOrder(searchObject, getState) || {} },
            `Assigned_Order_by_Agents_${moment().format("YYYYMMDD")}.xlsx`, () => {
                dispatch(showSuccess("Export Successfully"));
            }, err => handleApiError(dispatch, err));
    };
};

export const fetchAssignedOrderListForStaffGridData = (searchObject, options, reduxType) => {
    return (dispatch, getState) => {
        return apiFetchAssignedOrderBySchedulerForStaffGridData({
            searchObject: _buildDefaultSearchObjectForAssignedOrder(searchObject, getState),
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {
                if (item.OrderDate) {
                    item.OrderDate = moment(item.OrderDate).utc().format("MM/DD/YY");
                }
                return item;
            });

            dispatch({
                type: reduxType || FETCH_ASSIGNED_ORDER_LIST_FOR_STAFF_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const countAssignedOrderListForStaffGridData = (searchObject, reduxType) => {
    return (dispatch, getState) => {
        return apiCountAssignedOrderBySchedulerForStaffGridData({ searchObject: _buildDefaultSearchObjectForAssignedOrder(searchObject, getState) || {} }, (rs) => {
            dispatch({
                type: reduxType || COUNT_ASSIGNED_ORDER_LIST_FOR_STAFF_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchAssignedOrderBySchedulerForStaffChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchAssignedOrderBySchedulerForStaffChartData({ searchObject: _buildDefaultSearchObjectForAssignedOrder(searchObject, getState) }, (result) => {
            // add colors
            const colors = getState().cannedReport.main.colors;
            const data = clone(result.data);
            data.datasets = data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });
            dispatch({
                type: FETCH_ASSIGNED_ORDER_BY_SCHEDULER_FOR_STAFF_CHART_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};