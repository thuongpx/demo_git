import { ORDER_REPORT_AVAILABLE_FIELDS, VENDOR_REPORT_AVAILABLE_FIELDS, CLIENT_REPORT_AVAILABLE_FIELDS } from "../../../constant/constants";

export const UPDATE_CURRENT_SEARCH_OBJECT = "UPDATE_CURRENT_SEARCH_OBJECT";
export const UPDATE_MANUAL_REPORT_AVAILABLE_FIELDS = "UPDATE_MANUAL_REPORT_AVAILABLE_FIELDS";
//
export const SET_SELECTED_FIELD_LIST = "SET_SELECTED_FIELD_LIST";
export const SET_AVAILABLE_FIELD_LIST = "SET_AVAILABLE_FIELD_LIST";
export const REQUEST_TEMPLATE_REPORT = "REQUEST_TEMPLATE_REPORT";
export const RESPONSE_TEMPLATE_REPORT = "RESPONSE_TEMPLATE_REPORT";
export const REQUEST_DELETE_REPORT = "REQUEST_DELETE_REPORT";
export const RECEIVE_DELETE_REPORT = "RECEIVE_DELETE_REPORT";
export const REQUEST_GET_TEMPLATE_REPORT = "REQUEST_GET_TEMPLATE_REPORT";
export const RESPONSE_GET_TEMPLATE_REPORT = "RESPONSE_GET_TEMPLATE_REPORT";
export const REQUEST_TEMPLATE_BY_NAME = "REQUEST_TEMPLATE_BY_NAME";
export const RESPONSE_TEMPLATE_BY_NAME = "RESPONSE_TEMPLATE_BY_NAME";
import { showSuccess } from "../../main-layout/actions";
import { handleApiError } from "ErrorHandler";
import { SUCCESSFULLY_SAVED_MESSAGE } from "Constants";
import { apiAddTemplateReport, apiDeleteTemplateReport, apiGetTemplateReport, apiDownloadExcelManualReportOrder, apiDownloadExcelManualReportVendor, apiGetTemplateByName } from "../../../api/canned-report-api";
//
import moment from "moment";

export const updateCurrentSearchObject = (dataCriteria) => {
    return {
        type: UPDATE_CURRENT_SEARCH_OBJECT,
        payload: dataCriteria
    };
};

export const fetchAvailableFieldsByReportType = (reportType) => {
    return dispatch => {
        let availableFields = [];

        switch (reportType) {
            case "Vendor":
                availableFields = VENDOR_REPORT_AVAILABLE_FIELDS.map(i => {
                    return {
                        value: i,
                        label: i
                    };
                });
                break;
            case "Client":
                availableFields = CLIENT_REPORT_AVAILABLE_FIELDS.map(i => {
                    return {
                        value: i,
                        label: i
                    };
                });
                break;
            default:
                availableFields = ORDER_REPORT_AVAILABLE_FIELDS.map(i => {
                    return {
                        value: i,
                        label: i
                    };
                });
                break;
        }

        return dispatch({
            type: UPDATE_MANUAL_REPORT_AVAILABLE_FIELDS,
            payload: availableFields
        });
    };
};

//
export const setSelectedFieldList = (newListSelected) => {
    return {
        type: SET_SELECTED_FIELD_LIST,
        newListSelected
    };
};

export const setAvailableFieldList = (newListAvailable) => {
    return {
        type: SET_AVAILABLE_FIELD_LIST,
        newListAvailable
    };
};

// action get report
export const requestGetTemplateReport = () => {
    return {
        type: REQUEST_GET_TEMPLATE_REPORT,
        isFetching: true
    };
};

export const responseGetTemplateReport = (data) => {
    return {
        type: RESPONSE_GET_TEMPLATE_REPORT,
        isFetching: false,
        data
    };
};

export const getTemplateReport = () => {
    return dispatch => {
        dispatch(requestGetTemplateReport());

        return apiGetTemplateReport((result) => {
            dispatch(responseGetTemplateReport(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

//action save template report
export const requestTemplateReport = () => {
    return {
        type: REQUEST_TEMPLATE_REPORT,
        isFetching: true
    };
};

export const responseTemplateReport = (data) => {
    return {
        type: RESPONSE_TEMPLATE_REPORT,
        isFetching: false,
        data
    };
};

export const saveTemplateReport = (dataObjSave) => {
    return dispatch => {
        dispatch(requestTemplateReport());
        return apiAddTemplateReport(dataObjSave, (result) => {
            dispatch(responseTemplateReport(result.data));
            dispatch(getTemplateReport());
            dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
        }, (error) => handleApiError(dispatch, error));
    };
};

// action delete report
export const requestDeleteReport = () => {
    return {
        type: REQUEST_DELETE_REPORT,
        isFetching: true
    };
};

export const receiveDeleteReport = (data) => {

    return {
        type: RECEIVE_DELETE_REPORT,
        isFetching: false,
        data
    };
};

export const deleteReport = (reportId) => {
    return dispatch => {
        dispatch(requestDeleteReport());
        return apiDeleteTemplateReport(reportId, (result) => {
            dispatch(receiveDeleteReport(result.data));
            dispatch(fetchAvailableFieldsByReportType());
            dispatch(getTemplateReport());
        });
    };
};

// action get template by name
export const requestTemplateByName = () => {
    return {
        type: REQUEST_TEMPLATE_BY_NAME,
        isFetching: true
    };
};

export const responseTemplateByName = (data) => {
    return {
        type: RESPONSE_TEMPLATE_BY_NAME,
        isFetching: false,
        data
    };
};

export const getTemplateReportByName = (reportName) => {
    return dispatch => {
        dispatch(requestTemplateByName());
        return apiGetTemplateByName({ reportName }, (result) => {
            dispatch(responseTemplateByName(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

// action export excel
const _buildSearchObjectForManualReport = (searchObject) => {
    if (!searchObject) return {};
    const returnData = {};
    const newArrayColumns = searchObject.map(item => item.value);
    returnData.newArrayColumns = searchObject.newArrayColumns;

    return newArrayColumns;
};

export const exportManualReportOrder = (searchObject) => {
    return (dispatch) => {
        return apiDownloadExcelManualReportOrder({
            searchObject: _buildSearchObjectForManualReport(searchObject) || {}
        }, `Manual_report_order${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};

export const exportManualReportVendor = (searchObject) => {
    return (dispatch) => {
        return apiDownloadExcelManualReportVendor({
            searchObject: _buildSearchObjectForManualReport(searchObject) || {}
        }, `Manual_report_order${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};
