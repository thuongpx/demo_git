import { apiGetInitDataForCannedReport, apiExportDrillDownData } from "../../../api/canned-report-api";
import { handleApiError } from "ErrorHandler";
import clone from "clone";
import moment from "moment";
import { showSuccess } from "../../main-layout/actions";

export const CANNED_REPORT_CLEAR_REDUCERS = "CANNED_REPORT_CLEAR_REDUCERS";
export const GET_INIT_DATA_FOR_CANNED_REPORT = "GET_INIT_DATA_FOR_CANNED_REPORT";
export const START_GET_CANNED_REPORT_GRID_DATA = "START_GET_CANNED_REPORT_GRID_DATA";
export const END_GET_CANNED_REPORT_GRID_DATA = "END_GET_CANNED_REPORT_GRID_DATA";
export const OPEN_DRILL_DOWN_MODAL = "OPEN_DRILL_DOWN_MODAL";
export const CLOSE_DRILL_DOWN_MODAL = "CLOSE_DRILL_DOWN_MODAL";
export const UPDATE_DRILL_DOWN_DATASOURCE = "UPDATE_DRILL_DOWN_DATASOURCE";
export const UPDATE_DRILL_DOWN_CRITERIA = "UPDATE_DRILL_DOWN_CRITERIA";

export const clearCannedReportReducers = () => {
    return {
        type: CANNED_REPORT_CLEAR_REDUCERS
    };
};

export const getInitDataForCannedReport = () => {
    return dispatch => {
        return apiGetInitDataForCannedReport((rs) => {
            const orderTypes = clone(rs.data.orderTypes);
            const agents = clone(rs.data.agents);
            const schedulers = clone(rs.data.schedulers);

            dispatch({
                type: GET_INIT_DATA_FOR_CANNED_REPORT,
                orderTypes,
                agents,
                schedulers
            });
        },
            err => handleApiError(dispatch, err));
    };
};

export const startGetCannedReportGridData = () => {
    return {
        type: START_GET_CANNED_REPORT_GRID_DATA
    };
};

export const endGetCannedReportGridData = () => {
    return {
        type: END_GET_CANNED_REPORT_GRID_DATA
    };
};

export const closeDrillDownModal = () => {
    return {
        type: CLOSE_DRILL_DOWN_MODAL
    };
};

export const openDrillDownModal = (options) => {
    return {
        type: OPEN_DRILL_DOWN_MODAL,
        options
    };
};

export const updateDrillDownModalDataSource = (dataSource) => {
    return {
        type: UPDATE_DRILL_DOWN_DATASOURCE,
        dataSource
    };
};

export const updateDrilldownCriteria = (criteria) => {
    return {
        type: UPDATE_DRILL_DOWN_CRITERIA,
        criteria
    };
};

export const exportDrillDownData = (data, columns, title) => {
    return dispatch => {
        apiExportDrillDownData({ data, columns, title }, `${title}_${moment().format("YYYYMMDD").toString()}.xlsx`, () => dispatch(showSuccess("Export Successfully"))
            , err => handleApiError(dispatch, err));
    };
};