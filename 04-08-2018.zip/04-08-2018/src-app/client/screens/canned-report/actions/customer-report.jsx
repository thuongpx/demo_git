import {
    apiFetchMilestonesGridData, apiCountMilestonesGridData,
    apiFetchClosedOrdersByCustomersChartData, apiFetchMilestonesChartData, apiFetchOpenOrderTrendChartData,
    apiFetchClosedOrdersByCustomersGridData, apiCountClosedOrdersByCustomersGridData,
    apiFetchOpenOrderTrendGridData, apiCountOpenOrderTrendGridData,
    apiFetchOrderByCustomerAndStatusChartData,
    apiFetchOrderByCustomerAndStatusForStaffChartData, apiFetchOrderByCustomerAndStatusForStaffGridData, apiCountOrderByCustomerAndStatusForStaffGridData,
    apiFetchClosedOrdersByClientForStaffChartData, apiFetchClosedOrdersByClientForStaffGridData, apiCountClosedOrdersByClientForStaffGridData,

    apiFetchOpenOrderTrendForStaffChartData, apiFetchOpenOrderTrendForStaffGridData, apiCountOpenOrderTrendForStaffGridData,
    apiFetchMilestonesForStaffChartData, apiFetchMilestonesForStaffGridData, apiCountMilestonesForStaffGridData, apiExportMilestoneGridData, apiExportOpenOrdersTrendByCustomer, apiExportOrderByCustomerAndStatusGridData, apiExportClosedOrdersByCustomersGridData

} from "../../../api/canned-report-api";
import { handleApiError } from "ErrorHandler";
import clone from "clone";
import moment from "moment";
import { hasStringValue } from "../../../helpers/common-helper";
import { USER_TYPE } from "../../../constant/constants";
import { showSuccess } from "../../main-layout/actions";

export const FETCH_MILESTONE_CHART_DATA = "FETCH_MILESTONE_CHART_DATA";
export const FETCH_MILESTONE_GRID_DATA = "FETCH_MILESTONE_GRID_DATA";
export const COUNT_MILESTONE_GRID_DATA = "COUNT_MILESTONE_GRID_DATA";

export const FETCH_CLOSED_ORDERS_BY_CUSTOMERS_GRID_DATA = "FETCH_CLOSED_ORDERS_BY_CUSTOMERS_GRID_DATA";
export const COUNT_CLOSED_ORDERS_BY_CUSTOMERS_GRID_DATA = "COUNT_CLOSED_ORDERS_BY_CUSTOMERS_GRID_DATA";

export const FETCH_OPEN_ORDER_TREND_CHART_DATA = "FETCH_OPEN_ORDER_TREND_CHART_DATA";
export const FETCH_CLOSED_ORDERS_BY_CUSTOMERS_CHART_DATA = "FETCH_CLOSED_ORDERS_BY_CUSTOMERS_CHART_DATA";
export const FETCH_OPEN_ORDER_TREND_GRID_DATA = "FETCH_OPEN_ORDER_TREND_GRID_DATA";
export const COUNT_OPEN_ORDER_TREND_GRID_DATA = "COUNT_OPEN_ORDER_TREND_GRID_DATA";
export const FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_CHART_DATA = "FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_CHART_DATA";
export const COUNT_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_GRID_DATA = "COUNT_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_GRID_DATA";
export const FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_GRID_DATA = "FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_GRID_DATA";
export const FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_CHART_DATA = "FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_CHART_DATA";
export const COUNT_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_GRID_DATA = "COUNT_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_GRID_DATA";
export const FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_GRID_DATA = "FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_GRID_DATA";
export const CLEAR_CUSTOMER_REPORT = "CLEAR_CUSTOMER_REPORT";
export const FETCH_CLOSED_ORDERS_BY_CLIENT_FOR_STAFF_CHART_DATA = "FETCH_CLOSED_ORDERS_BY_CLIENT_FOR_STAFF_CHART_DATA";
export const FETCH_CLOSED_ORDERS_BY_CLIENTS_FOR_STAFF_GRID_DATA = "FETCH_CLOSED_ORDERS_BY_CLIENTS_FOR_STAFF_GRID_DATA";
export const COUNT_CLOSED_ORDERS_BY_CLIENTS_FOR_STAFF_GRID_DATA = "COUNT_CLOSED_ORDERS_BY_CLIENTS_FOR_STAFF_GRID_DATA";
export const FETCH_OPEN_ORDER_TREND_FOR_STAFF_CHART_DATA = "FETCH_OPEN_ORDER_TREND_FOR_STAFF_CHART_DATA";
export const FETCH_OPEN_ORDER_TREND_FOR_STAFF_GRID_DATA = "FETCH_OPEN_ORDER_TREND_FOR_STAFF_GRID_DATA";
export const COUNT_OPEN_ORDER_TREND_FOR_STAFF_GRID_DATA = "COUNT_OPEN_ORDER_TREND_FOR_STAFF_GRID_DATA";


//staff
export const FETCH_MILESTONE_FOR_STAFF_CHART_DATA = "FETCH_MILESTONE_FOR_STAFF_CHART_DATA";
export const FETCH_MILESTONE_FOR_STAFF_GRID_DATA = "FETCH_MILESTONE_FOR_STAFF_GRID_DATA";
export const COUNT_MILESTONE_FOR_STAFF_GRID_DATA = "COUNT_MILESTONE_FOR_STAFF_GRID_DATA";


export const clearCustomerReport = () => {
    return {
        type: CLEAR_CUSTOMER_REPORT
    };
};

const _buildDefaultSearchObject = (searchObject, getState) => {
    const { cannedReport } = getState();
    const { main } = cannedReport;
    const { months } = main;

    // get default months
    const curMonthVal = Number(moment().utc().format("M"));
    const preMonthVal = curMonthVal - 1;
    const pre2MonthVal = curMonthVal - 2;

    // get current month label and previous month label
    const curMonth = months.find(m => Number(m.value) === curMonthVal);
    const preMonth = months.find(m => Number(m.value) === preMonthVal);
    const pre2Month = months.find(m => Number(m.value) === pre2MonthVal);

    // if search object is null or undefinied, assign it as an empty object
    if (!searchObject) searchObject = {};

    // if day from is empty, assign it to 1
    if (!hasStringValue(searchObject.dayFrom)) searchObject.dayFrom = "1";


    // if day to is empty, assign it to the current day
    if (!hasStringValue(searchObject.dayTo)) searchObject.dayTo = `${moment().utc().format("D")}`;

    // if month(s) are not selected, assign it as the current month and the previous month
    if (!hasStringValue(searchObject.month) || (searchObject.month.length === 0)) {
        searchObject.month = [{ ...curMonth }, { ...preMonth }, { ...pre2Month }];
    }
    if (!hasStringValue(searchObject.customer) || (searchObject.customer.length === 0)) {
        searchObject.customer = "Top10AndOthers";
    }
    if (!hasStringValue(searchObject.agent) || (searchObject.agent.length === 0)) {
        searchObject.agent = "Top10AndOthers";
    }


    searchObject.year = Number(moment().utc().format("YYYY"));

    return searchObject;
};

const _buildDefaultSearchObjectByCustomerAndStatus = (searchObject, getState) => {

    const { authentication } = getState();
    const { role } = authentication;
    const { roleType } = role;

    // if search object is null or undefinied, assign it as an empty object
    if (!searchObject) searchObject = {};

    // if customerName is empty, assign it equals is Top 10 And Others
    if (!hasStringValue(searchObject.customer)) searchObject.customer = `Top10AndOthers`;

    // if orderStaus is empty, assign it equals is Open
    if (!hasStringValue(searchObject.orderStatus)) searchObject.orderStatus = [{ label: "Open", value: "Open" }];


    // if day to is empty, assign it to the current day
    if (!hasStringValue(searchObject.fromDate)) searchObject.fromDate = `${moment().utc().format("MM/DD/YYYY")}`;

    if (!hasStringValue(searchObject.toDate)) searchObject.toDate = `${moment().utc().format("MM/DD/YYYY")}`;

    // if roleType is Staff, assign fullService equals 1
    if (roleType === USER_TYPE.Staff) { searchObject.isFullService = true; } else { delete searchObject.isFullService; }

    return searchObject;
};

export const fetchOpenOrderTrendByCustomerChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchOpenOrderTrendChartData({ searchObject: _buildDefaultSearchObject(searchObject, getState) || {} }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const data = clone(rs.data);
            data.datasets = data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });

            dispatch({
                type: FETCH_OPEN_ORDER_TREND_CHART_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchMilestonesGridData = (searchObject, options) => {
    return (dispatch) => {
        return apiFetchMilestonesGridData({
            searchObject: searchObject || {},
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {
                return item;
            });

            dispatch({
                type: FETCH_MILESTONE_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const countMilestonesGridData = (searchObject) => {
    return (dispatch) => {
        return apiCountMilestonesGridData({ searchObject: searchObject || {} }, (rs) => {
            dispatch({
                type: COUNT_MILESTONE_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const exportMilestonesGridData = (searchObject) => {
    return (dispatch) => {
        return apiExportMilestoneGridData({ searchObject: searchObject || {} }, `Custome_Milestone_${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchMilestonesChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchMilestonesChartData({ searchObject: searchObject || {} }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const data = clone(rs.data);
            data.datasets = data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });

            dispatch({
                type: FETCH_MILESTONE_CHART_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchClosedOrdersByCustomersChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchClosedOrdersByCustomersChartData({ searchObject: _buildDefaultSearchObject(searchObject, getState) || {} }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const data = clone(rs.data);
            data.datasets = data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });

            dispatch({

                type: FETCH_CLOSED_ORDERS_BY_CUSTOMERS_CHART_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchOpenOrderTrendGridData = (searchObject, options) => {
    return (dispatch, getState) => {
        return apiFetchOpenOrderTrendGridData({
            searchObject: _buildDefaultSearchObject(searchObject, getState) || {},
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {
                return item;
            });

            dispatch({
                type: FETCH_OPEN_ORDER_TREND_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};


export const countOpenOrderTrendGridData = (searchObject) => {
    return (dispatch, getState) => {
        return apiCountOpenOrderTrendGridData({ searchObject: _buildDefaultSearchObject(searchObject, getState) || {} }, (rs) => {
            dispatch({
                type: COUNT_OPEN_ORDER_TREND_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const exportOpenOrderTrendGridData = (searchObject) => {
    return (dispatch, getState) => {
        return apiExportOpenOrdersTrendByCustomer({ searchObject: _buildDefaultSearchObject(searchObject, getState) || {} }, `Order_Trend_${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};

// Order by Customer and Status

export const fetchOpenOrderByCustomerAndStatusChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchOrderByCustomerAndStatusChartData({ searchObject: _buildDefaultSearchObjectByCustomerAndStatus(searchObject, getState) }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const data = clone(rs.data);
            data.datasets = data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });

            dispatch({
                type: FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_CHART_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};
export const fetchOpenOrderByCustomerAndStatusGridData = (searchObject, options, reduxType) => {
    return (dispatch, getState) => {
        return apiFetchOpenOrderTrendGridData({
            searchObject: _buildDefaultSearchObjectByCustomerAndStatus(searchObject, getState) || {},
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {
                item.Agents = `${item.AgentFirstName || ""} ${item.AgentLastName || ""}`;
                if (item.ClosingDate) {
                    item.ClosingDate = moment(item.ClosingDate).utc().format("YYYY-MM-DD HH:mm:ss");
                }

                if (item.OpenDate) {
                    item.OpenDate = moment(item.OpenDate).utc().format("YYYY-MM-DD HH:mm:ss");
                }

                return item;
            });

            dispatch({
                type: reduxType || FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const countOpenOrderByCustomerAndStatusGridData = (searchObject, reduxType) => {
    return (dispatch, getState) => {
        return apiCountOpenOrderTrendGridData({ searchObject: _buildDefaultSearchObjectByCustomerAndStatus(searchObject, getState) } || {}, (rs) => {
            dispatch({
                type: reduxType || COUNT_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const exportOpenOrderByCustomerAndStatusGridData = (searchObject) => {
    return (dispatch, getState) => {
        return apiExportOrderByCustomerAndStatusGridData({ searchObject: _buildDefaultSearchObjectByCustomerAndStatus(searchObject, getState) || {} }, `Open_Order_by_Customer_${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchClosedOrdersByCustomersGridData = (searchObject, options, reduxType) => {
    return (dispatch, getState) => {
        return apiFetchClosedOrdersByCustomersGridData({
            searchObject: _buildDefaultSearchObject(searchObject, getState) || {},
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {

                return item;
            });

            dispatch({
                type: reduxType || FETCH_CLOSED_ORDERS_BY_CUSTOMERS_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const countClosedOrdersByCustomersGridData = (searchObject, reduxType) => {
    return (dispatch, getState) => {
        return apiCountClosedOrdersByCustomersGridData({ searchObject: _buildDefaultSearchObject(searchObject, getState) || {} }, (rs) => {
            dispatch({
                type: reduxType || COUNT_CLOSED_ORDERS_BY_CUSTOMERS_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const exportClosedOrdersByCustomersGridData = (searchObject) => {
    return (dispatch, getState) => {
        return apiExportClosedOrdersByCustomersGridData({ searchObject: _buildDefaultSearchObject(searchObject, getState) || {} }, `Closed_Order_by_Customer_${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};

//milestone for staff
export const fetchMilestonesForStaffChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchMilestonesForStaffChartData({ searchObject: searchObject || {} }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const data = clone(rs.data);
            data.datasets = data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });

            dispatch({
                type: FETCH_MILESTONE_FOR_STAFF_CHART_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchMilestonesForStaffGridData = (searchObject, options, reduxType) => {
    return (dispatch) => {
        return apiFetchMilestonesForStaffGridData({
            searchObject: searchObject || {},
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {
                return item;
            });

            dispatch({
                type: reduxType || FETCH_MILESTONE_FOR_STAFF_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const countMilestonesForStaffGridData = (searchObject, reduxType) => {
    return (dispatch) => {
        return apiCountMilestonesForStaffGridData({ searchObject: searchObject || {} }, (rs) => {
            dispatch({
                type: reduxType || COUNT_MILESTONE_FOR_STAFF_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchOpenOrdersForStaffChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchOpenOrderTrendForStaffChartData({ searchObject: _buildDefaultSearchObject(searchObject, getState) || {} }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const data = clone(rs.data);
            data.datasets = data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });

            dispatch({

                type: FETCH_OPEN_ORDER_TREND_FOR_STAFF_CHART_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchOpenOrderTrendForStaffGridData = (searchObject, options) => {
    return (dispatch, getState) => {
        return apiFetchOpenOrderTrendForStaffGridData({
            searchObject: _buildDefaultSearchObject(searchObject, getState) || {},
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {

                return item;
            });

            dispatch({
                type: FETCH_OPEN_ORDER_TREND_FOR_STAFF_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const countOpenOrderTrendForStaffGridData = (searchObject) => {
    return (dispatch, getState) => {
        return apiCountOpenOrderTrendForStaffGridData({ searchObject: _buildDefaultSearchObject(searchObject, getState) || {} }, (rs) => {
            dispatch({
                type: COUNT_OPEN_ORDER_TREND_FOR_STAFF_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchClosedOrdersByClientChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchClosedOrdersByClientForStaffChartData({ searchObject: _buildDefaultSearchObject(searchObject, getState) || {} }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const data = clone(rs.data);
            data.datasets = data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });

            dispatch({

                type: FETCH_CLOSED_ORDERS_BY_CLIENT_FOR_STAFF_CHART_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};


export const fetchClosedOrdersByClientForStaffGridData = (searchObject, options, reduxType) => {
    return (dispatch, getState) => {
        return apiFetchClosedOrdersByClientForStaffGridData({
            searchObject: _buildDefaultSearchObject(searchObject, getState) || {},
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {
                if (item.AvgIncome === null || item.AvgIncome === "") {
                    item.AvgIncome = 0;
                } if (item.AvgCOS === null || item.AvgCOS === "") {
                    item.AvgCOS = 0;
                }
                if (item.AvgNetRevenue === null || item.AvgNetRevenue === "") {
                    item.AvgNetRevenue = 0;
                }
                return item;
            });

            dispatch({
                type: reduxType || FETCH_CLOSED_ORDERS_BY_CLIENTS_FOR_STAFF_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const countClosedOrdersByClientForStaffGridData = (searchObject, reduxType) => {
    return (dispatch, getState) => {
        return apiCountClosedOrdersByClientForStaffGridData({ searchObject: _buildDefaultSearchObject(searchObject, getState) || {} }, (rs) => {
            dispatch({
                type: reduxType || COUNT_CLOSED_ORDERS_BY_CLIENTS_FOR_STAFF_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

// Order by Customer and Status by staff

export const fetchOpenOrderByCustomerAndStatusForStaffChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchOrderByCustomerAndStatusForStaffChartData({ searchObject: _buildDefaultSearchObjectByCustomerAndStatus(searchObject, getState) }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const data = clone(rs.data);
            data.datasets = data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });

            dispatch({
                type: FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_CHART_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};
export const fetchOpenOrderByCustomerAndStatusForStaffGridData = (searchObject, options, reduxType) => {
    return (dispatch, getState) => {
        return apiFetchOrderByCustomerAndStatusForStaffGridData({
            searchObject: _buildDefaultSearchObjectByCustomerAndStatus(searchObject, getState) || {},
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {
                item.Agents = `${item.AgentFirstName || ""} ${item.AgentLastName || ""}`;
                if (item.ClosingDate) {
                    item.ClosingDate = moment(item.ClosingDate).utc().format("YYYY-MM-DD HH:mm:ss");
                }

                if (item.OpenDate) {
                    item.OpenDate = moment(item.OpenDate).utc().format("YYYY-MM-DD HH:mm:ss");
                }

                return item;
            });

            dispatch({
                type: reduxType || FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const countOpenOrderByCustomerAndStatusForStaffGridData = (searchObject, reduxType) => {
    return (dispatch, getState) => {
        return apiCountOrderByCustomerAndStatusForStaffGridData({ searchObject: _buildDefaultSearchObjectByCustomerAndStatus(searchObject, getState) } || {}, (rs) => {
            dispatch({
                type: reduxType || COUNT_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

