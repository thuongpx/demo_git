import {
    apiFetchEconomicChartData, apiCountEconomicGridData, apiFetchEconomicGridData, apiGetDefaultEconomicAgent,
    apiFetchEconomicProfitTrendMonthlyChartData, apiFetchEconomicProfitTrendDailyChartData, apiFetchEconomicMixChartData, apiGetListLoanTypeForMixChart, apiFetchEconomicClosedOrderDrilldownData, apiCountEconomicClosedOrderDrilldownData, apiDownloadExcelEconomicRequestFeeGridData
} from "../../../api/canned-report-api";
import { handleApiError } from "../../../helpers/error-handler";
import clone from "clone";
import moment from "moment";
import { hasStringValue } from "../../../helpers/common-helper";
import { USER_TYPE } from "../../../constant/constants";
import { showSuccess } from "../../main-layout/actions";

export const RECEIVE_ECONOMICS_CHART_DATA = "RECEIVE_ECONOMICS_CHART_DATA";
export const RECEIVE_ECONOMICS_DRILLDOWN_DATA = "RECEIVE_ECONOMICS_DRILLDOWN_DATA";
export const RECEIVE_ECONOMICS_DRILLDOWN_COUNT_TOTAL_RECORDS = "RECEIVE_ECONOMICS_DRILLDOWN_COUNT_TOTAL_RECORDS";
export const RECEIVE_ECONOMICS_AGENTS_DATA = "RECEIVE_ECONOMICS_AGENTS_DATA";
export const FETCH_ECONOMIC_TREND_ON_MONTHLY_BASIC_CHART_DATA = "FETCH_ECONOMIC_TREND_ON_MONTHLY_BASIC_CHART_DATA";
export const RECEIVE_ECONOMICS_PROFIT_TREND_DAILY_CHART_DATA = "RECEIVE_ECONOMICS_PROFIT_TREND_DAILY_CHART_DATA";
export const RECEIVE_ECONIMICS_MIX_CHART_DATA = "RECEIVE_ECONIMICS_MIX_CHART_DATA";
export const RECEIVE_ECONOMICS_MIX_CHART_LIST_DEFAULT_LOANTYPE = "RECEIVE_ECONOMICS_MIX_CHART_LIST_DEFAULT_LOANTYPE";
export const RECEIVE_ECONOMICS_CLOSED_ORDERS_DRILLDOWN_DATA = "RECEIVE_ECONOMICS_CLOSED_ORDERS_DRILLDOWN_DATA";
export const RECEIVE_ECONOMICS_CLOSED_ORDERS_DRILLDOWN_COUNT_TOTAL_RECORDS = "RECEIVE_ECONOMICS_CLOSED_ORDERS_DRILLDOWN_COUNT_TOTAL_RECORDS";

const _buildSearchObjectForEconomicReport = (searchObject, state, isStaffBuildSearchObj = false, primaryId = 0) => {
    if (!searchObject) return {};
    const returnData = {};
    const listDefaultAgent = state().cannedReport.economicReport.listAgent.listDefaultData;
    const currentDateMoment = moment();
    const firstDateOfMonth = `${currentDateMoment.format("YYYY-MM").toString()}-01`;

    returnData.reqFromDate = searchObject.reqFromDate !== undefined ? searchObject.reqFromDate || "" : firstDateOfMonth;
    returnData.reqToDate = searchObject.reqToDate !== undefined ? searchObject.reqToDate || "" : currentDateMoment.format("YYYY-MM-DD").toString();
    returnData.status = {};
    returnData.agentId = [];

    if (searchObject.status) {
        searchObject.status.forEach(item => {
            returnData.status[item.value] = true;
        });
    }

    if (searchObject.agentId) {
        searchObject.agentId.forEach(item => {
            returnData.agentId.push(item.value);
        });
    } else {
        listDefaultAgent.forEach(item => {
            returnData.agentId.push(item.value);
        });
    }

    returnData.isFullService = false;
    returnData.userPrimaryId = primaryId;

    if (isStaffBuildSearchObj) {
        returnData.isFullService = true;
        delete returnData.userPrimaryId;
    }

    return returnData;
};

const _buildSearchObjectForEconomicProfitTrendMonthly = (searchObject, getState) => {

    const { cannedReport, authentication } = getState();
    const { role } = authentication;
    const { roleType } = role;
    const { main } = cannedReport;
    const { months } = main;

    const listPreMonth = [];
    searchObject.monthEconomic = searchObject.monthEconomic || [];
    // get default months
    const curMonthVal = Number(moment().utc().format("M"));
    const preMonthVal = [curMonthVal - 1, curMonthVal - 2, curMonthVal - 3, curMonthVal - 4, curMonthVal - 5];

    // get current month label and previous month label
    const curMonth = months.find(m => Number(m.value) === curMonthVal);
    listPreMonth.push(curMonth);
    preMonthVal.map(index => {
        const preMonth = months.find(m => Number(m.value) === index);
        listPreMonth.push(preMonth);
    });

    // if search object is null or undefinied, assign it as an empty object
    if (!searchObject) searchObject = {};

    // if month(s) are not selected, assign it as the current month and the previous month
    if (!hasStringValue(searchObject.monthEconomic) || (searchObject.monthEconomic.length === 0)) {
        listPreMonth.map(index => {
            searchObject.monthEconomic.push({ ...index });
        });
    }
    // if roleType is Staff, assign fullService equals 1
    if (roleType === USER_TYPE.Staff) { searchObject.isFullService = true; } else { delete searchObject.isFullService; }

    // if assignType is null, assign assignType is Both
    if (!hasStringValue(searchObject.assignType)) searchObject.assignType = "0";

    searchObject.year = Number(moment().utc().format("YYYY"));

    return searchObject;
};


const _validateData = (data) => {
    if (!data) return true;

    let check = true;
    Object.keys(data).forEach(item => {
        if (data[item]) check = false;
    });

    return check;
};

export const getDefaultEconomicAgent = (cb = () => { }, inputs = {}) => {
    return (dispatch) => {
        apiGetDefaultEconomicAgent(inputs, rs => {
            dispatch({ type: RECEIVE_ECONOMICS_AGENTS_DATA, listAgent: rs.data.listAgent, listToptenAgent: rs.data.listToptenAgent });
            cb();
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchEconomicReportChartData = (searchObject, invalidData, isStaff = false, primaryId = 0) => {
    return (dispatch, getState) => {

        if (!_validateData(invalidData)) return 0;

        const buildSearchObj = _buildSearchObjectForEconomicReport(searchObject, getState, isStaff, primaryId) || {};

        return apiFetchEconomicChartData({ searchObject: buildSearchObj }, (result) => {
            // add colors
            const colors = getState().cannedReport.main.colors;
            const data = clone(result.data);
            data.datasets = data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });
            dispatch({ type: RECEIVE_ECONOMICS_CHART_DATA, data });
            dispatch(getDefaultEconomicAgent(() => { }, { searchObject: buildSearchObj }));
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchEconomicListGridData = (searchObject, options, invalidData, isStaff = false, primaryId = 0) => {
    return (dispatch, getState) => {
        if (!_validateData(invalidData)) return 0;

        return apiFetchEconomicGridData({
            searchObject: _buildSearchObjectForEconomicReport(searchObject, getState, isStaff, primaryId) || {},
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(i => {
                i.orderDate = moment(i.orderDate).format("YYYY/MM/DD hh:mm:ss");
                return i;
            });

            dispatch({ data, type: RECEIVE_ECONOMICS_DRILLDOWN_DATA, criteria: options });
        }, err => handleApiError(dispatch, err));
    };
};

export const countEconomicListGridData = (searchObject, invalidData, isStaff = false, primaryId = 0) => {
    return (dispatch, getState) => {
        if (!_validateData(invalidData)) return 0;

        return apiCountEconomicGridData({ searchObject: _buildSearchObjectForEconomicReport(searchObject, getState, isStaff, primaryId) || {} }, (rs) => {
            dispatch({ data: rs.data, type: RECEIVE_ECONOMICS_DRILLDOWN_COUNT_TOTAL_RECORDS });
        }, err => handleApiError(dispatch, err));
    };
};

export const exportEconomicRequestFeeGridData = (searchObject, isStaff = false, primaryId) => {
    return (dispatch, getState) => {
        return apiDownloadExcelEconomicRequestFeeGridData({
            searchObject: _buildSearchObjectForEconomicReport(searchObject, getState, isStaff, primaryId) || {}
        }, `Fee_Increase_${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};

const _buildSearchObjectForEconomicProfitTrendDaily = (searchObject) => {
    const returnData = {};

    const currentMonth = moment().format("MM").toString();
    if (hasStringValue(searchObject.month)) {
        returnData.month = searchObject.month;
    } else {
        returnData.month = currentMonth;
    }

    returnData.assignType = searchObject.assignType;

    // if assignType is null, assign assignType is Both
    if (!hasStringValue(searchObject.assignType)) returnData.assignType = "0";

    returnData.isFullService = true;

    return returnData;
};

export const fetchEconomicProfitDailyChartData = (searchObject) => {
    return (dispatch, getState) => {
        apiFetchEconomicProfitTrendDailyChartData({ searchObject: _buildSearchObjectForEconomicProfitTrendDaily(searchObject) || {} }, (result) => {
            // add colors
            const colors = getState().cannedReport.main.colors;
            const data = clone(result.data);
            data.datasets = data.datasets.map((i, index) => {
                const color = colors[index];
                const color2 = colors[100 - index - 1];
                return {
                    ...i,
                    borderColor: color,
                    backgroundColor: "#ffffff",
                    lineTension: 0.1,
                    fill: false,
                    borderCapStyle: "square",
                    borderDash: [],
                    borderDashOffset: 0.0,
                    borderJoinStyle: "miter",
                    pointBorderColor: color2,
                    pointBackgroundColor: color,
                    pointBorderWidth: 1,
                    pointHoverRadius: 8,
                    pointHoverBackgroundColor: color,
                    pointHoverBorderColor: color2,
                    pointHoverBorderWidth: 2,
                    pointRadius: 4,
                    pointHitRadius: 10,
                    spanGaps: true
                };
            });
            dispatch({ type: RECEIVE_ECONOMICS_PROFIT_TREND_DAILY_CHART_DATA, data });
        }, err => handleApiError(dispatch, err));
    };
};

// Economic Profit Monthly

export const fetchEconomicTrendOnMonthlyBasicChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchEconomicProfitTrendMonthlyChartData({ searchObject: _buildSearchObjectForEconomicProfitTrendMonthly(searchObject, getState) }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const data = clone(rs.data);
            data.datasets = data.datasets.map((i, index) => {
                const color = colors[index];
                const color2 = colors[100 - index - 1];
                return {
                    ...i,
                    borderColor: color,
                    backgroundColor: "#ffffff",
                    lineTension: 0.1,
                    fill: false,
                    borderCapStyle: "square",
                    borderDash: [],
                    borderDashOffset: 0.0,
                    borderJoinStyle: "miter",
                    pointBorderColor: color2,
                    pointBackgroundColor: color,
                    pointBorderWidth: 1,
                    pointHoverRadius: 8,
                    pointHoverBackgroundColor: color,
                    pointHoverBorderColor: color2,
                    pointHoverBorderWidth: 2,
                    pointRadius: 4,
                    pointHitRadius: 10,
                    spanGaps: true
                };
            });

            dispatch({
                type: FETCH_ECONOMIC_TREND_ON_MONTHLY_BASIC_CHART_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

const _buildSearchObjectForMixChart = (searchObject, getState) => {
    if (!searchObject) return {};
    const returnData = {};
    const listDefaultLoanType = getState().cannedReport.economicReport.listLoanType.listDefaultLoanType;

    returnData.closedOrderFromDate = hasStringValue(searchObject.fromDate) ? moment(`${searchObject.fromDate} 00:00:00`).utc().format("YYYY-MM-DD HH:mm:ss") : ``;
    returnData.closedOrderToDate = hasStringValue(searchObject.toDate) ? moment(`${searchObject.toDate} 23:59:59`).utc().format("YYYY-MM-DD HH:mm:ss") : ``;
    returnData.listLoanType = [];

    if (searchObject.orderType) {
        searchObject.orderType.forEach(item => {
            returnData.listLoanType.push(item.value);
        });
    } else {
        listDefaultLoanType.forEach(item => {
            returnData.listLoanType.push(item.value);
        });
    }

    return returnData;
};

export const fetchEconomicClosedOrdersListGridData = (searchObject, options, invalidData) => {
    return (dispatch, getState) => {
        if (!_validateData(invalidData)) return 0;

        return apiFetchEconomicClosedOrderDrilldownData({
            searchObject: _buildSearchObjectForMixChart(searchObject, getState) || {}
        }, (rs) => {
            dispatch({ data: rs.data.data, type: RECEIVE_ECONOMICS_CLOSED_ORDERS_DRILLDOWN_DATA, criteria: options });
        }, err => handleApiError(dispatch, err));
    };
};

export const countEconomicClosedOrderListGridData = (searchObject, invalidData) => {
    return (dispatch, getState) => {
        if (!_validateData(invalidData)) return 0;

        return apiCountEconomicClosedOrderDrilldownData({ searchObject: _buildSearchObjectForMixChart(searchObject, getState) || {} }, (rs) => {
            dispatch({ data: rs.data, type: RECEIVE_ECONOMICS_CLOSED_ORDERS_DRILLDOWN_COUNT_TOTAL_RECORDS });
        }, err => handleApiError(dispatch, err));
    };
};

//get mix chart data
export const fetchEconomicMixChartData = (searchObject, invalidData) => {
    return (dispatch, getState) => {
        if (!_validateData(invalidData)) return 0;

        return apiFetchEconomicMixChartData({ searchObject: _buildSearchObjectForMixChart(searchObject, getState) }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const secColors = getState().cannedReport.main.secondaryColors;
            const data = clone(rs.data);
            data.datasets = data.datasets.map((i, index) => {
                const color = colors[index];
                if (i.type === "line") {
                    return {
                        ...i,
                        fill: false,
                        borderColor: secColors[0],
                        backgroundColor: secColors[0],
                        pointBorderColor: secColors[0],
                        pointBackgroundColor: secColors[0],
                        pointHoverBackgroundColor: secColors[0],
                        pointHoverBorderColor: secColors[0]
                    };
                }

                return {
                    ...i,
                    fill: false,
                    backgroundColor: color,
                    borderColor: color,
                    hoverBackgroundColor: color,
                    hoverBorderColor: color
                };
            });

            dispatch({
                type: RECEIVE_ECONIMICS_MIX_CHART_DATA,
                data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const getListDefaultLoanType = (cb = () => { }) => {
    return dispatch => {
        apiGetListLoanTypeForMixChart(rs => {
            dispatch({
                type: RECEIVE_ECONOMICS_MIX_CHART_LIST_DEFAULT_LOANTYPE,
                data: rs.data
            });
            cb();
        }, err => handleApiError(dispatch, err));
    };
};