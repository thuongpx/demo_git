import {
    apiFetchOrderByStatusChartData,
    apiFetchOrderByStatusGridData,
    apiCountOrderByStatusGridData,
    apiFetchOrderComparisonByBussinessChartData,
    apiFetchDailyAutoAssignedOrderByStatusChartData,
    apiFetchDailyAutoAssignOrdersByStatusGridData,
    apicountDailyAutoAssignOrdersByStatusGridData,
    apiFetchDailyManualAssignedOrderByStatusChartData,
    apiFetchDailyManualAssignOrdersByStatusGridData,
    apicountDailyManualAssignOrdersByStatusGridData,
    apiGetMetricRevenue,
    apiGetMetricOpenedVolume,
    apiGetMetricClosedVolume,
    apiGetMetricGrossProfit,
    apiDownloadComparisonByBusinessDayGridData,
    apiDownloadOrderByStatusGridData,
    apiDailyAutoAssignedOrdersByStatusGrid,
    apiDailyManualAssignedOrdersByStatusGrid,
    apiDailylAssignedOrdersByStatusGrid,
    apiDownloadComparisonByBusinessDayGridDataForStaff
} from "../../../api/canned-report-api";
import { handleApiError } from "ErrorHandler";
import clone from "clone";
import moment from "moment";
import { USER_TYPE, CHARJS_CONSTANTS } from "../../../constant/constants";
import { hasStringValue } from "../../../helpers/common-helper";
import { showSuccess } from "../../main-layout/actions";

export const FETCH_ORDER_BY_STATUS_CHART_DATA = "FETCH_ORDER_BY_STATUS_CHART_DATA";
export const FETCH_ORDER_BY_STATUS_GRID_DATA = "FETCH_ORDER_BY_STATUS_GRID_DATA";
export const COUNT_ORDER_BY_STATUS_GRID_DATA = "COUNT_ORDER_BY_STATUS_GRID_DATA";
export const FETCH_ORDER_COMPARISON_BY_BUSINESS_DAY_CHART_DATA = "FETCH_ORDER_COMPARISON_BY_BUSINESS_DAY_CHART_DATA";
export const FETCH_ORDER_COMPARISON_BY_BUSINESS_DAY_GRID_DATA = "FETCH_ORDER_COMPARISON_BY_BUSINESS_DAY_GRID_DATA";
export const COUNT_ORDER_COMPARISON_BY_BUSINESS_DAY_GRID_DATA = "COUNT_ORDER_COMPARISON_BY_BUSINESS_DAY_GRID_DATA";
export const FETCH_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_CHAR_DATA = "FETCH_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_CHAR_DATA";
export const FETCH_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_GRID_DATA = "FETCH_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_GRID_DATA";
export const COUNT_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_GRID_DATA = "COUNT_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_GRID_DATA";
export const FETCH_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_CHAR_DATA = "FETCH_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_CHAR_DATA";
export const FETCH_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_GRID_DATA = "FETCH_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_GRID_DATA";
export const COUNT_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_GRID_DATA = "COUNT_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_GRID_DATA";
export const GET_METRIC_GROSS_PROFIT = "GET_METRIC_GROSS_PROFIT";
export const CLEAR_DAILY_REPORT = "CLEAR_DAILY_REPORT";
export const GET_METRIC_OPENED_VOLUME = "GET_METRIC_OPENED_VOLUME";
export const REQUEST_METRIC_CLOSED_VOLUME = "REQUEST_METRIC_CLOSED_VOLUME";
export const RECEIVE_METRIC_CLOSED_VOLUME = "RECEIVE_METRIC_CLOSED_VOLUME";

export const RECEIVE_METRIC_REVENUE = "RECEIVE_METRIC_REVENUE";
export const REQUEST_METRIC_REVENUE = "REQUEST_METRIC_REVENUE";


export const clearDailyReport = () => {
    return {
        type: CLEAR_DAILY_REPORT
    };
};

export const fetchOrderByStatusChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchOrderByStatusChartData({ searchObject }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;

            rs.data.datasets = rs.data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });

            dispatch({
                type: FETCH_ORDER_BY_STATUS_CHART_DATA,
                payload: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchOrderByStatusGridData = (searchObject, options, reduxType) => {
    return (dispatch) => {
        return apiFetchOrderByStatusGridData({
            searchObject: searchObject || {},
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {
                item.Agents = `${item.AgentFirstName || ""} ${item.AgentLastName || ""}`;
                if (item.ClosingDate) {
                    item.ClosingDate = moment(item.ClosingDate).utc().format("YYYY-MM-DD HH:mm:ss");
                }

                if (item.OpenDate) {
                    item.OpenDate = moment(item.OpenDate).utc().format("YYYY-MM-DD HH:mm:ss");
                }

                return item;
            });

            dispatch({
                type: reduxType || FETCH_ORDER_BY_STATUS_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const countOrderByStatusGridData = (searchObject, reduxType) => {
    return (dispatch) => {
        return apiCountOrderByStatusGridData({ searchObject: searchObject || {} }, (rs) => {
            dispatch({
                type: reduxType || COUNT_ORDER_BY_STATUS_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

const _buildDefaultSearchObjectForDayComparision = (searchObject, getState) => {
    const { cannedReport, authentication } = getState();
    const { role } = authentication;
    const { roleType } = role;
    const { main } = cannedReport;
    const { months } = main;

    // get default months
    const curMonthVal = Number(moment().utc().format("M"));
    const preMonthVal = curMonthVal - 1;

    // get current month label and previous month label
    const curMonth = months.find(m => Number(m.value) === curMonthVal);
    const preMonth = months.find(m => Number(m.value) === preMonthVal);

    // if search object is null or undefinied, assign it as an empty object
    if (!searchObject) searchObject = {};

    // if day from is empty, assign it to 1
    if (!hasStringValue(searchObject.dayFrom)) searchObject.dayFrom = "1";

    // if day to is empty, assign it to the current day
    if (!hasStringValue(searchObject.dayTo)) searchObject.dayTo = `${moment().utc().format("D")}`;

    // if month(s) are not selected, assign it as the current month and the previous month
    if (!hasStringValue(searchObject.month) || (searchObject.month.length === 0)) {
        searchObject.month = [{ ...curMonth }, { ...preMonth }];
    }
    // if roleType is Staff, assign fullService equals 1
    if (roleType === USER_TYPE.Staff) { searchObject.isFullService = true; } else { delete searchObject.isFullService; }

    searchObject.year = Number(moment().utc().format("YYYY"));

    return searchObject;
};

const _builDefaultSearchObjectDayCurrentDailyCounterReport = (searchObject, getState) => {

    const { authentication } = getState();
    const { role } = authentication;
    const { roleType } = role;

    // if search object is null or undefinied, assign it as an empty object
    if (!searchObject) searchObject = {};

    // if day to is empty, assign it to the current day ${moment("07/18/2018").utc().format("YYYY-MM-DD")}
    // if (!hasStringValue(searchObject.date)) searchObject.date = `2018-07-18`;
    if (!hasStringValue(searchObject.date)) searchObject.date = `${moment().utc().format("YYYY-MM-DD")}`;

    // if roleType is Staff, assign fullService equals 1
    if (roleType === USER_TYPE.Staff) { searchObject.isFullService = true; } else { delete searchObject.isFullService; }

    return searchObject;
};

//Business Day
export const fetchOrderComparisonByBusinessDayChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchOrderComparisonByBussinessChartData({ searchObject: _buildDefaultSearchObjectForDayComparision(searchObject, getState) }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const data = clone(rs.data);
            data.datasets = data.datasets.map((i, index) => {
                return {
                    ...i,
                    backgroundColor: colors[index]
                };
            });

            dispatch({
                type: FETCH_ORDER_COMPARISON_BY_BUSINESS_DAY_CHART_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchOrderComparisonByBusinessDayGridData = (searchObject, options) => {
    return (dispatch, getState) => {
        dispatch(fetchOrderByStatusGridData(
            _buildDefaultSearchObjectForDayComparision(searchObject, getState), options,
            FETCH_ORDER_COMPARISON_BY_BUSINESS_DAY_GRID_DATA));
    };
};

export const countOrderComparisonByBusinessDayGridData = (searchObject) => {
    return (dispatch, getState) => dispatch(countOrderByStatusGridData(
        _buildDefaultSearchObjectForDayComparision(searchObject, getState),
        COUNT_ORDER_COMPARISON_BY_BUSINESS_DAY_GRID_DATA));
};

//daily auto assgined order by status

export const fetchDailyAutoAssignedOrderByStatusChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchDailyAutoAssignedOrderByStatusChartData({ searchObject: _builDefaultSearchObjectDayCurrentDailyCounterReport(searchObject, getState) }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const secColors = getState().cannedReport.main.secondaryColors;

            const data = {
                labels: rs.data.labels,
                datasets: []
            };
            const lData = rs.data.datasets.find(i => i.type === CHARJS_CONSTANTS.LINE);
            if (lData) {
                data.datasets.push({
                    ...lData,
                    fill: false,
                    borderColor: secColors[0],
                    backgroundColor: secColors[0],
                    pointBorderColor: secColors[0],
                    pointBackgroundColor: secColors[0],
                    pointHoverBackgroundColor: secColors[0],
                    pointHoverBorderColor: secColors[0],
                    yAxisID: "y-axis-2"
                });
            }

            const bData = rs.data.datasets.find(i => i.type === CHARJS_CONSTANTS.BAR);
            if (bData) {
                data.datasets.push({
                    ...bData,
                    fill: false,
                    backgroundColor: colors[0],
                    borderColor: colors[0],
                    hoverBackgroundColor: colors[0],
                    hoverBorderColor: colors[0],
                    yAxisID: "y-axis-1"
                });
            }

            dispatch({
                type: FETCH_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_CHAR_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchDailyAutoAssignedOrderByStatusGridData = (searchObject, options, reduxType) => {
    return (dispatch, getState) => {
        return apiFetchDailyAutoAssignOrdersByStatusGridData({
            searchObject: _builDefaultSearchObjectDayCurrentDailyCounterReport(searchObject, getState) || {},
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {
                item.Agents = `${item.AgentFirstName || ""} ${item.AgentLastName || ""}`;
                if (item.ClosingDate) {
                    item.ClosingDate = moment(item.ClosingDate).utc().format("YYYY-MM-DD HH:mm:ss");
                }

                if (item.OpenDate) {
                    item.OpenDate = moment(item.OpenDate).utc().format("YYYY-MM-DD HH:mm:ss");
                }

                return item;
            });

            dispatch({
                type: reduxType || FETCH_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const countDailyAutoAssignedOrderByStatusGridData = (searchObject, reduxType) => {
    return (dispatch, getState) => {
        return apicountDailyAutoAssignOrdersByStatusGridData({ searchObject: _builDefaultSearchObjectDayCurrentDailyCounterReport(searchObject, getState) } || {}, (rs) => {
            dispatch({
                type: reduxType || COUNT_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

//daily manual assgined order by status

export const fetchDailyManualAssignedOrderByStatusChartData = (searchObject) => {
    return (dispatch, getState) => {
        return apiFetchDailyManualAssignedOrderByStatusChartData({ searchObject: _builDefaultSearchObjectDayCurrentDailyCounterReport(searchObject, getState) }, (rs) => {
            // add color to datasets
            const colors = getState().cannedReport.main.colors;
            const secColors = getState().cannedReport.main.secondaryColors;

            const data = {
                labels: rs.data.labels,
                datasets: []
            };
            const lData = rs.data.datasets.find(i => i.type === CHARJS_CONSTANTS.LINE);
            if (lData) {
                data.datasets.push({
                    ...lData,
                    fill: false,
                    borderColor: secColors[0],
                    backgroundColor: secColors[0],
                    pointBorderColor: secColors[0],
                    pointBackgroundColor: secColors[0],
                    pointHoverBackgroundColor: secColors[0],
                    pointHoverBorderColor: secColors[0],
                    yAxisID: "y-axis-2"
                });
            }

            const bData = rs.data.datasets.find(i => i.type === CHARJS_CONSTANTS.BAR);
            if (bData) {
                data.datasets.push({
                    ...bData,
                    fill: false,
                    backgroundColor: colors[0],
                    borderColor: colors[0],
                    hoverBackgroundColor: colors[0],
                    hoverBorderColor: colors[0],
                    yAxisID: "y-axis-1"
                });
            }

            dispatch({
                type: FETCH_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_CHAR_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const fetchDailyManualAssignedOrderByStatusGridData = (searchObject, options, reduxType) => {
    return (dispatch, getState) => {
        return apiFetchDailyManualAssignOrdersByStatusGridData({
            searchObject: _builDefaultSearchObjectDayCurrentDailyCounterReport(searchObject, getState) || {},
            options: options || {}
        }, (rs) => {
            const data = rs.data.data.map(item => {
                item.Agents = `${item.AgentFirstName || ""} ${item.AgentLastName || ""}`;
                if (item.ClosingDate) {
                    item.ClosingDate = moment(item.ClosingDate).utc().format("YYYY-MM-DD HH:mm:ss");
                }

                if (item.OpenDate) {
                    item.OpenDate = moment(item.OpenDate).utc().format("YYYY-MM-DD HH:mm:ss");
                }

                return item;
            });

            dispatch({
                type: reduxType || FETCH_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_GRID_DATA,
                payload: data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const countDailyManualAssignedOrderByStatusGridData = (searchObject, reduxType) => {
    return (dispatch, getState) => {
        return apicountDailyManualAssignOrdersByStatusGridData({ searchObject: _builDefaultSearchObjectDayCurrentDailyCounterReport(searchObject, getState) } || {}, (rs) => {
            dispatch({
                type: reduxType || COUNT_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_GRID_DATA,
                count: rs.data
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const getMetricOpenedVolume = () => {
    return dispatch => {
        return apiGetMetricOpenedVolume((rs) => {
            const mtd = clone(rs.data.mtd);
            const today = clone(rs.data.today);
            dispatch({
                type: GET_METRIC_OPENED_VOLUME,
                mtd,
                today
            });
        }, err => handleApiError(dispatch, err));
    };
};

export const getMetricGrossProfit = () => {
    return dispatch => {
        return apiGetMetricGrossProfit((rs) => {
            const today = clone(rs.data.today);
            const mtd = clone(rs.data.mtd);
            dispatch({
                type: GET_METRIC_GROSS_PROFIT,
                today,
                mtd
            });
        },
            err => handleApiError(dispatch, err));
    };
};

//Closed Volume Metric
export const requestMetricClosedVolume = () => {
    return {
        type: REQUEST_METRIC_CLOSED_VOLUME
    };
};

export const receiveMetricClosedVolume = (data) => {
    return {
        type: RECEIVE_METRIC_CLOSED_VOLUME,
        closedVolumeToday: data.closedVolumeToday,
        closedVolumeMtd: data.closedVolumeMtd
    };
};

export const getMetricClosedVolume = () => {
    return dispatch => {
        dispatch(requestMetricClosedVolume());
        return apiGetMetricClosedVolume(result => {
            dispatch(receiveMetricClosedVolume(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};
//revenue
export const receiveMetricRevenue = (today, mtd) => {
    return {
        type: RECEIVE_METRIC_REVENUE,
        today,
        mtd
    };
};

export const requestMetricRevenue = () => {
    return {
        type: REQUEST_METRIC_REVENUE
    };
};


export const getMetricRevenue = () => {
    return dispatch => {
        dispatch(requestMetricRevenue());
        return apiGetMetricRevenue((result) => {
            dispatch(receiveMetricRevenue(result.data.today, result.data.mtd));

        }, err => handleApiError(dispatch, err));
    };
};

// exportComparisonByBusinessDayGridData

export const exportComparisonByBusinessDayGridData = (searchObject) => {
    return (dispatch, getState) => {
        return apiDownloadComparisonByBusinessDayGridData({
            searchObject: _buildDefaultSearchObjectForDayComparision(searchObject, getState) || {}
        }, `Comparison_By_Business_Day${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};

// exportOrderByStatusGridData
export const exportOrderByStatusGridData = (searchObject) => {
    return (dispatch) => {
        return apiDownloadOrderByStatusGridData({
            searchObject: searchObject || {}
        }, `Open_Order_List_by_Status${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};

// exportDailyAutoAssignedOrdersByStatusGrid

export const exportDailyAutoAssignedOrdersByStatusGrid = (searchObject) => {
    return (dispatch, getState) => {
        return apiDailyAutoAssignedOrdersByStatusGrid({
            searchObject: _builDefaultSearchObjectDayCurrentDailyCounterReport(searchObject, getState) || {}
        }, `Daily_Auto_Assigned_Orders_By_Status${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};

// exportDailyManualAssignedOrdersByStatusGrid

export const exportDailyManualAssignedOrdersByStatusGrid = (searchObject) => {
    return (dispatch, getState) => {
        return apiDailyManualAssignedOrdersByStatusGrid({
            searchObject: _builDefaultSearchObjectDayCurrentDailyCounterReport(searchObject, getState) || {}
        }, `Daily_Manual_Assigned_Orders_By_Status${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};

// exportDailyAssignedOrdersByStatusGrid

export const exportDailyAssignedOrdersByStatusGrid = (searchObject) => {
    return (dispatch, getState) => {
        return apiDailylAssignedOrdersByStatusGrid({
            searchObject: _builDefaultSearchObjectDayCurrentDailyCounterReport(searchObject, getState) || {}
        }, `View_All_Orders_By_Status${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};

// exportComparisonByBusinessDayGridData

export const exportComparisonByBusinessDayGridDataForStaff = (searchObject) => {
    return (dispatch, getState) => {
        return apiDownloadComparisonByBusinessDayGridDataForStaff({
            searchObject: _buildDefaultSearchObjectForDayComparision(searchObject, getState) || {}
        }, `Comparison_By_Business_Day_For_Staff${moment().format("YYYYMMDD")}.xlsx`, () => {
            dispatch(showSuccess("Export Successfully"));
        }, err => handleApiError(dispatch, err));
    };
};