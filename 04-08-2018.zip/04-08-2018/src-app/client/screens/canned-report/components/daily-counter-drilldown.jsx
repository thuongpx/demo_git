import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { USER_TYPE } from "../../../constant/constants";

class DailyCounterDrillDown extends Component {
    constructor(props) {
        super(props);
        const { roleType } = this.props;

        this.state = {
            autoRow: true,
            manualRow: true
        };

        this._isStaff = roleType === USER_TYPE.Staff;
    }

    handleShowRowDetail(isAuto) {
        if (isAuto) {
            this.setState(prevState => ({
                autoRow: !prevState.autoRow
            }));
        } else {
            this.setState(prevState => ({
                manualRow: !prevState.manualRow
            }));
        }
    }

    renderColumns(columns) {
        return columns.map((item, key) => {
            return (
                <th key={key}>
                    {item.title}
                </th>
            );
        });
    }

    renderTablesAutoByClient(dataSourceAuto, autoRow) {
        if (dataSourceAuto.length === 0) {
            return (
                <div className={autoRow ? "" : "hide"}>
                    <td>There are no records to show</td>
                </div>
            );
        } else {
            return dataSourceAuto.map((data, index) => {
                return (
                    <tr key={index} className={(autoRow || (!autoRow && index === (dataSourceAuto.length - 1))) ? "" : "hide"}>
                        <td>{data.OrderStatus}</td>
                        <td>{data.TotalOrder}</td>
                        <td>{data.SumOfAssignTime}</td>
                        <td>{data.AverageOfAssignTime}</td>
                    </tr>
                );
            });
        }
    }

    renderTablesAutoByStaff(dataSourceAuto, autoRow) {
        if (dataSourceAuto.length === 0) {
            return (
                <div className={autoRow ? "" : "hide"}>
                    <td>There are no records to show</td>
                </div>
            );
        } else {
            return dataSourceAuto.map((data, index) => {
                return (
                    <tr key={index} className={(autoRow || (!autoRow && index === (dataSourceAuto.length - 1))) ? "" : "hide"}>
                        <td>{data.OrderStatus}</td>
                        <td>{data.TotalOrder}</td>
                        <td>{data.SumOfProfit}</td>
                        <td>{data.AverageProfit}</td>
                        <td>{data.SumOfAssignTime}</td>
                        <td>{data.AverageOfAssignTime}</td>
                    </tr>
                );
            });
        }
    }

    renderTablesManualByClient(dataSourceManual, manualRow) {
        if (dataSourceManual.length === 0) {
            return (
                <div className={manualRow ? "" : "hide"}>
                    <td>There are no records to show</td>
                </div>
            );
        } else {
            return dataSourceManual.map((data, index) => {
                return (
                    <tr key={index} className={(manualRow || (!manualRow && index === (dataSourceManual.length - 1))) ? "" : "hide"}>
                        <td>{data.OrderStatus}</td>
                        <td>{data.TotalOrder}</td>
                        <td>{data.SumOfAssignTime}</td>
                        <td>{data.AverageOfAssignTime}</td>
                    </tr>
                );
            });
        }
    }

    renderTablesManualByStaff(dataSourceManual, manualRow) {
        if (dataSourceManual.length === 0) {
            return (
                <div className={manualRow ? "" : "hide"}>
                    <td>There are no records to show</td>
                </div>
            );
        } else {
            return dataSourceManual.map((data, index) => {
                return (
                    <tr key={index} className={(manualRow || (!manualRow && index === (dataSourceManual.length - 1))) ? "" : "hide"}>
                        <td>{data.OrderStatus}</td>
                        <td>{data.TotalOrder}</td>
                        <td>{data.SumOfProfit}</td>
                        <td>{data.AverageProfit}</td>
                        <td>{data.SumOfAssignTime}</td>
                        <td>{data.AverageOfAssignTime}</td>
                    </tr>
                );
            });
        }
    }

    renderDesignClient() {
        const array = ["", "", ""];
        return array.map(index => {
            return (
                <td key={index}></td>
            );
        });
    }

    renderDesignStaff() {
        const array = ["", "", "", "", ""];
        return array.map(index => {
            return (
                <td key={index}></td>
            );
        });
    }

    render() {
        const { autoRow, manualRow } = this.state;
        const { datasources, columns, totalRecords } = this.props;
        let totalSumOfProfit = 0;
        const dataSourceAuto = datasources[0].dataSourceAuto.sort((a, b) => {
            return parseInt(a.TotalOrder) - parseInt(b.TotalOrder);
        });
        const dataSourceManual = datasources[1].dataSourceManual.sort((a, b) => {
            return parseInt(a.TotalOrder) - parseInt(b.TotalOrder);
        });

        if (dataSourceAuto.length === 0 && dataSourceManual.length !== 0) {
            totalSumOfProfit = dataSourceManual[dataSourceManual.length - 1].SumOfProfit;
        } else if (dataSourceAuto.length !== 0 && dataSourceManual.length === 0) {
            totalSumOfProfit = dataSourceAuto[dataSourceAuto.length - 1].SumOfProfit;
        } else if (dataSourceAuto.length !== 0 && dataSourceManual.length !== 0) {
            totalSumOfProfit = dataSourceAuto[dataSourceAuto.length - 1].SumOfProfit + dataSourceManual[dataSourceManual.length - 1].SumOfProfit;
        } else {
            totalSumOfProfit = 0;
        }

        return (
            <div className="tab-content">
                <div className="row">
                    <div className="col s12">
                        <table className="striped highlight responsive-table">
                            <thead>
                                <tr>
                                    {this.renderColumns(columns)}
                                </tr>
                            </thead>
                            <tbody>
                                <tr id="1">
                                    <td><a className="btn-floating waves-effect waves-light green mr-1" onClick={() => this.handleShowRowDetail(true)} >
                                        <i className="material-icons">{(autoRow) ? "keyboard_arrow_down" : "keyboard_arrow_right"}</i>
                                    </a>
                                        <strong>Auto</strong>
                                    </td>
                                    {this._isStaff ? this.renderDesignStaff() : this.renderDesignClient()}
                                </tr>
                                {this._isStaff ? this.renderTablesAutoByStaff(dataSourceAuto, autoRow) : this.renderTablesAutoByClient(dataSourceAuto, autoRow)}
                                <tr id="2">
                                    <td><a className="btn-floating waves-effect waves-light green mr-1" onClick={() => this.handleShowRowDetail(false)} >
                                        <i className="material-icons">{(manualRow) ? "keyboard_arrow_down" : "keyboard_arrow_right"}</i>
                                    </a>
                                        <strong>Manual</strong>
                                    </td>
                                    {this._isStaff ? this.renderDesignStaff() : this.renderDesignClient()}
                                </tr>
                                {this._isStaff ? this.renderTablesManualByStaff(dataSourceManual, manualRow) : this.renderTablesManualByClient(dataSourceManual, manualRow)}
                                <tr>
                                    <td><strong className="font-15 red-color">Total</strong></td>
                                    <td className="font-15 red-color"><strong>{totalRecords}</strong></td>
                                    {this._isStaff ? <td className="font-15 red-color"><strong>{totalSumOfProfit}</strong></td> : ""}
                                    {this._isStaff ? <td></td> : ""}
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        );
    }
}

DailyCounterDrillDown.propTypes = {
    datasources: PropTypes.array,
    columns: PropTypes.array,
    totalRecords: PropTypes.number,
    roleType: PropTypes.string
};

export default DailyCounterDrillDown;