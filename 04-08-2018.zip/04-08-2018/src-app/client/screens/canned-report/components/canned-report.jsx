import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";

import SearchField from "./canned-search-field";
import Select from "../../../features/form/select";
import { guid } from "../../../helpers/crypto-helper";
import { shallowCompareState, shallowCompareProps } from "../../../helpers/common-helper";

import { CHARJS_CONSTANTS, USER_TYPE } from "../../../constant/constants";
import CannedChart from "./canned-chart";
import { openDrillDownModal, updateDrillDownModalDataSource } from "../actions";
import { hasStringValue } from "../../../helpers/validation-helper";
import moment from "moment";
import {
    exportDailyAssignedOrdersByStatusGrid
} from "../actions/daily-report";

class CannedReport extends Component {
    constructor(...args) {
        super(...args);

        this._id = this.props.id || `canned-report-${guid()}`;
        this.invalidData = {};
        this._controlKeys = [];

        if (this.props.controls && this.props.controls.length > 0) {
            this._controlKeys = this.props.controls.map(() => {
                return guid();
            });
        }

        this._isClient = this.props.roleType === USER_TYPE.Client;

        const ids = [this.props.profileId];

        this.state = {
            searchObject: {
                brokerId: this._isClient ? ids : null
            },
            chartType: null,
            isDrilldownOpen: false
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentDidMount() {
        this.reRenderChart();
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.isOpenDrillDown && nextProps.isOpenDrillDown && !shallowCompareProps(this.props.gridOptions, nextProps.gridOptions)) {
            const { dispatch, gridOptions } = nextProps;

            if (gridOptions) {
                dispatch(updateDrillDownModalDataSource(gridOptions.dataSource));
            }
        }
    }

    handleOnChange(e) {
        const searchObj = this.state.searchObject;

        searchObj[e.name] = e.value;
        this.invalidData[e.name] = e.invalidData;

        this.setState({
            searchObject: searchObj
        });

        if (this.props.getChangeObj) this.props.getChangeObj(searchObj);
    }

    reRenderChart() {
        const { onRenderChart } = this.props;
        const { searchObject } = this.state;

        if (onRenderChart) {
            onRenderChart(searchObject, this.invalidData);
        }

        this.handleFetchDrillDownData();
    }

    isInvalidFromDateAndToDate(dateFrom, dateTo) {
        if (!hasStringValue(dateFrom) && !hasStringValue(dateTo)) return false;

        const momentFrom = moment(dateFrom);
        const momentTo = moment(dateTo);

        if (hasStringValue(dateFrom) && momentFrom !== "Invalid date" && !hasStringValue(dateTo)) return false;
        if (hasStringValue(dateTo) && momentTo !== "Invalid date" && !hasStringValue(momentFrom)) return false;
        if (momentFrom !== "Invalid date" && momentTo !== "Invalid date") return momentFrom > momentTo;

        return true;
    }

    isInvalidFromDateAndToDateBySelect(dateFrom, dateTo) {
        if (!hasStringValue(dateFrom) && !hasStringValue(dateTo)) return false;

        if (parseInt(dateFrom) <= parseInt(dateTo)) return false;

        return true;
    }

    renderControls() {
        const { controls, orderStatuses, orderTypes, dayFroms, dayTos, months, customers, agents, feeRequestStatus, schedulers, assignType } = this.props;
        const { searchObject } = this.state;

        if (controls) {
            return controls.map((it, ix) => {
                let type;
                let label;
                let name;
                let dataSource = it.dataSource;
                let defaultValue;
                let subType;
                let compareDate;
                let inValidMess;

                switch (it.type) {
                    case "orderType":
                        type = "multiselect";
                        name = "orderType";
                        label = "Order Type";
                        defaultValue = it.defaultValue || [];
                        dataSource = it.dataSource || orderTypes.map(i => {
                            return {
                                label: i,
                                value: i
                            };
                        });
                        break;
                    case "orderStatus":
                        type = "multiselect";
                        name = "orderStatus";
                        label = "Order Status";
                        dataSource = orderStatuses.map(i => {
                            return {
                                label: i,
                                value: i
                            };
                        });
                        break;
                    case "dayFrom":
                        type = "select";
                        name = "dayFrom";
                        label = "Day From";
                        inValidMess = "‘Date From’ cannot be later than ‘To’ field. Please re-enter!";
                        this.invalidData[name] = this.isInvalidFromDateAndToDateBySelect(searchObject[name], searchObject.dayTo);
                        dataSource = dayFroms.map(i => {
                            return {
                                label: i,
                                value: i
                            };
                        });
                        break;
                    case "dayTo":
                        type = "select";
                        label = "Day To";
                        name = "dayTo";
                        inValidMess = "‘Date From’ cannot be later than ‘To’ field. Please re-enter!";
                        this.invalidData[name] = this.isInvalidFromDateAndToDateBySelect(searchObject.dayFrom, searchObject[name]);
                        dataSource = dayTos.map(i => {
                            return {
                                label: i,
                                value: i
                            };
                        });
                        break;
                    case "month":
                        type = "multiselect";
                        label = "Month";
                        name = "month";
                        dataSource = months.map(i => {
                            return {
                                label: i.label,
                                value: i.value
                            };
                        });
                        break;
                    case "agents":
                        type = "multiselect";
                        label = "Agents";
                        name = "agents";
                        dataSource = agents.map((i) => {
                            return {
                                label: i.label,
                                value: i.value
                            };
                        });
                        break;
                    case "customer":
                        type = "select";
                        label = "Customer";
                        name = "customer";
                        this.invalidData[name] = false;
                        dataSource = customers.map(i => {
                            return {
                                label: i.label,
                                value: i.value
                            };
                        });
                        break;
                    case "agent":
                        type = "multiselect";
                        label = "Agent";
                        name = "agentId";
                        defaultValue = it.defaultValue;
                        break;
                    case "feeRequestStatus":
                        type = "multiselect";
                        label = "Status";
                        name = "status";
                        dataSource = feeRequestStatus;
                        break;
                    case "reqFromDate":
                        type = "datepicker";
                        label = "Req Date From";
                        name = "reqFromDate";
                        defaultValue = it.defaultValue;
                        subType = "fromdate";
                        compareDate = it.compareDate;
                        inValidMess = it.inValidMess;
                        this.invalidData[name] = this.isInvalidFromDateAndToDate((searchObject[name] || defaultValue || ""), it.compareDate);
                        break;
                    case "reqToDate":
                        type = "datepicker";
                        label = "Req Date To";
                        name = "reqToDate";
                        defaultValue = it.defaultValue;
                        subType = "todate";
                        compareDate = it.compareDate;
                        inValidMess = it.inValidMess;
                        this.invalidData[name] = this.isInvalidFromDateAndToDate(it.compareDate, (searchObject[name] || defaultValue || ""));
                        break;
                    case "fromDate":
                        type = "datepicker";
                        label = "Date From";
                        name = "fromDate";
                        defaultValue = it.defaultValue;
                        subType = "fromdate";
                        compareDate = it.compareDate;
                        inValidMess = it.inValidMess;
                        this.invalidData[name] = this.isInvalidFromDateAndToDate((searchObject[name] || defaultValue || ""), it.compareDate);
                        break;
                    case "toDate":
                        type = "datepicker";
                        label = "Date To";
                        name = "toDate";
                        defaultValue = it.defaultValue;
                        subType = "todate";
                        compareDate = it.compareDate;
                        inValidMess = it.inValidMess;
                        this.invalidData[name] = this.isInvalidFromDateAndToDate(it.compareDate, (searchObject[name] || defaultValue || ""));
                        break;
                    case "agentStaff":
                        type = "select";
                        label = "Agent";
                        name = "agent";
                        this.invalidData[name] = false;
                        defaultValue = it.defaultValue;
                        dataSource = customers.map(i => {
                            return {
                                label: i.label,
                                value: i.value
                            };
                        });
                        break;
                    case "schedulers":
                        type = "multiselect";
                        label = "Scheduler";
                        name = "schedulers";
                        dataSource = schedulers.map((i) => {
                            return {
                                label: i.label,
                                value: i.value
                            };
                        });
                        break;
                    case "assignType":
                        type = "select";
                        label = "Assign Type";
                        name = "assignType";
                        defaultValue = moment().format("MM").toString();
                        dataSource = assignType;
                        break;
                    case "singleMonth":
                        type = "select";
                        label = "Month";
                        name = "month";
                        this.invalidData[name] = false;
                        dataSource = months;
                        break;
                    case "monthEconomic":
                        type = "multiselect";
                        label = "Month";
                        name = "monthEconomic";
                        dataSource = months.map(i => {
                            return {
                                label: i.label,
                                value: i.value
                            };
                        });
                        break;
                }

                const inputValue = searchObject[name] !== undefined ? searchObject[name] : (defaultValue || "");

                return (
                    <SearchField
                        id={this._controlKeys[ix]}
                        key={this._controlKeys[ix]}
                        dataSource={dataSource}
                        name={name}
                        className={it.classes}
                        type={type}
                        subType={subType || ""}
                        compareDate={compareDate}
                        label={label}
                        inValidMess={inValidMess || ""}
                        inputValue={inputValue}
                        onValueChange={(e) => this.handleOnChange(e)}
                        invalidData={this.invalidData[name]}
                    />
                );
            });
        }

        return <div></div>;
    }

    onGraphChange(e) {
        this.setState({
            chartType: e.value
        });
    }

    renderButtonViewAll(classes) {
        return (
            <div className={classes || "col s6"}>
                <button type="button" className="btn default-color w-100 btn-small mt-2 truncate modal-trigger" data-target="modalShowAll"
                    onClick={() => this.handleClickButtonShowAll()}
                >
                    View All Orders by Status</button>
            </div>
        );
    }

    renderButtonApply(classes) {
        return (
            <div className={classes || "col s6"}>
                <button id={`${this._id}-apply`} type="button" className="btn success-color w-100 btn-small mt-2" onClick={() => this.reRenderChart()}> Apply</button>
            </div>
        );
    }

    renderGraphSelect() {
        const source = [
            {
                label: "Column",
                type: CHARJS_CONSTANTS.BAR
            },
            {
                label: "Line",
                type: CHARJS_CONSTANTS.LINE
            },
            {
                label: "Clustered Column",
                type: CHARJS_CONSTANTS.BAR
            }
        ];

        const { chartType } = this.state;

        return (
            <div id={guid()} className={"col s6"}>
                <div className="input-field">
                    <Select
                        value={chartType || ""}
                        dataSource={source}
                        mapDataToRenderOptions={{ value: "type", label: "label" }}
                        onChange={(value) => this.onGraphChange({ value, name })}
                    />
                    <label>Select Graph</label>
                </div>
            </div>
        );
    }

    handleClickButtonShowAll() {
        const { dispatch, dailyAutoAssignedOrdersByStatusTotalRecord, dailyAutoAssignedOrdersByStatusGridData, dailyManualAssignedOrdersByStatusGridData, roleType } = this.props;
        const { searchObject } = this.state;
        const gridOptionsByClient = {
            type: "dailyCounter",
            label: "View All Orders by Status",
            totalRecord: dailyAutoAssignedOrdersByStatusTotalRecord,
            dataSource: [
                { dataSourceAuto: dailyAutoAssignedOrdersByStatusGridData || [] },
                { dataSourceManual: dailyManualAssignedOrdersByStatusGridData || [] }
            ],
            columns: [
                { SortOrder: 0, title: "Open Status", data: "OrderStatus", id: "OrderId" },
                { SortOrder: 1, title: "Total Order", data: "TotalOrder" },
                { SortOrder: 3, title: "Sum Of Assign Time", data: "SumOfAssignTime" },
                { SortOrder: 4, title: "Average Of Assign Time", data: "AverageOfAssignTime" }
            ],
            exportDrilldownData: () => dispatch(exportDailyAssignedOrdersByStatusGrid(searchObject))
        };
        const gridOptionsByStaff = {
            type: "dailyCounter",
            label: "View All Orders by Status",
            totalRecord: dailyAutoAssignedOrdersByStatusTotalRecord,
            dataSource: [
                { dataSourceAuto: dailyAutoAssignedOrdersByStatusGridData || [] },
                { dataSourceManual: dailyManualAssignedOrdersByStatusGridData || [] }
            ],
            columns: [
                { SortOrder: 0, title: "Open Status", data: "OrderStatus", id: "OrderId" },
                { SortOrder: 1, title: "Total Order", data: "TotalOrder" },
                { SortOrder: 2, title: "Sum of Profit", data: "SumOfProfit" },
                { SortOrder: 3, title: "Average profit", data: "AverageProfit" },
                { SortOrder: 4, title: "Sum Of Assign Time", data: "SumOfAssignTime" },
                { SortOrder: 5, title: "Average Of Assign Time", data: "AverageOfAssignTime" }
            ]
        };

        if (roleType === USER_TYPE.Staff) {
            dispatch(openDrillDownModal({ ...gridOptionsByStaff, searchObject }));
        } else {
            dispatch(openDrillDownModal({ ...gridOptionsByClient, searchObject }));
        }
    }

    validateData(data) {
        if (!data) return true;

        let check = true;
        Object.keys(data).forEach(item => {
            if (data[item]) check = false;
        });

        return check;
    }

    handleOnChartClick() {
        const { dispatch, gridOptions } = this.props;
        const { searchObject } = this.state;

        if (!this.validateData(this.invalidData)) {
            return;
        }

        if (gridOptions) {
            // set page to the first page
            gridOptions.criteria = {
                ...gridOptions.criteria,
                page: 1
            };

            dispatch(openDrillDownModal({ ...gridOptions, searchObject }));
        }
    }

    handleFetchDrillDownData() {
        const { gridOptions } = this.props;

        if (gridOptions) {
            const { searchObject } = this.state;

            // get grid data
            gridOptions.fetchDrilldownData(searchObject, gridOptions.criteria, this.invalidData);
            gridOptions.countDrilldownRecord(searchObject, gridOptions.criteria, this.invalidData);
        }
    }

    render() {
        const { changeChartType, isShowButtonViewAll } = this.props;
        const { chartData, id, chartWidth, chartHeight, chartLabel, chartType, controls } = this.props;
        const { buttonShowAllClasses, buttonApplyClasses } = this.props;

        return (
            <div id={this._id}>
                <div className="canned-report-control-box">
                    {controls &&
                        <div>
                            <div className="row">
                                {this.renderControls()}
                                {changeChartType && this.renderGraphSelect()}
                                {isShowButtonViewAll && this.renderButtonViewAll(buttonShowAllClasses)}
                                {this.renderButtonApply(buttonApplyClasses)}
                            </div>
                        </div>
                    }
                </div>
                <div className="canned-report-chart-box">
                    <CannedChart
                        type={this.state.chartType || chartType}
                        dataSource={chartData}
                        id={id}
                        width={chartWidth}
                        height={chartHeight}
                        label={chartLabel}
                        handleOnChartClick={() => this.handleOnChartClick()}
                    />
                </div>
            </div>
        );
    }
}

CannedReport.propTypes = {
    id: PropTypes.string,
    chartData: PropTypes.object,
    chartType: PropTypes.string,
    chartLabel: PropTypes.string,
    chartHeight: PropTypes.number,
    chartWidth: PropTypes.number,
    gridOptions: PropTypes.object,
    fetchDrilldownData: PropTypes.func,
    changeChartType: PropTypes.bool,
    controls: PropTypes.array,
    onRenderChart: PropTypes.func,
    onOpenDrill: PropTypes.func,

    orderStatuses: PropTypes.array,
    orderTypes: PropTypes.array,
    dayFroms: PropTypes.array,
    dayTos: PropTypes.array,
    months: PropTypes.array,
    agents: PropTypes.array,

    dispatch: PropTypes.func,
    isShowButtonViewAll: PropTypes.bool,

    customers: PropTypes.array,

    dailyAutoAssignedOrdersByStatusGridData: PropTypes.array,
    dailyAutoAssignedOrdersByStatusTotalRecord: PropTypes.number,

    dailyManualAssignedOrdersByStatusGridData: PropTypes.array,
    dailyManualAssignedOrdersByStatusTotalRecord: PropTypes.number,
    feeRequestStatus: PropTypes.array,
    getChangeObj: PropTypes.func,

    roleType: PropTypes.string,
    profileId: PropTypes.number,
    gid: PropTypes.number,
    schedulers: PropTypes.array,
    assignType: PropTypes.array,

    buttonShowAllClasses: PropTypes.string,
    buttonApplyClasses: PropTypes.string,

    isOpenDrillDown: PropTypes.bool
};

const mapStateToProps = (state) => {
    const { cannedReport, authentication } = state;
    const { main, dailyReport } = cannedReport;
    const { role, profile } = authentication;

    return {
        orderStatuses: main.orderStatuses,
        orderTypes: main.orderTypes,
        isRequestingGridData: main.isRequestingGridData,
        dayTos: main.dayTos,
        dayFroms: main.dayFroms,
        months: main.months,
        agents: main.agents,
        customers: main.customers,
        feeRequestStatus: main.feeRequestStatus,

        dailyAutoAssignedOrdersByStatusTotalRecord: dailyReport.dailyAutoAssignedOrdersByStatusTotalRecord,
        dailyAutoAssignedOrdersByStatusGridData: dailyReport.dailyAutoAssignedOrdersByStatusGridData,

        dailyManualAssignedOrdersByStatusGridData: dailyReport.dailyManualAssignedOrdersByStatusGridData,
        dailyManualAssignedOrdersByStatusTotalRecord: dailyReport.dailyManualAssignedOrdersByStatusTotalRecord,

        roleType: role ? role.roleType : null,
        profileId: profile.id,
        gid: profile.GID,

        schedulers: main.schedulers,
        assignType: main.assignType,

        isOpenDrillDown: main.isOpenDrillDown
    };
};

export default connect(mapStateToProps)(CannedReport);