import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";

import { shallowCompareState, shallowCompareProps, hasStringValue } from "../../../helpers/common-helper";
import { guid } from "../../../helpers/crypto-helper";

import Select from "../../../features/form/select";
import MultiSelect from "../../../features/multi-select/multi-select-wrapper";
import DatePicker from "../../../features/form/date-picker";
import moment from "moment";
import { INPUT_ERROR_1X_IMAGE_URL } from "ImageConfig";

class SearchField extends Component {
    constructor(...args) {
        super(...args);

        this._id = this.props.id || guid();
    }

    handleBlurDatePickerField(value, name) {
        const { subType, compareDate, onValueChange } = this.props;

        const momentValue = moment(value).format("MM/DD/YYYY").toString();

        if (hasStringValue(value) && momentValue === "Invalid date") {
            onValueChange({ value, name, invalidData: true });
            return;
        }

        let invalidCompare = false;

        if (hasStringValue(value) && hasStringValue(subType) && hasStringValue(compareDate) && moment(compareDate) !== "Invalid date") {
            switch (subType.toLowerCase()) {
                case "fromdate": {
                    if (moment(value).format("MM/DD/YYYY") > moment(compareDate).format("MM/DD/YYYY")) invalidCompare = true;
                    break;
                }
                case "todate": {
                    if (moment(value).format("MM/DD/YYYY") < moment(compareDate).format("MM/DD/YYYY")) invalidCompare = true;
                    break;
                }
            }
        }

        const returnValue = hasStringValue(value) ? momentValue : "";

        onValueChange({ value: returnValue, name, invalidData: invalidCompare });
    }

    renderControl() {
        const {
            dataSource, type, onValueChange, name, inputValue, inValidMess, invalidData
        } = this.props;

        switch (type) {
            case "select": {
                return (
                    <Select
                        value={inputValue || ""}
                        dataSource={dataSource}
                        mapDataToRenderOptions={{ value: "value", label: "label" }}
                        onChange={(value) => onValueChange({ value, name })}
                    />);
            }
            case "multiselect": {
                return (
                    <MultiSelect
                        isFromReport
                        values={inputValue && Array.isArray(inputValue) ? inputValue : []}
                        options={dataSource || []}
                        onValuesChange={(value) => onValueChange({ value, name })}
                        label={this.props.label || ""}
                    />);

            }
            case "datepicker": {
                return (
                    <DatePicker
                        onBlur={e => this.handleBlurDatePickerField(e, name)}
                        defaultValue={inputValue || ""}
                        invalidMessage={invalidData ? inValidMess : ""}
                        labelText={this.props.label || ""}
                    />
                );
            }
        }

        return <div></div>;
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {
        const {
            name, className, label, type, invalidData, inValidMess
        } = this.props;

        const inputClasses = () => {
            let classes = "";
            if (type === "select") {
                classes += "input-field suffixinput";
                if (invalidData) classes += " has-error";
            }

            return classes;
        };

        return (
            <div id={this._id} name={name} className={className} style={{ marginBottom: "10px", height: "80px" }}>
                <div className={inputClasses()}>
                    {type === "select" && <label>{label}</label>}
                    {this.renderControl()}
                    {type === "select" && <span className={`suffix-text ${invalidData ? "" : "hide"}`} style={{ right: "22px" }}>
                        <img className={`red-text`} src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={inValidMess} />
                    </span>}
                </div>
            </div>
        );
    }
}

SearchField.propTypes = {
    id: PropTypes.string,
    dataSource: PropTypes.array,
    label: PropTypes.string,
    className: PropTypes.string,
    name: PropTypes.string,
    type: PropTypes.string,
    inputValue: PropTypes.oneOfType([
        PropTypes.object,
        PropTypes.array,
        PropTypes.string
    ]),

    mapDataToRenderOptions: PropTypes.object,
    onValueChange: PropTypes.func,
    subType: PropTypes.string,
    compareDate: PropTypes.string,
    inValidMess: PropTypes.string,
    invalidData: PropTypes.bool
};

export default SearchField;