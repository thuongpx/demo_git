import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { Bar, Line } from "react-chartjs-2";
import "chartjs-plugin-datalabels";

import { guid } from "../../../helpers/crypto-helper";
import { shallowCompareState, shallowCompareProps } from "../../../helpers/common-helper";

import { CHARJS_CONSTANTS } from "../../../constant/constants";

class CannedChart extends Component {
    constructor(...args) {
        super(...args);

        this._id = this.props.id || guid();
    }

    shouldComponentUpdate(nextProps, nextState) {
        const a = !shallowCompareState(this.state, nextState);
        const b = !shallowCompareProps(this.props, nextProps);
        return a || b;
    }

    handleOnChartClick() {
        const { handleOnChartClick } = this.props;

        if (handleOnChartClick) handleOnChartClick();
    }

    _removeEmptyColumn(dataSource) {
        const emptyIndex = [];

        if (!dataSource || !dataSource.labels || !dataSource.datasets) {
            return dataSource;
        }

        const labels = dataSource.labels;
        const datasets = dataSource.datasets;

        if (labels.length > 0) {
            for (let i = 0; i < labels.length; i++) {
                let isEmpty = true;
                for (let j = 0; j < datasets.length; j++) {
                    if (datasets[j].data.length >= labels.length && datasets[j].data[i] > 0) {
                        isEmpty = false;
                        continue;
                    }
                }

                if (isEmpty) {
                    emptyIndex.push(i);
                }
            }

            // remove
            return {
                labels: labels.filter((l, i) => {
                    return emptyIndex.indexOf(i) < 0;
                }),
                datasets: datasets.map(i => {
                    i.data = i.data.filter((d, index) => {
                        return emptyIndex.indexOf(index) < 0;
                    });
                    return i;
                })
            };
        }

        return dataSource;
    }

    _checkEmptyChart(dataSource) {
        if (!dataSource) {
            return true;
        }

        if (!dataSource.labels || dataSource.labels.length === 0) {
            return true;
        }

        if (!dataSource.datasets || !dataSource.datasets.length === 0) {
            return true;
        }

        // check if data is empty
        let hasData = false;
        for (let i = 0; i < dataSource.datasets.length; i++) {
            for (let j = 0; j < dataSource.datasets[i].data.length; j++) {
                if (dataSource.datasets[i].data[j] > 0) {
                    hasData = true;
                    break;
                }
            }
        }

        if (!hasData) return true;

        return false;
    }

    renderChart() {
        const { type, dataSource, barOptions, lineOptions, mixedOptions, width, height, label } = this.props;

        const graphType = type;

        if (this._checkEmptyChart(dataSource)) {
            // there is nothing to show
            return (
                <p className="no-chart-title">There are no records to show</p>
            );
        }

        const cleanDataSource = this._removeEmptyColumn(dataSource);

        switch (graphType) {
            case CHARJS_CONSTANTS.MIXED_BAR: {
                const options = {
                    ...mixedOptions,
                    scales: {
                        ...mixedOptions.scales,
                        xAxes: [{
                            ...mixedOptions.scales.xAxes[0],
                            labels: cleanDataSource.labels || []
                        }]
                    },
                    labels: cleanDataSource.labels || [],
                    title: {
                        ...mixedOptions.title,
                        text: label
                    }
                };

                const data = {
                    datasets: [...(cleanDataSource.datasets || [])]
                };

                return (
                    <Bar
                        data={data}
                        options={options}
                        id={this._id}
                        width={width}
                        height={height || 300}
                        onElementsClick={() => this.props.handleOnChartClick()}
                        ref="chart"
                    />
                );
            }
            case CHARJS_CONSTANTS.LINE: {
                const options = {
                    ...lineOptions,
                    title: {
                        ...lineOptions.title,
                        text: label
                    }
                };

                return (
                    <Line
                        data={cleanDataSource}
                        options={options}
                        id={this._id}
                        width={width}
                        height={height || 300}
                        onElementsClick={() => this.props.handleOnChartClick()}
                        ref="chart"
                    />);
            }
            default: {
                const options = {
                    ...barOptions,
                    title: {
                        ...barOptions.title,
                        text: label
                    }
                };

                return (
                    <Bar
                        data={cleanDataSource}
                        options={options}
                        id={this._id}
                        width={width}
                        height={height || 300}
                        onElementsClick={() => this.props.handleOnChartClick()}
                        ref="chart"
                    />
                );
            }
        }
    }

    render() {
        return (
            <div className="row">
                <div className="col s12">{this.renderChart()}</div>
            </div>
        );
    }
}

CannedChart.defaultProps = {
    barOptions: {
        tooltips: {
            enabled: false,
            mode: null
        },
        title: {
            display: true,
            // text: "Order By Status",
            padding: 20,
            fontSize: 14
        },
        hover: { mode: null },
        barValueSpacing: 20,
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    padding: 25
                }
            }],
            xAxes: [{
                ticks: {
                    autoSkip: false
                }
            }]
        },
        legend: {
            display: true,
            fullWidth: true,
            onClick: () => { }
        },
        plugins: {
            datalabels: {
                color: "black",
                align: "end",
                anchor: "end",
                font: {
                    size: 15,
                    weight: 700
                },
                offset: 8,
                formatter: (value) => {
                    return Math.round(value * 100) / 100;
                },
                display: (context) => {
                    return context.dataset.data[context.dataIndex] > 0;
                }
            }
        }
    },
    lineOptions: {
        tooltips: {
            mode: "label"
        },
        title: {
            display: true,
            padding: 20,
            fontSize: 14
        },
        legend: {
            display: true,
            fullWidth: true,
            onClick: () => { }
        },
        hover: { mode: null },
        barValueSpacing: 20,
        scales: {
            yAxes: [{
                ticks: {
                    padding: 20
                }
            }],
            xAxes: [{
                ticks: {
                    padding: 20,
                    autoSkip: false
                }
            }]
        }
    },
    mixedOptions: {
        responsive: true,
        tooltips: {
            mode: "label"
        },
        title: {
            display: true,
            // text: "Open Orders Comparison by Business Day",
            padding: 20,
            fontSize: 14
        },
        elements: {
            line: {
                fill: false
            }
        },
        plugins: {
            datalabels: {
                color: "black",
                align: "end",
                anchor: "end",
                font: {
                    size: 15,
                    weight: 700
                },
                offset: 8,
                formatter: (value) => {
                    return Math.round(value * 100) / 100;
                },
                display: (context) => {
                    return context.dataset.data[context.dataIndex] > 0;
                }
            }
        },
        scales: {
            xAxes: [
                {
                    display: true,
                    gridLines: {
                        display: false
                    }
                }
            ],
            yAxes: [
                {
                    type: "linear",
                    ticks: {
                        beginAtZero: true
                    },
                    display: true,
                    position: "left",
                    id: "y-axis-1",
                    gridLines: {
                        display: false
                    },
                    labels: {
                        show: true
                    }
                },
                {
                    ticks: {
                        beginAtZero: true
                    },
                    type: "linear",
                    display: true,
                    position: "right",
                    id: "y-axis-2",
                    gridLines: {
                        display: false
                    },
                    labels: {
                        show: true
                    }
                }
            ]
        }
    },
    mixedPlugins: []
};

CannedChart.propTypes = {
    id: PropTypes.string,
    dataSource: PropTypes.object,
    barOptions: PropTypes.object,
    lineOptions: PropTypes.object,
    mixedOptions: PropTypes.object,
    mixedPlugins: PropTypes.array,
    label: PropTypes.string,
    height: PropTypes.number,
    width: PropTypes.number,
    type: PropTypes.string,

    handleOnChartClick: PropTypes.func
};

export default CannedChart;