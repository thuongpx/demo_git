import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";
import { GridView } from "../../../features/gridview/gridview";
import DailyCounterDrillDown from "../components/daily-counter-drilldown";
import MilestoneDrillDown from "./milestone-drilldown";

import { guid } from "../../../helpers/crypto-helper";
import { shallowCompareState, shallowCompareProps } from "../../../helpers/common-helper";

import { closeDrillDownModal, updateDrilldownCriteria } from "../actions/index";

class CannedDrillDown extends Component {
    constructor(...args) {
        super(...args);

        this._id = `modal-${guid()}`;

        this.state = {
            criteria: {}
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        const result = !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);

        return result;
    }

    componentWillReceiveProps(nextProps) {
        if (JSON.stringify(nextProps.gridCriteria) !== JSON.stringify(this.props.gridCriteria)) {
            this.setState({
                criteria: nextProps.gridCriteria
            });
        }
    }

    handleCancel() {
        const { handleFetchDatas, searchObject, dispatch } = this.props;
        const { criteria } = this.state;

        if (handleFetchDatas) handleFetchDatas(searchObject, criteria);

        return dispatch(closeDrillDownModal());
    }

    handleExport() {
        const { handleExportDatas, searchObject } = this.props;

        if (handleExportDatas) handleExportDatas(searchObject);
    }

    handlePrint() { }

    handleGridViewReload(newCriteria) {
        const { handleFetchDatas, searchObject, dispatch } = this.props;

        // update criteria
        dispatch(updateDrilldownCriteria(newCriteria));

        if (handleFetchDatas) handleFetchDatas(searchObject, newCriteria);
    }

    renderTables() {
        const { type, gridCriteria, gridTotalRecord, gridDataSource, gridFilters, gridColumns, gridIdentifier, roleType } = this.props;

        switch (type) {
            case "dailyCounter": {
                return (
                    <DailyCounterDrillDown
                        datasources={gridDataSource}
                        columns={gridColumns}
                        totalRecords={gridTotalRecord}
                        roleType={roleType}
                    />
                );
            }
            case "milestone":
                return (<MilestoneDrillDown />);
            default: {
                return (
                    <GridView
                        displayLength={30}
                        criteria={gridCriteria}
                        totalRecords={gridTotalRecord}
                        datasources={gridDataSource}
                        columns={gridColumns}
                        identifier={gridIdentifier}
                        filters={gridFilters}
                        onGridViewReload={this.handleGridViewReload.bind(this)}
                    />
                );
            }
        }
    }

    renderButtons() {
        return (
            <div className="row m-0">
                <div className="col m4">
                    <button className="btn white w-100" onClick={() => this.handleCancel()}>Back to Report</button>
                </div>
                <div className="col m4">
                    <button className="btn success-color w-100" onClick={() => this.handleExport()}>Export</button>
                </div>
                <div className="col m4">
                    <button className="btn success-color w-100" onClick={() => this.handlePrint()}>Print</button>
                </div>
            </div>
        );
    }

    render() {
        const { isOpen, label } = this.props;

        return (
            <div>
                <Modal id={this._id} isOpen={isOpen} style={{ width: "70%" }}>
                    <ModalBody>
                        <ModalTitle onClickClose={() => this.handleCancel()}>{label}</ModalTitle>
                        <div className="tab-content">
                            <div className="row">
                                <div className="col s12">
                                    {isOpen && this.renderTables()}
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>{this.renderButtons()}</ModalFooter>
                </Modal>
            </div >
        );
    }
}

CannedDrillDown.propTypes = {
    dispatch: PropTypes.func,
    isOpen: PropTypes.bool,
    label: PropTypes.string,
    type: PropTypes.string,
    gridDataSource: PropTypes.array,
    gridCriteria: PropTypes.object,
    gridTotalRecord: PropTypes.number,
    gridFilters: PropTypes.array,
    gridColumns: PropTypes.array,
    gridIdentifier: PropTypes.string,
    handleFetchDatas: PropTypes.func,
    handleCountDatas: PropTypes.func,
    searchObject: PropTypes.object,
    roleType: PropTypes.string,
    handleExportDatas: PropTypes.func
};

const mapStateToProps = (state) => {
    const { cannedReport, authentication } = state;
    const { main } = cannedReport;
    const { role } = authentication;
    const { drillDownOptions } = main;

    return {
        isOpen: main.isOpenDrillDown,
        label: drillDownOptions.label,
        type: drillDownOptions.type,
        gridDataSource: drillDownOptions.dataSource,
        gridCriteria: drillDownOptions.criteria,
        gridTotalRecord: drillDownOptions.totalRecord,
        gridFilters: drillDownOptions.filters,
        gridColumns: drillDownOptions.columns,
        gridIdentifier: drillDownOptions.identifier,
        handleFetchDatas: drillDownOptions.fetchDrilldownData,
        handleCountDatas: drillDownOptions.countDrilldownRecord,
        handleExportDatas: drillDownOptions.exportDrilldownData,
        searchObject: drillDownOptions.searchObject,
        roleType: role ? role.roleType : null
    };
};

export default connect(mapStateToProps)(CannedDrillDown);