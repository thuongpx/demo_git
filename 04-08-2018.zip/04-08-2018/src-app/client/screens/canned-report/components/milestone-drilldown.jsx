import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { GridView } from "GridView";
import Select from "../../../features/form/select";

import { guid } from "../../../helpers/crypto-helper";
import { shallowCompareState, shallowCompareProps } from "../../../helpers/common-helper";

import { closeDrillDownModal, updateDrilldownCriteria } from "../actions/index";

class CannedDrillDown extends Component {
    constructor(...args) {
        super(...args);

        this._id = `modal-${guid()}`;

        this.state = {
            criteria: {},
            selectedMilestone: ""
        };
    }

    handleValueChanged(value) {
        this.setState({
            selectedMilestone: value
        });

        const { handleFetchDatas, searchObject } = this.props;
        const { criteria } = this.state;

        if (handleFetchDatas) handleFetchDatas({ ...searchObject, "milestone": (value === 0 ? "" : value) }, criteria);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentWillReceiveProps(nextProps) {
        if (JSON.stringify(nextProps.gridCriteria) !== JSON.stringify(this.props.gridCriteria)) {
            this.setState({
                criteria: nextProps.gridCriteria
            });
        }
    }

    handleCancel() {
        const { dispatch } = this.props;

        return dispatch(closeDrillDownModal());
    }

    handleExport() { }

    handlePrint() { }

    handleGridViewReload(newCriteria) {
        const { handleFetchDatas, searchObject, dispatch } = this.props;
        const { selectedMilestone } = this.state;

        // update criteria
        dispatch(updateDrilldownCriteria(newCriteria));

        if (handleFetchDatas) handleFetchDatas({ ...searchObject, "milestone": (selectedMilestone === 0 ? "" : selectedMilestone) }, newCriteria);
    }

    renderTables() {
        const { gridCriteria, gridTotalRecord, gridDataSource, gridFilters, gridColumns, gridIdentifier, milestoneOptions } = this.props;
        const { selectedMilestone } = this.state;

        return (
            <div className="row">
                <div className="col s12">
                    <div className="row">
                        <div className="col s12 m3 l3">
                            <div className="input-field">
                                <Select
                                    id="select-milestone"
                                    value={selectedMilestone}
                                    dataSource={milestoneOptions}
                                    mapDataToRenderOptions={{ value: "value", label: "label" }}
                                    onChange={(value) => this.handleValueChanged(value)}
                                />
                                <label htmlFor="select-milestone">Milestone</label>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col s12">
                            <GridView
                                displayLength={30}
                                criteria={gridCriteria}
                                totalRecords={gridTotalRecord}
                                datasources={gridDataSource}
                                columns={gridColumns}
                                identifier={gridIdentifier}
                                filters={gridFilters}
                                onGridViewReload={this.handleGridViewReload.bind(this)}
                            />
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    renderButtons() {
        return (
            <div className="row m-0">
                <div className="col m4">
                    <button className="btn white w-100" onClick={() => this.handleCancel()}>Back to Report</button>
                </div>
                <div className="col m4">
                    <button className="btn success-color w-100" onClick={() => this.handleExport()}>Export</button>
                </div>
                <div className="col m4">
                    <button className="btn success-color w-100" onClick={() => this.handlePrint()}>Print</button>
                </div>
            </div>
        );
    }

    render() {
        return (
            <div className="tab-content" key={guid()}>
                {this.renderTables()}
            </div>
        );
    }
}

CannedDrillDown.propTypes = {
    dispatch: PropTypes.func,
    label: PropTypes.string,
    type: PropTypes.string,
    gridDataSource: PropTypes.array,
    gridCriteria: PropTypes.object,
    gridTotalRecord: PropTypes.number,
    gridFilters: PropTypes.array,
    gridColumns: PropTypes.array,
    gridIdentifier: PropTypes.string,
    handleFetchDatas: PropTypes.func,
    handleCountDatas: PropTypes.func,
    searchObject: PropTypes.object,

    milestoneOptions: PropTypes.array
};

CannedDrillDown.defaultProps = {
    milestoneOptions: [
        {
            label: "All",
            value: ""
        },
        {
            label: "1st order",
            value: 1
        },
        {
            label: "25th order",
            value: 25
        },
        {
            label: "50th order",
            value: 50
        },
        {
            label: "100th order",
            value: 100
        },
        {
            label: "250th order",
            value: 250
        },
        {
            label: "500th order",
            value: 500
        }
    ]
};

const mapStateToProps = (state) => {
    const { cannedReport } = state;
    const { main, customerReport } = cannedReport;
    const { drillDownOptions } = main;
    const { milestoneTotalRecord, milestoneGridData } = customerReport;

    return {
        label: drillDownOptions.label,
        type: drillDownOptions.type,
        gridDataSource: milestoneGridData,
        gridCriteria: drillDownOptions.criteria,
        gridTotalRecord: milestoneTotalRecord,
        gridFilters: drillDownOptions.filters,
        gridColumns: drillDownOptions.columns,
        gridIdentifier: drillDownOptions.identifier,
        handleFetchDatas: drillDownOptions.fetchDrilldownData,
        handleCountDatas: drillDownOptions.countDrilldownRecord,
        searchObject: drillDownOptions.searchObject
    };
};

export default connect(mapStateToProps)(CannedDrillDown);