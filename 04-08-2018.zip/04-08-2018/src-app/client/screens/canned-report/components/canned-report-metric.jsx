import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";

import { guid } from "../../../helpers/crypto-helper";
import { shallowCompareState, shallowCompareProps } from "../../../helpers/common-helper";

class CannedReportMetric extends Component {
    constructor(...args) {
        super(...args);

        this._id = this.props.id || `canned-report-metric-${guid()}`;
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentDidMount() {
        this.renderMetrics();
    }

    renderMetrics() {
        const { renderMetric } = this.props;

        if (renderMetric) renderMetric();
    }

    render() {
        const { title, todayCount, mtdCount } = this.props;

        return (
            <div id={this._id} className={"col s12 m3"}>
                <div className="card-panel box-shadow-none fullbg-style-dashboard w-100 staff-report">
                    <h5>{title}</h5>
                    <div className="clear"></div>
                    <div className="wrap-volume">
                        <div className="text-content">
                            <p className="number">{todayCount}</p>
                            <span className="card-title truncate">Today</span>
                        </div>
                        <div className="text-content right">
                            <p className="number">{mtdCount}</p>
                            <span className="card-title truncate">MTD</span>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

CannedReportMetric.propTypes = {
    id: PropTypes.string,
    mtdCount: PropTypes.number,
    todayCount: PropTypes.number,
    title: PropTypes.string,
    renderMetric: PropTypes.func
};

export default CannedReportMetric;