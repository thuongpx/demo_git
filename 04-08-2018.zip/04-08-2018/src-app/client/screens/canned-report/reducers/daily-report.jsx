import {
    FETCH_ORDER_BY_STATUS_CHART_DATA,
    FETCH_ORDER_BY_STATUS_GRID_DATA,
    COUNT_ORDER_BY_STATUS_GRID_DATA,

    FETCH_ORDER_COMPARISON_BY_BUSINESS_DAY_CHART_DATA,
    FETCH_ORDER_COMPARISON_BY_BUSINESS_DAY_GRID_DATA,
    COUNT_ORDER_COMPARISON_BY_BUSINESS_DAY_GRID_DATA,

    FETCH_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_CHAR_DATA,
    FETCH_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_GRID_DATA,
    COUNT_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_GRID_DATA,

    FETCH_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_CHAR_DATA,
    FETCH_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_GRID_DATA,
    COUNT_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_GRID_DATA,
    GET_METRIC_GROSS_PROFIT,

    CLEAR_DAILY_REPORT,
    RECEIVE_METRIC_REVENUE, REQUEST_METRIC_REVENUE,
    GET_METRIC_OPENED_VOLUME,

    REQUEST_METRIC_CLOSED_VOLUME,
    RECEIVE_METRIC_CLOSED_VOLUME
} from "../actions/daily-report";

const defaultDailyReportReducer = {
    orderByStatusChartData: {},
    orderByStatusGridData: null,
    orderByStatusTotalRecord: 0,

    orderComparisonByBusinessDayChartData: {},
    orderComparisonByBusinessDayGridData: null,
    orderComparisonByBusinessDayTotalRecord: 0,

    dailyAutoAssignOrdersByStatusCharData: {},
    dailyAutoAssignedOrdersByStatusGridData: null,
    dailyAutoAssignedOrdersByStatusTotalRecord: 0,

    dailyManualAssignOrdersByStatusCharData: {},
    dailyManualAssignedOrdersByStatusGridData: null,
    dailyManualAssignedOrdersByStatusTotalRecord: 0,
    revenueToday: 0,
    revenueMTD: 0,
    isFetching: false,

    openedVolumeMTD: 0,
    openedVolumeToDay: 0,

    closedVolumeToday: 0,
    closedVolumeMtd: 0,
    grossProfitToday: 0,
    grossProfitMtd: 0
};

export default function dailyReportReducer(state = defaultDailyReportReducer, action) {
    switch (action.type) {
        case FETCH_ORDER_BY_STATUS_CHART_DATA:
            return {
                ...state,
                orderByStatusChartData: action.payload
            };
        case FETCH_ORDER_BY_STATUS_GRID_DATA:
            return {
                ...state,
                orderByStatusGridData: action.payload
            };
        case COUNT_ORDER_BY_STATUS_GRID_DATA:
            return {
                ...state,
                orderByStatusTotalRecord: action.count
            };
        case FETCH_ORDER_COMPARISON_BY_BUSINESS_DAY_CHART_DATA:
            return {
                ...state,
                orderComparisonByBusinessDayChartData: action.payload
            };
        case FETCH_ORDER_COMPARISON_BY_BUSINESS_DAY_GRID_DATA:
            return {
                ...state,
                orderComparisonByBusinessDayGridData: action.payload
            };
        case COUNT_ORDER_COMPARISON_BY_BUSINESS_DAY_GRID_DATA:
            return {
                ...state,
                orderComparisonByBusinessDayTotalRecord: action.count
            };
        case FETCH_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_CHAR_DATA:
            return {
                ...state,
                dailyAutoAssignOrdersByStatusCharData: action.payload
            };
        case FETCH_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_GRID_DATA:
            return {
                ...state,
                dailyAutoAssignedOrdersByStatusGridData: action.payload
            };
        case COUNT_DAILY_AUTO_ASSIGN_ORDER_BY_STATUS_GRID_DATA:
            return {
                ...state,
                dailyAutoAssignedOrdersByStatusTotalRecord: action.count
            };
        case FETCH_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_CHAR_DATA:
            return {
                ...state,
                dailyManualAssignOrdersByStatusCharData: action.payload
            };
        case FETCH_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_GRID_DATA:
            return {
                ...state,
                dailyManualAssignedOrdersByStatusGridData: action.payload
            };
        case COUNT_DAILY_MANUAL_ASSIGN_ORDER_BY_STATUS_GRID_DATA:
            return {
                ...state,
                dailyManualAssignedOrdersByStatusTotalRecord: action.count
            };
        case GET_METRIC_OPENED_VOLUME:
            return {
                ...state,
                openedVolumeMTD: action.mtd,
                openedVolumeToDay: action.today
            };
        case REQUEST_METRIC_CLOSED_VOLUME:
            return {
                ...state
            };
        case RECEIVE_METRIC_CLOSED_VOLUME:
            return {
                ...state,
                closedVolumeToday: action.closedVolumeToday,
                closedVolumeMtd: action.closedVolumeMtd
            };
        case GET_METRIC_GROSS_PROFIT:
            return {
                ...state,
                grossProfitToday: action.today,
                grossProfitMtd: action.mtd
            };
        case CLEAR_DAILY_REPORT:
            return defaultDailyReportReducer;

        case RECEIVE_METRIC_REVENUE:
            return {
                ...state,
                isFetching: false,
                revenueToday: action.today,
                revenueMTD: action.mtd
            };
        case REQUEST_METRIC_REVENUE:
            return {
                ...state,
                isFetching: true
            };
        default:
            return state;
    }
}