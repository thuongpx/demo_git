import {
    UPDATE_CURRENT_TEMPLATE_FIELDS,
    UPDATE_MANUAL_REPORT_AVAILABLE_FIELDS,
    //
    SET_SELECTED_FIELD_LIST,
    SET_AVAILABLE_FIELD_LIST,
    RESPONSE_TEMPLATE_REPORT,
    RECEIVE_DELETE_REPORT,
    RESPONSE_GET_TEMPLATE_REPORT,
    REQUEST_GET_TEMPLATE_REPORT,
    REQUEST_TEMPLATE_BY_NAME,
    RESPONSE_TEMPLATE_BY_NAME

} from "../actions/manual-report";

export default function staffReportReducer(state = {
    currentTemplate: {
        selectedFields: []
    },
    searchObject: {
        reportType: "OrderReport",
        savedTemplate: "",
        searchBy: "DateClosing",
        dateFrom: "",
        dateTo: "",
        allFiles: false,
        state: "",
        vendorStatus: "Both"
    },
    initialDatas: {
        availableFields: [],
        searchOptions: [
            {
                value: "DateClosing",
                label: "Date Closing"
            },
            {
                value: "DateOfOrder",
                label: "Date of Order"
            }
        ],
        savedTemplates: [],
        reportTypes: [
            {
                value: "OrderReport",
                label: "Order Report"
            },
            {
                value: "VendorReport",
                label: "Vendor Report"
            }
        ],
        reportTypesRoleStaff: [
            {
                value: "OrderReport",
                label: "Order Report"
            },
            {
                value: "VendorReport",
                label: "Vendor Report"
            },
            {
                value: "ClientReport",
                label: "Client Report"
            }
        ]
    },
    reportId: null,
    listReport: []
}, action) {
    switch (action.type) {
        case UPDATE_CURRENT_TEMPLATE_FIELDS:
            return {
                ...state,
                searchObject: {
                    ...state.searchObject,
                    ...action.payload
                }
            };
        case UPDATE_MANUAL_REPORT_AVAILABLE_FIELDS:
            return {
                ...state,
                initialDatas: {
                    ...state.initialDatas,
                    availableFields: action.payload
                }
            };
        //
        case SET_SELECTED_FIELD_LIST: {
            const { newListSelected } = action;
            const { currentTemplate, initialDatas } = state;
            const newList2 = [...newListSelected, ...currentTemplate.selectedFields];
            const newList1 = initialDatas.availableFields.filter((item) => {
                return !newListSelected.find((tempItem) => { return tempItem.value === item.value; });
            });

            return {
                ...state,
                initialDatas: {
                    availableFields: newList1,
                    reportTypes: initialDatas.reportTypes,
                    searchOptions: initialDatas.searchOptions
                },
                currentTemplate: {
                    ...state.currentTemplate,
                    selectedFields: newList2
                }
            };
        }

        case SET_AVAILABLE_FIELD_LIST: {
            const { newListAvailable } = action;
            const { currentTemplate, initialDatas } = state;
            const newList1 = [...newListAvailable, ...initialDatas.availableFields];
            const newList2 = currentTemplate.selectedFields.filter((item) => {
                return !newListAvailable.find(tempItem => { return tempItem.value === item.value; });
            });


            return {
                ...state,
                currentTemplate: {
                    selectedFields: newList2
                },
                initialDatas: {
                    ...state.initialDatas,
                    availableFields: newList1
                }
            };
        }

        case RESPONSE_TEMPLATE_REPORT: {
            return {
                ...state,
                reportId: action.data.reportId
            };
        }

        case RECEIVE_DELETE_REPORT: {
            return {
                ...state,
                currentTemplate: {
                    ...state.currentTemplate,
                    selectedFields: []
                },
                reportId: null
            };
        }
        case REQUEST_GET_TEMPLATE_REPORT:
            return {
                ...state,
                isFetching: true
            };

        case RESPONSE_GET_TEMPLATE_REPORT: {
            return {
                ...state,
                isFetching: false,
                listReport: action.data.listReport
            };
        }

        case REQUEST_TEMPLATE_BY_NAME: {
            return {
                ...state,
                isFetching: true
            };
        }

        case RESPONSE_TEMPLATE_BY_NAME: {
            return {
                ...state,
                isFetching: false,
                currentTemplate: {
                    ...state.currentTemplate,
                    selectedFields: action.data.listColumnsByReportName
                },
                reportId: action.data.reportId
            };
        }
        default:
            return state;
    }
}