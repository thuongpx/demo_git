import { combineReducers } from "redux";
import { GREEN_COLORS, RED_COLORS } from "../../../constant/constants";
import dailyReportReducer from "./daily-report";
import customerReportReducer from "./customer-report";
import manualReportReducer from "./manual-report";
import staffReportReducer from "./staff-report";
import economicsReportReducer from "./economics-report";

import {
    CANNED_REPORT_CLEAR_REDUCERS, GET_INIT_DATA_FOR_CANNED_REPORT,
    START_GET_CANNED_REPORT_GRID_DATA, END_GET_CANNED_REPORT_GRID_DATA,
    CLOSE_DRILL_DOWN_MODAL, OPEN_DRILL_DOWN_MODAL, UPDATE_DRILL_DOWN_DATASOURCE, UPDATE_DRILL_DOWN_CRITERIA
} from "../actions";

const cannedReportMainReducer = (state = {
    isOpenDrillDown: false,
    drillDownOptions: {},
    colors: GREEN_COLORS,
    secondaryColors: RED_COLORS,
    orderStatuses: [
        "Open",
        "Assigned to Vendor",
        "Appt Confirmed Pending Docs",
        "Pending Pre-call",
        "Appt Ready",
        "Closed Pending Review/PC Resolution",
        "Closed Pending QC Review",
        "Closing Completed",
        "Post Close",
        "Hold",
        "Canceled",
        "Unsuccessful signing attempt"
    ],
    orderTypes: [],
    dayFroms: ["1", "2", "3", "4", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"],
    dayTos: ["1", "2", "3", "4", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"],
    months: [
        { label: "Jan", value: "01" },
        { label: "Feb", value: "02" },
        { label: "Mar", value: "03" },
        { label: "Apr", value: "04" },
        { label: "May", value: "05" },
        { label: "Jun", value: "06" },
        { label: "Jul", value: "07" },
        { label: "Aug", value: "08" },
        { label: "Sep", value: "09" },
        { label: "Oct", value: "10" },
        { label: "Nov", value: "11" },
        { label: "Dec", value: "12" }
    ],
    agents: [],
    isRequestingGridData: false,
    customers: [{ label: "All", value: "All" }, { label: "Top 10 And Others", value: "Top10AndOthers" }, { label: "Top 20 And Others", value: "Top20AndOthers" }],
    feeRequestStatus: [
        { label: "Approved", value: "Approved" },
        { label: "Rejected", value: "Rejected" },
        { label: "Pending", value: "Pending" }
    ],
    schedulers: [],
    assignType: [
        { label: "Both", value: "0" },
        { label: "Manually Assigned", value: "1" },
        { label: "Automatically Assigned", value: "2" }
    ]
}, action) => {
    switch (action.type) {
        case GET_INIT_DATA_FOR_CANNED_REPORT:
            return {
                ...state,
                orderTypes: action.orderTypes,
                agents: action.agents,
                schedulers: action.schedulers
            };
        case START_GET_CANNED_REPORT_GRID_DATA:
            return {
                ...state,
                isRequestingGridData: true
            };
        case END_GET_CANNED_REPORT_GRID_DATA:
            return {
                ...state,
                isRequestingGridData: false
            };
        case CLOSE_DRILL_DOWN_MODAL:
            return {
                ...state,
                isOpenDrillDown: false,
                drillDownOptions: {}
            };
        case OPEN_DRILL_DOWN_MODAL:
            return {
                ...state,
                isOpenDrillDown: true,
                drillDownOptions: action.options
            };
        case UPDATE_DRILL_DOWN_DATASOURCE:
            return {
                ...state,
                drillDownOptions: {
                    ...state.drillDownOptions,
                    dataSource: action.dataSource
                }
            };
        case UPDATE_DRILL_DOWN_CRITERIA:
            return {
                ...state,
                drillDownOptions: {
                    ...state.drillDownOptions,
                    criteria: action.criteria
                }
            };
        default:
            return state;
    }
};

const reducers = combineReducers({
    dailyReport: dailyReportReducer,
    staffReport: staffReportReducer,
    customerReport: customerReportReducer,
    manualReport: manualReportReducer,
    main: cannedReportMainReducer,
    economicReport: economicsReportReducer
});

const cannedReportReducer = (state, action) => {
    switch (action.type) {
        case CANNED_REPORT_CLEAR_REDUCERS:
            return reducers({}, action);
        default:
            return reducers(state, action);
    }
};


export default cannedReportReducer;
