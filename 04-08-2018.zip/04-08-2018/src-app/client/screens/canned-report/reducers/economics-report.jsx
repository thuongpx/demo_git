import {
    RECEIVE_ECONOMICS_CHART_DATA, RECEIVE_ECONOMICS_DRILLDOWN_COUNT_TOTAL_RECORDS, RECEIVE_ECONOMICS_DRILLDOWN_DATA, RECEIVE_ECONOMICS_AGENTS_DATA,
    FETCH_ECONOMIC_TREND_ON_MONTHLY_BASIC_CHART_DATA, RECEIVE_ECONOMICS_PROFIT_TREND_DAILY_CHART_DATA, RECEIVE_ECONIMICS_MIX_CHART_DATA, RECEIVE_ECONOMICS_MIX_CHART_LIST_DEFAULT_LOANTYPE, RECEIVE_ECONOMICS_CLOSED_ORDERS_DRILLDOWN_COUNT_TOTAL_RECORDS, RECEIVE_ECONOMICS_CLOSED_ORDERS_DRILLDOWN_DATA
} from "../actions/economic-report";

export default function economicsReportReducer(state = {
    criteria: {
        sortColumn: "orderDate",
        sortDirection: false,
        page: 1,
        itemPerPage: 25
    },
    closedOrdersCriteria: {
        sortColumn: "OrderDate",
        sortDirection: false,
        page: 1,
        itemPerPage: 25
    },
    economicChartData: {},
    economicGridData: [],
    economicGridTotalRecord: 0,

    economicTrendOnMonthlyBasicChartData: {},
    listAgent: {
        listData: [],
        listDefaultData: []
    },
    economicProfitDailyChartData: {},
    economicMixChartData: {},
    listLoanType: {
        listLoanType: [],
        listDefaultLoanType: []
    },
    economicClosedOrdersGridData: [],
    economicClosedOrderGridTotalRecord: 0
}, action) {
    switch (action.type) {
        case RECEIVE_ECONOMICS_CHART_DATA:
            return {
                ...state,
                economicChartData: action.data
            };
        case RECEIVE_ECONOMICS_DRILLDOWN_COUNT_TOTAL_RECORDS:
            return {
                ...state,
                economicGridTotalRecord: action.data
            };
        case RECEIVE_ECONOMICS_DRILLDOWN_DATA:
            return {
                ...state,
                economicGridData: action.data,
                criteria: action.criteria
            };
        case RECEIVE_ECONOMICS_AGENTS_DATA:
            return {
                ...state,
                listAgent: {
                    listData: action.listAgent,
                    listDefaultData: action.listToptenAgent
                }
            };
        case FETCH_ECONOMIC_TREND_ON_MONTHLY_BASIC_CHART_DATA:
            return {
                ...state,
                economicTrendOnMonthlyBasicChartData: action.payload
            };
        case RECEIVE_ECONOMICS_PROFIT_TREND_DAILY_CHART_DATA:
            return {
                ...state,
                economicProfitDailyChartData: action.data
            };
        case RECEIVE_ECONIMICS_MIX_CHART_DATA:
            return {
                ...state,
                economicMixChartData: action.data
            };
        case RECEIVE_ECONOMICS_MIX_CHART_LIST_DEFAULT_LOANTYPE:
            return {
                ...state,
                listLoanType: action.data
            };
        case RECEIVE_ECONOMICS_CLOSED_ORDERS_DRILLDOWN_DATA:
            return {
                ...state,
                economicClosedOrdersGridData: action.data
            };
        case RECEIVE_ECONOMICS_CLOSED_ORDERS_DRILLDOWN_COUNT_TOTAL_RECORDS:
            return {
                ...state,
                economicClosedOrderGridTotalRecord: action.data
            };
        default:
            return state;
    }
}