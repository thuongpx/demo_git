import {
    FETCH_ASSIGNED_ORDER_BY_AGENTS_CHART_DATA,
    FETCH_ASSIGNED_ORDER_LIST_GRID_DATA,
    COUNT_ASSIGNED_ORDER_LIST_GRID_DATA,
    FETCH_ASSIGNED_ORDER_LIST_FOR_STAFF_GRID_DATA,
    COUNT_ASSIGNED_ORDER_LIST_FOR_STAFF_GRID_DATA,
    FETCH_ASSIGNED_ORDER_BY_SCHEDULER_FOR_STAFF_CHART_DATA,
    CLEAR_STAFF_REPORT
} from "../actions/staff-report";

const defaultStaffReportReducer = {
    assignedOrdersByAgentsChartData: {},
    assignedOrdersByAgentsGridData: null,
    assignedOrdersByAgentsTotalRecord: 0
};

export default function staffReportReducer(state = defaultStaffReportReducer, action) {
    switch (action.type) {
        case FETCH_ASSIGNED_ORDER_BY_AGENTS_CHART_DATA:
            return {
                ...state,
                assignedOrdersByAgentsChartData: action.payload
            };
        case FETCH_ASSIGNED_ORDER_LIST_GRID_DATA:
            return {
                ...state,
                assignedOrdersByAgentsGridData: action.payload
            };
        case COUNT_ASSIGNED_ORDER_LIST_GRID_DATA:
            return {
                ...state,
                assignedOrdersByAgentsTotalRecord: action.count
            };
        case FETCH_ASSIGNED_ORDER_LIST_FOR_STAFF_GRID_DATA:
            return {
                ...state,
                assignedOrdersByAgentsGridData: action.payload
            };
        case COUNT_ASSIGNED_ORDER_LIST_FOR_STAFF_GRID_DATA:
            return {
                ...state,
                assignedOrdersByAgentsTotalRecord: action.count
            };
        case FETCH_ASSIGNED_ORDER_BY_SCHEDULER_FOR_STAFF_CHART_DATA:
            return {
                ...state,
                assignedOrdersByAgentsChartData: action.payload
            };
        case CLEAR_STAFF_REPORT:
            return defaultStaffReportReducer;
        default:
            return state;
    }
}