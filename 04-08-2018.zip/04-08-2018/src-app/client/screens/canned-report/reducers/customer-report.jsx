import {
    CLEAR_CUSTOMER_REPORT,

    FETCH_MILESTONE_CHART_DATA, FETCH_MILESTONE_GRID_DATA, COUNT_MILESTONE_GRID_DATA,
    FETCH_CLOSED_ORDERS_BY_CUSTOMERS_CHART_DATA, FETCH_OPEN_ORDER_TREND_CHART_DATA,
    COUNT_OPEN_ORDER_TREND_GRID_DATA, FETCH_OPEN_ORDER_TREND_GRID_DATA,
    FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_CHART_DATA, COUNT_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_GRID_DATA, FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_GRID_DATA,
    FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_CHART_DATA, COUNT_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_GRID_DATA, FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_GRID_DATA,

    FETCH_CLOSED_ORDERS_BY_CLIENT_FOR_STAFF_CHART_DATA, FETCH_CLOSED_ORDERS_BY_CLIENTS_FOR_STAFF_GRID_DATA, COUNT_CLOSED_ORDERS_BY_CLIENTS_FOR_STAFF_GRID_DATA,
    FETCH_CLOSED_ORDERS_BY_CUSTOMERS_GRID_DATA, COUNT_CLOSED_ORDERS_BY_CUSTOMERS_GRID_DATA, FETCH_OPEN_ORDER_TREND_FOR_STAFF_CHART_DATA,
    COUNT_OPEN_ORDER_TREND_FOR_STAFF_GRID_DATA, FETCH_OPEN_ORDER_TREND_FOR_STAFF_GRID_DATA,
    FETCH_MILESTONE_FOR_STAFF_CHART_DATA, FETCH_MILESTONE_FOR_STAFF_GRID_DATA, COUNT_MILESTONE_FOR_STAFF_GRID_DATA
} from "../actions/customer-report";

const defaultCustomerReportReducer = {
    milestoneChartData: {},
    milestoneGridData: null,
    milestoneTotalRecord: 0,

    openOrderTrendChartData: {},
    openOrderTrendGridData: null,
    openOrderTrendTotalRecord: 0,

    openOrderByCustomerAndStatusChartData: {},
    openOrderByCustomerAndStatusGridData: null,
    openOrderByCustomerAndStatusTotalRecord: 0,

    closedOrdersByCustomersChartData: {},

    closedOrdersByCustomersGridData: null,
    closedOrdersByCustomersRecord: 0,

    openOrderByCustomerAndStatusForStaffChartData: {},
    openOrderByCustomerAndStatusForStaffGridData: null,
    openOrderByCustomerAndStatusForStaffTotalRecord: 0,

    closedOrdersByClientForStaffChartData: {},

    closedOrdersByClientForStaffGridData: null,
    closedOrdersByClientForStaffRecord: 0,

    milestoneForStaffChartData: {},
    milestoneForStaffGridData: null,
    milestoneForStaffTotalRecord: 0
};

export default function customerReportReducer(state = defaultCustomerReportReducer, action) {
    switch (action.type) {
        case FETCH_MILESTONE_CHART_DATA:
            return {
                ...state,
                milestoneChartData: action.payload
            };
        case FETCH_MILESTONE_GRID_DATA:
            return {
                ...state,
                milestoneGridData: action.payload
            };
        case COUNT_MILESTONE_GRID_DATA:
            return {
                ...state,
                milestoneTotalRecord: action.count
            };
        case FETCH_CLOSED_ORDERS_BY_CUSTOMERS_CHART_DATA:
            return {
                ...state,
                closedOrdersByCustomersChartData: action.payload
            };
        case FETCH_OPEN_ORDER_TREND_CHART_DATA:
            return {
                ...state,
                openOrderTrendChartData: action.payload
            };

        case FETCH_CLOSED_ORDERS_BY_CUSTOMERS_GRID_DATA:
            return {
                ...state,
                closedOrdersByCustomersGridData: action.payload
            };
        case COUNT_CLOSED_ORDERS_BY_CUSTOMERS_GRID_DATA:
            return {
                ...state,
                closedOrdersByCustomersRecord: action.count
            };
        case COUNT_OPEN_ORDER_TREND_GRID_DATA:
            return {
                ...state,
                openOrderTrendTotalRecord: action.count
            };
        case FETCH_OPEN_ORDER_TREND_GRID_DATA:
            return {
                ...state,
                openOrderTrendGridData: action.payload
            };
        case FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_CHART_DATA:
            return {
                ...state,
                openOrderByCustomerAndStatusChartData: action.payload
            };
        case COUNT_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_GRID_DATA:
            return {
                ...state,
                openOrderByCustomerAndStatusTotalRecord: action.count
            };
        case FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_GRID_DATA:
            return {
                ...state,
                openOrderByCustomerAndStatusGridData: action.payload
            };
        case FETCH_OPEN_ORDER_TREND_FOR_STAFF_CHART_DATA:
            return {
                ...state,
                openOrderTrendChartData: action.payload
            };
        case FETCH_OPEN_ORDER_TREND_FOR_STAFF_GRID_DATA:
            return {
                ...state,
                openOrderTrendGridData: action.payload
            };
        case COUNT_OPEN_ORDER_TREND_FOR_STAFF_GRID_DATA:
            return {
                ...state,
                openOrderTrendTotalRecord: action.count
            };
        case FETCH_MILESTONE_FOR_STAFF_CHART_DATA:
            return {
                ...state,
                milestoneChartData: action.payload
            };
        case FETCH_MILESTONE_FOR_STAFF_GRID_DATA:
            return {
                ...state,
                milestoneGridData: action.payload
            };
        case COUNT_MILESTONE_FOR_STAFF_GRID_DATA:
            return {
                ...state,
                milestoneTotalRecord: action.count
            };
        case CLEAR_CUSTOMER_REPORT:
            return defaultCustomerReportReducer;
        case FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_CHART_DATA:
            return {
                ...state,
                openOrderByCustomerAndStatusForStaffChartData: action.payload
            };
        case COUNT_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_GRID_DATA:
            return {
                ...state,
                openOrderByCustomerAndStatusForStaffTotalRecord: action.count
            };
        case FETCH_OPEN_ORDER_BY_CUSTOMER_AND_STATUS_FOR_STAFF_GRID_DATA:
            return {
                ...state,
                openOrderByCustomerAndStatusForStaffGridData: action.payload
            };

        case FETCH_CLOSED_ORDERS_BY_CLIENT_FOR_STAFF_CHART_DATA:
            return {
                ...state,
                closedOrdersByClientForStaffChartData: action.payload
            };

        case FETCH_CLOSED_ORDERS_BY_CLIENTS_FOR_STAFF_GRID_DATA:
            return {
                ...state,
                closedOrdersByClientForStaffGridData: action.payload
            };
        case COUNT_CLOSED_ORDERS_BY_CLIENTS_FOR_STAFF_GRID_DATA:
            return {
                ...state,
                closedOrdersByClientForStaffRecord: action.count
            };
        default:
            return state;
    }
}
