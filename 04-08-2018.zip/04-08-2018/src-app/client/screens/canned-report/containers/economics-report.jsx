import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import CannedReport from "../components/canned-report";
import { CHARJS_CONSTANTS } from "../../../constant/constants";
import {
    fetchEconomicReportChartData, fetchEconomicListGridData, countEconomicListGridData, getDefaultEconomicAgent,
    fetchEconomicTrendOnMonthlyBasicChartData, fetchEconomicProfitDailyChartData, fetchEconomicMixChartData, getListDefaultLoanType, fetchEconomicClosedOrdersListGridData, countEconomicClosedOrderListGridData, exportEconomicRequestFeeGridData
} from "../actions/economic-report";
import Loader from "./../../../features/loader/index";
import moment from "moment";
import CannedReportMetric from "../components/canned-report-metric";
import {
    getMetricRevenue,
    getMetricGrossProfit
} from "../actions/daily-report";
import { USER_TYPE } from "../../../constant/constants";


class EconomicsReport extends Component {
    constructor(props) {
        super(props);

        this.state = {
            reqFromDate: "",
            reqToDate: "",
            countOrderFromDate: "",
            countOrderToDate: "",
            Loading: true,
            LoadingMixData: true
        };
        const { roleType } = this.props;
        this._isStaff = roleType === USER_TYPE.Staff;
    }

    handleChangeSearchObj(searchObj) {
        this.setState({
            reqFromDate: searchObj.reqFromDate || "",
            reqToDate: searchObj.reqToDate || ""
        });
    }

    handleChangeCountOrderDate(searchObj) {
        this.setState({
            countOrderFromDate: searchObj.fromDate || "",
            countOrderToDate: searchObj.toDate || ""
        });
    }

    componentWillMount() {
        const { dispatch } = this.props;
        dispatch(getDefaultEconomicAgent(() => {
            setTimeout(() => {
                this.setState({ Loading: false });
            }, 300);
        }));
        dispatch(getListDefaultLoanType(() => {
            setTimeout(() => {
                this.setState({ LoadingMixData: false });
            }, 300);
        }));
    }

    render() {
        const { dispatch, criteria, economicGridData, economicGridTotalRecord, listAgent, economicChartData,
            economicTrendOnMonthlyBasicChartData, economicProfitDailyChartData, revenueToday,
            revenueMTD, grossToday, grossMtd, economicMixChartData, listLoanType,
            closedOrdersCriteria, economicClosedOrdersGridData, economicClosedOrderGridTotalRecord,
            profile
        } = this.props;
        const currentDate = moment();
        const currentDay = currentDate.format("DD");
        const currentMonth = currentDate.format("MM");
        const currentYear = currentDate.format("YYYY");

        const economicRequestControls = [
            {
                type: "reqFromDate",
                classes: "col s12 m6 l2",
                dataSource: [],
                compareDate: this.state.reqToDate,
                inValidMess: "Request From Date can not be greater than Request To Date",
                defaultValue: `${currentMonth}/01/${currentYear}`
            },
            {
                type: "reqToDate",
                classes: "col s12 m6 l2",
                dataSource: [],
                compareDate: this.state.reqFromDate,
                inValidMess: "Request From Date can not be greater than Request To Date",
                defaultValue: `${currentMonth}/${currentDay}/${currentYear}`
            },
            {
                type: "agent",
                classes: "col s12 m6 l4",
                dataSource: listAgent.listData,
                defaultValue: listAgent.listDefaultData
            },
            {
                type: "feeRequestStatus",
                classes: "col s12 m6 l2"
            }
        ];

        const economicProfitTrendDailyControl = [
            {
                type: "assignType",
                classes: "col s12 m6 l6 xl3"
            },
            {
                type: "singleMonth",
                classes: "col s12 m6 l6 xl3"
            }
        ];

        const economicProfitTrendMonthlyControl = [
            {
                type: "assignType",
                classes: "col s12 m6 l6 xl3"
            },
            {
                type: "monthEconomic",
                classes: "col s12 m6 l6 xl3"
            }
        ];

        const economicMixChartControl = [
            {
                type: "orderType",
                classes: "col s12 m4 l4 xl4",
                dataSource: listLoanType.listLoanType,
                defaultValue: listLoanType.listDefaultLoanType
            },
            {
                type: "fromDate",
                classes: "col s12 m4 l4 xl4",
                dataSource: [],
                compareDate: this.state.countOrderToDate,
                inValidMess: "Request From Date can not be greater than Request To Date",
                defaultValue: `${currentMonth}/01/${currentYear}`
            },
            {
                type: "toDate",
                classes: "col s12 m4 l4 xl4",
                dataSource: [],
                compareDate: this.state.countOrderFromDate,
                inValidMess: "Request From Date can not be greater than Request To Date",
                defaultValue: `${currentMonth}/${currentDay}/${currentYear}`
            }
        ];

        const economicGridOptions = {
            label: "Fee Increase Request/ Approval List",
            criteria,
            totalRecord: economicGridTotalRecord,
            dataSource: economicGridData,
            columns: [
                { SortOrder: 0, title: "Open Date", data: "orderDate" },
                { SortOrder: 1, title: "Order Number", data: "orderId" },
                { SortOrder: 2, title: "Original Fee", data: "originalAmount", type: "money" },
                { SortOrder: 3, title: "Proposed Fee ", data: "feeAmount", type: "money" },
                { SortOrder: 4, title: "Agent", data: "agent" },
                { SortOrder: 5, title: "Approved", data: "approved" }
            ],
            fetchDrilldownData: (s, o, i) => dispatch(fetchEconomicListGridData(s, o, i, this._isStaff, profile.id)),
            countDrilldownRecord: (s, o, i) => dispatch(countEconomicListGridData(s, i, this._isStaff, profile.id)),
            exportDrilldownData: (s) => dispatch(exportEconomicRequestFeeGridData(s, this._isStaff, profile.id))
        };

        const economicClosedOrderGridOptions = {
            label: "Fee Increase Request/ Approval List",
            criteria: closedOrdersCriteria,
            totalRecord: economicClosedOrderGridTotalRecord,
            dataSource: economicClosedOrdersGridData,
            columns: [
                { SortOrder: 0, title: "Open Date", data: "OrderDate" },
                { SortOrder: 1, title: "Order Number", data: "OrderId" },
                { SortOrder: 2, title: "Order Type", data: "LoanType" },
                { SortOrder: 3, title: "Client Fee", data: "clientFee" },
                { SortOrder: 4, title: "SA Fee", data: "saFee" },
                { SortOrder: 5, title: "Gross Profit", data: "grossProfit" }
            ],
            fetchDrilldownData: (s, o, i) => dispatch(fetchEconomicClosedOrdersListGridData(s, o, i)),
            countDrilldownRecord: (s, o, i) => dispatch(countEconomicClosedOrderListGridData(s, i))
        };

        return (
            <div>
                {this._isStaff &&
                    <div className="row" id="daily-report-metrics">
                        <CannedReportMetric
                            mtdCount={revenueMTD}
                            todayCount={revenueToday}
                            title="Total Revenue"
                            renderMetric={() => dispatch(getMetricRevenue())}
                        />
                        <CannedReportMetric
                            title={"Total Gross"}
                            todayCount={grossToday}
                            mtdCount={grossMtd}
                            renderMetric={() => dispatch(getMetricGrossProfit())}
                        />
                    </div>}
                <div className="row">
                    {this._isStaff && <div className="col s12 m6" style={{ position: "relative" }}>
                        <Loader isShow={this.state.LoadingMixData}>
                            <CannedReport
                                id="economic-closed-orders-economics-chart"
                                changeChartType={false}
                                chartLabel={"Closed Orders Economics"}
                                chartData={economicMixChartData}
                                chartType={CHARJS_CONSTANTS.MIXED_BAR}
                                onRenderChart={(object, invalidData) => dispatch(fetchEconomicMixChartData(object, invalidData))}
                                controls={economicMixChartControl}
                                getChangeObj={(searchObj) => this.handleChangeCountOrderDate(searchObj)}
                                gridOptions={economicClosedOrderGridOptions}
                            />
                        </Loader>
                    </div>}

                    <div className={`col s12 ${this._isStaff ? "m6" : "m10 offset-m1"}`} style={{ position: "relative" }}>
                        <blockquote className="title-quote">Fee Increase Request/Approval</blockquote>

                        <Loader isShow={this.state.Loading}>
                            <CannedReport
                                id="economic-request-fee-chart"
                                changeChartType={false}
                                chartLabel={"Fee Increase Request/Approval"}
                                chartData={economicChartData}
                                chartType={CHARJS_CONSTANTS.BAR}
                                onRenderChart={(object, invalidData) => dispatch(fetchEconomicReportChartData(object, invalidData, this._isStaff, profile.id))}
                                controls={economicRequestControls}
                                getChangeObj={(searchObj) => this.handleChangeSearchObj(searchObj)}
                                gridOptions={economicGridOptions}
                                buttonApplyClasses={"col s6 m6 l2"}
                            />
                        </Loader>
                    </div>

                    {this._isStaff && <div>
                        <div className="clearfix"></div>

                        <div className={`col s12 m6`} style={{ position: "relative" }}>
                            <blockquote className="title-quote">Profit Trend on Daily Basis</blockquote>

                            <CannedReport
                                id="economic-profit-trend-daily-chart"
                                changeChartType={false}
                                chartLabel={"Profit Trend on Daily Basis"}
                                chartData={economicProfitDailyChartData}
                                chartType={CHARJS_CONSTANTS.LINE}
                                onRenderChart={(object) => dispatch(fetchEconomicProfitDailyChartData(object))}
                                controls={economicProfitTrendDailyControl}
                                getChangeObj={(searchObj) => this.handleChangeSearchObj(searchObj)}

                            />
                        </div>
                        <div className={`col s12 m6`}>
                            <blockquote className="title-quote">Profit Trend on Monthly Basis</blockquote>

                            <CannedReport
                                id="economic-profit-trend-monthly-chart"
                                changeChartType={false}
                                chartLabel={"Profit Trend on Monthly Basis"}
                                chartData={economicTrendOnMonthlyBasicChartData}
                                chartType={CHARJS_CONSTANTS.LINE}
                                onRenderChart={(object) => dispatch(fetchEconomicTrendOnMonthlyBasicChartData(object))}
                                controls={economicProfitTrendMonthlyControl}
                                getChangeObj={(searchObj) => this.handleChangeSearchObj(searchObj)}
                            />
                        </div>
                    </div>}
                </div>
            </div>
        );
    }
}

EconomicsReport.propTypes = {
    dispatch: PropTypes.func,
    criteria: PropTypes.object,
    economicChartData: PropTypes.object,
    economicGridData: PropTypes.array,
    economicGridTotalRecord: PropTypes.number,
    listAgent: PropTypes.object,
    roleType: PropTypes.string,
    economicTrendOnMonthlyBasicChartData: PropTypes.object,
    economicProfitDailyChartData: PropTypes.object,
    revenueToday: PropTypes.number,
    revenueMTD: PropTypes.number,
    grossToday: PropTypes.number,
    grossMtd: PropTypes.number,
    economicMixChartData: PropTypes.object,
    listLoanType: PropTypes.object,
    closedOrdersCriteria: PropTypes.object,
    economicClosedOrdersGridData: PropTypes.array,
    economicClosedOrderGridTotalRecord: PropTypes.number,
    profile: PropTypes.object
};

const mapStateToProps = (state) => {
    const { cannedReport, authentication } = state;
    const { economicReport, dailyReport } = cannedReport;
    const { role, profile } = authentication;
    const { criteria, economicChartData, economicGridData, economicGridTotalRecord, listAgent, economicProfitDailyChartData, economicTrendOnMonthlyBasicChartData,
        economicMixChartData, listLoanType, closedOrdersCriteria, economicClosedOrdersGridData, economicClosedOrderGridTotalRecord } = economicReport;

    return {
        criteria,
        economicChartData,
        economicGridData,
        economicGridTotalRecord,
        listAgent,
        roleType: role ? role.roleType : null,
        economicTrendOnMonthlyBasicChartData,
        economicProfitDailyChartData,
        revenueToday: dailyReport.revenueToday,
        revenueMTD: dailyReport.revenueMTD,
        grossToday: dailyReport.grossProfitToday,
        grossMtd: dailyReport.grossProfitMtd,
        economicMixChartData,
        listLoanType,
        closedOrdersCriteria,
        economicClosedOrdersGridData,
        economicClosedOrderGridTotalRecord,
        profile
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(EconomicsReport);