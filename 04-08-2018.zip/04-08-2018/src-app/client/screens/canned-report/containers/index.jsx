import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";

import { getInitDataForCannedReport } from "../actions";

import DailyReport from "./daily-report";
import StaffReport from "./staff-report";
import CustomerReport from "./customer-report";
import ManualReport from "./manual-report";
// import SLAReport from "./../components/client-sla-report";
import EconomicReport from "./economics-report";

import CannedDrillDown from "../components/canned-drilldown";

class CannedReport extends Component {
    constructor(props, defaultProps) {
        super(props, defaultProps);
        const tabs = [
            {
                title: "Daily Report",
                component: DailyReport
            }, {
                title: "Staff Report",
                component: StaffReport
            },
            {
                title: "Customer Report",
                component: CustomerReport
            }, {
                title: "Economics Report",
                component: EconomicReport
            }, {
                title: "Manual Report",
                component: ManualReport
                // }, {
                //     title: "SLA",
                //     component: SLAReport
            }
        ];

        this.state = {
            tabs,
            currentTabIndex: 0
        };
    }

    componentDidMount() {
        const { dispatch } = this.props;

        dispatch(getInitDataForCannedReport());
    }

    handleTabClick(tabIndex) {
        if (this.currentTabRef.validateForm && this.currentTabRef.saveChanges) {
            const validateForm = this.currentTabRef.validateForm();

            if (!validateForm) {
                return;
            }

            this.currentTabRef.saveChanges(false, () => this.setActiveTab(tabIndex));
        }

        this.setActiveTab(tabIndex);
    }

    setActiveTab(currentTabIndex) {
        this.setState({ currentTabIndex });
    }

    renderTabs() {
        const { tabs, currentTabIndex } = this.state;

        return tabs.map((tab, key) => {
            const classNameActive = (key === currentTabIndex) ? "active" : "";

            return (
                <li className="tab col" key={key}
                    onClick={() => { this.handleTabClick(key); }}
                >
                    <a className={classNameActive} style={{ cursor: "pointer" }}>{tab.title}</a>
                </li>
            );
        });
    }

    renderTabContent() {
        const { tabs, currentTabIndex } = this.state;
        const TabComponent = tabs[currentTabIndex].component;

        return (
            <TabComponent
                ref={instance => {
                    if (instance) {
                        this.currentTabRef = instance.getWrappedInstance ? instance.getWrappedInstance() : instance;
                    }
                }}
            />
        );
    }

    render() {
        return (
            <div className="row">
                <div className="col s12"><h3 className="title-page-detail">Canned Reports</h3></div>
                <div className="col s12">
                    <div className="custome-modal">
                        <ul className="tabs">
                            {this.renderTabs()}
                        </ul>
                        <div>
                            {this.renderTabContent()}
                        </div>
                    </div>
                </div>
                <CannedDrillDown />
            </div>
        );
    }
}

CannedReport.propTypes = {
    dispatch: PropTypes.func
};

export default connect()(CannedReport);