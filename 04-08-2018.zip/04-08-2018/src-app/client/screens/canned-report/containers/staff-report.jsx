import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";

import { CHARJS_CONSTANTS, USER_TYPE } from "../../../constant/constants";

import CannedReport from "../components/canned-report";

import {
    fetchAssignedOrderByAgentChartData,
    fetchAssignedOrderListGridData,
    countAssignedOrderListGridData,
    fetchAssignedOrderListForStaffGridData,
    countAssignedOrderListForStaffGridData,
    fetchAssignedOrderBySchedulerForStaffChartData,
    exportAssignedOrderGridData
} from "../actions/staff-report";

class StaffReport extends Component {
    constructor(props) {
        super(props);

        this.state = {};
        const { roleType } = this.props;
        this._isStaff = roleType === USER_TYPE.Staff;
    }

    render() {
        const { dispatch } = this.props;
        const { assignedOrdersByAgentsChartData,
            assignedOrdersByAgentsGridData,
            assignedOrdersByAgentsTotalRecord
        } = this.props;

        const assignedOrderByAgentsControls = [
            {
                type: "agents",
                classes: "col s12 m3 l2"
            },
            {
                type: "orderType",
                classes: "col s12 m3 l2"
            },
            {
                type: "dayFrom",
                classes: "col s12 m2 l1"
            },
            {
                type: "dayTo",
                classes: "col s12 m2 l1"
            },
            {
                type: "month",
                classes: "col s12 m3 l3"
            }
        ];

        const assignedOrdersListGridOptions = {
            label: "Assigned Orders List by Agents",
            criteria: {
                sortColumn: "OrderDate",
                sortDirection: false,
                page: 1,
                itemPerPage: 25
            },
            totalRecord: assignedOrdersByAgentsTotalRecord,
            dataSource: assignedOrdersByAgentsGridData,
            filters: [],
            columns: [
                { SortOrder: 0, title: "Open Date", data: "OrderDate", id: "OpenDate" },
                { SortOrder: 1, title: "Agents", data: "Agents" },
                { SortOrder: 2, title: "Order Number", data: "OrderNumber" },
                { SortOrder: 3, title: "Borrower Last", data: "BorrowerLast" },
                { SortOrder: 4, title: "Type of Transaction", data: "OrderType" },
                { SortOrder: 5, title: "Status", data: "Status" },
                { SortOrder: 6, title: "Vendor Fee", data: "VendorFee" },
                { SortOrder: 7, title: "Client Fee", data: "ClientFee" },
                { SortOrder: 8, title: "Scheduler", data: "Scheduler" }
            ],
            fetchDrilldownData: (s, o) => dispatch(fetchAssignedOrderListGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countAssignedOrderListGridData(s)),
            exportDrilldownData: (s) => dispatch(exportAssignedOrderGridData(s))
        };
        const assignedOrdersListForStaffGridOptions = {
            label: "Open Orders List by Status",
            criteria: {
                sortColumn: "OrderDate",
                sortDirection: false,
                page: 1,
                itemPage: 25
            },
            totalRecord: assignedOrdersByAgentsTotalRecord,
            dataSource: assignedOrdersByAgentsGridData,
            filters: [],
            columns: [
                { SortOrder: 0, title: "Open Date", data: "OrderDate", id: "OpenDate" },
                { SortOrder: 1, title: "Title Company", data: "TitleCompany" },
                { SortOrder: 2, title: "Agents", data: "Agents" },
                { SortOrder: 3, title: "Order Number", data: "OrderNumber" },
                { SortOrder: 4, title: "Borrower Last", data: "BorrowerLast" },
                { SortOrder: 5, title: "Type of Transaction", data: "OrderType" },
                { SortOrder: 6, title: "Status", data: "Status" },
                { SortOrder: 7, title: "Vender Fee", data: "VendorFee" },
                { SortOrder: 8, title: "Client Fee", data: "ClientFee" },
                { SortOrder: 9, title: "Gross Profit", data: "GrossProfit" },
                { SortOrder: 10, title: "Scheduler", data: "Scheduler" }
            ],
            fetchDrilldownData: (s, o) => dispatch(fetchAssignedOrderListForStaffGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countAssignedOrderListForStaffGridData(s))
        };

        const assignedOrderBySchedulerForStaffControls = [
            {
                type: "schedulers",
                classes: "col s12 m3 l2"
            },
            {
                type: "orderType",
                classes: "col s12 m3 l2"
            },
            {
                type: "dayFrom",
                classes: "col s12 m2 l1"
            },
            {
                type: "dayTo",
                classes: "col s12 m2 l1"
            },
            {
                type: "month",
                classes: "col s12 m3 l3"
            }
        ];

        return (
            <div>
                <div className="row">
                    <div className="col s12">
                        <blockquote className="title-quote">Assigned Orders by Agents</blockquote>

                        {!this._isStaff &&
                            <CannedReport
                                id="assigned-order-by-agents-chart"
                                changeChartType={false}
                                chartLabel={"Assigned Orders by Agents"}
                                chartData={assignedOrdersByAgentsChartData}
                                chartType={CHARJS_CONSTANTS.BAR}
                                onRenderChart={(object) => dispatch(fetchAssignedOrderByAgentChartData(object))}
                                controls={assignedOrderByAgentsControls}
                                gridOptions={assignedOrdersListGridOptions}
                                buttonApplyClasses={"col s12 m2 l3"}
                            />
                            ||
                            <CannedReport
                                id="assigned-order-by-agents-chart"
                                changeChartType={false}
                                chartLabel={"Assigned Orders by Agents"}
                                chartData={assignedOrdersByAgentsChartData}
                                chartType={CHARJS_CONSTANTS.BAR}
                                onRenderChart={(object) => dispatch(fetchAssignedOrderBySchedulerForStaffChartData(object))}
                                controls={assignedOrderBySchedulerForStaffControls}
                                gridOptions={assignedOrdersListForStaffGridOptions}
                                buttonApplyClasses={"col s12 m2 l3"}
                            />
                        }
                    </div>
                </div>
            </div>
        );
    }
}

StaffReport.propTypes = {
    dispatch: PropTypes.func,

    assignedOrdersByAgentsChartData: PropTypes.object,
    assignedOrdersByAgentsGridData: PropTypes.array,
    assignedOrdersByAgentsTotalRecord: PropTypes.number,
    roleType: PropTypes.string,
    roleNames: PropTypes.array
};

const mapStateToProps = (state) => {
    const { cannedReport, authentication } = state;
    const { staffReport } = cannedReport;
    const { role } = authentication;

    return {
        assignedOrdersByAgentsChartData: staffReport.assignedOrdersByAgentsChartData,
        assignedOrdersByAgentsGridData: staffReport.assignedOrdersByAgentsGridData,
        assignedOrdersByAgentsTotalRecord: staffReport.assignedOrdersByAgentsTotalRecord,
        roleType: role ? role.roleType : null,
        roleNames: role ? role.roleNames : []
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(StaffReport);