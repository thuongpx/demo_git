import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";

import { CHARJS_CONSTANTS, USER_TYPE } from "../../../constant/constants";

import CannedReport from "../components/canned-report";
import CannedReportMetric from "../components/canned-report-metric";

import {
    fetchOrderByStatusChartData,
    fetchOrderByStatusGridData,
    countOrderByStatusGridData,

    fetchOrderComparisonByBusinessDayChartData,
    fetchOrderComparisonByBusinessDayGridData,
    countOrderComparisonByBusinessDayGridData,

    fetchDailyAutoAssignedOrderByStatusChartData,
    fetchDailyAutoAssignedOrderByStatusGridData,
    countDailyAutoAssignedOrderByStatusGridData,

    fetchDailyManualAssignedOrderByStatusChartData,
    fetchDailyManualAssignedOrderByStatusGridData,
    countDailyManualAssignedOrderByStatusGridData,

    clearDailyReport, getMetricRevenue,

    getMetricOpenedVolume,
    getMetricClosedVolume,
    getMetricGrossProfit,

    exportComparisonByBusinessDayGridData,
    exportOrderByStatusGridData,
    exportDailyAutoAssignedOrdersByStatusGrid,
    exportDailyManualAssignedOrdersByStatusGrid,
    exportComparisonByBusinessDayGridDataForStaff

} from "../actions/daily-report";

class DailyReport extends Component {
    constructor(props) {
        super(props);

        this.state = {};
        const { roleType } = this.props;
        this._isStaff = roleType === USER_TYPE.Staff;
        this.searchObject = {};
    }

    handleShowRowDetail(isAuto) {
        if (isAuto) {
            this.setState(prevState => ({
                autoRow: !prevState.autoRow
            }));
        } else {
            this.setState(prevState => ({
                manualRow: !prevState.manualRow
            }));
        }
    }

    handleChangeGraph(e) {
        switch (e.target.value) {
            case "line":
                this.myBarChart.config.type = "line";

                for (let i = 0; i < this.myBarChart.config.data.datasets.length; i++) {
                    this.myBarChart.config.data.datasets[i].borderColor = this.myBarChart.config.data.datasets[i].backgroundColor;
                    this.myBarChart.config.data.datasets[i].fill = false;
                    this.myBarChart.config.data.datasets[i].lineTension = 0;
                }
                this.myBarChart.update();
                break;

            case "col":
                this.myBarChart.config.type = "bar";
                this.myBarChart.update();
                break;

            default:
                break;
        }
    }

    render() {
        const { dispatch } = this.props;
        const {
            orderByStatusChartData, orderByStatusTotalRecord, orderByStatusGridData,
            orderComparisonByBusinessDayChartData, orderComparisonByBusinessDayTotalRecord, orderComparisonByBusinessDayGridData,
            dailyAutoAssignOrdersByStatusCharData, dailyAutoAssignedOrdersByStatusTotalRecord, dailyAutoAssignedOrdersByStatusGridData,
            dailyManualAssignOrdersByStatusCharData, dailyManualAssignedOrdersByStatusGridData, dailyManualAssignedOrdersByStatusTotalRecord,
            roleType, openedVolumeMTD, openedVolumeToDay,
            closedVolumeToday, closedVolumeMtd,
            grossProfitToday, grossProfitMtd
        } = this.props;
        const { revenueToday, revenueMTD } = this.props;

        const orderByStatusControls = [
            {
                type: "orderType",
                classes: "col s6"
            },
            {
                type: "orderStatus",
                classes: "col s6"
            }
        ];

        const orderByBusinessDayControls = [
            {
                type: "orderType",
                classes: "col s4 offset-s8 pull-s8"
            },
            {
                type: "dayFrom",
                classes: "col s2"
            },
            {
                type: "dayTo",
                classes: "col s2"
            },
            {
                type: "month",
                classes: "col s4"
            }
        ];

        const dailyAutoCountReportControls = [
            {
                type: "orderStatus",
                classes: "col s4"
            }
        ];

        const orderByStatusGridOptions = {
            label: "Open Order List by Status",
            criteria: {
                sortColumn: "OpenDate",
                sortDirection: false,
                page: 1,
                itemPerPage: 25
            },
            totalRecord: orderByStatusTotalRecord,
            dataSource: orderByStatusGridData,
            filters: [],
            columns: [
                { SortOrder: 0, title: "Open Date", data: "OpenDate", id: "OrderId" },
                { SortOrder: 1, title: "Order Number", data: "OrderNumber" },
                { SortOrder: 2, title: "Closing Date", data: "ClosingDate" },
                { SortOrder: 3, title: "Title Company", data: "TitleCompany" },
                { SortOrder: 4, title: "Agents", data: "Agents" },
                { SortOrder: 5, title: "Borrower Last", data: "BorrowerLast" },
                { SortOrder: 6, title: "Type of Transaction", data: "LoanType" },
                { SortOrder: 7, title: "Status", data: "OrderStatus" },
                { SortOrder: 8, title: "Vendor Fee", data: "VendorFee" },
                { SortOrder: 9, title: "Client Fee", data: "ClientFee" },
                { SortOrder: 10, title: "Appoint Assigned By", data: "AppointAssignedBy" }
            ],
            fetchDrilldownData: (s, o) => dispatch(fetchOrderByStatusGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countOrderByStatusGridData(s)),
            exportDrilldownData: (s) => dispatch(exportOrderByStatusGridData(s))
        };

        const orderComparisonByBusinessDayGridOptions = {
            ...orderByStatusGridOptions,
            label: "Open Orders Comparison by Business Day",
            totalRecord: orderComparisonByBusinessDayTotalRecord,
            dataSource: orderComparisonByBusinessDayGridData,
            fetchDrilldownData: (s, o) => dispatch(fetchOrderComparisonByBusinessDayGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countOrderComparisonByBusinessDayGridData(s)),
            exportDrilldownData: (s) => dispatch(exportComparisonByBusinessDayGridData(s))
        };

        const dailyAutoAssignedOrdersByStatusGridOptions = {
            ...orderByStatusGridOptions,
            label: "Daily Auto-Assigned Orders by Status",
            totalRecord: dailyAutoAssignedOrdersByStatusTotalRecord,
            dataSource: dailyAutoAssignedOrdersByStatusGridData,
            columns: [
                { SortOrder: 0, title: "Open Status", data: "OrderStatus", id: "OrderId" },
                { SortOrder: 1, title: "Total Order", data: "TotalOrder" },
                { SortOrder: 2, title: "Sum Of Assign Time", data: "SumOfAssignTime" },
                { SortOrder: 3, title: "Average Of Assign Time", data: "AverageOfAssignTime" }
            ],
            fetchDrilldownData: (s) => {
                dispatch(fetchDailyManualAssignedOrderByStatusGridData(s));
                dispatch(fetchDailyAutoAssignedOrderByStatusGridData(s));
            },
            countDrilldownRecord: (s) => {
                dispatch(countDailyManualAssignedOrderByStatusGridData(s));
                dispatch(countDailyAutoAssignedOrderByStatusGridData(s));
            },
            exportDrilldownData: (s) => dispatch(exportDailyAutoAssignedOrdersByStatusGrid(s))

        };

        const dailyManualAssignedOrdersByStatusGridOptions = {
            ...dailyAutoAssignedOrdersByStatusGridOptions,
            label: "Daily Manual-Assigned Orders by Status",
            totalRecord: dailyManualAssignedOrdersByStatusTotalRecord,
            dataSource: dailyManualAssignedOrdersByStatusGridData,
            columns: [
                { SortOrder: 0, title: "Open Status", data: "OrderStatus", id: "OrderId" },
                { SortOrder: 1, title: "Total Order", data: "TotalOrder" },
                { SortOrder: 2, title: "Sum Of Assign Time", data: "SumOfAssignTime" },
                { SortOrder: 3, title: "Average Of Assign Time", data: "AverageOfAssignTime" }
            ],
            fetchDrilldownData: () => {
            },
            countDrilldownRecord: () => {
            },
            exportDrilldownData: () => dispatch(exportDailyManualAssignedOrdersByStatusGrid(this.searchObject))
        };

        const orderComparisonByBusinessDayGridOptionsByStaff = {
            ...orderByStatusGridOptions,
            columns: [
                { SortOrder: 0, title: "Open Date", data: "OpenDate", id: "OrderId" },
                { SortOrder: 1, title: "Order Number", data: "OrderNumber" },
                { SortOrder: 2, title: "Closing Date", data: "ClosingDate" },
                { SortOrder: 3, title: "Title Company", data: "TitleCompany" },
                { SortOrder: 5, title: "Borrower Last", data: "BorrowerLast" },
                { SortOrder: 6, title: "Type of Transaction", data: "LoanType" },
                { SortOrder: 7, title: "Status", data: "OrderStatus" },
                { SortOrder: 8, title: "Vendor Fee", data: "VendorFee" },
                { SortOrder: 9, title: "Client Fee", data: "ClientFee" },
                { SortOrder: 9, title: "Gross Profit", data: "GrossProfit" },
                { SortOrder: 10, title: "Appoint Assigned By", data: "AppointAssignedBy" }
            ],
            label: "Open Orders Comparison by Business Day",
            totalRecord: orderComparisonByBusinessDayTotalRecord,
            dataSource: orderComparisonByBusinessDayGridData,
            fetchDrilldownData: (s, o) => dispatch(fetchOrderComparisonByBusinessDayGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countOrderComparisonByBusinessDayGridData(s)),
            exportDrilldownData: (s) => dispatch(exportComparisonByBusinessDayGridDataForStaff(s))
        };

        const dailyAutoAssignedOrdersByStatusGridOptionsByStaff = {
            ...dailyAutoAssignedOrdersByStatusGridOptions,
            columns: [
                { SortOrder: 0, title: "Open Status", data: "OrderStatus", id: "OrderId" },
                { SortOrder: 1, title: "Total Order", data: "TotalOrder" },
                { SortOrder: 2, title: "Sum of Profit", data: "SumOfProfit" },
                { SortOrder: 3, title: "Average profit", data: "AverageProfit" },
                { SortOrder: 4, title: "Sum Of Assign Time", data: "SumOfAssignTime" },
                { SortOrder: 5, title: "Average Of Assign Time", data: "AverageOfAssignTime" }
            ]
        };

        const dailyManualAssignedOrdersByStatusGridOptionsByStaff = {
            ...dailyManualAssignedOrdersByStatusGridOptions,
            columns: [
                { SortOrder: 0, title: "Open Status", data: "OrderStatus", id: "OrderId" },
                { SortOrder: 1, title: "Total Order", data: "TotalOrder" },
                { SortOrder: 2, title: "Sum of Profit", data: "SumOfProfit" },
                { SortOrder: 3, title: "Average profit", data: "AverageProfit" },
                { SortOrder: 4, title: "Sum Of Assign Time", data: "SumOfAssignTime" },
                { SortOrder: 5, title: "Average Of Assign Time", data: "AverageOfAssignTime" }
            ]
        };

        return (
            <div>
                {this._isStaff &&
                    <div className="row" id="daily-report-metrics">
                        <CannedReportMetric
                            title={"Opened Volume"}
                            mtdCount={openedVolumeMTD}
                            todayCount={openedVolumeToDay}
                            renderMetric={() => dispatch(getMetricOpenedVolume())}
                        />
                        <CannedReportMetric mtdCount={closedVolumeMtd}
                            todayCount={closedVolumeToday}
                            title="Closed Volume"
                            renderMetric={() => dispatch(getMetricClosedVolume())}
                        />
                        <CannedReportMetric
                            mtdCount={revenueMTD}
                            todayCount={revenueToday}
                            title="Revenue"

                            renderMetric={() => dispatch(getMetricRevenue())}
                        />
                        <CannedReportMetric
                            title={"Gross Profit"}
                            todayCount={grossProfitToday}
                            mtdCount={grossProfitMtd}
                            renderMetric={() => dispatch(getMetricGrossProfit())}
                        />
                    </div>}
                <div className="row">
                    <div className="col s12 m6">
                        <blockquote className="title-quote">Open Order by Status</blockquote>

                        <CannedReport
                            id="open-order-by-status-chart"
                            changeChartType
                            chartLabel={"Order By Status"}
                            chartData={orderByStatusChartData}
                            chartType={CHARJS_CONSTANTS.BAR}
                            onRenderChart={(object) => dispatch(fetchOrderByStatusChartData(object))}
                            controls={orderByStatusControls}
                            gridOptions={orderByStatusGridOptions}
                        />
                    </div>

                    <div className="col s12 m6">
                        <blockquote className="title-quote">
                            Open Orders Comparison by Business Day</blockquote>

                        <CannedReport
                            id="open-order-comparison-by-business-day-chart"
                            chartLabel={"Open Orders Comparison by Business Day"}
                            chartData={orderComparisonByBusinessDayChartData}
                            chartType={CHARJS_CONSTANTS.BAR}
                            onRenderChart={(object) => dispatch(fetchOrderComparisonByBusinessDayChartData(object))}
                            controls={orderByBusinessDayControls}
                            gridOptions={(roleType === USER_TYPE.Staff) ? orderComparisonByBusinessDayGridOptionsByStaff : orderComparisonByBusinessDayGridOptions}
                            buttonApplyClasses={"col s4"}
                        />
                    </div>

                    <div className="clear"></div>

                    <div className="col s12 m6">
                        <blockquote className="title-quote">Daily Counter Report</blockquote>
                        <CannedReport
                            id="daily-auto-assigned-order-by-status-chart"
                            isShowButtonViewAll
                            chartLabel={"Daily Auto-Assigned Orders by Status"}
                            chartData={dailyAutoAssignOrdersByStatusCharData}
                            chartType={CHARJS_CONSTANTS.MIXED_BAR}
                            onRenderChart={(object) => {
                                dispatch(fetchDailyAutoAssignedOrderByStatusChartData(object));
                                dispatch(fetchDailyManualAssignedOrderByStatusChartData(object));
                                this.searchObject = object;
                            }}
                            controls={dailyAutoCountReportControls}
                            gridOptions={(roleType === USER_TYPE.Staff) ? dailyAutoAssignedOrdersByStatusGridOptionsByStaff : dailyAutoAssignedOrdersByStatusGridOptions}
                            buttonApplyClasses={"col s4"}
                            buttonShowAllClasses={"col s4"}
                        />
                    </div>

                    <div className="col s12 m6">
                        <blockquote className="title-quote white-color"></blockquote>
                        <CannedReport
                            id="daily-manual-assigned-order-by-status-chart"

                            chartLabel={"Daily Manual-Assigned Orders by Status"}
                            chartData={dailyManualAssignOrdersByStatusCharData}
                            chartType={CHARJS_CONSTANTS.MIXED_BAR}
                            gridOptions={(roleType === USER_TYPE.Staff) ? dailyManualAssignedOrdersByStatusGridOptionsByStaff : dailyManualAssignedOrdersByStatusGridOptions}
                        />
                    </div>
                </div>
            </div>
        );
    }

    componentWillUnmount() {
        const { dispatch } = this.props;

        dispatch(clearDailyReport());
    }
}

DailyReport.propTypes = {
    dispatch: PropTypes.func,

    orderByStatusChartData: PropTypes.object,
    orderByStatusGridData: PropTypes.array,
    orderByStatusTotalRecord: PropTypes.number,

    orderComparisonByBusinessDayChartData: PropTypes.object,
    orderComparisonByBusinessDayGridData: PropTypes.array,
    orderComparisonByBusinessDayTotalRecord: PropTypes.number,

    dailyAutoAssignOrdersByStatusCharData: PropTypes.object,
    dailyAutoAssignedOrdersByStatusGridData: PropTypes.array,
    dailyAutoAssignedOrdersByStatusTotalRecord: PropTypes.number,

    dailyManualAssignOrdersByStatusCharData: PropTypes.object,
    dailyManualAssignedOrdersByStatusGridData: PropTypes.array,
    dailyManualAssignedOrdersByStatusTotalRecord: PropTypes.number,

    closedVolumeToday: PropTypes.number,
    closedVolumeMtd: PropTypes.number,

    roleType: PropTypes.string,
    revenueToday: PropTypes.number,
    revenueMTD: PropTypes.number,

    openedVolumeMTD: PropTypes.number,
    openedVolumeToDay: PropTypes.number,
    grossProfitToday: PropTypes.number,
    grossProfitMtd: PropTypes.number

};

const mapStateToProps = (state) => {
    const { cannedReport, authentication } = state;
    const { role } = authentication;
    const { dailyReport } = cannedReport;


    return {
        orderByStatusChartData: dailyReport.orderByStatusChartData,
        orderByStatusGridData: dailyReport.orderByStatusGridData,
        orderByStatusTotalRecord: dailyReport.orderByStatusTotalRecord,

        orderComparisonByBusinessDayChartData: dailyReport.orderComparisonByBusinessDayChartData,
        orderComparisonByBusinessDayTotalRecord: dailyReport.orderComparisonByBusinessDayTotalRecord,
        orderComparisonByBusinessDayGridData: dailyReport.orderComparisonByBusinessDayGridData,

        dailyAutoAssignOrdersByStatusCharData: dailyReport.dailyAutoAssignOrdersByStatusCharData,
        dailyAutoAssignedOrdersByStatusTotalRecord: dailyReport.dailyAutoAssignedOrdersByStatusTotalRecord,
        dailyAutoAssignedOrdersByStatusGridData: dailyReport.dailyAutoAssignedOrdersByStatusGridData,

        dailyManualAssignOrdersByStatusCharData: dailyReport.dailyManualAssignOrdersByStatusCharData,
        dailyManualAssignedOrdersByStatusGridData: dailyReport.dailyManualAssignedOrdersByStatusGridData,
        dailyManualAssignedOrdersByStatusTotalRecord: dailyReport.dailyManualAssignedOrdersByStatusTotalRecord,

        openedVolumeMTD: dailyReport.openedVolumeMTD,
        openedVolumeToDay: dailyReport.openedVolumeToDay,
        closedVolumeToday: dailyReport.closedVolumeToday,
        closedVolumeMtd: dailyReport.closedVolumeMtd,

        roleType: role ? role.roleType : null,

        revenueToday: dailyReport.revenueToday,
        revenueMTD: dailyReport.revenueMTD,
        grossProfitToday: dailyReport.grossProfitToday,
        grossProfitMtd: dailyReport.grossProfitMtd

    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(DailyReport);