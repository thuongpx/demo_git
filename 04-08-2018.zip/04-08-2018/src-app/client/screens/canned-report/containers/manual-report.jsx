import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import moment from "moment";

import DatePicker from "DatePicker";
import Select from "../../../features/form/select";
import DragDropTable from "../../../features/drag-drop-table/drag-drop-table";

import {
    updateCurrentSearchObject,
    fetchAvailableFieldsByReportType,
    setSelectedFieldList,
    setAvailableFieldList,
    saveTemplateReport,
    deleteReport,
    getTemplateReport,
    //
    exportManualReportOrder,
    exportManualReportVendor,
    getTemplateReportByName
} from "../actions/manual-report";

import { showError } from "../../main-layout/actions";
import { Modal, ModalBody, ModalFooter, ModalTitle } from "Modal";
import CommonModal from "CommonModal";
import { validateRequired } from "Helpers/validation-helper";
import { INPUT_ERROR_1X_IMAGE_URL, INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";

class ManualReport extends Component {
    constructor(props) {
        super(props);
        this.state = {
            moveType: "",
            tempListData: [],
            showReportNameModal: false,
            dataCriteria: {},
            tempListData2: [],
            validator: {
                isReportNameRequiredInvalid: false,
                isReportNameExistInvalid: false
            }
        };
    }

    componentDidUpdate() {
        this.refs.reportName.focus();
    }

    resetValidator() {
        this.setState({
            validator: {
                isReportNameRequiredInvalid: false,
                isReportNameExistInvalid: false
            }
        });
    }

    validateReportNameRequired() {
        const isReportNameRequiredInvalid = !validateRequired(this.refs.reportName.value);
        return isReportNameRequiredInvalid;
    }

    handleValidateReportName() {
        const isReportNameRequiredInvalid = this.validateReportNameRequired();
        let isReportNameExistInvalid = false;
        const { listReport } = this.props;

        if (!isReportNameRequiredInvalid) {
            listReport.forEach(item => {
                if (this.refs.reportName.value.trim() === item.ReportName) {
                    isReportNameExistInvalid = true;

                    this.setState({
                        validator: {
                            isReportNameRequiredInvalid,
                            isReportNameExistInvalid
                        }
                    });
                } else {
                    this.setState({
                        validator: {
                            isReportNameRequiredInvalid,
                            isReportNameExistInvalid
                        }
                    });
                }
            });
        } else {
            this.setState({
                validator: {
                    isReportNameRequiredInvalid,
                    isReportNameExistInvalid
                }
            });
        }
        this.setState({
            validator: {
                isReportNameRequiredInvalid,
                isReportNameExistInvalid
            }
        });
    }

    validateForm() {
        return !this.state.validator.isReportNameRequiredInvalid && !this.state.validator.isReportNameExistInvalid;
    }

    getAllReportTemplate() {
        const { dispatch } = this.props;

        dispatch(getTemplateReport());
    }

    componentDidMount() {
        const { dispatch } = this.props;

        dispatch(fetchAvailableFieldsByReportType());
        this.getAllReportTemplate();
    }

    handleValueChanged(fieldObject) {
        const { dispatch, currentTemplate } = this.props;
        const { dataCriteria } = this.state;
        const newTempCriteria = { ...dataCriteria, ...fieldObject };

        this.setState({
            dataCriteria: newTempCriteria
        });

        if (fieldObject.reportType === "VendorReport") {
            currentTemplate.selectedFields = [];
            dispatch(fetchAvailableFieldsByReportType("Vendor"));
        }
        if (fieldObject.reportType === "ClientReport") {
            dispatch(fetchAvailableFieldsByReportType("Client"));
        }
        if (fieldObject.reportType !== "ClientReport" && fieldObject.reportType !== "VendorReport") {
            currentTemplate.selectedFields = [];
            dispatch(fetchAvailableFieldsByReportType());
        }
        if (fieldObject.savedTemplates) {
            const reportName = fieldObject.savedTemplates;

            dispatch(getTemplateReportByName(reportName));
        }

        dispatch(updateCurrentSearchObject(dataCriteria));
    }

    handleSelectedOnRowClick(data) {
        const { availableFields } = this.props.initialDatas;
        const { tempListData } = this.state;
        let newTempList = [];

        if (!tempListData.find((tempItem) => { return tempItem.value === data; })) {
            newTempList = [availableFields.find(item => item.value === data), ...tempListData];

        } else {
            newTempList = tempListData.filter((temp) => { return temp.value !== data; });
        }

        this.setState({ tempListData: newTempList });
    }

    handleSelectedOnRowClick2(data) {
        const { selectedFields } = this.props.currentTemplate;
        const { tempListData2 } = this.state;
        let newTempList2 = [];

        if (!tempListData2.find((tempItem) => { return tempItem.value === data; })) {
            newTempList2 = [selectedFields.find(item => item.value === data), ...tempListData2];
        } else {
            newTempList2 = tempListData2.filter((temp) => { return temp.value !== data; });
        }

        this.setState({ tempListData2: newTempList2 });
    }

    handleOnMove(moveType) {
        const { dispatch } = this.props;
        const { tempListData, tempListData2 } = this.state;
        const newListSelected = [];
        const newListAvailable = [];

        switch (moveType) {
            case "MOVE_RIGHT":
                if (tempListData.length <= 0) {
                    dispatch(showError("Please select one field before clicking this button."));
                } else {
                    tempListData.forEach((item) => {
                        newListSelected.push(item);
                    });

                    this.setState({
                        tempListData: newListSelected
                    });

                    dispatch(setSelectedFieldList(tempListData));
                    this.setState({
                        tempListData: []
                    });
                }
                break;

            case "MOVE_LEFT":
                if (tempListData2.length <= 0) {
                    dispatch(showError("Please select one field before clicking this button."));
                } else {
                    tempListData2.forEach((item) => {
                        newListAvailable.push(item);
                    });

                    this.setState({
                        tempListData2: newListAvailable
                    });

                    dispatch(setAvailableFieldList(tempListData2));
                    this.setState({
                        tempListData2: []
                    });
                }
                break;
        }
    }

    handleShowModal() {
        const { dispatch, currentTemplate } = this.props;
        this.resetValidator();
        if (currentTemplate.selectedFields.length > 0) {
            this.setState({ showReportNameModal: true });
        } else {
            dispatch(showError("Please select one field before save."));
        }
    }

    handleCloseModal() {
        this.refs.reportName.value = "";
        this.setState({
            showReportNameModal: false
        });
    }

    handleSaveTemplate() {
        if (this.validateForm()) {
            const { currentTemplate, dispatch, searchObject } = this.props;
            const { dataCriteria } = this.state;
            const dataColumns = [];
            currentTemplate.selectedFields.forEach(item => {
                dataColumns.push(item.value);
            });
            const dataSave = { ...dataCriteria, ...dataColumns };
            const listSelectedStr = Array.prototype.map.call(dataColumns, (item) => { return item; }).join(", ");

            const dataObjSave = {
                reportName: this.refs.reportName.value,
                reportType: dataCriteria.reportType === "OrderReport" ? "o" : "v",
                searchBy: dataCriteria.searchBy === "DateAndTimeClosing" ? 1 : 0,
                fromDate: dataSave.dateFrom,
                toDate: dataSave.dateTo,
                searchAll: 1,
                vendorStatus: dataSave.vendorStatus,
                columns: listSelectedStr
            };
            dispatch(saveTemplateReport(dataObjSave));
            this.refs.reportName.value = "";
            this.handleCloseModal();
        }
    }

    handleDelete(reportId) {
        const { dispatch } = this.props;

        this.commonModal.showModal({
            type: "confirm",
            message: "Are you sure you would like to delete this report template?"
        }, () => {
            dispatch(deleteReport(reportId));
        }, () => { });
    }

    handleCancel() {
        this.refs.reportName.value = "";
    }

    handleExport() {
        const { dispatch, currentTemplate } = this.props;
        const { dataCriteria } = this.state;

        if (currentTemplate.selectedFields.length <= 0) {
            dispatch(showError("Please select fields to export"));
        } else if (dataCriteria.reportType === "OrderReport" || dataCriteria.reportType === undefined) {
            dispatch(exportManualReportOrder(currentTemplate.selectedFields));
        } else {
            dispatch(exportManualReportVendor(currentTemplate.selectedFields));
        }
    }

    render() {
        const { currentTemplate, initialDatas, searchObject, reportId, vendorStatusList, roleType, listReport } = this.props;
        const { showReportNameModal } = this.state;
        const { dataCriteria } = this.state;
        return (
            <div>
                <div className="row">
                    <div className="col s12 m2 l2">
                        <div className="input-field">
                            <Select
                                id="report-type"
                                value={dataCriteria.reportType || ""}
                                dataSource={roleType !== "Staff" ? initialDatas.reportTypes : initialDatas.reportTypesRoleStaff}
                                mapDataToRenderOptions={{ value: "value", label: "label" }}
                                onChange={(value) => this.handleValueChanged({ reportType: value })}
                            />
                            <label htmlFor="report-type">Report Type</label>
                        </div>
                    </div>
                    <div className="col s12 m2 l2">
                        <div className="input-field">
                            <Select
                                id="saved-template"
                                value={listReport.ReportName || ""}
                                dataSource={listReport}
                                mapDataToRenderOptions={{ value: "ReportName", label: "ReportName" }}
                                onChange={(value) => this.handleValueChanged({ savedTemplates: value })}
                            />
                            <label htmlFor="saved-template">Saved Template</label>
                        </div>
                    </div>
                    <div className="col s12 m2 l2" style={dataCriteria.reportType !== "OrderReport" ? { display: "none" } : { display: "block" }}>
                        <div className="input-field">
                            <Select
                                id="search-by"
                                value={dataCriteria.searchBy}
                                dataSource={initialDatas.searchOptions}
                                mapDataToRenderOptions={{ value: "value", label: "label" }}
                                onChange={(value) => this.handleValueChanged({ searchBy: value })}
                            />
                            <label htmlFor="search-by">Search By</label>
                        </div>
                    </div>

                    <div className="col s12 m2 l2 " style={dataCriteria.reportType !== "OrderReport" ? { display: "none" } : { display: "block" }}>
                        <div className="input-field">
                            <DatePicker
                                id="date-from"
                                defaultValue={dataCriteria.dateFrom || ""}
                                labelText="Date From"
                                onBlur={(e) => this.handleValueChanged({ dateFrom: moment(e).format("MM/DD/YYYY") })}
                            />
                        </div>
                    </div>
                    <div className="col s12 m2 l2" style={dataCriteria.reportType !== "OrderReport" ? { display: "none" } : { display: "block" }}>
                        <div className="input-field">
                            <DatePicker
                                id="date-to"
                                defaultValue={dataCriteria.dateTo || ""}
                                labelText="To"
                                onBlur={(e) => this.handleValueChanged({ dateTo: moment(e).format("MM/DD/YYYY") })}
                            />
                        </div>
                    </div>
                    <div className="col s12 m2 l2" style={dataCriteria.reportType !== "VendorReport" ? { display: "none" } : { display: "block" }}>
                        <div className="input-field">
                            <Select
                                id="vendor-status"
                                value={vendorStatusList.vendorStatus || ""}
                                dataSource={vendorStatusList}
                                mapDataToRenderOptions={{ value: "index", label: "name" }}
                                onChange={(value) => this.handleValueChanged({ vendorStatus: value })}
                            />
                            <label htmlFor="vendor-status">Vendor Status</label>
                        </div>
                    </div>
                    <div className="col s12 m2 l2" style={dataCriteria.reportType !== "OrderReport" ? { display: "none" } : { display: "block" }}>
                        <div className="input-field">
                            <label>
                                <input type="checkbox" defaultChecked="" />
                                <span>All Files</span>
                            </label>
                        </div>
                    </div>
                </div>

                <div className="row">
                    <div className="col s12 ">
                        <p className="left red-color">You can drag and drop item between sections.</p>
                        <div className="right">
                            <button className="btn default-color action-btn" onClick={() => this.handleExport()}>Export</button>
                            <button className="btn success-color action-btn" onClick={() => this.handleShowModal()}>Save This Template</button>
                            <button className="btn success-color action-btn" disabled={reportId === null} onClick={() => this.handleDelete(reportId)}>Delete This Template</button>
                        </div>
                    </div>
                </div>

                <div className="row">
                    <div className="col s12 manual-report-tab">
                        <div className="available dragsec">
                            <DragDropTable
                                id="available-fields"
                                highlightKey="isSelected"
                                primaryKey="value"
                                columns={[
                                    { header: "Available Fields", dataField: "label" }
                                ]}
                                allowFocus
                                source={initialDatas.availableFields}
                                handleOnEnd={(evt) => this.handleOnEnd(evt)}
                                onRowClick={(primaryKey) => this.handleSelectedOnRowClick(primaryKey)}
                            />
                        </div>
                        <div className="control-group">
                            <button className="btn success-color" onClick={() => this.handleOnMove("MOVE_RIGHT")}>
                                <span className="lnr lnr-chevron-right"></span>
                            </button>
                            <div className="clear"></div>
                            <button className="btn success-color mt-1" onClick={() => this.handleOnMove("MOVE_LEFT")}>
                                <span className="lnr lnr-chevron-left"></span>
                            </button>
                        </div>
                        <div className="selected dragsec">
                            <DragDropTable
                                id="selected-fields"
                                highlightKey="isSelected"
                                primaryKey="value"
                                columns={[
                                    { header: "Selected Fields", dataField: "label" }
                                ]}
                                allowFocus
                                source={currentTemplate.selectedFields}
                                handleOnEnd={(evt) => this.handleOnEnd(evt)}
                                onRowClick={(primaryKey) => this.handleSelectedOnRowClick2(primaryKey)}
                            />
                        </div>
                    </div>
                </div>
                <Modal isOpen={showReportNameModal} addClass={"height-custom"}>
                    <ModalBody>
                        <ModalTitle onClickClose={() => this.handleCloseModal()}>Add Report Name</ModalTitle>
                        <div className="row">
                            <div className={`input-field col s12 required suffixinput ${this.state.validator.isReportNameRequiredInvalid ? "required-field" : ""} ${this.state.validator.isReportNameExistInvalid ? "has-error" : ""}`}>
                                <textarea
                                    className="materialize-textarea"
                                    style={{ minHeight: "60px" }}
                                    maxLength="250" type="text"
                                    ref="reportName" id="reportName"
                                    maxLength="50"
                                    onBlur={() => this.handleValidateReportName()}
                                />
                                <label htmlFor="reportName">Report Name</label>
                                <span className="suffix-text" style={this.state.validator.isReportNameRequiredInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" />
                                </span>
                                <span className="suffix-text" style={this.state.validator.isReportNameExistInvalid ? { display: "block" } : { display: "none" }} >
                                    <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title="The Template name cannot be duplicate." />
                                </span>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col m6">
                                <button className="btn white w-100" onClick={() => this.handleCancel()}>Cancel</button>
                            </div>
                            <div className="col m6">
                                <button className="btn success-color w-100" onClick={() => this.handleSaveTemplate()}>Add</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div >
        );
    }
}

ManualReport.propTypes = {
    dispatch: PropTypes.func,
    currentTemplate: PropTypes.object,
    initialDatas: PropTypes.object,
    searchObject: PropTypes.object,
    selectedFields: PropTypes.array,
    reportId: PropTypes.number,
    listReport: PropTypes.array,
    vendorStatusList: PropTypes.array,
    roleType: PropTypes.string,
    onRowClick: PropTypes.func,
    listColumnsByReportName: PropTypes.array,
    reportTypes: PropTypes.object
};

ManualReport.defaultProps = {
    vendorStatusList: [
        { index: 0, name: "Both" },
        { index: 1, name: "Active" },
        { index: 2, name: "Inactive" }
    ]
};
const mapStateToProps = (state) => {
    const { cannedReport, authentication } = state;
    const { role } = authentication;
    const { roleType } = role;
    const { manualReport } = cannedReport;
    const { reportId } = manualReport;
    const { listReport } = manualReport;

    return {
        searchObject: manualReport.searchObject,
        currentTemplate: manualReport.currentTemplate,
        initialDatas: manualReport.initialDatas,
        reportTypes: manualReport.initialDatas,
        reportId,
        listReport,
        roleType
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(ManualReport);