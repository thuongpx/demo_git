import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { CHARJS_CONSTANTS } from "../../../constant/constants";
import CannedReport from "../components/canned-report";
import {
    fetchMilestonesChartData, fetchMilestonesGridData, countMilestonesGridData,
    fetchClosedOrdersByCustomersChartData, fetchOpenOrderTrendByCustomerChartData,
    countClosedOrdersByCustomersGridData, fetchClosedOrdersByCustomersGridData,
    fetchOpenOrderTrendGridData, countOpenOrderTrendGridData,
    fetchOpenOrderByCustomerAndStatusChartData, fetchOpenOrderByCustomerAndStatusGridData, countOpenOrderByCustomerAndStatusGridData,
    fetchOpenOrderByCustomerAndStatusForStaffChartData, fetchOpenOrderByCustomerAndStatusForStaffGridData, countOpenOrderByCustomerAndStatusForStaffGridData,

    fetchClosedOrdersByClientChartData, fetchClosedOrdersByClientForStaffGridData, countClosedOrdersByClientForStaffGridData,
    fetchOpenOrdersForStaffChartData, fetchOpenOrderTrendForStaffGridData, countOpenOrderTrendForStaffGridData,
    fetchMilestonesForStaffChartData, fetchMilestonesForStaffGridData, countMilestonesForStaffGridData, exportMilestonesGridData, exportOpenOrderTrendGridData, exportClosedOrdersByCustomersGridData, exportOpenOrderByCustomerAndStatusGridData
} from "../actions/customer-report";
import { USER_TYPE } from "../../../constant/constants";

class CustomerReport extends Component {
    constructor(props) {
        super(props);

        this.state = {
            fromDate: "",
            toDate: "",
            Loading: true
        };
        const { roleType } = this.props;
        this._isStaff = roleType === USER_TYPE.Staff;
    }

    handleChangeSearchObj(searchObj) {
        this.setState({
            fromDate: searchObj.fromDate || "",
            toDate: searchObj.toDate || ""
        });
    }
    handleShowRowDetail(isAuto) {
        if (isAuto) {
            this.setState(prevState => ({
                autoRow: !prevState.autoRow
            }));
        } else {
            this.setState(prevState => ({
                manualRow: !prevState.manualRow
            }));
        }
    }
    handleChangeGraph(e) {
        switch (e.target.value) {
            case "line":
                this.myBarChart.config.type = "line";

                for (let i = 0; i < this.myBarChart.config.data.datasets.length; i++) {
                    this.myBarChart.config.data.datasets[i].borderColor = this.myBarChart.config.data.datasets[i].backgroundColor;
                    this.myBarChart.config.data.datasets[i].fill = false;
                    this.myBarChart.config.data.datasets[i].lineTension = 0;
                }
                this.myBarChart.update();
                break;

            case "col":
                this.myBarChart.config.type = "bar";
                this.myBarChart.update();
                break;

            default:
                break;
        }
    }

    render() {
        const { dispatch } = this.props;
        const { closedOrdersByCustomersChartData } = this.props;
        const { milestoneChartData, milestoneGridData, milestoneTotalRecord, openOrderTrendGridData, openOrderTrendTotalRecord,
            openOrderByCustomerAndStatusChartData, openOrderByCustomerAndStatusTotalRecord, openOrderByCustomerAndStatusGridData,
            closedOrdersByCustomersRecord, closedOrdersByCustomersGridData, roleType,
            openOrderByCustomerAndStatusForStaffChartData, openOrderByCustomerAndStatusForStaffGridData, openOrderByCustomerAndStatusForStaffTotalRecord,
            closedOrdersByClientForStaffChartData, closedOrdersByClientForStaffRecord, closedOrdersByClientForStaffGridData, openOrderTrendChartData
        } = this.props;

        const milestoneGridOptions = {
            type: "milestone",
            label: "Customer Milestones",
            criteria: {
                sortColumn: "TotalClosedOrders",
                sortDirection: false,
                page: 1,
                itemPerPage: 25
            },
            totalRecord: milestoneTotalRecord,
            dataSource: milestoneGridData,
            filters: [],
            columns: [
                { SortOrder: 0, title: "Company", data: "Company", id: "Company" },
                { SortOrder: 1, title: "Total Orders", data: "TotalOrders" },
                { SortOrder: 2, title: "Total Closed Orders", data: "TotalClosedOrders" }
            ],
            fetchDrilldownData: (s, o) => dispatch(fetchMilestonesGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countMilestonesGridData(s)),
            exportDrilldownData: (s) => dispatch(exportMilestonesGridData(s))
        };

        const openOrderTrendGridOptions = {
            label: "Open Orders List by Clients and Status",
            criteria: {
                sortColumn: "TotalOrder",
                sortDirection: false,
                page: 1,
                itemPerPage: 25
            },
            totalRecord: openOrderTrendTotalRecord,
            dataSource: openOrderTrendGridData,
            filters: [],
            columns: [
                { SortOrder: 0, title: "Customer", data: "Customer", id: "TotalOrder" },
                { SortOrder: 1, title: "Open Orders", data: "TotalOrder" },
                { SortOrder: 3, title: "Closed", data: "Closed" },
                { SortOrder: 4, title: "Pending", data: "Pending" },
                { SortOrder: 5, title: "Canceled", data: "Canceled" },
                { SortOrder: 6, title: "Cancellation Percentage", data: "CancellationPercentage" }
            ],
            fetchDrilldownData: (s, o) => dispatch(fetchOpenOrderTrendGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countOpenOrderTrendGridData(s)),
            exportDrilldownData: (s) => dispatch(exportOpenOrderTrendGridData(s))
        };

        const openOrderByCustomerOptions = {
            label: "Open Orders List by Clients and Status",
            criteria: {
                sortColumn: "TotalOrder",
                sortDirection: false,
                page: 1,
                itemPerPage: 25
            },
            totalRecord: openOrderByCustomerAndStatusTotalRecord,
            dataSource: openOrderByCustomerAndStatusGridData,
            filters: [],
            columns: [
                { SortOrder: 0, title: "Customer", data: "Customer", id: "TotalOrder" },
                { SortOrder: 1, title: "Open Orders", data: "TotalOrder" },
                { SortOrder: 3, title: "Closed", data: "Closed" },
                { SortOrder: 4, title: "Pending", data: "Pending" },
                { SortOrder: 5, title: "Canceled", data: "Canceled" },
                { SortOrder: 6, title: "Cancellation Percentage", data: "CancellationPercentage" }
            ],
            fetchDrilldownData: (s, o) => dispatch(fetchOpenOrderByCustomerAndStatusGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countOpenOrderByCustomerAndStatusGridData(s)),
            exportDrilldownData: (s) => dispatch(exportOpenOrderByCustomerAndStatusGridData(s))
        };

        const openOrderByCustomerOptionsForStaff = {
            ...openOrderByCustomerOptions,
            totalRecord: openOrderByCustomerAndStatusForStaffTotalRecord,
            dataSource: openOrderByCustomerAndStatusForStaffGridData,
            fetchDrilldownData: (s, o) => dispatch(fetchOpenOrderByCustomerAndStatusForStaffGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countOpenOrderByCustomerAndStatusForStaffGridData(s))
        };

        const openOrderTrendForStaffGridOptions = {
            label: "Open Orders List by Clients and Status",
            criteria: {
                sortColumn: "Agents",
                sortDirection: false,
                page: 1,
                itemPerPage: 25
            },
            totalRecord: openOrderTrendTotalRecord,
            dataSource: openOrderTrendGridData,
            filters: [],
            columns: [
                { SortOrder: 0, title: "Customer", data: "Agents", id: "Agents" },
                { SortOrder: 1, title: "Open Orders", data: "TotalOrder" },
                { SortOrder: 3, title: "Closed", data: "Closed" },
                { SortOrder: 4, title: "Pending", data: "Pending" },
                { SortOrder: 5, title: "Canceled", data: "Canceled" },
                { SortOrder: 6, title: "Cancellation Percentage", data: "CancellationPercentage" }
            ],
            fetchDrilldownData: (s, o) => dispatch(fetchOpenOrderTrendForStaffGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countOpenOrderTrendForStaffGridData(s))
        };

        const closedOrdersByCustomersControl = [
            {
                type: "customer",
                classes: "col s4 offset-s8 pull-s8",
                defaultValue: "Top10AndOthers"
            },
            {
                type: "dayFrom",
                classes: "col s2"
            },
            {
                type: "dayTo",
                classes: "col s2"
            },
            {
                type: "month",
                classes: "col s5"
            }
        ];

        const closedOrdersByClientForStaffControl = [
            {
                type: "agentStaff",
                classes: "col s4 offset-s8 pull-s8"
            },
            {
                type: "dayFrom",
                classes: "col s2"
            },
            {
                type: "dayTo",
                classes: "col s2"
            },
            {
                type: "month",
                classes: "col s5"
            }
        ];

        const openOrderTrendbyCustomerControls = [
            {
                type: "customer",
                classes: "col s4 offset-s8 pull-s8",
                defaultValue: "Top10AndOthers"
            },
            {
                type: "dayFrom",
                classes: "col s2"
            },
            {
                type: "dayTo",
                classes: "col s2"
            },
            {
                type: "month",
                classes: "col s5"
            }
        ];

        const openOrderByCustomerControls = [
            {
                type: "customer",
                classes: "col s3 offset-s9 pull-s9"
            },
            {
                type: "orderStatus",
                classes: "col s3"
            },
            {
                type: "fromDate",
                classes: "col s3",
                dataSource: [],
                compareDate: this.state.toDate,
                inValidMess: "Request From Date can not be greater than Request To Date"
            },
            {
                type: "toDate",
                classes: "col s3",
                dataSource: [],
                compareDate: this.state.fromDate,
                inValidMess: "Request From Date can not be greater than Request To Date"
            }
        ];

        const openOrderTrendForStaffControls = [
            {
                type: "agentStaff",
                classes: "col s4 offset-s8 pull-s8"
            },
            {
                type: "dayFrom",
                classes: "col s2"
            },
            {
                type: "dayTo",
                classes: "col s2"
            },
            {
                type: "month",
                classes: "col s5"
            }
        ];

        const closedOrdersByCustomersGridOptions = {
            label: "Closed Orders By Customers",
            criteria: {
                sortColumn: "Customer",
                sortDirection: true,
                page: 1,
                itemPerPage: 25
            },
            totalRecord: closedOrdersByCustomersRecord,
            dataSource: closedOrdersByCustomersGridData,
            filters: [],
            columns: [
                { SortOrder: 0, title: "Customers", data: "Customer", id: "Customer" },
                { SortOrder: 1, title: "Closed Orders", data: "Closed" },
                { SortOrder: 2, title: "Cancelled Orders", data: "Canceled" }
            ],
            fetchDrilldownData: (s, o) => dispatch(fetchClosedOrdersByCustomersGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countClosedOrdersByCustomersGridData(s)),
            exportDrilldownData: (s) => dispatch(exportClosedOrdersByCustomersGridData(s))
        };

        const closedOrdersByClientsForStaffGridOptions = {
            label: "Closed Orders By Clients",
            criteria: {
                sortColumn: "Agents",
                sortDirection: false,
                page: 1,
                itemPerPage: 25
            },
            totalRecord: closedOrdersByClientForStaffRecord,
            dataSource: closedOrdersByClientForStaffGridData,
            filters: [],
            columns: [
                { SortOrder: 0, title: "Customers", data: "Agents", id: "Customer" },
                { SortOrder: 1, title: "Closed Orders", data: "Closed" },
                { SortOrder: 2, title: "Cancelled Orders", data: "Canceled" },
                { SortOrder: 3, title: "Income", data: "Income" },
                { SortOrder: 4, title: "Cost of Sales", data: "CostOfSales" },
                { SortOrder: 5, title: "Net Revenue", data: "NetRevenue" },
                { SortOrder: 6, title: "Avg Income", data: "AvgIncome" },
                { SortOrder: 7, title: "Avg COS", data: "AvgCOS" },
                { SortOrder: 8, title: "AvgNetRevenue", data: "AvgNetRevenue" }
            ],
            fetchDrilldownData: (s, o) => dispatch(fetchClosedOrdersByClientForStaffGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countClosedOrdersByClientForStaffGridData(s))
        };

        // const { autoRow, manualRow } = this.state;
        //milestone for staff
        const milestoneGridForStaffOptions = {
            type: "milestone",
            label: "Customer Milestones",
            criteria: {
                sortColumn: "ClientID",
                sortDirection: false,
                page: 1,
                itemPerPage: 25
            },
            totalRecord: milestoneTotalRecord,
            dataSource: milestoneGridData,
            filters: [],
            columns: [
                { SortOrder: 0, title: "Client ID", data: "ClientID", id: "ClientID" },
                { SortOrder: 1, title: "Company", data: "Company" },
                { SortOrder: 2, title: "Agents", data: "Agents" },
                { SortOrder: 3, title: "Total Orders", data: "TotalOrders" },
                { SortOrder: 4, title: "Total Closed Orders", data: "TotalClosedOrders" },
                { SortOrder: 5, title: "Address", data: "Address" },
                { SortOrder: 6, title: "City", data: "City" },
                { SortOrder: 7, title: "State", data: "State" },
                { SortOrder: 8, title: "Zip", data: "Zip" },
                { SortOrder: 9, title: "Direct", data: "Direct" },
                { SortOrder: 10, title: "Fax", data: "Fax" }
            ],
            fetchDrilldownData: (s, o) => dispatch(fetchMilestonesForStaffGridData(s, o)),
            countDrilldownRecord: (s) => dispatch(countMilestonesForStaffGridData(s))
        };
        return (
            <div className="row">
                <div className="col s12 m6">
                    <blockquote className="title-quote">{(roleType === USER_TYPE.Staff) ? `Open Orders by Clients` : `Open Orders by Customer`}</blockquote>

                    <CannedReport
                        id="open-order-trend-chart"
                        chartLabel={(roleType === USER_TYPE.Staff) ? "Open Orders by Clients and Status" : "Open Orders by Customers and Status"}
                        chartData={(roleType === USER_TYPE.Staff) ? openOrderByCustomerAndStatusForStaffChartData : openOrderByCustomerAndStatusChartData}
                        chartType={CHARJS_CONSTANTS.BAR}
                        onRenderChart={(object) => (roleType === USER_TYPE.Staff) ? dispatch(fetchOpenOrderByCustomerAndStatusForStaffChartData(object)) : dispatch(fetchOpenOrderByCustomerAndStatusChartData(object))}
                        controls={openOrderByCustomerControls}
                        getChangeObj={(searchObj) => this.handleChangeSearchObj(searchObj)}
                        gridOptions={(roleType === USER_TYPE.Staff) ? openOrderByCustomerOptionsForStaff : openOrderByCustomerOptions}
                        buttonApplyClasses={"col s3"}
                    />
                </div>
                <div className="col s12 m6">
                    <blockquote className="title-quote">{this._isStaff ? "Open Orders Trend by Clients" : "Open Orders Trend by Customer"}</blockquote>
                    {this._isStaff ?
                        <CannedReport
                            id="open-order-trend-for-staff-chart"
                            chartLabel={"Open Orders Trend by Clients"}
                            chartData={openOrderTrendChartData}
                            chartType={CHARJS_CONSTANTS.BAR}
                            onRenderChart={(object) => dispatch(fetchOpenOrdersForStaffChartData(object))}
                            controls={openOrderTrendForStaffControls}
                            getChangeObj={(searchObj) => this.handleChangeSearchObj(searchObj)}
                            gridOptions={openOrderTrendForStaffGridOptions}
                            buttonApplyClasses={"col s3"}
                        /> :
                        <CannedReport
                            id="open-order-trend-chart"
                            chartLabel={"Open Orders Trend by Customers"}
                            chartData={openOrderTrendChartData}
                            chartType={CHARJS_CONSTANTS.BAR}
                            onRenderChart={(object) => dispatch(fetchOpenOrderTrendByCustomerChartData(object))}
                            controls={openOrderTrendbyCustomerControls}
                            gridOptions={openOrderTrendGridOptions}
                            buttonApplyClasses={"col s3"}
                        />}
                </div>

                <div className="clear"></div>


                <div className="col s12 m6">
                    <blockquote className="title-quote">{this._isStaff ? "Closed Orders By Clients" : "Closed Orders By Customers"}</blockquote>
                    {this._isStaff ?
                        <CannedReport
                            id="closed-orders-by-clients"
                            chartLabel={"Closed Orders By Clients"}
                            chartData={closedOrdersByClientForStaffChartData}
                            chartType={CHARJS_CONSTANTS.BAR}
                            onRenderChart={(object) => dispatch(fetchClosedOrdersByClientChartData(object))}
                            controls={closedOrdersByClientForStaffControl}
                            gridOptions={closedOrdersByClientsForStaffGridOptions}
                            buttonApplyClasses={"col s3"}
                        /> :
                        <CannedReport
                            id="closed-orders-by-customers"
                            chartLabel={"Closed Orders By Customers"}
                            chartData={closedOrdersByCustomersChartData}
                            chartType={CHARJS_CONSTANTS.BAR}
                            onRenderChart={(object) => dispatch(fetchClosedOrdersByCustomersChartData(object))}
                            controls={closedOrdersByCustomersControl}
                            gridOptions={closedOrdersByCustomersGridOptions}
                            buttonApplyClasses={"col s3"}
                        />}
                </div>

                {this._isStaff ?
                    <div className="col s12 m6">
                        <blockquote className="title-quote">Customer Milestones</blockquote>
                        <CannedReport
                            id="milestones-for-staff-chart"
                            chartLabel={"Customer Milestones"}
                            chartData={milestoneChartData}
                            chartType={CHARJS_CONSTANTS.BAR}
                            onRenderChart={(object) => dispatch(fetchMilestonesForStaffChartData(object))}
                            gridOptions={milestoneGridForStaffOptions}
                        />
                    </div>
                    :
                    <div className="col s12 m6">
                        <blockquote className="title-quote">Customer Milestones</blockquote>
                        <CannedReport
                            id="milestones"
                            chartLabel={"Customer Milestones"}
                            chartData={milestoneChartData}
                            chartType={CHARJS_CONSTANTS.BAR}
                            onRenderChart={(object) => dispatch(fetchMilestonesChartData(object))}
                            gridOptions={milestoneGridOptions}
                        />
                    </div>
                }
            </div >
        );
    }
}


CustomerReport.propTypes = {
    dispatch: PropTypes.func,
    milestoneChartData: PropTypes.object,
    milestoneGridData: PropTypes.array,
    milestoneTotalRecord: PropTypes.number,
    openOrderTrendChartData: PropTypes.object,
    closedOrdersByCustomersChartData: PropTypes.object,

    closedOrdersByCustomersGridData: PropTypes.array,
    closedOrdersByCustomersRecord: PropTypes.number,
    openOrderTrendTotalRecord: PropTypes.number,
    openOrderTrendGridData: PropTypes.array,
    openOrderByCustomerAndStatusChartData: PropTypes.object,
    openOrderByCustomerAndStatusTotalRecord: PropTypes.number,
    openOrderByCustomerAndStatusGridData: PropTypes.array,
    roleType: PropTypes.string,

    openOrderByCustomerAndStatusForStaffChartData: PropTypes.object,
    openOrderByCustomerAndStatusForStaffGridData: PropTypes.array,
    openOrderByCustomerAndStatusForStaffTotalRecord: PropTypes.number,


    closedOrdersByClientForStaffChartData: PropTypes.object,
    closedOrdersByClientForStaffGridData: PropTypes.array,
    closedOrdersByClientForStaffRecord: PropTypes.number
};

const mapStateToProps = (state) => {
    const { cannedReport, authentication } = state;
    const { customerReport } = cannedReport;
    const { role } = authentication;

    return {
        milestoneChartData: customerReport.milestoneChartData,
        milestoneGridData: customerReport.milestoneGridData,
        milestoneTotalRecord: customerReport.milestoneTotalRecord,

        openOrderTrendChartData: customerReport.openOrderTrendChartData,
        openOrderTrendTotalRecord: customerReport.openOrderTrendTotalRecord,
        openOrderTrendGridData: customerReport.openOrderTrendGridData,

        closedOrdersByCustomersChartData: customerReport.closedOrdersByCustomersChartData,
        closedOrdersByCustomersGridData: customerReport.closedOrdersByCustomersGridData,
        closedOrdersByCustomersRecord: customerReport.closedOrdersByCustomersRecord,

        openOrderByCustomerAndStatusChartData: customerReport.openOrderByCustomerAndStatusChartData,
        openOrderByCustomerAndStatusTotalRecord: customerReport.openOrderByCustomerAndStatusTotalRecord,
        openOrderByCustomerAndStatusGridData: customerReport.openOrderByCustomerAndStatusGridData,
        roleType: role ? role.roleType : null,

        openOrderByCustomerAndStatusForStaffChartData: customerReport.openOrderByCustomerAndStatusForStaffChartData,
        openOrderByCustomerAndStatusForStaffGridData: customerReport.openOrderByCustomerAndStatusForStaffGridData,
        openOrderByCustomerAndStatusForStaffTotalRecord: customerReport.openOrderByCustomerAndStatusForStaffTotalRecord,

        closedOrdersByClientForStaffChartData: customerReport.closedOrdersByClientForStaffChartData,

        closedOrdersByClientForStaffGridData: customerReport.closedOrdersByClientForStaffGridData,
        closedOrdersByClientForStaffRecord: customerReport.closedOrdersByClientForStaffRecord

    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(CustomerReport);