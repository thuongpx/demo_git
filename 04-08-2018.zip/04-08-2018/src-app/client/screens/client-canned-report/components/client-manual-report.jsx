import React from "react";
import { Component } from "react";
import DatePicker from "DatePicker";

class ManualReport extends Component {
    constructor(props) {
        super(props);
    }

    loadScript(src) {
        return new Promise(((resolve, reject) => {
            const script = document.createElement("script");
            script.src = src;
            script.addEventListener("load", () => {
                resolve();
            });
            script.addEventListener("error", (e) => {
                reject(e);
            });
            document.body.appendChild(script);
        }));
    }

    loadStyle(src) {
        return new Promise(((resolve, reject) => {
            const link = document.createElement("link");
            link.href = src;
            link.addEventListener("load", () => {
                resolve();
            });
            link.addEventListener("error", (e) => {
                reject(e);
            });
            link.rel = "stylesheet";
            link.type = "text/css";
            const head = document.getElementsByTagName("head")[0];
            head.appendChild(link);
        }));
    }

    componentDidMount() {

        const loadScript = this.loadScript("https://code.jquery.com/ui/1.12.1/jquery-ui.js");
        const loadStyle = this.loadStyle("https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css");

        Promise.all([loadScript, loadStyle]).then(() => {
            $(() => {
                $(".available ul, .selected ul").sortable({
                    connectWith: ".dragsec"
                });
            });
        });

        $(".modal").modal();
        $("select").formSelect();
        $(".select-wrapper").each((i, obj) => {
            if ($(obj).find(".custome-style-select").length !== 0 && $(obj).find(".caret.updown").length === 0) {
                $(obj).find("svg").remove();
                $(obj).append("<span class=\"caret updown\"></span>");
            }
        });

    }

    render() {
        return (
            <div>

                <div className="row">
                    <div className="col s12 m2 l2">
                        <div className="input-field">
                            <select className="custome-style-select">
                                <option value="" selected>Order Report</option>
                                <option value="">Vendor Report</option>
                                <option value="">Client Report</option>
                            </select>
                            <label>Report Type</label>
                        </div>
                    </div>
                    <div className="col s12 m2 l2">
                        <div className="input-field">
                            <select className="custome-style-select">
                                <option value="" selected>All</option>
                            </select>
                            <label>Saved Template</label>
                        </div>
                    </div>

                    <div className="col s12 m2 l2">
                        <div className="input-field">
                            <select className="custome-style-select">
                                <option value="" selected>Closing Time</option>
                            </select>
                            <label>Search By</label>
                        </div>
                    </div>

                    <div className="col s12 m2 l2">
                        <div className="input-field">
                            <DatePicker
                                id="dailyCounterReportDate"
                                inputFormat="MM/DD/YYYY"
                                labelText="Date From"
                            />
                        </div>
                    </div>
                    <div className="col s12 m2 l2">
                        <div className="input-field">
                            <DatePicker
                                id="dailyCounterReportDate"
                                inputFormat="MM/DD/YYYY"
                                labelText="Date To"
                            />
                        </div>
                    </div>

                    <div className="col s12 m2 l2">
                        <div className="input-field">
                            <label>
                                <input type="checkbox" defaultChecked="checked" />
                                <span>All Orders</span>
                            </label>
                        </div>
                    </div>
                </div>

                <div className="row">
                    <div className="col s12 ">
                        <p className="left red-color">You can drag and drop item between sections.</p>
                        <div className="right">
                            <button className="btn default-color action-btn">Export</button>
                            <button className="btn success-color action-btn">Save This Template</button>
                        </div>
                    </div>
                </div>

                <div className="row">
                    <div className="col s12 manual-report-tab">
                        <div className="available dragsec">
                            <p>Available Fields</p>
                            <ul>
                                <li>Open Date</li>
                                <li>Title Company</li>
                                <li>File Number</li>
                                <li>Order Number</li>
                                <li>Borrower Last Name</li>
                                <li>Type of Transaction</li>
                                <li>Status</li>
                                <li>Cancel Date</li>
                                <li>Vender Fee</li>
                                <li>Client Fee</li>
                                <li>Appointment Assigned By</li>

                            </ul>
                        </div>
                        <div className="control-group">
                            <button className="btn success-color">
                                <span className="lnr lnr-chevron-right"></span>
                            </button>
                            <div className="clear"></div>
                            <button className="btn success-color mt-1">
                                <span className="lnr lnr-chevron-left"></span>
                            </button>
                        </div>
                        <div className="selected dragsec">
                            <p>Selected Fields</p>
                            <ul>

                                <li>Scheduler</li>
                                <li>Open Order Date/time</li>
                                <li>Assign Date/time</li>
                                <li>Assign hours</li>
                                <li>Assign Minutes</li>
                                <li>Assign Time</li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        );
    }
}


export default (ManualReport);