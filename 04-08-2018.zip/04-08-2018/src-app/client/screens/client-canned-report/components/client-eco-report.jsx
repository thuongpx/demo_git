import React from "react";
import { Component } from "react";
import DatePicker from "DatePicker";

class EconomicReport extends Component {
    constructor(props) {
        super(props);
    }

    loadScript(src) {
        return new Promise(((resolve, reject) => {
            const script = document.createElement("script");
            script.src = src;
            script.addEventListener("load", () => {
                resolve();
            });
            script.addEventListener("error", (e) => {
                reject(e);
            });
            document.body.appendChild(script);
        }));
    }
    componentDidMount() {

        const doLoadScript = this.loadScript("https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js");
        $(".modal").modal();
        $("select").formSelect();
        $(".select-wrapper").each((i, obj) => {
            if ($(obj).find(".custome-style-select").length !== 0 && $(obj).find(".caret.updown").length === 0) {
                $(obj).find("svg").remove();
                $(obj).append("<span class=\"caret updown\"></span>");
            }
        });

        doLoadScript.then(() => {
            const ctx = document.getElementById("feeRequestApproval").getContext("2d");

            const data = {
                labels: ["SLA Deadline", "Location/Distance", "SA Backout", "Same Day Signing", "Holiday", "Other", "Best Option Avaiable"],
                datasets: [
                    {
                        label: "Yes",
                        backgroundColor: "#ea6d6d",
                        data: [73, 70, 60, 61, 67, 20, 5]
                    },
                    {
                        label: "No",
                        backgroundColor: "#B8D64B",
                        data: [16, 12, 15, 10, 5, 8, 1]
                    }
                ]
            };

            this.myBarChart = new Chart(ctx, {
                type: "bar",
                data,

                options: {
                    tooltips: {
                        enabled: false,
                        mode: null
                    },
                    title: {
                        display: true,
                        text: "Fee Increase Request/Approval",
                        padding: 20,
                        fontSize: 14
                    },
                    animation: {
                        onComplete() {


                            const ctx = this.chart.ctx;
                            ctx.textAlign = "center";
                            ctx.textBaseline = "middle";
                            const chart = this;
                            const datasets = this.config.data.datasets;

                            datasets.forEach((dataset, i) => {
                                ctx.font = "14px Poppins";
                                ctx.fillStyle = "#222";
                                chart.getDatasetMeta(i).data.forEach((p, j) => {
                                    ctx.fillText(datasets[i].data[j], p._model.x, p._model.y - 10);
                                });
                            });


                        }
                    },
                    hover: { mode: null },
                    barValueSpacing: 20,
                    scales: {
                        yAxes: [{
                            ticks: {
                                min: 0
                            }
                        }],
                        xAxes: [{
                            ticks: {
                                autoSkip: false
                            }
                        }]
                    }
                }
            });
        });
    }

    shuffleArray(array) {
        let i = array.length - 1;
        for (; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            const temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        return array;
    }

    reRenderGraphStaff() {

        for (var i = 0; i < this.myBarChart.config.data.datasets.length; i++) {
            this.myBarChart.config.data.datasets[i].data = this.shuffleArray(this.myBarChart.config.data.datasets[i].data);
        }
        this.myBarChart.update();
    }

    render() {
        return (
            <div>
                <div className="row">
                    <div className="col s12 m12">
                        <blockquote className="title-quote">
                            Fee Increase Request/Approval
                                        </blockquote>

                        <div className="row">
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <DatePicker
                                        id="dailyCounterReportDate"
                                        inputFormat="MM/DD/YYYY"
                                        labelText="Req Date From"
                                    />
                                </div>
                            </div>
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <DatePicker
                                        id="dailyCounterReportDate"
                                        inputFormat="MM/DD/YYYY"
                                        labelText="Req Date To"
                                    />
                                </div>
                            </div>
                            <div className="col s12 m3 l3">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>All</option>
                                        <option value="">Best Option Available</option>
                                        <option value="">Location/Distance</option>
                                        <option value="">SA Backout</option>
                                        <option value="">SLA Deadline</option>
                                        <option value="">Holiday</option>
                                        <option value="">Sam Day Signing</option>
                                        <option value="">Other</option>
                                    </select>
                                    <label>Fee Increase Request reason</label>
                                </div>
                            </div>
                            <div className="col s12 m3 l3">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>Both</option>
                                        <option value="">Yes</option>
                                        <option value="">No</option>
                                    </select>
                                    <label>Approve?</label>
                                </div>
                            </div>

                            <div className="col s12 m2 l2 mt-2">
                                <button type="button" className="btn success-color w-100 btn-small" onClick={() => this.reRenderGraphStaff()}> Apply</button>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12 m8 offset-m2">
                                <canvas id="feeRequestApproval" width="100%" className="modal-trigger" data-target="modalFeeRequest" style={{ cursor: "pointer" }}></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="modalFeeRequest" className="modal custome-modal modal-fixed-footer modal-large no-tab">
                    <div className="modal-content">
                        <p className="header-title-modal">Fee Increase Request/Approval List</p>
                        <div className="tab-content">
                            <div className="row">
                                <div className="col s12">
                                    <table className="striped highlight responsive-table">
                                        <thead>
                                            <tr>
                                                <th>Open Date</th>
                                                <th>Order Number</th>
                                                <th>Original Fee</th>
                                                <th>Proposed Fee</th>
                                                <th>Fee Increase Reason</th>
                                                <th>Approved</th>
                                                <th>Schedulers</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>

                                                <td>7/9/2017</td>
                                                <td>1</td>
                                                <td>$35</td>
                                                <td>$50</td>
                                                <td>Location/Distance</td>
                                                <td>Yes</td>
                                                <td>Jacqueline Anderson</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="modal-footer">
                        <div className="row center-align m-0">
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn white modal-action modal-close w-100">Back to Report page</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Export</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Print</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        );
    }
}


export default (EconomicReport);