import React from "react";
import { Component } from "react";
import DatePicker from "DatePicker";

class DailyReport extends Component {
    constructor(props) {
        super(props);
        this.state = {
            autoRow: true,
            manualRow: true
        };
    }

    handleShowRowDetail(isAuto) {
        if (isAuto) {
            this.setState(prevState => ({
                autoRow: !prevState.autoRow
            }));
        } else {
            this.setState(prevState => ({
                manualRow: !prevState.manualRow
            }));
        }
    }

    loadScript(src) {
        return new Promise(((resolve, reject) => {
            const script = document.createElement("script");
            script.src = src;
            script.addEventListener("load", () => {
                resolve();
            });
            script.addEventListener("error", (e) => {
                reject(e);
            });
            document.body.appendChild(script);
        }));
    }

    componentDidMount() {

        const doLoadScript = this.loadScript("https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js");
        $(".modal").modal();
        $("select").formSelect();
        $(".select-wrapper").each((i, obj) => {
            if ($(obj).find(".custome-style-select").length !== 0 && $(obj).find(".caret.updown").length === 0) {
                $(obj).find("svg").remove();
                $(obj).append("<span class=\"caret updown\"></span>");
            }
        });

        doLoadScript.then(() => {
            const ctx = document.getElementById("openorder").getContext("2d");
            const ctx_comparison = document.getElementById("openorder-comparison").getContext("2d");
            const ctx_autoassign = document.getElementById("openorder-auto-assign").getContext("2d");
            const ctx_manualassign = document.getElementById("order-manual-assign").getContext("2d");

            const data = {
                labels: ["Closed", "Appt Made", "Pending Docs", "Open", "Hold", "Canceled", "Closed Pending Faxback", "Pending"],
                datasets: [
                    {
                        label: "First Mortgage",
                        backgroundColor: "#769A2A",
                        data: [75, 51, 44, 43, 43, 43, 41, 41]
                    },
                    {
                        label: "Auto",
                        backgroundColor: "#B8D64B",
                        data: [12, 14, 13, 13, 12, 12, 14, 13]
                    }
                ]
            };

            const data_compar = {
                labels: ["", "Aug", "Sep", ""],
                datasets: [
                    {
                        borderColor: "#EA6d6d",
                        backgroundColor: "#EA6d6d",
                        fill: false,
                        lineTension: 0,
                        data: [null, 599, 484, null]
                    }
                ]
            };


            this.myBarChartAuToAssign = new Chart(ctx_autoassign, {
                type: "bar",
                data: {
                    datasets: [
                        //     {
                        //     label: "Avg of Profit",
                        //     data: [44, 49, 40],
                        //     borderColor: "#EA6d6d",
                        //     backgroundColor: "#EA6d6d",
                        //     // Changes this dataset to become a line
                        //     type: "line",
                        //     lineTension: 0,
                        //     fill: false
                        // },
                        {
                            label: "Total orders",
                            backgroundColor: "#769A2A",
                            data: [20, 16, 6],
                            type: "bar"
                        }],
                    labels: ["Pending", "Apt. Made", "Closed"]
                },
                options: {
                    tooltips: {
                        enabled: false,
                        mode: null
                    },
                    title: {
                        display: true,
                        text: "Daily Auto-Assigned Orders by Status",
                        padding: 20,
                        fontSize: 14
                    },
                    animation: {
                        onComplete() {

                            const ctx = this.chart.ctx;
                            ctx.textAlign = "center";
                            ctx.textBaseline = "middle";
                            const chart = this;
                            const datasets = this.config.data.datasets;

                            datasets.forEach((dataset, i) => {

                                ctx.font = "14px Poppins";
                                ctx.fillStyle = "#222";
                                chart.getDatasetMeta(i).data.forEach((p, j) => {
                                    if (datasets[i].type === "bar") ctx.fillText(datasets[i].data[j], p._model.x, p._model.y - 10);

                                });
                            });


                        }
                    },
                    hover: { mode: null },
                    scales: {
                        yAxes: [{
                            ticks: {
                                min: 0
                            }
                        }],
                        xAxes: [{
                            barPercentage: 0.4,
                            ticks: {
                                autoSkip: false
                            }
                        }]
                    }
                }
            });

            this.myBarChartManualAssign = new Chart(ctx_manualassign, {
                type: "bar",
                data: {
                    datasets: [{
                        label: "Total orders",
                        backgroundColor: "#769A2A",
                        data: [24, 19, 14],
                        type: "bar"
                    }
                        // {
                        //     label: "Avg of Profit",
                        //     data: [11, 27, 13],
                        //     borderColor: "#EA6d6d",
                        //     backgroundColor: "#EA6d6d",
                        //     // Changes this dataset to become a line
                        //     type: "line",
                        //     lineTension: 0,
                        //     fill: false
                        // }
                    ],
                    labels: ["Pending", "Apt. Made", "Closed"]
                },
                options: {
                    tooltips: {
                        enabled: false,
                        mode: null
                    },
                    title: {
                        display: true,
                        text: "Daily Manual-Assigned Orders by Status",
                        padding: 20,
                        fontSize: 14
                    },
                    animation: {
                        onComplete() {

                            const ctx = this.chart.ctx;
                            ctx.textAlign = "center";
                            ctx.textBaseline = "middle";
                            const chart = this;
                            const datasets = this.config.data.datasets;

                            datasets.forEach((dataset, i) => {
                                ctx.font = "14px Poppins";
                                ctx.fillStyle = "#222";
                                chart.getDatasetMeta(i).data.forEach((p, j) => {
                                    if (datasets[i].type === "bar") ctx.fillText(datasets[i].data[j], p._model.x, p._model.y - 10);
                                });
                            });


                        }
                    },
                    hover: {
                        // Overrides the global setting
                        mode: null
                    },
                    scales: {
                        yAxes: [{
                            ticks: {
                                min: 0
                            }
                        }],
                        xAxes: [{
                            barPercentage: 0.4,
                            ticks: {
                                autoSkip: false
                            }
                        }]
                    }
                }
            });

            this.myBarChartCompar = new Chart(ctx_comparison, {
                type: "line",
                data: data_compar,

                options: {
                    tooltips: {
                        enabled: false,
                        mode: null
                    },
                    title: {
                        display: true,
                        text: "Open Orders Comparison by Business Day",
                        padding: 20,
                        fontSize: 14
                    },
                    legend: {
                        display: false
                    },
                    animation: {

                    },
                    hover: { mode: null },
                    barValueSpacing: 20,
                    scales: {
                        yAxes: [{
                            ticks: {
                                padding: 20,
                                min: 0
                            }
                        }],
                        xAxes: [{
                            ticks: {
                                padding: 20,
                                autoSkip: false
                            }
                        }]
                    }
                }
            });

            this.myBarChart = new Chart(ctx, {
                type: "bar",
                data,

                options: {
                    tooltips: {
                        enabled: false,
                        mode: null
                    },
                    title: {
                        display: true,
                        text: "Order By Status",
                        padding: 20,
                        fontSize: 14
                    },
                    animation: {
                        onComplete() {


                            const ctx = this.chart.ctx;
                            ctx.textAlign = "center";
                            ctx.textBaseline = "middle";
                            const chart = this;
                            const datasets = this.config.data.datasets;

                            datasets.forEach((dataset, i) => {
                                ctx.font = "14px Poppins";
                                ctx.fillStyle = "#222";
                                chart.getDatasetMeta(i).data.forEach((p, j) => {
                                    ctx.fillText(datasets[i].data[j], p._model.x, p._model.y - 10);
                                });
                            });


                        }
                    },
                    hover: { mode: null },
                    barValueSpacing: 20,
                    scales: {
                        yAxes: [{
                            ticks: {
                                min: 0
                            }
                        }],
                        xAxes: [{
                            ticks: {
                                autoSkip: false
                            }
                        }]
                    }
                }
            });
        });
    }

    shuffleArray(array) {
        let i = array.length - 1;
        for (; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            const temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        return array;
    }

    reRenderGraph(grap) {
        switch (grap) {
            case "statusGraph":

                for (var i = 0; i < this.myBarChart.config.data.datasets.length; i++) {
                    this.myBarChart.config.data.datasets[i].data = this.shuffleArray(this.myBarChart.config.data.datasets[i].data);
                }
                this.myBarChart.update();
                break;

            case "comparGraph":


                this.myBarChartCompar.config.data.datasets[0].data[1] = Math.floor(Math.random() * 99) + 10;
                this.myBarChartCompar.config.data.datasets[0].data[2] = Math.floor(Math.random() * 99) + 10;
                this.myBarChartCompar.update();
                break;

            case "dailyCountGraph":

                for (var i = 0; i < this.myBarChartManualAssign.config.data.datasets.length; i++) {
                    this.myBarChartManualAssign.config.data.datasets[i].data = this.shuffleArray(this.myBarChartManualAssign.config.data.datasets[i].data);
                }

                for (var i = 0; i < this.myBarChartAuToAssign.config.data.datasets.length; i++) {
                    this.myBarChartAuToAssign.config.data.datasets[i].data = this.shuffleArray(this.myBarChartAuToAssign.config.data.datasets[i].data);
                }

                this.myBarChartManualAssign.update();
                this.myBarChartAuToAssign.update();

                break;

            default:
                break;
        }
    }
    handleChangeGraph(e) {
        switch (e.target.value) {
            case "line":
                this.myBarChart.config.type = "line";

                for (var i = 0; i < this.myBarChart.config.data.datasets.length; i++) {
                    this.myBarChart.config.data.datasets[i].borderColor = this.myBarChart.config.data.datasets[i].backgroundColor;
                    this.myBarChart.config.data.datasets[i].fill = false;
                    this.myBarChart.config.data.datasets[i].lineTension = 0;
                }
                this.myBarChart.update();
                break;

            case "col":
                this.myBarChart.config.type = "bar";
                this.myBarChart.update();
                break;

            default:
                break;
        }
    }

    render() {
        const { autoRow, manualRow } = this.state;
        return (
            <div>
                <div className="row">
                    <div className="col s12 m3">
                        <div className="card-panel box-shadow-none fullbg-style-dashboard w-100 staff-report" style={{ backgroundColor: "#eee" }}>
                            <h5>Opened Volume</h5>
                            <div className="clear"></div>
                            <div className="wrap-volume">
                                <div className="text-content">
                                    <p className="number"> 30 </p>
                                    <span className="card-title truncate">Today</span>
                                </div>
                                <div className="text-content right">
                                    <p className="number"> 200 </p>
                                    <span className="card-title truncate">MTD</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col s12 m3">
                        <div className="card-panel box-shadow-none fullbg-style-dashboard w-100 staff-report closed-vol">
                            <h5>Closed Volume</h5>
                            <div className="clear"></div>
                            <div className="wrap-volume">
                                <div className="text-content">
                                    <p className="number"> 30 </p>
                                    <span className="card-title truncate">Today</span>
                                </div>
                                <div className="text-content right">
                                    <p className="number"> 200 </p>
                                    <span className="card-title truncate">MTD</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col s12 m3">
                        <div className="card-panel box-shadow-none fullbg-style-dashboard w-100 staff-report revenue">
                            <h5>Revenue</h5>
                            <div className="clear"></div>
                            <div className="wrap-volume">
                                <div className="text-content">
                                    <p className="number"> 4,560 </p>
                                    <span className="card-title truncate">Today</span>
                                </div>
                                <div className="text-content right">
                                    <p className="number"> 94,050 </p>
                                    <span className="card-title truncate">MTD</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col s12 m3">
                        <div className="card-panel box-shadow-none fullbg-style-dashboard w-100 staff-report gross-profit">
                            <h5>Gross Profit</h5>
                            <div className="clear"></div>
                            <div className="wrap-volume">
                                <div className="text-content">
                                    <p className="number"> 3,340 </p>
                                    <span className="card-title truncate">Today</span>
                                </div>
                                <div className="text-content right">
                                    <p className="number"> 80,050 </p>
                                    <span className="card-title truncate">MTD</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="row">
                    <div className="col s12 m6">
                        <blockquote className="title-quote">
                            Open Order by Status
                                        </blockquote>

                        <div className="row">
                            <div className="col s12 m3 l3">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="1" selected>Application</option>
                                        <option value="">Purchase</option>
                                        <option value="">Seller Side Purchase (Sale)</option>
                                        <option value="">Refinance</option>
                                        <option value="">Second Mortgage</option>
                                        <option value="">HELOC</option>
                                        <option value="">Deed In Lieu</option>
                                        <option value="">Quit Claim</option>
                                        <option value="">Disclosure</option>
                                        <option value="">Deed Only</option>
                                        <option value="">Note/Loan Modification</option>
                                        <option value="">Investment Purchase</option>
                                        <option value="">Investment Refinance</option>
                                    </select>
                                    <label>Order Type</label>
                                </div></div>
                            <div className="col s12 m3 l3">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="1">Open</option>
                                        <option value="2">Auto Assign</option>
                                        <option value="3">Assigned to Vendor</option>
                                        <option value="">Appt Confirmed</option>
                                        <option value="">Pending Pre-call</option>
                                        <option value="">Appt Ready</option>
                                        <option value="">Closed Pending Review</option>
                                        <option value="">Closed Pending QC Review</option>
                                        <option value="">Closed Pending Client Review</option>
                                        <option value="">Closing Completed</option>
                                        <option value="">Hold</option>
                                        <option value="">Canceled</option>
                                    </select>
                                    <label>Order Status</label>
                                </div></div>
                            <div className="col s12 m3 l3">
                                <div className="input-field">
                                    <select id="select-grahp" className="custome-style-select" onChange={(e) => this.handleChangeGraph(e)}>
                                        <option value="col" selected>Column</option>
                                        <option value="line">Line</option>
                                        <option value="clus">Clustered Column</option>
                                    </select>
                                    <label>Select Graph</label>
                                </div>
                            </div>
                            <div className="col s12 m3 l3 mt-2">
                                <button type="button" className="btn success-color w-100 btn-small" onClick={() => this.reRenderGraph("statusGraph")}> Apply</button>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12">
                                <canvas id="openorder" width="100%" className="modal-trigger" data-target="modalOrderStatus" style={{ cursor: "pointer" }}></canvas>
                            </div>
                        </div>
                    </div>
                    <div className="col s12 m6">
                        <blockquote className="title-quote">
                            Open Orders Comparison by Business Day
                                        </blockquote>

                        <div className="row">
                            <div className="col s12 m3 l3">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="1" selected>Application</option>
                                        <option value="">Purchase</option>
                                        <option value="">Seller Side Purchase (Sale)</option>
                                        <option value="">Refinance</option>
                                        <option value="">Second Mortgage</option>
                                        <option value="">HELOC</option>
                                        <option value="">Deed In Lieu</option>
                                        <option value="">Quit Claim</option>
                                        <option value="">Disclosure</option>
                                        <option value="">Deed Only</option>
                                        <option value="">Note/Loan Modification</option>
                                        <option value="">Investment Purchase</option>
                                        <option value="">Investment Refinance</option>
                                    </select>
                                    <label>Order Type</label>
                                </div>
                            </div>
                            <div className="col s12 m2 l2 input-field">
                                <select className="custome-style-select">
                                    <option value="1" selected>1</option>
                                </select>
                                <label>Day From</label>
                            </div>
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="1" selected>31</option>
                                    </select>
                                    <label>Day To</label>
                                </div>
                            </div>
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>Jun, Aug</option>
                                    </select>
                                    <label>Month</label>
                                </div>
                            </div>
                            <div className="col s12 m3 l3 mt-2">
                                <button type="button" className="btn success-color w-100 btn-small" onClick={() => this.reRenderGraph("comparGraph")}> Apply</button>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12">
                                <canvas id="openorder-comparison" width="100%"></canvas>
                            </div>
                        </div>
                    </div>

                    <div className="clear"></div>

                    <div className="col s12 ">
                        <blockquote className="title-quote">
                            Daily Counter Report
                                        </blockquote>

                        <div className="row">
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="1" selected>Pending, Apt. Made, Closed</option>
                                    </select>
                                    <label>Order Status</label>
                                </div></div>
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <DatePicker
                                        id="dailyCounterReportDate"
                                        inputFormat="MM/DD/YYYY"
                                        labelText="Date"
                                    />
                                </div>
                            </div>
                            <div className="col s12 m2 l2 mt-2">
                                <button type="button" className="btn success-color w-100 btn-small" onClick={() => this.reRenderGraph("dailyCountGraph")}> Apply</button>
                            </div>
                            <div className="col s12 m2 l2 mt-2 ">
                                <button type="button" className="btn default-color w-100 btn-small truncate modal-trigger" data-target="modalShowAll"> View All Orders by Status</button>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12 m6 l6">
                                <canvas id="openorder-auto-assign" width="100%" className="modal-trigger" data-target="modalAutoAssign" style={{ cursor: "pointer" }}></canvas>
                            </div>

                            <div className="col s12 m6 l6">
                                <canvas id="order-manual-assign" width="100%" className="modal-trigger" data-target="modalManualAssign" style={{ cursor: "pointer" }}></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="modalShowAll" className="modal custome-modal modal-fixed-footer modal-large no-tab">
                    <div className="modal-content">
                        <p className="header-title-modal">All Daily Order Volume</p>
                        <div className="tab-content">
                            <div className="row">
                                <div className="col s12">
                                    <table className="striped highlight responsive-table">
                                        <thead>
                                            <tr>
                                                <th>Order Status</th>
                                                <th>Total Orders</th>
                                                <th>Sum of Profit</th>
                                                <th>Average Profit</th>
                                                <th>Count of Assign Time</th>
                                                <th>Sum of Assign Time</th>
                                                <th>Average of Assign Time</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr id="1">
                                                <td><a className="btn-floating waves-effect waves-light green mr-1" onClick={() => this.handleShowRowDetail(true)} >
                                                    <i className="material-icons">{(autoRow) ? "keyboard_arrow_down" : "keyboard_arrow_right"}</i>
                                                </a>
                                                    <strong>Auto</strong>
                                                </td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr className={(autoRow) ? "" : "hide"}>
                                                <td>Closed</td>
                                                <td>6</td>
                                                <td>243</td>
                                                <td>40.50</td>
                                                <td>6</td>
                                                <td>30.68</td>
                                                <td>5.11</td>
                                            </tr>
                                            <tr className={(autoRow) ? "" : "hide"}>
                                                <td>Pending</td>
                                                <td>20</td>
                                                <td>877</td>
                                                <td></td>
                                                <td>20</td>
                                                <td>26.25</td>
                                                <td>1.31</td>
                                            </tr>
                                            <tr>
                                                <td><strong>Sub Total</strong></td>
                                                <td><strong>26</strong></td>
                                                <td><strong>1320</strong></td>
                                                <td></td>
                                                <td><strong>26</strong></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr id="2">
                                                <td><a className="btn-floating waves-effect waves-light green mr-1" onClick={() => this.handleShowRowDetail(false)} >
                                                    <i className="material-icons">{(manualRow) ? "keyboard_arrow_down" : "keyboard_arrow_right"}</i>
                                                </a>
                                                    <strong>Manual</strong>
                                                </td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr className={(manualRow) ? "" : "hide"}>
                                                <td>Closed</td>
                                                <td>6</td>
                                                <td>243</td>
                                                <td>40.50</td>
                                                <td>6</td>
                                                <td>30.68</td>
                                                <td>5.11</td>
                                            </tr>
                                            <tr className={(manualRow) ? "" : "hide"}>
                                                <td>Pending</td>
                                                <td>20</td>
                                                <td>877</td>
                                                <td></td>
                                                <td>20</td>
                                                <td>26.25</td>
                                                <td>1.31</td>
                                            </tr>
                                            <tr>
                                                <td><strong>Sub Total</strong></td>
                                                <td><strong>26</strong></td>
                                                <td><strong>1320</strong></td>
                                                <td></td>
                                                <td><strong>26</strong></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <strong className="font-15 red-color">Total</strong></td>
                                                <td className="font-15 red-color"><strong>52</strong></td>
                                                <td className="font-15 red-color"><strong>2640</strong></td>
                                                <td></td>
                                                <td className="font-15 red-color"><strong>52</strong></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="modal-footer">
                        <div className="row center-align m-0">
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn white modal-action modal-close w-100">Back to Report page</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Export</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Print</button>
                            </div>
                        </div>
                    </div>
                </div>


                <div id="modalAutoAssign" className="modal custome-modal modal-fixed-footer modal-large no-tab">
                    <div className="modal-content">
                        <p className="header-title-modal">Auto-Assign Daily Order Volume</p>
                        <div className="tab-content">
                            <div className="row">
                                <div className="col s12">
                                    <table className="striped highlight responsive-table">
                                        <thead>
                                            <tr>
                                                <th>Order Status</th>
                                                <th>Total Orders</th>

                                                <th>Count of Assign Time</th>
                                                <th>Sum of Assign Time</th>
                                                <th>Average of Assign Time</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Closed</td>
                                                <td>6</td>

                                                <td>6</td>
                                                <td>30.68</td>
                                                <td>5.11</td>
                                            </tr>
                                            <tr>
                                                <td>Pending</td>
                                                <td>20</td>

                                                <td>20</td>
                                                <td>26.25</td>
                                                <td>1.31</td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <strong className="font-14">Sub Total</strong></td>
                                                <td className="font-14"><strong>26</strong></td>

                                                <td className="font-14"><strong>26</strong></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="modal-footer">
                        <div className="row center-align m-0">
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn white modal-action modal-close w-100">Back to Report page</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Export</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Print</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="modalManualAssign" className="modal custome-modal modal-fixed-footer modal-large no-tab">
                    <div className="modal-content">
                        <p className="header-title-modal">Manual-Assign Daily Order Volume</p>
                        <div className="tab-content">
                            <div className="row">
                                <div className="col s12">
                                    <table className="striped highlight responsive-table">
                                        <thead>
                                            <tr>
                                                <th>Order Status</th>
                                                <th>Total Orders</th>

                                                <th>Count of Assign Time</th>
                                                <th>Sum of Assign Time</th>
                                                <th>Average of Assign Time</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Closed</td>
                                                <td>6</td>

                                                <td>6</td>
                                                <td>30.68</td>
                                                <td>5.11</td>
                                            </tr>
                                            <tr>
                                                <td>Pending</td>
                                                <td>20</td>

                                                <td>20</td>
                                                <td>26.25</td>
                                                <td>1.31</td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <strong className="font-14">Sub Total</strong></td>
                                                <td className="font-14"><strong>26</strong></td>

                                                <td className="font-14"><strong>26</strong></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="modal-footer">
                        <div className="row center-align m-0">
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn white modal-action modal-close w-100">Back to Report page</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Export</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Print</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="modalOrderStatus" className="modal custome-modal modal-fixed-footer modal-large no-tab">
                    <div className="modal-content">
                        <p className="header-title-modal">Open Orders List by Status</p>
                        <div className="tab-content">
                            <div className="row">
                                <div className="col s12">
                                    <table className="striped highlight responsive-table">
                                        <thead>
                                            <tr>
                                                <th>Open Date</th>
                                                <th>Order Number</th>
                                                <th>Closing Date</th>
                                                <th>Title Company</th>
                                                <th>Borrower Last</th>
                                                <th>Type of Transaction</th>
                                                <th>Status</th>
                                                <th>Vender Fee</th>
                                                <th>Client Fee</th>
                                                <th>Appoint Assigned By</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>341334</td>
                                                <td>2017/09/01 13:00:00 EST</td>
                                                <td>Perland Title</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Canceled by customer</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>courtney</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>341334</td>
                                                <td>2017/09/01 13:00:00 EST</td>
                                                <td>Perland Title</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Canceled by customer</td>
                                                <td>110</td>
                                                <td>165</td>

                                                <td>courtney</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>341334</td>
                                                <td>2017/09/01 13:00:00 EST</td>
                                                <td>Perland Title</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Canceled by customer</td>
                                                <td>110</td>
                                                <td>165</td>

                                                <td>courtney</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>341334</td>
                                                <td>2017/09/01 13:00:00 EST</td>
                                                <td>Perland Title</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Canceled by customer</td>
                                                <td>110</td>
                                                <td>165</td>

                                                <td>courtney</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>341334</td>
                                                <td>2017/09/01 13:00:00 EST</td>
                                                <td>Perland Title</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Canceled by customer</td>
                                                <td>110</td>
                                                <td>165</td>

                                                <td>courtney</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>341334</td>
                                                <td>2017/09/01 13:00:00 EST</td>
                                                <td>Perland Title</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Canceled by customer</td>
                                                <td>110</td>
                                                <td>165</td>

                                                <td>courtney</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>341334</td>
                                                <td>2017/09/01 13:00:00 EST</td>
                                                <td>Perland Title</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Canceled by customer</td>
                                                <td>110</td>
                                                <td>165</td>

                                                <td>courtney</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>341334</td>
                                                <td>2017/09/01 13:00:00 EST</td>
                                                <td>Perland Title</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Canceled by customer</td>
                                                <td>110</td>
                                                <td>165</td>

                                                <td>courtney</td>
                                            </tr><tr>
                                                <td>9/1/2017</td>
                                                <td>341334</td>
                                                <td>2017/09/01 13:00:00 EST</td>
                                                <td>Perland Title</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Canceled by customer</td>
                                                <td>110</td>
                                                <td>165</td>

                                                <td>courtney</td>
                                            </tr><tr>
                                                <td>9/1/2017</td>
                                                <td>341334</td>
                                                <td>2017/09/01 13:00:00 EST</td>
                                                <td>Perland Title</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Canceled by customer</td>
                                                <td>110</td>
                                                <td>165</td>

                                                <td>courtney</td>
                                            </tr><tr>
                                                <td>9/1/2017</td>
                                                <td>341334</td>
                                                <td>2017/09/01 13:00:00 EST</td>
                                                <td>Perland Title</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Canceled by customer</td>
                                                <td>110</td>
                                                <td>165</td>

                                                <td>courtney</td>
                                            </tr><tr>
                                                <td>9/1/2017</td>
                                                <td>341334</td>
                                                <td>2017/09/01 13:00:00 EST</td>
                                                <td>Perland Title</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Canceled by customer</td>
                                                <td>110</td>
                                                <td>165</td>

                                                <td>courtney</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="modal-footer">
                        <div className="row center-align m-0">
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn white modal-action modal-close w-100">Back to Report page</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Export</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Print</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        );
    }
}


export default (DailyReport);