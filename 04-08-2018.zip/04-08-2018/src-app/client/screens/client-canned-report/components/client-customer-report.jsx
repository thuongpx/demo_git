import React from "react";
import { Component } from "react";
import DatePicker from "DatePicker";

class CustomerReport extends Component {
    constructor(props) {
        super(props);
    }

    loadScript(src) {
        return new Promise(((resolve, reject) => {
            const script = document.createElement("script");
            script.src = src;
            script.addEventListener("load", () => {
                resolve();
            });
            script.addEventListener("error", (e) => {
                reject(e);
            });
            document.body.appendChild(script);
        }));
    }
    componentDidMount() {

        const doLoadScript = this.loadScript("https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js");
        $(".modal").modal();
        $("select").formSelect();
        $(".select-wrapper").each((i, obj) => {
            if ($(obj).find(".custome-style-select").length !== 0 && $(obj).find(".caret.updown").length === 0) {
                $(obj).find("svg").remove();
                $(obj).append("<span class=\"caret updown\"></span>");
            }
        });

        doLoadScript.then(() => {
            const ctx = document.getElementById("openOrderTrend").getContext("2d");

            const data = {
                labels: ["Altisource", "Data Search Inc.", "Title Source Inc.", "Stewart CTS", "Power Auto Loan", "Other"],
                datasets: [
                    {
                        label: "Jul",
                        backgroundColor: "#769A2A",
                        data: [177, 156, 125, 115, 86, 40]
                    },
                    {
                        label: "Aug",
                        backgroundColor: "#B8D64B",
                        data: [168, 120, 44, 97, 64, 9]
                    },
                    {
                        label: "Sep",
                        backgroundColor: "#c9e26f",
                        data: [90, 18, 60, 190, 69, 45]
                    }
                ]
            };

            this.myBarChart = new Chart(ctx, {
                type: "bar",
                data,

                options: {
                    tooltips: {
                        enabled: false,
                        mode: null
                    },
                    title: {
                        display: true,
                        text: "Open Orders Trend by Customers",
                        padding: 20,
                        fontSize: 14
                    },
                    animation: {
                        onComplete() {


                            const ctx = this.chart.ctx;
                            ctx.textAlign = "center";
                            ctx.textBaseline = "middle";
                            const chart = this;
                            const datasets = this.config.data.datasets;

                            datasets.forEach((dataset, i) => {
                                ctx.font = "14px Poppins";
                                ctx.fillStyle = "#222";
                                chart.getDatasetMeta(i).data.forEach((p, j) => {
                                    ctx.fillText(datasets[i].data[j], p._model.x, p._model.y - 10);
                                });
                            });


                        }
                    },
                    hover: { mode: null },
                    barValueSpacing: 20,
                    scales: {
                        yAxes: [{
                            ticks: {
                                min: 0
                            }
                        }],
                        xAxes: [{
                            ticks: {
                                autoSkip: false
                            }
                        }]
                    }
                }
            });

            const ctx_open_status_customers = document.getElementById("openOrderCustomer").getContext("2d");

            const data1 = {
                labels: ["Altisource", "Data Search Inc.", "Title Source Inc.", "Stewart CTS", "Power Auto Loan", "Other"],
                datasets: [
                    {
                        label: "Closed",
                        backgroundColor: "#769A2A",
                        data: [177, 156, 125, 115, 86, 40]
                    }
                ]
            };

            this.myBarChart1 = new Chart(ctx_open_status_customers, {
                type: "horizontalBar",
                data: data1,

                options: {
                    tooltips: {
                        enabled: false,
                        mode: null
                    },
                    title: {
                        display: true,
                        text: "Open Orders Trend by Customers",
                        padding: 20,
                        fontSize: 14
                    },
                    animation: {
                        onComplete() {


                            const ctx = this.chart.ctx;
                            ctx.textAlign = "center";
                            ctx.textBaseline = "middle";
                            const chart = this;
                            const datasets = this.config.data.datasets;

                            datasets.forEach((dataset, i) => {
                                ctx.font = "14px Poppins";
                                ctx.fillStyle = "#222";
                                chart.getDatasetMeta(i).data.forEach((p, j) => {
                                    ctx.fillText(datasets[i].data[j], p._model.x - 10, p._model.y);
                                });
                            });


                        }
                    },
                    hover: { mode: null },
                    barValueSpacing: 20,
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true,
                                min: 0
                            }
                        }],
                        xAxes: [{
                            ticks: {
                                autoSkip: false,
                                beginAtZero: true,
                                min: 0
                            }
                        }]
                    }
                }
            });

            const ctx2 = document.getElementById("closedOrder").getContext("2d");

            const data2 = {
                labels: ["Altisource", "Data Search Inc.", "Title Source Inc.", "Stewart CTS", "Power Auto Loan", "Other"],
                datasets: [
                    {
                        label: "Jul",
                        backgroundColor: "#769A2A",
                        data: [191, 100, 125, 115, 86, 40]
                    },
                    {
                        label: "Aug",
                        backgroundColor: "#B8D64B",
                        data: [168, 124, 44, 121, 3, 9]
                    },
                    {
                        label: "Sep",
                        backgroundColor: "#c9e26f",
                        data: [177, 90, 60, 22, 100, 45]
                    }
                ]
            };

            this.myBarChart2 = new Chart(ctx2, {
                type: "bar",
                data: data2,

                options: {
                    tooltips: {
                        enabled: false,
                        mode: null
                    },
                    title: {
                        display: true,
                        text: "Closed Orders by Customers",
                        padding: 20,
                        fontSize: 14
                    },
                    animation: {
                        onComplete() {


                            const ctx = this.chart.ctx;
                            ctx.textAlign = "center";
                            ctx.textBaseline = "middle";
                            const chart = this;
                            const datasets = this.config.data.datasets;

                            datasets.forEach((dataset, i) => {
                                ctx.font = "14px Poppins";
                                ctx.fillStyle = "#222";
                                chart.getDatasetMeta(i).data.forEach((p, j) => {
                                    ctx.fillText(datasets[i].data[j], p._model.x, p._model.y - 10);
                                });
                            });


                        }
                    },
                    hover: { mode: null },
                    barValueSpacing: 20,
                    scales: {
                        yAxes: [{
                            ticks: {
                                min: 0
                            }
                        }],
                        xAxes: [{
                            ticks: {
                                autoSkip: false
                            }
                        }]
                    }
                }
            });

            const ctx3 = document.getElementById("customerMiles").getContext("2d");

            const data3 = {
                labels: ["1", "25", "50", "100", "250", "500"],
                datasets: [
                    {
                        backgroundColor: "#769A2A",
                        data: [191, 100, 125, 115, 86, 40]
                    }
                ]
            };

            this.myBarChart3 = new Chart(ctx3, {
                type: "bar",
                data: data3,

                options: {
                    tooltips: {
                        enabled: false,
                        mode: null
                    },
                    title: {
                        display: true,
                        text: "Customer Milestones",
                        padding: 20,
                        fontSize: 14
                    },
                    animation: {
                        onComplete() {


                            const ctx = this.chart.ctx;
                            ctx.textAlign = "center";
                            ctx.textBaseline = "middle";
                            const chart = this;
                            const datasets = this.config.data.datasets;

                            datasets.forEach((dataset, i) => {
                                ctx.font = "14px Poppins";
                                ctx.fillStyle = "#222";
                                chart.getDatasetMeta(i).data.forEach((p, j) => {
                                    ctx.fillText(datasets[i].data[j], p._model.x, p._model.y - 10);
                                });
                            });


                        }
                    },
                    legend: {
                        display: false
                    },
                    hover: { mode: null },
                    barValueSpacing: 20,
                    scales: {
                        yAxes: [{
                            ticks: {
                                min: 0
                            }
                        }],
                        xAxes: [{
                            barPercentage: 0.4,
                            ticks: {
                                autoSkip: false
                            }
                        }]
                    }
                }
            });
        });
    }

    shuffleArray(array) {
        let i = array.length - 1;
        for (; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            const temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        return array;
    }

    reRenderGraph(grap) {
        switch (grap) {
            case "openOrder":

                for (var i = 0; i < this.myBarChart1.config.data.datasets.length; i++) {
                    this.myBarChart1.config.data.datasets[i].data = this.shuffleArray(this.myBarChart1.config.data.datasets[i].data);
                }
                this.myBarChart1.update();
                break;

            case "openOrderTrend":


                for (var i = 0; i < this.myBarChart.config.data.datasets.length; i++) {
                    this.myBarChart.config.data.datasets[i].data = this.shuffleArray(this.myBarChart.config.data.datasets[i].data);
                }
                this.myBarChart.update();
                break;

            case "closedOrder":
                for (var i = 0; i < this.myBarChart3.config.data.datasets.length; i++) {
                    this.myBarChart3.config.data.datasets[i].data = this.shuffleArray(this.myBarChart3.config.data.datasets[i].data);
                }
                for (var i = 0; i < this.myBarChart2.config.data.datasets.length; i++) {
                    this.myBarChart2.config.data.datasets[i].data = this.shuffleArray(this.myBarChart2.config.data.datasets[i].data);
                }

                this.myBarChart3.update();
                this.myBarChart2.update();

                break;

            default:
                break;
        }
    }

    render() {
        return (
            <div>
                <div className="row">
                    <div className="col s12 m6">
                        <blockquote className="title-quote">
                            Open Orders by Customers
                                        </blockquote>

                        <div className="row">
                            <div className="col s12 m3 l3">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="1" selected>Stewart CTS</option>
                                    </select>
                                    <label>Customer</label>
                                </div></div>

                            <div className="col s12 m3 l3">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="1">Open</option>
                                        <option value="2">Auto Assign</option>
                                        <option value="3">Assigned to Vendor</option>
                                        <option value="">Appt Confirmed</option>
                                        <option value="">Pending Pre-call</option>
                                        <option value="">Appt Ready</option>
                                        <option value="">Closed Pending Review</option>
                                        <option value="">Closed Pending QC Review</option>
                                        <option value="">Closed Pending Client Review</option>
                                        <option value="">Closing Completed</option>
                                        <option value="">Hold</option>
                                        <option value="">Canceled</option>
                                    </select>
                                    <label>Order Status</label>
                                </div>
                            </div>
                            <div className="col s12 m3 l3">
                                <div className="input-field">
                                    <DatePicker
                                        id="dailyCounterReportDate"
                                        inputFormat="MM/DD/YYYY"
                                        labelText="Date"
                                    />
                                </div>
                            </div>
                            <div className="col s12 m3 l3 mt-2">
                                <button type="button" className="btn success-color w-100 btn-small" onClick={() => this.reRenderGraph("openOrder")}> Apply</button>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12">
                                <canvas id="openOrderCustomer" width="100%" className="modal-trigger" data-target="modalOrderCustomerStatus" style={{ cursor: "pointer" }}></canvas>
                            </div>
                        </div>
                    </div>

                    <div className="col s12 m6">
                        <blockquote className="title-quote">
                            Open Orders Trend by Customers
                                        </blockquote>

                        <div className="row">
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="1" selected>Stewart CTS</option>
                                    </select>
                                    <label>Customer</label>
                                </div></div>

                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>1</option>
                                    </select>
                                    <label>Day From</label>
                                </div>
                            </div>
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>31</option>
                                    </select>
                                    <label>Day To</label>
                                </div>
                            </div>
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>Sep, Aug, Jul</option>
                                    </select>
                                    <label>Month</label>
                                </div>
                            </div>
                            <div className="col s12 m3 l3 mt-2 offset-m1 right">
                                <button type="button" className="btn success-color w-100 btn-small" onClick={() => this.reRenderGraph("openOrderTrend")}> Apply</button>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12">
                                <canvas id="openOrderTrend" width="100%"></canvas>
                            </div>
                        </div>
                    </div>

                </div>

                <div className="row">
                    <div className="col s12 m6 l6">
                        <blockquote className="title-quote">
                            Closed Orders by Customers
                                        </blockquote>

                        <div className="row">
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="1" selected>Top 10 and</option>
                                    </select>
                                    <label>Customer</label>
                                </div></div>

                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>1</option>
                                    </select>
                                    <label>Day From</label>
                                </div>
                            </div>
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>31</option>
                                    </select>
                                    <label>Day To</label>
                                </div>
                            </div>
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>Sep, Aug, Jul</option>
                                    </select>
                                    <label>Month</label>
                                </div>
                            </div>
                            <div className="col s12 m3 l3 mt-2 offset-m1 right">
                                <button type="button" className="btn success-color w-100 btn-small" onClick={() => this.reRenderGraph("closedOrder")}> Apply</button>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12">
                                <canvas id="closedOrder" width="100%" className="modal-trigger" data-target="modalClosedOrders" style={{ cursor: "pointer" }}></canvas>
                            </div>
                        </div>
                    </div>

                    <div className="col s12 m6 l6">
                        <blockquote className="title-quote">
                            Customer Milestones
                                        </blockquote>

                        <div className="row">
                            <div className="col s12 m2 l2 opacity-0">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="1" selected></option>
                                    </select>
                                    <label>hidden</label>
                                </div></div>
                        </div>
                        <div className="row">
                            <div className="col s12">
                                <canvas id="customerMiles" width="100%" className="modal-trigger" data-target="modalCustomerMiles" style={{ cursor: "pointer" }}></canvas>
                            </div>
                        </div>
                    </div>

                </div>

                <div id="modalOrderCustomerStatus" className="modal custome-modal modal-fixed-footer modal-large no-tab">
                    <div className="modal-content">
                        <p className="header-title-modal">Open Orders List by Customers and Status</p>
                        <div className="tab-content">
                            <div className="row">
                                <div className="col s12">
                                    <table className="striped highlight responsive-table">
                                        <thead>
                                            <tr>
                                                <th>Customer</th>
                                                <th>Open Orders</th>
                                                <th>Previous Month +/-</th>
                                                <th>Closed</th>
                                                <th>Pending</th>
                                                <th>Canceled</th>
                                                <th>Cancellation Percentage</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Title Source Inc.</td>
                                                <td>18</td>
                                                <td>18</td>
                                                <td>8</td>
                                                <td>2</td>
                                                <td>1</td>
                                                <td></td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="modal-footer">
                        <div className="row center-align m-0">
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn white modal-action modal-close w-100">Back to Report page</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Export</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Print</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="modalClosedOrders" className="modal custome-modal modal-fixed-footer modal-large no-tab">
                    <div className="modal-content">
                        <p className="header-title-modal">Closed Orders List by Customers</p>
                        <div className="tab-content">
                            <div className="row">
                                <div className="col s12">
                                    <table className="striped highlight responsive-table">
                                        <thead>
                                            <tr>
                                                <th>Customer</th>
                                                <th>Closed Orders</th>
                                                <th>Previous Month +/-</th>
                                                <th>Cancelled Orders</th>
                                                <th>Previous Month +/-</th>

                                                <th>Vendor Fees</th>
                                                <th>Client Fees</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Altisource</td>
                                                <td>9</td>
                                                <td></td>
                                                <td>1</td>

                                                <td>116</td>
                                                <td>91</td>
                                                <td>25</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="modal-footer">
                        <div className="row center-align m-0">
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn white modal-action modal-close w-100">Back to Report page</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Export</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Print</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="modalCustomerMiles" className="modal custome-modal modal-fixed-footer modal-large no-tab">
                    <div className="modal-content">
                        <p className="header-title-modal">Customers Milestones</p>
                        <div className="tab-content">
                            
                        </div>

                    </div>
                    <div className="modal-footer">
                        <div className="row center-align m-0">
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn white modal-action modal-close w-100">Back to Report page</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Export</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Print</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}


export default (CustomerReport);