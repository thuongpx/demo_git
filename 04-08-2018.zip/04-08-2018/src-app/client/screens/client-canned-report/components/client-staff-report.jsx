import React from "react";
import { Component } from "react";
import DatePicker from "DatePicker";

class StaffReport extends Component {
    constructor(props) {
        super(props);
    }

    loadScript(src) {
        return new Promise(((resolve, reject) => {
            const script = document.createElement("script");
            script.src = src;
            script.addEventListener("load", () => {
                resolve();
            });
            script.addEventListener("error", (e) => {
                reject(e);
            });
            document.body.appendChild(script);
        }));
    }
    componentDidMount() {

        const doLoadScript = this.loadScript("https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js");
        $(".modal").modal();
        $("select").formSelect();
        $(".select-wrapper").each((i, obj) => {
            if ($(obj).find(".custome-style-select").length !== 0 && $(obj).find(".caret.updown").length === 0) {
                $(obj).find("svg").remove();
                $(obj).append("<span class=\"caret updown\"></span>");
            }
        });

        doLoadScript.then(() => {
            const ctx = document.getElementById("assignedOrderScheduler").getContext("2d");

            const data = {
                labels: ["Celiza", "Rashida Coles", "Luke Vafiades", "Jacque line Anderson", "Marc Kroll", "Theodore Zanardelli",
                    "Cynthia Munson", "Marwa Mohamood"],
                datasets: [
                    {
                        label: "Jul",
                        backgroundColor: "#769A2A",
                        data: [448, 448, 424, 357, 347, 347, 346, 346]
                    },
                    {
                        label: "Aug",
                        backgroundColor: "#B8D64B",
                        data: [305, 179, 129, 130, 127, 127, 127, 205]
                    },
                    {
                        label: "Sep",
                        backgroundColor: "#c9e26f",
                        data: [360, 234, 203, 184, 182, 182, 182, 260]
                    }
                ]
            };

            this.myBarChart = new Chart(ctx, {
                type: "bar",
                data,

                options: {
                    tooltips: {
                        enabled: false,
                        mode: null
                    },
                    title: {
                        display: true,
                        text: "Assigned Orders by Schedulers",
                        padding: 20,
                        fontSize: 14
                    },
                    animation: {
                        onComplete() {


                            const ctx = this.chart.ctx;
                            ctx.textAlign = "center";
                            ctx.textBaseline = "middle";
                            const chart = this;
                            const datasets = this.config.data.datasets;

                            datasets.forEach((dataset, i) => {
                                ctx.font = "14px Poppins";
                                ctx.fillStyle = "#222";
                                chart.getDatasetMeta(i).data.forEach((p, j) => {
                                    ctx.fillText(datasets[i].data[j], p._model.x, p._model.y - 10);
                                });
                            });


                        }
                    },
                    hover: { mode: null },
                    barValueSpacing: 20,
                    scales: {
                        yAxes: [{
                            ticks: {
                                min: 0
                            }
                        }],
                        xAxes: [{
                            ticks: {
                                autoSkip: false
                            }
                        }]
                    }
                }
            });
        });
    }

    shuffleArray(array) {
        let i = array.length - 1;
        for (; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            const temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        return array;
    }

    reRenderGraphStaff() {

        for (var i = 0; i < this.myBarChart.config.data.datasets.length; i++) {
            this.myBarChart.config.data.datasets[i].data = this.shuffleArray(this.myBarChart.config.data.datasets[i].data);
        }
        this.myBarChart.update();
    }

    render() {
        return (
            <div>
                <div className="row">
                    <div className="col s12 m12">
                        <blockquote className="title-quote">
                            Assigned Orders by Schedulers
                                        </blockquote>

                        <div className="row">
                            <div className="col s12 m6 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="1" selected>All</option>
                                    </select>
                                    <label>Scheduler</label>
                                </div></div>
                            <div className="col s12 m6 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="1" selected>Application</option>
                                        <option value="">Purchase</option>
                                        <option value="">Seller Side Purchase (Sale)</option>
                                        <option value="">Refinance</option>
                                        <option value="">Second Mortgage</option>
                                        <option value="">HELOC</option>
                                        <option value="">Deed In Lieu</option>
                                        <option value="">Quit Claim</option>
                                        <option value="">Disclosure</option>
                                        <option value="">Deed Only</option>
                                        <option value="">Note/Loan Modification</option>
                                        <option value="">Investment Purchase</option>
                                        <option value="">Investment Refinance</option>
                                    </select>
                                    <label>Order Type</label>
                                </div></div>
                            <div className="col s12 m6 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>1</option>
                                    </select>
                                    <label>Day From</label>
                                </div>
                            </div>
                            <div className="col s12 m6 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>31</option>
                                    </select>
                                    <label>Day To</label>
                                </div>
                            </div>
                            <div className="col s12 m6 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>Sep, Aug, Jul</option>
                                    </select>
                                    <label>Month</label>
                                </div>
                            </div>
                            <div className="col s12 m6 l2 mt-2">
                                <button type="button" className="btn success-color w-100 btn-small" onClick={() => this.reRenderGraphStaff()}> Apply</button>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12 m8 offset-m2">
                                <canvas id="assignedOrderScheduler" width="100%" className="modal-trigger" data-target="modalAssignOrder" style={{ cursor: "pointer" }}></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="modalAssignOrder" className="modal custome-modal modal-fixed-footer modal-large no-tab">
                    <div className="modal-content">
                        <p className="header-title-modal">Assigned Orders List by Schedulers</p>
                        <div className="tab-content">
                            <div className="row">
                                <div className="col s12">
                                    <table className="striped highlight responsive-table">
                                        <thead>
                                            <tr>
                                                <th>Open Date</th>
                                                <th>Title Company</th>
                                                <th>Order Number</th>
                                                <th>Borrower Last</th>
                                                <th>Type of Transaction</th>
                                                <th>Status</th>
                                                <th>Vender Fee</th>
                                                <th>Client Fee</th>
                                                <th>Scheduler</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                            <tr>
                                                <td>9/1/2017</td>
                                                <td>Perland Title & Escrow Services</td>
                                                <td>5234524</td>
                                                <td>Lengel</td>
                                                <td>Cash (Seller Only)</td>
                                                <td>Closed</td>
                                                <td>110</td>
                                                <td>165</td>
                                                <td>Celiza Barba</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="modal-footer">
                        <div className="row center-align m-0">
                            <div className="col s4">
                                <button type="button" className="btn white modal-action modal-close w-100">Back to Report page</button>
                            </div>
                            <div className="col s4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Export</button>
                            </div>
                            <div className="col s4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Print</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        );
    }
}


export default (StaffReport);