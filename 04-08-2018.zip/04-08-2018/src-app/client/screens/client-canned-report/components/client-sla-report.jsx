import React from "react";
import { Component } from "react";

class SLAReport extends Component {
    constructor(props) {
        super(props);
    }

    loadScript(src) {
        return new Promise(((resolve, reject) => {
            const script = document.createElement("script");
            script.src = src;
            script.addEventListener("load", () => {
                resolve();
            });
            script.addEventListener("error", (e) => {
                reject(e);
            });
            document.body.appendChild(script);
        }));
    }
    componentDidMount() {

        const doLoadScript = this.loadScript("https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js");
        $(".modal").modal();
        $("select").formSelect();
        $(".select-wrapper").each((i, obj) => {
            if ($(obj).find(".custome-style-select").length !== 0 && $(obj).find(".caret.updown").length === 0) {
                $(obj).find("svg").remove();
                $(obj).append("<span class=\"caret updown\"></span>");
            }
        });

        const elem = document.querySelector(".collapsible.expandable");
        const instance = M.Collapsible.init(elem, {
            accordion: false
        });

        doLoadScript.then(() => {
            const ctx = document.getElementById("sla").getContext("2d");

            const data = {
                labels: ["Aug SLA1", "Sep SLA1", "Aug SLA2", "Sep SLA2", "Aug SLA1", "Sep SLA3", "Aug SLA4", "Sep SLA4"],
                datasets: [
                    {
                        label: "Within SLA",
                        backgroundColor: "#B8D64B",
                        data: [100, 220, 60, 80, 124, 215, 107]
                    },
                    {
                        label: "Not Within SLA",
                        backgroundColor: "#ea6d6d",
                        data: [0, 4, 0, 0, 15, 18, 1, 12]
                    }
                ]
            };

            this.myBarChart = new Chart(ctx, {
                type: "bar",
                data,

                options: {
                    tooltips: {
                        enabled: false,
                        mode: null
                    },
                    title: {
                        display: true,
                        text: "SLAs",
                        padding: 20,
                        fontSize: 14
                    },
                    animation: {
                        onComplete() {


                            const ctx = this.chart.ctx;
                            ctx.textAlign = "center";
                            ctx.textBaseline = "middle";
                            const chart = this;
                            const datasets = this.config.data.datasets;

                            datasets.forEach((dataset, i) => {
                                ctx.font = "14px Poppins";
                                ctx.fillStyle = "#222";
                                chart.getDatasetMeta(i).data.forEach((p, j) => {
                                    ctx.fillText(datasets[i].data[j], p._model.x, p._model.y - 10);
                                });
                            });


                        }
                    },
                    hover: { mode: null },
                    barValueSpacing: 20,
                    scales: {
                        yAxes: [{
                            ticks: {
                                min: 0
                            }
                        }],
                        xAxes: [{
                            ticks: {
                                autoSkip: false
                            }
                        }]
                    }
                }
            });
        });
    }

    shuffleArray(array) {
        let i = array.length - 1;
        for (; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            const temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        return array;
    }

    reRenderGraphStaff() {

        for (var i = 0; i < this.myBarChart.config.data.datasets.length; i++) {
            this.myBarChart.config.data.datasets[i].data = this.shuffleArray(this.myBarChart.config.data.datasets[i].data);
        }
        this.myBarChart.update();
    }

    render() {
        return (
            <div>
                <div className="row">
                    <div className="col s12 m12">
                        <blockquote className="title-quote">
                            SLAs
                                        </blockquote>

                        <div className="row">
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>Schedulers</option>
                                    </select>
                                    <label>Filter by</label>
                                </div>
                            </div>
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>All</option>
                                    </select>
                                    <label>Name</label>
                                </div>
                            </div>
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>1</option>
                                    </select>
                                    <label>Day From</label>
                                </div>
                            </div>
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>31</option>
                                    </select>
                                    <label>Day To</label>
                                </div>
                            </div>
                            <div className="col s12 m2 l2">
                                <div className="input-field">
                                    <select className="custome-style-select">
                                        <option value="" selected>October</option>
                                    </select>
                                    <label>Month</label>
                                </div>
                            </div>

                            <div className="col s6 m1 l1 mt-2">
                                <button type="button" className="btn success-color w-100 btn-small" onClick={() => this.reRenderGraphStaff()}> Search</button>
                            </div>
                            <div className="col s6 m1 l1 mt-2">
                                <button type="button" className="btn success-color w-100 btn-small"> Reset</button>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s12 m8 offset-m2">
                                <canvas id="sla" width="100%" className="modal-trigger" data-target="modalFeeRequest" style={{ cursor: "pointer" }}></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="modalFeeRequest" className="modal custome-modal modal-fixed-footer modal-large no-tab">
                    <div className="modal-content">
                        <p className="header-title-modal">SLAs</p>
                        <div className="tab-content">
                            <div className="row">
                                <div className="col s12">
                                    <ul className="collapsible expandable" style={{ border: "none", boxShadow: "none" }}>
                                        <li className="wrap-alert box-shadow-none m-0 active">
                                            <div className="title-wrap-alert green-color font-13 collapsible-header" style={{ display: "block" }}>Closing Date is lower than Closing Docs Executed
                                        <span className="font-12 right sla-result-total"><strong>Total:</strong> <span className="green-color">202</span> - <strong>% Within SLA Avg:</strong> <span className="green-color">100.00%</span> -<strong> Business Hours:</strong> <span className="green-color">3.52</span></span>
                                            </div>
                                            <div className="sla-item collapsible-body mt-1">
                                                <div className="row">
                                                    <div className="col s12 m2 l2">
                                                        <p className="orderIdd">Order </p>
                                                        <span>465246</span>
                                                        <p>Loan # </p>
                                                        <span>12312312</span>
                                                        <p>Notary Name </p>
                                                        <span>MiMi Notary</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>City  </p>
                                                        <span>Da Nang</span>
                                                        <p>State </p>
                                                        <span>Mien Trung</span>
                                                        <p>Borrower </p>
                                                        <span>Thuy Borr</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Vendor Assigned Date  </p>
                                                        <span>02/03/2018</span>
                                                        <p>Scheduling Confirmation</p>
                                                        <span> 02/03/2018</span>
                                                        <p>Closing Date </p>
                                                        <span>05/03/2018</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Closing Doc Executed </p>
                                                        <span>3</span>
                                                        <p>Incoming Fax Rec</p>
                                                        <span>5</span>
                                                        <p>Document Signing Verified</p>
                                                        <span>2</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Bus Days</p>
                                                        <span>12</span>
                                                        <p>Bus Hrs</p>
                                                        <span>3</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Employee</p>
                                                        <span>1233</span>
                                                        <p>Team</p>
                                                        <span>10</span>
                                                        <p>Customer</p>
                                                        <span>2</span>
                                                    </div>
                                                </div>

                                                <div className="row">
                                                    <div className="col s12 m2 l2">
                                                        <p className="orderIdd">Order </p>
                                                        <span>465246</span>
                                                        <p>Loan # </p>
                                                        <span>12312312</span>
                                                        <p>Notary Name </p>
                                                        <span>MiMi Notary</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>City  </p>
                                                        <span>Da Nang</span>
                                                        <p>State </p>
                                                        <span>Mien Trung</span>
                                                        <p>Borrower </p>
                                                        <span>Thuy Borr</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Vendor Assigned Date  </p>
                                                        <span>02/03/2018</span>
                                                        <p>Scheduling Confirmation</p>
                                                        <span> 02/03/2018</span>
                                                        <p>Closing Date </p>
                                                        <span>05/03/2018</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Closing Doc Executed </p>
                                                        <span>3</span>
                                                        <p>Incoming Fax Rec</p>
                                                        <span>5</span>
                                                        <p>Document Signing Verified</p>
                                                        <span>2</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Bus Days</p>
                                                        <span>12</span>
                                                        <p>Bus Hrs</p>
                                                        <span>3</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Employee</p>
                                                        <span>1233</span>
                                                        <p>Team</p>
                                                        <span>10</span>
                                                        <p>Customer</p>
                                                        <span>2</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li className="wrap-alert box-shadow-none m-0">
                                            <div className="title-wrap-alert green-color font-13 collapsible-header" style={{ display: "block" }}>Closing Date is greater than Receipt of Fax Back
                                        <span className="font-12 right sla-result-total"><strong>Total:</strong> <span className="green-color">62</span> - <strong>% Within SLA Avg:</strong> <span className="green-color">100.00%</span> -<strong> Business Hours:</strong> <span className="green-color">3.90</span></span>
                                            </div>
                                            <div className="sla-item collapsible-body mt-1">
                                                <div className="row">
                                                    <div className="col s12 m2 l2">
                                                        <p className="orderIdd">Order </p>
                                                        <span>465246</span>
                                                        <p>Loan # </p>
                                                        <span>12312312</span>
                                                        <p>Notary Name </p>
                                                        <span>MiMi Notary</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>City  </p>
                                                        <span>Da Nang</span>
                                                        <p>State </p>
                                                        <span>Mien Trung</span>
                                                        <p>Borrower </p>
                                                        <span>Thuy Borr</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Vendor Assigned Date  </p>
                                                        <span>02/03/2018</span>
                                                        <p>Scheduling Confirmation</p>
                                                        <span> 02/03/2018</span>
                                                        <p>Closing Date </p>
                                                        <span>05/03/2018</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Closing Doc Executed </p>
                                                        <span>3</span>
                                                        <p>Incoming Fax Rec</p>
                                                        <span>5</span>
                                                        <p>Document Signing Verified</p>
                                                        <span>2</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Bus Days</p>
                                                        <span>12</span>
                                                        <p>Bus Hrs</p>
                                                        <span>3</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Employee</p>
                                                        <span>1233</span>
                                                        <p>Team</p>
                                                        <span>10</span>
                                                        <p>Customer</p>
                                                        <span>2</span>
                                                    </div>
                                                </div>

                                                <div className="row">
                                                    <div className="col s12 m2 l2">
                                                        <p className="orderIdd">Order </p>
                                                        <span>465246</span>
                                                        <p>Loan # </p>
                                                        <span>12312312</span>
                                                        <p>Notary Name </p>
                                                        <span>MiMi Notary</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>City  </p>
                                                        <span>Da Nang</span>
                                                        <p>State </p>
                                                        <span>Mien Trung</span>
                                                        <p>Borrower </p>
                                                        <span>Thuy Borr</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Vendor Assigned Date  </p>
                                                        <span>02/03/2018</span>
                                                        <p>Scheduling Confirmation</p>
                                                        <span> 02/03/2018</span>
                                                        <p>Closing Date </p>
                                                        <span>05/03/2018</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Closing Doc Executed </p>
                                                        <span>3</span>
                                                        <p>Incoming Fax Rec</p>
                                                        <span>5</span>
                                                        <p>Document Signing Verified</p>
                                                        <span>2</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Bus Days</p>
                                                        <span>12</span>
                                                        <p>Bus Hrs</p>
                                                        <span>3</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Employee</p>
                                                        <span>1233</span>
                                                        <p>Team</p>
                                                        <span>10</span>
                                                        <p>Customer</p>
                                                        <span>2</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li className="wrap-alert box-shadow-none m-0">
                                            <div className="title-wrap-alert green-color font-13 collapsible-header" style={{ display: "block" }}>Closing Date is greater than Closing Docs Executed
                                        <span className="font-12 right sla-result-total"><strong>Total:</strong> <span className="green-color">214</span> - <strong>% Within SLA Avg:</strong> <span className="green-color">100.00%</span> -<strong> Business Hours:</strong> <span className="green-color">21.57</span></span>
                                            </div>
                                            <div className="sla-item collapsible-body mt-1">
                                                <div className="row">
                                                    <div className="col s12 m2 l2">
                                                        <p className="orderIdd">Order </p>
                                                        <span>465246</span>
                                                        <p>Loan # </p>
                                                        <span>12312312</span>
                                                        <p>Notary Name </p>
                                                        <span>MiMi Notary</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>City  </p>
                                                        <span>Da Nang</span>
                                                        <p>State </p>
                                                        <span>Mien Trung</span>
                                                        <p>Borrower </p>
                                                        <span>Thuy Borr</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Vendor Assigned Date  </p>
                                                        <span>02/03/2018</span>
                                                        <p>Scheduling Confirmation</p>
                                                        <span> 02/03/2018</span>
                                                        <p>Closing Date </p>
                                                        <span>05/03/2018</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Closing Doc Executed </p>
                                                        <span>3</span>
                                                        <p>Incoming Fax Rec</p>
                                                        <span>5</span>
                                                        <p>Document Signing Verified</p>
                                                        <span>2</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Bus Days</p>
                                                        <span>12</span>
                                                        <p>Bus Hrs</p>
                                                        <span>3</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Employee</p>
                                                        <span>1233</span>
                                                        <p>Team</p>
                                                        <span>10</span>
                                                        <p>Customer</p>
                                                        <span>2</span>
                                                    </div>
                                                </div>

                                                <div className="row">
                                                    <div className="col s12 m2 l2">
                                                        <p className="orderIdd">Order </p>
                                                        <span>465246</span>
                                                        <p>Loan # </p>
                                                        <span>12312312</span>
                                                        <p>Notary Name </p>
                                                        <span>MiMi Notary</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>City  </p>
                                                        <span>Da Nang</span>
                                                        <p>State </p>
                                                        <span>Mien Trung</span>
                                                        <p>Borrower </p>
                                                        <span>Thuy Borr</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Vendor Assigned Date  </p>
                                                        <span>02/03/2018</span>
                                                        <p>Scheduling Confirmation</p>
                                                        <span> 02/03/2018</span>
                                                        <p>Closing Date </p>
                                                        <span>05/03/2018</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Closing Doc Executed </p>
                                                        <span>3</span>
                                                        <p>Incoming Fax Rec</p>
                                                        <span>5</span>
                                                        <p>Document Signing Verified</p>
                                                        <span>2</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Bus Days</p>
                                                        <span>12</span>
                                                        <p>Bus Hrs</p>
                                                        <span>3</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Employee</p>
                                                        <span>1233</span>
                                                        <p>Team</p>
                                                        <span>10</span>
                                                        <p>Customer</p>
                                                        <span>2</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li className="wrap-alert box-shadow-none m-0">
                                            <div className="title-wrap-alert green-color font-13 collapsible-header" style={{ display: "block" }}>Vendor Assigned to Borrower Scheduling Confirmation
                                        <span className="font-12 right sla-result-total"><strong>Total:</strong> <span className="green-color">225</span> - <strong>% Within SLA Avg:</strong> <span className="green-color">100.00%</span> -<strong> Business Hours:</strong> <span className="green-color">0.93</span></span>
                                            </div>
                                            <div className="sla-item collapsible-body mt-1">
                                                <div className="row">
                                                    <div className="col s12 m2 l2">
                                                        <p className="orderIdd">Order </p>
                                                        <span>465246</span>
                                                        <p>Loan # </p>
                                                        <span>12312312</span>
                                                        <p>Notary Name </p>
                                                        <span>MiMi Notary</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>City  </p>
                                                        <span>Da Nang</span>
                                                        <p>State </p>
                                                        <span>Mien Trung</span>
                                                        <p>Borrower </p>
                                                        <span>Thuy Borr</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Vendor Assigned Date  </p>
                                                        <span>02/03/2018</span>
                                                        <p>Scheduling Confirmation</p>
                                                        <span> 02/03/2018</span>
                                                        <p>Closing Date </p>
                                                        <span>05/03/2018</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Closing Doc Executed </p>
                                                        <span>3</span>
                                                        <p>Incoming Fax Rec</p>
                                                        <span>5</span>
                                                        <p>Document Signing Verified</p>
                                                        <span>2</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Bus Days</p>
                                                        <span>12</span>
                                                        <p>Bus Hrs</p>
                                                        <span>3</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Employee</p>
                                                        <span>1233</span>
                                                        <p>Team</p>
                                                        <span>10</span>
                                                        <p>Customer</p>
                                                        <span>2</span>
                                                    </div>
                                                </div>

                                                <div className="row">
                                                    <div className="col s12 m2 l2">
                                                        <p className="orderIdd">Order </p>
                                                        <span>465246</span>
                                                        <p>Loan # </p>
                                                        <span>12312312</span>
                                                        <p>Notary Name </p>
                                                        <span>MiMi Notary</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>City  </p>
                                                        <span>Da Nang</span>
                                                        <p>State </p>
                                                        <span>Mien Trung</span>
                                                        <p>Borrower </p>
                                                        <span>Thuy Borr</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Vendor Assigned Date  </p>
                                                        <span>02/03/2018</span>
                                                        <p>Scheduling Confirmation</p>
                                                        <span> 02/03/2018</span>
                                                        <p>Closing Date </p>
                                                        <span>05/03/2018</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Closing Doc Executed </p>
                                                        <span>3</span>
                                                        <p>Incoming Fax Rec</p>
                                                        <span>5</span>
                                                        <p>Document Signing Verified</p>
                                                        <span>2</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Bus Days</p>
                                                        <span>12</span>
                                                        <p>Bus Hrs</p>
                                                        <span>3</span>
                                                    </div>
                                                    <div className="col s12 m2 l2">
                                                        <p>Employee</p>
                                                        <span>1233</span>
                                                        <p>Team</p>
                                                        <span>10</span>
                                                        <p>Customer</p>
                                                        <span>2</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="modal-footer">
                        <div className="row center-align m-0">
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn white modal-action modal-close w-100">Back to Report page</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Export</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button type="button" className="btn modal-action modal-close w-100 success-color">Print</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        );
    }
}


export default (SLAReport);