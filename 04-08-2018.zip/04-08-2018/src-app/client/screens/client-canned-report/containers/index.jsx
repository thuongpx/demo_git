import React from "react";
import { Component } from "react";
import { getCookies, setCookies } from "../../../helpers/cookies-helper";
import DailyReport from "./../components/client-daily-report";
import StaffReport from "./../components/client-staff-report";
import CustomerReport from "./../components/client-customer-report";
import ManualReport from "./../components/client-manual-report";
import SLAReport from "./../components/client-sla-report";
import EconomicReport from "./../components/client-eco-report";

class ClientCannedReport extends Component {
    constructor(props, defaultProps) {
        super(props, defaultProps);
        const tabs = [
            {
                title: "Daily Report",
                component: DailyReport
            },
            {
                title: "Staff Report",
                component: StaffReport
            },
            {
                title: "Customer Report",
                component: CustomerReport
            },
            {
                title: "Economics Report",
                component: EconomicReport
            },
            {
                title: "Manual Report",
                component: ManualReport
            },
            {
                title: "SLA",
                component: SLAReport
            }];
        //find active tab
        const currentTabIndex = getCookies(this.cookieKey) ? +getCookies(this.cookieKey) : 0;

        this.state = {
            tabs,
            currentTabIndex
        };
    }

    handleTabClick(tabIndex) {
        if (this.currentTabRef.validateForm && this.currentTabRef.saveChanges) {
            const validateForm = this.currentTabRef.validateForm();

            if (!validateForm) {
                return;
            }

            this.currentTabRef.saveChanges(false, () => this.setActiveTab(tabIndex));
        }

        this.setActiveTab(tabIndex);
    }

    setActiveTab(currentTabIndex) {
        setCookies(this.cookieKey, currentTabIndex); // set cookie to get and set active tab after reload
        this.setState({ currentTabIndex });
    }

    renderTabs() {
        const { tabs, currentTabIndex } = this.state;

        return tabs.map((tab, key) => {
            const classNameActive = (key === currentTabIndex) ? "active" : "";

            return (
                <li className="tab col s6 m6 l6" key={key}
                    onClick={() => { this.handleTabClick(key); }}
                >
                    <a className={classNameActive} style={{ cursor: "pointer" }}>{tab.title}</a>
                </li>
            );
        });
    }

    renderTabContent() {
        const { tabs, currentTabIndex } = this.state;
        const TabComponent = tabs[currentTabIndex].component;

        return (
            <TabComponent
                ref={instance => {
                    if (instance) {
                        this.currentTabRef = instance.getWrappedInstance ? instance.getWrappedInstance() : instance;
                    }
                }}
            />
        );
    }

    render() {

        return (
            <div className="row">
                <div className="col s12"><h3 className="title-page-detail">CE Staff Report</h3></div>
                <div className="col s12">
                    <div className="custome-modal">
                        <ul className="tabs">
                            {this.renderTabs()}
                        </ul>

                        <div>
                            {this.renderTabContent()}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default ClientCannedReport;