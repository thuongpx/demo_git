import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import GridView from "GridView";
import AgentUpSertModal from "../components/agent-upsert-modal";
import { getAgentsList, setAgentSearchCriteria, startToggleAgentUpSertModal, setControllInactiveAgent, setGridViewCriteria } from "../actions/agent-management-action";
import CommonModal from "CommonModal";
import NumbericInput from "NumbericInput";
import { updateTextFields } from "../../../helpers/theme-helper";

const redirectRoute = () => `/`;

class AgentManagement extends Component {

    constructor(props) {
        super(props);
        this.state = {
            agentId: ""
        };
    }

    componentDidMount() {
        const { dispatch, brokerId, criteria, roleNames } = this.props;
        let isAccess = false;

        for (const key in roleNames) {
            if (roleNames[key] === "Client" || roleNames[key] === "Branch") {
                isAccess = true;
            }
        }

        if (isAccess) {
            dispatch(getAgentsList({ ...criteria, brokerId }));
        } else {
            this.props.router.push(redirectRoute());
        }
    }

    searchButtonClick(event) {
        event.preventDefault();

        const { dispatch, criteria, brokerId } = this.props;
        dispatch(setAgentSearchCriteria({ ...criteria, page: 1 }));
        dispatch(getAgentsList({ ...criteria, page: 1, brokerId }));
    }

    handleOnBlur(e) {
        const { name, value } = e.target;
        const { dispatch, criteria } = this.props;

        dispatch(setAgentSearchCriteria({ ...criteria, [name]: value }));
    }

    handleAgentIdOnBlur(value) {
        const { dispatch, criteria } = this.props;

        dispatch(setAgentSearchCriteria({ ...criteria, agentId: value }));
    }

    handleGridViewReload(newCriteria) {
        const { dispatch, criteria, brokerId } = this.props;

        dispatch(setGridViewCriteria({ ...criteria, ...newCriteria, brokerId }));
    }

    handleGridViewActionClick(action, identifier) {
        const { dispatch, brokerId } = this.props;
        switch (action) {
            case "Edit":
                dispatch(startToggleAgentUpSertModal(true, identifier, brokerId));
                break;

            case "Disable":
                {
                    this.commonModal.showModal({
                        type: "confirm",
                        message: `Are you sure you would like to disable this Agent?`
                    }, () => {
                        dispatch(setControllInactiveAgent(identifier, true, brokerId));
                    });
                    break;
                }

            case "Activate":
                {
                    this.commonModal.showModal({
                        type: "confirm",
                        message: `Are you sure you would like to activate this Agent?`
                    }, () => {
                        dispatch(setControllInactiveAgent(identifier, false, brokerId));
                    });
                    break;
                }
        }
    }

    handleReset() {
        const { dispatch, criteria, brokerId } = this.props;
        this.setState({
            agentId: ""
        });
        this.refs.agentName.value = "";
        this.refs.agentEmail.value = "";
        this.refs.userName.value = "";
        this.refs.branchDivisionCompany.value = "";
        updateTextFields();

        dispatch(setAgentSearchCriteria({ ...criteria, page: 1, agentId: "", agentName: "", agentEmail: "", company: "", userName: "" }));
        dispatch(getAgentsList({ ...criteria, brokerId, agentId: "", agentName: "", agentEmail: "", company: "", userName: "" }));
    }
    handleInputChanged(agentId) {
        this.setState({
            ...this.state,
            agentId
        }, () => { });
    }

    render() {
        const { dispatch, columns, agentSearchDataSources, criteria, brokerId } = this.props;

        return (
            <div>
                <div className="place-section">
                    <div className="row">
                        <div className="col s12">
                            <h3 className="title-page-detail">
                                Agent Management
                            </h3>
                        </div>
                    </div>

                    <div className="wrap-search-form">
                        <div className="row">
                            <div className="input-field col s12 m4">
                                <NumbericInput className="validate" id="agentId" name="agentId" value={this.state.agentId} maxValue={2147483647} maxLength="9" onChange={(value) => this.handleInputChanged(value)} onBlur={(e) => this.handleAgentIdOnBlur(e)} />
                                <label htmlFor="agentId">Agent ID</label>
                            </div>
                            <div className="input-field col s12 m4">
                                <input type="text" className="validate" id="agentName" ref="agentName" maxLength="46" name="agentName" onBlur={(e) => this.handleOnBlur(e)} />
                                <label htmlFor="agentName">Agent Name</label>
                            </div>
                            <div className="input-field col s12 m4">
                                <input type="text" className="validate" id="agentEmail" ref="agentEmail" maxLength="46" name="agentEmail" onBlur={(e) => this.handleOnBlur(e)} />
                                <label htmlFor="agentEmail">Agent Email</label>
                            </div>
                        </div>
                        <div className="row">
                            <div className="input-field col s12 m4">
                                <input type="text" className="validate" id="userName" ref="userName" maxLength="46" name="userName" onBlur={(e) => this.handleOnBlur(e)} />
                                <label htmlFor="userName">Username</label>
                            </div>
                            <div className="input-field col s12 m4">
                                <input type="text" className="validate" id="branchDivisionCompany" ref="branchDivisionCompany" maxLength="46" name="company" onBlur={(e) => this.handleOnBlur(e)} />
                                <label htmlFor="branchDivisionCompany">Branch/Division/Company</label>
                            </div>
                        </div>

                        <div className="row mb-0">
                            <div className="col s12 m6">
                                <p className="left red-color">Insert criteria to search for specific agent</p>
                            </div>
                            <div className="col s12 m6">
                                <div className="right center-btn-mobile">
                                    <button className="btn btn-small reload-btn btn-primary" type="button" onClick={() => this.handleReset()} style={{ marginRight: "5px" }}> <i className="lnr lnr-redo"></i></button>
                                    <button onClick={(event) => this.searchButtonClick(event)} className="btn success-color action-btn">Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row mb-0">
                        <div className="col s12 m6">
                            <p className="left" style={{ margin: "2.111111rem 0px" }}><strong>Search Results</strong></p>
                        </div>
                        <div className="col s12 m6">
                            <div className="right center-btn-mobile" style={{ margin: "1.5rem 0px" }}  >
                                <button type="button" className="btn action-btn success-color" onClick={() => {
                                    dispatch(startToggleAgentUpSertModal(true, 0, brokerId));
                                }}>Add Agent</button>
                            </div>
                        </div>
                    </div>
                    <div className="wrap-result-search">
                        <GridView
                            criteria={criteria}
                            totalRecords={agentSearchDataSources.totalRecords}
                            datasources={agentSearchDataSources.data} //Pass datasources
                            columns={columns} //Pass columns array
                            identifier={"AgentId"} //Identifier for grid row
                            onGridViewReload={(newCriteria) => this.handleGridViewReload(newCriteria)} //Paginate changed => need reload datasource base on criteria
                            onActionClick={(action, identifier) => this.handleGridViewActionClick(action, identifier)} //Handle actions
                        />
                        <AgentUpSertModal brokerId={brokerId} />
                    </div>
                </div>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

AgentManagement.defaultProps = {
    columns: [
        {
            title: "Agent ID",
            data: "AgentId"
        },
        {
            title: "Company/Branch/Division",
            data: "Company"
        },
        {
            title: "First Name",
            data: "FirstName"
        },
        {
            title: "Last Name",
            data: "LastName"
        },
        {
            title: "Phone Ext.",
            data: "Ext"
        },
        {
            title: "Email Address",
            data: "Email"
        },
        {
            title: "FAX Number",
            data: "Fax",
            type: "phone"
        },
        {
            title: "Username",
            data: "UserName"
        },
        {
            title: "Action",
            type: "agent-action"
        }
    ]
};

AgentManagement.propTypes = {
    dispatch: PropTypes.func,
    agentSearchDataSources: PropTypes.object,
    criteria: PropTypes.object,
    columns: PropTypes.array,
    brokerId: PropTypes.number,
    roleNames: PropTypes.array,
    router: PropTypes.object
};

const mapStateToProps = (state) => {
    const { agentManagementReducers, authentication } = state;
    const { userId, role } = authentication;
    const { agentManagementDetailsReducer } = agentManagementReducers;
    const { agentSearchDataSources, criteria } = agentManagementDetailsReducer;

    return {
        agentSearchDataSources,
        criteria,
        brokerId: userId,
        roleNames: role.roleNames
    };
};

export default connect(mapStateToProps)(AgentManagement);