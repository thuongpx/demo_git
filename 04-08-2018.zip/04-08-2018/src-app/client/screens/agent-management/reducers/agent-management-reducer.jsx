import { AGENT_SET_SEARCH_CRITERIA, AGENT_SET_AGENT, AGENT_SET_BRANCHES, AGENT_SET_VALIDATOR, AGENT_SET_USER, AGENT_TOGGLE_UPSERTMODAL, AGENT_SEARCH_RECEIVE } from "./../actions/agent-management-action";

export default function agentManagementDetailsReducer(state = {
    agentSearchDataSources: {
        data: [],
        totalRecords: 0
    },
    criteria: {
        sortColumn: "AgentId",
        sortDirection: false,
        page: 1,
        itemPerPage: 25
    },
    isShowModal: false,
    agentId: 0,
    agent: {},
    user: {},
    branches: [],
    validator: {}
}, action) {
    switch (action.type) {

        case AGENT_SEARCH_RECEIVE:
            return {
                ...state,
                agentSearchDataSources: action.agents
            };

        case AGENT_SET_AGENT:
            return {
                ...state,
                agent: action.agent
            };

        case AGENT_SET_BRANCHES:
            return {
                ...state,
                branches: action.branches
            };

        case AGENT_SET_VALIDATOR:
            return {
                ...state,
                validator: action.validator
            };

        case AGENT_TOGGLE_UPSERTMODAL:
            return {
                ...state,
                agentId: action.agentId,
                agent: action.agent,
                isShowModal: action.isShowModal
            };

        case AGENT_SET_SEARCH_CRITERIA:
            return {
                ...state,
                criteria: action.criteria
            };

        case AGENT_SET_USER:
            return {
                ...state,
                user: action.user
            };

        default:
            return state;
    }
}