import { combineReducers } from "redux";
import agentManagementDetailsReducer from "./agent-management-reducer";

const agentManagementReducers = combineReducers({
    agentManagementDetailsReducer
});

export default agentManagementReducers;
