import { apiGetAgentByOption, apiGetAgent, apiAddAgent, apiUpdateAgent, apiDisableOrActiveAgent } from "Api/agent-api";
import { apiGetBranchesByBrokerId } from "Api/clients-api";

import { handleApiError } from "ErrorHandler";

export const AGENT_SET_SEARCH_CRITERIA = "MANAGE_AGENT_SET_SEARCH_CRITERIA";
export const AGENT_SET_BRANCHES = "MANAGE_AGENT_SET_BRANCHES";
export const AGENT_SET_AGENT = "MANAGE_AGENT_SET_AGENT";
export const AGENT_SET_VALIDATOR = "MANAGE_AGENT_SET_VALIDATOR";
export const AGENT_SET_USER = "MANAGE_AGENT_SET_USER";
export const AGENT_TOGGLE_UPSERTMODAL = "MANAGE_AGENT_TOGGLE_UPSERTMODAL";
export const AGENT_SEARCH_RECEIVE = "MANAGE_AGENT_SEARCH_RECEIVE";

import { showSuccess } from "../../main-layout/actions";
import {
    SUCCESSFULLY_SAVED_MESSAGE,
    SUCCESSFULLY_CREATED_MESSAGE
} from "Constants";

export const setAgentSearchCriteria = (criteria) => {
    return {
        type: AGENT_SET_SEARCH_CRITERIA,
        criteria
    };
};

export const setBranches = (branches) => {
    return {
        type: AGENT_SET_BRANCHES,
        branches
    };
};

export const setAgent = (agent) => {
    return {
        type: AGENT_SET_AGENT,
        agent
    };
};

export const setvalidator = (validator) => {
    return {
        type: AGENT_SET_VALIDATOR,
        validator
    };
};

export const setUser = (user) => {
    return {
        type: AGENT_SET_USER,
        user
    };
};

export const toggleAgentUpSertModal = (isShowModal, agentId, agent) => {
    return {
        type: AGENT_TOGGLE_UPSERTMODAL,
        agentId,
        agent,
        isShowModal
    };
};

export const receiveAgents = (agents) => {
    return {
        type: AGENT_SEARCH_RECEIVE,
        agents
    };
};

export const startToggleAgentUpSertModal = (isShowModal, agentId, brokerId) => {
    return (dispatch) => {
        if (brokerId > 0) {
            apiGetBranchesByBrokerId(brokerId, (branches) => {
                dispatch(setBranches(branches.data));
            });
        }
        if (agentId > 0) {
            apiGetAgent(agentId, (response) => {
                response.data.BranchID = response.data.BrokerId;

                dispatch(toggleAgentUpSertModal(isShowModal, agentId, response.data));
            }, (error) => handleApiError(dispatch, error));
        } else {
            dispatch(toggleAgentUpSertModal(isShowModal, 0, {
                TenantId: 1,
                Ext: "",
                Fax: "",
                Email: "",
                AfterhoursPhone: "",
                Inactive: false,
                BranchID: 0,
                Direct: "",
                ViewAll: false,
                FullName: "",
                BrokerId: brokerId,
                NeedResetPassword: false,
                FirstName: "",
                LastName: ""
            }));
            dispatch(setUser({
                Username: "",
                Password: "",
                ConfirmPassword: ""
            }));
            dispatch(setvalidator({}));
        }
    };
};

export const getAgentsList = (criteria) => {
    return dispatch => {
        return apiGetAgentByOption(criteria, (response) => {
            let newArrayObj = [];

            if (response.data) {
                response.data.data.map((key) => {
                    if (key.Inactive.data[0] === 1) {
                        newArrayObj = [
                            ...newArrayObj,
                            {
                                ...key,
                                Inactive: true
                            }
                        ];
                    } else {
                        newArrayObj = [
                            ...newArrayObj,
                            {
                                ...key,
                                Inactive: false
                            }
                        ];
                    }
                });
            }
            response.data = {
                ...response.data,
                data: newArrayObj
            };
            dispatch(receiveAgents(response.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const updateAgent = (brokerId) => {
    return (dispatch, getState) => {
        const agent = getState().agentManagementReducers.agentManagementDetailsReducer.agent;
        const criteria = getState().agentManagementReducers.agentManagementDetailsReducer.criteria;

        if (agent.BrokerId && agent.BrokerId.toString() === "0") {
            agent.BrokerId = brokerId;
        }
        apiUpdateAgent(agent, () => {
            dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
            dispatch(getAgentsList({ ...criteria, brokerId }));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const addAgent = (brokerId) => {
    return (dispatch, getState) => {
        const agent = getState().agentManagementReducers.agentManagementDetailsReducer.agent;
        const criteria = getState().agentManagementReducers.agentManagementDetailsReducer.criteria;
        const newCriteria = { ...criteria, brokerId };

        if (agent.BrokerId && agent.BrokerId.toString() === "0") {
            agent.BrokerId = brokerId;
        }

        apiAddAgent(agent, getState().agentManagementReducers.agentManagementDetailsReducer.user, () => {
            dispatch(showSuccess(SUCCESSFULLY_CREATED_MESSAGE));
            dispatch(getAgentsList(newCriteria));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const setControllInactiveAgent = (agentId, isInactive, brokerId) => {
    return (dispatch, getState) => {
        const agent = { AgentId: agentId, Inactive: isInactive };
        const criteria = getState().agentManagementReducers.agentManagementDetailsReducer.criteria;
        const newCriteria = { ...criteria, brokerId };

        apiDisableOrActiveAgent(agent, () => {
            dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
            dispatch(getAgentsList(newCriteria));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const setGridViewCriteria = (criteria) => {
    return dispatch => {
        dispatch(setAgentSearchCriteria(criteria));
        dispatch(getAgentsList(criteria));
    };
};