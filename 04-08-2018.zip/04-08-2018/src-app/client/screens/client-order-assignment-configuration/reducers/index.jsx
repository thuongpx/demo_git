import { CLIENT_ORDER_ASSIGN_CONFIG_REQUEST, CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_INIT_DATA, CLIENT_ORDER_ASSIGN_CONFIG_HANDLE_ONCHANGE, CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_LIST_CLIENT_PREFERRED, CLIENT_ORDER_ASSIGN_CONFIG_STOP_FETCHING, CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_LIST_CLIENT_CONFIG_LOG, CLIENT_ORDER_ASSIGN_CONFIG_RESET_CONFIG, CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_VENDOR_POOL, CLIENT_ORDER_ASSIGN_CONFIG_CLEAR_REDUCRE } from "../actions";
import { deepClone, hasStringValue } from "../../../helpers/common-helper";

const defaultState = {
    isFetching: false,
    listTrainingCourse: [],
    listVendorCategories: [],
    inputs: {
        performanceRating: {
            isActive: false,
            data: [],
            isInvalid: false
        },
        specialty: {
            isActive: false,
            data: [],
            isInvalid: false
        },
        experience: {
            isActive: false,
            data: "",
            isInvalid: false
        },
        training: {
            isActive: false,
            data: [],
            isInvalid: false
        },
        clientPreferred: {
            isActive: false,
            isInvalid: false
        }
    },
    listPreferredVendors: {
        data: [],
        totalRecords: 0
    },
    listConfigLog: {
        data: [],
        totalRecords: 0
    },
    vendorPool: 0
};

export default function clientOrderAssignConfigReducer(state = deepClone(defaultState), action) {
    switch (action.type) {
        case CLIENT_ORDER_ASSIGN_CONFIG_REQUEST:
            return {
                ...state,
                isFetching: true
            };
        case CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_INIT_DATA:
            return {
                ...state,
                isFetching: false,
                listVendorCategories: action.data.listVendorCategories || [],
                listTrainingCourse: action.data.listTrainingCourse || [],
                inputs: {
                    ...state.inputs,
                    performanceRating: {
                        isActive: action.data.rating.length > 0,
                        data: action.data.rating,
                        isInvalid: false
                    },
                    specialty: {
                        isActive: action.data.specialy.length > 0,
                        data: action.data.specialy,
                        isInvalid: false
                    },
                    experience: {
                        isActive: hasStringValue(action.data.experience),
                        data: hasStringValue(action.data.experience) ? action.data.experience : "",
                        isInvalid: false
                    },
                    training: {
                        isActive: action.data.training.length > 0,
                        data: action.data.training,
                        isInvalid: false
                    },
                    clientPreferred: {
                        isActive: action.data.hasPreferredVendor > 0,
                        isInvalid: false
                    }
                },
                listPreferredVendors: {
                    data: [],
                    totalRecords: action.data.hasPreferredVendor
                }
            };
        case CLIENT_ORDER_ASSIGN_CONFIG_HANDLE_ONCHANGE:
            return {
                ...state,
                inputs: action.inputs
            };
        case CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_LIST_CLIENT_PREFERRED:
            return {
                ...state,
                isFetching: false,
                listPreferredVendors: {
                    data: action.data.listClientPreferred,
                    totalRecords: action.data.totalRecords
                }
            };
        case CLIENT_ORDER_ASSIGN_CONFIG_STOP_FETCHING:
            return {
                ...state,
                isFetching: false
            };
        case CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_LIST_CLIENT_CONFIG_LOG:
            return {
                ...state,
                isFetching: false,
                listConfigLog: {
                    data: action.data.listConfigLog || [],
                    totalRecords: action.data.totalRecords || 0
                }
            };
        case CLIENT_ORDER_ASSIGN_CONFIG_RESET_CONFIG:
            return {
                ...state,
                inputs: {
                    performanceRating: {
                        isActive: false,
                        data: [],
                        isInvalid: false
                    },
                    specialty: {
                        isActive: false,
                        data: [],
                        isInvalid: false
                    },
                    experience: {
                        isActive: false,
                        data: "",
                        isInvalid: false
                    },
                    training: {
                        isActive: false,
                        data: [],
                        isInvalid: false
                    },
                    clientPreferred: {
                        isActive: false,
                        isInvalid: false
                    }
                },
                isFetching: false,
                listPreferredVendors: {
                    data: [],
                    totalRecords: 0
                }
            };
        case CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_VENDOR_POOL:
            return {
                ...state,
                vendorPool: action.data
            };
        case CLIENT_ORDER_ASSIGN_CONFIG_CLEAR_REDUCRE:
            return deepClone(defaultState);
        default:
            return state;
    }
}