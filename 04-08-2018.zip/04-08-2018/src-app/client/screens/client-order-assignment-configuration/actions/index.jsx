import { apiGetInitDataForClientOrderAssignConfig, apiGetlistClientPreferred, apiSaveClientOrderAssignConfig } from "../../../api/broker-api";
import { handleApiError } from "ErrorHandler";
import { apiAddClientPreferredVendor, apiAddClientPreferredVendorOutsideTCE, apiDeletePreferredVendor, apiDeleteAllClientPreferredVendor, apiCheckExistsClientPreferredVendor } from "../../../api/clients-api";
import { apiGetTotalVendorPoolForClientOrderAssignConfig } from "../../../api/signer-api";

export const CLIENT_ORDER_ASSIGN_CONFIG_REQUEST = "CLIENT_ORDER_ASSIGN_CONFIG_REQUEST";
export const CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_INIT_DATA = "CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_INIT_DATA";
export const CLIENT_ORDER_ASSIGN_CONFIG_HANDLE_ONCHANGE = "CLIENT_ORDER_ASSIGN_CONFIG_HANDLE_ONCHANGE";
export const CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_LIST_CLIENT_PREFERRED = "CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_LIST_CLIENT_PREFERRED";
export const CLIENT_ORDER_ASSIGN_CONFIG_STOP_FETCHING = "CLIENT_ORDER_ASSIGN_CONFIG_STOP_FETCHING";
export const CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_LIST_CLIENT_CONFIG_LOG = "CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_LIST_CLIENT_CONFIG_LOG";
export const CLIENT_ORDER_ASSIGN_CONFIG_RESET_CONFIG = "CLIENT_ORDER_ASSIGN_CONFIG_RESET_CONFIG";
export const CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_VENDOR_POOL = "CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_VENDOR_POOL";
export const CLIENT_ORDER_ASSIGN_CONFIG_CLEAR_REDUCRE = "CLIENT_ORDER_ASSIGN_CONFIG_CLEAR_REDUCRE";

export const requestFetchingData = () => {
    return {
        type: CLIENT_ORDER_ASSIGN_CONFIG_REQUEST
    };
};

export const stopFetchingData = () => {
    return {
        type: CLIENT_ORDER_ASSIGN_CONFIG_STOP_FETCHING
    };
};

export const receiveInitData = (data) => {
    return {
        type: CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_INIT_DATA,
        data
    };
};

export const receiveVendorPool = (data) => {
    return {
        type: CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_VENDOR_POOL,
        data
    };
};

export const clearReducer = () => {
    return {
        type: CLIENT_ORDER_ASSIGN_CONFIG_CLEAR_REDUCRE
    };
};

export const getInitDataForAssignConfig = (inputs) => {
    return dispatch => {
        dispatch(requestFetchingData());
        apiGetInitDataForClientOrderAssignConfig(inputs, result => {
            dispatch(receiveInitData(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const handleOnChangeField = (inputs) => {
    return {
        type: CLIENT_ORDER_ASSIGN_CONFIG_HANDLE_ONCHANGE,
        inputs
    };
};

export const receiveListClientPreferred = (data) => {
    return {
        type: CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_LIST_CLIENT_PREFERRED,
        data
    };
};

export const receiveListConfigLog = (data) => {
    return {
        type: CLIENT_ORDER_ASSIGN_CONFIG_RECEIVE_LIST_CLIENT_CONFIG_LOG,
        data
    };
};

export const resetClientConfig = () => {
    return {
        type: CLIENT_ORDER_ASSIGN_CONFIG_RESET_CONFIG
    };
};

export const getListClientPreferred = (inputs) => {
    return dispatch => {
        dispatch(requestFetchingData());
        apiGetlistClientPreferred(inputs, result => {
            dispatch(receiveListClientPreferred(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const addSelectedSearchVendor = (inputs, cb) => {
    return dispatch => {
        dispatch(requestFetchingData());
        apiAddClientPreferredVendor(inputs, () => {
            dispatch(stopFetchingData());
            cb();
        }, (error) => handleApiError(dispatch, error));
    };
};


export const addVendorOutsideTCE = (inputs, cb) => {
    return dispatch => {
        dispatch(requestFetchingData());
        apiAddClientPreferredVendorOutsideTCE(inputs, () => {
            dispatch(stopFetchingData());
            cb();
        }, (error) => handleApiError(dispatch, error));
    };
};

export const deletePreferredVendor = (inputs, cb) => {
    return dispatch => {
        dispatch(requestFetchingData());
        apiDeletePreferredVendor(inputs, () => {
            dispatch(stopFetchingData());
            cb();
        }, (error) => handleApiError(dispatch, error));
    };
};

export const saveClientOrderAssignConfig = (inputs, cb) => {
    return dispatch => {
        dispatch(requestFetchingData());
        apiSaveClientOrderAssignConfig(inputs, () => {
            dispatch(stopFetchingData());
            cb();
        }, (error) => handleApiError(dispatch, error));
    };
};

export const resetCurrentSetting = (inputs, cb) => {
    return dispatch => {
        dispatch(requestFetchingData());
        apiDeleteAllClientPreferredVendor(inputs, () => {
            dispatch(resetClientConfig());
            cb();
        }, (error) => handleApiError(dispatch, error));
    };
};

export const getVendorPool = (inputs) => {
    return dispatch => {
        dispatch(requestFetchingData());
        apiGetTotalVendorPoolForClientOrderAssignConfig(inputs, (result) => {
            dispatch(receiveVendorPool(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const clearDataForNewClientId = (newClientId, isCustomer) => {
    return dispatch => {
        dispatch(clearReducer());
        dispatch(getInitDataForAssignConfig({ clientId: newClientId, isCustomer }));
    };
};

export const checkVendorIsExists = (inputs, cb, dispatch) => {
    apiCheckExistsClientPreferredVendor(inputs, (result) => {
        cb(result.data);
    }, (error) => handleApiError(dispatch, error));
};