import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import ClientOrderAssignConfigOptions from "../components/client-order-assign-config-option";
import { shallowCompareState, shallowCompareProps } from "../../../helpers/common-helper";
import { getInitDataForAssignConfig, clearDataForNewClientId } from "../actions";

class ClientOrderAssignmentConfig extends Component {
    constructor(props) {
        super(props);

        const { params, isStaffConfig, staffConfigId } = this.props;
        let customerId = 0;
        if (params) customerId = params.customerId;

        this.state = {
            customerId: isStaffConfig ? Number(staffConfigId) : Number(customerId)
        };

        if (isStaffConfig) {
            this.isCustomer = false;
        } else {
            this.isCustomer = this.state.customerId > 0;
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentWillMount() {
        const { dispatch, profile, isStaffConfig } = this.props;
        dispatch(getInitDataForAssignConfig({ clientId: this.state.customerId === 0 && !isStaffConfig ? profile.id : this.state.customerId, isCustomer: this.isCustomer }));
    }

    componentWillReceiveProps(nextProps) {
        if (!shallowCompareProps(this.props.params, nextProps.params) && !this.props.isStaffConfig) {
            const { dispatch, params, profile } = nextProps;
            const { customerId } = params;
            this.setState({ customerId: Number(customerId) });
            this.isCustomer = Number(customerId) > 0;

            dispatch(clearDataForNewClientId(Number(customerId) === 0 ? profile.id : Number(customerId), this.isCustomer));
        }
    }

    render() {
        const { clientOrderAssignConfig, dispatch, profile, isStaffConfig, setEditMode } = this.props;

        return (
            <div className="tab-content">
                {!isStaffConfig && <div className="row">
                    <div className="col s12"><h3 className="title-page-detail">Order Assignment Configuration</h3></div>
                </div>}
                <div className="row">
                    <p>
                        Clients have the ability to set the criteria by which signing agent searches will be conducted. These criteria will be used when staff conducts all searches on the client’s behalf. Please select the all relevant boxes to determine the Order Assignment Configuration. For example, if you select only Excellent and Very Good ratings and 100+ Orders Experience, The Closing Exchange will assign orders to only the signing agents who have Excellent or Very Good Ratings who have completed more than 100 orders for The Closing Exchange.
                    </p>
                </div>
                <ClientOrderAssignConfigOptions
                    clientId={this.state.customerId}
                    configData={clientOrderAssignConfig}
                    dispatch={(action) => dispatch(action)}
                    profile={profile}
                    isStaffConfig={isStaffConfig || false}
                    ref={instance => { this.ConfigOption = instance; }}
                    setEditMode={(mode) => setEditMode(mode)}
                />
            </div>
        );
    }
}

ClientOrderAssignmentConfig.propTypes = {
    params: PropTypes.object,
    clientOrderAssignConfig: PropTypes.object,
    dispatch: PropTypes.func,
    profile: PropTypes.object,
    isStaffConfig: PropTypes.bool,
    staffConfigId: PropTypes.number,
    setEditMode: PropTypes.func
};

ClientOrderAssignmentConfig.defaultProps = {
    setEditMode: () => { }
};

const mapStateToProps = (state) => {
    const { clientOrderAssignConfig, authentication } = state;
    const { profile, accountId } = authentication;

    return {
        clientOrderAssignConfig,
        profile,
        accountId
    };

};

export default connect(mapStateToProps, null, null, { withRef: true })(ClientOrderAssignmentConfig);