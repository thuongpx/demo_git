import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import Select from "Select";
import { VENDOR_REQUIREMENTS_DATA } from "../../../constant/constants";
import MultiSelectWrapper from "../../../features/multi-select/multi-select-wrapper";
import { shallowCompareState, shallowCompareProps, deepClone, hasStringValue } from "../../../helpers/common-helper";
import SelectPreferredVendorsModal from "./select-preferred-vendors-modal";
import { handleOnChangeField, saveClientOrderAssignConfig, resetCurrentSetting, getVendorPool } from "../actions";
import { updateSelectFields } from "../../../helpers/theme-helper";
import { showSuccess } from "../../main-layout/actions";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import { requireComboBoxMessage } from "../../../helpers/validation-helper";

class ClientOrderAssignConfigOptions extends Component {
    constructor(props) {
        super(props);

        this.state = {
            isOpenSelectVendorsModal: false,
            isEditMode: false
        };

        const { clientId, profile, isStaffConfig } = this.props;
        if (isStaffConfig) {
            this.clientId = clientId;
            this.isCustomer = false;
        } else {
            this.clientId = clientId === 0 ? profile.id : clientId;
            this.isCustomer = clientId === 0 ? false : true;
        }
    }

    handleOnchangeActiveConditional(value, fieldName) {
        const { configData, dispatch } = this.props;
        const inputs = deepClone(configData.inputs);

        inputs[fieldName].isActive = value;
        if (fieldName === "experience") {
            inputs[fieldName].data = "";
        } else {
            inputs[fieldName].data = [];
        }
        inputs[fieldName].isInvalid = false;

        dispatch(handleOnChangeField(inputs));
    }

    handleOnchangeValueConditional(value, fieldName) {
        const { configData, dispatch } = this.props;
        const inputs = deepClone(configData.inputs);
        inputs[fieldName].data = value;

        if ((Array.isArray(value) && value.length === 0) || value === "") {
            inputs[fieldName].isInvalid = true;
        } else {
            inputs[fieldName].isInvalid = false;
        }

        dispatch(handleOnChangeField(inputs));
    }

    componentWillReceiveProps(nextProps) {
        if (!shallowCompareProps(this.props.configData.inputs, nextProps.configData.inputs)) {
            this.reloadVendorPool(nextProps.configData.inputs);
        }
        if (!shallowCompareProps(this.props.clientId, nextProps.clientId)) {
            const { clientId, profile, isStaffConfig } = this.props;

            if (isStaffConfig) {
                this.clientId = clientId;
                this.isCustomer = false;
            } else {
                this.clientId = clientId === 0 ? profile.id : clientId;
                this.isCustomer = clientId === 0 ? false : true;
            }
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentDidUpdate() {
        updateSelectFields();
    }

    handleToggleVendorModal() {
        if (this.state.isOpenSelectVendorsModal) {
            this.setState({ isOpenSelectVendorsModal: false });
            this.reloadVendorPool(this.props.configData.inputs);
        } else {
            this.setState({ isOpenSelectVendorsModal: true });
        }
    }

    componentDidMount() {
        this.reloadVendorPool(this.props.configData.inputs);
    }

    validateForm() {
        const { dispatch, configData } = this.props;
        const inputs = deepClone(configData.inputs);
        const { listPreferredVendors } = configData;
        let check = true;

        Object.keys(inputs).forEach(item => {
            if (item !== "clientPreferred") {
                if (inputs[item].isActive && ((Array.isArray(inputs[item].data) && inputs[item].data.length === 0) || inputs[item].data === "")) {
                    inputs[item].isInvalid = true;
                    check = false;
                } else {
                    inputs[item].isInvalid = false;
                }
            }
        });

        if (inputs.clientPreferred.isActive && listPreferredVendors.totalRecords === 0) {
            inputs.clientPreferred.isInvalid = true;
            check = false;
        } else {
            inputs.clientPreferred.isInvalid = false;
        }

        dispatch(handleOnChangeField(inputs));
        return check;
    }

    reloadVendorPool(inputs) {

        // clear and delete timeout if existed
        if (this.currentTimeOut) {
            clearTimeout(this.currentTimeOut);
            delete this.currentTimeOut;
        }


        this.currentTimeOut = setTimeout(() => {
            const { dispatch } = this.props;

            dispatch(getVendorPool({ inputs, isCustomer: this.isCustomer, clientId: this.clientId }));

            delete this.currentTimeOut; // delete timeout
        }, 1000);

    }

    handleSaveChange(isShowNoti = true) {
        const { dispatch, configData, profile } = this.props;
        const { inputs } = configData;

        if (!this.validateForm()) return;

        dispatch(saveClientOrderAssignConfig({ inputs, isCustomer: this.isCustomer, clientId: this.clientId, changedBy: profile.userId }, () => {
            if (isShowNoti) dispatch(showSuccess("Created Successfully"));
            this.setState({ isEditMode: false });
            this.props.setEditMode(false);
        }));
    }

    handleReset() {
        const { dispatch } = this.props;


        this.SelectVendorModal.commonModal.showModal({ type: "confirm", message: "Clicking this button means all criteria entered by you including Preferred Vendor will be reset to default value. Are you sure you would like to continue?" },
            () => {
                dispatch(resetCurrentSetting({ isCustomer: this.isCustomer, clientId: this.clientId }, () => this.handleSaveChange()));
            },
            () => {
            }
            , false, "Yes", "No");
    }

    handleActiveEditMode() {
        this.setState({ isEditMode: true });
        this.props.setEditMode(true);
    }

    render() {
        const ratingListOptions = [];
        const specialtyListOptions = [];
        const trainingListOptions = [];
        const { configData, dispatch, clientId, profile, isStaffConfig } = this.props;
        const { inputs } = configData;

        VENDOR_REQUIREMENTS_DATA.performanceRatings.forEach(item => {
            ratingListOptions.push({ id: item.value, label: item.data, value: item.value });
        });

        configData.listVendorCategories.forEach(item => {
            specialtyListOptions.push({ id: item.CatId, label: item.CatName, value: item.CatId });
        });

        configData.listTrainingCourse.forEach(item => {
            trainingListOptions.push({ id: item.courseId, label: item.description, value: item.courseId });
        });

        return (
            <div>
                <div className="row">
                    <div className="col s12 m12 l9">
                        <div className="col s12 m4 pt-2">
                            <label>
                                <input
                                    type="checkbox"
                                    id="performanceRating"
                                    checked={inputs.performanceRating.isActive}
                                    onChange={e => this.handleOnchangeActiveConditional(e.target.checked, "performanceRating")}
                                    disabled={!this.state.isEditMode}
                                />
                                <span>Performance Rating</span>
                            </label>
                        </div>
                        <div className={`col s12 m8`}>
                            <MultiSelectWrapper
                                options={ratingListOptions}
                                values={inputs.performanceRating.data}
                                onValuesChange={(selectedList) => this.handleOnchangeValueConditional(selectedList, "performanceRating")}
                                placeholder="---Select Ratings---"
                                disabled={!inputs.performanceRating.isActive || !this.state.isEditMode}
                                requiredMess={inputs.performanceRating.isActive && inputs.performanceRating.isInvalid ? "Performance Rating" : ""}
                            />
                        </div>

                        <div className="clearfix"></div>

                        <div className="col s12 m4 pt-2">
                            <label>
                                <input
                                    type="checkbox"
                                    id="specialty"
                                    checked={inputs.specialty.isActive}
                                    onChange={e => this.handleOnchangeActiveConditional(e.target.checked, "specialty")}
                                    disabled={!this.state.isEditMode}
                                />
                                <span>Specialty</span>
                            </label>
                        </div>
                        <div className={`col s12 m8`}>
                            <MultiSelectWrapper
                                options={specialtyListOptions}
                                values={inputs.specialty.data}
                                onValuesChange={(selectedList) => { this.handleOnchangeValueConditional(selectedList, "specialty"); }}
                                placeholder="---Select Specialty---"
                                disabled={!inputs.specialty.isActive || !this.state.isEditMode}
                                requiredMess={inputs.specialty.isActive && inputs.specialty.isInvalid ? "Specialty" : ""}
                            />
                        </div>

                        <div className="clearfix"></div>

                        <div className="col s12 m4 pt-2">
                            <label>
                                <input
                                    type="checkbox"
                                    id="experience"
                                    checked={inputs.experience.isActive}
                                    onChange={e => this.handleOnchangeActiveConditional(e.target.checked, "experience")}
                                    disabled={!this.state.isEditMode}
                                />
                                <span>Experience</span>
                            </label>
                        </div>
                        <div className="col s12 m8">
                            <div className={`input-field suffixinput ${inputs.experience.isActive && inputs.experience.isInvalid ? "required-field" : ""}`}>
                                <Select
                                    dataSource={VENDOR_REQUIREMENTS_DATA.experience}
                                    mapDataToRenderOptions={{ value: "value", label: "data" }}
                                    value={hasStringValue(inputs.experience.data) ? Number(inputs.experience.data) : ""}
                                    optionDefaultLabel="---Select Experience---"
                                    onChange={(value) => this.handleOnchangeValueConditional(value, "experience")}
                                    disabled={!inputs.experience.isActive || !this.state.isEditMode}
                                />
                                {inputs.experience.isActive && inputs.experience.isInvalid && <span className={`suffix-text`} style={{ right: 15 }}>
                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireComboBoxMessage("Experience")} />
                                </span>}
                            </div>

                        </div>

                        <div className="clearfix"></div>

                        <div className="col s12 m4 pt-2">
                            <label>
                                <input
                                    type="checkbox"
                                    id="training"
                                    checked={inputs.training.isActive}
                                    onChange={e => this.handleOnchangeActiveConditional(e.target.checked, "training")}
                                    disabled={!this.state.isEditMode}
                                />
                                <span>Training</span>
                            </label>
                        </div>
                        <div className={`col s12 m8`}>
                            <MultiSelectWrapper
                                options={trainingListOptions}
                                values={inputs.training.data}
                                onValuesChange={(selectedList) => { this.handleOnchangeValueConditional(selectedList, "training"); }}
                                placeholder="---Select Trainings---"
                                disabled={!inputs.training.isActive || !this.state.isEditMode}
                                requiredMess={inputs.training.isActive && inputs.training.isInvalid ? "Training" : ""}
                            />
                        </div>

                        <div className="clearfix"></div>

                        <div className="col s12 m4 pt-2">
                            <label>
                                <input
                                    type="checkbox"
                                    id="clientPreferred"
                                    checked={inputs.clientPreferred.isActive}
                                    onChange={e => this.handleOnchangeActiveConditional(e.target.checked, "clientPreferred")}
                                    disabled={!this.state.isEditMode}
                                />
                                <span>Client-Preferred</span>
                            </label>
                        </div>
                        <div className="col s12 m8 pt-2">
                            <span
                                className={`blue-color ${inputs.clientPreferred.isActive ? "" : "hide"}`}
                                style={{ cursor: "pointer" }}
                                onClick={() => this.handleToggleVendorModal()}
                            ><strong><u>Select Vendors</u></strong></span>
                            {inputs.clientPreferred.isActive && inputs.clientPreferred.isInvalid && <span className={``}>
                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireComboBoxMessage("Client-Preferred")} />
                            </span>}
                        </div>

                    </div>
                    <div className="col s12 m12 l3">
                        <div className="row">
                            <div className="col s12">
                                <div className="row row card-panel white box-shadow-none border-style-dashboard mt-1 mb-0" style={{ marginTop: "1rem !important" }}>
                                    <div className="col s10 offset-s1 center-align">
                                        <h5 className="green-color mb-0">Vendor Pool</h5>
                                        <div className="divider"></div>
                                    </div>
                                    <div className="clearfix"></div>
                                    <div className="row mt-1">
                                        <div className="col s8 m12 l9 center-align">
                                            <h1 className="dark-green-color m-0 center-align"><strong>{configData.vendorPool}</strong></h1>
                                            <div className="clearfix"></div>
                                            {configData.vendorPool === 0 && <span className="red-color center-align" style={{ fontSize: 12 }}><i>No vendor matches with your selected criteria. Please re-set.</i></span>}
                                        </div>
                                        <div className="col s3 m1 l3 offset-m6"><span className="lnr lnr-users small-icon icon-vendor-pool"></span></div>
                                    </div>
                                </div>
                            </div>
                            <div className="col s12">
                                <p>This number shows how many vendors matching your selected criteria per order. By default, this is number of all available vendors in the system.</p>
                                <p>Please be noted that the more criteria you select, the less vendor per order</p>
                            </div>
                        </div>
                    </div>
                </div>
                {!isStaffConfig && <div className="row">
                    {this.state.isEditMode ?
                        <div>
                            <div className="col s3 m3 l1 offset-s3 offset-l4 offset-m3">
                                <button className="btn white w-100" onClick={() => this.handleReset()}>Reset</button>
                            </div>
                            <div className="col s3 m3 l1">
                                <button className="btn success-color w-100" onClick={() => this.handleSaveChange()}>Save</button>
                            </div>
                        </div> :
                        <div className="col s3 m2 l1 offset-s4 offset-m5 offset-l5">
                            <button className="btn success-color w-100" onClick={() => this.handleActiveEditMode()}>Edit</button>
                        </div>
                    }

                </div>}
                <SelectPreferredVendorsModal
                    isOpen={this.state.isOpenSelectVendorsModal}
                    toggleModal={() => this.handleToggleVendorModal()}
                    dispatch={(action) => dispatch(action)}
                    clientId={clientId}
                    profile={profile}
                    listClientPreferred={configData.listPreferredVendors}
                    ref={node => { this.SelectVendorModal = node; }}
                    isStaffConfig={isStaffConfig}
                    isEditMode={this.state.isEditMode}
                />
            </div>
        );
    }
}

ClientOrderAssignConfigOptions.propTypes = {
    clientId: PropTypes.number,
    configData: PropTypes.object,
    dispatch: PropTypes.func,
    profile: PropTypes.object,
    isStaffConfig: PropTypes.bool,
    setEditMode: PropTypes.func
};

export default ClientOrderAssignConfigOptions;