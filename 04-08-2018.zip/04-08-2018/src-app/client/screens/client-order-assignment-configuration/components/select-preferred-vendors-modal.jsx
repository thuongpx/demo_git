import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";
import GridView from "GridView";
import { shallowCompareState, shallowCompareProps, hasStringValue, deepClone, replaceAll } from "../../../helpers/common-helper";
import { getListClientPreferred, addSelectedSearchVendor, addVendorOutsideTCE, deletePreferredVendor, checkVendorIsExists } from "../actions";
import ReactTooltip from "react-tooltip";
import { axiosCancel, getAxiosSource, isCancel } from "../../../helpers/axios-helper";
import { apiGetListVendorByNameOrEmail } from "../../../api/signer-api";
import { showError } from "../../main-layout/actions";
import { updateTextFields } from "../../../helpers/theme-helper";
import { validateEmail } from "Helpers/validation-helper";
import NumbericInput from "NumbericInput";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import { INPUT_ERROR_1X_IMAGE_URL } from "ImageConfig";
import { requireMessage, invalidMessage } from "../../../helpers/validation-helper";
import CommonModal from "../../../features/common-modal/common-modal";

class SelectPreferredVendorsModal extends Component {
    constructor(props) {
        super(props);

        this.state = {
            gridCriteria: deepClone(this.props.defaultGridCriteria),
            inputs: {
                searchNameText: ""
            },
            invalidField: {},
            isSearchingNewList: false,
            hasSearchData: false,
            listDataSearchVendor: []
        };

        this.minLengthSearch = 2;
        this.isOpenModal = false;
        this.isCustomer = false;
        this.selectedVendor = {};
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    handleSelectedSearchVendor(vendor, checked) {
        if (checked) {
            this.selectedVendor[vendor.signerId] = vendor;
            this.selectedVendor[vendor.signerId].checked = true;
        } else {
            delete this.selectedVendor[vendor.signerId];
        }
    }

    handleOnchangeVendorSearchTextField(value) {
        const { inputs } = this.state;
        const hasSearchData = false;
        let isSearchingNewList = true;

        inputs.searchNameText = value;
        inputs.listSelectVendor = [];

        // abort previous request if existed
        if (this.axiosSource) {
            axiosCancel(this.axiosSource);
        }

        // clear and delete timeout if existed
        if (this.currentTimeOut) {
            clearTimeout(this.currentTimeOut);
            delete this.currentTimeOut;
        }

        // searchText is empty or not enough char, don't need search
        if (!hasStringValue(value.trim()) || value.trim().length < this.minLengthSearch) {
            isSearchingNewList = false;
        } else {
            this.handleSearchVendor(value.trim());
        }

        this.setState({ inputs, isSearchingNewList, hasSearchData });
        this.selectedVendor = {};
    }

    handleSearchVendor(searchText) {
        this.currentTimeOut = setTimeout(() => {
            this.axiosSource = getAxiosSource();
            const { clientId, profile, isStaffConfig } = this.props;
            const id = this.isCustomer || isStaffConfig ? clientId : profile.id;

            //call api get list data
            apiGetListVendorByNameOrEmail({ searchText, isCustomer: this.isCustomer, clientId: id }, result => {
                delete this.axiosSource; // delete source

                const listDataSearchVendor = result.data;

                this.setState({ listDataSearchVendor, isSearchingNewList: false, hasSearchData: true });

            }, err => {
                delete this.axiosSource; // delete source

                if (!isCancel(err)) {
                    const { dispatch } = this.props;
                    dispatch(showError(err.message));
                }
            });

            delete this.currentTimeOut; // delete timeout
        }, 1000);
    }

    handleAddVendorFromAutoSuggest() {
        const listId = [];
        const { clientId, profile, dispatch, isStaffConfig } = this.props;
        const id = this.isCustomer || isStaffConfig ? clientId : profile.id;
        Object.keys(this.selectedVendor).forEach(item => listId.push(this.selectedVendor[item].signerId));


        dispatch(addSelectedSearchVendor({ listId, clientId: id, isCustomer: this.isCustomer }, () => {
            this.reloadListClientPreferred(id, this.state.gridCriteria, this.isCustomer);
            this.closeSearchTooltip();
        }));
    }

    componentWillReceiveProps(nextProps) {
        const { isOpen, profile } = nextProps;
        if (isOpen) {
            if (!this.isOpenModal) {
                this.isOpenModal = true;

                //get list client preferred
                const { clientId, isStaffConfig } = nextProps;
                const isCustomer = (clientId > 0);
                const id = isCustomer ? clientId : profile.id;

                this.isCustomer = isStaffConfig ? false : isCustomer;
                this.reloadListClientPreferred(id, this.state.gridCriteria, this.isCustomer);
            }
        } else {
            this.isOpenModal = false;
            this.isCustomer = false;
            this.isShowSearchTooltip = false;
            this.selectedVendor = {};
        }
    }


    handleGridViewReload(newGridCriteria) {
        const { profile, clientId, isStaffConfig } = this.props;
        let id = clientId;

        if (!this.isCustomer && !isStaffConfig) {
            id = profile.id;
        }

        this.setState({ gridCriteria: newGridCriteria });
        this.reloadListClientPreferred(id, newGridCriteria, this.isCustomer);
    }

    reloadListClientPreferred(clientId, gridCriteria, isCustomerPreferred = false) {
        const { dispatch } = this.props;

        dispatch(getListClientPreferred({ clientId, ...gridCriteria, isCustomerPreferred }));
    }

    componentDidUpdate() {
        updateTextFields();
    }

    renderMessageSelectList() {
        const { isSearchingNewList, hasSearchData } = this.state;

        if (isSearchingNewList) return "Loading...";
        if (!hasSearchData) return `Type ${this.minLengthSearch} or more characters to get suggestion`;
        return "No record found";
    }

    closeSearchTooltip() {
        this.searchTooltip.hideTooltip();
        this.setState({
            inputs: {
                searchNameText: ""
            },
            isSearchingNewList: false,
            hasSearchData: false,
            listDataSearchVendor: []
        });
        this.selectedVendor = {};
    }

    componentDidMount() {
        $("#preferred-vendors-content").scroll(() => {
            this.searchTooltip.hideTooltip();
        });
    }

    handleOnchangeOutsideVendorValue(value, fieldName) {
        const { inputs, invalidField } = this.state;

        inputs[fieldName] = value;

        if (hasStringValue(value)) {
            delete invalidField[fieldName];
        }


        this.setState({ inputs, invalidField });
    }

    handleOnblurEmailField(value, fieldName) {
        const { invalidField } = this.state;

        if (value === "") {
            delete invalidField[`${fieldName}Data`];
            this.setState({ invalidField });
            return;
        }

        if (!validateEmail(value)) {
            invalidField[`${fieldName}Data`] = true;
        } else {
            delete invalidField[`${fieldName}Data`];
        }

        this.setState({ invalidField });
    }

    validateDataVendor() {
        const { inputs } = this.state;
        const invalidField = {};

        if (!hasStringValue(inputs.firstName)) invalidField.firstName = true;
        if (!hasStringValue(inputs.lastName)) invalidField.lastName = true;
        if (!hasStringValue(inputs.email)) {
            invalidField.email = true;
        } else if (!validateEmail(inputs.email)) invalidField.emailData = true;

        if (!hasStringValue(inputs.taxId)) invalidField.taxId = true;
        const check = Object.keys(invalidField)[0];

        this.setState({ invalidField });

        if (check) {
            $(replaceAll(`#preferred-vendors-${check}`, "Data", "")).focus();
            return false;
        } else {
            return true;
        }
    }

    handleAddOutsideVendor() {
        if (!this.validateDataVendor()) {
            return;
        }

        const { dispatch, profile, clientId, isStaffConfig } = this.props;
        const { inputs } = this.state;
        let id = clientId;

        if (!this.isCustomer && !isStaffConfig) {
            id = profile.id;
        }

        const dataSent = {
            firstName: inputs.firstName,
            lastName: inputs.lastName,
            email: inputs.email,
            taxId: inputs.taxId,
            clientId: id,
            isCustomer: this.isCustomer
        };

        checkVendorIsExists(dataSent, (data) => {
            if (data.isExist) {
                this.commonModal.showModal({ type: "error", message: "This vendor has already been added in the preferred list. Please add another vendor." });
            } else {
                dispatch(addVendorOutsideTCE(dataSent, () => {
                    this.reloadListClientPreferred(id, this.state.gridCriteria, this.isCustomer);
                    this.setState({
                        inputs: {
                            ...this.state.inputs,
                            firstName: "",
                            lastName: "",
                            email: "",
                            taxId: ""
                        }
                    });
                }));
            }
        }, dispatch);
    }

    handleRemoveClientPreferred(preferredVendorId) {
        this.commonModal.showModal({ type: "confirm", message: "Are you sure you would like to delete this vendor?" },
            () => {
                const { dispatch, profile, clientId, isStaffConfig } = this.props;
                let id = clientId;

                if (!this.isCustomer && !isStaffConfig) {
                    id = profile.id;
                }

                dispatch(deletePreferredVendor({ id: preferredVendorId, isCustomer: this.isCustomer }, () => {
                    this.reloadListClientPreferred(id, this.state.gridCriteria, this.isCustomer);
                }));
            },
            () => {
            }
            , false, "Yes", "No");
    }

    render() {
        const { isOpen, toggleModal, columns, listClientPreferred } = this.props;
        const { listDataSearchVendor, isSearchingNewList, hasSearchData } = this.state;

        const renderSearchResult = (listData) => {
            const disableAddBtn = Object.keys(this.selectedVendor).length === 0;
            const renderOptions = [];

            listData.forEach((item, index) => {
                renderOptions.push(
                    <li key={index}>
                        <span>{`${item.fullName}_${item.email} `}</span>
                        <label>
                            <input type="checkbox" checked={this.selectedVendor[item.signerId] || false} onChange={(e) => this.handleSelectedSearchVendor(item, e.target.checked)} />
                            <span className="right"></span>
                        </label>
                    </li>
                );
            });
            return (
                <div className="row client-preferred-list-search">
                    <label htmlFor="">Select Vendors</label>
                    <ul>
                        {isSearchingNewList || !hasSearchData || listData.length === 0 ? <li>{this.renderMessageSelectList()}</li> : renderOptions}
                    </ul>

                    <footer>
                        <div className="row">
                            <div className="col s6">
                                <button className="btn btn-small white w-100" onClick={() => this.closeSearchTooltip()}>Cancel</button>
                            </div>
                            {!isSearchingNewList && hasSearchData && listData.length > 0 && <div className="col s6">
                                <button className="btn btn-small success-color w-100" disabled={disableAddBtn} onClick={() => this.handleAddVendorFromAutoSuggest()}>Add</button>
                            </div>}
                        </div>
                    </footer>
                </div>
            );
        };

        return (
            <div>
                < Modal isOpen={isOpen} style={{ overflowX: "hidden" }}>
                    <ModalBody style={{ height: "100%" }}>
                        <ModalTitle onClickClose={() => toggleModal()}>Select Preferred Vendors</ModalTitle>
                        <div id="preferred-vendors-content" className="tab-content pb-0">
                            <div className="row m-1">
                                <div className="col s2 mt-1"><b>TCE Vendors</b></div>
                                <div className="col s5">
                                    <input
                                        disabled={!this.props.isEditMode}
                                        maxLength={75}
                                        ref="preferredVendorsInfoSearch"
                                        type="text"
                                        id="preferred-vendors-info-search"
                                        placeholder="Enter Vendor Name/Email to add"
                                        data-event="focus click change"
                                        data-tip data-for={`client-preferred-modal-search-tooltip`}
                                        data-event-off="DoubleClick"
                                        value={this.state.inputs.searchNameText}
                                        onChange={(e) => this.handleOnchangeVendorSearchTextField(e.target.value)}
                                    />
                                </div>
                                <div className="col s2 left-align mt-1 suggest-tooltip client-preferred-fixed-left-tooltip">
                                    <i
                                        className={`lnr lnr-magnifier cursor-pointer`}
                                        style={{ fontSize: "20px" }}
                                        title="Search"
                                        data-event="focus click"
                                        data-tip data-for={`client-preferred-modal-search-tooltip`}
                                        data-event-off="DoubleClick"
                                        id="reset-tooltip-icon"
                                    ></i>
                                    <ReactTooltip
                                        ref={(node) => { this.searchTooltip = node; }}
                                        id={`client-preferred-modal-search-tooltip`}
                                        place="bottom" aria-haspopup="true" role="example" allow
                                        scrollHide
                                        getContent={[() => <div>{renderSearchResult(listDataSearchVendor)}</div>]}
                                    />
                                </div>

                                <div className="clearfix"></div>
                                <br />

                                <div className="col s12"><span>OR add other Vendors outside TCE system who you prefer to do your order</span></div>

                                <div className="clearfix"></div>
                                <br />

                                <div className="col s12"><b>Other Vendors</b></div>

                                <div className="clearfix"></div>

                                <div className={`col s3 input-field required suffixinput ${this.state.invalidField.firstName ? "required-field" : ""}`}>
                                    <input disabled={!this.props.isEditMode} type="text" maxLength={15} id="preferred-vendors-firstName" value={this.state.inputs.firstName || ""} onChange={(e) => this.handleOnchangeOutsideVendorValue(e.target.value, "firstName")} />
                                    <label htmlFor="preferred-vendors-firstName">First Name</label>
                                    {this.state.invalidField.firstName && <span className={`suffix-text`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("First Name")} />
                                    </span>}
                                </div>
                                <div className={`col s3 input-field required suffixinput ${this.state.invalidField.lastName ? "required-field" : ""}`}>
                                    <input disabled={!this.props.isEditMode} type="text" maxLength={25} id="preferred-vendors-lastName" value={this.state.inputs.lastName || ""} onChange={(e) => this.handleOnchangeOutsideVendorValue(e.target.value, "lastName")} />
                                    <label htmlFor="preferred-vendors-lastName">Last Name</label>
                                    {this.state.invalidField.lastName && <span className={`suffix-text`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Last Name")} />
                                    </span>}
                                </div>
                                <div className={`col s3 input-field required suffixinput ${this.state.invalidField.email ? "required-field" : ""} ${this.state.invalidField.emailData ? "has-error" : ""}`}>
                                    <input
                                        disabled={!this.props.isEditMode}
                                        type="text"
                                        maxLength={75}
                                        id="preferred-vendors-email"
                                        value={this.state.inputs.email || ""}
                                        onChange={(e) => this.handleOnchangeOutsideVendorValue(e.target.value, "email")}
                                        onBlur={(e) => this.handleOnblurEmailField(e.target.value, "email")}
                                    />
                                    <label htmlFor="preferred-vendors-email">Email Address</label>
                                    {this.state.invalidField.email && <span className={`suffix-text`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Email Address")} />
                                    </span>}
                                    {this.state.invalidField.emailData && <span className={`suffix-text`}>
                                        <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Email Address")} />
                                    </span>}
                                </div>
                                <div className={`col s2 input-field required suffixinput ${this.state.invalidField.taxId ? "required-field" : ""}`}>
                                    <NumbericInput disabled={!this.props.isEditMode} maxLength="50" type="text" id="preferred-vendors-taxId" value={this.state.inputs.taxId || ""} onChange={(e) => this.handleOnchangeOutsideVendorValue(e, "taxId")} />
                                    <label htmlFor="preferred-vendors-taxId">SSN/TaxID</label>
                                    {this.state.invalidField.taxId && <span className={`suffix-text`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("SSN/TaxID")} />
                                    </span>}
                                </div>
                                <div className="col s1 mt-1"><button disabled={!this.props.isEditMode} className="btn btn-small success-color action-btn" onClick={() => this.handleAddOutsideVendor()}>Add</button></div>
                                <div className="divider"></div>
                            </div>

                            <div className="row m-1">
                                <GridView
                                    criteria={this.state.gridCriteria}
                                    totalRecords={listClientPreferred.totalRecords}
                                    datasources={listClientPreferred.data} //Pass datasources
                                    columns={columns} //Pass columns array
                                    identifier={"id"} //Identifier for grid row
                                    defaultSortColumn={"firstName"} //Default sort column
                                    actions={this.props.isEditMode ? ["delete"] : undefined} //Remove if no action needed
                                    onGridViewReload={(criteria) => this.handleGridViewReload(criteria)} //Paginate changed => need reload datasource base on criteria
                                    onActionClick={(action, identifier) => this.handleRemoveClientPreferred(identifier)}
                                />
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row"><div className="col s12 m6 center-col"><button className="btn white w-100" onClick={() => toggleModal()}>Close</button></div></div>
                    </ModalFooter>
                </Modal >
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div >
        );
    }
}

SelectPreferredVendorsModal.defaultProps = {
    columns: [
        {
            title: "First Name",
            data: "firstName"
        },
        {
            title: "Last Name",
            data: "lastName"
        },
        {
            title: "Email Address",
            data: "email"
        },
        {
            title: "SSN/TaxID",
            data: "taxId",
            type: "taxId"
        },
        {
            title: "Status",
            data: "status"
        }
    ],
    defaultGridCriteria: {
        sortColumn: "firstName",
        sortDirection: false,
        page: 1,
        itemPerPage: 25
    }
};

SelectPreferredVendorsModal.propTypes = {
    isOpen: PropTypes.bool,
    toggleModal: PropTypes.func,
    defaultGridCriteria: PropTypes.object,
    columns: PropTypes.array,
    dispatch: PropTypes.func,
    clientId: PropTypes.number,
    profile: PropTypes.object,
    listClientPreferred: PropTypes.object,
    isStaffConfig: PropTypes.bool,
    isEditMode: PropTypes.bool
};

export default SelectPreferredVendorsModal;