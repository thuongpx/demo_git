import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
// import ReactTooltip from "react-tooltip";
import { Link } from "react-router";
import { GridView } from "GridView";
import { getOrdersInfoDetail } from "../actions/order-progress";
import { DASHBOARD_ITEMS_PERPAGE } from "../../../constant/constants";
import { CLIENT_SUB_ROLE } from "Constants";

class MiddleAllServiceAssigned extends Component {
    constructor(props, defaultProps) {
        super(props, defaultProps);
        this.state = {
            UncofirmedCriteria: this.getDefaultGridCriteria(),
            UncofirmedColumn: [
                { title: "", data: "OrderId", type: "orderLinkWithOrderId" },
                { title: "(Min)", data: "DurationMinute" }
            ],
            PendingDocsCriteria: this.getDefaultGridCriteria(),
            PendingDocsColumn: [
                { title: "", data: "OrderId", type: "orderLinkWithOrderId" },
                { title: "(Min)", data: "DurationMinute" }
            ],
            NeedingPreCallCriteria: this.getDefaultGridCriteria(),
            NeedingPreCallColumn: [
                { title: "", data: "OrderId", type: "orderLinkWithOrderId" },
                { title: "(Min)", data: "DurationMinute" }
            ],
            timeZone: -(new Date().getTimezoneOffset() / 60)
        };
    }

    getDefaultGridCriteria() {
        return {
            sortColumn: "OrderId",
            sortDirection: true,
            page: 1,
            itemPerPage: DASHBOARD_ITEMS_PERPAGE
        };
    }

    roleNameFinal(roles) {
        if (roles.indexOf(CLIENT_SUB_ROLE.AGENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.AGENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        if (roles.indexOf(CLIENT_SUB_ROLE.CLIENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.CLIENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        if (roles.indexOf(CLIENT_SUB_ROLE.BRANCH.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.BRANCH.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        return "";
    }

    componentDidMount() {
        const { dispatch, profile, role } = this.props;
        dispatch(getOrdersInfoDetail({ id: profile.id, role: this.roleNameFinal(role.roleNames), service: "All", statusGroup: "Assigned", ...this.getDefaultGridCriteria(), timeZone: this.state.timeZone }));
    }

    handleGridViewReload(criteria, group) {
        const { dispatch, profile, role } = this.props;

        dispatch(getOrdersInfoDetail({ ...criteria, id: profile.id, role: this.roleNameFinal(role.roleNames), service: "All", statusGroup: group, timeZone: this.state.timeZone })).then(() => {
            //update criteria
            const newCriteria = {
                sortColumn: criteria.sortColumn,
                sortDirection: criteria.sortDirection,
                page: criteria.page,
                itemPerPage: criteria.itemPerPage
            };
            switch (group) {
                case "Unconfirmed":
                    this.setState({ UncofirmedCriteria: newCriteria });
                    break;
                case "Pending Docs":
                    this.setState({ PendingDocsCriteria: newCriteria });
                    break;
                case "Needing Pre-call":
                    this.setState({ NeedingPreCallCriteria: newCriteria });
                    break;
            }
        });
    }

    render() {
        const { OrdersAllService } = this.props;
        const { UncofirmedCriteria, UncofirmedColumn } = this.state;
        const { PendingDocsCriteria, PendingDocsColumn } = this.state;
        const { NeedingPreCallCriteria, NeedingPreCallColumn } = this.state;

        return (
            <div className="row alert-section-mobile pagination-style small-col">
                <div className="col s12 m4 card alert-section p-1 unfilled Orders box-shadow-none card-dashboard">
                    <span className="card-title truncate"><Link to="/view-orders-progress/Unconfirmed">Unconfirmed</Link></span>
                    <a href="#" className="more-option">
                        <i className="ti ti-more"></i>
                    </a>
                    <div className="divider"></div>
                    <ul className="alert-list client-list-dashboard">
                        <li className="mb-1">
                            <div className="row">
                                <div className="col s12">
                                    <GridView
                                        criteria={UncofirmedCriteria}
                                        totalRecords={OrdersAllService.UnconfirmedOrdersTotal}
                                        datasources={OrdersAllService.UnconfirmedOrders}
                                        columns={UncofirmedColumn}
                                        identifier={"OrderId"}
                                        allowSorting={false}
                                        onGridViewReload={(e) => this.handleGridViewReload(e, "Unconfirmed")}
                                    />
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>

                <div className="col s12 m4 card alert-section p-1 unfilled Orders box-shadow-none card-dashboard">
                    <span className="card-title truncate"><Link to="/view-orders-progress/Pending Docs">Pending Docs</Link></span>
                    <a href="#" className="more-option">
                        <i className="ti ti-more"></i>
                    </a>
                    <div className="divider"></div>
                    <ul className="alert-list client-list-dashboard">
                        <li className="mb-1">
                            <div className="row">
                                <div className="col s12">
                                    <GridView
                                        criteria={PendingDocsCriteria}
                                        totalRecords={OrdersAllService.PendingDocsOrdersTotal}
                                        datasources={OrdersAllService.PendingDocsOrders}
                                        columns={PendingDocsColumn}
                                        identifier={"OrderId"}
                                        allowSorting={false}
                                        onGridViewReload={(e) => this.handleGridViewReload(e, "Pending Docs")}
                                    />
                                </div>

                            </div>
                        </li>
                    </ul>
                </div>

                <div className="col s12 m4 card alert-section p-1 unfilled Orders box-shadow-none card-dashboard">
                    <span className="card-title truncate"><Link to="/view-orders-progress/Needing Pre-call">Needing Pre-call</Link></span>
                    <a href="#" className="more-option">
                        <i className="ti ti-more"></i>
                    </a>
                    <div className="divider"></div>
                    <ul className="alert-list client-list-dashboard">
                        <li className="mb-1">
                            <div className="row">
                                <div className="col s12">
                                    <GridView
                                        criteria={NeedingPreCallCriteria}
                                        totalRecords={OrdersAllService.NeedingPreCallOrdersTotal}
                                        datasources={OrdersAllService.NeedingPreCallOrders}
                                        columns={NeedingPreCallColumn}
                                        identifier={"OrderId"}
                                        allowSorting={false}
                                        onGridViewReload={(e) => this.handleGridViewReload(e, "Needing Pre-call")}
                                    />
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        );
    }
}

MiddleAllServiceAssigned.propTypes = {
    dispatch: PropTypes.func,
    profile: PropTypes.object,
    role: PropTypes.object,
    onToggleOrderSection: PropTypes.func,
    onToggleFullSection: PropTypes.func,
    onChangeViewAlert: PropTypes.func,
    OrdersAllService: PropTypes.object
};

const mapStateToProps = (state) => {
    const { authentication, clientDashboard } = state;
    const { profile, role } = authentication;
    const { OrdersAllService } = clientDashboard.ordersInfo;

    return {
        profile,
        role,
        OrdersAllService
    };

};
export default connect(mapStateToProps)(MiddleAllServiceAssigned);