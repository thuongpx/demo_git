import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
// import ReactTooltip from "react-tooltip";
import { Link } from "react-router";
import { GridView } from "GridView";
import { getOrdersInfoDetail } from "../actions/order-progress";
import { DASHBOARD_ITEMS_PERPAGE } from "../../../constant/constants";
import { CLIENT_SUB_ROLE } from "Constants";

class MiddleSelfServiceDidNotClose extends Component {
    constructor(props, defaultProps) {
        super(props, defaultProps);
        this.state = {
            CanceledByClientCriteria: this.getDefaultGridCriteria(),
            CanceledByClientColumn: [
                { title: "", data: "OrderId", type: "orderLinkWithOrderId" },
                { title: "(Min)", data: "DurationMinute" }
            ],
            UnsuccessfulCriteria: this.getDefaultGridCriteria(),
            UnsuccessfulColumn: [
                { title: "", data: "OrderId", type: "orderLinkWithOrderId" },
                { title: "(Min)", data: "DurationMinute" }
            ],
            PlacedOnHoldCriteria: this.getDefaultGridCriteria(),
            PlacedOnHoldColumn: [
                { title: "", data: "OrderId", type: "orderLinkWithOrderId" },
                { title: "(Min)", data: "DurationMinute" }
            ],
            timeZone: -(new Date().getTimezoneOffset() / 60)
        };
    }

    getDefaultGridCriteria() {
        return {
            sortColumn: "OrderId",
            sortDirection: true,
            page: 1,
            itemPerPage: DASHBOARD_ITEMS_PERPAGE
        };
    }

    roleNameFinal(roles) {
        if (roles.indexOf(CLIENT_SUB_ROLE.AGENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.AGENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        if (roles.indexOf(CLIENT_SUB_ROLE.CLIENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.CLIENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        if (roles.indexOf(CLIENT_SUB_ROLE.BRANCH.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.BRANCH.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        return "";
    }

    componentDidMount() {
        const { dispatch, profile, role } = this.props;
        dispatch(getOrdersInfoDetail({ id: profile.id, role: this.roleNameFinal(role.roleNames), service: "Self", statusGroup: "Did Not Close", ...this.getDefaultGridCriteria(), timeZone: this.state.timeZone }));
    }

    resetGridCriteria() {
        this.setState({
            CanceledByClientCriteria: this.getDefaultGridCriteria(),
            UnsuccessfulCriteria: this.getDefaultGridCriteria(),
            PlacedOnHoldCriteria: this.getDefaultGridCriteria()
        });
    }

    handleGridViewReload(criteria, group) {
        const { dispatch, profile, role } = this.props;

        dispatch(getOrdersInfoDetail({ ...criteria, id: profile.id, role: this.roleNameFinal(role.roleNames), service: "Self", statusGroup: group, timeZone: this.state.timeZone })).then(() => {
            //update criteria
            const newCriteria = {
                sortColumn: criteria.sortColumn,
                sortDirection: criteria.sortDirection,
                page: criteria.page,
                itemPerPage: criteria.itemPerPage
            };
            switch (group) {
                case "Canceled By Client":
                    this.setState({ CanceledByClientCriteria: newCriteria });
                    break;
                case "Unsuccessful":
                    this.setState({ UnsuccessfulCriteria: newCriteria });
                    break;
                case "Placed On Hold":
                    this.setState({ PlacedOnHoldCriteria: newCriteria });
                    break;
            }
        });
    }

    render() {
        const { OrdersSelfService, isShowPlacedOnHold } = this.props;
        const { CanceledByClientCriteria, CanceledByClientColumn } = this.state;
        const { UnsuccessfulCriteria, UnsuccessfulColumn } = this.state;
        const { PlacedOnHoldCriteria, PlacedOnHoldColumn } = this.state;

        return (
            <div className="row alert-section-mobile pagination-style small-col">
                <div className="col s12 m4 card alert-section p-1 unfilled Orders box-shadow-none card-dashboard">
                    <span className="card-title truncate">
                        <Link to="/view-orders-progress/Self-Service - Canceled By Client">Canceled by Client (MTD)</Link>
                    </span>
                    <a href="#" className="more-option">
                        <i className="ti ti-more"></i>
                    </a>
                    <div className="divider"></div>
                    <ul className="alert-list client-list-dashboard">
                        <li className="mb-1">
                            <div className="row">
                                <div className="col s12">
                                    <GridView
                                        criteria={CanceledByClientCriteria}
                                        totalRecords={OrdersSelfService.CanceledByClientOrdersTotal}
                                        datasources={OrdersSelfService.CanceledByClientOrders}
                                        columns={CanceledByClientColumn}
                                        identifier={"OrderId"}
                                        allowSorting={false}
                                        onGridViewReload={(e) => this.handleGridViewReload(e, "Canceled By Client")}
                                    />
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>

                <div className="col s12 m4 card alert-section p-1 unfilled Orders box-shadow-none card-dashboard">
                    <span className="card-title truncate">
                        <Link to="/view-orders-progress/Self-Service - Unsuccessful">Unsuccessful (MTD)</Link>
                    </span>
                    <a href="#" className="more-option">
                        <i className="ti ti-more"></i>
                    </a>
                    <div className="divider"></div>
                    <ul className="alert-list client-list-dashboard">
                        <li className="mb-1">
                            <div className="row">
                                <div className="col s12">
                                    <GridView
                                        criteria={UnsuccessfulCriteria}
                                        totalRecords={OrdersSelfService.UnsuccessfulOrdersTotal}
                                        datasources={OrdersSelfService.UnsuccessfulOrders}
                                        columns={UnsuccessfulColumn}
                                        identifier={"OrderId"}
                                        allowSorting={false}
                                        onGridViewReload={(e) => this.handleGridViewReload(e, "Unsuccessful")}
                                    />
                                </div>

                            </div>
                        </li>
                    </ul>
                </div>
                {isShowPlacedOnHold &&
                    <div className="col s12 m4 card alert-section p-1 unfilled Orders box-shadow-none card-dashboard">
                        <span className="card-title truncate">
                            <Link to="/view-orders-progress/Self-Service - Placed On Hold">Placed on Hold (MTD)</Link>
                        </span>
                        <a href="#" className="more-option">
                            <i className="ti ti-more"></i>
                        </a>
                        <div className="divider"></div>
                        <ul className="alert-list client-list-dashboard">
                            <li className="mb-1">
                                <div className="row">
                                    <div className="col s12">
                                        <GridView
                                            criteria={PlacedOnHoldCriteria}
                                            totalRecords={OrdersSelfService.PlacedOnHoldOrdersTotal}
                                            datasources={OrdersSelfService.PlacedOnHoldOrders}
                                            columns={PlacedOnHoldColumn}
                                            identifier={"OrderId"}
                                            allowSorting={false}
                                            onGridViewReload={(e) => this.handleGridViewReload(e, "Placed On Hold")}
                                        />
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>}

            </div>
        );
    }
}

MiddleSelfServiceDidNotClose.propTypes = {
    dispatch: PropTypes.func,
    profile: PropTypes.object,
    role: PropTypes.object,
    onToggleOrderSection: PropTypes.func,
    onToggleFullSection: PropTypes.func,
    onChangeViewAlert: PropTypes.func,
    OrdersSelfService: PropTypes.object,
    isShowPlacedOnHold: PropTypes.bool
};

const mapStateToProps = (state) => {
    const { authentication, clientDashboard } = state;
    const { profile, role } = authentication;
    const { OrdersSelfService } = clientDashboard.ordersInfo;
    const { isShowPlacedOnHold } = clientDashboard.ClientDashboardOrder;

    return {
        profile,
        role,
        OrdersSelfService,
        isShowPlacedOnHold
    };

};
export default connect(mapStateToProps)(MiddleSelfServiceDidNotClose);