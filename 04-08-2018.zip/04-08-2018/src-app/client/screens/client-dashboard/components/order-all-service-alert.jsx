import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { displayIntervalTimeForNotifications, openNewTab } from "../../../helpers/common-helper";
import { APP_URL } from "Config/config";
import gridViewStyle from "Styles/gridview.css";
import { handleApiError } from "../../../helpers/error-handler";
import { emitReloadAlert, listenReloadAlert, stopListenReloadAlert } from "../../../socket/notification";
import { markAsRead } from "../../main-layout/actions";
import { apiGetPositionAlert, apiGetAllDataAlert } from "../../../api/order-progress-api";

class OrderAllServiceAlert extends Component {
    constructor(props) {
        super(props);
        this.state = {
            listAllProgressLog: {
                dataAlert: [],
                dataTotalRecords: 0
            },
            count: 0,
            criteria: {
                page: 1,
                itemPerPage: 5
            },
            positionFocusOfAlert: 0
        };

        window.reloadDashboard = () => {
            this.reload();
        };
    }

    reload() {
        const { profile, roleNames, accountId } = this.props;
        const { criteria } = this.state;
        const role = roleNames[0];
        const userId = profile.id;
        const isSelfService = null;

        apiGetAllDataAlert(criteria, role, userId, accountId, isSelfService, (response) => {
            this.setState({ listAllProgressLog: response.data });
        }, (error) => handleApiError(this.props.dispatch, error));
    }

    componentWillMount() {
        this.reload();

        setInterval(() => {
            const { count } = this.state;
            this.setState({ count: count > 10 ? 0 : count + 1 });
        }, 60000);
    }

    handleClickMaskAsRead(isRead, progressLogId) {
        const { dispatch } = this.props;
        const data = {
            isMarkAsRead: (!isRead ? 1 : 0),
            ProgressLogId: progressLogId
        };

        dispatch(markAsRead(data, () => {
            this.setState({ positionFocusOfAlert: 0 }, () => {
                this.reload();

                const { profile, roleNames } = this.props;
                const role = roleNames[0];
                const userId = profile.id;
                emitReloadAlert({ userId, role });
            });
        }, (error) => {
            handleApiError(this.props.dispatch, error);
        }));
    }

    componentDidMount() {
        listenReloadAlert(data => {
            const { profile, roleNames, accountId } = this.props;
            const role = roleNames[0];
            const userId = profile.id;
            const isSelfService = null;

            if (data.role === role && data.userId === userId && data.progressLogId) {
                const alertId = data.progressLogId;
                apiGetPositionAlert({ role, userId, alertId, accountId, isSelfService }, (response) => {
                    //eslint-disable-next-line
                    this.setState({ positionFocusOfAlert: data.progressLogId }, () => {
                        this.handlePaginateChanged(response.data.page, this.state.criteria.itemPerPage);
                        this.refs.page.value = response.data.page;
                    });
                }, err => handleApiError(this.props.dispatch, err));
            }
        });
    }

    componentWillUnmount() {
        stopListenReloadAlert();
        if (window.listenAlert) window.listenAlert();
        delete window.reloadDashboard;
    }

    handlePaginateChanged(page, itemPerPage) {
        this.setState({
            criteria: {
                page,
                itemPerPage
            }
        }, () => this.reload());
    }

    handleOnBlurPageNumber(value) {
        const { listAllProgressLog, criteria } = this.state;
        const { itemPerPage } = criteria;
        const { dataTotalRecords } = listAllProgressLog;
        const totalPages = Math.ceil(dataTotalRecords / itemPerPage);
        let pageNumber = 1;

        if (!isNaN(value)) {
            pageNumber = Number(value);
            if (pageNumber > totalPages) pageNumber = totalPages;
            if (pageNumber < 1) pageNumber = 1;
        } else {
            pageNumber = 1;
        }

        this.handlePaginateChanged(pageNumber, itemPerPage);
        this.refs.page.value = pageNumber;
    }

    render() {
        const { listAllProgressLog, criteria } = this.state;
        const { dataTotalRecords } = listAllProgressLog;
        const { page, itemPerPage } = criteria;
        const firstPageClassName = (dataTotalRecords === 0 || page === 1) ? gridViewStyle.disabled : "";
        const previousPageClassName = firstPageClassName;
        const totalPages = Math.ceil(dataTotalRecords / itemPerPage);
        const nextPageClassName = (dataTotalRecords === 0 || page === totalPages) ? gridViewStyle.disabled : "";
        const lastPageClassName = nextPageClassName;

        const renderListAlerts = () => {
            if (!dataTotalRecords) {
                return <div className="center-align p-4">There are no records to show.</div>;
            }
            return (
                listAllProgressLog.dataAlert.map((item, index) => {
                    const isRead = item.isRead;
                    const progressLogId = item.progressLogId;
                    const IsSelfService = item.IsSelfService;
                    return (
                        <li key={index} className={`${!isRead ? "unread" : ""} ${progressLogId === this.state.positionFocusOfAlert ? "new" : ""} ${IsSelfService ? "is-self-service" : ""}`} onClick={!isRead ? () => this.handleClickMaskAsRead(isRead, progressLogId) : () => { this.setState({ positionFocusOfAlert: 0 }); }}>
                            <div className={`left ${!isRead ? "bold-5" : ""}`}>Order<a onClick={() => openNewTab(`${APP_URL}/order-detail/${item.orderId}`)}>{` ${item.orderId}`}</a>
                            </div>

                            <div className="clear"></div>
                            <div className={`left ${!isRead ? "bold-5" : ""}`}>
                                <p title={item.activity}>{item.activity}</p>
                            </div>

                            <div className="clear"></div>
                            <small className={`${!isRead ? "bold-5" : ""}`} title="Change Time">{displayIntervalTimeForNotifications(item.DateLog || "")}</small>
                        </li >
                    );
                })
            );
        };
        const renderGridPaginate = () => {
            if (!dataTotalRecords) {
                return <div></div>;
            }
            return (
                <div className="row mt-1 mb-0 pagination">
                    <div className="col s12 m12 pb-0" style={{ position: "relative" }}>
                        <div className="left left-bar">
                            <ul className={`${gridViewStyle.pagination} clearfix m-0`} style={{ padding: "0" }}>
                                <li title="First Page" className="paginate-alert">
                                    <a style={{ cursor: "pointer" }} className={firstPageClassName} onClick={() => {
                                        this.refs.page.value = 1;
                                        this.handlePaginateChanged(1, itemPerPage);
                                    }}>
                                        <span className="ti-angle-double-left"></span>
                                    </a>
                                </li>
                                <li title="Previous Page" className="paginate-alert" style={{ left: "50px" }}>
                                    <a style={{ cursor: "pointer" }} className={previousPageClassName} onClick={() => {
                                        this.refs.page.value = page - 1;
                                        this.handlePaginateChanged(page - 1, itemPerPage);
                                    }}>
                                        <span className="ti-angle-left"></span>
                                    </a>
                                </li>
                                <li className="paginate-alert page-alert" style={{ left: "90px", background: "none" }}>
                                    <div className="clearfix page-input">
                                        Page <input className={`${gridViewStyle["txt-page-number"]} validate valid`} type="text" ref="page" id="txt-page-number" defaultValue={page} onBlur={(e) => this.handleOnBlurPageNumber(e.target.value)} /> of {totalPages}
                                    </div>
                                </li>
                                <li title="Next Page" className="paginate-alert" style={{ left: "85px" }}>
                                    <a style={{ cursor: "pointer" }} className={nextPageClassName} onClick={() => {
                                        this.refs.page.value = page + 1;
                                        this.handlePaginateChanged(page + 1, itemPerPage);
                                    }}>
                                        <span className="ti-angle-right"></span>
                                    </a>
                                </li>
                                <li title="Last Page" className="paginate-alert" style={{ left: "135px" }}>
                                    <a style={{ cursor: "pointer" }} className={lastPageClassName} onClick={() => {
                                        this.refs.page.value = totalPages;
                                        this.handlePaginateChanged(totalPages, itemPerPage);
                                    }}>
                                        <span className="ti-angle-double-right"></span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div >
            );
        };
        return (
            <div className="col s12 m2 card alert-section p-1 box-shadow-none card-dashboard alert-section-mobile pagination-style" >
                <div className="wrap-alert">
                    <span className="card-title red-color">Alerts</span>
                    <div className="divider"></div>
                    <ul className="alert-list">
                        {renderListAlerts()}
                    </ul>
                    <div className="divider"></div>
                    {renderGridPaginate()}
                </div>
            </div>
        );
    }
}

OrderAllServiceAlert.propTypes = {
    dispatch: PropTypes.func,
    profile: PropTypes.object,
    roleType: PropTypes.string,
    accountId: PropTypes.number,
    roleNames: PropTypes.array
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { isAuthenticated, profile, role, userId, accountId } = authentication;

    return {
        isAuthenticated,
        profile,
        roleType: role ? role.roleType : null,
        roleNames: role ? role.roleNames : [],
        userId,
        accountId
    };
};

export default connect(mapStateToProps)(OrderAllServiceAlert);