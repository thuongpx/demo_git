import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import {
    Modal,
    ModalTitle,
    ModalBody
} from "Modal";

class WelcomeModal extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isOpen: false,
            validator: {},
            signer: {},
            isDirty: false
        };
    }

    show() {
        this.setState({ isOpen: true });
    }

    render() {
        const { isOpen } = this.state;
        const { profile } = this.props;
        return (
            <div>
                <div id="basic-information-vendor-modal" className="text-center">
                    <Modal isOpen={isOpen} addClass="no-tab">
                        <ModalBody>
                            <ModalTitle onClickClose={() => { this.setState({ isOpen: false }); }}>
                                <div>
                                    Welcome to The Closing Exchange
                                </div>
                            </ModalTitle>
                            <div className="tab-content" style={{ height: "100%" }}>
                                <div className="row mt-2">
                                    <span>Hi {profile.firstName} - Thanks for signing up. We're excited to have you.</span>
                                </div>
                                <div className="row mt-2 pl-5 pr-5">
                                    <span>In order to serve you best, we'll need to learn more about where vendors send their documents as well as understand your signing preferences</span>
                                </div>
                                <div className="row mt-2 text-left">
                                    <div className="col s2"></div>
                                    <div className="col s8">
                                        <button className="text-left btn action-btn success-color w-100" onClick={() => {
                                            if (this.props.onSendInvite) {
                                                this.setState({ isOpen: false });
                                                this.props.onSendInvite();
                                            }
                                        }}> Send some invites! </button>
                                        <i style={{ display: "block", margin: "5px" }}>
                                            Add sub-administrator or agents to your team.
                                        </i>
                                    </div>
                                    <div className="col s2"></div>
                                </div>
                                <div className="row mt-2 text-left">
                                    <div className="col s2"></div>
                                    <div className="col s8">
                                        <button className="text-left btn action-btn success-color w-100" onClick={() => {
                                            if (this.props.onSetMiscellaneous) {
                                                this.props.onSetMiscellaneous();
                                            }
                                        }}> Set miscellaneous info!</button>
                                        <i style={{ display: "block", margin: "5px" }}>
                                            This information lets us know what to expect when providing our services to you.
                                        </i>
                                    </div>
                                    <div className="col s2"></div>
                                </div>
                            </div>
                        </ModalBody>

                    </Modal>

                </div>
            </div >
        );
    }
}

WelcomeModal.propTypes = {
    dispatch: PropTypes.func,
    isOpen: PropTypes.bool,
    columns: PropTypes.array,
    router: PropTypes.object,
    profile: PropTypes.object,
    onSetMiscellaneous: PropTypes.func,
    onSendInvite: PropTypes.func
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { profile } = authentication;

    return {
        profile
    };

};

export default connect(mapStateToProps, null, null, { withRef: true })(WelcomeModal);
