import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import ReactTooltip from "react-tooltip";
import CommonModal from "CommonModal";
import moment from "moment";
import { Link } from "react-router";
//will be changed to Full service
import MiddleFullServiceOpen from "./middle-full-service-open";
import MiddleFullServiceAssigned from "./middle-full-service-assigned";
import MiddleFullServiceApptReady from "./middle-full-service-appt-ready";
import MiddleFullServiceClosedPending from "./middle-full-service-closed-pending";
import MiddleFullServiceClosingComplete from "./middle-full-service-closing-complete";
import MiddleFullServiceDidNotClose from "./middle-full-service-did-not-close";
import { toggleConfiguration, togglePlaceOnHold } from "../actions/client-dashboard-order";

class OrderFullService extends Component {
    constructor(props, defaultProps) {
        super(props, defaultProps);

        this.state = {
            middleWindow: "Open"
        };
    }

    componentDidMount() {
    }

    componentDidUpdate() {
    }

    changeMiddleWindow(middleWindow) {
        this.setState({ middleWindow });
    }

    renderMiddleWindow() {
        switch (this.state.middleWindow) {
            case "Open": return <MiddleFullServiceOpen />;
            case "Assigned": return <MiddleFullServiceAssigned />;
            case "Appt Ready": return <MiddleFullServiceApptReady />;
            case "Closed Pending": return <MiddleFullServiceClosedPending />;
            case "Closing Complete": return <MiddleFullServiceClosingComplete />;
            case "Did Not Close": return <MiddleFullServiceDidNotClose />;
            default: return <MiddleFullServiceOpen />;
        }
    }

    handleOpenConfiguration() {
        const { dispatch } = this.props;

        dispatch(toggleConfiguration(true));
    }

    handleAddRemovePlacedOnHold(action) {
        const { dispatch } = this.props;
        if (action === "Remove") {
            this.commonModal.showModal({
                type: "confirm",
                message: "Are you sure you would like to remove Placed on Hold field from the dashboard?"
            }, () => {
                dispatch(togglePlaceOnHold(false));
            }, () => {
                return;
            });
        } else {
            this.commonModal.showModal({
                type: "confirm",
                message: "Are you sure you would like to add Placed on Hold field to the dashboard?"
            }, () => {
                dispatch(togglePlaceOnHold(true));
            }, () => {
                return;
            });
        }
    }
    render() {
        const { OrdersFullService, isShowPlacedOnHold, UserMTD } = this.props;
        return (
            <div className="col s12 m6 full-service-section">
                <div className="row ">
                    <div className="col s12  pos-rel">
                        <h3 className="title-page-detail">
                            My Orders (Full-Service)
                        </h3>
                        <span id="warning-alert-full-service" className="lnr lnr-warning small-lnr-btn-warning" data-tip data-for="tootltip-alert-full-service"
                            onClick={() => this.props.onChangeViewAlert()}
                        ></span>
                        <ReactTooltip id="tootltip-alert-full-service" aria-haspopup="true">
                            <p id="p-tootltip-alert-full-service">See Alerts of Full-Service Orders</p>
                        </ReactTooltip>
                        <span id="switchSection-full-service"
                            className="lnr lnr-sync"
                            onClick={() => this.props.onToggleOrderSection()}
                        >
                        </span>
                        <span id="toggleSection-full-service"
                            className="lnr lnr-frame-expand" data-tip data-for="tootltip-toggleSection-full-service"
                            onClick={() => this.props.onToggleFullSection("full", "toggleSection-full-service")}
                        >
                        </span>
                        <ReactTooltip id="tootltip-toggleSection-full-service" aria-haspopup="true">
                            <p id="p-tootltip-toggleSection-full-service">See Full-Screen view for Full-Service Orders</p>
                        </ReactTooltip>
                    </div>
                    <div className="col s12 m4 pl-custome custome-widthdash">
                        <div className={`card-panel white box-shadow-none border-style-dashboard ${this.state.middleWindow === "Open" && `active`}`}>
                            <span className="card-title truncate " title="Open" onClick={() => this.changeMiddleWindow("Open")}>Open
                                <span data-tip data-for="tootltip-open-self-service" className="lnr lnr-question-circle right primary-color "></span>
                                <ReactTooltip id="tootltip-open-self-service" aria-haspopup="true">
                                    <p style={{ whiteSpace: "pre-line" }}>This area shows you all orders that are awaiting some attention.</p>
                                </ReactTooltip>
                            </span>
                            <div className="divider"></div>
                            <p className="number truncate"><Link to="/view-orders-progress/Full-Service - Open">{OrdersFullService.OpenFullService}</Link></p>
                            <p className={`number truncate ${OrdersFullService.OpenSLAApproachingFullService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Full-Service - Open Approaching SLA">{OrdersFullService.OpenSLAApproachingFullService} approaching SLA</Link></p>
                            <p className={`number truncate ${OrdersFullService.OpenSLAOutOfFullService > 0 && "red-color"}`}><Link to="/view-orders-progress/Full-Service - Open Out of SLA">{OrdersFullService.OpenSLAOutOfFullService} out of SLA</Link></p>
                        </div>
                    </div>
                    <div className="col s12 m4 custome-widthdash">
                        <div className={`card-panel white box-shadow-none border-style-dashboard ${this.state.middleWindow === "Assigned" && `active`}`}>
                            <span className="card-title truncate " title="Assigned" onClick={() => this.changeMiddleWindow("Assigned")}>Assigned
                                <span data-tip data-for="tootltip-assigned-self-service" className="lnr lnr-question-circle right primary-color "></span>
                                <ReactTooltip id="tootltip-assigned-self-service" aria-haspopup="true">
                                    <p style={{ whiteSpace: "pre-line" }}>This area shows all of the orders that have been assigned to a vendor.</p>
                                </ReactTooltip>
                            </span>
                            <div className="divider"></div>
                            <p className="number truncate"><Link to="/view-orders-progress/Full-Service - Unconfirmed">{OrdersFullService.UnconfirmedFullService} unconfirmed.</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.UnconfirmedSLAApproachingFullService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Full-Service - Unconfirmed Approaching SLA">{OrdersFullService.UnconfirmedSLAApproachingFullService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.UnconfirmedSLAOutOfFullService > 0 && "red-color"}`}><Link to="/view-orders-progress/Full-Service - Unconfirmed Out of SLA">{OrdersFullService.UnconfirmedSLAOutOfFullService} out of SLA</Link></p>
                            <p className="number truncate"><Link to="/view-orders-progress/Full-Service - Pending Docs">{OrdersFullService.PendingDocsFullService} pending docs</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.PendingDocsSLAApproachingFullService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Full-Service - Pending Docs Approaching SLA">{OrdersFullService.PendingDocsSLAApproachingFullService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.PendingDocsSLAOutOfFullService > 0 && "red-color"}`}><Link to="/view-orders-progress/Full-Service - Pending Docs Out of SLA">{OrdersFullService.PendingDocsSLAOutOfFullService} out of SLA</Link></p>
                            <p className="number truncate"><Link to="/view-orders-progress/Full-Service - Needing Pre-call">{OrdersFullService.NeedingPreCallFullService} needing pre-call</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.NeedingPreCallSLAApproachingFullService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Full-Service - Needing Pre-call Approaching SLA">{OrdersFullService.NeedingPreCallSLAApproachingFullService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.NeedingPreCallSLAOutOfFullService > 0 && "red-color"}`}><Link to="/view-orders-progress/Full-Service - Needing Pre-call Out of SLA">{OrdersFullService.NeedingPreCallSLAOutOfFullService} out of SLA</Link></p>
                        </div>
                    </div>
                    <div className="col s12 m4 custome-widthdash">
                        <div className={`card-panel white box-shadow-none border-style-dashboard ${this.state.middleWindow === "Appt Ready" && `active`}`}>
                            <span className="card-title truncate " title="Appt Ready" onClick={() => this.changeMiddleWindow("Appt Ready")}>Appt Ready
                                <span data-tip data-for="tootltip-appt-ready-self-service" className="lnr lnr-question-circle right primary-color "></span>
                                <ReactTooltip id="tootltip-appt-ready-self-service" aria-haspopup="true" data-html>
                                    <p style={{ whiteSpace: "pre-line" }}>This area will display all orders that are confirmed, docs are ready and vendor is ready to go!</p>
                                </ReactTooltip>
                            </span>
                            <div className="divider"></div>
                            <p className="number truncate"><Link to="/view-orders-progress/Full-Service - Appointment Ready">{OrdersFullService.ApptReadyFullService}</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.ApptReadySLAApproachingFullService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Full-Service - Appointment Ready Approaching SLA">{OrdersFullService.ApptReadySLAApproachingFullService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.ApptReadySLAOutOfFullService > 0 && "red-color"}`}><Link to="/view-orders-progress/Full-Service - Appointment Ready post schedule time">{OrdersFullService.ApptReadySLAOutOfFullService} post schedule time</Link></p>
                        </div>
                    </div>
                    <div className="col s12 m4 pl-custome custome-widthdash">
                        <div className={`card-panel white box-shadow-none border-style-dashboard ${this.state.middleWindow === "Closed Pending" && `active`}`}>
                            <span className="card-title truncate " title="Closed Pending" onClick={() => this.changeMiddleWindow("Closed Pending")}>Closed Pending
                                <span data-tip data-for="tootltip-closed-pending-self-service" className="lnr lnr-question-circle right primary-color "></span>
                                <ReactTooltip id="tootltip-closed-pending-self-service" aria-haspopup="true" data-html>
                                    <p style={{ whiteSpace: "pre-line" }}>These orders have been submitted as closed, but need a bit more attention.</p>
                                </ReactTooltip>
                            </span>
                            <div className="divider"></div>
                            <p className="number truncate"><Link to="/view-orders-progress/Full-Service - Pending Review PC">{OrdersFullService.PendingReviewPCFullService} Pending Review/PC</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.PendingReviewPCSLAApproachingFullService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Full-Service - Pending Review PC Approaching SLA">{OrdersFullService.PendingReviewPCSLAApproachingFullService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.PendingReviewPCSLAOutOfFullService > 0 && "red-color"}`}><Link to="/view-orders-progress/Full-Service - Pending Review PC Out of SLA">{OrdersFullService.PendingReviewPCSLAOutOfFullService} out of SLA</Link></p>
                            <p className={`number truncate `}><Link to="/view-orders-progress/Full-Service - Awaiting Scanbacks">{OrdersFullService.AwaitingScanbacksFullService} Awaiting Scanbacks</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.AwaitingScanbacksSLAApproachingFullService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Full-Service - Awaiting Scanbacks Approaching SLA">{OrdersFullService.AwaitingScanbacksSLAApproachingFullService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.AwaitingScanbacksSLAOutOfFullService > 0 && "red-color"}`}><Link to="/view-orders-progress/Full-Service - Awaiting Scanbacks Out of SLA">{OrdersFullService.AwaitingScanbacksSLAOutOfFullService} out of SLA</Link></p>
                            <p className="number truncate"><Link to="/view-orders-progress/Full-Service - Pending QC Review">{OrdersFullService.PendingQCReviewFullService} Pending QC Review</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.PendingQCReviewSLAApproachingFullService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Full-Service - Pending QC Review Approaching SLA">{OrdersFullService.PendingQCReviewSLAApproachingFullService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.PendingQCReviewSLAOutOfFullService > 0 && "red-color"}`}><Link to="/view-orders-progress/Full-Service - Pending QC Review Out of SLA">{OrdersFullService.PendingQCReviewSLAOutOfFullService} out of SLA</Link></p>
                        </div>
                    </div>
                    <div className="col s12 m4 custome-widthdash">
                        <div className={`card-panel white box-shadow-none border-style-dashboard ${this.state.middleWindow === "Closing Complete" && `active`}`}>
                            <span className="card-title truncate " title="Closing Complete" onClick={() => this.changeMiddleWindow("Closing Complete")}>Closing Complete
                                <span data-tip data-for="tootltip-closing-complete-self-service" className="lnr lnr-question-circle right primary-color "></span>
                                <ReactTooltip id="tootltip-closing-complete-self-service" aria-haspopup="true">
                                    <p style={{ whiteSpace: "pre-line" }}>Displaying all closed orders month to date and orders requiring Post Close work.</p>
                                </ReactTooltip>
                            </span>
                            <div className="divider"></div>
                            <p className="number" title={`Closed ${UserMTD.period ? `${UserMTD.period}` : `from ${moment(UserMTD.fromDate).format("MM/DD/YYYY").toString()} to ${moment(UserMTD.toDate).format("MM/DD/YYYY").toString()}`}`}>
                                <Link to="/view-orders-progress/Full-Service - Closed">{OrdersFullService.ClosedMTDFullService} closed {UserMTD.period && `${UserMTD.period}`}</Link>
                                <button style={{
                                    background: "transparent",
                                    border: "none",
                                    marginTop: "4px",
                                    marginLeft: "10px",
                                    padding: "0"
                                }}
                                    onClick={() => this.handleOpenConfiguration()}
                                >
                                    <span className="lnr lnr-menu-circle  primary-color"></span>
                                </button>
                            </p>
                            <p className="number truncate"><Link to="/view-orders-progress/Full-Service - Post Close Issue">{OrdersFullService.PostCloseIssueFullService} post close issue</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.PostCloseIssueSLAApproachingFullService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Full-Service - Post Close Issue Approaching SLA">{OrdersFullService.PostCloseIssueSLAApproachingFullService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersFullService.PostCloseIssueSLAOutOfFullService > 0 && "red-color"}`}><Link to="/view-orders-progress/Full-Service - Post Close Issue Out of SLA">{OrdersFullService.PostCloseIssueSLAOutOfFullService} out of SLA</Link></p>
                        </div>
                    </div>
                    <div className="col s12 m4 custome-widthdash">
                        <div className={`card-panel white box-shadow-none border-style-dashboard ${this.state.middleWindow === "Did Not Close" && `active`}`}>
                            <span className="card-title truncate " title="Did Not Close" onClick={() => this.changeMiddleWindow("Did Not Close")}>Did Not Close
                                <span data-tip data-for="tootltip-did-not-close-self-service" className="lnr lnr-question-circle right primary-color "></span>
                                <ReactTooltip id="tootltip-did-not-close-self-service" aria-haspopup="true">
                                    <p style={{ whiteSpace: "pre-line" }}>Displaying all orders that were canceled or did not close successfully month to date.</p>
                                </ReactTooltip>
                            </span>
                            <div className="divider"></div>
                            <p className="number truncate"><Link to="/view-orders-progress/Full-Service - Canceled By Client">{OrdersFullService.CanceledByClientMTDFullService} canceled by client</Link></p>
                            <p className="number truncate"><Link to="/view-orders-progress/Full-Service - Unsuccessful">{OrdersFullService.UnsuccessfulMTDFullService} unsuccessful</Link></p>
                            <p className="number truncate option">{isShowPlacedOnHold && <Link to="/view-orders-progress/Full-Service - Placed On Hold">{OrdersFullService.PlacedOnHoldMTDFullService} placed on hold</Link>}
                                {isShowPlacedOnHold ?
                                    <button data-target="modal11" className="modal-trigger" style={{ background: "transparent", border: "none", fontSize: "13pt", cursor: "pointer", padding: "0", float: "right" }}
                                        onClick={() => this.handleAddRemovePlacedOnHold("Remove")}
                                    >
                                        <span data-tip data-for="tootltip-remove-place-on-hold" className="lnr lnr-cross-circle  primary-color"></span>
                                        <ReactTooltip id="tootltip-remove-place-on-hold" aria-haspopup="true">
                                            <p style={{ whiteSpace: "pre-line" }}>Remove Placed on Hold from Dashboard</p>
                                        </ReactTooltip>
                                    </button> :
                                    <button data-target="modal11" className="modal-trigger" style={{ background: "transparent", border: "none", fontSize: "13pt", cursor: "pointer", padding: "0", float: "right" }}
                                        onClick={() => this.handleAddRemovePlacedOnHold("Add")}
                                    >
                                        <span data-tip data-for="tootltip-add-place-on-hold" className="lnr lnr-plus-circle  primary-color"></span>
                                        <ReactTooltip id="tootltip-add-place-on-hold" aria-haspopup="true">
                                            <p style={{ whiteSpace: "pre-line" }}>Add Placed on Hold to Dashboard</p>
                                        </ReactTooltip>
                                    </button>
                                }
                            </p>
                        </div>
                    </div>
                </div>

                {this.renderMiddleWindow()}

                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

OrderFullService.propTypes = {
    dispatch: PropTypes.func,
    onToggleOrderSection: PropTypes.func,
    onToggleFullSection: PropTypes.func,
    onChangeViewAlert: PropTypes.func,
    OrdersFullService: PropTypes.object,
    isShowPlacedOnHold: PropTypes.bool,
    UserMTD: PropTypes.object
};

const mapStateToProps = (state) => {
    const { authentication, clientDashboard } = state;
    const { profile, role } = authentication;
    const { OrdersFullService } = clientDashboard.ordersInfo;
    const { isShowPlacedOnHold, UserMTD } = clientDashboard.ClientDashboardOrder;

    return {
        profile,
        role,
        OrdersFullService,
        isShowPlacedOnHold,
        UserMTD
    };

};
export default connect(mapStateToProps)(OrderFullService);