import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
// import ReactTooltip from "react-tooltip";
import { Link } from "react-router";
import { GridView } from "GridView";
import { getOrdersInfoDetail } from "../actions/order-progress";
import { DASHBOARD_ITEMS_PERPAGE } from "../../../constant/constants";
import { CLIENT_SUB_ROLE } from "Constants";

class MiddleAllServiceApptReady extends Component {
    constructor(props, defaultProps) {
        super(props, defaultProps);
        this.state = {
            ApptReadyCriteria: this.getDefaultGridCriteria(),
            ApptReadyColumn: [
                { title: "", data: "OrderId", type: "orderLinkWithOrderId" },
                { title: "(Min)", data: "DurationMinute" }
            ],
            timeZone: -(new Date().getTimezoneOffset() / 60)
        };
    }

    getDefaultGridCriteria() {
        return {
            sortColumn: "OrderId",
            sortDirection: true,
            page: 1,
            itemPerPage: DASHBOARD_ITEMS_PERPAGE
        };
    }

    roleNameFinal(roles) {
        if (roles.indexOf(CLIENT_SUB_ROLE.AGENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.AGENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        if (roles.indexOf(CLIENT_SUB_ROLE.CLIENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.CLIENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        if (roles.indexOf(CLIENT_SUB_ROLE.BRANCH.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.BRANCH.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        return "";
    }

    componentDidMount() {
        const { dispatch, profile, role } = this.props;
        dispatch(getOrdersInfoDetail({ id: profile.id, role: this.roleNameFinal(role.roleNames), service: "All", statusGroup: "Appt Ready", ...this.getDefaultGridCriteria(), timeZone: this.state.timeZone }));
    }

    handleGridViewReload(criteria, group) {
        const { dispatch, profile, role } = this.props;

        dispatch(getOrdersInfoDetail({ ...criteria, id: profile.id, role: this.roleNameFinal(role.roleNames), service: "All", statusGroup: group, timeZone: this.state.timeZone })).then(() => {
            //update criteria
            const newCriteria = {
                sortColumn: criteria.sortColumn,
                sortDirection: criteria.sortDirection,
                page: criteria.page,
                itemPerPage: criteria.itemPerPage
            };
            this.setState({ ApptReadyCriteria: newCriteria });
        });
    }

    render() {
        const { OrdersAllService } = this.props;
        const { ApptReadyCriteria, ApptReadyColumn } = this.state;

        return (
            <div className="row alert-section-mobile pagination-style small-col">
                <div className="col s12 m4 card alert-section p-1 unfilled Orders box-shadow-none card-dashboard">
                    <span className="card-title truncate"><Link to="/view-orders-progress/Appointment Ready">Appointment Ready</Link></span>
                    <a href="#" className="more-option">
                        <i className="ti ti-more"></i>
                    </a>
                    <div className="divider"></div>
                    <ul className="alert-list client-list-dashboard">
                        <li className="mb-1">
                            <div className="row">
                                <div className="col s12">
                                    <GridView
                                        criteria={ApptReadyCriteria}
                                        totalRecords={OrdersAllService.ApptReadyOrdersTotal}
                                        datasources={OrdersAllService.ApptReadyOrders}
                                        columns={ApptReadyColumn}
                                        identifier={"OrderId"}
                                        allowSorting={false}
                                        onGridViewReload={(e) => this.handleGridViewReload(e, "Appt Ready")}
                                    />
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>

            </div>
        );
    }
}

MiddleAllServiceApptReady.propTypes = {
    dispatch: PropTypes.func,
    profile: PropTypes.object,
    role: PropTypes.object,
    onToggleOrderSection: PropTypes.func,
    onToggleFullSection: PropTypes.func,
    onChangeViewAlert: PropTypes.func,
    OrdersAllService: PropTypes.object
};

const mapStateToProps = (state) => {
    const { authentication, clientDashboard } = state;
    const { profile, role } = authentication;
    const { OrdersAllService } = clientDashboard.ordersInfo;

    return {
        profile,
        role,
        OrdersAllService
    };

};
export default connect(mapStateToProps)(MiddleAllServiceApptReady);