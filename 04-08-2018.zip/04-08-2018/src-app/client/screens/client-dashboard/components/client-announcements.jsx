import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";

import { getAnnouncementsByUserId } from "../actions/client-announcements";
import { apiAddUpdateUserAnnouncements } from "Api/announcements-api";


class ClientAnnouncements extends Component {
    constructor(props) {
        super(props);

        this.state = {
            announcements: []
        };
    }

    componentDidMount() {
        const { dispatch, userId } = this.props;

        dispatch(getAnnouncementsByUserId(userId));
    }

    handleCloseModal() {
        const { onCloseAnnouncementsModal } = this.props;
        this.saveChanges();
        onCloseAnnouncementsModal();
    }

    saveChanges() {
        const { announcements, userId } = this.props;
        const announcementsAdd = [];

        announcements.map(i => {
            announcementsAdd.push({
                UserId: userId,
                AnnouncementID: i.announcementId,
                NumOfAppearance: i.numOfAppearance ? i.numOfAppearance + 1 : 1,
                InActive: this.refs.dontShowAnnouncements.checked ? 1 : 0,
                uaId: i.uaId
            });
        });

        apiAddUpdateUserAnnouncements({
            announcements: announcementsAdd
        });
    }

    render() {
        const { announcements } = this.props;
        let { isOpen } = this.props;

        if (announcements.length < 1) {
            isOpen = false;
        }

        const renderAnnoucements = announcements.map((item, index) => {
            const content = item.content;
            return (
                <div key={index + 1} className="row" >
                    <div className="col s1" style={{ width: "auto" }}>
                        <p>{index + 1}</p>
                    </div>
                    <div className="col s11" style={{ width: "95%" }} dangerouslySetInnerHTML={{ __html: content }}>
                    </div>
                </div>
            );
        });

        return (
            <div>
                <Modal isOpen={isOpen} addClass="modal-large no-tab">
                    <ModalBody>
                        <ModalTitle onClickClose={() => this.handleCloseModal()}>Announcements</ModalTitle>
                        <div className="tab-content">
                            {renderAnnoucements}
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row">
                            <div className="col s6"></div>
                            <div className="col s4" style={{ lineHeight: "60px" }}>
                                <label>
                                    <input
                                        type="checkbox"
                                        ref="dontShowAnnouncements"
                                    />
                                    <span>Don’t show these announcements</span>
                                </label>
                            </div>
                            <div className="col s2">
                                <button className="btn btn-small white w-100" onClick={() => this.handleCloseModal()}>Close</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
            </div>
        );
    }

}

ClientAnnouncements.propTypes = {
    dispatch: PropTypes.func,
    announcements: PropTypes.array,
    isOpen: PropTypes.bool,
    onCloseAnnouncementsModal: PropTypes.func,
    userId: PropTypes.number
};

export default ClientAnnouncements;