import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Component } from "react";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";

import DatePicker from "DatePicker";
import moment from "moment";
import Select from "Select";
import { toggleConfiguration, getUserMTD } from "../actions/client-dashboard-order";
import { apiGetClientMTDConfigByUserId, addClientMTDConfig } from "Api/client-config-api";
import { showSuccess } from "../../main-layout/actions";
import { SUCCESSFULLY_SAVED_MESSAGE } from "Constants";
import CommonModal from "CommonModal";
import { requireMessage } from "Helpers/validation-helper";

class ClientConfigurationModal extends Component {
    constructor(props) {
        super(props);

        this.state = {
            inputs: {
                isDateRange: false,
                period: "MTD"
            },
            validator: {}
        };

        this.isDirty = false;
        this.isFirstTime = true;
    }

    handleCloseModal() {
        const { dispatch } = this.props;

        this.isDirty = false;
        this.setState({
            validator: {}
        });
        dispatch(toggleConfiguration(false));
    }

    componentDidMount() {
        this.handleLoadData();
    }

    handleLoadData() {
        const { dispatch, userId } = this.props;

        apiGetClientMTDConfigByUserId(userId, (result) => {
            dispatch(getUserMTD(result.data.clientConfig));
        });
    }

    componentWillReceiveProps(nextProps) {
        if (this.isFirstTime) {
            if (nextProps.UserMTD.id) {
                this.setState({
                    inputs: {
                        ...nextProps.UserMTD,
                        fromDate: nextProps.UserMTD.fromDate ? moment(nextProps.UserMTD.fromDate).format("MM/DD/YYYY") : "",
                        toDate: nextProps.UserMTD.fromDate ? moment(nextProps.UserMTD.fromDate).format("MM/DD/YYYY") : "",
                        isDateRange: nextProps.UserMTD.period === null ? true : false,
                        period: nextProps.UserMTD.period ? nextProps.UserMTD.period : "MTD"
                    }
                });
                this.isFirstTime = false;
            }
        }
    }

    handleBlurFromDate(value) {
        const { inputs, validator } = this.state;
        let tempToDate = "";
        let isFormatToDate = false;
        let isFormatFromDate = false;
        const isRequiredFromDate = this.validateRequiredDateTime(value);

        if (inputs.toDate !== "" && inputs.toDate !== "Invalid date" && inputs.toDate !== null) {

            tempToDate = inputs.toDate;
            if (moment(inputs.toDate) < moment(value)) {
                if (value !== "" && value !== "Invalid date") {
                    isFormatToDate = true;
                    isFormatFromDate = true;
                }
            }
        } else {
            tempToDate = (value !== "Invalid date") ? value : "";
        }

        this.setState({
            inputs: {
                ...inputs,
                fromDate: value !== "Invalid date" ? value : null,
                toDate: tempToDate
            },
            validator: {
                ...validator,
                isRequiredToDate: false,
                isFormatToDate,
                isFormatFromDate,
                isRequiredFromDate
            }
        });
        this.isDirty = true;
    }

    handleBlurToDate(value) {
        const { inputs, validator } = this.state;
        let isFormatToDate = false;
        let isFormatFromDate = false;
        const isRequiredToDate = this.validateRequiredDateTime(value);

        if (inputs.fromDate !== "" && inputs.fromDate !== "Invalid date") {
            if (moment(value) < moment(inputs.fromDate)) {
                isFormatToDate = true;
                isFormatFromDate = true;
            }
        }

        this.setState({
            inputs: {
                ...inputs,
                toDate: value !== "Invalid date" ? value : null
            },
            validator: {
                ...validator,
                isFormatToDate,
                isFormatFromDate,
                isRequiredToDate
            }
        });
        this.isDirty = true;
    }

    validateRequiredDateTime(value) {
        if (value !== "" && value !== "Invalid date" && value !== undefined && value !== null) {
            return false;
        }

        return true;
    }

    validateForm() {
        const { validator, inputs } = this.state;
        const isRequiredToDate = this.validateRequiredDateTime(inputs.toDate);
        const isRequiredFromDate = this.validateRequiredDateTime(inputs.fromDate);

        const newValidator = {
            ...validator,
            isRequiredToDate,
            isRequiredFromDate
        };

        this.setState({
            validator: newValidator
        });

        for (const key in newValidator) {
            if (newValidator[key]) {
                return false;
            }
        }

        return true;
    }

    handleSave() {
        const { inputs } = this.state;
        const { dispatch, userId } = this.props;

        if (inputs.isDateRange) {
            if (!this.validateForm()) return;
        }

        addClientMTDConfig({
            ...inputs,
            period: !inputs.isDateRange ? inputs.period : null,
            fromDate: inputs.isDateRange ? inputs.fromDate : null,
            toDate: inputs.isDateRange ? inputs.toDate : null,
            userId
        }, () => {
            this.props.dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
            dispatch(getUserMTD({
                ...inputs,
                period: !inputs.isDateRange ? inputs.period : null,
                fromDate: inputs.isDateRange ? inputs.fromDate : null,
                toDate: inputs.isDateRange ? inputs.toDate : null,
                userId
            }));
            this.handleCloseModal();
            this.props.onSave();
        });
    }

    handlePeriodChange(value) {
        this.setState({
            inputs: {
                ...this.state.inputs,
                period: value
            }
        });
        this.isDirty = true;
    }

    handleCancel() {
        if (this.isDirty) {
            this.commonModal.showModal({
                type: "confirm",
                message: `Are you sure you would like to cancel updating this configuration?`
            }, () => {
                this.handleCloseModal();
            });
        } else {
            this.handleCloseModal();
        }

        this.isFirstTime = true;
    }

    render() {
        const { isShowConfiguration, periods } = this.props;
        const { inputs, validator } = this.state;

        return (
            <div>
                <Modal isOpen={isShowConfiguration} addClass="no-tab" style={{ height: "36%" }}>
                    <ModalBody>
                        <ModalTitle onClickClose={() => this.handleCloseModal()}>Configuration</ModalTitle>
                        <div className="tab-content">
                            <div className="row">
                                <div className="col s4 input-field">
                                    <label htmlFor="isDateRange">
                                        <input
                                            className="with-gap"
                                            type="radio"
                                            name="dateRangePeriod"
                                            id="isDateRange"
                                            checked={inputs.isDateRange}
                                            onChange={() => {
                                                this.isDirty = true;
                                                this.setState({
                                                    inputs: {
                                                        ...this.state.inputs,
                                                        isDateRange: true
                                                    }
                                                });
                                            }}
                                        />
                                        <span>Date Range</span>
                                    </label>
                                </div>
                                <div className="col s4">
                                    <DatePicker
                                        defaultValue={inputs.fromDate || ""}
                                        labelText="From Date"
                                        onBlur={e => this.handleBlurFromDate(moment(e).format("MM/DD/YYYY").toString())}
                                        disabled={!inputs.isDateRange}
                                        invalidMessage={validator.isFormatFromDate ? "From date cannot be greater than To Date" : ""}
                                        isRequiredField
                                        requiredMessage={validator.isRequiredFromDate ? requireMessage("From Date") : ""}
                                    />
                                </div>
                                <div className="col s4">
                                    <DatePicker
                                        defaultValue={inputs.toDate || ""}
                                        labelText="To Date"
                                        onBlur={e => this.handleBlurToDate(moment(e).format("MM/DD/YYYY").toString())}
                                        disabled={!inputs.isDateRange}
                                        invalidMessage={validator.isFormatToDate ? "From date cannot be greater than To Date" : ""}
                                        isRequiredField
                                        requiredMessage={validator.isRequiredToDate ? requireMessage("To Date") : ""}
                                    />
                                </div>
                            </div>

                            <div className="row">
                                <div className="col s4 input-field">
                                    <label htmlFor="isPeriod">
                                        <input
                                            className="with-gap"
                                            type="radio"
                                            name="dateRangePeriod"
                                            id="isPeriod"
                                            checked={!inputs.isDateRange}
                                            onChange={() => {
                                                this.isDirty = true;
                                                this.setState({
                                                    inputs: {
                                                        ...this.state.inputs,
                                                        isDateRange: false
                                                    }
                                                });
                                            }}
                                        />
                                        <span>Period</span>
                                    </label>
                                </div>
                                <div className="col s8">
                                    <Select
                                        dataSource={periods}
                                        onChange={(value) => this.handlePeriodChange(value)}
                                        mapDataToRenderOptions={{ value: "value", label: "label" }}
                                        id="period"
                                        ref="period"
                                        disabled={inputs.isDateRange}
                                        value={inputs.period || "MTD"}
                                    />
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col s6 m6">
                                <button type="button" className="btn white action-btn w-100" onClick={() => this.handleCancel()}>Cancel</button>
                            </div>
                            <div className="col s6 m6">
                                <button type="button" className="btn btn-small success-color w-100" onClick={() => this.handleSave()}>Save</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div >
        );
    }

}

ClientConfigurationModal.propTypes = {
    dispatch: PropTypes.func,
    onSave: PropTypes.func,
    isShowConfiguration: PropTypes.bool,
    periods: PropTypes.array,
    userId: PropTypes.number
};

ClientConfigurationModal.defaultProps = {
    periods: [
        {
            value: "YTD",
            label: "YTD"
        },
        {
            value: "MTD",
            label: "MTD"
        },
        {
            value: "WTD",
            label: "WTD"
        },
        {
            value: "Daily",
            label: "Daily"
        }
    ]
};

const mapStateToProps = (state) => {
    const { clientDashboard, authentication } = state;
    const { isShowConfiguration, UserMTD } = clientDashboard.ClientDashboardOrder;

    return {
        isShowConfiguration,
        userId: authentication.userId,
        UserMTD
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(ClientConfigurationModal);