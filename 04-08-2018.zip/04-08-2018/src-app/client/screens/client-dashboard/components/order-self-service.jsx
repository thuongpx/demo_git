import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import ReactTooltip from "react-tooltip";
import CommonModal from "CommonModal";
import moment from "moment";
import { Link } from "react-router";
import MiddleSelfServiceOpen from "./middle-self-service-open";
import MiddleSelfServiceAssigned from "./middle-self-service-assigned";
import MiddleSelfServiceApptReady from "./middle-self-service-appt-ready";
import MiddleSelfServiceClosedPending from "./middle-self-service-closed-pending";
import MiddleSelfServiceClosingComplete from "./middle-self-service-closing-complete";
import MiddleSelfServiceDidNotClose from "./middle-self-service-did-not-close";
import { toggleConfiguration, togglePlaceOnHold } from "../actions/client-dashboard-order";

class OrderSelfService extends Component {
    constructor(props, defaultProps) {
        super(props, defaultProps);

        this.state = {
            middleWindow: "Open"
        };
    }

    componentDidMount() {
    }

    componentDidUpdate() {
    }

    changeMiddleWindow(middleWindow) {
        this.setState({ middleWindow });
    }

    renderMiddleWindow() {
        switch (this.state.middleWindow) {
            case "Open": return <MiddleSelfServiceOpen />;
            case "Assigned": return <MiddleSelfServiceAssigned />;
            case "Appt Ready": return <MiddleSelfServiceApptReady />;
            case "Closed Pending": return <MiddleSelfServiceClosedPending />;
            case "Closing Complete": return <MiddleSelfServiceClosingComplete />;
            case "Did Not Close": return <MiddleSelfServiceDidNotClose />;
            default: return <MiddleSelfServiceOpen />;
        }
    }

    handleOpenConfiguration() {
        const { dispatch } = this.props;

        dispatch(toggleConfiguration(true));
    }

    handleAddRemovePlacedOnHold(action) {
        const { dispatch } = this.props;
        if (action === "Remove") {
            this.commonModal.showModal({
                type: "confirm",
                message: "Are you sure you would like to remove Placed on Hold field from the dashboard?"
            }, () => {
                dispatch(togglePlaceOnHold(false));
            }, () => {
                return;
            });
        } else {
            this.commonModal.showModal({
                type: "confirm",
                message: "Are you sure you would like to add Placed on Hold field to the dashboard?"
            }, () => {
                dispatch(togglePlaceOnHold(true));
            }, () => {
                return;
            });
        }
    }

    render() {
        const { OrdersSelfService, isShowPlacedOnHold, UserMTD } = this.props;
        return (
            <div className="col s12 m6 self-service-section">
                <div className="row ">
                    <div className="col s12  pos-rel">
                        <h3 className="title-page-detail">
                            My Orders (Self-Service)
                        </h3>
                        <span id="warning-alert-self-service" className="lnr lnr-warning small-lnr-btn-warning" data-tip data-for="tootltip-alert-self-service"
                            onClick={() => this.props.onChangeViewAlert()}
                        ></span>
                        <ReactTooltip id="tootltip-alert-self-service" aria-haspopup="true">
                            <p id="p-tootltip-alert-self-service">See Alerts of Self-Service Orders</p>
                        </ReactTooltip>
                        <span id="switchSection-self-service"
                            className="lnr lnr-sync"
                            onClick={() => this.props.onToggleOrderSection()}
                        >
                        </span>
                        <span id="toggleSection-self-service"
                            className="lnr lnr-frame-expand" data-tip data-for="tootltip-toggleSection-self-service"
                            onClick={() => this.props.onToggleFullSection("self", "toggleSection-self-service")}
                        >
                        </span>
                        <ReactTooltip id="tootltip-toggleSection-self-service" aria-haspopup="true">
                            <p id="p-tootltip-toggleSection-self-service">See Full-Screen view for Self-Service Orders</p>
                        </ReactTooltip>
                    </div>
                    <div className="col s12 m4 pl-custome custome-widthdash">
                        <div className={`card-panel white box-shadow-none border-style-dashboard ${this.state.middleWindow === "Open" && `active`}`}>
                            <span className="card-title truncate " title="Open" onClick={() => this.changeMiddleWindow("Open")}>Open
                                <span data-tip data-for="tootltip-open-self-service" className="lnr lnr-question-circle right primary-color "></span>
                                <ReactTooltip id="tootltip-open-self-service" aria-haspopup="true">
                                    <p style={{ whiteSpace: "pre-line" }}>This area shows you all orders that are awaiting some attention.</p>
                                </ReactTooltip>
                            </span>
                            <div className="divider"></div>
                            <p className="number truncate"><Link to="/view-orders-progress/Self-Service - Open">{OrdersSelfService.OpenSelfService}</Link></p>
                            <p className={`number truncate ${OrdersSelfService.OpenSLAApproachingSelfService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Self-Service - Open Approaching SLA">{OrdersSelfService.OpenSLAApproachingSelfService} approaching SLA</Link></p>
                            <p className={`number truncate ${OrdersSelfService.OpenSLAOutOfSelfService > 0 && "red-color"}`}><Link to="/view-orders-progress/Self-Service - Open Out of SLA">{OrdersSelfService.OpenSLAOutOfSelfService} out of SLA</Link></p>
                        </div>
                    </div>
                    <div className="col s12 m4 custome-widthdash">
                        <div className={`card-panel white box-shadow-none border-style-dashboard ${this.state.middleWindow === "Assigned" && `active`}`}>
                            <span className="card-title truncate " title="Assigned" onClick={() => this.changeMiddleWindow("Assigned")}>Assigned
                                <span data-tip data-for="tootltip-assigned-self-service" className="lnr lnr-question-circle right primary-color "></span>
                                <ReactTooltip id="tootltip-assigned-self-service" aria-haspopup="true">
                                    <p style={{ whiteSpace: "pre-line" }}>This area shows all of the orders that have been assigned to a vendor.</p>
                                </ReactTooltip>
                            </span>
                            <div className="divider"></div>
                            <p className="number truncate"><Link to="/view-orders-progress/Self-Service - Unconfirmed">{OrdersSelfService.UnconfirmedSelfService} unconfirmed</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.UnconfirmedSLAApproachingSelfService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Self-Service - Unconfirmed Approaching SLA">{OrdersSelfService.UnconfirmedSLAApproachingSelfService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.UnconfirmedSLAOutOfSelfService > 0 && "red-color"}`}><Link to="/view-orders-progress/Self-Service - Unconfirmed Out of SLA">{OrdersSelfService.UnconfirmedSLAOutOfSelfService} out of SLA</Link></p>
                            <p className="number truncate"><Link to="/view-orders-progress/Self-Service - Pending Docs">{OrdersSelfService.PendingDocsSelfService} pending docs</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.PendingDocsSLAApproachingSelfService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Self-Service - Pending Docs Approaching SLA">{OrdersSelfService.PendingDocsSLAApproachingSelfService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.PendingDocsSLAOutOfSelfService > 0 && "red-color"}`}><Link to="/view-orders-progress/Self-Service - Pending Docs Out of SLA">{OrdersSelfService.PendingDocsSLAOutOfSelfService} out of SLA</Link></p>
                            <p className="number truncate"><Link to="/view-orders-progress/Self-Service - Needing Pre-call">{OrdersSelfService.NeedingPreCallSelfService} needing pre-call</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.NeedingPreCallSLAApproachingSelfService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Self-Service - Needing Pre-call Approaching SLA">{OrdersSelfService.NeedingPreCallSLAApproachingSelfService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.NeedingPreCallSLAOutOfSelfService > 0 && "red-color"}`}><Link to="/view-orders-progress/Self-Service - Needing Pre-call Out of SLA">{OrdersSelfService.NeedingPreCallSLAOutOfSelfService} out of SLA</Link></p>
                        </div>
                    </div>
                    <div className="col s12 m4 custome-widthdash">
                        <div className={`card-panel white box-shadow-none border-style-dashboard ${this.state.middleWindow === "Appt Ready" && `active`}`}>
                            <span className="card-title truncate " title="Appt Ready" onClick={() => this.changeMiddleWindow("Appt Ready")}>Appt Ready
                                <span data-tip data-for="tootltip-appt-ready-self-service" className="lnr lnr-question-circle right primary-color "></span>
                                <ReactTooltip id="tootltip-appt-ready-self-service" aria-haspopup="true" data-html>
                                    <p style={{ whiteSpace: "pre-line" }}>This area will display all orders that are confirmed, docs are ready and vendor is ready to go!</p>
                                </ReactTooltip>
                            </span>
                            <div className="divider"></div>
                            <p className="number truncate"><Link to="/view-orders-progress/Self-Service - Appointment Ready">{OrdersSelfService.ApptReadySelfService}</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.ApptReadySLAApproachingSelfService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Self-Service - Appointment Ready Approaching SLA">{OrdersSelfService.ApptReadySLAApproachingSelfService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.ApptReadySLAOutOfSelfService > 0 && "red-color"}`}><Link to="/view-orders-progress/Self-Service - Appointment Ready post schedule time">{OrdersSelfService.ApptReadySLAOutOfSelfService} post schedule time</Link></p>
                        </div>
                    </div>
                    <div className="col s12 m4 pl-custome custome-widthdash">
                        <div className={`card-panel white box-shadow-none border-style-dashboard ${this.state.middleWindow === "Closed Pending" && `active`}`}>
                            <span className="card-title truncate " title="Closed Pending" onClick={() => this.changeMiddleWindow("Closed Pending")}>Closed Pending
                                <span data-tip data-for="tootltip-closed-pending-self-service" className="lnr lnr-question-circle right primary-color "></span>
                                <ReactTooltip id="tootltip-closed-pending-self-service" aria-haspopup="true" data-html>
                                    <p style={{ whiteSpace: "pre-line" }}>These orders have been submitted as closed, but need a bit more attention.</p>
                                </ReactTooltip>
                            </span>
                            <div className="divider"></div>
                            <p className="number truncate"><Link to="/view-orders-progress/Self-Service - Pending Review PC">{OrdersSelfService.PendingReviewPCSelfService} Pending Review/PC</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.PendingReviewPCSLAApproachingSelfService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Self-Service - Pending Review PC Approaching SLA">{OrdersSelfService.PendingReviewPCSLAApproachingSelfService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.PendingReviewPCSLAOutOfSelfService > 0 && "red-color"}`}><Link to="/view-orders-progress/Self-Service - Pending Review PC Out of SLA">{OrdersSelfService.PendingReviewPCSLAOutOfSelfService} out of SLA</Link></p>
                            <p className={`number truncate `}><Link to="/view-orders-progress/Self-Service - Awaiting Scanbacks">{OrdersSelfService.AwaitingScanbacksSelfService} Awaiting Scanbacks</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.AwaitingScanbacksSLAApproachingSelfService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Self-Service - Awaiting Scanbacks Approaching SLA">{OrdersSelfService.AwaitingScanbacksSLAApproachingSelfService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.AwaitingScanbacksSLAOutOfSelfService > 0 && "red-color"}`}><Link to="/view-orders-progress/Self-Service - Awaiting Scanbacks Out of SLA">{OrdersSelfService.AwaitingScanbacksSLAOutOfSelfService} out of SLA</Link></p>
                            <p className="number truncate"><Link to="/view-orders-progress/Self-Service - Pending QC Review">{OrdersSelfService.PendingQCReviewSelfService} Pending QC Review</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.PendingQCReviewSLAApproachingSelfService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Self-Service - Pending QC Review Approaching SLA">{OrdersSelfService.PendingQCReviewSLAApproachingSelfService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.PendingQCReviewSLAOutOfSelfService > 0 && "red-color"}`}><Link to="/view-orders-progress/Self-Service - Pending QC Review Out of SLA">{OrdersSelfService.PendingQCReviewSLAOutOfSelfService} out of SLA</Link></p>
                        </div>
                    </div>
                    <div className="col s12 m4 custome-widthdash">
                        <div className={`card-panel white box-shadow-none border-style-dashboard ${this.state.middleWindow === "Closing Complete" && `active`}`}>
                            <span className="card-title truncate " title="Closing Complete" onClick={() => this.changeMiddleWindow("Closing Complete")}>Closing Complete
                                <span data-tip data-for="tootltip-closing-complete-self-service" className="lnr lnr-question-circle right primary-color "></span>
                                <ReactTooltip id="tootltip-closing-complete-self-service" aria-haspopup="true">
                                    <p style={{ whiteSpace: "pre-line" }}>Displaying all closed orders month to date and orders requiring Post Close work.</p>
                                </ReactTooltip>
                            </span>
                            <div className="divider"></div>
                            <p className="number" title={`Closed ${UserMTD.period ? `${UserMTD.period}` : `from ${moment(UserMTD.fromDate).format("MM/DD/YYYY").toString()} to ${moment(UserMTD.toDate).format("MM/DD/YYYY").toString()}`}`}>
                                <Link to="/view-orders-progress/Self-Service - Closed">{OrdersSelfService.ClosedMTDSelfService} closed {UserMTD.period && `${UserMTD.period}`}</Link>
                                <button style={{
                                    background: "transparent",
                                    border: "none",
                                    marginTop: "4px",
                                    marginLeft: "10px",
                                    padding: "0"
                                }}
                                    onClick={() => this.handleOpenConfiguration()}
                                >
                                    <span className="lnr lnr-menu-circle  primary-color"></span>
                                </button>
                            </p>
                            <p className="number truncate"><Link to="/view-orders-progress/Self-Service - Post Close Issue">{OrdersSelfService.PostCloseIssueSelfService} post close issue</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.PostCloseIssueSLAApproachingSelfService > 0 && "warning-color"}`}><Link to="/view-orders-progress/Self-Service - Post Close Issue Approaching SLA">{OrdersSelfService.PostCloseIssueSLAApproachingSelfService} approaching SLA</Link></p>
                            <p className={`number truncate sub-number ${OrdersSelfService.PostCloseIssueSLAOutOfSelfService > 0 && "red-color"}`}><Link to="/view-orders-progress/Self-Service - Post Close Issue Out of SLA">{OrdersSelfService.PostCloseIssueSLAOutOfSelfService} out of SLA</Link></p>
                        </div>
                    </div>
                    <div className="col s12 m4 custome-widthdash">
                        <div className={`card-panel white box-shadow-none border-style-dashboard ${this.state.middleWindow === "Did Not Close" && `active`}`}>
                            <span className="card-title truncate " title="Did Not Close" onClick={() => this.changeMiddleWindow("Did Not Close")}>Did Not Close
                                <span data-tip data-for="tootltip-did-not-close-self-service" className="lnr lnr-question-circle right primary-color "></span>
                                <ReactTooltip id="tootltip-did-not-close-self-service" aria-haspopup="true">
                                    <p style={{ whiteSpace: "pre-line" }}>Displaying all orders that were canceled or did not close successfully month to date.</p>
                                </ReactTooltip>
                            </span>
                            <div className="divider"></div>
                            <p className="number truncate"><Link to="/view-orders-progress/Self-Service - Canceled By Client">{OrdersSelfService.CanceledByClientMTDSelfService} canceled by client</Link></p>
                            <p className="number truncate"><Link to="/view-orders-progress/Self-Service - Unsuccessful">{OrdersSelfService.UnsuccessfulMTDSelfService} unsuccessful</Link></p>
                            <p className="number truncate option">{isShowPlacedOnHold && <Link to="/view-orders-progress/Self-Service - Placed On Hold">{OrdersSelfService.PlacedOnHoldMTDSelfService} placed on hold</Link>}
                                {isShowPlacedOnHold ?
                                    <button data-target="modal11" className="modal-trigger" style={{ background: "transparent", border: "none", fontSize: "13pt", cursor: "pointer", padding: "0", float: "right" }}
                                        onClick={() => this.handleAddRemovePlacedOnHold("Remove")}
                                    >
                                        <span data-tip data-for="tootltip-remove-place-on-hold" className="lnr lnr-cross-circle  primary-color"></span>
                                        <ReactTooltip id="tootltip-remove-place-on-hold" aria-haspopup="true">
                                            <p style={{ whiteSpace: "pre-line" }}>Remove Placed on Hold from Dashboard</p>
                                        </ReactTooltip>
                                    </button> :
                                    <button data-target="modal11" className="modal-trigger" style={{ background: "transparent", border: "none", fontSize: "13pt", cursor: "pointer", padding: "0", float: "right" }}
                                        onClick={() => this.handleAddRemovePlacedOnHold("Add")}
                                    >
                                        <span data-tip data-for="tootltip-add-place-on-hold" className="lnr lnr-plus-circle  primary-color"></span>
                                        <ReactTooltip id="tootltip-add-place-on-hold" aria-haspopup="true">
                                            <p style={{ whiteSpace: "pre-line" }}>Add Placed on Hold to Dashboard</p>
                                        </ReactTooltip>
                                    </button>
                                }
                            </p>
                        </div>
                    </div>
                </div>

                {this.renderMiddleWindow()}

                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

OrderSelfService.propTypes = {
    dispatch: PropTypes.func,
    onToggleOrderSection: PropTypes.func,
    onToggleFullSection: PropTypes.func,
    onChangeViewAlert: PropTypes.func,
    OrdersSelfService: PropTypes.object,
    isShowPlacedOnHold: PropTypes.bool,
    UserMTD: PropTypes.object
};

const mapStateToProps = (state) => {
    const { authentication, clientDashboard } = state;
    const { profile, role } = authentication;
    const { OrdersSelfService } = clientDashboard.ordersInfo;
    const { isShowPlacedOnHold, UserMTD } = clientDashboard.ClientDashboardOrder;

    return {
        profile,
        role,
        OrdersSelfService,
        isShowPlacedOnHold,
        UserMTD
    };

};
export default connect(mapStateToProps)(OrderSelfService);