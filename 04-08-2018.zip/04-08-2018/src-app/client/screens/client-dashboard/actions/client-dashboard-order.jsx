export const GET_USER_MTD = "GET_USER_MTD";
export const TOGGLE_CONFIGURATION = "TOGGLE_CONFIGURATION";
export const TOGGLE_PLACEDONHOLD = "TOGGLE_PLACEDONHOLD";

export const getUserMTD = (data) => {
    return {
        type: GET_USER_MTD,
        data
    };
};

export const togglePlaceOnHold = (isShowPlacedOnHold) => {
    return {
        type: TOGGLE_PLACEDONHOLD,
        isShowPlacedOnHold
    };
};

export const toggleConfiguration = (isShowConfiguration) => {
    return {
        type: TOGGLE_CONFIGURATION,
        isShowConfiguration
    };
};
