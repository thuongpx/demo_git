import {
    apiGetOrdersInfoDashboard, apiGetOrdersInfoDetailDashboard, apiGetSLA
} from "../../../api/dashboard-api";
import { handleApiError } from "ErrorHandler";

export const CHANGE_ORDERS_INFO = "CHANGE_ORDERS_INFO";

export const CHANGE_ORDERS_SELF_OPEN_ALL_DETAIL = "CHANGE_ORDERS_SELF_OPEN_ALL_DETAIL";
export const CHANGE_ORDERS_SELF_OPEN_DETAIL = "CHANGE_ORDERS_SELF_OPEN_DETAIL";
export const CHANGE_ORDERS_SELF_OPEN_SLA_APPROACHING_DETAIL = "CHANGE_ORDERS_SELF_OPEN_SLA_APPROACHING_DETAIL";
export const CHANGE_ORDERS_SELF_OPEN_SLA_OUTOF_DETAIL = "CHANGE_ORDERS_SELF_OPEN_SLA_OUTOF_DETAIL";

export const CHANGE_ORDERS_SELF_ASSIGNED_DETAIL = "CHANGE_ORDERS_SELF_ASSIGNED_DETAIL";
export const CHANGE_ORDERS_SELF_UNCONFIRMED_DETAIL = "CHANGE_ORDERS_SELF_UNCONFIRMED_DETAIL";
export const CHANGE_ORDERS_SELF_PENDINGDOCS_DETAIL = "CHANGE_ORDERS_SELF_PENDINGDOCS_DETAIL";
export const CHANGE_ORDERS_SELF_NEEDINGPRECALL_DETAIL = "CHANGE_ORDERS_SELF_NEEDINGPRECALL_DETAIL";

export const CHANGE_ORDERS_SELF_APPT_READY_DETAIL = "CHANGE_ORDERS_SELF_APPT_READY_DETAIL";

export const CHANGE_ORDERS_SELF_CLOSED_PENDING_DETAIL = "CHANGE_ORDERS_SELF_CLOSED_PENDING_DETAIL";
export const CHANGE_ORDERS_SELF_PENDINGREVIEWPC_DETAIL = "CHANGE_ORDERS_SELF_PENDINGREVIEWPC_DETAIL";
export const CHANGE_ORDERS_SELF_AWAITINGSCANBACKS_DETAIL = "CHANGE_ORDERS_SELF_AWAITINGSCANBACKS_DETAIL";
export const CHANGE_ORDERS_SELF_PENDINGQCREVIEW_DETAIL = "CHANGE_ORDERS_SELF_PENDINGQCREVIEW_DETAIL";

export const CHANGE_ORDERS_SELF_CLOSING_COMPLETE_DETAIL = "CHANGE_ORDERS_SELF_CLOSING_COMPLETE_DETAIL";
export const CHANGE_ORDERS_SELF_CLOSEDMTD_DETAIL = "CHANGE_ORDERS_SELF_CLOSEDMTD_DETAIL";
export const CHANGE_ORDERS_SELF_POSTCLOSEISSUE_DETAIL = "CHANGE_ORDERS_SELF_POSTCLOSEISSUE_DETAIL";

export const CHANGE_ORDERS_SELF_DID_NOT_CLOSE_DETAIL = "CHANGE_ORDERS_SELF_DID_NOT_CLOSE_DETAIL";
export const CHANGE_ORDERS_SELF_CANCELEDBYCLIENT_DETAIL = "CHANGE_ORDERS_SELF_CANCELEDBYCLIENT_DETAIL";
export const CHANGE_ORDERS_SELF_UNSUCCESSFUL_DETAIL = "CHANGE_ORDERS_SELF_UNSUCCESSFUL_DETAIL";
export const CHANGE_ORDERS_SELF_PLACEDONHOLD_DETAIL = "CHANGE_ORDERS_SELF_PLACEDONHOLD_DETAIL";

export const CHANGE_ORDERS_FULL_OPEN_ALL_DETAIL = "CHANGE_ORDERS_FULL_OPEN_ALL_DETAIL";
export const CHANGE_ORDERS_FULL_OPEN_DETAIL = "CHANGE_ORDERS_FULL_OPEN_DETAIL";
export const CHANGE_ORDERS_FULL_OPEN_SLA_APPROACHING_DETAIL = "CHANGE_ORDERS_FULL_OPEN_SLA_APPROACHING_DETAIL";
export const CHANGE_ORDERS_FULL_OPEN_SLA_OUTOF_DETAIL = "CHANGE_ORDERS_FULL_OPEN_SLA_OUTOF_DETAIL";

export const CHANGE_ORDERS_FULL_ASSIGNED_DETAIL = "CHANGE_ORDERS_FULL_ASSIGNED_DETAIL";
export const CHANGE_ORDERS_FULL_UNCONFIRMED_DETAIL = "CHANGE_ORDERS_FULL_UNCONFIRMED_DETAIL";
export const CHANGE_ORDERS_FULL_PENDINGDOCS_DETAIL = "CHANGE_ORDERS_FULL_PENDINGDOCS_DETAIL";
export const CHANGE_ORDERS_FULL_NEEDINGPRECALL_DETAIL = "CHANGE_ORDERS_FULL_NEEDINGPRECALL_DETAIL";

export const CHANGE_ORDERS_FULL_APPT_READY_DETAIL = "CHANGE_ORDERS_FULL_APPT_READY_DETAIL";

export const CHANGE_ORDERS_FULL_CLOSED_PENDING_DETAIL = "CHANGE_ORDERS_FULL_CLOSED_PENDING_DETAIL";
export const CHANGE_ORDERS_FULL_PENDINGREVIEWPC_DETAIL = "CHANGE_ORDERS_FULL_PENDINGREVIEWPC_DETAIL";
export const CHANGE_ORDERS_FULL_AWAITINGSCANBACKS_DETAIL = "CHANGE_ORDERS_FULL_AWAITINGSCANBACKS_DETAIL";
export const CHANGE_ORDERS_FULL_PENDINGQCREVIEW_DETAIL = "CHANGE_ORDERS_FULL_PENDINGQCREVIEW_DETAIL";

export const CHANGE_ORDERS_FULL_CLOSING_COMPLETE_DETAIL = "CHANGE_ORDERS_FULL_CLOSING_COMPLETE_DETAIL";
export const CHANGE_ORDERS_FULL_CLOSEDMTD_DETAIL = "CHANGE_ORDERS_FULL_CLOSEDMTD_DETAIL";
export const CHANGE_ORDERS_FULL_POSTCLOSEISSUE_DETAIL = "CHANGE_ORDERS_FULL_POSTCLOSEISSUE_DETAIL";

export const CHANGE_ORDERS_FULL_DID_NOT_CLOSE_DETAIL = "CHANGE_ORDERS_FULL_DID_NOT_CLOSE_DETAIL";
export const CHANGE_ORDERS_FULL_CANCELEDBYCLIENT_DETAIL = "CHANGE_ORDERS_FULL_CANCELEDBYCLIENT_DETAIL";
export const CHANGE_ORDERS_FULL_UNSUCCESSFUL_DETAIL = "CHANGE_ORDERS_FULL_UNSUCCESSFUL_DETAIL";
export const CHANGE_ORDERS_FULL_PLACEDONHOLD_DETAIL = "CHANGE_ORDERS_FULL_PLACEDONHOLD_DETAIL";

export const CHANGE_ORDERS_ALL_OPEN_ALL_DETAIL = "CHANGE_ORDERS_ALL_OPEN_ALL_DETAIL";
export const CHANGE_ORDERS_ALL_OPEN_DETAIL = "CHANGE_ORDERS_ALL_OPEN_DETAIL";
export const CHANGE_ORDERS_ALL_OPEN_SLA_APPROACHING_DETAIL = "CHANGE_ORDERS_ALL_OPEN_SLA_APPROACHING_DETAIL";
export const CHANGE_ORDERS_ALL_OPEN_SLA_OUTOF_DETAIL = "CHANGE_ORDERS_ALL_OPEN_SLA_OUTOF_DETAIL";

export const CHANGE_ORDERS_ALL_ASSIGNED_DETAIL = "CHANGE_ORDERS_ALL_ASSIGNED_DETAIL";
export const CHANGE_ORDERS_ALL_UNCONFIRMED_DETAIL = "CHANGE_ORDERS_ALL_UNCONFIRMED_DETAIL";
export const CHANGE_ORDERS_ALL_PENDINGDOCS_DETAIL = "CHANGE_ORDERS_ALL_PENDINGDOCS_DETAIL";
export const CHANGE_ORDERS_ALL_NEEDINGPRECALL_DETAIL = "CHANGE_ORDERS_ALL_NEEDINGPRECALL_DETAIL";

export const CHANGE_ORDERS_ALL_APPT_READY_DETAIL = "CHANGE_ORDERS_ALL_APPT_READY_DETAIL";

export const CHANGE_ORDERS_ALL_CLOSED_PENDING_DETAIL = "CHANGE_ORDERS_ALL_CLOSED_PENDING_DETAIL";
export const CHANGE_ORDERS_ALL_PENDINGREVIEWPC_DETAIL = "CHANGE_ORDERS_ALL_PENDINGREVIEWPC_DETAIL";
export const CHANGE_ORDERS_ALL_AWAITINGSCANBACKS_DETAIL = "CHANGE_ORDERS_ALL_AWAITINGSCANBACKS_DETAIL";
export const CHANGE_ORDERS_ALL_PENDINGQCREVIEW_DETAIL = "CHANGE_ORDERS_ALL_PENDINGQCREVIEW_DETAIL";

export const CHANGE_ORDERS_ALL_CLOSING_COMPLETE_DETAIL = "CHANGE_ORDERS_ALL_CLOSING_COMPLETE_DETAIL";
export const CHANGE_ORDERS_ALL_CLOSEDMTD_DETAIL = "CHANGE_ORDERS_ALL_CLOSEDMTD_DETAIL";
export const CHANGE_ORDERS_ALL_POSTCLOSEISSUE_DETAIL = "CHANGE_ORDERS_ALL_POSTCLOSEISSUE_DETAIL";

export const CHANGE_ORDERS_ALL_DID_NOT_CLOSE_DETAIL = "CHANGE_ORDERS_ALL_DID_NOT_CLOSE_DETAIL";
export const CHANGE_ORDERS_ALL_CANCELEDBYCLIENT_DETAIL = "CHANGE_ORDERS_ALL_CANCELEDBYCLIENT_DETAIL";
export const CHANGE_ORDERS_ALL_UNSUCCESSFUL_DETAIL = "CHANGE_ORDERS_ALL_UNSUCCESSFUL_DETAIL";
export const CHANGE_ORDERS_ALL_PLACEDONHOLD_DETAIL = "CHANGE_ORDERS_ALL_PLACEDONHOLD_DETAIL";

export const INIT_SLA = "INIT_SLA";

export const changeOrdersInfo = (data) => {
    return {
        type: CHANGE_ORDERS_INFO,
        data
    };
};

export const changeOrdersInfoDetail = (resultData, data) => {
    switch (data.service) {
        case "Self":
            if (data.statusGroup === "OpenAll") {
                return {
                    type: CHANGE_ORDERS_SELF_OPEN_ALL_DETAIL,
                    resultData
                };
            }
            if (data.statusGroup === "Open") {
                return {
                    type: CHANGE_ORDERS_SELF_OPEN_DETAIL,
                    resultData
                };
            }
            if (data.statusGroup === "OpenSLAApproaching") {
                return {
                    type: CHANGE_ORDERS_SELF_OPEN_SLA_APPROACHING_DETAIL,
                    resultData
                };
            }
            if (data.statusGroup === "OpenSLAOutOf") {
                return {
                    type: CHANGE_ORDERS_SELF_OPEN_SLA_OUTOF_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Assigned") {
                return {
                    type: CHANGE_ORDERS_SELF_ASSIGNED_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Unconfirmed") {
                return {
                    type: CHANGE_ORDERS_SELF_UNCONFIRMED_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Pending Docs") {
                return {
                    type: CHANGE_ORDERS_SELF_PENDINGDOCS_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Needing Pre-call") {
                return {
                    type: CHANGE_ORDERS_SELF_NEEDINGPRECALL_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Appt Ready") {
                return {
                    type: CHANGE_ORDERS_SELF_APPT_READY_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Closed Pending") {
                return {
                    type: CHANGE_ORDERS_SELF_CLOSED_PENDING_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "PendingReviewPC") {
                return {
                    type: CHANGE_ORDERS_SELF_PENDINGREVIEWPC_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "AwaitingScanbacks") {
                return {
                    type: CHANGE_ORDERS_SELF_AWAITINGSCANBACKS_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "PendingQCReview") {
                return {
                    type: CHANGE_ORDERS_SELF_PENDINGQCREVIEW_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Closing Complete") {
                return {
                    type: CHANGE_ORDERS_SELF_CLOSING_COMPLETE_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Closed MTD") {
                return {
                    type: CHANGE_ORDERS_SELF_CLOSEDMTD_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Post Close Issue") {
                return {
                    type: CHANGE_ORDERS_SELF_POSTCLOSEISSUE_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Did Not Close") {
                return {
                    type: CHANGE_ORDERS_SELF_DID_NOT_CLOSE_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Canceled By Client") {
                return {
                    type: CHANGE_ORDERS_SELF_CANCELEDBYCLIENT_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Unsuccessful") {
                return {
                    type: CHANGE_ORDERS_SELF_UNSUCCESSFUL_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Placed On Hold") {
                return {
                    type: CHANGE_ORDERS_SELF_PLACEDONHOLD_DETAIL,
                    resultData
                };
            }

            break;
        case "Full":
            if (data.statusGroup === "OpenAll") {
                return {
                    type: CHANGE_ORDERS_FULL_OPEN_ALL_DETAIL,
                    resultData
                };
            }
            if (data.statusGroup === "Open") {
                return {
                    type: CHANGE_ORDERS_FULL_OPEN_DETAIL,
                    resultData
                };
            }
            if (data.statusGroup === "OpenSLAApproaching") {
                return {
                    type: CHANGE_ORDERS_FULL_OPEN_SLA_APPROACHING_DETAIL,
                    resultData
                };
            }
            if (data.statusGroup === "OpenSLAOutOf") {
                return {
                    type: CHANGE_ORDERS_FULL_OPEN_SLA_OUTOF_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Assigned") {
                return {
                    type: CHANGE_ORDERS_FULL_ASSIGNED_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Unconfirmed") {
                return {
                    type: CHANGE_ORDERS_FULL_UNCONFIRMED_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Pending Docs") {
                return {
                    type: CHANGE_ORDERS_FULL_PENDINGDOCS_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Needing Pre-call") {
                return {
                    type: CHANGE_ORDERS_FULL_NEEDINGPRECALL_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Appt Ready") {
                return {
                    type: CHANGE_ORDERS_FULL_APPT_READY_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Closed Pending") {
                return {
                    type: CHANGE_ORDERS_FULL_CLOSED_PENDING_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "PendingReviewPC") {
                return {
                    type: CHANGE_ORDERS_FULL_PENDINGREVIEWPC_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "AwaitingScanbacks") {
                return {
                    type: CHANGE_ORDERS_FULL_AWAITINGSCANBACKS_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "PendingQCReview") {
                return {
                    type: CHANGE_ORDERS_FULL_PENDINGQCREVIEW_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Closing Complete") {
                return {
                    type: CHANGE_ORDERS_FULL_CLOSING_COMPLETE_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Closed MTD") {
                return {
                    type: CHANGE_ORDERS_FULL_CLOSEDMTD_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Post Close Issue") {
                return {
                    type: CHANGE_ORDERS_FULL_POSTCLOSEISSUE_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Did Not Close") {
                return {
                    type: CHANGE_ORDERS_FULL_DID_NOT_CLOSE_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Canceled By Client") {
                return {
                    type: CHANGE_ORDERS_FULL_CANCELEDBYCLIENT_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Unsuccessful") {
                return {
                    type: CHANGE_ORDERS_FULL_UNSUCCESSFUL_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Placed On Hold") {
                return {
                    type: CHANGE_ORDERS_FULL_PLACEDONHOLD_DETAIL,
                    resultData
                };
            }

            break;
        default:
            if (data.statusGroup === "OpenAll") {
                return {
                    type: CHANGE_ORDERS_ALL_OPEN_ALL_DETAIL,
                    resultData
                };
            }
            if (data.statusGroup === "Open") {
                return {
                    type: CHANGE_ORDERS_ALL_OPEN_DETAIL,
                    resultData
                };
            }
            if (data.statusGroup === "OpenSLAApproaching") {
                return {
                    type: CHANGE_ORDERS_ALL_OPEN_SLA_APPROACHING_DETAIL,
                    resultData
                };
            }
            if (data.statusGroup === "OpenSLAOutOf") {
                return {
                    type: CHANGE_ORDERS_ALL_OPEN_SLA_OUTOF_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Assigned") {
                return {
                    type: CHANGE_ORDERS_ALL_ASSIGNED_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Unconfirmed") {
                return {
                    type: CHANGE_ORDERS_ALL_UNCONFIRMED_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Pending Docs") {
                return {
                    type: CHANGE_ORDERS_ALL_PENDINGDOCS_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Needing Pre-call") {
                return {
                    type: CHANGE_ORDERS_ALL_NEEDINGPRECALL_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Appt Ready") {
                return {
                    type: CHANGE_ORDERS_ALL_APPT_READY_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Closed Pending") {
                return {
                    type: CHANGE_ORDERS_ALL_CLOSED_PENDING_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "PendingReviewPC") {
                return {
                    type: CHANGE_ORDERS_ALL_PENDINGREVIEWPC_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "AwaitingScanbacks") {
                return {
                    type: CHANGE_ORDERS_ALL_AWAITINGSCANBACKS_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "PendingQCReview") {
                return {
                    type: CHANGE_ORDERS_ALL_PENDINGQCREVIEW_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Closing Complete") {
                return {
                    type: CHANGE_ORDERS_ALL_CLOSING_COMPLETE_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Closed MTD") {
                return {
                    type: CHANGE_ORDERS_ALL_CLOSEDMTD_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Post Close Issue") {
                return {
                    type: CHANGE_ORDERS_ALL_POSTCLOSEISSUE_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Did Not Close") {
                return {
                    type: CHANGE_ORDERS_ALL_DID_NOT_CLOSE_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Canceled By Client") {
                return {
                    type: CHANGE_ORDERS_ALL_CANCELEDBYCLIENT_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Unsuccessful") {
                return {
                    type: CHANGE_ORDERS_ALL_UNSUCCESSFUL_DETAIL,
                    resultData
                };
            }

            if (data.statusGroup === "Placed On Hold") {
                return {
                    type: CHANGE_ORDERS_ALL_PLACEDONHOLD_DETAIL,
                    resultData
                };
            }

    }
    return {
        type: CHANGE_ORDERS_ALL_OPEN_DETAIL,
        resultData
    };
};

export const initSLA = (data) => {
    return {
        type: INIT_SLA,
        data
    };
};

export const getOrdersInfo = (data) => {
    return dispatch => {
        return apiGetOrdersInfoDashboard(data, result => {
            if (result) {
                dispatch(changeOrdersInfo(result.data));
            }
        }, (error) => handleApiError(dispatch, error));
    };
};

export const getOrdersInfoDetail = (data) => {
    return dispatch => {
        return apiGetOrdersInfoDetailDashboard(data, result => {
            if (result) {
                dispatch(changeOrdersInfoDetail(result.data, data));
            }
        }, (error) => handleApiError(dispatch, error));
    };
};

export const getSLA = (data) => {
    return dispatch => {
        return apiGetSLA(data, result => {
            if (result) {
                dispatch(initSLA(result.data));
            }
        }, (error) => handleApiError(dispatch, error));
    };
};

