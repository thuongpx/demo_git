import { apiGetAnnouncementsByUserId } from "Api/announcements-api";
import { handleApiError } from "ErrorHandler";

export const ANNOUNCEMENTS_BY_USERID_REQUEST = "ANNOUNCEMENTS_BY_USERID_REQUEST";
export const ANNOUNCEMENTS_BY_USERID_RECEIVE = "ANNOUNCEMENTS_BY_USERID_RECEIVE";
export const ANNOUNCEMENTS_BY_USERID_SHOWHIDE = "ANNOUNCEMENTS_BY_USERID_SHOWHIDE";
export const ANNOUNCEMENTS_BY_USERID_FIRSTSHOWHIDE = "ANNOUNCEMENTS_BY_USERID_FIRSTSHOWHIDE";

export const requestAnnouncementsByUserId = () => {
    return {
        type: ANNOUNCEMENTS_BY_USERID_REQUEST,
        isFetching: true
    };
};

export const showHideAnnouncementsByUserId = (isShowAnnouncement) => {
    return {
        type: ANNOUNCEMENTS_BY_USERID_SHOWHIDE,
        isShowAnnouncement
    };
};

export const setFirstShowHideAnnouncementsByUserId = (isFirstShowAnnouncement) => {
    return {
        type: ANNOUNCEMENTS_BY_USERID_FIRSTSHOWHIDE,
        isFirstShowAnnouncement
    };
};

export const receiveAnnouncementsByUserId = (announcements) => {
    return {
        type: ANNOUNCEMENTS_BY_USERID_RECEIVE,
        isFetching: false,
        announcements
    };
};

// export const getAnnouncementsByUserId = (userId) => {
//     debugger
//     return (dispatch, getState) => {
//         dispatch(requestAnnouncementsByUserId());

//         return apiGetAnnouncementsByUserId(userId, (result) => {
//             dispatch(showHideAnnouncementsByUserId(result.data.length > 0 && getState().clientDashboard.clientAnnouncements.isFirstShowAnnouncement));
//             dispatch(receiveAnnouncementsByUserId(result.data));
//         }, (error) => handleApiError(dispatch, error));
//     };
// };