import { apiGetDataAlert, apiUpdateMaskReadOrUnread } from "Api/order-progress-api";
import { handleApiError } from "ErrorHandler";
export const REQUEST_GET_ALERT = "REQUEST_GET_ALERT";
export const RECEIVE_GET_ALERT = "RECEIVE_GET_ALERT";
export const REQUEST_UPDATE_MASK_READ_OR_UNREAD = "REQUEST_UPDATE_MASK_READ_OR_UNREAD";
export const RECEIVE_UPDATE_MASK_READ_OR_UNREAD = "RECEIVE_UPDATE_MASK_READ_OR_UNREAD";


export const requestGetDataAlert = () => {
    return {
        type: REQUEST_GET_ALERT,
        isFetching: true
    };
};

export const receiveGetDataAlert = (data) => {
    return {
        type: RECEIVE_GET_ALERT,
        isFetching: false,
        data
    };
};

export const getDataAlert = (criteria, role, clientId) => {
    return dispatch => {
        dispatch(requestGetDataAlert());
        return apiGetDataAlert(criteria, role, clientId, (result) => {
            dispatch(receiveGetDataAlert(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const requestUpdateMaskReadOrUnread = () => {
    return {
        type: REQUEST_UPDATE_MASK_READ_OR_UNREAD,
        isFetching: true
    };
};

export const receiveUpdateMaskReadOrUnread = (data) => {
    return {
        type: RECEIVE_UPDATE_MASK_READ_OR_UNREAD,
        isFetching: false,
        data
    };
};

export const updateMaskReadOrUnread = (progressLog) => {
    return dispatch => {
        dispatch(requestUpdateMaskReadOrUnread());
        return apiUpdateMaskReadOrUnread(progressLog, (result) => {
            dispatch(receiveUpdateMaskReadOrUnread(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};