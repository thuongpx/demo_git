import {
    TOGGLE_CONFIGURATION,
    GET_USER_MTD,
    TOGGLE_PLACEDONHOLD
} from "../actions/client-dashboard-order";

export default function clientDashboardOrderReducer(state = {
    UserMTD: {},
    isShowPlacedOnHold: true,
    isShowConfiguration: false
}, action) {
    switch (action.type) {
        case GET_USER_MTD:
            return {
                ...state,
                UserMTD: action.data
            };
        case TOGGLE_PLACEDONHOLD:
            return {
                ...state,
                isShowPlacedOnHold: action.isShowPlacedOnHold
            };
        case TOGGLE_CONFIGURATION:
            return {
                ...state,
                isShowConfiguration: action.isShowConfiguration
            };
        default:
            return state;
    }
}