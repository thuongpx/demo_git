import {
    CHANGE_ORDERS_INFO,

    CHANGE_ORDERS_SELF_OPEN_ALL_DETAIL,
    CHANGE_ORDERS_SELF_OPEN_DETAIL,
    CHANGE_ORDERS_SELF_OPEN_SLA_APPROACHING_DETAIL,
    CHANGE_ORDERS_SELF_OPEN_SLA_OUTOF_DETAIL,

    CHANGE_ORDERS_SELF_ASSIGNED_DETAIL,
    CHANGE_ORDERS_SELF_UNCONFIRMED_DETAIL,
    CHANGE_ORDERS_SELF_PENDINGDOCS_DETAIL,
    CHANGE_ORDERS_SELF_NEEDINGPRECALL_DETAIL,

    CHANGE_ORDERS_SELF_APPT_READY_DETAIL,

    CHANGE_ORDERS_SELF_CLOSED_PENDING_DETAIL,
    CHANGE_ORDERS_SELF_PENDINGREVIEWPC_DETAIL,
    CHANGE_ORDERS_SELF_AWAITINGSCANBACKS_DETAIL,
    CHANGE_ORDERS_SELF_PENDINGQCREVIEW_DETAIL,

    CHANGE_ORDERS_SELF_CLOSING_COMPLETE_DETAIL,
    CHANGE_ORDERS_SELF_CLOSEDMTD_DETAIL,
    CHANGE_ORDERS_SELF_POSTCLOSEISSUE_DETAIL,

    CHANGE_ORDERS_SELF_DID_NOT_CLOSE_DETAIL,
    CHANGE_ORDERS_SELF_CANCELEDBYCLIENT_DETAIL,
    CHANGE_ORDERS_SELF_UNSUCCESSFUL_DETAIL,
    CHANGE_ORDERS_SELF_PLACEDONHOLD_DETAIL,

    CHANGE_ORDERS_FULL_OPEN_ALL_DETAIL,
    CHANGE_ORDERS_FULL_OPEN_DETAIL,
    CHANGE_ORDERS_FULL_OPEN_SLA_APPROACHING_DETAIL,
    CHANGE_ORDERS_FULL_OPEN_SLA_OUTOF_DETAIL,

    CHANGE_ORDERS_FULL_ASSIGNED_DETAIL,
    CHANGE_ORDERS_FULL_UNCONFIRMED_DETAIL,
    CHANGE_ORDERS_FULL_PENDINGDOCS_DETAIL,
    CHANGE_ORDERS_FULL_NEEDINGPRECALL_DETAIL,

    CHANGE_ORDERS_FULL_APPT_READY_DETAIL,

    CHANGE_ORDERS_FULL_CLOSED_PENDING_DETAIL,
    CHANGE_ORDERS_FULL_PENDINGREVIEWPC_DETAIL,
    CHANGE_ORDERS_FULL_AWAITINGSCANBACKS_DETAIL,
    CHANGE_ORDERS_FULL_PENDINGQCREVIEW_DETAIL,

    CHANGE_ORDERS_FULL_CLOSING_COMPLETE_DETAIL,
    CHANGE_ORDERS_FULL_CLOSEDMTD_DETAIL,
    CHANGE_ORDERS_FULL_POSTCLOSEISSUE_DETAIL,

    CHANGE_ORDERS_FULL_DID_NOT_CLOSE_DETAIL,
    CHANGE_ORDERS_FULL_CANCELEDBYCLIENT_DETAIL,
    CHANGE_ORDERS_FULL_UNSUCCESSFUL_DETAIL,
    CHANGE_ORDERS_FULL_PLACEDONHOLD_DETAIL,

    CHANGE_ORDERS_ALL_OPEN_ALL_DETAIL,
    CHANGE_ORDERS_ALL_OPEN_DETAIL,
    CHANGE_ORDERS_ALL_OPEN_SLA_APPROACHING_DETAIL,
    CHANGE_ORDERS_ALL_OPEN_SLA_OUTOF_DETAIL,

    CHANGE_ORDERS_ALL_ASSIGNED_DETAIL,
    CHANGE_ORDERS_ALL_UNCONFIRMED_DETAIL,
    CHANGE_ORDERS_ALL_PENDINGDOCS_DETAIL,
    CHANGE_ORDERS_ALL_NEEDINGPRECALL_DETAIL,

    CHANGE_ORDERS_ALL_APPT_READY_DETAIL,

    CHANGE_ORDERS_ALL_CLOSED_PENDING_DETAIL,
    CHANGE_ORDERS_ALL_PENDINGREVIEWPC_DETAIL,
    CHANGE_ORDERS_ALL_AWAITINGSCANBACKS_DETAIL,
    CHANGE_ORDERS_ALL_PENDINGQCREVIEW_DETAIL,

    CHANGE_ORDERS_ALL_CLOSING_COMPLETE_DETAIL,
    CHANGE_ORDERS_ALL_CLOSEDMTD_DETAIL,
    CHANGE_ORDERS_ALL_POSTCLOSEISSUE_DETAIL,

    CHANGE_ORDERS_ALL_DID_NOT_CLOSE_DETAIL,
    CHANGE_ORDERS_ALL_CANCELEDBYCLIENT_DETAIL,
    CHANGE_ORDERS_ALL_UNSUCCESSFUL_DETAIL,
    CHANGE_ORDERS_ALL_PLACEDONHOLD_DETAIL,

    INIT_SLA
} from "../actions/order-progress";

export default function OrdersInfoReducer(state = {
    OrdersSelfService: {
        //Open
        OpenOrders: [],
        OpenOrdersTotal: 0,
        OpenOrdersSLAApproaching: [],
        OpenOrdersSLAApproachingTotal: 0,
        OpenOrdersSLAOutOf: [],
        OpenOrdersSLAOutOfTotal: 0,
        //Assigned
        UnconfirmedOrders: [],
        UnconfirmedOrdersTotal: 0,
        PendingDocsOrders: [],
        PendingDocsOrdersTotal: 0,
        NeedingPreCallOrders: [],
        NeedingPreCallOrdersTotal: 0,
        //Appt Ready
        ApptReadyOrders: [],
        ApptReadyOrdersTotal: 0,
        //Closed Pending
        PendingReviewPCOrders: [],
        PendingReviewPCOrdersTotal: 0,
        AwaitingScanbacksOrders: [],
        AwaitingScanbacksOrdersTotal: 0,
        PendingQCReviewOrders: [],
        PendingQCReviewOrdersTotal: 0,
        //Closing Complete
        ClosedMTDOrders: [],
        ClosedMTDOrdersTotal: 0,
        PostCloseIssueOrders: [],
        PostCloseIssueOrdersTotal: 0,
        //Did Not Close
        CanceledByClientOrders: [],
        CanceledByClientOrdersTotal: 0,
        UnsuccessfulOrders: [],
        UnsuccessfulOrdersTotal: 0,
        PlacedOnHoldOrders: [],
        PlacedOnHoldOrdersTotal: 0
    },
    OrdersFullService: {
        //Open
        OpenOrders: [],
        OpenOrdersTotal: 0,
        OpenOrdersSLAApproaching: [],
        OpenOrdersSLAApproachingTotal: 0,
        OpenOrdersSLAOutOf: [],
        OpenOrdersSLAOutOfTotal: 0,
        //Assigned
        UnconfirmedOrders: [],
        UnconfirmedOrdersTotal: 0,
        PendingDocsOrders: [],
        PendingDocsOrdersTotal: 0,
        NeedingPreCallOrders: [],
        NeedingPreCallOrdersTotal: 0,
        //Appt Ready
        ApptReadyOrders: [],
        ApptReadyOrdersTotal: 0,
        //Closed Pending
        PendingReviewPCOrders: [],
        PendingReviewPCOrdersTotal: 0,
        AwaitingScanbacksOrders: [],
        AwaitingScanbacksOrdersTotal: 0,
        PendingQCReviewOrders: [],
        PendingQCReviewOrdersTotal: 0,
        //Closing Complete
        ClosedMTDOrders: [],
        ClosedMTDOrdersTotal: 0,
        PostCloseIssueOrders: [],
        PostCloseIssueOrdersTotal: 0,
        //Did Not Close
        CanceledByClientOrders: [],
        CanceledByClientOrdersTotal: 0,
        UnsuccessfulOrders: [],
        UnsuccessfulOrdersTotal: 0,
        PlacedOnHoldOrders: [],
        PlacedOnHoldOrdersTotal: 0
    },
    OrdersAllService: {
        //Open
        OpenOrders: [],
        OpenOrdersTotal: 0,
        OpenOrdersSLAApproaching: [],
        OpenOrdersSLAApproachingTotal: 0,
        OpenOrdersSLAOutOf: [],
        OpenOrdersSLAOutOfTotal: 0,
        //Assigned
        UnconfirmedOrders: [],
        UnconfirmedOrdersTotal: 0,
        PendingDocsOrders: [],
        PendingDocsOrdersTotal: 0,
        NeedingPreCallOrders: [],
        NeedingPreCallOrdersTotal: 0,
        //Appt Ready
        ApptReadyOrders: [],
        ApptReadyOrdersTotal: 0,
        //Closed Pending
        PendingReviewPCOrders: [],
        PendingReviewPCOrdersTotal: 0,
        AwaitingScanbacksOrders: [],
        AwaitingScanbacksOrdersTotal: 0,
        PendingQCReviewOrders: [],
        PendingQCReviewOrdersTotal: 0,
        //Closing Complete
        ClosedMTDOrders: [],
        ClosedMTDOrdersTotal: 0,
        PostCloseIssueOrders: [],
        PostCloseIssueOrdersTotal: 0,
        //Did Not Close
        CanceledByClientOrders: [],
        CanceledByClientOrdersTotal: 0,
        UnsuccessfulOrders: [],
        UnsuccessfulOrdersTotal: 0,
        PlacedOnHoldOrders: [],
        PlacedOnHoldOrdersTotal: 0
    },
    SLA_Broker: {},
    SLA: {}
}, action) {
    switch (action.type) {
        case CHANGE_ORDERS_INFO:
            return {
                ...state,
                OrdersSelfService: { ...state.OrdersSelfService, ...action.data.SelfService },
                OrdersFullService: { ...state.OrdersFullService, ...action.data.FullService }
            };
        //Open
        case CHANGE_ORDERS_SELF_OPEN_ALL_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    OpenOrders: action.resultData.OpenOrders,
                    OpenOrdersTotal: action.resultData.OpenOrdersTotal,
                    OpenOrdersSLAApproaching: action.resultData.OpenOrdersSLAApproaching,
                    OpenOrdersSLAApproachingTotal: action.resultData.OpenOrdersSLAApproachingTotal,
                    OpenOrdersSLAOutOf: action.resultData.OpenOrdersSLAOutOf,
                    OpenOrdersSLAOutOfTotal: action.resultData.OpenOrdersSLAOutOfTotal
                }
            };
        case CHANGE_ORDERS_SELF_OPEN_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    OpenOrders: action.resultData.OpenOrders,
                    OpenOrdersTotal: action.resultData.OpenOrdersTotal
                }
            };
        case CHANGE_ORDERS_SELF_OPEN_SLA_APPROACHING_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    OpenOrdersSLAApproaching: action.resultData.OpenOrdersSLAApproaching,
                    OpenOrdersSLAApproachingTotal: action.resultData.OpenOrdersSLAApproachingTotal
                }
            };
        case CHANGE_ORDERS_SELF_OPEN_SLA_OUTOF_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    OpenOrdersSLAOutOf: action.resultData.OpenOrdersSLAOutOf,
                    OpenOrdersSLAOutOfTotal: action.resultData.OpenOrdersSLAOutOfTotal
                }
            };
        //Assigned
        case CHANGE_ORDERS_SELF_ASSIGNED_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    UnconfirmedOrders: action.resultData.UnconfirmedOrders,
                    UnconfirmedOrdersTotal: action.resultData.UnconfirmedOrdersTotal,
                    PendingDocsOrders: action.resultData.PendingDocsOrders,
                    PendingDocsOrdersTotal: action.resultData.PendingDocsOrdersTotal,
                    NeedingPreCallOrders: action.resultData.NeedingPreCallOrders,
                    NeedingPreCallOrdersTotal: action.resultData.NeedingPreCallOrdersTotal
                }
            };
        case CHANGE_ORDERS_SELF_UNCONFIRMED_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    UnconfirmedOrders: action.resultData.UnconfirmedOrders,
                    UnconfirmedOrdersTotal: action.resultData.UnconfirmedOrdersTotal
                }
            };
        case CHANGE_ORDERS_SELF_PENDINGDOCS_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    PendingDocsOrders: action.resultData.PendingDocsOrders,
                    PendingDocsOrdersTotal: action.resultData.PendingDocsOrdersTotal
                }
            };
        case CHANGE_ORDERS_SELF_NEEDINGPRECALL_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    NeedingPreCallOrders: action.resultData.NeedingPreCallOrders,
                    NeedingPreCallOrdersTotal: action.resultData.NeedingPreCallOrdersTotal
                }
            };
        //Appt Read
        case CHANGE_ORDERS_SELF_APPT_READY_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    ApptReadyOrders: action.resultData.ApptReadyOrders,
                    ApptReadyOrdersTotal: action.resultData.ApptReadyOrdersTotal
                }
            };
        //Closed Pending
        case CHANGE_ORDERS_SELF_CLOSED_PENDING_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    PendingReviewPCOrders: action.resultData.PendingReviewPCOrders,
                    PendingReviewPCOrdersTotal: action.resultData.PendingReviewPCOrdersTotal,
                    AwaitingScanbacksOrders: action.resultData.AwaitingScanbacksOrders,
                    AwaitingScanbacksOrdersTotal: action.resultData.AwaitingScanbacksOrdersTotal,
                    PendingQCReviewOrders: action.resultData.PendingQCReviewOrders,
                    PendingQCReviewOrdersTotal: action.resultData.PendingQCReviewOrdersTotal
                }
            };
        case CHANGE_ORDERS_SELF_PENDINGREVIEWPC_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    PendingReviewPCOrders: action.resultData.PendingReviewPCOrders,
                    PendingReviewPCOrdersTotal: action.resultData.PendingReviewPCOrdersTotal
                }
            };
        case CHANGE_ORDERS_SELF_AWAITINGSCANBACKS_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    AwaitingScanbacksOrders: action.resultData.AwaitingScanbacksOrders,
                    AwaitingScanbacksOrdersTotal: action.resultData.AwaitingScanbacksOrdersTotal
                }
            };
        case CHANGE_ORDERS_SELF_PENDINGQCREVIEW_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    PendingQCReviewOrders: action.resultData.PendingQCReviewOrders,
                    PendingQCReviewOrdersTotal: action.resultData.PendingQCReviewOrdersTotal
                }
            };
        //Closing complete
        case CHANGE_ORDERS_SELF_CLOSING_COMPLETE_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    ClosedMTDOrders: action.resultData.ClosedMTDOrders,
                    ClosedMTDOrdersTotal: action.resultData.ClosedMTDOrdersTotal,
                    PostCloseIssueOrders: action.resultData.PostCloseIssueOrders,
                    PostCloseIssueOrdersTotal: action.resultData.PostCloseIssueOrdersTotal
                }
            };
        case CHANGE_ORDERS_SELF_CLOSEDMTD_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    ClosedMTDOrders: action.resultData.ClosedMTDOrders,
                    ClosedMTDOrdersTotal: action.resultData.ClosedMTDOrdersTotal
                }
            };
        case CHANGE_ORDERS_SELF_POSTCLOSEISSUE_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    PostCloseIssueOrders: action.resultData.PostCloseIssueOrders,
                    PostCloseIssueOrdersTotal: action.resultData.PostCloseIssueOrdersTotal
                }
            };
        //Did Not Close
        case CHANGE_ORDERS_SELF_DID_NOT_CLOSE_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    CanceledByClientOrders: action.resultData.CanceledByClientOrders,
                    CanceledByClientOrdersTotal: action.resultData.CanceledByClientOrdersTotal,
                    UnsuccessfulOrders: action.resultData.UnsuccessfulOrders,
                    UnsuccessfulOrdersTotal: action.resultData.UnsuccessfulOrdersTotal,
                    PlacedOnHoldOrders: action.resultData.UnsuccessfulOrders,
                    PlacedOnHoldOrdersTotal: action.resultData.UnsuccessfulOrdersTotal
                }
            };
        case CHANGE_ORDERS_SELF_CANCELEDBYCLIENT_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    CanceledByClientOrders: action.resultData.CanceledByClientOrders,
                    CanceledByClientOrdersTotal: action.resultData.CanceledByClientOrdersTotal
                }
            };
        case CHANGE_ORDERS_SELF_UNSUCCESSFUL_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    UnsuccessfulOrders: action.resultData.UnsuccessfulOrders,
                    UnsuccessfulOrdersTotal: action.resultData.UnsuccessfulOrdersTotal
                }
            };
        case CHANGE_ORDERS_SELF_PLACEDONHOLD_DETAIL:
            return {
                ...state,
                OrdersSelfService: {
                    ...state.OrdersSelfService,
                    PlacedOnHoldOrders: action.resultData.UnsuccessfulOrders,
                    PlacedOnHoldOrdersTotal: action.resultData.UnsuccessfulOrdersTotal
                }
            };

        //FULL SERVICE
        //Open
        case CHANGE_ORDERS_FULL_OPEN_ALL_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    OpenOrders: action.resultData.OpenOrders,
                    OpenOrdersTotal: action.resultData.OpenOrdersTotal,
                    OpenOrdersSLAApproaching: action.resultData.OpenOrdersSLAApproaching,
                    OpenOrdersSLAApproachingTotal: action.resultData.OpenOrdersSLAApproachingTotal,
                    OpenOrdersSLAOutOf: action.resultData.OpenOrdersSLAOutOf,
                    OpenOrdersSLAOutOfTotal: action.resultData.OpenOrdersSLAOutOfTotal
                }
            };
        case CHANGE_ORDERS_FULL_OPEN_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    OpenOrders: action.resultData.OpenOrders,
                    OpenOrdersTotal: action.resultData.OpenOrdersTotal
                }
            };
        case CHANGE_ORDERS_FULL_OPEN_SLA_APPROACHING_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    OpenOrdersSLAApproaching: action.resultData.OpenOrdersSLAApproaching,
                    OpenOrdersSLAApproachingTotal: action.resultData.OpenOrdersSLAApproachingTotal
                }
            };
        case CHANGE_ORDERS_FULL_OPEN_SLA_OUTOF_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    OpenOrdersSLAOutOf: action.resultData.OpenOrdersSLAOutOf,
                    OpenOrdersSLAOutOfTotal: action.resultData.OpenOrdersSLAOutOfTotal
                }
            };
        //Assigned
        case CHANGE_ORDERS_FULL_ASSIGNED_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    UnconfirmedOrders: action.resultData.UnconfirmedOrders,
                    UnconfirmedOrdersTotal: action.resultData.UnconfirmedOrdersTotal,
                    PendingDocsOrders: action.resultData.PendingDocsOrders,
                    PendingDocsOrdersTotal: action.resultData.PendingDocsOrdersTotal,
                    NeedingPreCallOrders: action.resultData.NeedingPreCallOrders,
                    NeedingPreCallOrdersTotal: action.resultData.NeedingPreCallOrdersTotal
                }
            };
        case CHANGE_ORDERS_FULL_UNCONFIRMED_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    UnconfirmedOrders: action.resultData.UnconfirmedOrders,
                    UnconfirmedOrdersTotal: action.resultData.UnconfirmedOrdersTotal
                }
            };
        case CHANGE_ORDERS_FULL_PENDINGDOCS_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    PendingDocsOrders: action.resultData.PendingDocsOrders,
                    PendingDocsOrdersTotal: action.resultData.PendingDocsOrdersTotal
                }
            };
        case CHANGE_ORDERS_FULL_NEEDINGPRECALL_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    NeedingPreCallOrders: action.resultData.NeedingPreCallOrders,
                    NeedingPreCallOrdersTotal: action.resultData.NeedingPreCallOrdersTotal
                }
            };
        //Appt Read
        case CHANGE_ORDERS_FULL_APPT_READY_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    ApptReadyOrders: action.resultData.ApptReadyOrders,
                    ApptReadyOrdersTotal: action.resultData.ApptReadyOrdersTotal
                }
            };
        //Closed Pending
        case CHANGE_ORDERS_FULL_CLOSED_PENDING_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    PendingReviewPCOrders: action.resultData.PendingReviewPCOrders,
                    PendingReviewPCOrdersTotal: action.resultData.PendingReviewPCOrdersTotal,
                    AwaitingScanbacksOrders: action.resultData.AwaitingScanbacksOrders,
                    AwaitingScanbacksOrdersTotal: action.resultData.AwaitingScanbacksOrdersTotal,
                    PendingQCReviewOrders: action.resultData.PendingQCReviewOrders,
                    PendingQCReviewOrdersTotal: action.resultData.PendingQCReviewOrdersTotal
                }
            };
        case CHANGE_ORDERS_FULL_PENDINGREVIEWPC_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    PendingReviewPCOrders: action.resultData.PendingReviewPCOrders,
                    PendingReviewPCOrdersTotal: action.resultData.PendingReviewPCOrdersTotal
                }
            };
        case CHANGE_ORDERS_FULL_AWAITINGSCANBACKS_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    AwaitingScanbacksOrders: action.resultData.AwaitingScanbacksOrders,
                    AwaitingScanbacksOrdersTotal: action.resultData.AwaitingScanbacksOrdersTotal
                }
            };
        case CHANGE_ORDERS_FULL_PENDINGQCREVIEW_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    PendingQCReviewOrders: action.resultData.PendingQCReviewOrders,
                    PendingQCReviewOrdersTotal: action.resultData.PendingQCReviewOrdersTotal
                }
            };
        //Closing complete
        case CHANGE_ORDERS_FULL_CLOSING_COMPLETE_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    ClosedMTDOrders: action.resultData.ClosedMTDOrders,
                    ClosedMTDOrdersTotal: action.resultData.ClosedMTDOrdersTotal,
                    PostCloseIssueOrders: action.resultData.PostCloseIssueOrders,
                    PostCloseIssueOrdersTotal: action.resultData.PostCloseIssueOrdersTotal
                }
            };
        case CHANGE_ORDERS_FULL_CLOSEDMTD_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    ClosedMTDOrders: action.resultData.ClosedMTDOrders,
                    ClosedMTDOrdersTotal: action.resultData.ClosedMTDOrdersTotal
                }
            };
        case CHANGE_ORDERS_FULL_POSTCLOSEISSUE_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    PostCloseIssueOrders: action.resultData.PostCloseIssueOrders,
                    PostCloseIssueOrdersTotal: action.resultData.PostCloseIssueOrdersTotal
                }
            };
        //Did Not Close
        case CHANGE_ORDERS_FULL_DID_NOT_CLOSE_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    CanceledByClientOrders: action.resultData.CanceledByClientOrders,
                    CanceledByClientOrdersTotal: action.resultData.CanceledByClientOrdersTotal,
                    UnsuccessfulOrders: action.resultData.UnsuccessfulOrders,
                    UnsuccessfulOrdersTotal: action.resultData.UnsuccessfulOrdersTotal,
                    PlacedOnHoldOrders: action.resultData.UnsuccessfulOrders,
                    PlacedOnHoldOrdersTotal: action.resultData.UnsuccessfulOrdersTotal
                }
            };
        case CHANGE_ORDERS_FULL_CANCELEDBYCLIENT_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    CanceledByClientOrders: action.resultData.CanceledByClientOrders,
                    CanceledByClientOrdersTotal: action.resultData.CanceledByClientOrdersTotal
                }
            };
        case CHANGE_ORDERS_FULL_UNSUCCESSFUL_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    UnsuccessfulOrders: action.resultData.UnsuccessfulOrders,
                    UnsuccessfulOrdersTotal: action.resultData.UnsuccessfulOrdersTotal
                }
            };
        case CHANGE_ORDERS_FULL_PLACEDONHOLD_DETAIL:
            return {
                ...state,
                OrdersFullService: {
                    ...state.OrdersFullService,
                    PlacedOnHoldOrders: action.resultData.UnsuccessfulOrders,
                    PlacedOnHoldOrdersTotal: action.resultData.UnsuccessfulOrdersTotal
                }
            };


        //ALL SERVICE
        //Open
        case CHANGE_ORDERS_ALL_OPEN_ALL_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    OpenOrders: action.resultData.OpenOrders,
                    OpenOrdersTotal: action.resultData.OpenOrdersTotal,
                    OpenOrdersSLAApproaching: action.resultData.OpenOrdersSLAApproaching,
                    OpenOrdersSLAApproachingTotal: action.resultData.OpenOrdersSLAApproachingTotal,
                    OpenOrdersSLAOutOf: action.resultData.OpenOrdersSLAOutOf,
                    OpenOrdersSLAOutOfTotal: action.resultData.OpenOrdersSLAOutOfTotal
                }
            };
        case CHANGE_ORDERS_ALL_OPEN_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    OpenOrders: action.resultData.OpenOrders,
                    OpenOrdersTotal: action.resultData.OpenOrdersTotal
                }
            };
        case CHANGE_ORDERS_ALL_OPEN_SLA_APPROACHING_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    OpenOrdersSLAApproaching: action.resultData.OpenOrdersSLAApproaching,
                    OpenOrdersSLAApproachingTotal: action.resultData.OpenOrdersSLAApproachingTotal
                }
            };
        case CHANGE_ORDERS_ALL_OPEN_SLA_OUTOF_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    OpenOrdersSLAOutOf: action.resultData.OpenOrdersSLAOutOf,
                    OpenOrdersSLAOutOfTotal: action.resultData.OpenOrdersSLAOutOfTotal
                }
            };
        //Assigned
        case CHANGE_ORDERS_ALL_ASSIGNED_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    UnconfirmedOrders: action.resultData.UnconfirmedOrders,
                    UnconfirmedOrdersTotal: action.resultData.UnconfirmedOrdersTotal,
                    PendingDocsOrders: action.resultData.PendingDocsOrders,
                    PendingDocsOrdersTotal: action.resultData.PendingDocsOrdersTotal,
                    NeedingPreCallOrders: action.resultData.NeedingPreCallOrders,
                    NeedingPreCallOrdersTotal: action.resultData.NeedingPreCallOrdersTotal
                }
            };
        case CHANGE_ORDERS_ALL_UNCONFIRMED_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    UnconfirmedOrders: action.resultData.UnconfirmedOrders,
                    UnconfirmedOrdersTotal: action.resultData.UnconfirmedOrdersTotal
                }
            };
        case CHANGE_ORDERS_ALL_PENDINGDOCS_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    PendingDocsOrders: action.resultData.PendingDocsOrders,
                    PendingDocsOrdersTotal: action.resultData.PendingDocsOrdersTotal
                }
            };
        case CHANGE_ORDERS_ALL_NEEDINGPRECALL_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    NeedingPreCallOrders: action.resultData.NeedingPreCallOrders,
                    NeedingPreCallOrdersTotal: action.resultData.NeedingPreCallOrdersTotal
                }
            };
        //Appt Read
        case CHANGE_ORDERS_ALL_APPT_READY_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    ApptReadyOrders: action.resultData.ApptReadyOrders,
                    ApptReadyOrdersTotal: action.resultData.ApptReadyOrdersTotal
                }
            };
        //Closed Pending
        case CHANGE_ORDERS_ALL_CLOSED_PENDING_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    PendingReviewPCOrders: action.resultData.PendingReviewPCOrders,
                    PendingReviewPCOrdersTotal: action.resultData.PendingReviewPCOrdersTotal,
                    AwaitingScanbacksOrders: action.resultData.AwaitingScanbacksOrders,
                    AwaitingScanbacksOrdersTotal: action.resultData.AwaitingScanbacksOrdersTotal,
                    PendingQCReviewOrders: action.resultData.PendingQCReviewOrders,
                    PendingQCReviewOrdersTotal: action.resultData.PendingQCReviewOrdersTotal
                }
            };
        case CHANGE_ORDERS_ALL_PENDINGREVIEWPC_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    PendingReviewPCOrders: action.resultData.PendingReviewPCOrders,
                    PendingReviewPCOrdersTotal: action.resultData.PendingReviewPCOrdersTotal
                }
            };
        case CHANGE_ORDERS_ALL_AWAITINGSCANBACKS_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    AwaitingScanbacksOrders: action.resultData.AwaitingScanbacksOrders,
                    AwaitingScanbacksOrdersTotal: action.resultData.AwaitingScanbacksOrdersTotal
                }
            };
        case CHANGE_ORDERS_ALL_PENDINGQCREVIEW_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    PendingQCReviewOrders: action.resultData.PendingQCReviewOrders,
                    PendingQCReviewOrdersTotal: action.resultData.PendingQCReviewOrdersTotal
                }
            };
        //Closing complete
        case CHANGE_ORDERS_ALL_CLOSING_COMPLETE_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    ClosedMTDOrders: action.resultData.ClosedMTDOrders,
                    ClosedMTDOrdersTotal: action.resultData.ClosedMTDOrdersTotal,
                    PostCloseIssueOrders: action.resultData.PostCloseIssueOrders,
                    PostCloseIssueOrdersTotal: action.resultData.PostCloseIssueOrdersTotal
                }
            };
        case CHANGE_ORDERS_ALL_CLOSEDMTD_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    ClosedMTDOrders: action.resultData.ClosedMTDOrders,
                    ClosedMTDOrdersTotal: action.resultData.ClosedMTDOrdersTotal
                }
            };
        case CHANGE_ORDERS_ALL_POSTCLOSEISSUE_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    PostCloseIssueOrders: action.resultData.PostCloseIssueOrders,
                    PostCloseIssueOrdersTotal: action.resultData.PostCloseIssueOrdersTotal
                }
            };
        //Did Not Close
        case CHANGE_ORDERS_ALL_DID_NOT_CLOSE_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    CanceledByClientOrders: action.resultData.CanceledByClientOrders,
                    CanceledByClientOrdersTotal: action.resultData.CanceledByClientOrdersTotal,
                    UnsuccessfulOrders: action.resultData.UnsuccessfulOrders,
                    UnsuccessfulOrdersTotal: action.resultData.UnsuccessfulOrdersTotal,
                    PlacedOnHoldOrders: action.resultData.UnsuccessfulOrders,
                    PlacedOnHoldOrdersTotal: action.resultData.UnsuccessfulOrdersTotal
                }
            };
        case CHANGE_ORDERS_ALL_CANCELEDBYCLIENT_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    CanceledByClientOrders: action.resultData.CanceledByClientOrders,
                    CanceledByClientOrdersTotal: action.resultData.CanceledByClientOrdersTotal
                }
            };
        case CHANGE_ORDERS_ALL_UNSUCCESSFUL_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    UnsuccessfulOrders: action.resultData.UnsuccessfulOrders,
                    UnsuccessfulOrdersTotal: action.resultData.UnsuccessfulOrdersTotal
                }
            };
        case CHANGE_ORDERS_ALL_PLACEDONHOLD_DETAIL:
            return {
                ...state,
                OrdersAllService: {
                    ...state.OrdersAllService,
                    PlacedOnHoldOrders: action.resultData.UnsuccessfulOrders,
                    PlacedOnHoldOrdersTotal: action.resultData.UnsuccessfulOrdersTotal
                }
            };
        case INIT_SLA:
            return {
                ...state,
                SLA_Broker: action.data.SLA_Broker,
                SLA: action.data.SLA
            };
        default:
            return state;
    }
}