import { combineReducers } from "redux";
import OrdersInfoReducer from "./order-progress-reducer";
import clientAnnouncementsReducers from "./client-announcements";
import clientDashboardOrderReducer from "./client-dashboard-order-reducer";
import dashBoardAlertReducers from "./dashboard-alert-reducers";

const clientDashboardReducers = combineReducers({
    ordersInfo: OrdersInfoReducer,
    clientAnnouncements: clientAnnouncementsReducers,
    ClientDashboardOrder: clientDashboardOrderReducer,
    dashBoardAlert: dashBoardAlertReducers

});

export default clientDashboardReducers;