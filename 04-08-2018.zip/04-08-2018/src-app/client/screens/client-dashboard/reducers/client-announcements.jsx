import { ANNOUNCEMENTS_BY_USERID_REQUEST, ANNOUNCEMENTS_BY_USERID_RECEIVE, ANNOUNCEMENTS_BY_USERID_SHOWHIDE, ANNOUNCEMENTS_BY_USERID_FIRSTSHOWHIDE } from "./../actions/client-announcements";

const initState = {
    isFetching: false,
    announcements: [],
    isShowAnnouncement: false,
    isFirstShowAnnouncement: false
};

export default function clientAnnouncementsReducers(state = initState, action) {
    switch (action.type) {
        case ANNOUNCEMENTS_BY_USERID_REQUEST:
            return {
                ...state,
                isFetching: action.isFetching
            };
        case ANNOUNCEMENTS_BY_USERID_RECEIVE:
            return {
                ...state,
                isFetching: action.isFetching,
                announcements: action.announcements
            };
        case ANNOUNCEMENTS_BY_USERID_SHOWHIDE:
            return {
                ...state,
                isFetching: action.isFetching,
                isShowAnnouncement: action.isShowAnnouncement
            };
        case ANNOUNCEMENTS_BY_USERID_FIRSTSHOWHIDE:
            return {
                ...state,
                isFetching: action.isFetching,
                isFirstShowAnnouncement: action.isFirstShowAnnouncement
            };

        default:
            return state;
    }
}