import { REQUEST_GET_ALERT, RECEIVE_GET_ALERT, REQUEST_UPDATE_MASK_READ_OR_UNREAD, RECEIVE_UPDATE_MASK_READ_OR_UNREAD } from "../actions/dashboard-alert-actions";

export default function dashBoardAlertReducers(state = {
    isFetching: false,
    listDataAlert: [],
    dataTotalRecords: 0,
    gridCriteria: {
        page: 1,
        itemPerPage: 2
    }
}, action) {
    switch (action.type) {
        case REQUEST_GET_ALERT:
            return {
                ...state,
                isFetching: true
            };
        case RECEIVE_GET_ALERT:
            return {
                ...state,
                isFetching: false,
                listDataAlert: action.data.dataAlert,
                dataTotalRecords: action.data.dataTotalRecords
            };
        case REQUEST_UPDATE_MASK_READ_OR_UNREAD:
            return {
                ...state,
                isFetching: true
            };
        case RECEIVE_UPDATE_MASK_READ_OR_UNREAD:
            return {
                ...state,
                isFetching: false
            };
        default:
            return state;
    }
}