import React from "react";
import { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import moment from "moment";
import { getOrdersInfo, getSLA } from "../actions/order-progress";
import { CLIENT_SUB_ROLE } from "Constants";
import OrderAllService from "../components/order-all-service";
import OrderAllServiceAlert from "../components/order-all-service-alert";
import OrderSelfService from "../components/order-self-service";
import OrderSelfServiceAlert from "../components/order-self-service-alert";
import OrderFullService from "../components/order-full-service";
import OrderFullServiceAlert from "../components/order-full-service-alert";
import ClientConfigurationModal from "../components/client-configuration-modal";
import { listenReloadAlert } from "../../../socket/notification";
import { handleApiError } from "../../../helpers/error-handler";
import { apiGetPositionAlert } from "../../../api/order-progress-api";
import WelcomeModal from "../components/welcome-modal";
import SendInviteModal from "../../mu-profiles/containers/send-invite";
import { apiCheckFirstLogin, apiUpdateFirstLogin } from "Api/user-api";
class ClientDashboard extends Component {
    constructor(props, defaultProps) {
        super(props, defaultProps);
        this.state = {
            now: moment().format("YYYY-MM-DD HH:mm:ss"),
            showAllService: false,
            showAlert: "full-service",
            timeZone: -(new Date().getTimezoneOffset() / 60),
            criteria: {
                page: 1,
                itemPerPage: 5
            },
            positionFocusOfAlert: 0
        };
    }

    roleNameFinal(roles) {
        if (roles.indexOf(CLIENT_SUB_ROLE.AGENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.AGENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        if (roles.indexOf(CLIENT_SUB_ROLE.CLIENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.CLIENT.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        if (roles.indexOf(CLIENT_SUB_ROLE.BRANCH.toLowerCase().replace(/\b\w/g, l => l.toUpperCase())) > -1) return CLIENT_SUB_ROLE.BRANCH.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
        return "";
    }

    updateNow() {
        const { dispatch, profile, role } = this.props;
        dispatch(getOrdersInfo({ id: profile.id, role: this.roleNameFinal(role.roleNames), timeZone: this.state.timeZone }));
    }

    componentDidMount() {
        const { profile, roleNames, accountId, dispatch, roleType } = this.props;
        const role = roleNames[0];
        const userId = profile.id;

        this.updateNow();
        dispatch(getSLA({ clientId: profile.id }));
        this.timer = setInterval(() => { this.updateNow(); }, 10000);
        window.addEventListener("resize", this.updateDimensions);

        listenReloadAlert(data => {
            if (!data.isSelfService) {
                this.changeViewAlert("full-service");
                const isSelfService = 0;
                const progressLogId = (data.isSetPosition ? 0 : data.progressLogId);
                if (data.role === role && data.userId === userId && data.progressLogId) {
                    const alertId = data.progressLogId;
                    apiGetPositionAlert({ role, userId, alertId, accountId, isSelfService }, (response) => {
                        //eslint-disable-next-line
                        this.setState({
                            positionFocusOfAlert: progressLogId,
                            criteria: {
                                page: response.data.page,
                                itemPerPage: this.state.criteria.itemPerPage
                            }
                        });
                    }, err => handleApiError(this.props.dispatch, err));
                }
            } else {
                //eslint-disable-next-line
                this.changeViewAlert("self-service");
                const isSelfService = 1;
                const progressLogId = (data.isSetPosition ? 0 : data.progressLogId);
                if (data.role === role && data.userId === userId && data.progressLogId) {
                    const alertId = data.progressLogId;
                    apiGetPositionAlert({ role, userId, alertId, accountId, isSelfService }, (response) => {
                        //eslint-disable-next-line
                        this.setState({
                            positionFocusOfAlert: progressLogId,
                            criteria: {
                                page: response.data.page,
                                itemPerPage: this.state.criteria.itemPerPage
                            }
                        });
                    }, err => handleApiError(this.props.dispatch, err));
                }
            }
        });

        //show welcome modal
        if (role === "Client") {
            apiCheckFirstLogin(profile.userId, (response) => {
                if (!response.data.isFirstLogin) {
                    this.welcomeModal.show();
                    apiUpdateFirstLogin(profile.userId, () => { });
                }
            });
        }
    }

    componentWillUnmount() {
        clearInterval(this.timer);
    }

    clearPosition() {
        this.setState({
            positionFocusOfAlert: 0
        });
    }

    changeViewAlert(showAlert) {
        this.closeToolTip();
        switch (showAlert) {
            case "self-service":
                if ($("#switchSection-full-service").css("display") !== "none") {
                    showAlert = "self-service-right";
                }
                break;
        }
        this.setState({
            showAlert,
            criteria: {
                page: 1,
                itemPerPage: 5
            }
        });
    }

    closeToolTip() {
        $(".__react_component_tooltip").removeClass("show");
    }

    toggleAllSection() {
        this.setState({
            showAlert: !this.state.showAllService ? "all-service" : "full-service",
            showAllService: !this.state.showAllService,
            criteria: {
                page: 1,
                itemPerPage: 5
            }
        });
    }

    toggleOrderSection() {
        let isSelfVisible = false;
        if ($(".self-service-section").is(":visible")) {
            isSelfVisible = true;
        }
        $(".self-service-section").attr("style", "");
        $(".full-service-section").attr("style", "");
        if (isSelfVisible) {
            $(".full-service-section").show();
            $(".self-service-section").hide();
            this.changeViewAlert("full-service");
        } else {
            $(".self-service-section").show();
            $(".full-service-section").hide();
            this.changeViewAlert("self-service-right");
        }
    }

    toggleFullSection(type, id) {
        if (type === "self") {
            $(".self-service-section").attr("style", "");

            if ($(".self-service-section").hasClass("m6")) {
                $(".full-service-section").css("width", 0);
                $(".full-service-section").css("height", 0);
                $(".full-service-section").css("padding", 0);
                $(".full-service-section").css("opacity", 0);
                $("#toggleSection-full-service").hide();

                $("#warning-alert-self-service").css("display", "none");
                $(`#${id}`).removeClass("lnr-frame-expand").addClass("lnr-frame-contract");
                $(".self-service-section").removeClass("m6").addClass("m12");
                $("#p-tootltip-toggleSection-self-service").text("Back to Split-Screen view");

            } else {
                $(".full-service-section").css("width", "50%");
                $(".full-service-section").css("height", "auto");
                $(".full-service-section").css("padding", "0 .75rem");
                $(".full-service-section").css("opacity", 1);
                $("#toggleSection-full-service").show();

                $("#warning-alert-self-service").css("display", "");
                $(".self-service-section").removeClass("m12").addClass("m6");
                $(`#${id}`).removeClass("lnr-frame-contract").addClass("lnr-frame-expand");
                $("#p-tootltip-toggleSection-self-service").text("See Full-Screen view for Self-Service Orders");
            }
            this.changeViewAlert("self-service");
        } else {

            $(".full-service-section").attr("style", "");

            if ($(".full-service-section").hasClass("m6")) {
                $(".self-service-section").css("width", 0);
                $(".self-service-section").css("height", 0);
                $(".self-service-section").css("padding", 0);
                $(".self-service-section").css("opacity", 0);
                $("#toggleSection-self-service").show();

                $("#warning-alert-full-service").css("display", "none");
                $(`#${id}`).removeClass("lnr-frame-expand").addClass("lnr-frame-contract");
                $(".full-service-section").removeClass("m6").addClass("m12");
                $(".full-service-section").addClass("without-before");
                $("#p-tootltip-toggleSection-full-service").text("Back to Split-Screen view");
            } else {
                $(".self-service-section").css("width", "50%");
                $(".self-service-section").css("height", "auto");
                $(".self-service-section").css("padding", "0 .75rem");
                $(".self-service-section").css("opacity", 1);
                $("#toggleSection-self-service").show();

                $("#warning-alert-full-service").css("display", "");
                $(".full-service-section").removeClass("m12").addClass("m6");
                $(".full-service-section").removeClass("without-before");
                $(`#${id}`).removeClass("lnr-frame-contract").addClass("lnr-frame-expand");
                $("#p-tootltip-toggleSection-full-service").text("See Full-Screen view for Full-Service Orders");
            }
            this.changeViewAlert("full-service");
        }
    }

    updateDimensions() {
        $(".full-service-section").attr("style", "");
        $("#toggleSection-full-service").css("display", "");
        $(".self-service-section").attr("style", "");
        $("#toggleSection-self-service").css("display", "");
        // this.changeViewAlert("full-service");
    }

    handlePaginateChanged(page, itemPerPage) {
        this.setState({
            criteria: {
                page,
                itemPerPage
            }
        });
    }

    handleOnBlurPageNumber(value) {
        const { listAllProgressLog, criteria } = this.state;
        const { itemPerPage } = criteria;
        const { dataTotalRecords } = listAllProgressLog;
        const totalPages = Math.ceil(dataTotalRecords / itemPerPage);
        let pageNumber = 1;

        if (!isNaN(value)) {
            pageNumber = Number(value);
            if (pageNumber > totalPages) pageNumber = totalPages;
            if (pageNumber < 1) pageNumber = 1;
        } else {
            pageNumber = 1;
        }

        this.handlePaginateChanged(pageNumber, itemPerPage);
    }

    handleClientConfigSave() {
        this.updateNow();
    }

    render() {
        // const { announcements, dispatch, accountId, isShowAnnouncement } = this.props;
        return (
            <div className="place-section pos-rel client-dashboard-section">
                <div className="row">
                    {this.state.showAlert === "self-service" &&
                        <OrderSelfServiceAlert
                            position={this.state.positionFocusOfAlert}
                            criteria={this.state.criteria}
                            handlePaginateChanged={(page, itemPerPage) => this.handlePaginateChanged(page, itemPerPage)}
                            handleOnBlurPageNumber={(value) => this.handleOnBlurPageNumber(value)}
                            clearPosition={() => this.clearPosition()}
                        />}
                    <div className="col s12 m10">
                        <div className="row">
                            <div className="col s12 m12 mt-2 right-align">
                                <button className="btn btn-small default-bg-color view-order-btn"
                                    onClick={() => this.toggleAllSection()}
                                >{this.state.showAllService ? `Back to Previous View` : `View All Order`}</button>
                            </div>
                            {this.state.showAllService ? <div>
                                <OrderAllService />
                            </div> : <div>
                                    <OrderSelfService onToggleOrderSection={() => this.toggleOrderSection()} onToggleFullSection={(type, id) => this.toggleFullSection(type, id)} onChangeViewAlert={() => this.changeViewAlert("self-service")} />
                                    <OrderFullService onToggleOrderSection={() => this.toggleOrderSection()} onToggleFullSection={(type, id) => this.toggleFullSection(type, id)} onChangeViewAlert={() => this.changeViewAlert("full-service")} />
                                </div>}
                        </div>
                    </div>
                    {this.state.showAlert === "self-service-right" &&
                        <OrderSelfServiceAlert
                            position={this.state.positionFocusOfAlert}
                            criteria={this.state.criteria}
                            handlePaginateChanged={(page, itemPerPage) => this.handlePaginateChanged(page, itemPerPage)}
                            handleOnBlurPageNumber={(value) => this.handleOnBlurPageNumber(value)}
                            clearPosition={() => this.clearPosition()}
                        />}
                    {this.state.showAlert === "full-service" &&
                        <OrderFullServiceAlert
                            position={this.state.positionFocusOfAlert}
                            criteria={this.state.criteria}
                            handlePaginateChanged={(page, itemPerPage) => this.handlePaginateChanged(page, itemPerPage)}
                            handleOnBlurPageNumber={(value) => this.handleOnBlurPageNumber(value)}
                            clearPosition={() => this.clearPosition()}
                        />}
                    {this.state.showAlert === "all-service" && <OrderAllServiceAlert />}
                </div>
                <ClientConfigurationModal onSave={() => this.handleClientConfigSave()} />
                <WelcomeModal onSendInvite={() => {
                    this.sendInviteModal.show();
                }} onSetMiscellaneous={() => {
                    this.props.router.push(`/profiles-settings`);
                }} ref={(welcomeModal) => {
                    if (welcomeModal && welcomeModal.getWrappedInstance) {
                        this.welcomeModal = welcomeModal.getWrappedInstance();
                    }
                }} />
                <SendInviteModal ref={(sendInviteModal) => {
                    if (sendInviteModal && sendInviteModal.getWrappedInstance) {
                        this.sendInviteModal = sendInviteModal.getWrappedInstance();
                    }
                }} />
            </div>
        );
    }
}

ClientDashboard.propTypes = {
    dispatch: PropTypes.func,
    profile: PropTypes.object,
    role: PropTypes.object,
    announcements: PropTypes.array,
    accountId: PropTypes.number,
    roleType: PropTypes.string,
    isShowAnnouncement: PropTypes.bool,
    roleNames: PropTypes.array,
    router: PropTypes.object
};

const mapStateToProps = (state) => {
    const { clientDashboard, authentication } = state;
    const { profile, role, accountId } = authentication;
    const { announcements, isShowAnnouncement } = clientDashboard.clientAnnouncements;

    return {
        profile,
        role,
        announcements,
        isShowAnnouncement,
        accountId,
        roleNames: role ? role.roleNames : [],
        roleType: role ? role.roleType : null
    };

};
export default connect(mapStateToProps)(ClientDashboard);