import { apiGetBranchManagement } from "Api/branch-api";

import { handleApiError } from "ErrorHandler";

export const LIST_BRANCH_MANAGEMENT = "LIST_BRANCH_MANAGEMENT";
export const BRANCHES_SET_FILTER = "BRANCHES_SET_FILTER";

export const setBranchFilter = (filter) => {
    if (filter.brokerID === "" && filter.company === "" && filter.contactFirst === "" && filter.contactLast === "") {
        filter.disabled = true;
    } else {
        filter.disabled = false;
    }

    return {
        type: BRANCHES_SET_FILTER,
        filter
    };
};

export const receiveListBranches = (listBranches) => {
    return {
        type: LIST_BRANCH_MANAGEMENT,
        listBranches
    };
};

export const getBranchManagement = () => {
    return (dispatch, getState) => {
        return apiGetBranchManagement(getState().branchManagement.branchSearch.filter, (response) => {
            response.data.listBranch.branches.map((item, key) => {
                if (item.Inactive) {
                    response.data.listBranch.branches[key].Inactive = response.data.listBranch.branches[key].Inactive.data[0] === 1 ? 1 : 0;
                } else response.data.listBranch.branches[key].Inactive = false;
                if (response.data.listBranch.branches[key].Inactive === 1) {
                    response.data.listBranch.branches[key].Inactive = "Inactive";
                } else {
                    response.data.listBranch.branches[key].Inactive = "Active";
                }
            });
            dispatch(receiveListBranches(response.data.listBranch));
        }, (error) => handleApiError(dispatch, error));
    };
};