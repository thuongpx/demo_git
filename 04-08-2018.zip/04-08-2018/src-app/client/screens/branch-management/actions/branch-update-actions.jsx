import { handleApiError } from "ErrorHandler";

import { apiGetBranchByBrokerId } from "Api/broker-api";
import { apiUpdateBranch } from "Api/branch-api";
import { apiDeleteReturnAddress, apiAddReturnAddress, apiUpdateReturnAddress } from "Api/return-address-api";
import { apiDeleteCcEmail, apiAddCcEmail, apiUpdateCcEmail } from "Api/broker-emails-api";

export const REQUEST_BRANCH_INFORMATION = "REQUEST_BRANCH_INFORMATION";
export const RECEIVE_BRANCH_INFORMATION = "RECEIVE_BRANCH_INFORMATION";
export const RECEIVE_BRANCH_RETURN_ADDR = "RECEIVE_BRANCH_RETURN_ADDR";
export const RECEIVE_STATE_DROPDOWN = "RECEIVE_STATE_DROPDOWN";
export const RECEIVE_BRANCH_CC_EMAIL = "RECEIVE_BRANCH_CC_EMAIL";
export const REQUEST_UPDATE_BRANCH = "REQUEST_UPDATE_BRANCH";
export const RECEIVE_UPDATE_BRANCH = "RECEIVE_UPDATE_BRANCH";
export const REQUEST_ADD_RETURN_ADDRESS = "REQUEST_ADD_RETURN_ADDRESS";
export const RECEIVE_ADD_RETURN_ADDRESS = "RECEIVE_ADD_RETURN_ADDRESS";
export const REQUEST_DELETE_RETURN_ADDRESS = "REQUEST_DELETE_RETURN_ADDRESS";
export const RECEIVE_DELETE_RETURN_ADDRESS = "RECEIVE_DELETE_RETURN_ADDRESS";
export const REQUEST_UPDATE_RETURN_ADDRESS = "REQUEST_UPDATE_RETURN_ADDRESS";
export const RECEIVE_UPDATE_RETURN_ADDRESS = "RECEIVE_UPDATE_RETURN_ADDRESS";
export const REQUEST_ADD_CC_EMAIL = "REQUEST_ADD_CC_EMAIL";
export const RECEIVE_ADD_CC_EMAIL = "RECEIVE_ADD_CC_EMAIL";
export const REQUEST_DELETE_CC_EMAIL = "REQUEST_DELETE_CC_EMAIL";
export const RECEIVE_DELETE_CC_EMAIL = "RECEIVE_DELETE_CC_EMAIL";
export const REQUEST_UPDATE_CC_EMAIL = "REQUEST_UPDATE_CC_EMAIL";
export const RECEIVE_UPDATE_CC_EMAIL = "RECEIVE_UPDATE_CC_EMAIL";

export const SET_BRANCH_INFORMATION = "SET_BRANCH_INFORMATION";


export const requestBranchInformation = () => {
    return {
        type: REQUEST_BRANCH_INFORMATION
    };
};

export const receiveBranchInformation = (data) => {
    return {
        type: RECEIVE_BRANCH_INFORMATION,
        data
    };
};

export const receiveBranchReturnAddr = (data) => {
    return {
        type: RECEIVE_BRANCH_RETURN_ADDR,
        data
    };
};

export const receiveBranchCcEmail = (data) => {
    return {
        type: RECEIVE_BRANCH_CC_EMAIL,
        data
    };
};

export const receiveStateDropdown = (data) => {
    return {
        type: RECEIVE_STATE_DROPDOWN,
        data
    };
};

export const setBranchInformation = (data) => {
    return {
        type: SET_BRANCH_INFORMATION,
        data
    };
};

export const branchUpdateRequest = () => {
    return {
        type: REQUEST_UPDATE_BRANCH
    };
};

export const branchUpdateReceive = () => {
    return {
        type: RECEIVE_UPDATE_BRANCH
    };
};

export const returnAddressAddRequest = () => {
    return {
        type: REQUEST_ADD_RETURN_ADDRESS
    };
};

export const returnAddressAddReceive = () => {
    return {
        type: RECEIVE_ADD_RETURN_ADDRESS
    };
};

export const returnAddressDeleteRequest = () => {
    return {
        type: REQUEST_DELETE_RETURN_ADDRESS
    };
};

export const returnAddressDeleteReceive = () => {
    return {
        type: RECEIVE_DELETE_RETURN_ADDRESS
    };
};

export const returnAddressUpdateRequest = () => {
    return {
        type: REQUEST_UPDATE_RETURN_ADDRESS
    };
};

export const returnAddressUpdateReceive = () => {
    return {
        type: RECEIVE_UPDATE_RETURN_ADDRESS
    };
};


export const returnEmailAddRequest = () => {
    return {
        type: REQUEST_ADD_CC_EMAIL
    };
};

export const returnEmailAddReceive = () => {
    return {
        type: RECEIVE_ADD_CC_EMAIL
    };
};

export const returnEmailDeleteRequest = () => {
    return {
        type: REQUEST_DELETE_CC_EMAIL
    };
};

export const returnEmailDeleteReceive = () => {
    return {
        type: RECEIVE_DELETE_CC_EMAIL
    };
};

export const returnEmailUpdateRequest = () => {
    return {
        type: REQUEST_UPDATE_CC_EMAIL
    };
};

export const returnEmailUpdateReceive = () => {
    return {
        type: RECEIVE_UPDATE_CC_EMAIL
    };
};

export const getBranchInformation = (brokerId, customerId, firstLoad) => {
    return dispatch => {
        const identify = {
            brokerId,
            customerId
        };
        dispatch(requestBranchInformation());
        if (firstLoad) {
            return apiGetBranchByBrokerId((identify), (result) => {
                dispatch(receiveBranchInformation(result.data.branch));
                dispatch(receiveBranchReturnAddr(result.data.returnAddr));
                dispatch(receiveBranchCcEmail(result.data.ccEmail));
                dispatch(receiveStateDropdown(result.data.state));
            }, (error) => handleApiError(dispatch, error));
        } else {
            return apiGetBranchByBrokerId((identify), (result) => {
                dispatch(receiveBranchReturnAddr(result.data.returnAddr));
                dispatch(receiveBranchCcEmail(result.data.ccEmail));
            }, (error) => handleApiError(dispatch, error));
        }
    };
};

export const updateBranch = (branch) => {
    return dispatch => {
        dispatch(branchUpdateRequest());
        return apiUpdateBranch(branch, (result) => {
            dispatch(branchUpdateReceive(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const addReturnAddress = (returnAddr) => {
    return dispatch => {
        dispatch(returnAddressAddRequest());
        return apiAddReturnAddress(returnAddr, (result) => {
            dispatch(returnAddressAddReceive(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const deleteReturnAddress = (raId) => {
    return dispatch => {
        dispatch(returnAddressDeleteRequest());
        return apiDeleteReturnAddress(raId, (result) => {
            dispatch(returnAddressDeleteReceive(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const updateReturnAddress = (criteria) => {
    return dispatch => {
        dispatch(returnAddressUpdateRequest());
        return apiUpdateReturnAddress(criteria, (result) => {
            dispatch(returnAddressUpdateReceive(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const addCcEmail = (returnAddr) => {
    return dispatch => {
        dispatch(returnEmailAddRequest());
        return apiAddCcEmail(returnAddr, (result) => {
            dispatch(returnEmailAddReceive(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const deleteCcEmail = (BrokerEmailId) => {
    return dispatch => {
        dispatch(returnEmailDeleteRequest());
        return apiDeleteCcEmail(BrokerEmailId, (result) => {
            dispatch(returnEmailDeleteReceive(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const updateCcEmail = (ccEmail) => {
    return dispatch => {
        dispatch(returnEmailUpdateRequest());
        return apiUpdateCcEmail(ccEmail, (result) => {
            dispatch(returnEmailUpdateReceive(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};