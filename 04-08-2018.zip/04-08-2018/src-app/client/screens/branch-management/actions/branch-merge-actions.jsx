import { showSuccess } from "../../main-layout/actions";
import { handleApiError } from "ErrorHandler";
import { apiCheckBranchMergeable, apiMergeBranch, apiDisableBranch } from "Api/branch-api";

import { SUCCESSFULLY_UPDATE_MESSAGE } from "../../../constant/constants";

export const OPEN_MODAL = "OPEN_MODAL";
export const CLOSE_MODAL = "CLOSE_MODAL";
export const RECEIVE_BRANCH_MERGE_STATUS = "RECEIVE_BRANCH_MERGE_STATUS";
export const REQUEST_DISABLE_BRANCH = "REQUEST_DISABLE_BRANCH";
export const RECEIVE_DISABLE_BRANCH = "RECEIVE_DISABLE_BRANCH";

export const openModal = (branchId) => {
    return {
        type: OPEN_MODAL,
        branchId
    };
};

export const closeModal = () => {
    return {
        type: CLOSE_MODAL
    };
};

export const branchMergeStatusReceive = (data) => {
    return {
        type: RECEIVE_BRANCH_MERGE_STATUS,
        data
    };
};

export const disableBranchRequest = () => {
    return {
        type: REQUEST_DISABLE_BRANCH
    };
};


export const disableBranchReceive = () => {
    return {
        type: RECEIVE_DISABLE_BRANCH
    };
};

export const checkBranchMergeCondition = (branchId, userId) => {
    return dispatch => {
        dispatch(openModal(branchId));
        return apiCheckBranchMergeable(branchId, userId, (result) => {
            dispatch(branchMergeStatusReceive(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const mergeBranch = (originId, destinationId) => {
    return dispatch => {
        dispatch(disableBranchRequest());
        return apiMergeBranch(originId, destinationId, () => {
            return apiDisableBranch(originId, (output) => {
                dispatch(disableBranchReceive(output.data));
                dispatch(showSuccess(SUCCESSFULLY_UPDATE_MESSAGE));
            }, (error) => handleApiError(dispatch, error));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const disableBranch = (branchId) => {
    return dispatch => {
        dispatch(disableBranchRequest());
        return apiDisableBranch(branchId, (result) => {
            dispatch(disableBranchReceive(result.data));
            dispatch(showSuccess(SUCCESSFULLY_UPDATE_MESSAGE));
        }, (error) => handleApiError(dispatch, error));
    };
};