import { handleApiError } from "ErrorHandler";
import { apiGetAdminByBrokerId } from "Api/broker-api";
import { apiAddBranch } from "Api/user-api";

export const RECEIVE_LIST_STATE = "RECEIVE_LIST_STATE";
export const RECEIVE_LIST_RETURN_ADDR = "RECEIVE_LIST_RETURN_ADDR";
export const REQUEST_ADMIN_INFORMATION = "REQUEST_ADMIN_INFORMATION";
export const RECEIVE_ADMIN_INFORMATION = "RECEIVE_ADMIN_INFORMATION";
export const SET_BRANCH_STATE = "SET_BRANCH_STATE";
export const SET_BRANCH_VALIDATOR = "SET_BRANCH_VALIDATOR";
export const REQUEST_ADD_BRANCH = "REQUEST_ADD_BRANCH";
export const RECEIVE_ADD_BRANCH = "RECEIVE_ADD_BRANCH";

export const receiveListState = (data) => {
    return {
        type: RECEIVE_LIST_STATE,
        data
    };
};

export const receiveListReturnAddr = (data) => {
    return {
        type: RECEIVE_LIST_RETURN_ADDR,
        data
    };
};

export const requestAdminInformation = () => {
    return {
        type: REQUEST_ADMIN_INFORMATION
    };
};

export const receiveAdminInformation = (data) => {
    return {
        type: RECEIVE_ADMIN_INFORMATION,
        data
    };
};

export const setBranchState = (branch) => {
    return {
        type: SET_BRANCH_STATE,
        branch
    };
};

export const setBranchValidator = (validator) => {
    return {
        type: SET_BRANCH_VALIDATOR,
        validator
    };
};

export const branchAddRequest = () => {
    return {
        type: REQUEST_ADD_BRANCH
    };
};

export const branchAddReceive = () => {
    return {
        type: RECEIVE_ADD_BRANCH
    };
};

export const getAdminInformation = (brokerId) => {
    return dispatch => {
        dispatch(requestAdminInformation());

        return apiGetAdminByBrokerId(brokerId, (result) => {
            dispatch(receiveListReturnAddr(result.data.returnAddr));
            dispatch(receiveListState(result.data.state));
            dispatch(receiveAdminInformation(result.data.admin));
        }, (error) => handleApiError(dispatch, error));
    };
};

export const addBranch = (branch) => {
    return dispatch => {
        dispatch(branchAddRequest());

        return apiAddBranch(branch, (result) => {
            dispatch(branchAddReceive(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};