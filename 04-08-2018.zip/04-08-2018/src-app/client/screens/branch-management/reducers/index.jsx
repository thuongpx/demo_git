import { combineReducers } from "redux";
import branchSearchReducer from "./branch-search-reducers";
import branchAddReducer from "./branch-add-reducers";
import branchUpdateReducer from "./branch-update-reducers";
import branchMergeReducer from "./branch-merge-reducers";

const branchManagementReducers = combineReducers({
    branchSearch: branchSearchReducer,
    branchAdd: branchAddReducer,
    branchUpdate: branchUpdateReducer,
    branchMerge: branchMergeReducer
});

export default branchManagementReducers;