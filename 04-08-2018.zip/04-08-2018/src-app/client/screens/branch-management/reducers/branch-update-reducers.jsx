import {
    REQUEST_BRANCH_INFORMATION, RECEIVE_BRANCH_INFORMATION, SET_BRANCH_INFORMATION, REQUEST_UPDATE_BRANCH, RECEIVE_UPDATE_BRANCH, RECEIVE_BRANCH_CC_EMAIL,
    RECEIVE_BRANCH_RETURN_ADDR, REQUEST_DELETE_RETURN_ADDRESS, RECEIVE_DELETE_RETURN_ADDRESS, REQUEST_ADD_RETURN_ADDRESS, RECEIVE_ADD_RETURN_ADDRESS,
    REQUEST_ADD_CC_EMAIL, RECEIVE_ADD_CC_EMAIL, REQUEST_DELETE_CC_EMAIL, RECEIVE_DELETE_CC_EMAIL, REQUEST_UPDATE_CC_EMAIL, RECEIVE_UPDATE_CC_EMAIL,
    RECEIVE_STATE_DROPDOWN, REQUEST_UPDATE_RETURN_ADDRESS, RECEIVE_UPDATE_RETURN_ADDRESS
} from "./../actions/branch-update-actions";

import { REQUEST_ADD_BRANCH, RECEIVE_ADD_BRANCH } from "./../actions/branch-add-actions";

import { REQUEST_DISABLE_BRANCH, RECEIVE_DISABLE_BRANCH } from "./../actions/branch-merge-actions";

export default function branchUpdateReducer(state = {
    isFetching: false,
    branchInformation: {},
    branchReturnAddr: [],
    branchCcEmail: [],
    stateDropDown: [],
    needReload: false
}, action) {
    switch (action.type) {
        case REQUEST_BRANCH_INFORMATION:
            return {
                ...state,
                isFetching: true
            };
        case RECEIVE_BRANCH_INFORMATION:
            return {
                ...state,
                isFetching: false,
                branchInformation: action.data
            };
        case RECEIVE_BRANCH_RETURN_ADDR:
            return {
                ...state,
                isFetching: false,
                branchReturnAddr: action.data
            };
        case RECEIVE_BRANCH_CC_EMAIL:
            return {
                ...state,
                isFetching: false,
                branchCcEmail: action.data
            };
        case RECEIVE_STATE_DROPDOWN:
            return {
                ...state,
                isFetching: false,
                stateDropDown: action.data
            };
        case SET_BRANCH_INFORMATION:
            return {
                ...state,
                branchInformation: action.data
            };
        case REQUEST_UPDATE_BRANCH:
            return {
                ...state,
                isFetching: true,
                needReload: true
            };
        case RECEIVE_UPDATE_BRANCH:
            return {
                ...state,
                isFetching: false,
                needReload: false
            };
        case REQUEST_ADD_BRANCH:
            return {
                ...state,
                isFetching: true,
                needReload: true
            };
        case RECEIVE_ADD_BRANCH:
            return {
                ...state,
                isFetching: false,
                needReload: false
            };
        case REQUEST_ADD_RETURN_ADDRESS:
            return {
                ...state,
                isFetching: true,
                needReload: true
            };
        case RECEIVE_ADD_RETURN_ADDRESS:
            return {
                ...state,
                isFetching: false,
                needReload: false
            };
        case REQUEST_DELETE_RETURN_ADDRESS:
            return {
                ...state,
                isFetching: true,
                needReload: true
            };
        case RECEIVE_DELETE_RETURN_ADDRESS:
            return {
                ...state,
                isFetching: false,
                needReload: false
            };
        case REQUEST_UPDATE_RETURN_ADDRESS:
            return {
                ...state,
                isFetching: true,
                needReload: true
            };
        case RECEIVE_UPDATE_RETURN_ADDRESS:
            return {
                ...state,
                isFetching: false,
                needReload: false
            };
        case REQUEST_ADD_CC_EMAIL:
            return {
                ...state,
                isFetching: true,
                needReload: true
            };
        case RECEIVE_ADD_CC_EMAIL:
            return {
                ...state,
                isFetching: false,
                needReload: false
            };
        case REQUEST_DELETE_CC_EMAIL:
            return {
                ...state,
                isFetching: true,
                needReload: true
            };
        case RECEIVE_DELETE_CC_EMAIL:
            return {
                ...state,
                isFetching: false,
                needReload: false
            };
        case REQUEST_UPDATE_CC_EMAIL:
            return {
                ...state,
                isFetching: true,
                needReload: true
            };
        case RECEIVE_UPDATE_CC_EMAIL:
            return {
                ...state,
                isFetching: false,
                needReload: false
            };
        case REQUEST_DISABLE_BRANCH:
            return {
                ...state,
                isFetching: true,
                needReload: true
            };
        case RECEIVE_DISABLE_BRANCH:
            return {
                ...state,
                isFetching: false,
                needReload: false
            };
        default:
            return state;
    }
}