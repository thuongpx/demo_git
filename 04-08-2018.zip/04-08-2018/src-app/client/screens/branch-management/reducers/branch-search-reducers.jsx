import { LIST_BRANCH_MANAGEMENT, BRANCHES_SET_FILTER } from "./../actions/branch-search-actions";

export default function branchSearchReducer(state = {
    isFetching: false,
    needReload: false,
    listBranches: {},
    brokerId: 0,
    filter: {
        sortColumn: "RowNumber",
        sortDirection: false,
        page: 1,
        itemPerPage: 25,
        brokerID: "",
        company: "",
        contactFirst: "",
        contactLast: "",
        GID: 0
    },
    isShowModal: false
}, action) {
    switch (action.type) {
        case BRANCHES_SET_FILTER:
            return {
                ...state,
                filter: action.filter
            };
        case LIST_BRANCH_MANAGEMENT:
            return {
                ...state,
                isFetching: false,
                listBranches: action.listBranches
            };
        default:
            return state;
    }
}