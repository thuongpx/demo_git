import {
    RECEIVE_LIST_STATE, RECEIVE_LIST_RETURN_ADDR, SET_BRANCH_STATE, SET_BRANCH_VALIDATOR,
    REQUEST_ADMIN_INFORMATION, RECEIVE_ADMIN_INFORMATION,
    REQUEST_ADD_BRANCH, RECEIVE_ADD_BRANCH
} from "./../actions/branch-add-actions";

export default function branchAddReducer(state = {
    isFetching: false,
    listState: [],
    listReturnAddr: [],
    adminInformation: {},
    branches: {
        CourierId: 1,
        State: "AL"
    },
    validator: {}
}, action) {
    switch (action.type) {
        case RECEIVE_LIST_STATE:
            return {
                ...state,
                listState: action.data
            };
        case RECEIVE_LIST_RETURN_ADDR:
            return {
                ...state,
                listReturnAddr: action.data
            };
        case REQUEST_ADMIN_INFORMATION:
            return {
                ...state,
                isFetching: true
            };
        case RECEIVE_ADMIN_INFORMATION:
            return {
                ...state,
                isFetching: false,
                adminInformation: action.data
            };
        case SET_BRANCH_STATE:
            return {
                ...state,
                branches: action.branch
            };
        case SET_BRANCH_VALIDATOR:
            return {
                ...state,
                validator: action.validator
            };
        case REQUEST_ADD_BRANCH:
            return {
                ...state,
                isFetching: true
            };
        case RECEIVE_ADD_BRANCH:
            return {
                ...state,
                isFetching: false
            };
        default:
            return state;
    }
}