import { OPEN_MODAL, CLOSE_MODAL, RECEIVE_BRANCH_MERGE_STATUS, REQUEST_DISABLE_BRANCH, RECEIVE_DISABLE_BRANCH } from "./../actions/branch-merge-actions";

export default function branchSearchReducer(state = {
    isFetching: false,
    needReload: false,
    agentEmpty: true,
    orderEmpty: true,
    listMerge: []
}, action) {
    switch (action.type) {
        case OPEN_MODAL:
            return {
                ...state,
                isShowModal: true,
                branchId: action.branchId
            };
        case CLOSE_MODAL:
            return {
                ...state,
                isShowModal: false
            };
        case RECEIVE_BRANCH_MERGE_STATUS:
            return {
                ...state,
                agentEmpty: action.data.agentEmpty,
                orderEmpty: action.data.orderEmpty,
                listMerge: action.data.listMerge
            };
        case REQUEST_DISABLE_BRANCH:
            return {
                ...state,
                isFetching: true,
                needReload: true
            };
        case RECEIVE_DISABLE_BRANCH:
            return {
                ...state,
                isFetching: false,
                needReload: false
            };
        default:
            return state;
    }
}