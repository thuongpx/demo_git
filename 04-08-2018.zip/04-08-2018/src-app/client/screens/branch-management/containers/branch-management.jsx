import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import BranchAdd from "../components/branch-add";
import BranchUpdate from "../components/branch-update";

class BranchManagement extends Component {
    handleRedirect(url) {
        this.props.router.push(url);
    }

    render() {
        if (this.props.params.brokerId === "0" || this.props.params.brokerId === undefined) {
            return (
                <BranchAdd redirect={(url) => this.handleRedirect(url)} />
            );
        } else {
            return (
                <BranchUpdate redirect={(url) => this.handleRedirect(url)} updateId={this.props.params.brokerId} />
            );
        }
    }
}

BranchManagement.propTypes = {
    params: PropTypes.object,
    router: PropTypes.object,
    push: PropTypes.func
};

export default BranchManagement;