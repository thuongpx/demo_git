import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import InputMask from "react-input-mask";
import { validateRequired, validatePhone, validateZip, validateEmail, validatePassword, validateCompare, comparePasswordMessage, requireMessage, invalidMessage, invalidPasswordMessage, existingUsernameMessage } from "Helpers/validation-helper";
import { apiCheckExistUser } from "Api/user-api";
import CommonModal from "CommonModal";
import Select from "Select";
import PasswordPopover from "../../../features/password-popover/password-popover";
import { showSuccess, showError } from "../../main-layout/actions";
import { SUCCESSFULLY_CREATED_MESSAGE } from "Constants";
import { getStateCodeAndCityFromZip } from "Helpers/location-helper";
import { getAdminInformation, setBranchState, setBranchValidator, addBranch } from "../actions/branch-add-actions";
import { updateTextFields } from "../../../helpers/theme-helper";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import { INPUT_ERROR_1X_IMAGE_URL } from "ImageConfig";
import { convertToPhoneNumber } from "Helpers/common-helper";
import { handleApiError } from "ErrorHandler";

import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";

export class BranchAdd extends Component {
    constructor(props) {
        super(props);
    }

    componentWillUnmount() {
        const { dispatch } = this.props;
        dispatch(setBranchState({}));
    }

    componentDidMount() {
        const { dispatch, userId } = this.props;
        dispatch(getAdminInformation(userId));

        $("#btnSaveBranch").keydown((e) => {
            if ((e.which || e.keyCode) === 9) {
                e.preventDefault();
                $("#company").focus();
                //$(`#company`).attr("class", "tabbed");
            }
        });
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.isOpen !== this.props.isOpen && nextProps.isOpen) {
            setTimeout(() => {
                $(`#company`).focus();
            }, 200);
        }
    }

    componentDidUpdate() {
        updateTextFields();
    }

    handleValidateCompany() {
        const { dispatch } = this.props;
        const isRequireCompany = !validateRequired(this.refs.company.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireCompany }));
        return isRequireCompany;
    }

    handleValidatePhone() {
        const { dispatch } = this.props;
        const isFormatPhone = this.handleValidatePhoneFormat();
        const isRequirePhone = this.handleValidatePhoneRequire();
        dispatch(setBranchValidator({ ...this.props.validator, isFormatPhone, isRequirePhone }));
    }

    handleValidatePhoneFormat() {
        const { dispatch } = this.props;
        const isFormatPhone = !validatePhone(this.refs.phone.value);
        dispatch(setBranchValidator({ ...this.props.validator, isFormatPhone }));
        return isFormatPhone;
    }

    handleValidatePhoneRequire() {
        const { dispatch } = this.props;
        const isRequirePhone = !validateRequired(this.refs.phone.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequirePhone }));
        return isRequirePhone;
    }

    handleValidateFaxFormat() {
        const { dispatch } = this.props;
        const isFormatFax = !validatePhone(this.refs.contactFax.value);
        dispatch(setBranchValidator({ ...this.props.validator, isFormatFax }));
        return isFormatFax;
    }

    handleValidateAddress() {
        const { dispatch } = this.props;
        const isRequireAddress = !validateRequired(this.refs.address.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireAddress }));
        return isRequireAddress;
    }

    handleValidateCity() {
        const { dispatch } = this.props;
        const isRequireCity = !validateRequired(this.refs.city.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireCity }));
        return isRequireCity;
    }

    handleValidateState() {
        const { dispatch, branches } = this.props;
        const isRequireState = !validateRequired(branches.State);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireState }));
        return isRequireState;
    }

    handleValidateZipCode() {
        const { dispatch, branches } = this.props;
        const isRequireZipCode = this.handleValidateZipCodeRequired();
        const isFormatZipCode = this.handleValidateZipCodeFormat();
        dispatch(setBranchValidator({ ...this.props.validator, isRequireZipCode, isFormatZipCode }));

        if (!isFormatZipCode) {
            getStateCodeAndCityFromZip(this.refs.zipCode.value, (zipString) => {
                if (zipString !== "Invalid Zip Code" && zipString.country === "United States") {
                    if (branches.State !== "" && branches.State !== undefined && branches.City !== "" && branches.City !== undefined) {
                        const zipNotMatchMess = `The City ${branches.State !== zipString.state && branches.City !== zipString.city ? "and" : "or"} State do not match the Zip entered. Do you mean the signing address as follows? [${zipString.city}, ${zipString.state}, ${this.refs.zipCode.value}]. Click Yes to use that suggested address. Click No to re-enter the correct address.`;
                        if (branches.State === "" && branches.City === zipString.city) {
                            dispatch(setBranchState({ ...branches, State: zipString.state }));
                            // set state ref
                            dispatch(setBranchValidator({ ...this.props.validator, isRequireState: false }));
                        } else if (branches.City === "" && branches.State === zipString.state) {
                            dispatch(setBranchState({ ...branches, City: zipString.city }));
                            this.refs.city.value = zipString.city;
                            dispatch(setBranchValidator({ ...this.props.validator, isRequireCity: false }));
                        } else if (branches.City === zipString.city && branches.State === zipString.state) {
                            //
                        } else {
                            this.commonModal.showModal({
                                type: "warning",
                                message: zipNotMatchMess
                            }, () => {
                                dispatch(setBranchState({ ...branches, State: zipString.state, City: zipString.city }));
                                //set validator
                                dispatch(setBranchValidator({ ...this.props.validator, isRequireCity: false }));
                                dispatch(setBranchValidator({ ...this.props.validator, isRequireState: false }));
                            }, () => {
                                // handle callback no click here
                                dispatch(setBranchState({ ...branches, State: "", City: "", ZipCode: "" }));
                                setTimeout(() => {
                                    $("#zipcode").focus();
                                }, 200);
                            });
                        }
                    } else {
                        dispatch(setBranchState({ ...branches, State: zipString.state, City: zipString.city }));

                        //set validator
                        dispatch(setBranchValidator({ ...this.props.validator, isRequireCity: false }));
                        dispatch(setBranchValidator({ ...this.props.validator, isRequireState: false }));
                    }
                } else {

                    dispatch(showError("Your inputted Zip is not a valid US Zip Code. Please try again.", () => {
                        dispatch(setBranchState({ ...branches, ZipCode: "" }));
                        dispatch(setBranchValidator({ ...this.props.validator, isFormatZipCode: true }));
                        $("#zipcode").focus();
                    }));
                }
            });
        }
    }

    handleValidateZipCodeRequired() {
        const { dispatch } = this.props;
        const isRequireZipCode = !validateRequired(this.refs.zipCode.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireZipCode }));
        return isRequireZipCode;
    }

    handleValidateZipCodeFormat() {
        const { dispatch } = this.props;
        const isFormatZipCode = !validateZip(this.refs.zipCode.value);
        dispatch(setBranchValidator({ ...this.props.validator, isFormatZipCode }));
        return isFormatZipCode;
    }

    handleValidateContactFirst() {
        const { dispatch } = this.props;
        const isRequireContactFirst = !validateRequired(this.refs.contactFirst.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireContactFirst }));
        return isRequireContactFirst;
    }

    handleValidateContactLast() {
        const { dispatch } = this.props;
        const isRequireContactLast = !validateRequired(this.refs.contactLast.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireContactLast }));
        return isRequireContactLast;
    }

    handleValidateContactEmail() {
        const { dispatch } = this.props;
        const isRequireContactEmail = this.handleValidateContactEmailRequire();
        const isFormatContactEmail = this.handleValidateContactEmailFormat();
        dispatch(setBranchValidator({ ...this.props.validator, isFormatContactEmail, isRequireContactEmail }));
    }

    handleValidateContactEmailRequire() {
        const { dispatch } = this.props;
        const isRequireContactEmail = !validateRequired(this.refs.contactEmail.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireContactEmail }));
        return isRequireContactEmail;
    }

    handleValidateContactEmailFormat() {
        const { dispatch } = this.props;
        const isFormatContactEmail = !validateEmail(this.refs.contactEmail.value);
        dispatch(setBranchValidator({ ...this.props.validator, isFormatContactEmail }));
        return isFormatContactEmail;
    }

    handleValidateUsername() {
        const { dispatch } = this.props;
        const isRequireUsername = this.handleValidateUsernameRequire();
        const isExistUsername = this.handleValidateUsernameFormat();
        dispatch(setBranchValidator({ ...this.props.validator, isRequireUsername, isExistUsername }));
    }

    handleValidateUsernameRequire() {
        const { dispatch } = this.props;
        const isRequireUsername = !validateRequired(this.refs.username.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireUsername }));
        return isRequireUsername;
    }

    async handleValidateUsernameFormat() {
        const { dispatch } = this.props;
        let isExistUsername = false;

        try {
            const response = await apiCheckExistUser(this.refs.username.value);
            isExistUsername = response.data.isExist;
            dispatch(setBranchValidator({ ...this.props.validator, isExistUsername }));

        } catch (error) {
            handleApiError(dispatch, error);
        }

        return isExistUsername;
    }

    handleValidatePassword() {
        const { dispatch } = this.props;
        const isRequirePassword = this.handleValidatePasswordRequire();
        const isFormatPassword = this.handleValidatePasswordFormat();
        dispatch(setBranchValidator({ ...this.props.validator, isFormatPassword, isRequirePassword }));
    }

    handleValidatePasswordRequire() {
        const { dispatch } = this.props;
        const isRequirePassword = !validateRequired(this.refs.password.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequirePassword }));
        return isRequirePassword;
    }

    handleValidatePasswordFormat() {
        const { dispatch } = this.props;
        const isFormatPassword = !validatePassword(this.refs.password.value);
        dispatch(setBranchValidator({ ...this.props.validator, isFormatPassword }));
        return isFormatPassword;
    }

    handleValidateVerifyPassword() {
        const { dispatch } = this.props;
        const isRequireVerifyPassword = this.handleValidateVerifyPasswordRequire();
        const isFormatVerifyPassword = this.handleValidateVerifyPasswordFormat();
        dispatch(setBranchValidator({ ...this.props.validator, isFormatVerifyPassword, isRequireVerifyPassword }));
    }

    handleValidateVerifyPasswordRequire() {
        const { dispatch } = this.props;
        const isRequireVerifyPassword = !validateRequired(this.refs.verifyPassword.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireVerifyPassword }));
        return isRequireVerifyPassword;
    }

    handleValidateVerifyPasswordFormat() {
        const { dispatch } = this.props;
        const isFormatVerifyPassword = !validateCompare(this.refs.password.value, this.refs.verifyPassword.value);
        dispatch(setBranchValidator({ ...this.props.validator, isFormatVerifyPassword }));
        return isFormatVerifyPassword;
    }

    async validateForm() {
        const { dispatch } = this.props;
        const isRequireCompany = this.handleValidateCompany();
        const isFormatPhone = this.handleValidatePhoneFormat();
        const isRequirePhone = this.handleValidatePhoneRequire();
        const isRequireAddress = this.handleValidateAddress();
        const isRequireCity = this.handleValidateCity();
        const isRequireState = this.handleValidateState();
        const isRequireZipCode = this.handleValidateZipCodeRequired();
        const isFormatZipCode = this.handleValidateZipCodeFormat();
        const isRequireContactFirst = this.handleValidateContactFirst();
        const isRequireContactLast = this.handleValidateContactLast();
        const isRequireContactEmail = this.handleValidateContactEmailRequire();
        const isFormatContactEmail = this.handleValidateContactEmailFormat();
        const isRequireUsername = this.handleValidateUsernameRequire();
        const isExistUsername = await this.handleValidateUsernameFormat();
        const isRequirePassword = this.handleValidatePasswordRequire();
        const isFormatPassword = this.handleValidatePasswordFormat();
        const isRequireVerifyPassword = this.handleValidateVerifyPasswordRequire();
        const isFormatVerifyPassword = this.handleValidateVerifyPasswordFormat();
        const isFormatFax = this.handleValidateFaxFormat();

        const validator = {
            isRequireCompany,
            isRequirePhone,
            isFormatPhone,
            isRequireAddress,
            isRequireCity,
            isRequireState,
            isRequireZipCode,
            isFormatZipCode,
            isRequireContactFirst,
            isRequireContactLast,
            isRequireContactEmail,
            isFormatContactEmail,
            isRequireUsername,
            isExistUsername,
            isRequirePassword,
            isFormatPassword,
            isRequireVerifyPassword,
            isFormatVerifyPassword,
            isFormatFax
        };

        dispatch(setBranchValidator(validator));
        for (const key in validator) {
            if (validator[key]) {
                return false;
            }
        }

        return true;
    }

    saveChanges() {
        const { userId, listReturnAddr, branches, adminInformation } = this.props;

        const newBranch = {
            company: branches.Company,
            phone: convertToPhoneNumber(branches.Phone),
            address: branches.Address,
            suite: branches.Suite,
            city: branches.City,
            state: branches.State,
            zip: branches.ZipCode,
            adminFirst: adminInformation.AdministratorFirst,
            adminLast: adminInformation.AdministratorLast,
            adminExt: adminInformation.AdministratorExt,
            adminEmail: adminInformation.AdministratorEmail,
            contactFirst: branches.ContactFirst,
            contactLast: branches.ContactLast,
            contactEmail: branches.ContactEmail,
            contactExt: this.refs.contactExt.value,
            contactFax: convertToPhoneNumber(branches.contactFax),
            userName: branches.Username,
            password: branches.Password,
            GID: userId,
            listReturnAddr
        };

        const { dispatch } = this.props;
        dispatch(addBranch(newBranch));
        dispatch(showSuccess(SUCCESSFULLY_CREATED_MESSAGE));
    }

    async handleSaveClick() {
        if (await this.validateForm()) {
            const { dispatch } = this.props;

            this.saveChanges();
            dispatch(setBranchState({}));
            this.refs.phone.value = "";
            this.refs.contactExt.value = "";
            this.refs.contactFax.value = "";
        }
    }

    async handleSaveCloseClick() {
        if (await this.validateForm()) {
            const { dispatch } = this.props;

            this.saveChanges();
            dispatch(setBranchState({}));
            this.refs.phone.value = "";
            this.refs.contactExt.value = "";
            this.refs.contactFax.value = "";
            this.props.handleCancel();
        }
    }

    handleShowCancelConfirm() {
        this.commonModal.showModal({
            type: "confirm",
            message: "Are you sure you want to cancel adding this Branch/Division?"
        }, () => {
            const { dispatch } = this.props;
            dispatch(setBranchValidator({}));
            dispatch(setBranchState({}));
            this.props.handleCancel();
        }, () => {
            $("#btnCancelBranch").focus();
        });
    }

    handleOpenModalEnd() {
        this.refs.company.focus();
    }

    handleChangeUsername() {
        const { dispatch, branches } = this.props;
        const username = String(this.refs.username.value.trim()).split(" ").join("");

        dispatch(setBranchState({ ...branches, Username: username }));
    }

    render() {
        const { listState, validator, branches, dispatch, isFetching, isOpen } = this.props;

        const modalOptions = {
            onOpenEnd: () => this.handleOpenModalEnd()
        };

        return (
            <div>
                <Modal isOpen={isOpen} addClass="no-tab" modalOptions={modalOptions}>
                    <ModalBody>
                        <ModalTitle onClickClose={() => { this.handleShowCancelConfirm(); }}>Add Branch/Division</ModalTitle>
                        <div className="tab-content">
                            {/* branch information row group */}
                            <div className="row">
                                {/* address col group */}
                                <div className="col s12 m6">
                                    <div className="row">
                                        <div className={`input-field col s12 required suffixinput ${validator.isRequireCompany ? "required-field" : ""}`}>
                                            <input type="text" maxLength="50" value={branches.Company || ""}
                                                onChange={() => dispatch(setBranchState({ ...branches, Company: this.refs.company.value }))}
                                                onBlur={() => this.handleValidateCompany()}
                                                id="company" ref="company" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="company">Branch/Division Name</label>
                                            <span className={`suffix-text ${validator.isRequireCompany ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Branch/Division Name")} />
                                            </span>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className={`input-field col s12 required suffixinput ${validator.isRequireAddress ? "required-field" : ""}`}>
                                            <input type="text" maxLength="50" value={branches.Address || ""}
                                                onChange={() => dispatch(setBranchState({ ...branches, Address: this.refs.address.value }))}
                                                onBlur={() => this.handleValidateAddress()}
                                                id="address" ref="address" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="address">Street # and Address</label>
                                            <span className={`suffix-text ${validator.isRequireAddress ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Stress # and Address")} />
                                            </span>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="input-field col s12">
                                            <input type="text" maxLength="50" value={branches.Suite || ""}
                                                onChange={() => dispatch(setBranchState({ ...branches, Suite: this.refs.suite.value }))} id="suite" ref="suite"
                                            />
                                            <label htmlFor="suite">Unit #, Suite #, etc...</label>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className={`input-field col s4 required suffixinput ${validator.isRequireZipCode ? "required-field" : ""} ${validator.isFormatZipCode ? "has-error" : ""}`}>
                                            <InputMask
                                                type="text"
                                                value={branches.ZipCode}
                                                onChange={() => dispatch(setBranchState({ ...branches, ZipCode: this.refs.zipCode.value }))}
                                                onBlur={() => this.handleValidateZipCode()}
                                                mask="99999" style={{ paddingRight: "15px" }}
                                                id="zipcode" ref="zipCode"
                                                value={branches.ZipCode || ""}
                                            />
                                            <label htmlFor="zipcode">Zip</label>
                                            <span className={`suffix-text ${validator.isRequireZipCode ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Zip")} />
                                            </span>
                                            <span className={`suffix-text ${validator.isFormatZipCode ? "" : "hide"}`}>
                                                <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Zip")} />
                                            </span>
                                        </div>
                                        <div className={`input-field col s8 required suffixinput ${validator.isRequireCity ? "required-field" : ""}`}>
                                            <input type="text" maxLength="20" value={branches.City || ""}
                                                onChange={() => dispatch(setBranchState({ ...branches, City: this.refs.city.value.trim(), ZipCode: "" }))}
                                                onBlur={() => this.handleValidateCity()}
                                                id="city" ref="city" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="city">City</label>
                                            <span className={`suffix-text ${validator.isRequireCity ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("City")} />
                                            </span>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col s12 m12">
                                            <div className={`input-field required suffixinput ${validator.isRequireState ? "required-field" : ""}`}>
                                                <Select
                                                    dataSource={listState}
                                                    value={branches.State}
                                                    onChange={(value) => dispatch(setBranchState({ ...branches, State: value, ZipCode: "" }))}
                                                    mapDataToRenderOptions={{ value: "Code", label: "Code" }}
                                                    ref="state"
                                                    id="state"
                                                    optionDefaultLabel="Select Your State"
                                                />
                                                <label htmlFor="state">State</label>
                                                <span className={`suffix-text ${validator.isRequireState ? "" : "hide"}`}>
                                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("State")} />
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* user basic information col group */}
                                <div className="col s12 m6">
                                    <div className="row">
                                        <div className={`input-field col s6 required suffixinput ${validator.isRequireContactFirst ? "required-field" : ""}`}>
                                            <input type="text" maxLength="50" value={branches.ContactFirst || ""}
                                                onChange={() => dispatch(setBranchState({ ...branches, ContactFirst: this.refs.contactFirst.value }))}
                                                onBlur={() => this.handleValidateContactFirst()}
                                                id="contact-first" ref="contactFirst" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="contact-first">First Name</label>
                                            <span className={`suffix-text ${validator.isRequireContactFirst ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("First Name")} />
                                            </span>
                                        </div>
                                        <div className={`input-field col s6 required suffixinput ${validator.isRequireContactLast ? "required-field" : ""}`}>
                                            <input type="text" maxLength="50" value={branches.ContactLast || ""}
                                                onChange={() => dispatch(setBranchState({ ...branches, ContactLast: this.refs.contactLast.value }))}
                                                onBlur={() => this.handleValidateContactLast()}
                                                id="contact-last" ref="contactLast" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="contact-last">Last Name</label>
                                            <span className={`suffix-text ${validator.isRequireContactLast ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Last Name")} />
                                            </span>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className={`input-field col s8 required suffixinput ${validator.isRequirePhone ? "required-field" : ""} ${validator.isFormatPhone ? "has-error" : ""}`}>
                                            <InputMask
                                                type="text"
                                                onChange={() => dispatch(setBranchState({ ...branches, Phone: convertToPhoneNumber(this.refs.phone.value) }))}
                                                onBlur={() => this.handleValidatePhone()}
                                                id="phone" style={{ paddingRight: "15px" }}
                                                ref="phone"
                                                mask="(999) 999-9999"
                                                placeholder="(###) ###-####"
                                                value={branches.Phone || ""}
                                            />
                                            <label htmlFor="phone">Phone Number</label>
                                            <span className={`suffix-text ${validator.isRequirePhone ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Phone Number")} />
                                            </span>
                                            <span className={`suffix-text ${validator.isFormatPhone ? "" : "hide"}`}>
                                                <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Phone Number")} />
                                            </span>
                                        </div>
                                        <div className="input-field col s4">
                                            <input
                                                type="text" maxLength="10" id="contact-email-ext" ref="contactExt"
                                                value={branches.contactExt || ""}
                                                onChange={() => dispatch(setBranchState({ ...branches, contactExt: this.refs.contactExt.value }))}
                                            />
                                            <label htmlFor="contact-email-ext">Ext</label>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className={`input-field col s8 suffixinput ${validator.isFormatFax ? "has-error" : ""}`}>
                                            <InputMask
                                                onChange={() => dispatch(setBranchState({ ...branches, contactFax: convertToPhoneNumber(this.refs.contactFax.value) }))}
                                                onBlur={() => this.handleValidateFaxFormat()}
                                                type="text" style={{ paddingRight: "15px" }}
                                                mask="(999) 999-9999"
                                                placeholder="(###) ###-####"
                                                id="contactFax"
                                                ref="contactFax"
                                                value={branches.contactFax || ""}
                                            />
                                            <label htmlFor="contactFax">Fax</label>
                                            <span className={`suffix-text ${validator.isFormatFax ? "" : "hide"}`}>
                                                <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Fax")} />
                                            </span>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className={`input-field col s12 required suffixinput ${validator.isRequireContactEmail ? "required-field" : ""} ${validator.isFormatContactEmail ? "has-error" : ""}`}>
                                            <input type="text" maxLength="75" value={branches.ContactEmail || ""}
                                                onChange={() => dispatch(setBranchState({ ...branches, ContactEmail: this.refs.contactEmail.value }))}
                                                onBlur={() => this.handleValidateContactEmail()}
                                                id="contact-email" ref="contactEmail" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="contact-email">Email</label>
                                            <span className={`suffix-text ${validator.isRequireContactEmail ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Email")} />
                                            </span>
                                            <span className={`suffix-text ${validator.isFormatContactEmail ? "" : "hide"}`}>
                                                <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Email")} />
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* username row group */}
                            <div className="row">
                                <div className="col s12 m6">
                                    <div className="row">
                                        <div className={`input-field col s12 required suffixinput ${validator.isRequireUsername ? "required-field" : ""} ${validator.isExistUsername ? "has-error" : ""}`}>
                                            <input type="text" maxLength="100" disabled={isFetching} value={branches.Username || ""}
                                                onChange={() => this.handleChangeUsername()}
                                                onBlur={() => this.handleValidateUsername()}
                                                id="username" ref="username" style={{ paddingRight: "15px" }}
                                                maxLength="45"
                                            />
                                            <label htmlFor="username">Desired Unique User Name</label>
                                            <span className={`suffix-text ${validator.isRequireUsername ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Desired Unique User Name")} />
                                            </span>
                                            <span className={`suffix-text ${validator.isExistUsername ? "" : "hide"}`}>
                                                <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={existingUsernameMessage("Desired Unique User Name")} />
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* password row group */}
                            <div className="row">
                                <div className="col s12 m6">
                                    <div className="row">
                                        <div className={`input-field col s12 required suffixinput ${validator.isRequirePassword ? "required-field" : ""} ${validator.isFormatPassword ? "has-error" : ""}`}>
                                            <input type="password" maxLength="75" value={branches.Password || ""}
                                                onChange={() => dispatch(setBranchState({ ...branches, Password: this.refs.password.value }))}
                                                onBlur={() => this.handleValidatePassword()}
                                                id="password" ref="password" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="password">Password <span className="glyphicon glyphicon-info-sign"></span></label>
                                            <span className={`suffix-text ${validator.isRequirePassword ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Password")} />
                                            </span>
                                            <span className={`suffix-text ${validator.isFormatPassword ? "" : "hide"}`}>
                                                <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidPasswordMessage("Password")} />
                                            </span>
                                            <div>
                                                <PasswordPopover classNameAdded="mr-2" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col s12 m6">
                                    <div className="row">
                                        <div className={`input-field col s12 required suffixinput ${validator.isRequireVerifyPassword ? "required-field" : ""} ${validator.isFormatVerifyPassword ? "has-error" : ""}`}>
                                            <input type="password" maxLength="75" value={branches.VerifyPassword || ""}
                                                onChange={() => dispatch(setBranchState({ ...branches, VerifyPassword: this.refs.verifyPassword.value }))}
                                                onBlur={() => this.handleValidateVerifyPassword()}
                                                id="verify-password" ref="verifyPassword" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="verify-password">Verify Password</label>
                                            <span className={`suffix-text ${validator.isRequireVerifyPassword ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Verify Password")} />
                                            </span>
                                            <span className={`suffix-text ${validator.isFormatVerifyPassword ? "" : "hide"}`}>
                                                <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={comparePasswordMessage("Password", "Verify Password")} />
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col s12 m4 l4">
                                <button className="btn white w-100" id="btnCancelBranch" onClick={() => this.handleShowCancelConfirm()}>Cancel</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button className="btn success-color w-100" disabled={isFetching} onClick={() => this.handleSaveClick()}>Save</button>
                            </div>
                            <div className="col s12 m4 l4">
                                <button className="btn success-color w-100" id="btnSaveBranch" disabled={isFetching} onClick={() => this.handleSaveCloseClick()}>Save & Close</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>

                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div >
        );
    }
}

BranchAdd.propTypes = {
    dispatch: PropTypes.func.isRequired,
    isFetching: PropTypes.bool,
    listState: PropTypes.array,
    listReturnAddr: PropTypes.array,
    branches: PropTypes.object,
    validator: PropTypes.object,
    userId: PropTypes.number,
    adminInformation: PropTypes.object,
    brokerId: PropTypes.string,
    params: PropTypes.object,
    router: PropTypes.object,
    redirect: PropTypes.func,
    isOpen: PropTypes.bool,
    handleCancel: PropTypes.func
};

const mapStateToProps = (state) => {
    const { isFetching, listState, listReturnAddr, branches, validator, adminInformation } = state.branchManagement.branchAdd;
    const { userId } = state.authentication;

    return {
        isFetching,
        listState,
        listReturnAddr,
        branches,
        validator,
        userId,
        adminInformation
    };
};

export default connect(mapStateToProps)(BranchAdd);