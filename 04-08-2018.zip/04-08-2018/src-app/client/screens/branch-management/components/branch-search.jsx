import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";

import BranchMergeModal from "../components/branch-merge-modal";
import BranchAdd from "../components/branch-add";
import BranchUpdate from "../components/branch-update";

import { getBranchManagement, setBranchFilter } from "../actions/branch-search-actions";
import { checkBranchMergeCondition } from "../actions/branch-merge-actions";

import { API_URL } from "Config/config";
import MultiSelectWrapper from "../../../features/multi-select/multi-select-wrapper";
import { apiEnableBranch } from "Api/branch-api";
import { showSuccess } from "../../main-layout/actions";
import { SUCCESSFULLY_UPDATE_MESSAGE } from "../../../constant/constants";

import { updateTextFields } from "../../../helpers/theme-helper";

import GridView from "GridView";

import NumbericInput from "NumbericInput";
import CommonModal from "CommonModal";

class BranchSearch extends Component {
    constructor(props) {
        super(props);
        this.state = {
            addModalIsOpen: false,
            updateModalIsOpen: false,
            updateModalBrokerId: 0,
            branchNameSuggestion: []
        };
    }

    handleGridViewReload(criteria) {
        const { dispatch } = this.props;

        dispatch(setBranchFilter({
            ...this.props.filter,
            ...criteria
        }));

        dispatch(getBranchManagement());
    }

    handleBrokerIDChanged(value) {
        const { dispatch } = this.props;

        dispatch(setBranchFilter({ ...this.props.filter, brokerID: value }));
    }

    handleAddBranch() {
        this.setState({
            addModalIsOpen: true
        });
    }

    handleGridViewActionClick(action, identifier) {
        const { dispatch, userId } = this.props;

        switch (action) {
            case "edit":
                this.setState({
                    updateModalIsOpen: true,
                    updateModalBrokerId: identifier
                });
                break;
            case "disable":
                dispatch(checkBranchMergeCondition(identifier, userId));
                break;
            case "activate":
                this.commonModal.showModal({
                    type: "confirm",
                    message: `Are you sure you would like to activate this branch?`
                }, () => {
                    apiEnableBranch(identifier, (result) => {
                        if (result !== null) {
                            this.handleGridViewReload(this.props.filter);
                            dispatch(showSuccess(SUCCESSFULLY_UPDATE_MESSAGE));
                        }
                    });
                });
                break;
        }
    }

    handleSearchClick() {
        const { dispatch } = this.props;

        dispatch(setBranchFilter({
            ...this.props.filter,
            page: 1,
            contactLast: this.props.filter.contactLast.trim(),
            contactFirst: this.props.filter.contactFirst.trim()
        }));
        dispatch(getBranchManagement());
    }

    handleReset() {
        const { dispatch } = this.props;

        dispatch(setBranchFilter({
            ...this.props.filter,
            page: 1,
            brokerID: "",
            company: "",
            contactFirst: "",
            contactLast: "",
            disabled: true,
            inactive: false
        }));

        this.setState({ branchNameSuggestion: [] });
        dispatch(getBranchManagement());
    }

    componentDidUpdate() {
        updateTextFields();
    }

    componentDidMount() {
        const { dispatch, userId } = this.props;
        dispatch(setBranchFilter({
            ...this.props.filter,
            GID: userId
        }));
        dispatch(getBranchManagement());
    }

    componentWillUpdate() {
        const { dispatch, needReload } = this.props;
        if (needReload) {
            dispatch(getBranchManagement());
        }
    }

    renderBranchNameSuggestion(branch) {
        const options = branch.map(branches => {
            return { label: `${branches.Company}`, value: branches.BrokerID };
        });

        return options;
    }

    handleSelectedBranchesOptions(selectedOptions) {
        const { filter, dispatch } = this.props;

        const newState = {
            branchNameSuggestion: selectedOptions
        };

        if (selectedOptions.length === 1) {
            newState.branches = [];
        }

        let branchSearch = "";

        const tempBranch = selectedOptions.map(item => `'${item.label}'`).join(",");
        branchSearch = tempBranch.replace(/'/g, "\\\'");

        dispatch(setBranchFilter({ ...filter, company: branchSearch }));
        this.setState(newState);
    }

    handleCancelAdd() {
        this.setState({
            addModalIsOpen: false
        });
    }

    handleCancelUpdate() {
        this.setState({
            updateModalIsOpen: false,
            updateModalBrokerId: 0
        });
    }

    render() {
        const { listBranches, filter, columns, dispatch, userId } = this.props;

        const { branchNameSuggestion } = this.state;

        return (
            <div className="place-section">
                <div className="row">
                    <div className="col m12">
                        <h3 className="title-page-detail">
                            Branch Management
                        </h3>
                    </div>
                </div>


                <div className="wrap-search-form">
                    <div className="row">
                        <div className="input-field col s12 m6">
                            <NumbericInput id="broker-id" value={filter.brokerID} ref="brokerID" className="form-control" maxLength="9" onChange={this.handleBrokerIDChanged.bind(this)} />
                            <label className="control-label" htmlFor="broker-id">Branch/Division ID</label>
                        </div>
                        <div className="col s12 m6">
                            <MultiSelectWrapper
                                label="Branch/Division Name"
                                minTextLength={3}
                                values={branchNameSuggestion}
                                numberOptionsDisplay={150}
                                onValuesChange={selectedOptions => this.handleSelectedBranchesOptions(selectedOptions)}
                                sourceApiUrl={`${API_URL}/branch/getBranchNameByKeyword?GID=${userId}`}
                                formatOptions={(options) => this.renderBranchNameSuggestion(options)}
                            />
                        </div>
                    </div>
                    <div className="row">
                        <div className="input-field col s12 m6">
                            <input id="contact-first-name" value={filter.contactFirst} maxLength="50" ref="contactFirst" type="text" className="form-control" onChange={() => dispatch(setBranchFilter({ ...filter, contactFirst: this.refs.contactFirst.value }))} />
                            <label className="control-label" htmlFor="contact-first-name">Contact First Name</label>
                        </div>
                        <div className="input-field col s12 m6">
                            <input id="contact-last-name" value={filter.contactLast} maxLength="50" ref="contactLast" type="text" className="form-control" onChange={() => dispatch(setBranchFilter({ ...filter, contactLast: this.refs.contactLast.value }))} />
                            <label className="control-label" htmlFor="contact-last-name">Contact Last Name</label>
                        </div>
                    </div>

                    <div className="row mb-0">
                        <div className="col s12 m6">
                            <p className="left red-color">Insert criteria to search for specific branch/division</p>
                        </div>
                        <div className="col s12 m6">
                            <div className="right center-btn-mobile">
                                <button type="button" className="btn btn-small reload-btn btn-primary" style={{ marginRight: "5px" }} onClick={() => this.handleReset()}>
                                    <i className="lnr lnr-redo"></i>
                                </button>
                                <button onClick={(e) => this.handleSearchClick(e)} className="btn success-color action-btn">Search</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="row mb-0">
                    <div className="col s12 m6">
                        <p className="left" style={{ margin: "2.111111rem 0px" }}><strong>Search Results</strong></p>
                    </div>
                    <div className="col s12 m6">
                        <div className="right center-btn-mobile" style={{ margin: "1.5rem 0px" }}>
                            <button type="button" className="btn action-btn success-color" onClick={() => this.handleAddBranch()}>Add Branch/Division</button>
                        </div>
                    </div>
                </div>

                <div className="wrap-result-search">
                    <GridView
                        criteria={filter}
                        totalRecords={listBranches ? listBranches.totalRecords : []}
                        datasources={listBranches ? listBranches.branches : []} //Pass datasources
                        columns={columns} //Pass columns array
                        identifier={"BrokerID"} //Identifier for grid row
                        onGridViewReload={(e) => this.handleGridViewReload(e)} //Paginate changed => need reload datasource base on criteria
                        onActionClick={this.handleGridViewActionClick.bind(this)}
                    />
                </div>
                <BranchMergeModal />
                <BranchAdd handleCancel={() => this.handleCancelAdd()} isOpen={this.state.addModalIsOpen} />
                <BranchUpdate updateId={this.state.updateModalBrokerId} handleCancel={() => this.handleCancelUpdate()} isOpen={this.state.updateModalIsOpen} />
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div >
        );
    }
}

BranchSearch.defaultProps = {
    columns: [
        {
            title: "Branch/Division ID",
            data: "BrokerID"
        },
        {
            title: "Branch/Division Name",
            data: "Company"
        },
        {
            title: "Phone #",
            data: "Phone"
        },
        {
            title: "Contact Name",
            data: "ContactName"
        },
        {
            title: "Contact Email",
            data: "Email"
        },
        {
            title: "User Name",
            data: "UserName"
        },
        {
            title: "Status",
            data: "Inactive"
        },
        {
            title: "Action",
            type: "branch-action"
        }
    ]
};

BranchSearch.propTypes = {
    dispatch: PropTypes.func.isRequired,
    listBranches: PropTypes.object,
    filter: PropTypes.object,
    columns: PropTypes.array,
    userId: PropTypes.number,
    needReload: PropTypes.bool,
    router: PropTypes.object,
    push: PropTypes.func
};

const mapStateToProps = (state) => {
    const { listBranches, filter } = state.branchManagement.branchSearch;
    const { needReload } = state.branchManagement.branchUpdate;
    const { userId } = state.authentication;
    return {
        listBranches,
        filter,
        userId,
        needReload
    };
};

export default connect(mapStateToProps)(BranchSearch);