import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";

import Select from "Select";
import { closeModal, mergeBranch, disableBranch } from "../actions/branch-merge-actions";

export class BranchMergeModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            brokerId: -1
        };
    }

    handleChange(value) {
        this.setState({
            brokerId: value
        });
    }

    handleCloseModal() {
        const { dispatch } = this.props;

        dispatch(closeModal());
    }

    handleMerge() {
        const { dispatch, branchId, listMerge } = this.props;

        let brokerId;
        if (this.state.brokerId === -1) {
            brokerId = listMerge[0].BrokerID;
        } else {
            brokerId = this.state.brokerId;
        }

        dispatch(mergeBranch(branchId, brokerId));
        dispatch(closeModal());
    }

    handleDisable() {
        const { dispatch, branchId } = this.props;

        dispatch(disableBranch(branchId));
        dispatch(closeModal());
    }

    render() {
        const { isShowModal, agentEmpty, orderEmpty, listMerge } = this.props;

        if (agentEmpty && orderEmpty) {
            return (
                <Modal size={""} isOpen={isShowModal} fixedFooter={false} style={{ width: "45%" }} addClass={`common-popup confirm-com`}>
                    <ModalTitle onClickClose={() => this.handleNoAction()} className="text-primary"><span className="fa fa-question-circle"></span><span>Confirmation Message</span></ModalTitle>
                    <ModalBody>
                        <div className="row mb-0">
                            <div className="col s12">
                                <p className="m-0">Are you sure you would like to deactivate this branch?</p>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row">
                            <div className="col s6">
                                <button className="btn white w-100" onClick={() => this.handleCloseModal()}>No</button>
                            </div>
                            <div className={"col s6"}>
                                <button className="btn success-color w-100" style={{ marginRight: 5 }} onClick={() => this.handleDisable()}>Yes</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal >
            );
        } else if (listMerge.length === 0) {
            return (
                <Modal size={""} isOpen={isShowModal} fixedFooter={false} style={{ width: "45%" }} addClass={`common-popup confirm-com`}>
                    <ModalTitle onClickClose={() => { this.handleCloseModal(); }}>Merge Branch/Division</ModalTitle>
                    <ModalBody>
                        <div className="row mb-0">
                            <div className="col s12">
                                {(!agentEmpty && orderEmpty) ? <p className="m-0">This branch has (an) active agent(s) while there is no other active branch for you to merge.</p> : null}
                                {(agentEmpty && !orderEmpty) ? <p className="m-0">This branch has (a) open order(s) while there is no other active branch for you to merge. Please complete the open order(s) before disabling this branch.</p> : null}
                                {(!agentEmpty && !orderEmpty) ? <p className="m-0">This branch has (an) active agent(s) and open order(s) while there is no other active branch for you to merge. Please complete the open order(s) before disabling this branch.</p> : null}
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col s12 m12 center">
                                <button className="btn success-color w-100 center-align" onClick={() => this.handleCloseModal()}>Okay</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
            );
        } else {
            return (
                <div>
                    <Modal size={""} isOpen={isShowModal} fixedFooter={false} addClass={`common-popup confirm-com`}>
                        <ModalTitle>Merge Branch/Division</ModalTitle>
                        <ModalBody>
                            <div className="row">
                                <div className="col s12 m12">
                                    <p style={{ fontSize: "14px" }}>In order to disable this branch/division, you must merge the users/orders to an active branch/division.</p>
                                </div>
                                <div className="col s12 m6">
                                    <p htmlFor="branch" style={{ fontSize: "14px" }} >Branch/Division Name</p>
                                </div>
                                <div className="col s12 m6">
                                    <Select
                                        dataSource={listMerge}
                                        mapDataToRenderOptions={{ value: "BrokerID", label: "Company" }}
                                        onChange={(value) => this.handleChange(value)}
                                        id="branch"
                                        ref="branch"
                                    />
                                </div>
                            </div>
                        </ModalBody>
                        <ModalFooter>
                            <div className="row m-0">
                                <div className="col s6 m6">
                                    <button className="btn white w-100" onClick={() => this.handleCloseModal()}>Cancel</button>
                                </div>
                                <div className="col s6 m6">
                                    <button className="btn success-color w-100" onClick={() => this.handleMerge()}>Submit</button>
                                </div>
                            </div>
                        </ModalFooter>
                    </Modal>
                </div >
            );
        }
    }
}

BranchMergeModal.propTypes = {
    dispatch: PropTypes.func,
    isShowModal: PropTypes.bool,
    branchId: PropTypes.number,
    agentEmpty: PropTypes.bool,
    orderEmpty: PropTypes.bool,
    listMerge: PropTypes.array,
    userId: PropTypes.number
};

const mapStateToProps = (state) => {
    const { isShowModal, branchId, agentEmpty, orderEmpty, listMerge } = state.branchManagement.branchMerge;
    const { userId } = state.authentication;

    return {
        isShowModal,
        branchId,
        agentEmpty,
        orderEmpty,
        listMerge,
        userId
    };
};

export default connect(mapStateToProps)(BranchMergeModal);