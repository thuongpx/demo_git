import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import InputMask from "react-input-mask";
import { validateRequired, validatePhone, validateZip, validateEmail, requireMessage, invalidMessage } from "Helpers/validation-helper";
import { showSuccess } from "../../main-layout/actions";
import { SUCCESSFULLY_SAVED_MESSAGE, INVALID_CC_EMAIL_CHECK_MESSAGE, SUCCESSFULLY_DELETED_MESSAGE, SUCCESSFULLY_CREATED_MESSAGE, SUCCESSFULLY_UPDATE_MESSAGE } from "Constants";
import CommonModal from "CommonModal";
import Select from "Select";
import { getStateCodeAndCityFromZip } from "Helpers/location-helper";
import { setBranchValidator } from "../actions/branch-add-actions";
import {
    getBranchInformation, setBranchInformation, updateBranch,
    addReturnAddress, deleteReturnAddress, updateReturnAddress,
    addCcEmail, deleteCcEmail, updateCcEmail
} from "../actions/branch-update-actions";
import { updateTextFields } from "../../../helpers/theme-helper";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import { INPUT_ERROR_1X_IMAGE_URL } from "ImageConfig";
import { convertToPhoneNumber } from "Helpers/common-helper";
import { showError } from "../../main-layout/actions";

import {
    Modal,
    ModalTitle,
    ModalBody,
    ModalFooter
} from "Modal";
import { shallowCompareState, shallowCompareProps } from "../../../helpers/common-helper";
import { hasStringValue } from "../../../helpers/validation-helper";

export class BranchUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            isFetchingSave: false,
            isFetchingAddr: false,
            raId: "",
            branchReturnAddr: []
        };
    }

    handleInputChanged(key, value) {
        const { dispatch } = this.props;

        if (key === "City" || key === "State") {
            dispatch(setBranchInformation({ ...this.props.branchInformation, [key]: value, Zip: "" }));
        } else if (key === "ReturnAddrCity" || key === "ReturnAddrState") {
            dispatch(setBranchInformation({ ...this.props.branchInformation, [key]: value, ReturnAddrZip: "" }));
        } else {
            dispatch(setBranchInformation({ ...this.props.branchInformation, [key]: value }));
        }
    }

    componentDidMount() {
        const { dispatch, updateId, userId } = this.props;
        if (updateId !== 0) {
            dispatch(getBranchInformation(updateId, userId, true));
        }
    }

    componentWillReceiveProps(nextProps) {
        const { dispatch, updateId, userId } = this.props;
        if (nextProps.updateId !== updateId) {
            if (nextProps.updateId !== 0) {
                dispatch(getBranchInformation(nextProps.updateId, userId, true));
            }
        }

        const branchReturnAddr = nextProps.branchReturnAddr.map((item) => {
            if (this.state.raId !== "") {
                if (item.RaId === this.state.raId) {
                    item.DefaultAddr = "Y";
                } else {
                    item.DefaultAddr = "N";
                }
            }
            return item;
        });

        this.setState({
            branchReturnAddr
        });
    }

    componentDidUpdate() {
        updateTextFields();
    }

    componentWillUpdate() {
        const { dispatch, needReload, updateId, userId } = this.props;
        if (needReload && updateId !== 0) {
            dispatch(getBranchInformation(updateId, userId, false));
        }
    }

    handleValidateCompany() {
        const { dispatch } = this.props;
        const isRequireCompany = !validateRequired(this.refs.company.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireCompany }));
        return isRequireCompany;
    }

    handleValidatePhone() {
        const { dispatch } = this.props;
        const isFormatPhone = this.handleValidatePhoneFormat();
        const isRequirePhone = this.handleValidatePhoneRequire();
        dispatch(setBranchValidator({ ...this.props.validator, isFormatPhone, isRequirePhone }));
    }


    handleValidatePhoneFormat() {
        const { dispatch } = this.props;
        const isFormatPhone = !validatePhone(this.refs.phone.value);
        dispatch(setBranchValidator({ ...this.props.validator, isFormatPhone }));
        return isFormatPhone;
    }

    handleValidatePhoneRequire() {
        const { dispatch } = this.props;
        const isRequirePhone = !validateRequired(this.refs.phone.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequirePhone }));
        return isRequirePhone;
    }

    handleValidateFaxFormat() {
        const { dispatch } = this.props;
        const isFormatFax = !validatePhone(this.refs.contactFax.value);
        dispatch(setBranchValidator({ ...this.props.validator, isFormatFax }));
        return isFormatFax;
    }

    handleValidateAddress() {
        const { dispatch } = this.props;
        const isRequireAddress = !validateRequired(this.refs.address.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireAddress }));
        return isRequireAddress;
    }

    handleValidateCity() {
        const { dispatch } = this.props;
        const isRequireCity = !validateRequired(this.refs.city.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireCity }));
        return isRequireCity;
    }

    handleValidateState() {
        const { dispatch, branchInformation } = this.props;
        const isRequireState = !validateRequired(branchInformation.State);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireState }));
        return isRequireState;
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    handleValidateZipCode() {
        const { dispatch, branchInformation } = this.props;
        const isRequireZipCode = this.handleValidateZipCodeRequired();
        const isFormatZipCode = this.handleValidateZipCodeFormat();
        dispatch(setBranchValidator({ ...this.props.validator, isRequireZipCode, isFormatZipCode }));

        if (!isFormatZipCode) {

            getStateCodeAndCityFromZip(this.refs.zipCode.value, (zipString) => {
                if (zipString !== "Invalid Zip Code" && zipString.country === "United States") {
                    this.setState({ isFetchingSave: false });
                    if (branchInformation.State !== "" && branchInformation.State !== undefined && branchInformation.City.trim() !== "" && branchInformation.City !== undefined) {
                        const zipNotMatchMess = `The City ${branchInformation.State !== zipString.state && branchInformation.City !== zipString.city ? "and" : "or"} State do not match the Zip entered. Do you mean the signing address as follows? [${zipString.city}, ${zipString.state}, ${this.refs.zipCode.value}]. Click Yes to use that suggested address. Click No to re-enter the correct address.`;
                        if (branchInformation.State === "" && branchInformation.City === zipString.city) {
                            dispatch(setBranchInformation({ ...this.props.branchInformation, State: zipString.state }));
                            branchInformation.State = zipString.state;
                        } else if (branchInformation.City === "" && branchInformation.State === zipString.state) {
                            dispatch(setBranchInformation({ ...this.props.branchInformation, City: zipString.city }));
                        } else if (branchInformation.City === zipString.city && branchInformation.State === zipString.state) {
                            //
                        } else {
                            this.commonModal.showModal({ type: "warning", message: zipNotMatchMess }, () => {
                                dispatch(setBranchInformation({ ...this.props.branchInformation, State: zipString.state, City: zipString.city }));
                                dispatch(setBranchValidator({ ...this.props.validator, isRequireCity: false, isRequireState: false }));
                            }, () => {
                                // handle callback no click here
                                dispatch(setBranchInformation({ ...this.props.branchInformation, State: "", City: "", Zip: "" }));
                                setTimeout(() => {
                                    this.refs.zipCode.input.focus();
                                }, 200);
                            }, false);
                        }
                        this.handleValidateCity();
                        this.handleValidateState();
                    } else {
                        this.refs.zipCode.input.focus();
                        dispatch(setBranchInformation({ ...this.props.branchInformation, State: zipString.state, City: zipString.city }));
                    }
                    this.handleValidateCity();
                    this.handleValidateState();
                } else {
                    dispatch(showError("Your inputted Zip is not a valid US Zip Code. Please try again.", () => {
                        this.setState({ isFetchingSave: false });
                        dispatch(setBranchValidator({ ...this.props.validator, isFormatZipCode: true }));
                        dispatch(setBranchInformation({ ...this.props.branchInformation, Zip: "" }));
                        this.refs.zipCode.input.focus();
                    }));
                }
            });
        }
    }

    handleValidateZipCodeRequired() {
        const { dispatch } = this.props;
        const isRequireZipCode = !validateRequired(this.refs.zipCode.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireZipCode }));
        return isRequireZipCode;
    }

    handleValidateZipCodeFormat() {
        const { dispatch } = this.props;
        const isFormatZipCode = !validateZip(this.refs.zipCode.value);
        dispatch(setBranchValidator({ ...this.props.validator, isFormatZipCode }));
        return isFormatZipCode;
    }

    handleValidateReturnAddrZipCodeFormat() {
        const { dispatch } = this.props;
        const isFormatReturnAddrZip = !validateZip(this.refs.returnAddrZip.value);
        dispatch(setBranchValidator({ ...this.props.validator, isFormatReturnAddrZip }));
        return isFormatReturnAddrZip;
    }

    handleValidateContactFirst() {
        const { dispatch } = this.props;
        const isRequireContactFirst = !validateRequired(this.refs.contactFirst.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireContactFirst }));
        return isRequireContactFirst;
    }

    handleValidateContactLast() {
        const { dispatch } = this.props;
        const isRequireContactLast = !validateRequired(this.refs.contactLast.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireContactLast }));
        return isRequireContactLast;
    }

    handleValidateContactEmail() {
        const { dispatch } = this.props;
        const isRequireContactEmail = this.handleValidateContactEmailRequire();
        const isFormatContactEmail = this.handleValidateContactEmailFormat();
        dispatch(setBranchValidator({ ...this.props.validator, isFormatContactEmail, isRequireContactEmail }));
    }

    handleValidateContactEmailRequire() {
        const { dispatch } = this.props;
        const isRequireContactEmail = !validateRequired(this.refs.contactEmail.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireContactEmail }));
        return isRequireContactEmail;
    }

    handleValidateContactEmailFormat() {
        const { dispatch } = this.props;
        const isFormatContactEmail = !validateEmail(this.refs.contactEmail.value);
        dispatch(setBranchValidator({ ...this.props.validator, isFormatContactEmail }));
        return isFormatContactEmail;
    }

    handleValidateReturnAddr() {
        const { dispatch } = this.props;
        const isRequireReturnAddr = !validateRequired(this.refs.returnAddr.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireReturnAddr }));
        return isRequireReturnAddr;
    }

    handleValidateReturnAddrSuite() {
        const { dispatch } = this.props;
        const isRequireReturnAddrSuite = !validateRequired(this.refs.returnAddrSuite.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireReturnAddrSuite }));
        return isRequireReturnAddrSuite;
    }

    handleValidateReturnAddrCity() {
        const { dispatch } = this.props;
        const isRequireReturnAddrCity = !validateRequired(this.props.branchInformation.ReturnAddrCity);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireReturnAddrCity }));
        return isRequireReturnAddrCity;
    }

    handleValidateReturnAddrState() {
        const { dispatch, branchInformation } = this.props;
        const isRequireReturnAddrState = !validateRequired(branchInformation.ReturnAddrState);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireReturnAddrState }));
        return isRequireReturnAddrState;
    }

    handleValidateReturnAddrZip(isSubmit) {
        const { dispatch, branchInformation } = this.props;

        if (this.handleValidateReturnAddrZipFormat()) {
            dispatch(setBranchValidator({ ...this.props.validator, isRequireReturnAddrZip: true, isFormatReturnAddrZip: false }));
            this.refs.returnAddrZip.input.value = "";
            dispatch(setBranchInformation({ ...this.props.branchInformation, ReturnAddrZip: "" }));
            return false;
        }

        if (this.props.branchInformation.ReturnAddrZip === "") {
            return true;
        } else {
            // generate state, city from zip code
            this.setState({ isFetchingAddr: true });
            return getStateCodeAndCityFromZip(this.refs.returnAddrZip.value, (zipString) => {
                this.setState({ isFetchingAddr: false });
                if (zipString !== "Invalid Zip Code" && zipString.country === "United States") {
                    if (hasStringValue(branchInformation.ReturnAddrState) || hasStringValue(branchInformation.ReturnAddrCity)) {
                        const zipNotMatchMess = `The City ${branchInformation.ReturnAddrState !== zipString.state && branchInformation.ReturnAddrCity !== zipString.city ? "and" : "or"} State do not match the Zip entered. Do you mean the signing address as follows? [${zipString.city}, ${zipString.state}, ${this.refs.returnAddrZip.value}]. Click Yes to use that suggested address. Click No to re-enter the correct address.`;
                        if (!hasStringValue(branchInformation.ReturnAddrState) && branchInformation.ReturnAddrCity === zipString.city) {
                            dispatch(setBranchInformation({ ...this.props.branchInformation, ReturnAddrState: zipString.state }));
                        } else if (!hasStringValue(branchInformation.ReturnAddrCity) && branchInformation.ReturnAddrState === zipString.state) {
                            dispatch(setBranchInformation({ ...this.props.branchInformation, ReturnAddrCity: zipString.city }));
                        } else if (branchInformation.ReturnAddrCity === zipString.city && branchInformation.ReturnAddrState === zipString.state) {
                            dispatch(setBranchValidator({ ...this.props.validator, isRequireReturnAddrZip: false, isRequireReturnAddrCity: false, isRequireReturnAddrState: false, isFormatReturnAddrZip: false }));
                        } else if (!isSubmit) {
                            this.commonModal.showModal({ type: "warning", message: zipNotMatchMess }, () => {
                                dispatch(setBranchInformation({ ...this.props.branchInformation, ReturnAddrCity: zipString.city, ReturnAddrState: zipString.state }));
                                dispatch(setBranchValidator({ ...this.props.validator, isRequireReturnAddrZip: false, isRequireReturnAddrCity: false, isRequireReturnAddrState: false, isFormatReturnAddrZip: false }));
                            }, () => {
                                // handle callback no click here
                                setTimeout(() => {
                                    this.refs.returnAddrZip.input.focus();
                                }, 200);
                                dispatch(setBranchInformation({ ...this.props.branchInformation, ReturnAddrZip: "", ReturnAddrCity: "", ReturnAddrState: "" }));
                            }, true);
                        }
                    } else {
                        dispatch(setBranchInformation({ ...this.props.branchInformation, ReturnAddrCity: zipString.city, ReturnAddrState: zipString.state }));
                        dispatch(setBranchValidator({ ...this.props.validator, isRequireReturnAddrZip: false, isRequireReturnAddrCity: false, isRequireReturnAddrState: false, isFormatReturnAddrZip: false }));
                    }

                    return false;
                } else {
                    const isFormatReturnAddrZip = true;
                    dispatch(showError("Your inputted Zip is not a valid US Zip Code. Please try again.", () => {
                        this.refs.returnAddrZip.input.focus();
                        dispatch(setBranchValidator({ ...this.props.validator, isFormatReturnAddrZip }));
                        dispatch(setBranchInformation({ ...this.props.branchInformation, ReturnAddrZip: "" }));
                    }));
                    return isFormatReturnAddrZip;
                }
            });
        }
    }

    handleValidateReturnAddrZipFormat() {
        const isFormatReturnAddrZip = !validateZip(this.props.branchInformation.ReturnAddrZip);
        return isFormatReturnAddrZip;
    }

    handleValidateCcEmail() {
        const { dispatch } = this.props;
        const isRequireCcEmail = this.handleValidateCcEmailRequire();
        const isFormatCcEmail = this.handleValidateCcEmailFormat();
        dispatch(setBranchValidator({ ...this.props.validator, isFormatCcEmail, isRequireCcEmail }));
    }

    handleValidateRecName() {
        const { dispatch } = this.props;
        const isRequireRecName = this.handleValidateRecNameRequire();
        dispatch(setBranchValidator({ ...this.props.validator, isRequireRecName }));
    }

    handleValidateRecNameRequire() {
        const { dispatch } = this.props;
        const isRequireRecName = !validateRequired(this.refs.recipientName.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireRecName }));
        return isRequireRecName;
    }

    handleValidateCcEmailRequire() {
        const { dispatch } = this.props;
        const isRequireCcEmail = !validateRequired(this.refs.recipientEmail.value);
        dispatch(setBranchValidator({ ...this.props.validator, isRequireCcEmail }));
        return isRequireCcEmail;
    }

    handleValidateCcEmailFormat() {
        const { dispatch } = this.props;
        const isFormatCcEmail = !validateEmail(this.refs.recipientEmail.value);
        dispatch(setBranchValidator({ ...this.props.validator, isFormatCcEmail }));
        return isFormatCcEmail;
    }

    isValidated(validator) {
        for (const key in validator) {
            if (validator[key]) {
                return false;
            }
        }
        return true;
    }

    validateForm() {
        const { dispatch } = this.props;
        const isRequireCompany = this.handleValidateCompany();
        const isRequirePhone = this.handleValidatePhoneRequire();
        const isFormatPhone = this.handleValidatePhoneFormat();
        const isFormatFax = this.handleValidateFaxFormat();
        const isRequireAddress = this.handleValidateAddress();
        const isRequireCity = this.handleValidateCity();
        const isRequireState = this.handleValidateState();
        const isRequireZipCode = this.handleValidateZipCodeRequired();
        const isFormatZipCode = this.handleValidateZipCodeFormat();
        const isRequireContactFirst = this.handleValidateContactFirst();
        const isRequireContactLast = this.handleValidateContactLast();
        const isRequireContactEmail = this.handleValidateContactEmailRequire();
        const isFormatContactEmail = this.handleValidateContactEmailFormat();

        const validator = {
            isRequireCompany,
            isRequirePhone,
            isFormatPhone,
            isRequireAddress,
            isRequireCity,
            isRequireState,
            isRequireZipCode,
            isFormatZipCode,
            isRequireContactFirst,
            isRequireContactLast,
            isRequireContactEmail,
            isFormatContactEmail,
            isFormatFax
        };

        dispatch(setBranchValidator(validator));
        return this.isValidated(validator);
    }

    validateReturnAddress() {
        const { dispatch } = this.props;
        const isRequireReturnAddr = this.handleValidateReturnAddr();
        const isRequireReturnAddrState = this.handleValidateReturnAddrState();
        const isRequireReturnAddrCity = this.handleValidateReturnAddrCity();
        const isRequireReturnAddrZip = this.handleValidateReturnAddrZip(true);
        const isFormatReturnAddrZip = this.handleValidateReturnAddrZipCodeFormat();

        const validator = {
            isRequireReturnAddr,
            isRequireReturnAddrState,
            isRequireReturnAddrCity,
            isRequireReturnAddrZip,
            isFormatReturnAddrZip
        };

        dispatch(setBranchValidator(validator));
        return this.isValidated(validator);
    }

    validateCcEmail() {
        const { dispatch } = this.props;
        const isRequireCcEmail = this.handleValidateCcEmailRequire();
        const isFormatCcEmail = this.handleValidateCcEmailFormat();
        const isRequireRecName = this.handleValidateRecNameRequire();

        const validator = {
            isRequireCcEmail,
            isFormatCcEmail,
            isRequireRecName
        };

        dispatch(setBranchValidator(validator));
        return this.isValidated(validator);
    }

    saveChanges() {
        const { branchInformation } = this.props;
        const newBranch = {
            BrokerId: this.props.updateId,
            Company: branchInformation.Company,
            Phone: convertToPhoneNumber(branchInformation.Phone),
            Address: branchInformation.Address,
            Suite: branchInformation.Suite,
            City: branchInformation.City,
            State: branchInformation.State,
            Zip: branchInformation.Zip,
            AdministratorFirst: branchInformation.AdministratorFirst,
            AdministratorLast: branchInformation.AdministratorLast,
            AdministratorExt: branchInformation.AdministratorExt,
            AdministratorEmail: branchInformation.AdministratorEmail,
            PrimaryContactFirst: branchInformation.PrimaryContactFirst,
            PrimaryContactLast: branchInformation.PrimaryContactLast,
            Email: branchInformation.Email,
            PrimaryContactExt: branchInformation.PrimaryContactExt,
            PrimaryContactFax: convertToPhoneNumber(branchInformation.PrimaryContactFax)
        };


        const { dispatch } = this.props;
        dispatch(updateBranch(newBranch));
        dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
        this.handleUpdateReturnAddr(this.state.raId);
        this.props.handleCancel();
        this.handleResetFieldReturnAddress();
        this.handleResetCcEmail();
    }

    saveChangesReturnAddress() {
        const { branchInformation } = this.props;
        const returnAddr = {
            BrokerId: this.props.updateId,
            Address: branchInformation.ReturnAddr,
            Suite: branchInformation.ReturnAddrSuite,
            City: branchInformation.ReturnAddrCity,
            State: branchInformation.ReturnAddrState,
            Zip: branchInformation.ReturnAddrZip,
            DefaultAddr: "N"
        };

        const { dispatch } = this.props;
        dispatch(addReturnAddress(returnAddr));
    }

    saveChangesCcEmail() {
        const ccEmail = {
            BrokerId: this.props.updateId,
            EName: this.refs.recipientName.value,
            Email: this.refs.recipientEmail.value,
            EmailFor: "B"
        };

        const { dispatch } = this.props;
        dispatch(addCcEmail(ccEmail));
    }

    handleSaveClick() {
        if (this.validateForm()) {

            this.saveChanges();
        }
    }

    handleAddReturnAddressClick() {
        const { dispatch } = this.props;

        if (this.validateReturnAddress()) {
            this.saveChangesReturnAddress();

            this.handleResetFieldReturnAddress();
            dispatch(showSuccess(SUCCESSFULLY_CREATED_MESSAGE));
        }
    }

    handleResetFieldReturnAddress() {
        const { dispatch } = this.props;

        dispatch(setBranchInformation({ ...this.props.branchInformation, ReturnAddrDepartment: "", ReturnAddr: "", ReturnAddrSuite: "", ReturnAddrCity: "", ReturnAddrState: "", ReturnAddrZip: "" }));
    }

    handleDeleteReturnAddressClick(raId) {
        this.commonModal.showModal({
            type: "confirm",
            message: "Are you sure you would like to delete this address?"
        }, () => {
            const { dispatch } = this.props;
            dispatch(deleteReturnAddress(raId));
            dispatch(showSuccess(SUCCESSFULLY_DELETED_MESSAGE));
        });
    }

    handleAddCcEmailClick() {
        const { dispatch } = this.props;
        if (this.validateCcEmail()) {
            this.saveChangesCcEmail();
            this.handleResetCcEmail();
            dispatch(showSuccess(SUCCESSFULLY_CREATED_MESSAGE));
        }
    }

    handleResetCcEmail() {
        this.refs.recipientEmail.value = "";
        this.refs.recipientName.value = "";
    }

    handleDeleteCcEmailClick(BrokerEmailId) {
        this.commonModal.showModal({
            type: "confirm",
            message: "Are you sure you would like to delete this email?"
        }, () => {
            const { dispatch } = this.props;
            dispatch(deleteCcEmail(BrokerEmailId));
            dispatch(showSuccess(SUCCESSFULLY_DELETED_MESSAGE));
        });
    }

    handleUpdateReturnAddr(raId) {
        const { dispatch, updateId } = this.props;
        const criteria = {
            raId,
            brokerId: updateId
        };
        dispatch(updateReturnAddress(criteria));
        dispatch(showSuccess(SUCCESSFULLY_UPDATE_MESSAGE));
    }

    handleUpdateCcEmailInvoiceClick(invoice, emailFor, id) {
        if (invoice === true) {
            switch (emailFor) {
                case "B":
                    this.updateEmail(id, "S");
                    break;
                case "I":
                    this.commonModal.showModal({ message: INVALID_CC_EMAIL_CHECK_MESSAGE });
                    break;
                case "S":
                    this.updateEmail(id, "B");
                    break;
            }
        } else if (invoice === false) {
            switch (emailFor) {
                case "B":
                    this.updateEmail(id, "I");
                    break;
                case "I":
                    this.updateEmail(id, "B");
                    break;
                case "S":
                    this.commonModal.showModal({ message: INVALID_CC_EMAIL_CHECK_MESSAGE });
                    break;
            }
        }
    }

    updateEmail(id, emailFor) {
        const { dispatch } = this.props;
        const ccEmail = {
            BrokerEmailId: id,
            EmailFor: emailFor
        };

        dispatch(updateCcEmail(ccEmail));
        dispatch(showSuccess(SUCCESSFULLY_UPDATE_MESSAGE));
    }

    handleShowCancelConfirm() {
        this.commonModal.showModal({
            type: "confirm",
            message: "Are you sure you want to cancel updating this Branch/Division?"
        }, () => {
            const { dispatch } = this.props;
            dispatch(setBranchValidator({}));
            dispatch(setBranchInformation({}));
            this.props.handleCancel();
            this.handleResetFieldReturnAddress();
            this.handleResetCcEmail();
            // this.setState({
            //     raId: "",
            //     branchReturnAddr: []
            // });
        });
    }

    handleOpenModalEnd() {
        this.refs.company.focus();
    }

    handleClickRadio(raId, index) {
        const { branchReturnAddr } = this.state;

        branchReturnAddr.map((item, key) => {
            if (key === index) {
                item.DefaultAddr = "Y";
            } else {
                item.DefaultAddr = "N";
            }

            return item;
        });

        this.setState({
            raId,
            branchReturnAddr
        });
    }

    render() {
        const { branchInformation, branchCcEmail, stateDropDown, validator, isFetching, isOpen } = this.props;
        const { branchReturnAddr } = this.state;

        const returnAddressList = branchReturnAddr.map((item, index) => {
            const isDefault = item.DefaultAddr === "Y" ? true : false;
            return (
                <tr key={index}>
                    <td className="center-align">{index + 1}</td>
                    <td className="center-align">
                        <input className="with-gap" type="radio" id="rad" name="rad" checked={isDefault} disabled={isFetching} /><span htmlFor="rad" onClick={() => this.handleClickRadio(item.RaId, index)}></span>
                    </td>
                    <td>{item.Department}{item.Department === "" || item.Department === null || item.Department === undefined ? null : <span>,</span>}  {item.Address} {item.Suite}, {item.City}, {item.State} {item.Zip}</td>
                    <td className="center-align">
                        {isDefault ? <button className="btn btn-s-small error-color mr-1 disabled"> <span className="lnr lnr-trash"></span></button> : <button className="btn btn-s-small error-color mr-1" onClick={() => this.handleDeleteReturnAddressClick(item.RaId)}> <span className="lnr lnr-trash"></span></button>}
                    </td>
                </tr>
            );
        });

        const ccEmailList = branchCcEmail.map((item, index) => {
            const emailInvoice = item.EmailFor === "I" ? true : false;
            const emailStatus = item.EmailFor === "S" ? true : false;
            const emailBoth = item.EmailFor === "B" ? true : false;
            return (
                <tr key={index}>
                    <td className="center-align">{index + 1}</td>
                    <td className="center-align">
                        <input type="checkbox" disabled={isFetching} checked={emailInvoice || emailBoth} /><span onClick={() => this.handleUpdateCcEmailInvoiceClick(true, item.EmailFor, item.BrokerEmailId)}></span>
                    </td>
                    <td className="center-align">
                        <input type="checkbox" disabled={isFetching} checked={emailStatus || emailBoth} /><span onClick={() => this.handleUpdateCcEmailInvoiceClick(false, item.EmailFor, item.BrokerEmailId)}></span>
                    </td>
                    <td>{item.EName}</td>
                    <td>{item.Email}</td>
                    <td className="center-align"><button className="btn btn-s-small error-color mr-1" onClick={() => this.handleDeleteCcEmailClick(item.BrokerEmailId)}> <span className="lnr lnr-trash"></span></button></td>
                </tr>
            );
        });

        const modalOptions = {
            onOpenEnd: () => this.handleOpenModalEnd()
        };

        return (
            <div>
                <Modal isOpen={isOpen} addClass="no-tab" modalOptions={modalOptions}>
                    <ModalBody>
                        <ModalTitle onClickClose={() => { this.handleShowCancelConfirm(); }}>Update Branch/Division</ModalTitle>
                        <div className="tab-content">
                            {/* branch information row group */}
                            <div className="row">
                                {/* address col group */}
                                <div className="col s12 m6 l6">
                                    <div className="row">
                                        <div className={`input-field col s12 required suffixinput ${validator.isRequireCompany ? "required-field" : ""}`}>
                                            <input type="text" maxLength="50" disabled={isFetching} value={branchInformation.Company} name="Company"
                                                onChange={e => this.handleInputChanged(e.target.name, e.target.value)}
                                                onBlur={() => this.handleValidateCompany()} className="form-control" id="company" ref="company" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="company">Branch/Division Name</label>
                                            <span className={`suffix-text ${validator.isRequireCompany ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Branch/Division Name")} />
                                            </span>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className={`input-field col s12 required suffixinput ${validator.isRequireAddress ? "required-field" : ""}`}>
                                            <input type="text" maxLength="50" disabled={isFetching} value={branchInformation.Address} name="Address"
                                                onChange={e => this.handleInputChanged(e.target.name, e.target.value)}
                                                onBlur={() => this.handleValidateAddress()} className="form-control" id="address" ref="address" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="address">Street # and Address</label>
                                            <span className={`suffix-text ${validator.isRequireAddress ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Street # and Address")} />
                                            </span>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="input-field col s12">
                                            <input type="text" maxLength="50" disabled={isFetching} value={branchInformation.Suite} name="Suite" onChange={e => this.handleInputChanged(e.target.name, e.target.value)} className="form-control" id="suite" ref="suite" />
                                            <label htmlFor="suite">Unit #, Suite #, etc...</label>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className={`input-field col s12 m4 l4 required suffixinput ${validator.isRequireZipCode ? "required-field" : ""} ${validator.isFormatZipCode ? "has-error" : ""}`}>
                                            <InputMask
                                                type="text"
                                                value={branchInformation.Zip || ""} name="Zip" onChange={e => this.handleInputChanged("Zip", e.target.value)} onBlur={() => this.handleValidateZipCode()}
                                                mask="99999" className="form-control"
                                                id="zipcode" ref={"zipCode"}
                                                disabled={isFetching || this.state.isFetchingSave}
                                                style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="zipcode">Zip</label>
                                            <span className={`suffix-text ${validator.isRequireZipCode ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Zip")} />
                                            </span>
                                            <span className={`suffix-text ${validator.isFormatZipCode ? "" : "hide"}`}>
                                                <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Zip")} />
                                            </span>
                                        </div>
                                        <div className={`input-field col s12 m8 l8 required suffixinput ${validator.isRequireCity ? "required-field" : ""}`}>
                                            <input
                                                type="text" maxLength="20" disabled={isFetching} value={branchInformation.City} name="City"
                                                onChange={e => this.handleInputChanged(e.target.name, e.target.value)}
                                                onBlur={() => this.handleValidateCity()} className="form-control" id="city" ref="city" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="city">City</label>
                                            <span className={`suffix-text ${validator.isRequireCity ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("City")} />
                                            </span>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col s12 m12">
                                            <div className={`input-field required suffixinput ${validator.isRequireState ? "required-field" : ""}`}>
                                                <Select
                                                    disabled={isFetching}
                                                    dataSource={stateDropDown}
                                                    value={branchInformation.State}
                                                    onChange={(value) => this.handleInputChanged("State", value)}
                                                    mapDataToRenderOptions={{ value: "Code", label: "Code" }}
                                                    ref="state"
                                                    id="updateState"
                                                    optionDefaultLabel="Select Your State"
                                                />
                                                <label htmlFor="updateState">State</label>
                                                <span className={`suffix-text ${validator.isRequireState ? "" : "hide"}`}>
                                                    <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("State")} />
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* user basic information col group */}
                                <div className="col s12 m6 l6">
                                    <div className="row">
                                        <div className={`input-field col s12 m6 l6 required suffixinput ${validator.isRequireContactFirst ? "required-field" : ""}`}>
                                            <input type="text" maxLength="50" disabled={isFetching} value={branchInformation.PrimaryContactFirst} name="PrimaryContactFirst"
                                                onChange={e => this.handleInputChanged(e.target.name, e.target.value)}
                                                onBlur={() => this.handleValidateContactFirst()} className="form-control" id="contact-first" ref="contactFirst" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="contact-first">First Name</label>
                                            <span className={`suffix-text ${validator.isRequireContactFirst ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("First Name")} />
                                            </span>
                                        </div>
                                        <div className={`input-field col s12 m6 l6 required suffixinput ${validator.isRequireContactLast ? "required-field" : ""}`}>
                                            <input type="text" maxLength="50" disabled={isFetching} value={branchInformation.PrimaryContactLast} name="PrimaryContactLast"
                                                onChange={e => this.handleInputChanged(e.target.name, e.target.value)}
                                                onBlur={() => this.handleValidateContactLast()} className="form-control" id="contact-last" ref="contactLast" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="contact-last">Last Name</label>
                                            <span className={`suffix-text ${validator.isRequireContactLast ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Last Name")} />
                                            </span>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className={`input-field col s12 m8 l8 required suffixinput ${validator.isRequirePhone ? "required-field" : ""} ${validator.isFormatPhone ? "has-error" : ""}`}>
                                            <InputMask
                                                type="text"
                                                value={branchInformation.Phone || ""}
                                                name="Phone" onChange={e => this.handleInputChanged("Phone", convertToPhoneNumber(e.target.value))}
                                                onBlur={() => this.handleValidatePhone()}
                                                mask="(999) 999-9999"
                                                placeholder="(###) ###-####"
                                                id="phone"
                                                ref="phone"
                                                disabled={isFetching}
                                                style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="phone">Phone Number</label>
                                            <span className={`suffix-text ${validator.isRequirePhone ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Phone Number")} />
                                            </span>
                                            <span className={`suffix-text ${validator.isFormatPhone ? "" : "hide"}`}>
                                                <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Phone Number")} />
                                            </span>
                                        </div>
                                        <div className="input-field col s12 m4 l4">
                                            <input type="text" maxLength="10" disabled={isFetching} value={branchInformation.PrimaryContactExt} name="PrimaryContactExt" onChange={e => this.handleInputChanged(e.target.name, e.target.value)} className="form-control" id="contact-email-ext" ref="contactExt" />
                                            <label htmlFor="contact-email-ext">Ext</label>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className={`input-field col s12 suffixinput ${validator.isFormatFax ? "has-error" : ""}`}>
                                            <label htmlFor="contact-fax">Fax</label>
                                            <InputMask
                                                type="text"
                                                value={branchInformation.PrimaryContactFax || ""}
                                                name="PrimaryContactFax"
                                                onChange={e => this.handleInputChanged(e.target.name, e.target.value)}
                                                mask="(999) 999-9999"
                                                placeholder="(###) ###-####"
                                                id="contact-fax"
                                                ref="contactFax"
                                                onBlur={() => this.handleValidateFaxFormat()}
                                                disabled={isFetching}
                                                style={{ paddingRight: "15px" }}
                                            />
                                            <span className={`suffix-text ${validator.isFormatFax ? "" : "hide"}`}>
                                                <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Fax")} />
                                            </span>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className={`input-field col s12 required suffixinput ${validator.isRequireContactEmail ? "required-field" : ""} ${validator.isFormatContactEmail ? "has-error" : ""}`}>
                                            <input type="text" maxLength="50" disabled={isFetching} value={branchInformation.Email} name="Email"
                                                onChange={e => this.handleInputChanged(e.target.name, e.target.value)} className="form-control"
                                                onBlur={() => this.handleValidateContactEmail()} id="contact-email" ref="contactEmail" style={{ paddingRight: "15px" }}
                                            />
                                            <label htmlFor="contact-email">Email</label>
                                            <span className={`suffix-text ${validator.isRequireContactEmail ? "" : "hide"}`}>
                                                <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Email")} />
                                            </span>
                                            <span className={`suffix-text ${validator.isFormatContactEmail ? "" : "hide"}`}>
                                                <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Email")} />
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="row mb-0">
                                <div className="col s12 font-12 bold-6 primary-color">
                                    <strong>Addresses to return Documents</strong>
                                </div>
                            </div>
                            <div className="row">
                                <div className={`input-field col s12 m5 l5 required suffixinput ${validator.isRequireReturnAddr ? "required-field" : ""}`}>
                                    <input
                                        type="text" maxLength="30" disabled={isFetching} value={branchInformation.ReturnAddr}
                                        className="form-control" name="ReturnAddr" id="return-address" ref="returnAddr" style={{ paddingRight: "15px" }}
                                        onChange={e => this.handleInputChanged(e.target.name, e.target.value)}
                                        onBlur={() => this.handleValidateReturnAddr()}
                                    />
                                    <label htmlFor="return-address">Street # and Address</label>
                                    <span className={`suffix-text ${validator.isRequireReturnAddr ? "" : "hide"}`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Street # and Address")} />
                                    </span>
                                </div>
                                <div className={`input-field col s12 m5 l5`}>
                                    <input type="text" maxLength="10" disabled={isFetching} value={branchInformation.ReturnAddrSuite} className="form-control" name="ReturnAddrSuite" id="return-address-suite" ref="returnAddrSuite" onChange={e => this.handleInputChanged(e.target.name, e.target.value)} />
                                    <label htmlFor="return-address-suite">Unit #, Suite #, etc…</label>
                                </div>
                            </div>
                            <div className="row">
                                <div className={`input-field col s12 m2 l2 required suffixinput ${validator.isRequireReturnAddrZip ? "required-field" : ""} ${validator.isFormatReturnAddrZip ? "has-error" : ""}`}>
                                    <InputMask
                                        type="text"
                                        mask="99999"
                                        name="ReturnAddrZip"
                                        style={{ paddingRight: "15px" }}
                                        value={branchInformation.ReturnAddrZip || ""}
                                        onChange={e => this.handleInputChanged(e.target.name, e.target.value)}
                                        id="return-address-zip" ref="returnAddrZip"
                                        disabled={isFetching || this.state.isFetchingAddr}
                                        onBlur={() => this.handleValidateReturnAddrZip()}
                                    />
                                    <label htmlFor="return-address-zip">Zip</label>
                                    <span className={`suffix-text ${validator.isRequireReturnAddrZip ? "" : "hide"}`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Zip")} />
                                    </span>
                                    <span className={`suffix-text ${validator.isFormatReturnAddrZip ? "" : "hide"}`}>
                                        <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Zip")} />
                                    </span>
                                </div>
                                <div className={`input-field col s12 m3 l3 required suffixinput ${validator.isRequireReturnAddrCity ? "required-field" : ""}`}>
                                    <input
                                        type="text" maxLength="50" disabled={isFetching} value={branchInformation.ReturnAddrCity} className="form-control"
                                        name="ReturnAddrCity" id="return-address-city" ref="returnAddrCity" style={{ paddingRight: "15px" }}
                                        onChange={e => this.handleInputChanged(e.target.name, e.target.value)}
                                        onBlur={() => this.handleValidateReturnAddrCity()}
                                    />
                                    <label htmlFor="return-address-city">City</label>
                                    <span className={`suffix-text ${validator.isRequireReturnAddrCity ? "" : "hide"}`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("City")} />
                                    </span>
                                </div>
                                <div className="col s8 m5 l5">
                                    <div className={`input-field required suffixinput ${validator.isRequireReturnAddrState ? "required-field" : ""}`}>
                                        <Select
                                            disabled={isFetching}
                                            dataSource={stateDropDown}
                                            value={branchInformation.ReturnAddrState}
                                            onChange={(value) => this.handleInputChanged("ReturnAddrState", value)}
                                            mapDataToRenderOptions={{ value: "Code", label: "Code" }}
                                            ref="returnAddrState"
                                            id="return-address-state"
                                            optionDefaultLabel="Select Your State"
                                        />
                                        <label htmlFor="return-address-state">State</label>
                                        <span className={`suffix-text ${validator.isRequireReturnAddrState ? "" : "hide"}`}>
                                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("State")} />
                                        </span>
                                    </div>
                                </div>
                                <div className="input-field col s2 right-align">
                                    <button disabled={isFetching || this.state.isFetchingAddr} className="btn success-color action-btn" onClick={() => this.handleAddReturnAddressClick()}>Add</button>
                                </div>
                            </div>
                            <div className="mr-1">
                                <table className="striped highlight responsive-table">
                                    <thead>
                                        <tr className="info">
                                            <th className="center-align">#</th>
                                            <th className="center-align">Default</th>
                                            <th className="left-align">Return Address</th>
                                            <th className="center-align">Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {returnAddressList}
                                        {branchReturnAddr.length === 0 ? <tr><td className="center-align" colSpan="4">There are no records to show.</td></tr> : null}
                                    </tbody>
                                </table>
                            </div>

                            <div className="row mb-0 mt-2">
                                <div className="col s12 font-12 bold-6 primary-color">
                                    <strong>CC Email Recipients</strong>
                                </div>
                            </div>

                            <div className="row">
                                <div className={`input-field col s12 m5 l5 required suffixinput ${validator.isRequireRecName ? "required-field" : ""}`}>
                                    <input
                                        type="text" maxLength="75" disabled={isFetching} className="form-control" id="cc-email-recipient-name" ref="recipientName" style={{ paddingRight: "15px" }}
                                        onBlur={() => this.handleValidateRecName()}
                                    />
                                    <label htmlFor="cc-email-recipient-name">Recipient Name</label>
                                    <span className={`suffix-text ${validator.isRequireRecName ? "" : "hide"}`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Recipient Name")} />
                                    </span>
                                </div>
                                <div className={`input-field col s12 m5 l5 required suffixinput ${validator.isRequireCcEmail ? "required-field" : ""} ${validator.isFormatCcEmail ? "has-error" : ""}`}>
                                    <input
                                        type="text" maxLength="100" disabled={isFetching} style={{ paddingRight: "15px" }}
                                        className="form-control" id="cc-email-recipient-email" ref="recipientEmail"
                                        onBlur={() => this.handleValidateCcEmail()}
                                    />
                                    <label htmlFor="cc-email-recipient-email">Recipient Email</label>
                                    <span className={`suffix-text ${validator.isRequireCcEmail ? "" : "hide"}`}>
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={requireMessage("Recipient Email")} />
                                    </span>
                                    <span className={`suffix-text ${validator.isFormatCcEmail ? "" : "hide"}`}>
                                        <img src={INPUT_ERROR_1X_IMAGE_URL} alt="" title={invalidMessage("Recipient Email")} />
                                    </span>
                                </div>
                                <div className="input-field col s12 m2 l2 right-align">
                                    <button disabled={isFetching} className="btn success-color action-btn" onClick={() => this.handleAddCcEmailClick()}>Add</button>
                                </div>
                                <div className="col s12">
                                    <p><label><i>Checking the "Invoice Only" box will send recipient invoices for transactions.</i></label></p>
                                    <p><label><i>Checking the "Status Only" box will send recipient copies of order related emails.</i></label></p>
                                </div>
                            </div>
                            <div className="mr-1">
                                <table className="striped highlight responsive-table">
                                    <thead>
                                        <tr className="info">
                                            <th className="center-align">#</th>
                                            <th className="center-align">Invoice Only</th>
                                            <th className="center-align">Status Update Only</th>
                                            <th className="left-align">Recipient Name</th>
                                            <th className="left-align">Recipient Address</th>
                                            <th className="center-align">Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {ccEmailList}
                                        {branchCcEmail.length === 0 ? <tr><td className="center-align" colSpan="6">There are no records to show.</td></tr> : null}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col s6 m6 l6">
                                <button disabled={isFetching || this.state.isFetchingSave} className="btn white w-100" onClick={() => this.handleShowCancelConfirm()}>Cancel</button>
                            </div>
                            <div className="col s6 m6 l6">
                                <button disabled={isFetching || this.state.isFetchingSave} className="btn success-color w-100" onClick={() => this.handleSaveClick()}>Save Changes</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

BranchUpdate.propTypes = {
    dispatch: PropTypes.func.isRequired,
    listState: PropTypes.array,
    userId: PropTypes.number,
    brokerId: PropTypes.string,
    updateId: PropTypes.number,
    branchInformation: PropTypes.object,
    branchReturnAddr: PropTypes.array,
    branchCcEmail: PropTypes.array,
    stateDropDown: PropTypes.array,
    needReload: PropTypes.bool,
    isFetching: PropTypes.bool,
    validator: PropTypes.object,
    params: PropTypes.object,
    router: PropTypes.object,
    redirect: PropTypes.func,
    handleCancel: PropTypes.func,
    isOpen: PropTypes.bool
};

const mapStateToProps = (state) => {
    const { validator } = state.branchManagement.branchAdd;
    const { branchInformation, branchReturnAddr, branchCcEmail, stateDropDown, isFetching, needReload } = state.branchManagement.branchUpdate;
    const { userId } = state.authentication;

    return {
        validator,
        userId,
        branchInformation,
        branchReturnAddr,
        branchCcEmail,
        stateDropDown,
        needReload,
        isFetching
    };
};

export default connect(mapStateToProps)(BranchUpdate);