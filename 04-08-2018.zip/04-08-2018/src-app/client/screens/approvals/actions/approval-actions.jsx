import { apiGetOrdersFeeApprovalRequest, apiGetOrdersFeeApprovalDetails } from "Api/order-fee-approve-api";
import { apiGetSignersApprovalByBrokerId } from "Api/signers-approval-api";
import { handleApiError } from "ErrorHandler";

export const APPROVALS_SEARCH_RECEIVE = "APPROVALS_SEARCH_RECEIVE";
export const APPROVALS_SET_FILTER = "APPROVALS_SET_FILTER";
export const APPROVALS_SET_MODAL = "APPROVALS_SET_MODAL";
export const APPROVALS_DETAIL = "APPROVALS_DETAIL";

export const setApprovalFilter = (filter) => {
    return {
        type: APPROVALS_SET_FILTER,
        filter
    };
};

export const receiveApproval = (listApproval) => {
    return {
        type: APPROVALS_SEARCH_RECEIVE,
        listApproval
    };
};

export const setApprovalModal = (approvalModal) => {
    return {
        type: APPROVALS_SET_MODAL,
        approvalModal
    };
};

export const receiveApprovalDetail = (approvalModal) => {
    return {
        type: APPROVALS_DETAIL,
        approvalModal
    };
};

export const searchApproval = (filter, mod) => {
    return (dispatch) => {

        dispatch(setApprovalFilter(filter));
        if (mod === "fee") {
            return apiGetOrdersFeeApprovalRequest(filter, (response) => {
                dispatch(receiveApproval(response.data));
            }, (error) => handleApiError(dispatch, error));
        } else {
            return apiGetSignersApprovalByBrokerId(filter, (response) => {
                dispatch(receiveApproval(response.data));
            }, (error) => handleApiError(dispatch, error));
        }
    };
};

export const reviewApproval = (approvalId, mod) => {
    return (dispatch) => {

        return apiGetOrdersFeeApprovalDetails(approvalId, (response) => {
            const approvalModal = {
                isShowForm: true,
                approvalDetail: response.data,
                mod
            };

            dispatch(receiveApprovalDetail(approvalModal));
        }, (error) => handleApiError(dispatch, error));
    };
};