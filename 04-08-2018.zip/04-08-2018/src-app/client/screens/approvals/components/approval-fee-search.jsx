import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import { searchApproval, setApprovalFilter, receiveApprovalDetail, setApprovalModal } from "../actions/approval-actions";
import GridView from "GridView";
import NumbericInput from "NumbericInput";
import Select from "Select";
import ApprovalFeeModal from "../components/approval-modal";
import { getCommentByType } from "Api/comment-api";
import { COMMENT_TYPE, USER_TYPE } from "Constants";
import { ROLE_NAMES } from "../../../constant/role-constants";

class ApprovalFeeSearch extends Component {

    handleSearchClick() {
        const { dispatch, filter } = this.props;
        dispatch(setApprovalFilter({ ...filter, page: 1 }));
        dispatch(searchApproval({ ...filter, page: 1 }, "fee"));
    }

    handleResetClick() {
        const { dispatch } = this.props;
        const filter = {
            ...this.props.filter,
            page: 1,
            orderId: "",
            status: ""
        };
        dispatch(setApprovalFilter({ ...filter, page: 1 }));
        dispatch(searchApproval(filter, "fee"));
    }

    handleGridViewReload(criteria) {
        const { dispatch } = this.props;
        const filter = { ...this.props.filter, ...criteria };

        dispatch(searchApproval(filter, "fee"));
    }

    handleGridViewActionClick(action, identifier) {
        const { dispatch, listApproval } = this.props;
        switch (action) {
            case "review":
                listApproval.approvals.filter((approval) => {
                    if (approval.approvalId === identifier) {
                        const filter = {
                            typeId: COMMENT_TYPE.RequestFeeCommentType,
                            ownerId: approval.approvalId
                        };
                        getCommentByType(filter, (response) => {
                            const comments = response.data ? response.data : "";
                            const approvalModal = {
                                isShowForm: true,
                                approvalDetail: approval,
                                comments
                            };

                            dispatch(receiveApprovalDetail(approvalModal));
                        });

                    }
                });
                break;
        }
    }

    onCloseModal(isSearch) {
        this.props.dispatch(setApprovalModal({ ...this.props.approvalModal, isShowForm: false }));
        if (isSearch) {
            this.props.dispatch(searchApproval(this.props.filter, "fee"));
        }
    }

    componentDidMount() {
        const { dispatch, profile, roleType, roleNames } = this.props;

        const isScheduler = roleNames.includes(ROLE_NAMES.STAFF_SCHEDULER);
        const isStatusRep = roleNames.includes(ROLE_NAMES.STAFF_STATUS_REP);
        const isQualityControl = roleNames.includes(ROLE_NAMES.STAFF_QUALITY_CONTROL);
        const isTceManager = roleNames.includes(ROLE_NAMES.STAFF_ADMIN) || roleNames.includes(ROLE_NAMES.STAFF_OPERATIONAL_MANAGER);

        const filter = {
            ...this.props.filter,
            sortColumn: "date",
            orderId: "",
            status: "",
            brokerId: roleType === USER_TYPE.Client ? profile.id : 0,
            userId: profile.userId,
            isClientFee: false,
            isScheduler,
            isStatusRep,
            isQualityControl,
            isTceManager
        };

        dispatch(searchApproval(filter, "fee"));
    }

    handleOrderIDChanged(value) {
        const { dispatch } = this.props;
        dispatch(setApprovalFilter({ ...this.props.filter, orderId: value }));
    }

    render() {
        const { listApproval, filter, columnsClient, columnsStaff, dispatch, approvalModal, profile, roleType } = this.props;
        let columns = [];
        let isStaff = false;

        if (roleType === "Staff") {
            columns = columnsStaff;
            isStaff = true;
        } else {
            columns = columnsClient;
        }

        const renderInput = () => {
            return (
                <div className="row">
                    <div className="input-field col s12 m6">
                        <NumbericInput value={filter.orderId} ref="orderID" id="orderID" className="validate" maxLength="10" onChange={this.handleOrderIDChanged.bind(this)} />
                        <label htmlFor="orderID">Order ID</label>
                    </div>
                    <div className="input-field col s12 m6">
                        <Select
                            dataSource={[{ Code: "", Description: "All" }, { Code: "Pending", Description: "Pending" }, { Code: "Approved", Description: "Approved" }, { Code: "Rejected", Description: "Rejected" }]}
                            mapDataToRenderOptions={{ value: "Code", label: "Description" }}
                            ref="status"
                            id="status"
                            className="validate"
                            value={filter.status}
                            onChange={(status) => dispatch(setApprovalFilter({ ...filter, status }))}
                        />
                        <label htmlFor="customerName">Status</label>
                    </div>
                </div>
            );
        };
        return (
            <div className="place-section">
                <div className="row">
                    <div className="col s12">
                        <h3 className="title-page-detail">{`${isStaff ? "Vendor " : ""}Fee Requests`}</h3>
                    </div>
                </div>
                <div className="wrap-search-form">
                    {renderInput()}
                    <div className="row mb-0">
                        <div className="col s12 m6">
                            <p className="left red-color">Insert criteria to search for specific order</p>
                        </div>
                        <div className="col s12 m6">
                            <div className="right center-btn-mobile">
                                <button type="button" className="btn btn-small reload-btn btn-primary" style={{ marginRight: "5px" }} onClick={(e) => this.handleResetClick(e)}>
                                    <i className="lnr lnr-redo"></i>
                                </button>
                                <button onClick={(e) => this.handleSearchClick(e)} className="btn action-btn success-color">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row mb-0">
                    <div className="col s12 m12">
                        <p><b>Search Results</b></p>
                    </div>
                </div>
                <div className="wrap-result-search">
                    <GridView
                        criteria={filter}
                        totalRecords={listApproval ? listApproval.totalRecords : 0}
                        datasources={listApproval ? listApproval.approvals : []}
                        columns={columns}
                        identifier={"approvalId"}
                        actions={["review"]}
                        onGridViewReload={(e) => this.handleGridViewReload(e)}
                        onActionClick={this.handleGridViewActionClick.bind(this)}
                    />
                </div>
                <ApprovalFeeModal approvalModal={approvalModal} profile={profile} onCloseModal={(isSearch) => this.onCloseModal(isSearch)} />
            </div>
        );
    }
}

ApprovalFeeSearch.defaultProps = {
    columnsClient: [
        {
            title: "Date",
            data: "date",
            type: "datetime"
        },
        {
            title: "Order ID",
            data: "orderId",
            type: "orderDetailLink",
            id: "orderId"
        },
        {
            title: "Reason",
            data: "reason"
        },
        {
            title: "Vendor",
            data: "vendorName",
            type: "vendorLink",
            id: "signerId"
        },
        {
            title: "Original Fee",
            data: "originalVendorFee",
            type: "money"
        },
        {
            title: "Fee Requested",
            data: "originalVendorFee",
            type: "money"
        },
        {
            title: "Status",
            data: "status"
        },
        {
            title: "Approved/ Rejected by",
            data: "approvedBy"
        }
    ],
    columnsStaff: [
        {
            title: "Date",
            data: "date",
            type: "datetime"
        },
        {
            title: "Order ID",
            data: "orderId",
            type: "orderDetailLink",
            id: "orderId"
        },
        {
            title: "Reason",
            data: "reason"
        },
        {
            title: "Requested by",
            data: "requestedBy"
        },
        {
            title: "Vendor",
            data: "vendorName",
            type: "vendorLink",
            id: "signerId"
        },
        {
            title: "Client Fee",
            data: "currentClientFee",
            type: "money"
        },
        {
            title: "Original Fee",
            data: "originalVendorFee",
            type: "money"
        },
        {
            title: "Fee Requested",
            data: "proposedVendorFee",
            type: "money"
        },
        {
            title: "Status",
            data: "status"
        },
        {
            title: "Approved/ Rejected by",
            data: "approvedBy"
        }
    ]
};

ApprovalFeeSearch.propTypes = {
    dispatch: PropTypes.func.isRequired,
    params: PropTypes.object,
    listApproval: PropTypes.object,
    filter: PropTypes.object,
    columnsClient: PropTypes.array,
    columnsStaff: PropTypes.array,
    profile: PropTypes.object,
    approvalModal: PropTypes.object,
    brokerId: PropTypes.number,
    roleType: PropTypes.string,
    roleNames: PropTypes.array
};

const mapStateToProps = (state) => {
    const { listApproval, filter, approvalModal } = state.approvals;
    return {
        listApproval,
        approvalModal,
        filter,
        profile: state.authentication.profile,
        roleType: state.authentication.role.roleType,
        roleNames: state.authentication.role.roleNames
    };
};

export default connect(mapStateToProps)(ApprovalFeeSearch);