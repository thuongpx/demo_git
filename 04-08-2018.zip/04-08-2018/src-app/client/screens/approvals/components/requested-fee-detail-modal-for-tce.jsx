import React from "react";
import { connect } from "react-redux";
import { Component } from "react";
import PropTypes from "prop-types";
import { Modal, ModalBody, ModalFooter, ModalTitle } from "Modal";
import { apiUpdateOrdersFeeApprove } from "Api/order-fee-approve-api";
import { showSuccess, showError } from "../../main-layout/actions";
import CommonModal from "CommonModal";
import { apiCheckExistVendorOffer } from "Api/vendor-offer-api";
import { apiCheckOrderStatusForApprove } from "Api/orders-api";
import { apiAddComment, getCommentByType } from "Api/comment-api";
import moment from "moment";
import { COMMENT_TYPE } from "Constants";
import { receiveApprovalDetail } from "../actions/approval-actions";
import { apiUpdateVendorApprovalRequest } from "Api/signers-approval-api";
import { thousandSep } from "Helpers/common-helper";

import { emitRequestCountFeeVendorRequest } from "../../../socket/users";
import noAvatarImg from "./../../../public/images/no-avatar.png";


export class FeeApprovalModalForTce extends Component {

    constructor(props) {
        super(props);
        this.state = {
            disabled: true
        };
    }

    handleCloseForm() {
        this.props.onCloseModal(false);
        this.refs.addComment.value = "";
        this.setState({ disabled: true });
    }

    addComment() {
        const { dispatch, approvalModal, profile } = this.props;
        const comment = {
            Description: this.refs.addComment.value,
            CreatedBy: profile.userId,
            TypeID: approvalModal.mod === "fee" ? COMMENT_TYPE.RequestFeeCommentType : COMMENT_TYPE.VendorApprovalCommentType,
            OwnerID: approvalModal.approvalDetail.approvalId,
            ParentID: null,
            CreatedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        };
        apiAddComment(comment, (response) => {
            if (response.data.isSuccess) {
                const filter = {
                    typeId: approvalModal.mod === "fee" ? COMMENT_TYPE.RequestFeeCommentType : COMMENT_TYPE.VendorApprovalCommentType,
                    ownerId: approvalModal.approvalDetail.approvalId
                };
                getCommentByType(filter, (result) => {
                    const description = result.data ? result.data : "";

                    dispatch(receiveApprovalDetail({ ...approvalModal, description }));
                });
                this.refs.addComment.value = "";
                this.setState({ disabled: true });
            }
        });
    }

    handleKeyPress(e) {
        if (e.key === "Enter") {
            this.addComment();
        }
    }

    handleDecline() {
        const { dispatch, approvalModal, profile } = this.props;
        const mod = approvalModal.mod === "fee" ? "fee" : "Vendor";
        const approval = {
            feeApprovalId: approvalModal.approvalDetail.approvalId,
            orderId: approvalModal.approvalDetail.orderId,
            activity: `${profile.userName} declined the ${mod} request for this order.`,
            usersId: profile.userId,
            isApprove: false,
            feeApproval: approvalModal.approvalDetail.feeAmount
        };
        apiUpdateOrdersFeeApprove(approval, (response) => {
            if (response.data.isSuccess) {
                this.props.onCloseModal(true);
                dispatch(showSuccess("This request has been rejected"));
            }
        });
    }

    handleUpdateApprove(isApprove) {
        const { approvalModal, profile, roleType, roleNames } = this.props;
        // const activity = `${profile.userName} ${isApprove ? "approved" : "rejected"} the ${approvalModal.mod === "fee" ? "fee" : "Vendor"} request for ${approvalModal.approvalDetail.vendorName} in this order.`;
        const activity = `${profile.userName} ${isApprove ? "approved" : "rejected"} the ${approvalModal.mod === "fee" ? "fee" : "Vendor"} request for this order.`;
        let brokerId = 0;
        if (roleType === "Staff") {
            roleNames.map((item) => {
                if (item === "Admin" || item === "Operational Manager") {
                    brokerId = 0;
                }
            });
        } else {
            brokerId = profile.id;
        }
        const callApiApproveRejectRequest = () => {
            const approval = {
                feeApprovalId: approvalModal.approvalDetail.approvalId,
                orderId: approvalModal.approvalDetail.orderId,
                activity,
                clientAgentId: approvalModal.approvalDetail.usersId,
                usersId: profile.userId,
                isApprove,
                feeAmount: approvalModal.approvalDetail.feeAmount,
                signerId: approvalModal.approvalDetail.signerId,
                feeDescripId: approvalModal.approvalDetail.feeDescripId,
                reason: approvalModal.approvalDetail.reason,
                originalAmount: approvalModal.approvalDetail.originalAmount,
                offerId: approvalModal.approvalDetail.offerId,
                brokerId
            };

            apiUpdateOrdersFeeApprove(approval, (response) => {
                if (response.data.isSuccess) {
                    this.props.onCloseModal(true);
                    this.showMessageSuccess(isApprove);
                }

                // trigger to re-count pending requests
                emitRequestCountFeeVendorRequest(brokerId, profile.userId);
                //emitRequestCountFeeVendorRequest(profile.id, profile.userId);
            });
        };

        if (approvalModal.mod === "fee") {
            if (isApprove) {
                this.commonModal.showModal({
                    type: "confirm",
                    message: "Approving this fee request means all other fee requests for this order will be rejected. Are you sure you would like to approve this fee request?"
                }, () => {
                    callApiApproveRejectRequest();
                });
            } else {
                callApiApproveRejectRequest();
            }
        } else {
            const signerApproval = {
                approvedBy: profile.userId,
                approvalId: approvalModal.approvalDetail.approvalId,
                orderId: approvalModal.approvalDetail.orderId,
                signerId: approvalModal.approvalDetail.signerId,
                isApprove,
                activity,
                reason: approvalModal.approvalDetail.reason,
                clientAgentId: approvalModal.approvalDetail.usersId
            };
            apiUpdateVendorApprovalRequest(signerApproval, (response) => {
                if (response.data.isSuccess) {
                    this.props.onCloseModal(true);
                    this.showMessageSuccess(isApprove);
                }
            });
        }
    }

    showMessageSuccess(isApprove) {
        const { dispatch } = this.props;
        if (isApprove) {
            dispatch(showSuccess("Approved Successfully"));
        } else {
            dispatch(showSuccess("This request has been rejected"));
        }
    }

    handleApprove() {
        const { dispatch, approvalModal, profile, roleType, roleNames } = this.props;
        if (approvalModal.approvalDetail.signerId !== undefined && approvalModal.approvalDetail.signerId !== null) {
            let aptDateTime = moment(approvalModal.approvalDetail.aptDateTime).utc().format("YYYY-MM-DD HH:mm:ss");
            if (aptDateTime === "Invalid date") {
                aptDateTime = null;
            }
            apiCheckExistVendorOffer(aptDateTime, approvalModal.approvalDetail.signerId, approvalModal.approvalDetail.orderId, (response) => {
                switch (response.data.data) {
                    case 1: {
                        dispatch(showError("This Vendor has already assigned to another order having the same ADT", () => {
                            this.handleUpdateApprove(false);
                        }));
                        break;
                    }
                    case 2: {
                        this.checkOrderAssignAnotherVendor(approvalModal.approvalDetail.orderId);
                        break;
                    }
                    case 3: {
                        this.checkOrderAssignAnotherVendor(approvalModal.approvalDetail.orderId);
                        break;
                    }
                    default:
                        this.handleUpdateApprove(true);
                        break;
                }

                // trigger to re-count pending requests
                let brokerId = 0;
                if (roleType === "Staff") {
                    roleNames.map((item) => {
                        if (item === "Admin" || item === "Operational Manager") {
                            brokerId = 0;
                        }
                    });
                } else {
                    brokerId = profile.id;
                }
                emitRequestCountFeeVendorRequest(brokerId, profile.userId);
            });
        } else {
            this.handleUpdateApprove(true);
        }
    }

    checkOrderAssignAnotherVendor(orderId) {
        const { dispatch } = this.props;
        apiCheckOrderStatusForApprove(orderId, (result) => {
            if (result.data) {
                this.commonModal1.showModal({
                    type: "confirm",
                    message: "Another Vendor has been assigned to this order. Do you want to replace that Vendor?"
                }, () => {
                    this.handleUpdateApprove(true);
                }, () => {
                    this.handleUpdateApprove(false);
                });
            } else {
                dispatch(showError("This order has been closed by another vendor. You cannot change the order’s vendor", () => {
                    this.handleUpdateApprove(false);
                }));
            }
        });
    }

    renderComment() {
        const { accountId, img, userName, approvalModal } = this.props;
        const { description } = approvalModal;

        if (description !== undefined) {
            if (description.length > 0) {
                return (
                    <div>
                        <ol id="notePanel" className="notelist" style={{ maxHeight: "500px", overflowY: "scroll" }}>
                            {description.map((item, index) => {
                                if (item.usersId !== accountId) {
                                    return (
                                        <li className="your-note" key={index} style={{ marginBottom: "25px" }} >
                                            <div className="avt-note">
                                                <img alt="" title={item.UserName} className="responsive-img circle" src={(item.img === "" || item.img === undefined || item.img === null) ? noAvatarImg : item.img} />
                                            </div>
                                            <div className="chat-content" >
                                                <p style={{ wordBreak: "break-word" }}>{item.Description}</p>
                                                <small>{moment(item.createdDate).format("MMM D YYYY [at] h:mm A")}</small>
                                            </div>
                                        </li>
                                    );
                                }
                                return (
                                    <li className="other-note" key={index} style={{ marginBottom: "25px" }}>
                                        <div className="chat-content">
                                            <p style={{ wordBreak: "break-word" }}>{item.Description}</p>
                                            <div className="avt-note">
                                                <img alt="" title={userName} className="responsive-img circle" src={(item.img === "" || item.img === undefined) ? noAvatarImg : item.img} />
                                            </div>
                                            <small>{moment(item.createdDate).format("MMM D YYYY [at] h:mm A")}</small>
                                        </div>
                                    </li>
                                );
                            })}
                        </ol>
                    </div>
                );
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    handleResetComment() {
        this.refs.addComment.value = "";
        this.setState({
            disabled: true
        });
    }

    render() {
        const { approvalModal, roleType, roleNames } = this.props;
        let isStaff = false;

        if (roleType === "Staff") {
            roleNames.map((item) => {
                if (item === "Admin" || item === "Operational Manager") {
                    isStaff = true;
                }
            });
        }

        return (
            <div>
                <Modal onClickClose={() => { this.handleCloseForm(); }} isOpen={approvalModal.isShowForm} addClass="modal-approval">
                    <ModalBody>
                        <ModalTitle onClickClose={() => this.handleCloseForm()}>{approvalModal.mod === "fee" ? "Fee Approval Request Details" : "Vendor Approval Request Details"}</ModalTitle>
                        <div className="tab-content">
                            <div className="row">
                                <div className="input-field col s12 m12 l6">
                                    <b>Order ID: <span className="right">{approvalModal.approvalDetail.orderId}</span></b>
                                </div>
                                <div className="input-field col s12 m12 l6">
                                    <b>Fee Approval Status: <span className="right">{approvalModal.approvalDetail.status}</span></b>
                                </div>
                            </div>
                            {approvalModal.mod === "fee" ?
                                <div className="row">
                                    <div className="input-field col s12 m12 l6">
                                        <b>Original Fee to Vendor:</b> <span className="right">${thousandSep(parseFloat(approvalModal.approvalDetail.originalAmount ? approvalModal.approvalDetail.originalAmount : 0).toFixed(2))}</span>
                                    </div>
                                    <div className="input-field col s12 m12 l6">
                                        <b>Requested Fee to Vendor:</b> <span className="right">${thousandSep(parseFloat(approvalModal.approvalDetail.feeAmount ? approvalModal.approvalDetail.feeAmount : 0).toFixed(2))}</span>
                                    </div>
                                </div> : ""
                            }
                            {/* NamNV10 start*/}
                            {(approvalModal.mod === "fee" && isStaff) ?
                                <div className="row">
                                    <div className="input-field col s12 m12 l6">
                                        <b>Date:</b> <span className="right">{moment(approvalModal.approvalDetail.date).format("MM/DD/YY h:mm:ss A")}</span>
                                    </div>
                                    <div className="input-field col s12 m12 l6">
                                        <b>Client Fee:</b> <span className="right">${thousandSep(parseFloat(approvalModal.approvalDetail.clientFee ? approvalModal.approvalDetail.clientFee : 0).toFixed(2))}</span>
                                    </div>
                                </div> : ""
                            }
                            {/* NamNV10 end*/}
                            <div className="row">
                                <div className="input-field col s12 m12 l6">
                                    {approvalModal.mod === "fee" ? <span><b>Status Reason: </b> <span className="right">{approvalModal.approvalDetail.reason}</span> </span> : <span><b>Requested By:</b> <span className="right">{approvalModal.approvalDetail.requestedBy} </span></span>}
                                </div>
                                <div className="input-field col s12 m12 l6">
                                    <b>Vendor Name:</b> <span className="right">{approvalModal.approvalDetail.vendorName}</span>
                                </div>
                            </div>
                            {/* NamNV10 start*/}
                            {(approvalModal.mod === "vendor" && isStaff) ?
                                <div className="row">
                                    <div className="input-field col s12 m12 l6">
                                        <b>Date:</b> <span className="right">{moment(approvalModal.approvalDetail.date).format("MM/DD/YY h:mm:ss A")}</span>
                                    </div>
                                </div> : ""
                            }


                            {/* Description/Comment */}
                            <div style={{ borderWidth: "1px", borderRadius: "10px", borderStyle: "solid", margin: "20px 20px 0 20px", padding: "0 20px 0 20px", borderColor: "#e0e0e0" }}>
                                <div className="valign-wrapper">
                                    <p>Description/Comments</p>
                                </div>
                                <div className="divider" style={{ marginBottom: "20px" }}></div>
                                <div>
                                    {this.renderComment()}
                                </div>
                                <div className="row">
                                    <div className="input-field col s12 m12">
                                        <br />
                                        <input id="addComment"
                                            maxLength="250"
                                            type="text"
                                            ref="addComment"
                                            className="validate"
                                            onChange={() => this.setState({ ...this.state, disabled: this.refs.addComment.value === "" ? true : false })}
                                            onKeyPress={(e) => this.handleKeyPress(e)}
                                        />
                                        <label htmlFor="addComment">Enter a Description/ Comments for this Request</label>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="right input-field">
                                        <button type="button" className="btn white action-btn" disabled={this.state.disabled} onClick={() => this.handleResetComment()}>RESET</button>
                                        <button
                                            onClick={() => this.addComment()} className="btn btn-primary action-btn"
                                            disabled={this.state.disabled}
                                        >Add</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <div className="row m-0">
                            <div className="col s4 m4 l4">
                                <button className="btn white w-100" onMouseDown={() => this.handleCloseForm()}>Close</button>
                            </div>
                            <div className="col s4 m4 l4">
                                <button className="btn error-color w-100" onMouseDown={() => { this.handleUpdateApprove(false); }} disabled={approvalModal.approvalDetail.status === "Pending" ? false : true}>Decline</button>
                            </div>
                            <div className="col s4 m4 l4">
                                <button className="btn success-color w-100" onMouseDown={() => { this.handleApprove(); }} disabled={approvalModal.approvalDetail.status === "Pending" ? false : true}>Approve</button>
                            </div>
                        </div>
                    </ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
                <CommonModal ref={(commonModal1) => { this.commonModal1 = commonModal1; }} />
            </div>
        );
    }
}

FeeApprovalModalForTce.propTypes = {
    dispatch: PropTypes.func,
    onCloseModal: PropTypes.func,
    saveChanges: PropTypes.func,
    approvalModal: PropTypes.object,
    profile: PropTypes.object,
    roleType: PropTypes.string,
    roleNames: PropTypes.array,
    accountId: PropTypes.number,
    img: PropTypes.string,
    userName: PropTypes.string
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { role, accountId, profile } = authentication;
    const { userName, img } = profile;

    return {
        roleType: role.roleType,
        roleNames: role.roleNames,
        accountId,
        userName,
        img
    };
};

export default connect(mapStateToProps)(FeeApprovalModalForTce);