import React from "react";
import { connect } from "react-redux";
import { Component } from "react";
import PropTypes from "prop-types";
import { Modal, ModalBody, ModalFooter, ModalTitle } from "Modal";
import { showSuccess, showError } from "../../main-layout/actions";
import CommonModal from "CommonModal";
import { apiAddComment, getCommentByType } from "Api/comment-api";
import moment from "moment";
import { COMMENT_TYPE, ORDER_REQUEST_APPROVE_STATUS, USER_TYPE } from "Constants";
import { receiveApprovalDetail } from "../actions/approval-actions";
import { thousandSep } from "Helpers/common-helper";
import { emitRequestCountFeeVendorRequest } from "../../../socket/users";
import noAvatarImg from "./../../../public/images/no-avatar.png";
import { ROLE_NAMES } from "../../../constant/role-constants";
import { ACTION } from "../../../constant/progress-log-constants";
import { apiProcessClientFeeRequest } from "Api/order-request-approval-api";


export class ApprovalClientFeeModal extends Component {

    constructor(props) {
        super(props);
        this.state = {
            disabled: true
        };
    }

    handleCloseForm() {
        this.props.onCloseModal(false);
        this.refs.addComment.value = "";
        this.setState({ disabled: true });
    }

    addComment() {
        const { dispatch, approvalModal, profile } = this.props;
        const comment = {
            Description: this.refs.addComment.value,
            CreatedBy: profile.userId,
            TypeID: COMMENT_TYPE.RequestFeeCommentType,
            OwnerID: approvalModal.approvalDetail.approvalId,
            ParentID: null,
            CreatedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        };

        apiAddComment(comment, (response) => {
            if (response.data.isSuccess) {
                const filter = {
                    typeId: COMMENT_TYPE.RequestFeeCommentType,
                    ownerId: approvalModal.approvalDetail.approvalId
                };
                getCommentByType(filter, (result) => {
                    const comments = result.data ? result.data : "";

                    dispatch(receiveApprovalDetail({ ...approvalModal, comments }));
                });
                this.refs.addComment.value = "";
                this.setState({ disabled: true });
            }
        });
    }

    handleKeyPress(e) {
        if (e.key === "Enter") {
            this.addComment();
        }
    }

    processRequestedFee(isApprove) {
        const { approvalModal, profile, dispatch } = this.props;
        const { approvalDetail, comments } = approvalModal;

        const approvalData = {
            feeApprovalId: approvalDetail.approvalId,
            orderId: approvalDetail.orderId,
            usersId: profile.userId,
            isApprove,
            requestAmount: approvalDetail.proposedClientFee,
            originalAmount: approvalDetail.originalClientFee,
            feeDescripId: approvalDetail.feeDescripId,
            activity: `${profile.userName} ${isApprove ? `approved` : `declined`} the client fee request for this order.`,
            progressType: ACTION,
            brokerFee: approvalDetail.feeAmount,
            requestedBy: approvalDetail.usersId,
            reason: comments.length > 0 ? comments[0].Description : "",
            clientCompanyName: approvalDetail.clientCompanyName
        };

        // call api
        apiProcessClientFeeRequest(approvalData, () => {
            this.props.onCloseModal(true);
            dispatch(showSuccess(isApprove ? "This request has been approved" : "This request has been rejected"));
            emitRequestCountFeeVendorRequest(profile.userId);
        }, (error) => {
            if (error.response !== undefined) {
                if (error.response.data.message === "No Rows Updated") {
                    dispatch(showError("Save conflict!"));
                } else {
                    dispatch(showError(error.response.data.message));
                }
            } else {
                dispatch(showError(`Unable to connect ${error.config.url}`));
            }
            emitRequestCountFeeVendorRequest(profile.userId);
            this.props.onCloseModal(true);
        });
    }

    renderComment() {
        const { profile, approvalModal } = this.props;
        const { comments } = approvalModal;

        if (comments !== undefined) {
            if (comments.length > 0) {
                return (
                    <div>
                        <ol id="notePanel" className="notelist" style={{ maxHeight: "500px", overflowY: "scroll" }}>
                            {comments.map((item, index) => {
                                if (item.usersId !== profile.userId) {
                                    return (
                                        <li className="your-note" key={index} style={{ marginBottom: "25px" }} >
                                            <div className="avt-note">
                                                <img alt="" title={item.UserName} className="responsive-img circle" src={(item.img === "" || item.img === undefined || item.img === null) ? noAvatarImg : item.img} />
                                            </div>
                                            <div className="chat-content" >
                                                <p style={{ wordBreak: "break-word" }}>{item.Description}</p>
                                                <small>{moment(item.createdDate).format("MMM D YYYY [at] h:mm A")}</small>
                                            </div>
                                        </li>
                                    );
                                }
                                return (
                                    <li className="other-note" key={index} style={{ marginBottom: "25px" }}>
                                        <div className="chat-content">
                                            <p style={{ wordBreak: "break-word" }}>{item.Description}</p>
                                            <div className="avt-note">
                                                <img alt="" title={profile.userName} className="responsive-img circle" src={(item.img === "" || item.img === undefined) ? noAvatarImg : item.img} />
                                            </div>
                                            <small>{moment(item.createdDate).format("MMM D YYYY [at] h:mm A")}</small>
                                        </div>
                                    </li>
                                );
                            })}
                        </ol>
                    </div>
                );
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    renderCommentModule() {
        return (
            <div style={{ borderWidth: "1px", borderRadius: "10px", borderStyle: "solid", margin: "20px 20px 0 20px", padding: "0 20px 0 20px", borderColor: "#e0e0e0" }}>
                <div className="valign-wrapper">
                    <p>Description</p>
                </div>
                <div className="divider" style={{ marginBottom: "20px" }}></div>
                <div>
                    {this.renderComment()}
                </div>
                <div className="row">
                    <div className="input-field col s12 m12">
                        <br />
                        <input id="addComment"
                            maxLength="250"
                            type="text"
                            ref="addComment"
                            className="validate"
                            onChange={() => this.setState({ ...this.state, disabled: this.refs.addComment.value === "" ? true : false })}
                            onKeyPress={(e) => this.handleKeyPress(e)}
                        />
                        <label htmlFor="addComment">Add comment</label>
                    </div>
                </div>
                <div className="row">
                    <div className="right input-field">
                        {/* <button type="button" className="btn white action-btn" disabled={this.state.disabled} onClick={() => this.handleResetComment()}>RESET</button> */}
                        <button
                            onClick={() => this.addComment()} className="btn btn-primary action-btn"
                            disabled={this.state.disabled}
                        >ENTER</button>
                    </div>
                </div>
            </div>
        );
    }

    handleResetComment() {
        this.refs.addComment.value = "";
        this.setState({
            disabled: true
        });
    }

    render() {
        const { approvalModal, roleType, roleNames } = this.props;
        const { approvalDetail } = approvalModal;

        let isStaff = false;

        if (roleType === USER_TYPE.Staff) {
            isStaff = true;
        }

        // only Tce staff can see this screen
        if (!isStaff) {
            return (<div>
            </div>
            );
        }

        const renderButton = () => {
            if (!approvalDetail) {
                return (
                    <div className="col s12 m12 l12">
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                );
            }

            const isTceManager = roleNames.includes(ROLE_NAMES.STAFF_ADMIN) || roleNames.includes(ROLE_NAMES.STAFF_OPERATIONAL_MANAGER);

            // only process opening requests
            if (approvalDetail.status !== ORDER_REQUEST_APPROVE_STATUS.OPEN) {
                return (
                    <div className="col s12 m12 l12">
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                );
            }

            // Only Tce Manager can approve/decline request
            if (!isTceManager) {
                return (
                    <div className="col s12 m12 l12">
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                );
            }

            // admin/manager has permission to approve the request
            return (
                <div className="row m-0">
                    <div className="col s4 m4 l4">
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                    <div className="col s4 m4 l4">
                        <button className="btn error-color w-100" onClick={() => { this.processRequestedFee(false); }}>Decline</button>
                    </div>
                    <div className="col s4 m4 l4">
                        <button className="btn success-color w-100" onClick={() => { this.processRequestedFee(true); }}>Approve</button>
                    </div>
                </div>
            );
        }

        return (
            <div>
                <Modal onClickClose={() => { this.handleCloseForm(); }} isOpen={approvalModal.isShowForm} addClass="modal-approval">
                    <ModalBody>
                        <ModalTitle onClickClose={() => this.handleCloseForm()}>{"Fee Approval Request Details"}</ModalTitle>
                        <div className="tab-content">
                            <div className="row">
                                <div className="input-field col s12 m12 l6">
                                    <b>Order ID: <span className="right">{approvalDetail.orderId}</span></b>
                                </div>
                                <div className="input-field col s12 m12 l6">
                                    <b>Fee Approval Status: <span className="right">{approvalDetail.status}</span></b>
                                </div>
                            </div>

                            <div className="row">
                                <div className="input-field col s12 m12 l6">
                                    <b>Client Name: <span className="right">{approvalDetail.clientCompanyName}</span></b>
                                </div>
                                <div className="input-field col s12 m12 l6">
                                    <b>Vendor Fee: <span className="right">${thousandSep(parseFloat(approvalDetail.currentVendorFee || 0).toFixed(2))}</span></b>
                                </div>
                            </div>

                            <div className="row">
                                <div className="input-field col s12 m12 l6">
                                    <b>Original Client Fee: <span className="right">${thousandSep(parseFloat(approvalDetail.originalClientFee || 0).toFixed(2))}</span></b>
                                </div>
                                <div className="input-field col s12 m12 l6">
                                    <b>Requested Client Fee: <span className="right">${thousandSep(parseFloat(approvalDetail.proposedClientFee || 0).toFixed(2))}</span></b>
                                </div>
                            </div>

                            <div className="row">
                                <div className="input-field col s12 m12 l6">
                                    <b>Requested By: <span className="right">{approvalDetail.requestedBy}</span></b>
                                </div>
                            </div>

                            {/* Description/Comment */}
                            {this.renderCommentModule()}

                        </div>
                    </ModalBody>
                    <ModalFooter>
                        {renderButton()}
                    </ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

ApprovalClientFeeModal.propTypes = {
    dispatch: PropTypes.func,
    onCloseModal: PropTypes.func,
    saveChanges: PropTypes.func,
    approvalModal: PropTypes.object,
    profile: PropTypes.object,
    roleType: PropTypes.string,
    roleNames: PropTypes.array
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { role } = authentication;

    return {
        roleType: role.roleType,
        roleNames: role.roleNames
    };
};

export default connect(mapStateToProps)(ApprovalClientFeeModal);