import React from "react";
import { connect } from "react-redux";
import { Component } from "react";
import PropTypes from "prop-types";
import { Modal, ModalBody, ModalFooter, ModalTitle } from "Modal";
import { showSuccess, showError } from "../../main-layout/actions";
import CommonModal from "CommonModal";
import { apiAddComment, getCommentByType } from "Api/comment-api";
import { apiAddNewOrderProgress } from "Api/order-progress-api";
import moment from "moment";
import { COMMENT_TYPE, ORDER_REQUEST_APPROVE_STATUS, USER_TYPE } from "Constants";
import { receiveApprovalDetail } from "../actions/approval-actions";
import { thousandSep } from "Helpers/common-helper";
import { emitRequestCountFeeVendorRequest } from "../../../socket/users";
import noAvatarImg from "./../../../public/images/no-avatar.png";
import { ROLE_NAMES } from "../../../constant/role-constants";
import { apiCheckVendorAssignConditionsOfOrder, apiApproveFeeRequest, apiSubmitFeeRequestToMgr } from "Api/order-request-approval-api";
import { ACTION } from "../../../constant/progress-log-constants";
import { apiFeeRequestSendEmailToManager } from "Api/order-fee-approve-api";
import { handleApiError } from "ErrorHandler";


export class ApprovalFeeModal extends Component {

    constructor(props) {
        super(props);
        this.state = {
            disabled: true
        };
    }

    handleCloseForm() {
        this.props.onCloseModal(false);
        this.refs.addComment.value = "";
        this.setState({ disabled: true });
    }

    addComment() {
        const { dispatch, approvalModal, profile } = this.props;
        const comment = {
            Description: this.refs.addComment.value,
            CreatedBy: profile.userId,
            TypeID: COMMENT_TYPE.RequestFeeCommentType,
            OwnerID: approvalModal.approvalDetail.approvalId,
            ParentID: null,
            CreatedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        };
        apiAddComment(comment, (response) => {
            if (response.data.isSuccess) {
                const filter = {
                    typeId: COMMENT_TYPE.RequestFeeCommentType,
                    ownerId: approvalModal.approvalDetail.approvalId
                };
                getCommentByType(filter, (result) => {
                    const comments = result.data ? result.data : "";

                    dispatch(receiveApprovalDetail({ ...approvalModal, comments }));
                });
                this.refs.addComment.value = "";
                this.setState({ disabled: true });
            }
        });
    }

    handleKeyPress(e) {
        if (e.key === "Enter") {
            this.addComment();
        }
    }

    processFeeRequest(isApprove) {
        const { approvalModal, profile, dispatch } = this.props;
        const { approvalDetail } = approvalModal;

        const approvalData = {
            feeApprovalId: approvalDetail.approvalId,
            orderId: approvalDetail.orderId,
            signerId: approvalDetail.signerId,
            usersId: profile.userId,
            isApprove,
            feeApprovalDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            requestAmount: approvalDetail.proposedVendorFee,
            originalAmount: approvalDetail.originalVendorFee,
            feeDescripId: approvalDetail.feeDescripId,
            activity: `${profile.userName} ${isApprove ? `approved` : `declined`} the fee request for this order.`,
            progressType: ACTION,
            offerId: approvalDetail.offerId,
            signerFee: approvalDetail.feeAmount,
            reason: approvalDetail.reason,
            requestedBy: approvalDetail.usersId,
            requestedByVendor: approvalDetail.userType === USER_TYPE.Vendor,
            isSelfService: approvalDetail.isSelfService === "Y",
            vendorName: approvalDetail.vendorName
        };

        const updateFeeRequest = () => {
            apiApproveFeeRequest(approvalData, () => {
                this.props.onCloseModal(true);
                this.showMessageSuccess(isApprove);

            }, (error) => {
                if (error.response !== undefined) {
                    if (error.response.data.message === "No Rows Updated") {
                        dispatch(showError("Save conflict!"));
                    } else {
                        dispatch(showError(error.response.data.message));
                    }
                } else {
                    dispatch(showError(`Unable to connect ${error.config.url}`));
                }
                this.props.onCloseModal(true);
            });

            emitRequestCountFeeVendorRequest(profile.userId);
        };


        if (isApprove) {
            this.commonModal.showModal({
                type: "confirm",
                message: "Approving this fee request means all other fee requests for this order will be rejected. Are you sure you would like to approve this fee request?"
            }, () => {
                updateFeeRequest();
            });
        } else {
            updateFeeRequest();
        }
    }

    showMessageSuccess(isApprove) {
        const { dispatch } = this.props;
        if (isApprove) {
            dispatch(showSuccess("Approved Successfully"));
        } else {
            dispatch(showSuccess("This request has been rejected"));
        }
    }

    handleApprove() {
        const { dispatch, approvalModal, profile, roleType } = this.props;
        const { approvalDetail } = approvalModal;

        // trigger to re-count pending requests
        let brokerId = 0;
        if (roleType === USER_TYPE.Staff) {
            brokerId = 0;
        } else {
            brokerId = profile.id;
        }

        const checkData = {
            orderId: approvalDetail.orderId,
            signerId: approvalDetail.signerId
        };

        apiCheckVendorAssignConditionsOfOrder(checkData, (result) => {
            switch (result.data.case) {
                case "SUCCESS": {
                    this.processFeeRequest(true);
                    break;
                }
                case "SIGNER_ALREADY": {
                    this.commonModal.showModal({
                        type: "confirm",
                        message: "Another Vendor has been assigned to this order. Do you want to replace that Vendor?"
                    }, () => {
                        this.processFeeRequest(true);
                    }, () => {
                        this.processFeeRequest(false);
                    });
                    break;
                }
                case "ADT_DUPLICATED": {
                    dispatch(showError("This Vendor has already assigned to another order having the same Appointment Date time.", () => {
                        this.processFeeRequest(false);
                    }));
                    break;
                }
                case "CLOSED_ORDER": {
                    dispatch(showError("This Order has already closed", () => {
                        this.processFeeRequest(false);
                    }));
                    break;
                }
            }

            emitRequestCountFeeVendorRequest(profile.userId);
        }, (error) => handleApiError(dispatch, error));
    }

    handleSubmitToMgr() {
        const { approvalModal, profile, dispatch, roleType } = this.props;
        const { approvalDetail } = approvalModal;

        // trigger to re-count pending requests
        let brokerId = 0;
        if (roleType === USER_TYPE.Staff) {
            brokerId = 0;
        } else {
            brokerId = profile.id;
        }

        const requestData = {
            feeApprovalId: approvalDetail.approvalId,
            usersId: profile.userId
        };
        const mailData = {
            orderId: approvalDetail.orderId,
            expectedFee: approvalDetail.proposedVendorFee,
            originalFee: approvalDetail.originalVendorFee,
            reason: approvalDetail.reason,
            vendorName: approvalDetail.vendorName,
            userId: profile.userId,
            isClientFee: false
        };

        const log = {
            OrderId: approvalDetail.orderId,
            Activity: `${profile.userName} submitted a vendor fee request for this order.`,
            UsersId: profile.userId,
            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            ProgressType: ACTION
        };

        apiSubmitFeeRequestToMgr(requestData, () => {
            this.props.onCloseModal(true);
            apiAddNewOrderProgress(log,
                () => {

                },
                (error) => handleApiError(error)
            );
            dispatch(showSuccess("Submit Successfully"));
            apiFeeRequestSendEmailToManager(mailData);
            emitRequestCountFeeVendorRequest(profile.userId);
        }, (error) => handleApiError(dispatch, error));

    }

    renderComment() {
        const { profile, approvalModal } = this.props;
        const { comments } = approvalModal;

        if (comments !== undefined) {
            if (comments.length > 0) {
                return (
                    <div>
                        <ol id="notePanel" className="notelist" style={{ maxHeight: "500px", overflowY: "scroll" }}>
                            {comments.map((item, index) => {
                                if (item.usersId !== profile.userId) {
                                    return (
                                        <li className="your-note" key={index} style={{ marginBottom: "25px" }} >
                                            <div className="avt-note">
                                                <img alt="" title={item.UserName} className="responsive-img circle" src={(item.img === "" || item.img === undefined || item.img === null) ? noAvatarImg : item.img} />
                                            </div>
                                            <div className="chat-content" >
                                                <p style={{ wordBreak: "break-word" }}>{item.Description}</p>
                                                <small>{moment(item.createdDate).format("MMM D YYYY [at] h:mm A")}</small>
                                            </div>
                                        </li>
                                    );
                                }
                                return (
                                    <li className="other-note" key={index} style={{ marginBottom: "25px" }}>
                                        <div className="chat-content">
                                            <p style={{ wordBreak: "break-word" }}>{item.Description}</p>
                                            <div className="avt-note">
                                                <img alt="" title={profile.userName} className="responsive-img circle" src={(item.img === "" || item.img === undefined) ? noAvatarImg : item.img} />
                                            </div>
                                            <small>{moment(item.createdDate).format("MMM D YYYY [at] h:mm A")}</small>
                                        </div>
                                    </li>
                                );
                            })}
                        </ol>
                    </div>
                );
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    renderCommentModule() {
        return (
            <div style={{ borderWidth: "1px", borderRadius: "10px", borderStyle: "solid", margin: "20px 20px 0 20px", padding: "0 20px 0 20px", borderColor: "#e0e0e0" }}>
                <div className="valign-wrapper">
                    <p>Description</p>
                </div>
                <div className="divider" style={{ marginBottom: "20px" }}></div>
                <div>
                    {this.renderComment()}
                </div>
                <div className="row">
                    <div className="input-field col s12 m12">
                        <br />
                        <input id="addComment"
                            maxLength="250"
                            type="text"
                            ref="addComment"
                            className="validate"
                            onChange={() => this.setState({ ...this.state, disabled: this.refs.addComment.value === "" ? true : false })}
                            onKeyPress={(e) => this.handleKeyPress(e)}
                        />
                        <label htmlFor="addComment">Add comment</label>
                    </div>
                </div>
                <div className="row">
                    <div className="right input-field">
                        {/* <button type="button" className="btn white action-btn" disabled={this.state.disabled} onClick={() => this.handleResetComment()}>RESET</button> */}
                        <button
                            onClick={() => this.addComment()} className="btn btn-primary action-btn"
                            disabled={this.state.disabled}
                        >ENTER</button>
                    </div>
                </div>
            </div>
        );
    }

    handleResetComment() {
        this.refs.addComment.value = "";
        this.setState({
            disabled: true
        });
    }

    render() {
        const { approvalModal, roleType, roleNames, profile } = this.props;
        const { approvalDetail } = approvalModal;

        let isStaff = false;

        if (roleType === USER_TYPE.Staff) {
            isStaff = true;
        }

        const renderButtonForStaff = () => {
            if (!approvalDetail) {
                return (
                    <div className="col s12 m12 l12">
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                );
            }

            const isScheduler = roleNames.includes(ROLE_NAMES.STAFF_SCHEDULER);
            const isStatusRep = roleNames.includes(ROLE_NAMES.STAFF_STATUS_REP);
            const isQualityControl = roleNames.includes(ROLE_NAMES.STAFF_QUALITY_CONTROL);
            const isTceManager = roleNames.includes(ROLE_NAMES.STAFF_ADMIN) || roleNames.includes(ROLE_NAMES.STAFF_OPERATIONAL_MANAGER);

            // has no permission
            if (!isScheduler && !isStatusRep && !isQualityControl && !isTceManager) {
                return (
                    <div className="col s12 m12 l12">
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                );
            }

            // submit by himself
            if (profile.id === approvalDetail.userId) {
                return (
                    <div className="col s12 m12 l12">
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                );
            }

            // only process opening requests
            if (approvalDetail.status !== ORDER_REQUEST_APPROVE_STATUS.OPEN) {
                return (
                    <div className="col s12 m12 l12">
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                );
            }

            // admin/manager has permission to approve the request
            if (isTceManager) {
                return (
                    <div className="row m-0">
                        <div className="col s4 m4 l4">
                            <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                        </div>
                        <div className="col s4 m4 l4">
                            <button className="btn error-color w-100" onClick={() => { this.processFeeRequest(false); }}>Decline</button>
                        </div>
                        <div className="col s4 m4 l4">
                            <button className="btn success-color w-100" onClick={() => { this.handleApprove(); }}>Approve</button>
                        </div>
                    </div>
                );
            }

            // Tce Scheduler/QC/Status rep can only approve if requested amount is less than 10% original fee
            let allowApprove = approvalDetail.originalVendorFee * 1.1 < approvalDetail.proposedVendorFee;
            let allowSubmitToMgr = !allowApprove && approvalDetail.userType === USER_TYPE.Vendor;
            let columnWidth = 4;

            if (!allowSubmitToMgr && !allowApprove) {
                columnWidth = 6;
            }

            return (
                <div className="row m-0">
                    <div className={`col s${columnWidth} m${columnWidth} l${columnWidth}`}>
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                    <div className={`col s${columnWidth} m${columnWidth} l${columnWidth}`}>>
                        <button className="btn error-color w-100" onClick={() => { this.processFeeRequest(false); }}>Decline</button>
                    </div>
                    {allowApprove &&
                        <div className="col s4 m4 l4">
                            <button className="btn success-color w-100" onClick={() => { this.handleApprove(); }}>Approve</button>
                        </div>}
                    {allowSubmitToMgr &&
                        <div className="col s4 m4 l4">
                            <button className="btn success-color w-100" onClick={() => { this.handleSubmitToMgr(); }}>Submit to Mgr</button>
                        </div>}
                    }
                </div>
            );
        }

        const renderForStaff = () => {
            if (!approvalDetail) {
                return (<div></div>);
            }

            return (
                <div>
                    <Modal onClickClose={() => { this.handleCloseForm(); }} isOpen={approvalModal.isShowForm} addClass="modal-approval">
                        <ModalBody>
                            <ModalTitle onClickClose={() => this.handleCloseForm()}>{"Fee Approval Request Details"}</ModalTitle>
                            <div className="tab-content">
                                <div className="row">
                                    <div className="input-field col s12 m12 l6">
                                        <b>Order ID: <span className="right">{approvalDetail.orderId}</span></b>
                                    </div>
                                    <div className="input-field col s12 m12 l6">
                                        <b>Fee Approval Status: <span className="right">{approvalDetail.status}</span></b>
                                    </div>
                                </div>

                                <div className="row">
                                    <div className="input-field col s12 m12 l6">
                                        <b>Vendor Name: <span className="right">{approvalDetail.vendorName}</span></b>
                                    </div>
                                    <div className="input-field col s12 m12 l6">
                                        <b>Client Fee: <span className="right">${thousandSep(parseFloat(approvalDetail.currentClientFee || 0).toFixed(2))}</span></b>
                                    </div>
                                </div>

                                <div className="row">
                                    <div className="input-field col s12 m12 l6">
                                        <b>Original Fee To Vendor: <span className="right">${thousandSep(parseFloat(approvalDetail.originalVendorFee || 0).toFixed(2))}</span></b>
                                    </div>
                                    <div className="input-field col s12 m12 l6">
                                        <b>Requested Fee To Vendor: <span className="right">${thousandSep(parseFloat(approvalDetail.proposedVendorFee || 0).toFixed(2))}</span></b>
                                    </div>
                                </div>

                                <div className="row">
                                    <div className="input-field col s12 m12 l6">
                                        <b>Status Reason: <span className="right">{approvalDetail.reason}</span></b>
                                    </div>
                                    <div className="input-field col s12 m12 l6">
                                        <b>Requested By: <span className="right">{approvalDetail.requestedBy}</span></b>
                                    </div>
                                </div>

                                {/* Description/Comment */}
                                {this.renderCommentModule()}

                            </div>
                        </ModalBody>
                        <ModalFooter>
                            {renderButtonForStaff()}
                        </ModalFooter>
                    </Modal>
                    <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
                </div>
            );
        }

        if (isStaff) {
            return (<div>
                {renderForStaff()}
            </div>
            );
        }

        const renderButtonForClient = () => {
            if (!approvalDetail) {
                return (
                    <div className="col s12 m12 l12">
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                );
            }

            // only process opening requests
            if (approvalDetail.status !== ORDER_REQUEST_APPROVE_STATUS.OPEN) {
                return (
                    <div className="col s12 m12 l12">
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                );
            }

            const allowToApprove = roleNames.includes(ROLE_NAMES.CLIENT_ADMIN) || roleNames.includes(ROLE_NAMES.CLIENT_MANAGER);

            // has no permission
            if (!allowToApprove) {
                return (
                    <div className="col s12 m12 l12">
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                );
            }

            // Client admin/manager has permission to approve the request
            return (
                <div className="row m-0">
                    <div className="col s4 m4 l4">
                        <button className="btn white w-100" onClick={() => this.handleCloseForm()}>Close</button>
                    </div>
                    <div className="col s4 m4 l4">
                        <button className="btn error-color w-100" onClick={() => { this.processFeeRequest(false); }}>Decline</button>
                    </div>
                    <div className="col s4 m4 l4">
                        <button className="btn success-color w-100" onClick={() => { this.handleApprove(); }}>Approve</button>
                    </div>
                </div>
            );
        }

        // for Client
        return (
            <div>
                <Modal onClickClose={() => { this.handleCloseForm(); }} isOpen={approvalModal.isShowForm} addClass="modal-approval">
                    <ModalBody>
                        <ModalTitle onClickClose={() => this.handleCloseForm()}>{"Fee Approval Request Details"}</ModalTitle>
                        <div className="tab-content">
                            <div className="row">
                                <div className="input-field col s12 m12 l6">
                                    <b>Order ID: <span className="right">{approvalDetail.orderId}</span></b>
                                </div>
                                <div className="input-field col s12 m12 l6">
                                    <b>Fee Approval Status: <span className="right">{approvalDetail.status}</span></b>
                                </div>
                            </div>

                            <div className="row">
                                <div className="input-field col s12 m12 l6">
                                    <b>Original Fee to Vendor:</b> <span className="right">${thousandSep(parseFloat(approvalDetail.originalVendorFee || 0).toFixed(2))}</span>
                                </div>
                                <div className="input-field col s12 m12 l6">
                                    <b>Requested Fee to Vendor:</b> <span className="right">${thousandSep(parseFloat(approvalDetail.proposedVendorFee || 0).toFixed(2))}</span>
                                </div>
                            </div>

                            <div className="row">
                                <div className="input-field col s12 m12 l6">
                                    <b>Status Reason: </b> <span className="right">{approvalDetail.reason}</span>
                                </div>
                                <div className="input-field col s12 m12 l6">
                                    <b>Vendor Name:</b> <span className="right">{approvalDetail.vendorName}</span>
                                </div>
                            </div>

                            {/* Description/Comment */}
                            {this.renderCommentModule()}
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        {renderButtonForClient()}
                    </ModalFooter>
                </Modal>
                <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
            </div>
        );
    }
}

ApprovalFeeModal.propTypes = {
    dispatch: PropTypes.func,
    onCloseModal: PropTypes.func,
    saveChanges: PropTypes.func,
    approvalModal: PropTypes.object,
    profile: PropTypes.object,
    roleType: PropTypes.string,
    roleNames: PropTypes.array
};

const mapStateToProps = (state) => {
    const { authentication } = state;
    const { role } = authentication;

    return {
        roleType: role.roleType,
        roleNames: role.roleNames
    };
};

export default connect(mapStateToProps)(ApprovalFeeModal);