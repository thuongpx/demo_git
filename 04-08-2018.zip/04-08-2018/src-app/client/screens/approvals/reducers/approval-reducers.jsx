import { APPROVALS_SEARCH_RECEIVE, APPROVALS_SET_FILTER, APPROVALS_SET_MODAL, APPROVALS_DETAIL } from "./../actions/approval-actions";

export default function ApprovalReducer(state = {
    isFetching: false,
    listApproval: {},
    filter: {
        sortColumn: "date",
        sortDirection: false,
        page: 1,
        itemPerPage: 25,
        orderId: "",
        status: "",
        requestedBy: ""
    },
    approvalModal: {
        approvalDetail: {}
    }
}, action) {
    switch (action.type) {
        case APPROVALS_SET_FILTER:
            return {
                ...state,
                filter: action.filter
            };
        case APPROVALS_SEARCH_RECEIVE:
            return {
                ...state,
                isFetching: false,
                listApproval: action.listApproval
            };
        case APPROVALS_SET_MODAL:
            return {
                ...state,
                isFetching: false,
                approvalModal: action.approvalModal
            };
        case APPROVALS_DETAIL:
            return {
                ...state,
                isFetching: false,
                approvalModal: action.approvalModal
            };
        default:
            return state;
    }
}