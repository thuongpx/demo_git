import { combineReducers } from "redux";
import agentProfilesReducers from "./agent-profiles";
import { CLEAR_AGENT_PROFILES_SETTINGS_REDUCERS } from "../actions/agent-profiles";

const reducers = combineReducers({
    agentProfilesReducers
});

const agentProfileCombinedReducers = (state, action) => {
    switch (action.type) {
        case CLEAR_AGENT_PROFILES_SETTINGS_REDUCERS:
            return reducers({}, action);
        default:
            return reducers(state, action);
    }
};

export default agentProfileCombinedReducers;
