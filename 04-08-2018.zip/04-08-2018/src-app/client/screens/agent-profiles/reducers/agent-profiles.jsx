import { AGENT_PROFILES_REQUEST, AGENT_PROFILES_RECEIVE } from "../actions/agent-profiles";

export default function agentProfilesReducers(state = {
    isFetching: false,
    agentProfiles: {}
}, action) {
    switch (action.type) {
        case AGENT_PROFILES_REQUEST: {
            return {
                ...state,
                isFetching: action.isFetching
            };
        }
        case AGENT_PROFILES_RECEIVE: {
            if (action.data === undefined || action.data === null) {
                return {
                    ...state,
                    agentProfiles: null
                };
            }

            return {
                ...state,
                agentProfiles: {
                    agentId: action.data.AgentId,
                    firstName: action.data.FirstName,
                    lastName: action.data.LastName,
                    email: action.data.Email,
                    phone: action.data.Direct,
                    ext: action.data.Ext,
                    afterhoursPhone: action.data.AfterhoursPhone,
                    fax: action.data.Fax,
                    company: action.data.Company
                }
            };
        }
        default:
            return state;
    }
}