import React from "react";
import PropTypes from "prop-types";
import InputMask from "react-input-mask";
import { Component } from "react";
import { convertToPhoneNumber, convert2PhoneWithFormat, hasStringValue, toSafeString } from "Helpers/common-helper";
import NumbericInput from "NumbericInput";
import { getValidationCssClass, validationMessage } from "Helpers/validation-helper";
import { updateTextFields } from "Helpers/theme-helper";

class AgentInformation extends Component {

    componentDidMount() {
        this.refs.firstName.focus();
    }

    componentDidUpdate() {
        // binding default data
        const { agentInfo } = this.props;

        this.refs.firstName.value = agentInfo.firstName.value;
        this.refs.lastName.value = agentInfo.lastName.value;
        this.refs.email.value = agentInfo.email.value;
        this.refs.phone.value = convert2PhoneWithFormat(toSafeString(agentInfo.phone.value));
        this.refs.phone.input.value = convert2PhoneWithFormat(toSafeString(agentInfo.phone.value));
        this.refs.ext.value = agentInfo.ext.value;
        this.refs.ext.refs.numberic.value = agentInfo.ext.value;
        this.refs.afterhoursPhone.value = convert2PhoneWithFormat(toSafeString(agentInfo.afterhoursPhone.value));
        this.refs.afterhoursPhone.input.value = convert2PhoneWithFormat(toSafeString(agentInfo.afterhoursPhone.value));
        this.refs.fax.value = convert2PhoneWithFormat(toSafeString(agentInfo.fax.value));
        this.refs.fax.input.value = convert2PhoneWithFormat(toSafeString(agentInfo.fax.value));
        this.refs.company.value = agentInfo.company.value;

        // fix materialize
        updateTextFields();
    }

    render() {
        const { onInputBlur, agentInfo } = this.props;

        return (
            <div className="">
                <div className="row">
                    <div className="col s6">
                        <div className={`input-field col s6 required suffixinput ${getValidationCssClass(agentInfo.firstName.message)}`}>
                            <input id="firstName" maxLength="150" type="text" ref="firstName"
                                onBlur={(e) => onInputBlur({ firstName: { value: e.target.value, isDirty: true, message: "" } })}
                            />
                            <label htmlFor="firstName">First Name</label>
                            {hasStringValue(agentInfo.firstName.message) && validationMessage(agentInfo.firstName.message, "firstName", 0)}
                        </div>
                        <div className={`input-field col s6 required suffixinput ${getValidationCssClass(agentInfo.lastName.message)}`}>
                            <input id="lastName" maxLength="150" type="text" ref="lastName"
                                onBlur={(e) => onInputBlur({ lastName: { value: e.target.value, isDirty: true, message: "" } })}
                            />
                            <label htmlFor="lastName">Last Name</label>
                            {hasStringValue(agentInfo.lastName.message) && validationMessage(agentInfo.lastName.message, "lastName", 0)}
                        </div>
                    </div>
                    <div className="col s6">
                        <div className={`input-field col s12 required suffixinput ${getValidationCssClass(agentInfo.email.message)}`}>
                            <input id="email" maxLength="70" type="text" ref="email"
                                onBlur={(e) => onInputBlur({ email: { value: e.target.value, isDirty: true, message: "" } })}
                            />
                            <label htmlFor="email">Email</label>
                            {hasStringValue(agentInfo.email.message) && validationMessage(agentInfo.email.message, "email", 0)}
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col s6">
                        <div className={`input-field col s12 required suffixinput ${getValidationCssClass(agentInfo.phone.message)}`}>
                            <InputMask
                                type="text"
                                id="phone"
                                className="form-control"
                                ref="phone"
                                mask="(999) 999-9999"
                                placeholder="(###) ###-####"
                                onBlur={(e) => onInputBlur({ phone: { value: convertToPhoneNumber(e.target.value), isDirty: true, message: "" } })}
                            />
                            <label htmlFor="phone">Phone #</label>
                            {hasStringValue(agentInfo.phone.message) && validationMessage(agentInfo.phone.message, "phone", 0)}
                        </div>
                    </div>
                    <div className="col s6">
                        <div className="input-field col s12 suffixinput">
                            <NumbericInput id="ext" maxLength="5" ref="ext" className="form-control"
                                onBlur={(value) => onInputBlur({ ext: { value, isDirty: true, message: "" } })}
                            />
                            <label htmlFor="ext">Phone Ext</label>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col s6">
                        <div className={`input-field col s12 suffixinput ${getValidationCssClass(agentInfo.afterhoursPhone.message)}`}>
                            <InputMask
                                type="text"
                                id="afterhoursPhone"
                                className="form-control"
                                ref="afterhoursPhone"
                                mask="(999) 999-9999"
                                placeholder="(###) ###-####"
                                onBlur={(e) => onInputBlur({ afterhoursPhone: { value: convertToPhoneNumber(e.target.value), isDirty: true, message: "" } })}
                            />
                            <label htmlFor="afterhoursPhone">After Hours Phone #</label>
                            {hasStringValue(agentInfo.afterhoursPhone.message) && validationMessage(agentInfo.afterhoursPhone.message, "afterhoursPhone", 0)}
                        </div>
                    </div>
                    <div className="col s6">
                        <div className={`input-field col s12 suffixinput ${getValidationCssClass(agentInfo.fax.message)}`}>
                            <InputMask
                                type="text"
                                id="fax"
                                className="form-control"
                                ref="fax"
                                mask="(999) 999-9999"
                                placeholder="(###) ###-####"
                                onBlur={(e) => onInputBlur({ fax: { value: convertToPhoneNumber(e.target.value), isDirty: true, message: "" } })}
                            />
                            <label htmlFor="fax">Fax Number</label>
                            {hasStringValue(agentInfo.fax.message) && validationMessage(agentInfo.fax.message, "fax", 0)}
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col s6">
                        <div className="input-field col s12 suffixinput">
                            <input id="company" type="text" className="form-control" ref="company" disabled />
                            <label htmlFor="company">Division/ Branch</label>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

AgentInformation.propTypes = {
    agentInfo: PropTypes.object,
    onInputBlur: PropTypes.func
};

export default AgentInformation;