import { showSuccess } from "../../main-layout/actions";
import { SUCCESSFULLY_SAVED_MESSAGE } from "Constants";

import { handleApiError } from "ErrorHandler";

export const AGENT_PROFILES_REQUEST = "AGENT_PROFILES_REQUEST";
export const AGENT_PROFILES_RECEIVE = "AGENT_PROFILES_RECEIVE";
export const BEGIN_UPDATING_AGENT_PROFILES = "BEGIN_UPDATING_AGENT_PROFILES";
export const END_UPDATING_AGENT_PROFILES = "END_UPDATING_AGENT_PROFILES";
import { apiGetAgent, apiUpdateAgent } from "Api/agent-api";

export const requestAgentProfiles = () => {
    return {
        type: AGENT_PROFILES_REQUEST,
        isFetching: true
    };
};

export const receiveAgentProfiles = (data) => {
    return {
        type: AGENT_PROFILES_RECEIVE,
        isFetching: false,
        data
    };
};

export const getAgentProfilesData = (agentId) => {
    return dispatch => {
        dispatch(requestAgentProfiles());
        return apiGetAgent(agentId,
            (result) => {
                // success
                dispatch(receiveAgentProfiles(result.data));
            }, (error) => handleApiError(dispatch, error));
    };
};

export const beginUpdatingAgentProfiles = () => {
    return {
        type: BEGIN_UPDATING_AGENT_PROFILES,
        isFetching: true
    };
};

export const endUpdatingAgentProfiles = () => {
    return {
        type: END_UPDATING_AGENT_PROFILES,
        isFetching: false
    };
};


export const updateAgentProfiles = (payload, showMessage) => {
    return dispatch => {
        dispatch(beginUpdatingAgentProfiles());
        return apiUpdateAgent(payload.agentInfo,
            () => {
                // success
                dispatch(endUpdatingAgentProfiles());
                if (showMessage) {
                    dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
                }
            }, (error) => handleApiError(dispatch, error));
    };
};