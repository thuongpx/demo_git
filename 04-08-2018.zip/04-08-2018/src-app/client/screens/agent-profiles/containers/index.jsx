import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import AgentProfile from "./agent-profiles";
import ClientProfileCredentials from "Screens/client-profiles/containers/client-credentials";
import CommonModal from "CommonModal";
import { CLIENT_SUB_ROLE } from "Constants";

class AgentProfileContainer extends Component {
    constructor(props) {
        super(props);

        const tabs = [
            { title: "Profile", isActive: true },
            { title: "Credentials", isActive: false }
        ];

        // set to state
        this.state = {
            tabs
        };

        this.handleTabClick = this.handleTabClick.bind(this);
    }

    handleTabClick(tab) {
        const tabs = this.state.tabs;

        //validate current form
        for (const index in tabs) {
            const item = tabs[index];
            if (item.isActive && item.title !== tab.title) {
                let validateForm = true;
                switch (item.title) {
                    case "Profile":
                        validateForm = this.agentProfile.validateForm();
                        if (validateForm) {
                            this.agentProfile.saveChanges(false, () => this.setActiveTab(tab));
                        }
                        break;
                    case "Credentials":
                        validateForm = this.clientProfileCredentials.validateForm();
                        if (validateForm) {
                            this.clientProfileCredentials.saveChanges(false, () => this.setActiveTab(tab));
                        }
                        break;
                    default:
                        break;
                }

                if (!validateForm) {
                    return;
                }
            }
        }

        this.setActiveTab(tab);

    }

    setActiveTab(tab) {
        const tabs = this.state.tabs;
        tabs.map(item => {
            if (item.title === tab.title) {
                item.isActive = true;
            } else item.isActive = false;
            return item;
        });

        this.setState({ tabs });
    }

    handleSaveChanges() {
        const tabs = this.state.tabs;

        tabs.map(item => {
            if (item.isActive) {
                switch (item.title) {
                    case "Profile":
                        this.agentProfile.saveChanges(true);
                        break;
                    case "Credentials":
                        this.clientProfileCredentials.saveChanges(true);
                        break;
                    default:
                        break;
                }
            }
        });
    }

    handleCancelUpdating() {
        this.commonModal.showModal({
            type: "confirm",
            message: "Are you sure you would like to cancel to update your profile?"
        }, () => {
            // reset data
            const { tabs } = this.state;

            tabs.map(item => {
                if (item.isActive) {
                    switch (item.title) {
                        case "Profile":
                            this.agentProfile.reset();
                            break;
                        case "Credentials":
                            this.clientProfileCredentials.reset();
                            break;
                        default:
                            break;
                    }
                }
            });
        }, () => { });

        return false;
    }

    render() {
        const { agentId, clientType } = this.props;

        const renderTabs = () => {

            return this.state.tabs.map((tab, key) => {
                const classNameActive = tab.isActive ? "active" : "";

                return (
                    <li className="tab col" key={key} onClick={() => this.handleTabClick(tab)}>
                        <a style={{ cursor: "pointer" }} className={classNameActive}>{tab.title}</a>
                    </li>
                );
            });
        };

        const renderTabContent = () => {
            return this.state.tabs.map((tab, key) => {
                if (tab.isActive) {
                    switch (tab.title) {
                        case "Profile":
                            return (
                                <AgentProfile key={key} agentId={agentId}
                                    ref={instance => {
                                        if (instance && instance.getWrappedInstance) {
                                            this.agentProfile = instance.getWrappedInstance();
                                        }
                                    }}
                                />
                            );
                        case "Credentials":
                            return (
                                <ClientProfileCredentials
                                    key={key}
                                    ref={instance => {
                                        if (instance && instance.getWrappedInstance) {
                                            this.clientProfileCredentials = instance.getWrappedInstance();
                                        }
                                    }}
                                />
                            );
                        default:
                            break;
                    }
                }
                return null;
            });
        };

        const renderButtons = (
            <div className="row">
                <div className="col s5">
                    <button className="btn white w-100" onClick={() => this.handleCancelUpdating()}>Cancel</button>
                </div>
                <div className="col s2"></div>
                <div className="col s5">
                    <button className="btn success-color action-btn w-100" onClick={() => this.handleSaveChanges()}>Save</button>
                </div>
            </div>
        );

        const renderPage = () => {
            if (clientType === CLIENT_SUB_ROLE.AGENT) {
                return (
                    <div className="custome-modal">
                        <div className="row">
                            <div>
                                <h3 className="title-page-detail">
                                    Profiles & Settings
                                </h3>
                            </div>
                        </div>
                        <ul className="tabs">
                            {renderTabs()}
                        </ul>
                        <br />
                        <div className="container-fluid">
                            {renderTabContent()}
                        </div>
                        <hr />
                        <div className="center-align">
                            {renderButtons}
                        </div>
                        <CommonModal ref={(commonModal) => { this.commonModal = commonModal; }} />
                    </div >
                );
            } else {
                return null;
            }

        };

        return (
            <div className="container-fluid">
                {renderPage()}
            </div >
        );
    }
}

AgentProfileContainer.propTypes = {
    agentId: PropTypes.number,
    clientType: PropTypes.string
};

export default connect()(AgentProfileContainer);