import React from "react";
import PropTypes from "prop-types";
import { Component } from "react";
import { connect } from "react-redux";
import AgentInformation from "../components/agent-information";
import { getAgentProfilesData, updateAgentProfiles } from "../actions/agent-profiles";
import { hasStringValue, convertToPhoneNumber } from "Helpers/common-helper";
import { requireMessage, invalidMessage, validatePhoneWithoutHyphen, validateEmail } from "Helpers/validation-helper";

class AgentProfile extends Component {
    constructor(props) {
        super(props);

        this.state = {
            inputs: {
                firstName: {},
                lastName: {},
                email: {},
                phone: {},
                ext: {},
                afterhoursPhone: {},
                fax: {},
                company: {}
            }
        };
    }

    componentWillReceiveProps(nextProps) {
        // update to information
        const { agentProfiles } = nextProps;
        const rawInputs = {
            ...this.state.inputs,
            firstName: { value: agentProfiles.firstName },
            lastName: { value: agentProfiles.lastName },
            email: { value: agentProfiles.email },
            phone: { value: agentProfiles.phone },
            ext: { value: agentProfiles.ext },
            afterhoursPhone: { value: agentProfiles.afterhoursPhone },
            fax: { value: agentProfiles.fax },
            company: { value: agentProfiles.company }
        };

        this.setState({
            ...this.state,
            inputs: rawInputs,
            defaultInputs: rawInputs
        });
    }

    componentDidMount() {
        const { agentId } = this.props;

        this.reload(agentId);
    }

    componentWillUpdate(nextProps) {
        if (nextProps.agentId !== this.props.agentId) {
            const { agentId } = nextProps;

            this.reload(agentId);
        }
    }

    reload(agentId) {
        // load all default data from DATABASE
        const { dispatch } = this.props;

        dispatch(getAgentProfilesData(agentId));
    }

    validateInputs(inputs) {
        // required company infor
        const { firstName, lastName, email, phone, afterhoursPhone, fax } = inputs;

        // first name
        firstName.message = hasStringValue(firstName.value) ? "" : requireMessage("First Name");
        // last name
        lastName.message = hasStringValue(lastName.value) ? "" : requireMessage("Last Name");
        // email
        email.message = "";
        if (!hasStringValue(email.value)) {
            email.message = requireMessage("Email");
        }

        if (hasStringValue(email.value) && !validateEmail(email.value)) {
            email.message = invalidMessage("Email");
        }
        // phone #
        phone.message = "";
        if (!hasStringValue(phone.value)) {
            phone.message = requireMessage("Phone #");
        }

        if (hasStringValue(phone.value) && !validatePhoneWithoutHyphen(phone.value)) {
            phone.message = invalidMessage("Phone #");
        }

        // After hours phone #
        afterhoursPhone.message = hasStringValue(afterhoursPhone.value) && !validatePhoneWithoutHyphen(afterhoursPhone.value) ? invalidMessage("After Hours Phone #") : "";
        // fax number
        fax.message = hasStringValue(fax.value) && !validatePhoneWithoutHyphen(fax.value) ? invalidMessage("Fax Number") : "";

        this.setState({
            ...this.state,
            inputs
        });
    }

    handleInputBlur(obj) {
        Object.keys(obj).forEach((item) => {
            const newInput = obj[item];
            const oldInput = this.state.defaultInputs[item];

            obj[item].isDirty = newInput.value !== oldInput.value;
        });

        const inputs = {
            ...this.state.inputs,
            ...obj
        };

        this.validateInputs(inputs);
    }

    validationMessage(message) {
        if (message !== "" && message !== null && message !== undefined) {
            return (
                <span className="text-danger">{message}</span>
            );
        }

        return (<span></span>);
    }

    convertInputToPayLoad() {
        const { agentId } = this.props;
        const { inputs } = this.state;

        // broker infomation
        const agentInfo = {
            AgentId: agentId,
            FirstName: inputs.firstName.value === "" ? null : inputs.firstName.value,
            LastName: inputs.lastName.value === "" ? null : inputs.lastName.value,
            Email: inputs.email.value === "" ? null : inputs.email.value,
            Direct: inputs.phone.value === "" ? null : convertToPhoneNumber(inputs.phone.value),
            Ext: inputs.ext.value === "" ? null : inputs.ext.value,
            AfterhoursPhone: inputs.afterhoursPhone.value === "" ? null : convertToPhoneNumber(inputs.afterhoursPhone.value),
            Fax: inputs.fax.value === "" ? null : convertToPhoneNumber(inputs.fax.value)
        };

        const payload = {
            agentInfo
        };

        return payload;
    }

    hasChanges() {
        const { inputs } = this.state;
        let isDirty = false;

        Object.keys(inputs).forEach((item) => {
            const prop = inputs[item];

            if (prop.isDirty) {
                isDirty = true;
                return;
            }
        });

        return isDirty || this.state.hasChangeReturnAddr || this.state.hasChangeEmail;
    }

    validateForm() {
        // if user not change any thing on the form, do not need to check validation
        if (!this.hasChanges()) return true;

        // check validation
        const { inputs } = this.state;

        let isInvalid = false;

        // validate first
        Object.keys(inputs).forEach((item) => {
            const prop = inputs[item];

            if (prop.message !== undefined && prop.message !== null && prop.message !== "") {
                isInvalid = true;
                return;
            }
        });

        return !isInvalid;
    }

    // save changes
    saveChanges(showMessage = false) {
        // if user not change any thing on the form, do not need to save changes
        if (!this.hasChanges() && !showMessage) return;

        // validate first
        if (this.validateForm()) {
            const { dispatch } = this.props;
            const payload = this.convertInputToPayLoad();
            if (payload !== null) {
                dispatch(updateAgentProfiles(payload, showMessage));
            }
        }
    }

    reset() {
        this.setState({
            ...this.state,
            inputs: this.state.defaultInputs
        });
    }

    render() {
        const { inputs } = this.state;

        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col s12">
                        <div className="row">
                            <p><strong>Agent Information</strong></p>
                        </div>
                        <div className="row">
                            <AgentInformation agentInfo={inputs}
                                validationMessage={(message) => this.validationMessage(message)}
                                onInputBlur={(obj) => this.handleInputBlur(obj)}
                            />
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

AgentProfile.propTypes = {
    dispatch: PropTypes.func,
    agentProfile: PropTypes.object,
    subRoleType: PropTypes.string,
    agentId: PropTypes.number
};

const mapStateToProps = (state) => {
    const { agentProfileCombinedReducers } = state;
    const { agentProfilesReducers } = agentProfileCombinedReducers;
    const { agentProfiles } = agentProfilesReducers;

    return {
        agentProfiles
    };
};

export default connect(mapStateToProps, null, null, { withRef: true })(AgentProfile);