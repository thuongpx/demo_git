import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { addAnswer, checkUserAnswer } from "../actions/challenge-question-action";
import ChallengeQuestion from "../components/challenge-question";
import { requireMessage, invalidMessage, validateSpecialCharacter } from "Helpers/validation-helper";
import { hasStringValue } from "Helpers/common-helper";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { LOGO_2X_IMAGE_URL } from "ImageConfig";
import { removeCookies } from "../../../helpers/cookies-helper";
import { COOKIES_KEY } from "../../../constant/constants";
import { withRouter } from "react-router";
import ChallengeQuestionConfirm from "../components/challenge-question-confirm";
import { getSecQuestions } from "../actions/challenge-question-action";

class ChallengeQuestionManagement extends Component {
    constructor(props) {
        super(props);

        const { location } = this.props;
        const { query } = location;
        const { userId, token } = query;

        this.userId = userId;

        if (!hasStringValue(userId) || !hasStringValue(token) || token !== window._temporaryToken) {
            this.props.router.replace("/");
        }
        removeCookies(COOKIES_KEY.CE_ADDITIONAL_SECURITY_TOKEN);

        this.state = {
            inputs: {
                question1: {},
                question2: {},
                question3: {},
                answer1: {},
                answer2: {},
                answer3: {}
            }
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    componentWillReceiveProps(nextProps) {
        const { question1, question2, question3, answer1, answer2, answer3 } = nextProps;

        const rawInputs = {
            ...this.state.inputs,
            question1: {
                value: question1 || ""
            },
            question2: {
                value: question2 || ""
            },
            question3: {
                value: question3 || ""
            },
            answer1: {
                value: answer1 || ""
            },
            answer2: {
                value: answer2 || ""
            },
            answer3: {
                value: answer3 || ""
            }
        };

        this.setState({
            ...this.state,
            inputs: rawInputs,
            defaultInputs: rawInputs
        });
    }

    handleInputChange(obj) {
        this.setState({
            ...this.state,
            inputs: {
                ...this.state.inputs,
                ...obj
            }
        });
    }

    validateInputs(inputs) {
        const { question1, question2, question3, answer1, answer2, answer3 } = inputs;

        if (question1.value && question2.value) {
            question2.message =
                question2.value === question1.value ?
                    requireMessage("Question 1 and question 2 must be different ") : "";
        }

        if (question1.value && question3.value) {
            question1.message =
                question3.value === question1.value ?
                    requireMessage("Question 1 and question 3 must be different ") : "";
        }

        if (question2.value && question3.value) {
            question3.message =
                question3.value === question2.value ?
                    requireMessage("Question 2 and question 3 must be different ") : "";
        }

        answer1.message = !validateSpecialCharacter(answer1.value) && answer1.isDirty ?
            invalidMessage("answer1") : "";

        answer2.message = !validateSpecialCharacter(answer2.value) && answer2.isDirty ?
            invalidMessage("answer2") : "";

        answer3.message = !validateSpecialCharacter(answer3.value) && answer3.isDirty ?
            invalidMessage("answer3") : "";

        this.setState({
            ...this.state,
            inputs
        });
    }

    validationMessage(message) {
        if (message !== "" && message !== null && message !== undefined) {
            return (
                <span className="text-danger">{message}</span>
            );
        }

        return (<span></span>);
    }

    handleInputBlur(obj) {

        const inputs = {
            ...this.state.inputs,
            ...obj
        };

        this.validateInputs(inputs);
    }

    handleInputValidate() {
        const inputs = this.state.inputs;

        Object.keys(inputs).map((key) => {
            inputs[key].isDirty = true;
        });

        this.validateInputs(inputs);

    }

    hasChanges() {
        const { inputs } = this.state;
        let isDirty = false;

        Object.keys(inputs).forEach((item) => {
            const prop = inputs[item];

            if (prop.isDirty) {
                isDirty = true;
                return;
            }
        });

        return isDirty;
    }

    validateAnswerForm() {
        // if user not change any thing on the form, do not need to check validation
        if (!this.hasChanges()) return true;

        // if user not enter full information, check validation
        this.handleInputValidate();

        // check validation
        const { inputs } = this.state;
        const { currentQuestionNo } = this.props;
        // const { dataChallengeByUserId } = this.props;
        let isInvalid = false;

        if (inputs[`answer${currentQuestionNo}`].isDirty === true && !hasStringValue(inputs[`answer${currentQuestionNo}`].value)) {
            inputs[`answer${currentQuestionNo}`].message = "Please enter the answer";
        }

        Object.keys(inputs).forEach((item) => {
            const prop = inputs[item];

            if (prop.message !== undefined && prop.message !== "") {
                isInvalid = true;
                return;
            }
        });

        return !isInvalid;
    }

    validateForm() {
        // if user not change any thing on the form, do not need to check validation
        if (!this.hasChanges()) return true;

        // if user not enter full information, check validation
        this.handleInputValidate();

        // check validation
        const { inputs } = this.state;
        // const { dataChallengeByUserId } = this.props;
        let isInvalid = false;

        // validate first
        if (inputs.question1.isDirty === true && inputs.question2.isDirty === true && inputs.question3.isDirty === true) {
            if (!hasStringValue(inputs.question1.value) && hasStringValue(inputs.question2.value) && hasStringValue(inputs.question3.value)) {
                inputs.question1.message = "You must select all 3 questions";
            }
            if (!hasStringValue(inputs.question2.value) && hasStringValue(inputs.question1.value) && hasStringValue(inputs.question3.value)) {
                inputs.question2.message = "You must select all 3 questions";
            }
            if (!hasStringValue(inputs.question3.value) && hasStringValue(inputs.question1.value) && hasStringValue(inputs.question2.value)) {
                inputs.question3.message = "You must select all 3 questions";
            }
            //====== validate if only select 1 in 3 question
            if (hasStringValue(inputs.question1.value) && !hasStringValue(inputs.question2.value) && !hasStringValue(inputs.question3.value)) {
                inputs.question1.message = "You must select all 3 questions";
            }
            if (!hasStringValue(inputs.question1.value) && hasStringValue(inputs.question2.value) && !hasStringValue(inputs.question3.value)) {
                inputs.question2.message = "You must select all 3 questions";
            }
            if (!hasStringValue(inputs.question1.value) && !hasStringValue(inputs.question2.value) && hasStringValue(inputs.question3.value)) {
                inputs.question3.message = "You must select all 3 questions";
            }
            //====== validate if select question and not enter answer
            if (hasStringValue(inputs.question1.value) && hasStringValue(inputs.question2.value) && hasStringValue(inputs.question3.value)) {

                if (!hasStringValue(inputs.answer1.value)) {
                    inputs.answer1.message = "Please enter the answer1";
                }
                if (!hasStringValue(inputs.answer2.value)) {
                    inputs.answer2.message = "Please enter the answer2";
                }
                if (!hasStringValue(inputs.answer3.value)) {
                    inputs.answer3.message = "Please enter the answer3";
                }
            }
            //===== validate if enter answer and not select question
            if (hasStringValue(inputs.answer1.value) && hasStringValue(inputs.answer2.value) && hasStringValue(inputs.answer3.value)) {
                if (!hasStringValue(inputs.question1.value)) {
                    inputs.question1.message = "You must select all 3 questions";
                }
                if (!hasStringValue(inputs.question2.value)) {
                    inputs.question2.message = "You must select all 3 questions";
                }
                if (!hasStringValue(inputs.question3.value)) {
                    inputs.question3.message = "You must select all 3 questions";
                }
            }
            //===== validate if not enter 1 in 3 answer
            if (!hasStringValue(inputs.answer1.value) && hasStringValue(inputs.answer2.value) && hasStringValue(inputs.answer3.value)) {
                inputs.answer1.message = "Please enter the answer1";
            }
            if (!hasStringValue(inputs.answer2.value) && hasStringValue(inputs.answer1.value) && hasStringValue(inputs.answer3.value)) {
                inputs.answer2.message = "Please enter the answer2";
            }
            if (!hasStringValue(inputs.answer3.value) && hasStringValue(inputs.answer1.value) && hasStringValue(inputs.answer2.value)) {
                inputs.answer3.message = "Please enter the answer3";
            }
            //====== validate if only enter 1 in 3 answer
            if (hasStringValue(inputs.answer1.value) && !hasStringValue(inputs.answer2.value) && !hasStringValue(inputs.answer3.value)) {
                inputs.answer2.message = "Please enter the answer2";
                inputs.answer3.message = "Please enter the answer3";
            }
            if (!hasStringValue(inputs.answer1.value) && hasStringValue(inputs.answer2.value) && !hasStringValue(inputs.answer3.value)) {
                inputs.answer1.message = "Please enter the answer1";
                inputs.answer3.message = "Please enter the answer3";
            }
            if (!hasStringValue(inputs.answer1.value) && !hasStringValue(inputs.answer2.value) && hasStringValue(inputs.answer3.value)) {
                inputs.answer1.message = "Please enter the answer1";
                inputs.answer2.message = "Please enter the answer2";
            }
        }

        if (!hasStringValue(inputs.question1.value) && !hasStringValue(inputs.question2.value) && !hasStringValue(inputs.question3.value) &&
            !hasStringValue(inputs.answer1.value) && !hasStringValue(inputs.answer2.value) && !hasStringValue(inputs.answer3.value)) {
            inputs.question1.message = "Please enter the question1";
            inputs.question2.message = "Please enter the question2";
            inputs.question3.message = "Please enter the question3";
            inputs.answer1.message = "Please enter the answer1";
            inputs.answer2.message = "Please enter the answer2";
            inputs.answer3.message = "Please enter the answer3";
        }

        Object.keys(inputs).forEach((item) => {
            const prop = inputs[item];

            if (prop.message !== undefined && prop.message !== "") {
                isInvalid = true;
                return;
            }
        });
        return !isInvalid;
    }

    handleAnswerChallengeQuestions() {
        const { inputs } = this.state;

        // user is setting challenge questions
        if (this.validateAnswerForm()) {
            const { dispatch, currentQuestionNo, router, failedAttempt, location } = this.props;

            dispatch(checkUserAnswer({
                failedAttempt,
                answerNo: currentQuestionNo,
                answer: inputs[`answer${currentQuestionNo}`].value,
                userId: this.userId
            }, router, location.query.token, this.userId));
        }
    }

    handleSaveChallengeQuestions() {
        const { inputs } = this.state;

        // user is setting challenge questions
        if (this.validateForm()) {
            const { dispatch, router, location } = this.props;

            if (inputs.question1.value !== "" && inputs.question2.value !== "" && inputs.question3.value !== "" &&
                inputs.answer1.value !== "" && inputs.answer2.value !== "" && inputs.answer3.value !== "") {
                const newAnswer = {
                    mappingUserId: this.userId,
                    chalId1: inputs.question1.value,
                    answer1: inputs.answer1.value,
                    chalId2: inputs.question2.value,
                    answer2: inputs.answer2.value,
                    chalId3: inputs.question3.value,
                    answer3: inputs.answer3.value
                };
                dispatch(addAnswer(newAnswer, router, location.query.token, this.userId));
            }
        }
    }

    handleSubmit() {
        const { location } = this.props;

        if (location.query.isNeedConfirm) {
            this.handleAnswerChallengeQuestions();
        } else {
            this.handleSaveChallengeQuestions();
        }
    }

    render() {
        const { inputs } = this.state;
        const { secQuestions, userQuestions, currentQuestionNo, isDone, location, dispatch } = this.props;

        return (
            <div className="login-section">
                <div className="row">
                    <div className="col s12 m6 offset-m3">
                        <img src={LOGO_2X_IMAGE_URL} alt="" className="responsive-img" />
                        {!location.query.isNeedConfirm &&
                            <ChallengeQuestion data={inputs}
                                getSecQuestions={() => dispatch(getSecQuestions(this.userId, false))}
                                secQuestions={secQuestions}
                                onInputBlur={(obj) => this.handleInputBlur(obj)}
                                validationMessage={(message) => this.validationMessage(message)}
                                handleSubmit={() => this.handleSubmit()}
                            />
                        }
                        {location.query.isNeedConfirm &&
                            <ChallengeQuestionConfirm data={inputs}
                                getSecQuestions={() => dispatch(getSecQuestions(this.userId, true))}
                                userQuestions={userQuestions}
                                onInputBlur={(obj) => this.handleInputBlur(obj)}
                                validationMessage={(message) => this.validationMessage(message)}
                                handleSubmit={() => this.handleSubmit(true)}
                                answerNo={currentQuestionNo}
                                isDone={isDone}
                            />
                        }

                    </div>
                </div>
            </div>
        );
    }
}
ChallengeQuestionManagement.propTypes = {
    dispatch: PropTypes.func,
    inputs: PropTypes.object,
    secQuestions: PropTypes.array,
    dataChallengeByUserId: PropTypes.object,
    location: PropTypes.object,
    router: PropTypes.object,
    userQuestions: PropTypes.object,
    currentQuestionNo: PropTypes.number,
    failedAttempt: PropTypes.number,
    isDone: PropTypes.bool
};

const mapStateToProps = (state) => {
    const { challengeQuestionReducer } = state;
    const { secQuestions, dataChallengeByUserId, userQuestions, currentQuestionNo, failedAttempt, isDone } = challengeQuestionReducer;

    return {
        secQuestions,
        dataChallengeByUserId,
        userQuestions,
        currentQuestionNo,
        failedAttempt,
        isDone
    };
};

export default withRouter(connect(mapStateToProps)(ChallengeQuestionManagement));
