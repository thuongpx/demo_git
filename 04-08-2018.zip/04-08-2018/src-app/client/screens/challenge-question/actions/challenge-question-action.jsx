import {
    apiGetSecQuestionsForDropdown, apiAddSecAnswer, apiUpdateSecQuestionAnswers,
    apiGetQuestionAnswerByUserId, apiGetSecQuestionsOfUser, apiCheckUserAnswer
} from "Api/sec-api";
import { handleApiError } from "ErrorHandler";
import { SUCCESSFULLY_SAVED_MESSAGE } from "Constants";
import { showSuccess, showWarning, showError } from "../../main-layout/actions";
import { loginUser } from "../../authentication/actions";
import { hasStringValue } from "../../../helpers/common-helper";
import { COOKIES_KEY } from "../../../constant/constants";
import { setCookies } from "../../../helpers/cookies-helper";

export const SEC_QUESTIONS_REQUEST = "SEC_QUESTIONS_REQUEST";
export const SEC_QUESTIONS_RECEIVE = "SEC_QUESTIONS_RECEIVE";
export const SEC_ANSWERS_REQUEST = "SEC_ANSWERS_REQUEST";
export const SEC_ANSWERS_RECEIVE = "SEC_ANSWERS_RECEIVE";
export const UPDATE_QUESTIONS_ANSWERS_REQUEST = "UPDATE_QUESTIONS_ANSWERS_REQUEST";
export const UPDATE_QUESTIONS_ANSWERS_RECEIVE = "UPDATE_QUESTIONS_ANSWERS_RECEIVE";
export const GET_QUESTIONS_ANSWERS_REQUEST_BY_USERID = "GET_QUESTIONS_ANSWERS_REQUEST_BY_USERID";
export const GET_QUESTIONS_ANSWERS_RECEIVE_BY_USERID = "GET_QUESTIONS_ANSWERS_RECEIVE_BY_USERID";
export const USER_SEC_QUESTIONS_RECEIVE = "USER_SEC_QUESTIONS_RECEIVE";
export const START_CHECK_USER_ANSWER = "START_CHECK_USER_ANSWER";
export const DONE_CHECK_USER_ANSWER = "DONE_CHECK_USER_ANSWER";
export const MOVE_NEXT_CHALLENGE_QUESTION = "MOVE_NEXT_CHALLENGE_QUESTION";

export const requestQuestions = () => {
    return {
        type: SEC_QUESTIONS_REQUEST,
        isFetching: true
    };
};

export const receiveQuestions = (data) => {
    return {
        type: SEC_QUESTIONS_RECEIVE,
        isFetching: false,
        data
    };
};

export const receiveUserQuestions = (data) => {
    return {
        type: USER_SEC_QUESTIONS_RECEIVE,
        isFetching: false,
        data
    };
};

export const startCheckUserAnswer = () => {
    return {
        type: START_CHECK_USER_ANSWER,
        isFetching: true
    };
};

export const moveNextChallengeQuestion = () => {
    return {
        type: MOVE_NEXT_CHALLENGE_QUESTION
    };
};

export const doneCheckUserAnswer = () => {
    return {
        type: DONE_CHECK_USER_ANSWER
    };
};

export const checkUserAnswer = (answer, router, token, userId) => {
    return dispatch => {
        dispatch(startCheckUserAnswer());

        return apiCheckUserAnswer(answer, result => {
            if (!result || !result.data) handleApiError(dispatch);

            if (result.data.isValidAnswer) {
                dispatch(doneCheckUserAnswer());
                setCookies(`${COOKIES_KEY.CE_CHALLENGE_QUESTION_CONFIRMED}-${userId}`, true);
                dispatch(showSuccess("You answered correctly."));
                setTimeout(() => dispatch(loginUser({
                    userId,
                    tempToken: token
                }, router, "/")), 1000);
                return;
            }

            // if user has answered 3 questions and nothing is correct
            // kick him out and announce him to try again
            if (answer.failedAttempt === 4) {
                dispatch(showError("Too many failed attempt. Please try back again"));
                router.replace("/");
            } else {
                dispatch(showWarning("You answered incorrectly. Please try again."));
                dispatch(moveNextChallengeQuestion());
            }
        }, error => handleApiError(dispatch, error));
    };
};

export const getSecQuestions = (userId, isNeedConfirm) => {
    return dispatch => {
        dispatch(requestQuestions());

        if (hasStringValue(userId) && isNeedConfirm) {
            return apiGetSecQuestionsOfUser(userId, (result) => {
                dispatch(receiveUserQuestions(result.data));
            }, (error) => handleApiError(dispatch, error));
        } else {
            return apiGetSecQuestionsForDropdown((result) => {
                dispatch(receiveQuestions(result.data));
            }, (error) => handleApiError(dispatch, error));
        }


    };
};

// action add answer
export const answerAddRequest = () => {
    return {
        type: SEC_ANSWERS_REQUEST,
        sFetching: true
    };
};

export const answerAddSuccess = (data) => {
    return {
        type: SEC_ANSWERS_RECEIVE,
        isFetching: false,
        data
    };
};

export const addAnswer = (answer, router, tempToken, userId) => {
    return dispatch => {
        dispatch(answerAddRequest());

        return apiAddSecAnswer(answer, (result) => {
            dispatch(answerAddSuccess(result.data));
            dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
            setTimeout(() => dispatch(loginUser({
                userId,
                tempToken
            }, router, "/")), 1000);
        }, (error) => handleApiError(dispatch, error));
    };
};

// action update answer
export const answerUpdateRequest = () => {
    return {
        type: UPDATE_QUESTIONS_ANSWERS_REQUEST
    };
};

export const answerUpdateReceive = (isSuccess) => {
    return {
        type: UPDATE_QUESTIONS_ANSWERS_RECEIVE,
        isFetching: false,
        isSuccess
    };
};

export const updateAnswer = (updateAnser) => {
    return dispatch => {
        dispatch(answerUpdateRequest());
        return apiUpdateSecQuestionAnswers(updateAnser, (result) => {
            dispatch(answerUpdateReceive(result.data.isSuccess));
            dispatch(showSuccess(SUCCESSFULLY_SAVED_MESSAGE));
        }, (error) => handleApiError(dispatch, error));

    };
};

export const requestGetQuestionAnswerByUserId = () => {
    return {
        type: GET_QUESTIONS_ANSWERS_REQUEST_BY_USERID,
        isFetching: true
    };
};

export const receiveGetQuestionAnswerByUserId = (data) => {
    return {
        type: GET_QUESTIONS_ANSWERS_RECEIVE_BY_USERID,
        isFetching: false,
        data
    };
};

export const getQuestionAnswerByUserId = (userId) => {
    return dispatch => {
        dispatch(requestGetQuestionAnswerByUserId());
        return apiGetQuestionAnswerByUserId(userId, (result) => {
            dispatch(receiveGetQuestionAnswerByUserId(result.data));
        }, (error) => handleApiError(dispatch, error));
    };
};