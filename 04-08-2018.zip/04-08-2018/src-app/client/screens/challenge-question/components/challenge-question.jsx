import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import Select from "Select";
import { updateTextFields } from "Helpers/theme-helper";
import { getValidationCssClass, validationMessage } from "Helpers/validation-helper";
import { hasStringValue } from "Helpers/common-helper";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";

class ChallengeQuestion extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        const { getSecQuestions } = this.props;

        getSecQuestions();
    }

    componentDidUpdate() {
        updateTextFields();
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {
        const { onInputBlur, secQuestions, data, handleSubmit } = this.props;

        return (
            <div className="card ml-1 mr-1">
                {secQuestions &&
                    <div className="card-content">
                        <h4 className="bold-5 font-31 title-dark-style">Challenge Question</h4>
                        <h5 className="bold-5 font-17 main-header-dark-style"></h5>

                        <div className="row">
                            <div className="col s6 m6">
                                <div className={`input-field required suffixinput ${getValidationCssClass(data.question1.message)}`}>
                                    <Select
                                        dataSource={secQuestions}
                                        value={data.question1.value}
                                        onChange={(value) => onInputBlur({ question1: { value, isDirty: true, message: "" } })}
                                        mapDataToRenderOptions={{ value: "ChalID", label: "Question" }}
                                        ref="question1"
                                        id="question1"
                                        optionDefaultLabel="Select Challenge Question #1"
                                    />
                                    <label htmlFor="question1" className="control-label">Question 1</label>
                                    {hasStringValue(data.question1.message) && validationMessage(data.question1.message, "question1", 0)}
                                </div>
                            </div>
                            <div className="col s6 m6">
                                <div className={`input-field suffixinput ${getValidationCssClass(data.answer1.message)}`}>
                                    <input type="text" className="form-control" id="answer1" ref="answer1"
                                        onBlur={(e) => onInputBlur({ answer1: { value: e.target.value, isDirty: true, message: "" } })}
                                    />
                                    <label htmlFor="answer1" className="control-label">Enter Answer to Question 1</label>
                                    {hasStringValue(data.answer1.message) && validationMessage(data.answer1.message, "answer1", 0)}
                                    <span className="suffix-text" style={data.answer1.message ? { display: "block" } : { display: "none" }} >
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={data.answer1.message} />
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s6 m6">
                                <div className={`input-field required suffixinput ${getValidationCssClass(data.question2.message)}`}>
                                    <Select
                                        dataSource={secQuestions}
                                        value={data.question2.value}
                                        onChange={(value) => onInputBlur({ question2: { value, isDirty: true, message: "" } })}
                                        mapDataToRenderOptions={{ value: "ChalID", label: "Question" }}
                                        ref="question2"
                                        id="question2"
                                        optionDefaultLabel="Select Challenge Question #2"
                                    />
                                    <label htmlFor="question2" className="control-label">Question 2</label>
                                    {hasStringValue(data.question2.message) && validationMessage(data.question2.message, "question2", 0)}
                                </div>
                            </div>
                            <div className="col s6 m6">
                                <div className={`input-field suffixinput ${getValidationCssClass(data.answer2.message)}`}>
                                    <input type="text" className="form-control" id="answer2" ref="answer2"
                                        onBlur={(e) => onInputBlur({ answer2: { value: e.target.value, isDirty: true, message: "" } })}
                                    />
                                    <label htmlFor="answer2" className="control-label">Enter Answer to Question 2</label>
                                    {hasStringValue(data.answer2.message) && validationMessage(data.answer2.message, "answer2", 0)}
                                    <span className="suffix-text" style={data.answer2.message ? { display: "block" } : { display: "none" }} >
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={data.answer2.message} />
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col s6 m6">
                                <div className={`input-field required suffixinput ${getValidationCssClass(data.question3.message)}`}>
                                    <Select
                                        dataSource={secQuestions}
                                        value={data.question3.value}
                                        onChange={(value) => onInputBlur({ question3: { value, isDirty: true, message: "" } })}
                                        mapDataToRenderOptions={{ value: "ChalID", label: "Question" }}
                                        ref="question3"
                                        id="question3"
                                        optionDefaultLabel="Select Challenge Question #3"
                                    />
                                    <label htmlFor="question3" className="control-label">Question 3</label>
                                    {hasStringValue(data.question3.message) && validationMessage(data.question3.message, "question3", 0)}
                                </div>
                            </div>
                            <div className="col s6 m6">
                                <div className={`input-field suffixinput ${getValidationCssClass(data.answer3.message)}`}>
                                    <input type="text" className="form-control" id="answer3" ref="answer3"
                                        onBlur={(e) => onInputBlur({ answer3: { value: e.target.value, isDirty: true, message: "" } })}
                                    />
                                    <label htmlFor="answer3" className="control-label">Enter Answer to Question 3</label>
                                    {hasStringValue(data.answer3.message) && validationMessage(data.answer3.message, "answer3", 0)}
                                    <span className="suffix-text" style={data.answer3.message ? { display: "block" } : { display: "none" }} >
                                        <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={data.answer3.message} />
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div className="row">
                            <div className="col s12 m12">
                                <button className="btn success-color action-btn w-100" onClick={() => handleSubmit()}>Submit</button>
                            </div>
                        </div>
                    </div>
                }
            </div>
        );
    }
}

ChallengeQuestion.propTypes = {
    dispatch: PropTypes.func,
    data: PropTypes.object,
    secQuestions: PropTypes.array,
    onInputBlur: PropTypes.func,
    validationMessage: PropTypes.func,
    handleSubmit: PropTypes.func,
    getSecQuestions: PropTypes.func
};

export default ChallengeQuestion;