import React from "react";
import { Component } from "react";
import PropTypes from "prop-types";
import { updateTextFields } from "Helpers/theme-helper";
import { getValidationCssClass, validationMessage } from "Helpers/validation-helper";
import { hasStringValue } from "Helpers/common-helper";
import { shallowCompareProps, shallowCompareState } from "../../../helpers/common-helper";
import { INPUT_MISSING_1X_IMAGE_URL } from "ImageConfig";
import Loader from "../../../features/loader";

class ChallengeQuestionConfirm extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        const { getSecQuestions } = this.props;

        getSecQuestions();
    }

    componentDidUpdate() {
        updateTextFields();
        $(".input-answer").focus();
    }

    shouldComponentUpdate(nextProps, nextState) {
        return !shallowCompareState(this.state, nextState) || !shallowCompareProps(this.props, nextProps);
    }

    render() {
        const { onInputBlur, userQuestions, data, handleSubmit, answerNo, isDone } = this.props;

        return (
            <div className="card ml-1 mr-1">
                {(isDone || !userQuestions) && <Loader isShow />}
                {!isDone &&
                    <div className="card-content">
                        <h4 className="bold-5 font-31 title-dark-style">Challenge Question</h4>
                        <h5 className="bold-5 font-17 main-header-dark-style"></h5>

                        {answerNo === 1 &&
                            <div className="row">
                                <div className="col s12 m12">
                                    <div className={`input-field`}>
                                        <span className="bold-title truncate" style={{ marginTop: "30px" }}>{userQuestions.q1}</span>
                                    </div>
                                </div>
                                <div className="col s12 m12">
                                    <div className={`input-field suffixinput ${getValidationCssClass(data.answer1.message)}`}>
                                        <input type="text" className="form-control input-answer" id="answer1" ref="answer1"
                                            onBlur={(e) => onInputBlur({ answer1: { value: e.target.value, isDirty: true, message: "" } })}
                                        />
                                        <label htmlFor="answer1" className="control-label">Answer</label>
                                        {hasStringValue(data.answer1.message) && validationMessage(data.answer1.message, "answer1", 0)}
                                        <span className="suffix-text" style={data.answer1.message ? { display: "block" } : { display: "none" }} >
                                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={data.answer1.message} />
                                        </span>
                                    </div>
                                </div>
                            </div>
                        }
                        {answerNo === 2 &&
                            <div className="row">
                                <div className="col s12 m12">
                                    <div className={`input-field`}>
                                        <span className="bold-title truncate" style={{ marginTop: "30px" }}>{userQuestions.q2}</span>
                                    </div>
                                </div>
                                <div className="col s12 m12">
                                    <div className={`input-field suffixinput ${getValidationCssClass(data.answer2.message)}`}>
                                        <input type="text" className="form-control input-answer" id="answer2" ref="answer2"
                                            onBlur={(e) => onInputBlur({ answer2: { value: e.target.value, isDirty: true, message: "" } })}
                                        />
                                        <label htmlFor="answer2" className="control-label">Answer</label>
                                        {hasStringValue(data.answer2.message) && validationMessage(data.answer2.message, "answer2", 0)}
                                        <span className="suffix-text" style={data.answer2.message ? { display: "block" } : { display: "none" }} >
                                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={data.answer2.message} />
                                        </span>
                                    </div>
                                </div>
                            </div>
                        }
                        {answerNo === 3 &&
                            <div className="row">
                                <div className="col s12 m12">
                                    <div className={`input-field`}>
                                        <span className="bold-title truncate" style={{ marginTop: "30px" }}>{userQuestions.q3}</span>
                                    </div>
                                </div>
                                <div className="col s12 m12">
                                    <div className={`input-field suffixinput ${getValidationCssClass(data.answer3.message)}`}>
                                        <input type="text" className="form-control input-answer" id="answer3" ref="answer3"
                                            onBlur={(e) => onInputBlur({ answer3: { value: e.target.value, isDirty: true, message: "" } })}
                                        />
                                        <label htmlFor="answer3" className="control-label">Answer</label>
                                        {hasStringValue(data.answer3.message) && validationMessage(data.answer3.message, "answer3", 0)}
                                        <span className="suffix-text" style={data.answer3.message ? { display: "block" } : { display: "none" }} >
                                            <img src={INPUT_MISSING_1X_IMAGE_URL} alt="" title={data.answer3.message} />
                                        </span>
                                    </div>
                                </div>
                            </div>
                        }
                        <div className="row">
                            <div className="col s12 m12">
                                <button className="btn success-color action-btn w-100" onClick={() => handleSubmit()}>Submit</button>
                            </div>
                        </div>
                    </div>
                }
            </div>
        );
    }
}

ChallengeQuestionConfirm.propTypes = {
    dispatch: PropTypes.func,
    data: PropTypes.object,
    userQuestions: PropTypes.object,
    onInputBlur: PropTypes.func,
    validationMessage: PropTypes.func,
    handleSubmit: PropTypes.func,
    answerNo: PropTypes.number,
    isDone: PropTypes.bool,
    getSecQuestions: PropTypes.func
};

export default ChallengeQuestionConfirm;