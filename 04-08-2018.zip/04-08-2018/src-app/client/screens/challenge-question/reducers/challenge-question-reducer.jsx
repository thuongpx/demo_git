import {
    SEC_QUESTIONS_REQUEST, SEC_QUESTIONS_RECEIVE,
    SEC_ANSWERS_REQUEST, SEC_ANSWERS_RECEIVE,
    UPDATE_QUESTIONS_ANSWERS_REQUEST, UPDATE_QUESTIONS_ANSWERS_RECEIVE,
    GET_QUESTIONS_ANSWERS_REQUEST_BY_USERID, GET_QUESTIONS_ANSWERS_RECEIVE_BY_USERID,
    USER_SEC_QUESTIONS_RECEIVE, DONE_CHECK_USER_ANSWER, START_CHECK_USER_ANSWER,
    MOVE_NEXT_CHALLENGE_QUESTION
} from "../actions/challenge-question-action";

export default function challengeQuestionReducer(state = {
    isFetching: false,
    secQuestions: [],
    dataChallengeByUserId: {},
    currentQuestionNo: 1,
    userQuestions: {},
    failedAttempt: 0
}, action) {
    switch (action.type) {
        case SEC_QUESTIONS_REQUEST:
            return {
                ...state,
                isFetching: true
            };
        case SEC_QUESTIONS_RECEIVE:
            return {
                ...state,
                isFetching: false,
                secQuestions: action.data
            };
        case SEC_ANSWERS_REQUEST:
            return {
                ...state,
                isFetching: true
            };
        case SEC_ANSWERS_RECEIVE:
            return {
                ...state,
                isFetching: false
            };
        case UPDATE_QUESTIONS_ANSWERS_REQUEST:
            return {
                ...state,
                isFetching: true
            };
        case UPDATE_QUESTIONS_ANSWERS_RECEIVE:
            return {
                ...state,
                isFetching: false
            };
        case GET_QUESTIONS_ANSWERS_REQUEST_BY_USERID:
            return {
                ...state,
                isFetching: true
            };
        case GET_QUESTIONS_ANSWERS_RECEIVE_BY_USERID:
            return {
                ...state,
                isFetching: false,
                dataChallengeByUserId: action.data.dataChallengeByUserId
            };
        case USER_SEC_QUESTIONS_RECEIVE:
            return {
                ...state,
                isFetching: false,
                userQuestions: action.data
            };
        case DONE_CHECK_USER_ANSWER:
            return {
                isFetching: false,
                isDone: true
            };
        case START_CHECK_USER_ANSWER:
            return {
                ...state,
                isFetching: true
            };
        case MOVE_NEXT_CHALLENGE_QUESTION:
            return {
                ...state,
                isFetching: false,
                currentQuestionNo: state.currentQuestionNo === 3 ? 1 : state.currentQuestionNo + 1,
                failedAttempt: state.failedAttempt + 1
            };
        default:
            return state;
    }
}