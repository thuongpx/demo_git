import React from "react";
import { connect } from "react-redux";
import { Component } from "react";
import PropTypes from "prop-types";

import { showWarning } from "../screens/main-layout/actions";

import NotFound from "../screens/main-layout/components/page-404";
import NoPermission from "../screens/main-layout/components/page-no-permission";

import portalFilter from "./portal-filter";
import { getCurrentPortal } from "../helpers/common-helper";
import { logoutUser } from "../screens/authentication/actions/index";
import permissionFilter from "./permission-filter";

const redirectRoute = (redirect) => `/login?redirect=${redirect}`;

export default function (path, portal, isPublic) {
    class CustomFilter extends Component {
        componentWillMount() {
            const { isAuthenticated, location, dispatch } = this.props;
            const { pathname } = location;

            if (!isAuthenticated && !isPublic) {
                if (pathname !== "/") {
                    dispatch(showWarning(`You must log in to access this page`));
                }
                this.props.router.replace(redirectRoute(pathname));
            }

            if (isAuthenticated && isPublic && pathname.indexOf("/reset-password/") > -1) {
                this.props.dispatch(logoutUser());
                this.props.router.replace(pathname);
                return false;
            }

            return true;
        }

        componentWillReceiveProps(nextProps) {
            const { isAuthenticated } = nextProps;
            const { location, dispatch } = this.props;
            const { pathname } = location;

            if (!isAuthenticated && !isPublic) {
                if (pathname !== "/") {
                    dispatch(showWarning(`You must log in to access this page`));
                }
                nextProps.router.replace(redirectRoute(pathname));
            }
        }

        doFilter() {
            const currentPortal = getCurrentPortal();
            let filterResult = {};

            // determine if user have an access to this portal or not
            filterResult = portalFilter(path, currentPortal, portal, isPublic);
            if (!filterResult) return NotFound;

            // determine if user have a permission to this page or not
            // filterResult = permissionFilter(path, isPublic, filterResult);
            // if (!filterResult) return NoPermission;

            return filterResult;
        }

        render() {
            const { isAuthenticated } = this.props;

            const ComposingComponent = this.doFilter();

            return (
                <div>
                    {(isAuthenticated || isPublic) && <ComposingComponent {...this.props} />}
                </div>
            );
        }
    }

    CustomFilter.propTypes = {
        isAuthenticated: PropTypes.bool,
        router: PropTypes.object,
        location: PropTypes.object,
        dispatch: PropTypes.func
    };

    const mapStateToProps = (state) => {
        const { authentication } = state;
        const { isAuthenticated } = authentication;

        return {
            isAuthenticated
        };
    };

    return connect(mapStateToProps)(CustomFilter);
}