import { PORTAL_NAMES } from "../constant/constants";

import routeMap from "../routes.map";
import { hasStringValue } from "../helpers/common-helper";

const _responseFilter = (component) => {
    if (!component) {
        return null;
    }

    return component;
};

export default function PortalFilter(path, currentPortal, availablePortals = [], isPublic) {
    // if the current portal is undefined, only render component which is public
    if (!hasStringValue(currentPortal) && isPublic) {
        const defaultRoute = routeMap[path];

        if (defaultRoute) {
            const staff = defaultRoute[PORTAL_NAMES.STAFF.toLowerCase()];
            const client = defaultRoute[PORTAL_NAMES.CLIENT.toLowerCase()];
            const vendor = defaultRoute[PORTAL_NAMES.VENDOR.toLowerCase()];

            if (staff) return _responseFilter(staff);
            if (client) return _responseFilter(client);
            if (vendor) return _responseFilter(vendor);
        }
    } else {
        // if this view is not available for the current portal, should show not found
        const portal = availablePortals.find(i => i.toUpperCase() === currentPortal.toUpperCase());

        if (!portal) {
            return _responseFilter();
        }

        // find the appropriate component of the current portal
        const composingComponent = routeMap[path][portal.toLowerCase()];

        if (composingComponent) return _responseFilter(composingComponent);

        const defaultComponent = routeMap[path][PORTAL_NAMES.STAFF.toLowerCase()];

        if (defaultComponent) return _responseFilter(defaultComponent);
    }

    return _responseFilter();
}