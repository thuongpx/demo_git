import { getAuthenticatedUser } from "../helpers/common-helper";

export default function PermissionFilter(path, isPublic, composingComponent) {
    if (isPublic) {
        return composingComponent;
    }

    const userData = getAuthenticatedUser();

    if (userData && userData.role && userData.role.permissions && userData.role.permissions.length > 0) {
        const permissions = userData.role.permissions;

        if (permissions.find(p => p.toLowerCase() === path.toLowerCase())) {
            return composingComponent;
        }

        return null;
    }

    return composingComponent;
}