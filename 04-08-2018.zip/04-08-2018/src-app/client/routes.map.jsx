// not found
import NotFound from "./screens/main-layout/components/page-404";

// view orders
import ViewOrderVendor from "Screens/vendor-view-order/containers";
import ViewOrderStaff from "Screens/view-orders/containers/view-orders";
import ViewOrderClient from "Screens/view-orders-client-staff/containers/view-orders-client-staff";
import ViewOrdersClientProgressGroup from "Screens/view-orders-client-staff/containers/view-orders-client-progress-group";

// dashboard
import VendorDashboard from "Screens/vendor-dashboard/containers";
import ClientDashboard from "Screens/client-dashboard/containers";
import StaffDashboard from "Screens/staff-dashboard/containers";

// authentication
import Authentication from "Screens/authentication/containers/authentication";

// sign up
import SignUp from "Screens/vendor-registration/containers/vendor-sign-up";
import SignUpStep1 from "Screens/vendor-registration/components/client-sign-up-step-1";
import SignUpStep2 from "Screens/vendor-registration/components/client-sign-up-step-2";
import SignUpStep3 from "Screens/vendor-registration/components/client-sign-up-step-3";
import SignUpDone from "Screens/vendor-registration/components/client-sign-up-done";

// fee requests
import ApprovalFeeSearch from "Screens/approvals/components/approval-fee-search";
import ClientFeeSearch from "Screens/approvals/components/client-fee-search";

// vendor requests
import ApprovalVendorSearch from "Screens/approvals/components/approval-vendor-search";

// branch search
import BranchSearch from "Screens/branch-management/components/branch-search";

// manage agents
import AgentManagement from "Screens/agent-management/containers/agent-management";

// customer search
import CustomerSearch from "Screens/customers-management/components/customer-search";

// documentation
import VendorDocumentUpload from "Screens/vendor-registration/components/vendor-document-upload";

// vendor offers
import VendorOffers from "Screens/vendor-offer-management/containers/vendor-offer";

// service configuration
import ClientServiceConfiguration from "Screens/client-services-configuration/containers";

// vendor rating settings
import VendorRating from "Screens/vendor-rating/containers/index";

//vendor management
import VendorManagement from "Screens/vendor-management/containers/index";

// do not use vendor

// order detail
import OrderDetailClient from "Screens/client-order-detail/containers";
import OrderDetailVendor from "Screens/vendor-order-detail/containers/index";

// profile
import ClientProfiles from "Screens/client-profiles/containers/client-profiles-wrapper";

// import ClientProfiles from "Screens/profiles/containers/index";
import StaffProfiles from "Screens/staff-profiles-settings/containers/staff-profiles";

// vendor notary training
import VendorNotaryTraining from "Screens/vendor-notary-training/containers/vendor-training";

// vendor notary exam result
import VendorExamResult from "Screens/vendor-notary-training/containers/notary-exam-result";

// do not use
import VendorDoNotUse from "Screens/vendor-do-not-use/containers/vendor-do-not-use";

// canned report
import ClientCannedReport from "Screens/client-canned-report/containers/index";
import CannedReport from "./screens/canned-report/containers";

// vendor verified
import VendorVerified from "Screens/vendor-verified/containers";

// email verification
import EmailVerification from "Screens/vendor-registration/containers/email-verification";

// notification management
import NotificationManagement from "Screens/notification-management/containers";

// client registration
import ClientRegistration from "Screens/client-registration/containers";

import ConsumerSurvey from "Screens/consumer-survey/containers/consumer-survey";

//client management
import ClientDetail from "Screens/client-management/containers/client-management";
import ClientManagement from "Screens/client-management/components/client-search";

import ManagerInternalUser from "Screens/manager-internal-user/containers/view-manager-internal-user";

//training test maker
import TrainingTestMaker from "Screens/training-testing-maker/containers/training-testing-maker";


import ChallengeQuestionManagement from "Screens/challenge-question/containers";
// vendor exam
import VendorExam from "Screens/vendor-registration/containers/vendor-exam";

import StaffApprovalVendorManagement from "Screens/staff-approval-management/containers/vendor-approval";
import StaffManagerFeeApproval from "Screens/staff-approval-management/containers/fee-approval";
import StaffManagerApproval from "Screens/staff-approval-management/containers/";
import OrderIssuesReporting from "Screens/staff-issue-reporting/containers/staff-issue-reporting";
import VendorClassifications from "Screens/vendor-classifications-setting/containers/vendor-classifications-setting";
import UserProfileManagement from "Screens/user-profile-security/containers/index";
import VendorProblem from "Screens/vendor-problem/containers/vendor-problem";
import ProblemManagement from "Screens/client-issue-management/containers/problem-management";

//client order document
import ClientOrderDocument from "Screens/client-order-document/components/client-order-document";

//staff-approval-service-config
import ServiceConfigurationApproval from "Screens/staff-service-configuration-approval/containers/index";

//user-profile
import UserProfileSecurity from "Screens/user-profile-security/containers";

// change password
import UserChangePassword from "Screens/user-profile-security/components/user-change-password";
//client order assignment config
import ClientOrderAssignmentConfig from "./screens/client-order-assignment-configuration/containers";

const routes = {};

//vendor-profile
import VendorProfile from "Screens/vendor-profile/containers/vendor-profile";

//reset-password-page
import ResetPasswordPage from "Screens/authentication/components/reset-password-page";

//business-hours
import BusinessHours from "Screens/business-hours/containers/index";
//tool-view
import ToolResources from "Screens/tool-view/containers/resources";

//tool-interview
import ToolLinks from "Screens/tool-view/containers/links";
import FaqView from "Screens/tool-view/containers/faqs";
import UserAnnouncements from "Screens/user-announcement/containers/user-announcement";

//staff-configuration-settings
import StaffProductTypeSetting from "Screens/staff-configuration-setting/containers/product-type";
import CorrectionRequestType from "Screens/staff-configuration-setting/containers/correction-request-type";
import CorrectionRequestSubType from "Screens/staff-configuration-setting/containers/correction-request-sub-type";
import BonusCalculation from "Screens/staff-configuration-setting/containers/bonus-calculation";

//vendor-credential-document
import VendorCredentialDocument from "Screens/staff-configuration-setting/containers/vendor-credential-document";
//industry setting
import IndustrySetting from "Screens/staff-configuration-setting/components/industry";
//fee configuration
import Fee from "Screens/staff-configuration-setting/components/fee";
//staff-additional-service-settings
import StaffAdditionalServiceSetting from "Screens/staff-configuration-setting/containers/additional-service";
//staff-tool-manager
import StaffFaqsView from "Screens/tool-view-management/containers/faqs-management";
import StaffToolLink from "Screens/tool-view-management/containers/links-management";
import StaffResources from "Screens/tool-view-management/containers/resources-management";

//vender-notary-exam
import VendorNotaryExam from "Screens/vendor-notary-training/containers/notary-exam";
import ConfigurationSlas from "Screens/client-slas/containers/client-slas";

//quickbook
import VendorExport from "Screens/quickbook-invoices/components/vendor-export";
import VendorCheckExport from "Screens/quickbook-invoices/components/vendor-check-export";
import VendorBillExport from "Screens/quickbook-invoices/components/vendor-bill-export";
import ClientExport from "Screens/quickbook-invoices/components/client-export";
import ClientCheckExport from "Screens/quickbook-invoices/components/client-check-export";
import ClientInvoiceExport from "Screens/quickbook-invoices/components/client-invoice-export";
import InvoiceReport from "Screens/quickbook-invoices/components/invoice-report";
import QuickBookContent from "Screens/quickbook-invoices/components/quickbook-content";

// Roles & permissions
import RolesPermissions from "Screens/roles-permissions/containers/index";
import VendorCourseTraining from "Screens/vendor-notary-training/containers/vendor-course-training";
import ConfigurationVendorRating from "Screens/vendor-ratings-setting/containers/vendor-ratings-setting";

const generateRoute = (path, staff, vendor, client) => {
    routes[path] = {
        staff,
        client,
        vendor
    };
};

const generateRoutes = () => {
    // map go here
    generateRoute("view-orders", ViewOrderStaff, ViewOrderVendor, ViewOrderClient);
    generateRoute("view-orders-progress/:progressName", ViewOrdersClientProgressGroup);
    generateRoute("dashboard", StaffDashboard, VendorDashboard, ClientDashboard);
    generateRoute("login", Authentication);
    generateRoute("sign-up", SignUp, SignUp);
    generateRoute("sign-up-step-1", SignUpStep1);
    generateRoute("sign-up-step-2", SignUpStep2);
    generateRoute("sign-up-step-3", SignUpStep3);
    generateRoute("sign-up-done", SignUpDone);
    generateRoute("approval-fee-search", null, null, ApprovalFeeSearch);
    generateRoute("approval-vendor-search", ApprovalVendorSearch, null, ApprovalVendorSearch);
    generateRoute("branch-search", null, null, BranchSearch);
    generateRoute("agent-management", null, null, AgentManagement);
    generateRoute("customer-search", null, null, CustomerSearch);
    generateRoute("document", null, VendorDocumentUpload, null);
    generateRoute("service-configuration", null, null, ClientServiceConfiguration);
    generateRoute("vendor-rating", null, null, VendorRating);
    generateRoute("vendor-offers", null, VendorOffers, null);
    generateRoute("vendor-management", VendorManagement, null, null);
    generateRoute("vendor-exam", VendorExam);
    generateRoute("order-detail/:orderId", OrderDetailClient, OrderDetailVendor, OrderDetailClient);
    generateRoute("profiles-settings", StaffProfiles, null, ClientProfiles);
    generateRoute("notary-training", null, VendorNotaryTraining, null);
    generateRoute("do-not-use", null, null, VendorDoNotUse);
    generateRoute("canned-report-demo", null, null, ClientCannedReport);
    generateRoute("canned-reports", CannedReport, null, CannedReport);
    generateRoute("vendor-certificate", VendorVerified, null, VendorVerified);
    generateRoute("vendor-offer", VendorOffers);
    generateRoute("email-verification", EmailVerification, EmailVerification);
    generateRoute("notification-management", NotificationManagement);
    generateRoute("client-registration/:industryId", ClientRegistration);
    generateRoute("consumer-survey", ConsumerSurvey);
    generateRoute("client-management", ClientManagement);
    generateRoute("client-detail/:brokerId", ClientDetail);
    generateRoute("manager-internal-user", ManagerInternalUser, null, null);
    generateRoute("training-test-maker", TrainingTestMaker, null, null);
    generateRoute("challenge-question", ChallengeQuestionManagement);
    generateRoute("staff-approval-management/vendor-approval", StaffApprovalVendorManagement, null, null);
    generateRoute("staff-approval-management/fee-approval", StaffManagerFeeApproval, null, null);
    generateRoute("staff-approval-management", StaffManagerApproval, null, null);
    generateRoute("staff-issue-reporting", OrderIssuesReporting, null, null);
    generateRoute("vendor-classifications-setting", VendorClassifications, null, null);
    generateRoute("user-profile-security", UserProfileManagement, null, null);
    generateRoute("vendor-problem", null, VendorProblem, null);
    generateRoute("client-order-document", null, null, ClientOrderDocument);
    generateRoute("staff-approval-service-config", ServiceConfigurationApproval, null, null);
    generateRoute("user-profile", UserProfileSecurity);
    generateRoute("client-issue-management", null, null, ProblemManagement);
    generateRoute("client-order-assignment-config/:customerId", null, null, ClientOrderAssignmentConfig);
    generateRoute("change-password", UserChangePassword, UserChangePassword, UserChangePassword);
    generateRoute("vendor-profile/:signerId", VendorProfile, null, VendorProfile);
    generateRoute("vendor-profile/:signerId/:orderId", VendorProfile, null, VendorProfile);
    generateRoute("reset-password/:securityCode", ResetPasswordPage, null, null);
    generateRoute("business-hours", BusinessHours, null, null);
    generateRoute("vendor-fee-request", ApprovalFeeSearch, null, null);
    generateRoute("client-fee-request", ClientFeeSearch, null, null);
    generateRoute("resources", ToolResources);
    generateRoute("404", NotFound);
    generateRoute("user-announcement", UserAnnouncements, UserAnnouncements, UserAnnouncements);
    generateRoute("links", ToolLinks);
    generateRoute("staff-faqs", StaffFaqsView, null, null);
    generateRoute("staff-resources", StaffResources, null, null);
    generateRoute("staff-links", StaffToolLink, null, null);
    generateRoute("faqs", FaqView);
    generateRoute("staff-product-type-setting", StaffProductTypeSetting, null, null);
    generateRoute("correction-request-type-setting", CorrectionRequestType, null, null);
    generateRoute("bonus-calculation", BonusCalculation, null, null);
    generateRoute("correction-request-sub-type-setting", CorrectionRequestSubType, null, null);
    generateRoute("vendor-credential-document", VendorCredentialDocument, null, null);
    generateRoute("industry-setting", IndustrySetting, null, null);
    generateRoute("vendor-fee-config", null, null, Fee);
    generateRoute("fee-config", Fee, null, null);
    generateRoute("staff-additional-service-setting", StaffAdditionalServiceSetting, null, null);
    generateRoute("vendor-export", VendorExport);
    generateRoute("vendor-check-export", VendorCheckExport);
    generateRoute("vendor-bill-export", VendorBillExport);
    generateRoute("configuration-slas", ConfigurationSlas, null, ConfigurationSlas);
    generateRoute("quickbook-content/:fileName/:quickBookType/:brokerId/:isIncludeBranchs/:state/:startMonth/:endMonth/:inYear", QuickBookContent, null, null);
    generateRoute("notary-exam/:programId/:testId", null, VendorNotaryExam, null);
    generateRoute("notary-exam-result/:programId/:testId", null, VendorExamResult, null);
    generateRoute("client-export", ClientExport, null, null);
    generateRoute("client-check-export", ClientCheckExport, null, null);
    generateRoute("client-invoice-export", ClientInvoiceExport, null, null);
    generateRoute("invoice-report", InvoiceReport, null, null);
    generateRoute("roles-permissions-staff", RolesPermissions, null, null);
    generateRoute("roles-permissions-client", null, null, RolesPermissions);
    generateRoute("vendor-course/:ProgramId/:CourseId", null, VendorCourseTraining, null);
    generateRoute("configuration-vendor-rating", ConfigurationVendorRating, null, ConfigurationVendorRating);
    generateRoute("view-orders/:complete", null, ViewOrderVendor, null);

    return routes;
};

export default generateRoutes();