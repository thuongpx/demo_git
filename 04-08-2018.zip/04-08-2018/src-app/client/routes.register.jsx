import { MENU_NAMES } from "./constant/constants";

export const menuRoutes = [
        {
                name: "Dashboard",
                path: "dashboard",
                subMenu: "Dashboard",
                portal: ["client", "vendor", "staff"],
                isIndexRoute: true
        },
        {
                name: "ViewOrders",
                path: "view-orders",
                menu: MENU_NAMES.ORDERS,
                subMenu: "View Orders",
                portal: ["client", "staff", "vendor"]
        },
        {
                name: "Vendor Problem",
                menu: MENU_NAMES.MANAGEMENT,
                subMenu: "Correction Requests",
                path: "vendor-problem",
                portal: ["vendor"]
        },
        {
                name: "Documentation",
                menu: MENU_NAMES.ACCOUNTS,
                subMenu: "Documentation",
                path: "document",
                portal: ["vendor"],
                actors: ["vendor"]
        },
        {
                name: "Documentation",
                menu: MENU_NAMES.ACCOUNTS,
                subMenu: "Vendor Training",
                path: "notary-training",
                portal: ["vendor"],
                actors: ["vendor"]
        },
        {
                name: "VendorOffers",
                subMenu: MENU_NAMES.VENDOR_OFFERS,
                path: "vendor-offers",
                portal: ["vendor"],
                actors: ["vendor"]
        },
        {
                name: "PlaceOrder",
                menu: MENU_NAMES.ORDERS,
                subMenu: "Place Order",
                portal: ["client", "staff"],
                onClick: () => window.clientAddNewOrder()
        },
        {
                name: "FeeRequests",
                menu: MENU_NAMES.MANAGEMENT,
                subMenu: "Fee Requests",
                path: "approval-fee-search",
                portal: ["client"],
                actors: ["client", "branch"]
        },
        {
                name: "VendorFeeRequests",
                menu: MENU_NAMES.MANAGEMENT,
                subMenu: "Vendor Fee Requests",
                path: "vendor-fee-request",
                portal: ["staff"]
        },
        {
                name: "ClientFeeRequests",
                menu: MENU_NAMES.MANAGEMENT,
                subMenu: "Client Fee Requests",
                path: "client-fee-request",
                portal: ["staff"]
        },
        {
                name: "VendorRequests",
                menu: MENU_NAMES.MANAGEMENT,
                subMenu: "Vendor Requests",
                path: "approval-vendor-search",
                portal: ["client", "staff"],
                actors: ["client", "branch", "Admin", "Operational Manager"]
        },
        {
                name: "ClientOrderDocument",
                menu: MENU_NAMES.MANAGEMENT,
                subMenu: "Documents",
                path: "client-order-document",
                portal: ["client"],
                actors: ["client", "branch", "agent"]
        },
        {
                name: "ProblemManagement",
                menu: MENU_NAMES.MANAGEMENT,
                path: "client-issue-management",
                subMenu: "Correction Requests",
                portal: ["client"]
        },
        {
                name: "Staff Issue Reporting",
                menu: MENU_NAMES.MANAGEMENT,
                path: "staff-issue-reporting",
                subMenu: "Correction Requests",
                portal: ["staff"]
        },
        {
                name: "ManageBranches",
                menu: MENU_NAMES.ACCOUNTS,
                subMenu: "Manage Branches",
                path: "branch-search",
                portal: ["client"],
                actors: ["client"]
        },
        {
                name: "ManageAgents",
                menu: MENU_NAMES.ACCOUNTS,
                subMenu: "Manage Agents",
                path: "agent-management",
                portal: ["client"],
                actors: ["client", "branch"]
        },
        {
                name: "ManageCustomer",
                menu: MENU_NAMES.ACCOUNTS,
                subMenu: "Manage Customer",
                path: "customer-search",
                portal: ["client"],
                actors: ["client", "branch"]
        },
        {
                name: "Client Management",
                menu: MENU_NAMES.USER_MANAGEMENT,
                subMenu: "Manage Clients",
                path: "client-management",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "VendorManagement",
                path: "vendor-management",
                menu: MENU_NAMES.USER_MANAGEMENT,
                subMenu: "Manage Vendors",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "ManagerInternalUser",
                menu: MENU_NAMES.USER_MANAGEMENT,
                subMenu: "Manage Accounts",
                path: "manager-internal-user",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "Vendor Classifications",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Vendor Classification Settings",
                path: "vendor-classifications-setting",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "StaffServiceConfigApproval",
                path: "staff-approval-service-config",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Service Configuration",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "ClientOrderAssignmentConfig",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Order Assignment Configuration",
                path: "client-order-assignment-config/:customerId",
                customLink: "client-order-assignment-config/0",
                portal: ["client"],
                actors: ["Client"]
        },
        {
                name: "ServiceConfiguration",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Service Configuration",
                path: "service-configuration",
                portal: ["client"],
                actors: ["client", "branch"]
        },
        {
                name: "StaffRolesPermissions",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                path: "roles-permissions-staff",
                subMenu: "Role & Permission",
                portal: ["staff"],
                actors: ["Admin"]
        },
        {
                name: "Vendor Rating Settings",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Vendor Rating Settings",
                path: "configuration-vendor-rating",
                portal: ["client", "staff"],
                actors: ["client", "Admin", "Operational Manager"]
        },
        {
                name: "Vendor Fee Configuration",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Vendor Fee Configuration",
                path: "vendor-fee-config",
                portal: ["client"],
                actors: ["client"]
        },
        {
                name: "SLA Configuration",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "SLA Configuration",
                path: "configuration-slas",
                portal: ["client", "staff"],
                actors: ["client", "Admin", "Operational Manager"]
        },
        {
                name: "ClientRolesPermissions",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Role & Permission",
                path: "roles-permissions-client",
                portal: ["client"],
                actors: ["client"]
        },
        {
                name: "industries",
                path: "industry-setting",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Industries",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "StaffProductTypeSetting",
                path: "staff-product-type-setting",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Product Types",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "CorrectionRequestTypeSetting",
                path: "correction-request-type-setting",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Correction Request Type",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "CorrectionRequestSubTypeSetting",
                path: "correction-request-sub-type-setting",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Correction Request Sub Type",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "BonusCalculationSetting",
                path: "bonus-calculation",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Bonus Calculation",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "DoNotUseVendor",
                subMenu: "Vendors",
                path: "do-not-use",
                portal: ["client"],
                actors: ["client"]
        },
        {
                name: "ProfileSettings",
                menu: "Settings",
                subMenu: "Profile & Settings",
                path: "profiles-settings",
                portal: ["client", "staff"]
        },
        {
                name: "UpdateProfile",
                path: "user-profile",
                menu: "Settings",
                subMenu: "Update Profile",
                portal: ["vendor"]
        },
        {
                name: "UserAnnouncement",
                path: "user-announcement",
                menu: "Settings",
                subMenu: "Announcements",
                portal: ["staff", "client", "vendor"]
        },
        {
                name: "LogOut",
                menu: MENU_NAMES.SETTINGS,
                subMenu: "Log Out",
                icon: "ti-power-off",
                onClick: () => window.logOut()
        },
        {
                name: "NotificationManagement",
                path: "notification-management",
                menu: MENU_NAMES.GENERAL,
                subMenu: "Notification Management ",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "BusinessHours",
                menu: MENU_NAMES.GENERAL,
                subMenu: "Business Hours",
                path: "business-hours",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "Content Management System",
                menu: MENU_NAMES.CONTENT_MANAGEMENT,
                subMenu: "Content Management System",
                path: "view-orders",
                portal: ["staff"],
                actors: ["Admin", "Content Manager"]
        },
        {
                name: "FAQs",
                menu: MENU_NAMES.CONTENT_MANAGEMENT,
                subMenu: "FAQs",
                path: "staff-faqs",
                portal: ["staff"],
                actors: ["Admin", "Content Manager"]
        },
        {
                name: "Resources",
                menu: MENU_NAMES.CONTENT_MANAGEMENT,
                subMenu: "Resources",
                path: "staff-resources",
                portal: ["staff"],
                actors: ["Admin", "Content Manager"]
        },
        {
                name: "Links",
                menu: MENU_NAMES.CONTENT_MANAGEMENT,
                subMenu: "Links",
                path: "staff-links",
                portal: ["staff"],
                actors: ["Admin", "Content Manager"]
        },
        {
                name: "TrainingTestMaker",
                subMenu: MENU_NAMES.TRAINING_TESTING,
                path: "training-test-maker",
                portal: ["staff"],
                actor: ["Admin", "Training Manager"]
        },
        {
                name: "QB Vendor Export",
                menu: MENU_NAMES.ACCOUNTING,
                subMenu: "QB Vendor Export",
                path: "vendor-export",
                portal: ["staff"],
                actor: ["Admin", "Training Manager"]
        },
        {
                name: "QB Vendor Check Export",
                menu: MENU_NAMES.ACCOUNTING,
                subMenu: "QB Vendor Check Export",
                path: "vendor-check-export",
                portal: ["staff"],
                actor: ["Admin", "Training Manager"]
        },
        {
                name: "QB Vendor Bills Export",
                menu: MENU_NAMES.ACCOUNTING,
                subMenu: "QB Vendor Bills Export",
                path: "vendor-bill-export",
                portal: ["staff"],
                actor: ["Admin", "Training Manager"]
        },
        {
                name: "QB Client Export",
                menu: MENU_NAMES.ACCOUNTING,
                subMenu: "QB Client Export",
                path: "client-export",
                portal: ["staff"],
                actor: ["Admin", "Training Manager"]
        },
        {
                name: "QB Client Check Export",
                menu: MENU_NAMES.ACCOUNTING,
                subMenu: "QB Client Check Export",
                path: "client-check-export",
                portal: ["staff"],
                actor: ["Admin", "Training Manager"]
        },
        {
                name: "QB Client Invoice Export",
                menu: MENU_NAMES.ACCOUNTING,
                subMenu: "QB Client Invoice Export",
                path: "client-invoice-export",
                portal: ["staff"],
                actor: ["Admin", "Training Manager"]
        },
        {
                name: "Invoices",
                menu: MENU_NAMES.ACCOUNTING,
                subMenu: "Invoices",
                path: "invoice-report",
                portal: ["staff"],
                actor: ["Admin", "Training Manager"]
        },
        {
                name: "FaqView",
                menu: MENU_NAMES.TOOL,
                subMenu: "FAQ",
                path: "faqs",
                portal: ["client", "vendor"]
        },
        {
                name: "Resources",
                menu: MENU_NAMES.TOOL,
                subMenu: "Resources",
                path: "resources",
                portal: ["client", "vendor"]
        },
        {
                name: "ToolLinks",
                menu: MENU_NAMES.TOOL,
                subMenu: "Links",
                path: "links",
                portal: ["client", "vendor"]
        },
        {
                name: "VendorCredentialDocument",
                path: "vendor-credential-document",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Vendor Credential Documents",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        },
        {
                name: "Fee",
                path: "fee-config",
                menu: MENU_NAMES.CONFIGURATION_SETTINGS,
                subMenu: "Fees",
                portal: ["staff"],
                actors: ["Admin", "Operational Manager"]
        }
];

export const publicRoutes = [
        {
                name: "Login",
                path: "login",
                isPublic: true,
                portal: ["client", "staff", "vendor"]
        },
        {
                name: "SignUp",
                path: "sign-up",
                isPublic: true,
                portal: ["client", "staff", "vendor"]
        },
        {
                name: "SignUpStep1",
                path: "sign-up-step-1",
                isPublic: true,
                portal: ["client", "staff", "vendor"]
        },
        {
                name: "SignUpStep2",
                path: "sign-up-step-2",
                isPublic: true,
                portal: ["client", "staff", "vendor"]
        },
        {
                name: "SignUpStep3",
                path: "sign-up-step-3",
                isPublic: true,
                portal: ["client", "staff", "vendor"]
        },
        {
                name: "SignUpDone",
                path: "sign-up-done",
                isPublic: true,
                portal: ["client", "staff", "vendor"]
        },
        {
                name: "ResetPasswordPage",
                path: "reset-password/:securityCode",
                portal: ["staff"],
                isPublic: true
        },
        {
                name: "Page404",
                path: "404",
                isPublic: true,
                portal: ["staff", "client", "vendor"]
        },
        {
                name: "UserProfileSecurity",
                path: "user-profile",
                isPublic: true,
                portal: ["vendor"]
        },
        {
                name: "Change Password",
                path: "change-password",
                isPublic: true,
                portal: ["staff", "client", "vendor"]
        },
        {
                name: "ChallengeQuestionManagement",
                path: "challenge-question",
                isPublic: true,
                portal: ["client", "vendor"]
        }, {
                name: "ClientRegistration",
                path: "client-registration/:industryId",
                isPublic: true,
                portal: ["client", "staff", "vendor"]
        },
        {
                name: "ConsumerSurvey",
                path: "consumer-survey",
                isPublic: true,
                portal: ["client", "staff", "vendor"]
        },
        {
                name: "VendorOffer",
                path: "vendor-offer",
                isPublic: true,
                portal: ["client", "staff", "vendor"]
        },
        {
                name: "EmailVerification",
                path: "email-verification",
                isPublic: true,
                portal: ["client", "staff", "vendor"]
        }
];

export const noMenuRoutes = [
        {
                name: "VendorExam",
                path: "vendor-exam",
                portal: ["vendor"]
        },
        {
                name: "ViewOrdersClientProgressGroup",
                path: "view-orders-progress/:progressName",
                portal: ["client", "staff"]
        },
        {
                name: "OrderDetail",
                path: "order-detail/:orderId",
                portal: ["client", "staff", "vendor"]
        },
        {
                name: "VendorVerified",
                path: "vendor-certificate",
                portal: ["client", "staff"]
        },
        {
                name: "Client Detail",
                path: "client-detail/:brokerId",
                portal: ["staff"]
        },
        {
                name: "Staff Vendor Approval",
                path: "staff-approval-management/vendor-approval",
                portal: ["staff"]
        },
        {
                name: "Staff Fee Approval",
                path: "staff-approval-management/fee-approval",
                portal: ["staff"]
        },
        {
                name: "Staff Approval Management",
                path: "staff-approval-management",
                portal: ["staff"]
        },
        {
                name: "User Profile Security",
                path: "user-profile-security",
                portal: ["vendor"]
        },
        {
                name: "VendorProfile",
                path: "vendor-profile/:signerId",
                portal: ["staff", "client"]
        },
        {
                name: "VendorProfile",
                path: "vendor-profile/:signerId/:orderId",
                portal: ["client", "staff"]
        },
        {
                name: "StaffFaqsView",
                path: "staff-faqs",
                portal: ["staff"]
        },
        {
                name: "StaffResources",
                path: "staff-resources",
                portal: ["staff"]
        },
        {
                name: "StaffToolLink",
                path: "staff-links",
                portal: ["staff"]
        },
        {
                name: "VendorNotaryExam",
                path: "notary-exam/:programId/:testId",
                portal: ["vendor"]
        },
        {
                name: "quickbook-content",
                path: "quickbook-content/:fileName/:quickBookType/:brokerId/:isIncludeBranchs/:state/:startMonth/:endMonth/:inYear",
                portal: ["staff"]
        },
        {
                name: "VendorExamResult",
                path: "notary-exam-result/:programId/:testId",
                portal: ["vendor"]
        },
        {
                name: "VendorNotaryExamResult",
                path: "vendor-course/:ProgramId/:CourseId",
                portal: ["vendor"]
        },
        {
                name: "CannedReportsDemo",
                path: "canned-report-demo",
                portal: ["client", "staff"]
        },
        {
                name: "CannedReports",
                path: "canned-reports",
                subMenu: "Reports",
                portal: ["client", "staff"]
        },
        {
                name: "ViewOrderVendorActive",
                path: "view-orders/:complete",
                portal: ["vendor"]
        }
];

export const routeMap = [...menuRoutes, ...publicRoutes, ...noMenuRoutes];
