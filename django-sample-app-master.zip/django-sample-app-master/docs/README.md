# Docs for Django-sample-app

you can modify the conf.py file by hand.

Or better you can start with an empty dir and run sphinx-quickstart. It will make you some questions and create a default content based on your answers.

