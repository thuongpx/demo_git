.. _ref-templates:

.. index::
   single: Templates

=========
Templates
=========

List of template files coming with Django-sample-app.

**sample_app/diaryday_detail.html**
    Renders a DiaryDay with all the related entries in the DiaryDayEntry model. It's the default template used by the class view ``sample_app.views.DiaryDayView``.


