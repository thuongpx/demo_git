.. _ref-settings:

.. index::
   single: Settings

Settings
========

Django-sample-app setting.

.. automodule:: sample_app.conf.defaults
   :members:
