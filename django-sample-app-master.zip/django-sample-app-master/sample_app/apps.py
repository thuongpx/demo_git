from django.apps import AppConfig


class SampleAppConfig(AppConfig):
    name = 'sample_app'
    verbose_name = 'Sample App'
