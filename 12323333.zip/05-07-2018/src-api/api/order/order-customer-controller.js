import Boom from "boom";
import Bookshelf from "./../../db/database";
import Order from "./../../db/model/order";
import moment from "moment";
import { bufferToBoolean } from "../../helper/common-helper";

class OrderCustomerController {
    getInitDataForOrderDetailCustomer(request, reply) {
        const { orderId } = request.query;
        const getListLoanType = Promise.resolve(Bookshelf.knex.raw(`select lt.LoanTypeId, lt.LoanType from loan_type lt;`));
        const getListLanguage = Promise.resolve(Bookshelf.knex.raw(`select l.LanguageID, l.Language from \`language\` l;`));
        const getDefaultOrderCustomer = Promise.resolve(Bookshelf.knex.raw(
            `select o.OrderId, o.BrokerIdNum, o.LoanType, o.IsNonBorrowingSpouse, o.NonBorrowingSpouseFirst, o.NonBorrowingSpouseLast, o.FirstName, o.LastName, o.HomePhone, o.WorkPhone, o.BoWrkext,
		    o.CellPhone, o.CoFirstName, o.CoLastName, o.CoHomePhone, o.CoWorkPhone, o.CoBoWrkext, o.CoCellPhone, o.Address, o.City, o.State, o.Zip, o.AptDateTime, o.LanguageId, o.Email
            from \`order\` o where o.OrderId = ${orderId};`
        ));
        const getListState = Promise.resolve(Bookshelf.knex.raw(`SELECT s.Code, s.Description FROM state s;`));

        Promise.all([getListLoanType, getListLanguage, getDefaultOrderCustomer, getListState])
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.listLoanType = item[0];
                                    break;
                                case 1:
                                    data.listLanguage = item[0];
                                    break;
                                case 2:
                                    data.orderCustomerValue = item[0][0];
                                    break;
                                case 3:
                                    data.listState = item[0];
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    updateOrderDetailCustomer(request, reply) {
        const orderDetailCustomer = request.payload;

        const newOrderCustomer = {
            Address: orderDetailCustomer.Address,
            AptDateTime: moment(orderDetailCustomer.AptDateTime).format("YYYY-MM-DD HH:mm:ss").toString(),
            BoWrkext: orderDetailCustomer.BoWrkext,
            BrokerIdNum: orderDetailCustomer.BrokerIdNum,
            CellPhone: orderDetailCustomer.CellPhone,
            City: orderDetailCustomer.City,
            CoBoWrkext: orderDetailCustomer.CoBoWrkext,
            CoCellPhone: orderDetailCustomer.CoCellPhone,
            CoFirstName: orderDetailCustomer.CoFirstName,
            CoHomePhone: orderDetailCustomer.CoHomePhone,
            CoLastName: orderDetailCustomer.CoLastName,
            CoWorkPhone: orderDetailCustomer.CoWorkPhone,
            FirstName: orderDetailCustomer.FirstName,
            HomePhone: orderDetailCustomer.HomePhone,
            IsNonBorrowingSpouse: orderDetailCustomer.IsNonBorrowingSpouse,
            LanguageId: orderDetailCustomer.LanguageId,
            LastName: orderDetailCustomer.LastName,
            LoanType: orderDetailCustomer.LoanType,
            NonBorrowingSpouseFirst: orderDetailCustomer.NonBorrowingSpouseFirst,
            NonBorrowingSpouseLast: orderDetailCustomer.NonBorrowingSpouseLast,
            State: orderDetailCustomer.State,
            WorkPhone: orderDetailCustomer.WorkPhone,
            Zip: orderDetailCustomer.Zip,
            Email: orderDetailCustomer.Email
        };

        Order.where({ OrderId: orderDetailCustomer.OrderId })
            .save(newOrderCustomer, { method: "update" })
            .then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        return reply;
    }


    //save changes data of customer tab when client place order
    updateClientPlaceOrderCustomerData(request, reply) {
        const inputs = request.payload;

        const updateData = {
            FirstName: inputs.firstName,
            LastName: inputs.lastName,
            CoFirstName: inputs.coFirstName,
            CoLastName: inputs.coLastName,
            HomePhone: inputs.homePhone,
            coHomePhone: inputs.coHomePhone,
            WorkPhone: inputs.workPhone,
            CoWorkPhone: inputs.coWorkPhone,
            Email: inputs.email,
            CoEmail: inputs.coEmail,
            LanguageId: inputs.languageId,
            CoLanguageId: inputs.coLanguageId,
            IsCoBasicAccess: inputs.isCoBasicAccess,
            IsCoDocReview: inputs.isCoDocReview,
            IsPrimaryBasicAccess: inputs.isPrimaryBasicAccess,
            IsPrimaryDocReview: inputs.isPrimaryDocReview
        };

        Order.where({ OrderId: inputs.orderId })
            .save(updateData, { method: "update" })
            .then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        return reply;
    }

    getInitDataOfCustomerInfoForClientPlaceOrder(request, reply) {
        const { orderId } = request.query;

        const getListLanguage = Promise.resolve(Bookshelf.knex.raw(`select l.LanguageID, l.Language from \`language\` l;`));
        const getDefaultOrderCustomer = Promise.resolve(Bookshelf.knex.raw(
            `SELECT o.OrderId, o.FirstName, o.LastName, o.CoFirstName, o.CoLastName, o.HomePhone, o.CoHomePhone, o.WorkPhone, o.CoWorkPhone, o.Email, o.CoEmail,
            o.IsCoBasicAccess, o.IsCoDocReview, o.IsPrimaryBasicAccess, o.IsPrimaryDocReview,  o.IsVenOrCEDefineADT, o.LanguageId, o.CoLanguageId
            FROM \`order\` o
            WHERE o.OrderId = ${orderId};`));
        const getDefaultLanguage = Promise.resolve(Bookshelf.knex.raw(`SELECT l.LanguageID FROM \`language\` l where l.Language="English";`));

        Promise.all([getListLanguage, getDefaultOrderCustomer, getDefaultLanguage])
            .then(value => {
                const data = {};

                if (value !== null) {

                    value.forEach((item, index) => {
                        if (item) {
                            switch (index) {
                                case 0:
                                    data.listLanguages = item[0];
                                    break;
                                case 1:
                                    data.defaultValue = item[0][0];
                                    data.defaultValue.IsCoBasicAccess = bufferToBoolean(data.defaultValue.IsCoBasicAccess);
                                    data.defaultValue.IsCoDocReview = bufferToBoolean(data.defaultValue.IsCoDocReview);
                                    data.defaultValue.IsPrimaryBasicAccess = bufferToBoolean(data.defaultValue.IsPrimaryBasicAccess);
                                    data.defaultValue.IsPrimaryDocReview = bufferToBoolean(data.defaultValue.IsPrimaryDocReview);
                                    data.defaultValue.IsVenOrCEDefineADT = bufferToBoolean(data.defaultValue.IsVenOrCEDefineADT);
                                    break;
                                case 2:
                                    data.defaultLanguageId = item[0][0].LanguageID;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }
}

export default new OrderCustomerController();