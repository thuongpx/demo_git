import Boom from "boom";
import appConfig from "../../config/config";
import fs from "fs";
import Bookshelf from "../../db/database";
import {
    handleSingleQuote
} from "../../helper/common-helper";
import { TOOL_PAGE_DISPLAY } from "../../constant/common-constant";

class ToolController {
    constructor() { }
    getListResource(request, reply) {

        const sqlQuery = `SELECT * FROM resources;`;

        Bookshelf.knex.raw(sqlQuery)
            .then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        isNotFound: false,
                        listResource: result[0]
                    });
                } else {
                    reply({ isSuccess: false, isNotFound: true });
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
        return;
    }

    downloadResources(request, reply) {
        const {
            fileName
        } = request.query;

        const filePath = `${appConfig.file.serverPath}/upload/resources/${fileName}`;

        if (fs.existsSync(filePath)) {
            fs.readFile(filePath, (err, data) => {
                if (err) reply(Boom.badRequest(err.message));
                return reply(data).header("content-disposition", `attachment; filename=${fileName}`);
            });
        } else {
            reply(Boom.badRequest(`File ${filePath} is not exists.`));
        }
    }

    getListLink(request, reply) {
        const {
            typePage,
            pageDisplay
        } = request.payload;
        console.log(`type: ${typePage}`);
        console.log(`pageDisplay: ${pageDisplay}`);

        let listType = ``;

        typePage.forEach((item, index) => {
            if (index === 0) listType = `(`;
            listType = `${listType}'${item.key}'`;
            if (index < typePage.length - 1) {
                listType = `${listType},`;
            } else {
                listType = `${listType})`;
            }
        });

        console.log(listType);

        if (pageDisplay === true) {
            const sqlQuery = `SELECT Id, LinkTitle, Link, Description, Type, Target
            FROM links ${typePage.length > 0 ? `WHERE Views in ${listType}` : ""}`;
            console.log(sqlQuery);
            Bookshelf.knex.raw(sqlQuery)
                .then((result) => {
                    if (result !== null) {
                        reply({
                            isSuccess: true,
                            isNotFound: false,
                            isStaff: true,
                            isClient: false,
                            isVendor: false,
                            links: result[0]
                        });
                    } else {
                        reply({
                            isSuccess: false, isNotFound: true,
                            isStaff: true,
                            isClient: false,
                            isVendor: false
                        });
                    }
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });
        } else {
            const sqlQuery = `SELECT Id, LinkTitle, Link, Description, Type, Target
            FROM links`;
            console.log("2 cc");
            Bookshelf.knex.raw(sqlQuery)
                .then((result) => {
                    if (result !== null) {
                        reply({
                            isSuccess: true,
                            isNotFound: false,
                            isStaff: false,
                            isClient: false,
                            isVendor: false,
                            links: result[0]
                        });
                    } else {
                        reply({
                            isSuccess: false, isNotFound: true,
                            isStaff: false,
                            isClient: false,
                            isVendor: false
                        });
                    }
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });
        }
        return;

    }

    getFaqsByQuestion(request, reply) {
        const { question } = request.query;

        const newQuestion = (question === "" || question === undefined) ? "" : handleSingleQuote(question);

        const sqlQuery = `SELECT Id, SectId, Question, Answer, Views
        FROM faq
        WHERE Question LIKE '%${newQuestion}%'`;

        Bookshelf.knex.raw(sqlQuery)
            .then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        faqs: result[0]
                    });
                    return;
                }
                reply({ isSuccess: false, isNotFound: true });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        return;
    }

    getPageDisplayFromConstant(request, reply) {
        // console.log(TOOL_PAGE_DISPLAY);
        reply({
            listPage: TOOL_PAGE_DISPLAY
        });
    }

    getListResourceByViews(request, reply) {
        const {
            typePage
        } = request.query;
        console.log(typePage);
        const sqlQuery = `SELECT * FROM resources WHERE Views = '${typePage}'`;

        Bookshelf.knex.raw(sqlQuery)
            .then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        isNotFound: false,
                        isStaff: true,
                        isClient: false,
                        isVendor: false,
                        listResource: result[0]
                    });
                } else {
                    reply({
                        isSuccess: false, isNotFound: true,
                        isStaff: true,
                        isClient: false,
                        isVendor: false
                    });
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }

    /* getListLinksByViews(request, reply) {
        const {
            typePage
        } = request.query;
        console.log(typePage);
        const sqlQuery = `SELECT * FROM links WHERE Views = '${typePage}'`;

        Bookshelf.knex.raw(sqlQuery)
            .then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        isNotFound: false,
                        isStaff: true,
                        isClient: false,
                        isVendor: false,
                        links: result[0]
                    });
                } else {
                    reply({
                        isSuccess: false, isNotFound: true,
                        isStaff: true,
                        isClient: false,
                        isVendor: false
                    });
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    } */

    addLinksToDataBase(request, reply) {
        const {
            linkTitle, link, type, target, description, views
        } = request.payload;


        // let newType = "";
        // if (type === "General") {
        //     newType = "G";
        // } else if (type === "Client") {
        //     newType = "C";
        // } else {
        //     newType = "V";
        // }

        // let newTarget = "";
        // if (target === "External") {
        //     newTarget = "_blank";
        // } else if (target === "Internal") {
        //     newTarget = "_self";
        // }

        const sqlQuery = `INSERT INTO links (LinkTitle, Link, Description, Type, Target, Views)
                VALUES ('${linkTitle}', '${link}', '${description}', '${type}', '${target}', '${views}');
        `;
        console.log(sqlQuery);
        Bookshelf.knex.raw(sqlQuery).then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });

            }
            reply({
                isSuccess: false,
                isNotFound: true
            });
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }

    deleteLinksById(request, reply) {
        const {
            Id
        } = request.query;
        console.log(`Id: ${Id}`);

        const sqlQuery = `DELETE FROM links WHERE Id = ${Id}`;
        console.log(sqlQuery);
        Bookshelf.knex.raw(sqlQuery).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });

    }

    editLinksById(request, reply) {
        const {
            linkId, Title, Link, type, target, Description, views
        } = request.payload;

        // let newType = "";
        // if (type === "General") {
        //     newType = "G";
        // } else if (type === "Client") {
        //     newType = "C";
        // } else {
        //     newType = "V";
        // }

        // let newTarget = "";
        // if (target === "External") {
        //     newTarget = "_blank";
        // } else if (target === "Internal") {
        //     newTarget = "_self";
        // }
        console.log(`Id: ${linkId}`);

        const sqlQuery = `UPDATE links SET
            LinkTitle = '${Title}', Link = '${Link}', Description = '${Description}', Type = '${type}', Target = '${target}', Views = '${views}'
            WHERE Id = ${linkId}`;
        console.log(sqlQuery);
        Bookshelf.knex.raw(sqlQuery).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }
}

export default new ToolController();