import TrainingCourseController from "./training-courses-controller";

const routes = [
    {
        path: "/training-courses/getCourses",
        method: "GET",

        handler: TrainingCourseController.getCourses
    },
    {
        path: "/training-courses/getCourseById",
        method: "GET",
        handler: TrainingCourseController.getCourseById
    },
    {
        path: "/training-courses/deleteCourse",
        method: "GET",
        handler: TrainingCourseController.deleteCourse
    },
    {
        path: "/training-courses/addCourse",
        method: "POST",
        config: {
            auth: false,
            payload: {
                output: "stream",
                maxBytes: 1024 * 1024 * 20, // max: 20 MB
                allow: "multipart/form-data"
            }
        },
        handler: TrainingCourseController.addCourse
    },
    {
        path: "/training-courses/updateCourse",
        method: "POST",
        config: {
            auth: false,
            payload: {
                output: "stream",
                maxBytes: 1024 * 1024 * 20, // max: 20 MB
                allow: "multipart/form-data"
            }
        },
        handler: TrainingCourseController.updateCourse
    },
    {
        path: "/training-courses/changeStatusCourse",
        method: "GET",
        handler: TrainingCourseController.changeStatusCourse
    },
    {
        path: "/training-courses/checkExistCourseName",
        method: "GET",
        handler: TrainingCourseController.checkExistCourseName
    }
];

export default routes;