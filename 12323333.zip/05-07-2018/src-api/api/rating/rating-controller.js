import Boom from "boom";
import Rating from "./../../db/model/rating";

class RatingController {
    constructor() { }
    getRatings(request, reply) {
        new Rating().fetchAll({ columns: ["ratingId", "rating"] }).then((ratings) => {
            reply(ratings);
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}
export default new RatingController();