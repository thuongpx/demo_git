import TrainingProgramController from "./training-program-controller";
const routes = [
    {
        path: "/training-program/getTrainingPrograms",
        method: "GET",
        handler: TrainingProgramController.getTrainingPrograms
    },
    {
        path: "/training-program/countCoursesTestsById",
        method: "GET",
        handler: TrainingProgramController.countCoursesTestsById
    },
    {
        path: "/training-program/getInputProgagram",
        method: "GET",
        handler: TrainingProgramController.getInputProgagram
    },
    {
        path: "/training-program/updateTraningProgram",
        method: "POST",
        handler: TrainingProgramController.updateTraningProgram
    },
    {
        path: "/training-program/deleteTrainingProgram",
        method: "POST",
        handler: TrainingProgramController.deleteTrainingProgram
    },
    {
        path: "/training-program/publicUnPublicTrainingProgram",
        method: "POST",
        handler: TrainingProgramController.publicUnPublicTrainingProgram
    },
    {
        path: "/training-program/checkProgramName",
        method: "GET",
        handler: TrainingProgramController.checkProgramName
    }
];

export default routes;