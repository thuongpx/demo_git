import Bookshelf from "../../db/database";
import Boom from "boom";
import BusinessHours from "../../db/model/business-hours";
import BizHoursExcept from "../../db/model/biz-hours-except";
import {
    isBuffer,
    bufferToBoolean
} from "../../helper/common-helper";
import moment from "moment";

class BusinessHoursController {

    addBizHoursExcept(request, reply) {
        const bizHoursExcept = request.payload;
        let openTime = "";
        let closeTime = "";

        if (bizHoursExcept.startTime === "" || bizHoursExcept.startTime === "Invalid date" || bizHoursExcept.endTime === "" || bizHoursExcept.endTime === "Invalid date") {
            openTime = moment(`${bizHoursExcept.fromDate} ${"00:00:00"}`).format("YYYY-MM-DD HH:mm:ss");
            closeTime = moment(`${bizHoursExcept.toDate} ${"23:59:59"} `).format("YYYY-MM-DD HH:mm:ss");
        } else {
            openTime = moment(`${bizHoursExcept.fromDate} ${bizHoursExcept.startTime} `).format("YYYY-MM-DD HH:mm:ss");
            closeTime = moment(`${bizHoursExcept.toDate} ${bizHoursExcept.endTime} `).format("YYYY-MM-DD HH:mm:ss");
        }

        new BizHoursExcept().save({
            Description: bizHoursExcept.description,
            Closed: bizHoursExcept.closed,
            OpenTime: `${(openTime === "Invalid date") ? null : openTime} `,
            CloseTime: `${(closeTime === "Invalid date") ? null : closeTime} `
        }, { method: "insert" }).then(() => {
            reply({
                isSuccess: true
            });
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }

    getBizHoursExcept(request, reply) {
        const { sortColumn, sortDirection, page, itemPerPage } = request.query;
        const rawSql = `CALL GetBizHoursExcept('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage});`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                const data = result[0][0];

                data.map((item, index) => {
                    Object.keys(item).forEach((key) => {
                        const value = item[key];

                        if (isBuffer(value)) {
                            item[key] = bufferToBoolean(value);
                        }

                        switch (key) {
                            case "openTime":
                                // const dateTime = moment(value).utc().format("YYYY-MM-DD HH:mm:ss").toString();
                                item.openTime = moment(value).utc().format("h:mm A").toString();
                                item.startDate = moment(value).utc().format("MM/DD/YYYY").toString();
                                break;
                            case "closeTime":
                                item.closeTime = moment(value).utc().format("h:mm A").toString();
                                item.endDate = moment(value).utc().format("MM/DD/YYYY").toString();
                                break;
                        }
                    });
                    item.index = index + 1;
                });

                reply({
                    bizHoursExcept: data,
                    totalRecords: result[0][1][0].TotalRecords
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });


        // queue.push(Promise.resolve(Bookshelf.knex.raw(rawSql)));

        // Promise.all(queue)
        //     .then((result) => {
        //         if (result !== null) {
        //             const data = result[0][0];

        //             data.map((item, index) => {
        //                 Object.keys(item).forEach((key) => {
        //                     const value = item[key];

        //                     if (isBuffer(value)) {
        //                         item[key] = bufferToBoolean(value);
        //                     }

        //                     switch (key) {
        //                         case "openTime":
        //                             // const dateTime = moment(value).utc().format("YYYY-MM-DD HH:mm:ss").toString();
        //                             item.openTime = moment(value).utc().format("h:mm A").toString();
        //                             item.startDate = moment(value).utc().format("MM/DD/YYYY").toString();
        //                             break;
        //                         case "closeTime":
        //                             item.closeTime = moment(value).utc().format("h:mm A").toString();
        //                             item.endDate = moment(value).utc().format("MM/DD/YYYY").toString();
        //                             break;
        //                     }
        //                 });
        //                 item.index = index;
        //             });

        //             reply({
        //                 bizHoursExcept: data,
        //                 totalRecords: result[1][0][0].totalRecords
        //             });
        //         }
        //     }).catch((error) => {
        //         reply(Boom.badRequest(error));
        //     });
    }

    deleteBizHoursExcept(request, reply) {
        const exceptId = request.payload;

        BizHoursExcept.where(exceptId).destroy().then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    updateBusinessHours(request, reply) {
        const businessHours = request.payload;
        const currentDate = moment().format("YYYY-MM-DD");

        businessHours.map(item => {
            BusinessHours.where({ BussinessHoursId: item.bussinessHoursId }).save({
                IsClose: item.isClose,
                OpenTime: moment(`${currentDate} ${item.openTime} `).format("YYYY-MM-DD HH:mm:ss"),
                CloseTime: moment(`${currentDate} ${item.closeTime} `).format("YYYY-MM-DD HH:mm:ss"),
                LastUpdate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
            }, { method: "update" }).then(() => { reply({ isSuccess: true }); }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        });
    }

    getBusinessHours(request, reply) {
        const rawSql = "SELECT BussinessHoursId AS bussinessHoursId, Day As day, OpenTime AS openTime, CloseTime AS closeTime, IsClose AS isClose FROM business_hours;";

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result[0] !== null) {
                const data = result[0];
                data.map(item => {
                    Object.keys(item).forEach((key) => {
                        const value = item[key];

                        if (isBuffer(value)) {
                            item[key] = bufferToBoolean(value);
                        }

                        switch (key) {
                            case "openTime":
                                item.openTime = moment(value).utc().format("h:mm A").toString();
                                break;
                            case "closeTime":
                                item.closeTime = moment(value).utc().format("h:mm A").toString();
                                break;
                            case "day":
                                switch (item.day) {
                                    case "Mon":
                                        item.day = "Monday";
                                        break;
                                    case "Tue":
                                        item.day = "Tuesday";
                                        break;
                                    case "Wed":
                                        item.day = "Wednesday";
                                        break;
                                    case "Thu":
                                        item.day = "Thursday";
                                        break;
                                    case "Fri":
                                        item.day = "Friday";
                                        break;
                                    case "Sat":
                                        item.day = "Saturday";
                                        break;
                                    case "Sun":
                                        item.day = "Sunday";
                                        break;
                                }
                                break;
                        }
                    });
                });
                reply({
                    businessHours: result[0]
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }


}

export default new BusinessHoursController();