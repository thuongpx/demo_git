import CredentialDocumentController from "./credential-document-controller";
const routes = [
    {
        path: "/credential-document/getCredentialDocument",
        method: "GET",
        handler: CredentialDocumentController.getCredentialDocument
    },
    {
        path: "/credential-document/deleteCredentialDocument",
        method: "POST",
        handler: CredentialDocumentController.deleteCredentialDocument
    },
    {
        path: "/credential-document/addCredentialDocument",
        method: "POST",
        handler: CredentialDocumentController.addCredentialDocument
    },
    {
        path: "/credential-document/updateCredentialDocument",
        method: "POST",
        handler: CredentialDocumentController.updateCredentialDocument
    },
    {
        path: "/credential-document/checkExistCredentialDocument",
        method: "GET",
        handler: CredentialDocumentController.checkExistCredentialDocument
    },
    {
        path: "/credential-document/getStates",
        method: "GET",
        handler: CredentialDocumentController.getStates
    }
];

export default routes;