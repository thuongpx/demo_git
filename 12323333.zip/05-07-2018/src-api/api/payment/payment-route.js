import PaymentController from "./payment-controller";

const routes = [
    {
        path: "/payment/requestPaymentToken",
        config: { auth: false },
        method: "POST",
        handler: PaymentController.requestPaymentToken
    },
    {
        path: "/payment/removePaymentMethod",
        config: { auth: false },
        method: "POST",
        handler: PaymentController.removePaymentMethod
    },
    {
        path: "/payment/removeBraintreeCustomer",
        config: { auth: false },
        method: "POST",
        handler: PaymentController.removeBraintreeCustomer
    }
];

export default routes;