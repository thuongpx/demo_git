import ClientDetailController from "./client-detail-controller";

const routes = [
    //specifics
    {
        path: "/clientDetail/getClientSpecifics",
        method: "GET",
        handler: ClientDetailController.getClientSpecifics
    },

    {
        path: "/clientDetail/updateClientSpecifics",
        method: "POST",
        handler: ClientDetailController.updateClientSpecifics
    },

    {
        path: "/clientDetail/addClientSpecifics",
        method: "POST",
        handler: ClientDetailController.addClientSpecifics
    },

    //recent orders
    {
        path: "/clientDetail/getRecentOrders",
        method: "GET",
        handler: ClientDetailController.getRecentOrders
    },
    //do not use
    {
        path: "/clientDetail/getAvailableSigner",
        method: "GET",
        handler: ClientDetailController.getAvailableSigner
    },
    {
        path: "/clientDetail/getBlackListSigner",
        method: "GET",
        handler: ClientDetailController.getBlackListSigner
    },
    {
        path: "/clientDetail/updateBlackListSigner",
        method: "POST",
        handler: ClientDetailController.updateBlackListSigner
    },
    {
        path: "/clientDetail/updateWhiteListSigner",
        method: "POST",
        handler: ClientDetailController.updateWhiteListSigner
    }
];

export default routes;