import Bookshelf from "../../db/database";
import Boom from "boom";

import { distinctSingleValueArray } from "../../helper/common-helper";
import { getOrderTypes } from "./canned-report";

class CannedReportController {
	constructor() { }

	async getInitDataForCannedReport(request, reply) {
		// get order types list
		const orderTypes = await getOrderTypes();

		reply({
			orderTypes: distinctSingleValueArray(orderTypes.map(i => i.LoanType))
		});
	}

	fetchDataOfOpenOrderChart(request, reply) {
		const {
			orderStatus,
			orderType
		} = request.payload;

		let rawSql = `SELECT * FROM open_order_chart_v WHERE 1 = 1`;
		let tSql = "";
		let isShowAll = true;

		// order type
		if (orderType && orderType.length > 0) {
			tSql = "1 != 1";
			for (let i = 0; i < orderType.length; i++) {
				tSql += ` OR OrderType LIKE '${orderType[i].value || ""}'`;
			}

			rawSql += ` AND (${tSql})`;
			isShowAll = false;
		}

		// order status
		if (orderStatus && orderStatus.length > 0) {
			tSql = "1 != 1";
			for (let i = 0; i < orderStatus.length; i++) {
				tSql += ` OR OrderStatus LIKE '${orderStatus[i].value || ""}'`;
			}

			rawSql += ` AND (${tSql})`;
			isShowAll = false;
		}

		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null) {
					const rawData = result[0];

					// build labels
					const labels = distinctSingleValueArray(rawData.map(i => i.OrderStatus));

					// build datasets
					const orderTypes = distinctSingleValueArray(rawData.map(i => i.OrderType));

					const datasets = [];

					if (isShowAll) {
						const tData = {
							label: "All Data",
							data: []
						};

						for (let i = 0; i < labels.length; i++) {
							const f = rawData.filter(rd => rd.OrderStatus === labels[i]);
							const r = f.reduce((a, c) => {
								return {
									Count: a.Count + c.Count
								};
							});

							tData.data.push(r.Count);
						}

						datasets.push(tData);
					} else {
						for (let o = 0; o < orderTypes.length; o++) {
							const tData = {
								label: orderTypes[o],
								data: []
							};

							for (let i = 0; i < labels.length; i++) {
								const f = rawData.find(r => {
									return r.OrderType === orderTypes[o] && r.OrderStatus === labels[i];
								});

								tData.data.push(f ? f.Count : 0);
							}

							datasets.push(tData);
						}
					}

					reply({
						labels,
						datasets
					});
				}

				return reply;
			}).catch((error) => {
				reply(Boom.badRequest(error));

				return reply;
			});
	}
}

export default new CannedReportController();