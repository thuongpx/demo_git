import BranchController from "./branch-controller";
import BranchManagemetController from "./branch-management-controller";

const routes = [{
        path: "/branch/getBranchesForDropdown",
        method: "GET",
        handler: BranchController.getBranchesForDropdown
    }, {
        path: "/branch/lockBranch",
        method: "GET",
        handler: BranchController.lockBranch
    },
    {
        path: "/branch/getAllBranch",
        method: "GET",
        handler: BranchManagemetController.getAllBranch
    },
    {
        path: "/branch/getBranchNameByKeyword",
        method: "GET",
        handler: BranchController.getBranchNameByKeyword
    },
    {
        path: "/branch/getBranchManagementData",
        method: "POST",
        handler: BranchController.getBranchManagementData
    },
    {
        path: "/branch/updateBranch",
        method: "POST",
        handler: BranchController.updateBranch
    },
    {
        path: "/branch/checkBranchMergeable",
        method: "GET",
        handler: BranchController.checkBranchMergeable
    },
    {
        path: "/branch/mergeBranch",
        method: "GET",
        handler: BranchController.mergeBranch
    },
    {
        path: "/branch/disableBranch",
        method: "GET",
        handler: BranchController.disableBranch
    },
    {
        path: "/branch/enableBranch",
        method: "POST",
        config: {
            auth: false
        },
        handler: BranchController.activeBranch
    }
];

export default routes;