import ProductTypeController from "./product-type-controller";
const routes = [
    {
        path: "/product-type/getProductType",
        method: "GET",
        handler: ProductTypeController.getProductType
    },
    {
        path: "/product-type/deleteProductType",
        method: "POST",
        handler: ProductTypeController.deleteProductType
    },
    {
        path: "/product-type/addProductType",
        method: "POST",
        handler: ProductTypeController.addProductType
    },
    {
        path: "/product-type/updateProductType",
        method: "POST",
        handler: ProductTypeController.updateProductType
    },
    {
        path: "/product-type/checkExistProductType",
        method: "GET",
        handler: ProductTypeController.checkExistProductType
    }
];

export default routes;