import AnnouncementsControler from "./announcements-controller";

const routes = [{
    path: "/announcements/getAnnouncementsByUserId",
    method: "GET",
    config: {
        auth: false
    },
    handler: AnnouncementsControler.getAnnouncementsByUserId
},
{
    path: "/announcements/addUpdateUserAnnouncements",
    method: "POST",
    config: {
        auth: false
    },
    handler: AnnouncementsControler.addUpdateUserAnnouncements
}, {
    path: "/announcements/getVendorAnnouncements",
    method: "GET",
    config: {
        auth: false
    },
    handler: AnnouncementsControler.getVendorAnnouncements
}, {
    path: "/announcements/getUserUnreadAnnouncements",
    method: "GET",
    config: {
        auth: false
    },
    handler: AnnouncementsControler.getUserUnreadAnnouncements
}, {
    path: "/announcements/getUserReadAnnouncements",
    method: "GET",
    config: {
        auth: false
    },
    handler: AnnouncementsControler.getUserReadAnnouncements
},
{
    path: "/announcements/updateReadUserAnnouncement",
    method: "POST",
    config: {
        auth: false
    },
    handler: AnnouncementsControler.updateReadUserAnnouncement
}, {
    path: "/announcements/getTotalUnreadAnnouncement",
    method: "GET",
    config: {
        auth: false
    },
    handler: AnnouncementsControler.getTotalUnreadAnnouncement
}
];

export default routes;