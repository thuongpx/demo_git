export default {
	host: "localhost",
	port: 3001,
	secretKey: "lF7ioZHOa4iafmUfhcWwkUFRb7P7F09K"
};
