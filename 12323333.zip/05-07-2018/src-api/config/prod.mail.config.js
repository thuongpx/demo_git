export default {
        host: "notarydirect-com.mail.protection.outlook.com",
        port: 25,
        timeout: 10
};