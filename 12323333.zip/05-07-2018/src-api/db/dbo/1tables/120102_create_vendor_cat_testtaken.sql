CREATE TABLE IF NOT EXISTS `vendor_cat_testtaken` (
	Id INT(11) NOT NULL AUTO_INCREMENT,
    CatId INT NULL,
    TestId INT NULL,
    PRIMARY KEY (`Id`),
    KEY `vendor_cat_testtaken_catid` (`CatId`),
    CONSTRAINT `catid_vendor_category` FOREIGN KEY (`CatId`) 
		REFERENCES `vendor_categories` (`CatId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
	KEY `vendor_cat_testtaken_testid`(`TestId`),
    CONSTRAINT `testid_vendor_category`FOREIGN KEY (`TestId`)
		REFERENCES `test_info` (`TestId`) ON DELETE NO ACTION ON UPDATE NO ACTION
);