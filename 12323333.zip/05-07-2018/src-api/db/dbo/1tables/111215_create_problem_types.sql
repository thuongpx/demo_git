CREATE TABLE IF NOT EXISTS `problem_types` (
    `Id` INT(11) NOT NULL AUTO_INCREMENT,
    `Description` VARCHAR(100),
    PRIMARY KEY (`Id`)
);



