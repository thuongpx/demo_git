CREATE TABLE IF NOT EXISTS `signer_language` (
    `SlId` INT(11) NOT NULL AUTO_INCREMENT,
    `SignerId` INT(11),
	`LanguageId` INT(11),
    PRIMARY KEY (`SlId`),
    KEY `signerId_signer_language_idx`(`SignerId`),
    CONSTRAINT `signerId_signer_language` FOREIGN KEY(`SignerId`) REFERENCES `signer`(`SignerId`) ON UPDATE NO ACTION ON DELETE NO ACTION,
    KEY `languageId_signer_language_idx`(`LanguageId`),
    CONSTRAINT `languageId_signer_language` FOREIGN KEY(`LanguageId`) REFERENCES `language`(`LanguageId`) ON UPDATE NO ACTION ON DELETE NO ACTION
);