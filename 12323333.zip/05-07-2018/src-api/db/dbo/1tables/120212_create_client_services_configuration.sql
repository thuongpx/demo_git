use tce_dev;

CREATE TABLE IF NOT EXISTS `client_services_config` (
	`ConfigId` INT NOT NULL AUTO_INCREMENT,
    `ClientID` INT NULL,
    `CreatedDate` DATETIME NULL,
    `CreatedBy` INT NULL,
    `UpdatedDate` DATETIME NULL,
    `UpdatedBy` INT NULL,
    `Status` INT(11) NULL,
    `EffecttiveDate` DATETIME NULL,
    `ApprovedBy` INT NULL,
    `UseVolume` BIT NULL,
    `OrderPerDay` TINYINT NULL,
    `UseCalendar` BIT NULL,
    `CutoffDate` TINYINT NULL,
    `UseGeography` BIT NULL,
    `State1` VARCHAR(200) NULL,
    `MSA1` VARCHAR(500) NULL,
    PRIMARY KEY (`ConfigId`),
    KEY `clientid_client_services_config_idx` (`ClientID`),
    CONSTRAINT `clientid_client_services_config` FOREIGN KEY(`ClientID`)
		REFERENCES `broker` (`BrokerId`) ON UPDATE NO ACTION ON DELETE NO ACTION
);