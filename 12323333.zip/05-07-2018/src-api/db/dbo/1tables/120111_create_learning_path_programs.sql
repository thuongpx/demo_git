CREATE TABLE IF NOT EXISTS `training_lp_programs` (
	`Id` INT(11) NOT NULL AUTO_INCREMENT,
    `ProgramId` INT(11) NOT NULL,
	`LPID` INT(11) NULL,
    `SortOrder` SMALLINT NULL,
    PRIMARY KEY (`Id`),
	KEY `programid_learning_path_programs_idx` (`ProgramId`),
	CONSTRAINT `programid_learning_path_programs` FOREIGN KEY (`ProgramId`) REFERENCES `training_programs` (`ProgramId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
    KEY `lpid_learning_path_programs_idx` (`LPID`),
	CONSTRAINT `lpid_learning_path_programs` FOREIGN KEY (`LPID`) REFERENCES `training_learning_path` (`LPID`) ON DELETE NO ACTION ON UPDATE NO ACTION
);