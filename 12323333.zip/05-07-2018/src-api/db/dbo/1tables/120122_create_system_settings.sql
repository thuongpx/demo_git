use tce_dev;

CREATE TABLE IF NOT EXISTS `system_settings` (
	Id INT(11) NOT NULL AUTO_INCREMENT,
    TwilioId VARCHAR(100) NULL,
    TwilioToken VARCHAR(100) NULL,
    TwilioFrom VARCHAR(15) NULL,
    StandardClientFee DECIMAL(19, 4),
    PrimeClientFee DECIMAL(19, 4),
    EliteClientFee DECIMAL(19, 4),
    PRIMARY KEY (`Id`)
);
