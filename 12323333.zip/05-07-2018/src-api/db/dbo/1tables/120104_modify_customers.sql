ALTER TABLE `customers` ADD COLUMN `IsActive` BIT NULL;
ALTER TABLE `customers` ADD COLUMN `ReqRateNew` BIT(1) NULL;
ALTER TABLE `customers` ADD COLUMN `ReqRateGood` BIT(1) NULL;
ALTER TABLE `customers` ADD COLUMN `ReqRateVeryGood` BIT(1) NULL;
ALTER TABLE `customers` ADD COLUMN `ReqRateExellent` BIT(1) NULL;