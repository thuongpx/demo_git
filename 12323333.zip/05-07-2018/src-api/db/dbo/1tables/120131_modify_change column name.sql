use tce_dev;

-- table order
ALTER TABLE `order`
CHANGE COLUMN `IsActive` `Inactive` BIT;

UPDATE `order`
SET Inactive = 0 WHERE Inactive=1 and orderid <> 0;

-- table customer
ALTER TABLE `customers`
CHANGE COLUMN `IsActive` `Inactive` BIT;

UPDATE `customers`
SET Inactive = 0 WHERE Inactive=1 and CustomerId <> 0;

-- table test_qa
ALTER TABLE `test_qa`
CHANGE COLUMN `IsActive` `Inactive` BIT;

UPDATE `test_qa`
SET Inactive = 0 WHERE Inactive=1 and QuestionId <> 0;

-- table training_courses
ALTER TABLE `training_courses`
CHANGE COLUMN `IsActive` `Inactive` BIT;

UPDATE `training_courses`
SET Inactive = 0 WHERE Inactive=1 and CourseId <> 0;

-- table training_programs
ALTER TABLE `training_programs`
CHANGE COLUMN `IsActive` `Inactive` BIT;

UPDATE `training_programs`
SET Inactive = 0 WHERE Inactive=1 and ProgramId <> 0;

-- table users
ALTER TABLE `users`
CHANGE COLUMN `IsActive` `Inactive` BIT;

UPDATE `users`
SET Inactive = 0 WHERE Inactive=1 and UsersId <> 0;


