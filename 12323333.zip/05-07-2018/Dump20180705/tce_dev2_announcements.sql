-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `AnnouncementID` int(11) NOT NULL AUTO_INCREMENT,
  `CreatedDate` datetime DEFAULT NULL,
  `Title` varchar(100) DEFAULT NULL,
  `Content` varchar(4000) DEFAULT NULL,
  `Audience` varchar(50) DEFAULT NULL,
  `Status` varchar(15) DEFAULT NULL,
  `NumOfAppearance` tinyint(4) DEFAULT NULL,
  `PublishedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`AnnouncementID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES (1,'2018-04-24 14:25:06','Huent6 add','<p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p>','Vendors','Published',3,'2018-06-22 01:44:09'),(2,'2018-04-24 15:35:32','Test add no','<p>Hello</p>\n\n<p>ABC</p>','Vendors','Published',5,'2018-06-20 00:00:00'),(3,'2018-06-14 15:35:32','Name Test','<p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p><p>hello client</p>','Vendors','Published',3,'2018-06-21 01:44:12'),(5,'2018-06-21 03:50:00','Khanh','<p>khanh</p>','Client Admins/Managers','Published',1,'2018-06-21 03:51:20'),(6,'2018-06-21 03:54:45','khanh 2','<p>12312321</p>','Client Agents','Published',1,'2018-06-21 03:55:03'),(7,'2018-06-21 03:55:29','khanh3','<p>123123123</p>','Client Agents','Published',1,'2018-06-21 03:55:37'),(8,'2018-06-25 02:30:56','Test','<p>Test</p>','Client Admins/Managers','Unpublished',1,'2018-06-25 02:59:33');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-05 19:31:12
