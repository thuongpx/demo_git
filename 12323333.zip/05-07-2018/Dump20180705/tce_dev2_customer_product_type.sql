-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_product_type`
--

DROP TABLE IF EXISTS `customer_product_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_product_type` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CustomerId` int(11) NOT NULL,
  `ProductType` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `customerid_customer_product_type_idx` (`CustomerId`),
  KEY `loantype_customer_product_type_idx` (`ProductType`),
  CONSTRAINT `customerid_customer_product_type` FOREIGN KEY (`CustomerId`) REFERENCES `customers` (`CustomerId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `loantype_customer_product_type` FOREIGN KEY (`ProductType`) REFERENCES `loan_type` (`LoanTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=395 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_product_type`
--

LOCK TABLES `customer_product_type` WRITE;
/*!40000 ALTER TABLE `customer_product_type` DISABLE KEYS */;
INSERT INTO `customer_product_type` VALUES (5,4,3),(6,4,4),(7,4,6),(14,6,2),(15,6,3),(16,6,5),(17,7,2),(18,7,3),(19,7,5),(20,8,3),(21,8,4),(22,8,6),(23,5,3),(24,5,6),(25,5,4),(30,9,3),(31,9,4),(32,9,5),(33,9,6),(34,9,2),(40,10,2),(41,10,3),(42,10,10),(43,10,11),(44,10,12),(45,10,13),(46,10,9),(56,11,14),(64,16,5),(65,16,6),(66,17,1),(67,17,5),(341,2,1),(342,2,4),(343,2,3),(344,2,2),(382,13,3),(386,18,5),(387,18,1),(391,19,10),(392,19,14),(394,14,3);
/*!40000 ALTER TABLE `customer_product_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-05 19:31:12
