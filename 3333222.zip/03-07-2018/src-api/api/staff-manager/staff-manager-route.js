import ApprovalController from "./approval-controller";
const routes = [
    {
        path: "/staff-manager/getNumberApprovals",
        method: "GET",
        handler: ApprovalController.getNumberApprovals
    }
];

export default routes;