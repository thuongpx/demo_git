import ClientProfileCredentialsController from "./client-profile-credentials-controller";

const routes = [{
    path: "/client-profile/getUserProfileCredentials",
    method: "GET",
    handler: ClientProfileCredentialsController.getUserProfileCredentials
},
{
    path: "/client-profile/updateUserProfileCredentials",
    method: "POST",
    handler: ClientProfileCredentialsController.updateUserProfileCredentials
}
];

export default routes;