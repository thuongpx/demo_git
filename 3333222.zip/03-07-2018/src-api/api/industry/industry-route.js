import industryController from "./industry-controller";

const routes = [{
    path: "/industry/getAllIndustry",
    method: "GET",
    config: {
        auth: false
    },
    handler: industryController.getAllIndustry
}, {
    path: "/industry/getIndustries",
    method: "POST",
    handler: industryController.getIndustries
}, {
    path: "/industry/deleteIndustry",
    method: "POST",
    handler: industryController.deleteIndustry
}, {
    path: "/industry/checkExistIndustry",
    method: "POST",
    handler: industryController.checkExistIndustry
}, {
    path: "/industry/updateIndustry",
    method: "POST",
    handler: industryController.updateIndustry
}, {
    path: "/industry/addIndustry",
    method: "POST",
    handler: industryController.addIndustry
}];

export default routes;