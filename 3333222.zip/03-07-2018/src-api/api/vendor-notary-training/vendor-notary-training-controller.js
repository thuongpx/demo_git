import Bookshelf from "../../db/database";
import Boom from "boom";
import {
    handleSingleQuote,
    bufferToBoolean
} from "../../helper/common-helper";
import moment from "moment"; import {
    UPLOAD_PATH
} from "../../helper/file-helper";
import fs from "fs";

class NotaryTraning {
    getlistRegisteredPrograms(request, reply) {
        const {
            searchValue,
            userId
        } = request.query;
        const newSearchValue = (searchValue === "" || searchValue === undefined) ? "" : handleSingleQuote(searchValue);
        const rawSql = `SELECT distinct vrp.ProgramId, tp.Title, tp.Description, vrp.IsComplete
        FROM vendor_registered_programs vrp
        INNER JOIN training_programs tp ON vrp.ProgramId = tp.ProgramId and IsPublished = 1 and ForVendor = 1
        LEFT JOIN training_program_courses tpc ON vrp.ProgramId = tpc.ProgramId
        LEFT JOIN training_courses tc ON tpc.CourseId = tc.CourseId and tc.Inactive = 0
        WHERE vrp.VendorId = ${userId} and (tp.Title LIKE '%${newSearchValue}%' or tp.Description LIKE '%${newSearchValue}%' or tc.Title LIKE '%${newSearchValue}%') order by Title;`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    const data = result[0];
                    data.map(item => {
                        item.IsComplete = bufferToBoolean(item.IsComplete);
                    });
                    reply({
                        isSuccess: true,
                        listRegisteredProgram: result[0]
                    });
                    return;
                }
                reply({
                    isSuccess: false,
                    isNotFound: true
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getlistAllPrograms(request, reply) {
        const {
            searchValue,
            userId
        } = request.query;
        const newSearchValue = (searchValue === "" || searchValue === undefined) ? "" : handleSingleQuote(searchValue);
        const rawSql = `SELECT tp.ProgramId, tp.Title, tp.Description
        FROM  training_programs tp
        LEFT JOIN training_program_courses tpc ON tp.ProgramId = tpc.ProgramId
        LEFT JOIN training_courses tc ON tpc.CourseId = tc.CourseId and tc.Inactive = 0
        WHERE tp.ForVendor = 1 and tp.Inactive = 0 and (tp.Title LIKE '%${newSearchValue}%' or tp.Description LIKE '%${newSearchValue}%' or tc.Title LIKE '%${newSearchValue}%') and tp.ProgramId NOT IN (select ProgramId from vendor_registered_programs where vendorId=${userId}) 
        group by ProgramId
        order by Title;`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        listAllProgram: result[0]
                    });
                    return;
                }
                reply({
                    isSuccess: false,
                    isNotFound: true
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getListCourseandTestbyProgramId(request, reply) {
        const {
            programId
        } = request.query;
        const rawSql = `SELECT distinct tc.CourseId, ti.TestId, vcr.StartDate as courcestartdate, vcr.EndDate as courseenddate, vcr.IsComplete as coursestatus,
        vtr.StartDate as teststartdate, vtr.EndDate as testenddate, vtr.Passed as teststatus
        FROM tce_dev2.vendor_registered_programs vr
        INNER JOIN training_program_courses tpc on vr.ProgramId = tpc.ProgramId
        INNER JOIN training_program_test tpt on vr.ProgramId = tpt.ProgramId
        INNER JOIN training_courses tc on tc.CourseId = tpc.CourseId
        INNER JOIN vendor_courses_result vcr on vcr.CourseId = tc.CourseId
        INNER JOIN vendor_test_result vtr on vtr.TestId = tpt.TestId
        INNER JOIN test_info ti on ti.TestId = tpt.TestId
        WHERE vr.ProgramId = ${programId}`;
        Bookshelf.knex.raw(rawSql)
            .then(result => {
                reply({
                    listCourseandTestinProgram: result[0]
                });
            }).catch((error) => {
                reply(`"Not found record: " + ${error}`);
            });
    }

    getListRecentCourses(request, reply) {
        const {
            signerId
        } = request.query;
        const rawSql = `select c.CourseId, c.Title, cr.StartDate, cr.EndDate, cr.LastViewedDate, cr.IsComplete from training_courses c
                        inner join vendor_courses_result cr on c.CourseId = cr.CourseId
                        where cr.VendorId = ${signerId} and c.Inactive = 0
                        ORDER BY cr.LastViewedDate desc
                        limit 10;`;
        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                const data = result[0];
                data.map((item) => {
                    item.IsComplete = bufferToBoolean(item.IsComplete);
                });
                reply({
                    isSuccess: true,
                    isNotFound: false,
                    listRecentCourses: result[0]
                });
            }
            reply({
                isSuccess: false,
                isNotFound: true
            });
        }).catch((error) => {
            reply(`"Not found record : " + ${error}`);
        });
    }

    getListLearningPath(request, reply) {
        const rawSql = `SELECT lp.LPID learningPathId, lp.LPName learningPathName, p.Title, p.ForVendor, p.Inactive, p.IsPublished FROM training_learning_path lp 
        inner join training_lp_programs lpp on lp.LPID = lpp.LPID
        inner join training_programs p on lpp.ProgramId = p.ProgramId
        where p.ForVendor = 1 and p.Inactive = 0 and p.IsPublished = 1;`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                const data = result[0];
                data.map((item) => {
                    item.ForVendor = bufferToBoolean(item.ForVendor);
                    item.Inactive = bufferToBoolean(item.Inactive);
                    item.IsPublished = bufferToBoolean(item.IsPublished);
                });
                reply({
                    isSuccess: true,
                    isNotFound: false,
                    listLearningPath: result[0]
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getListPopularProgram(request, reply) {
        const rawSql = `select v.VendorId, v.ProgramId, tp.Title, tp.Description 
                        from vendor_registered_programs v, training_programs tp
                        where v.ProgramId = tp.ProgramId and tp.Inactive = 0
                        group by ProgramId 
                        ORDER BY COUNT(v.ProgramId) DESC
                        limit 10;`;
        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                reply({
                    isSuccess: true,
                    isNotFound: false,
                    listPopularProgram: result[0]
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    registerPopularProgram(request, reply) {
        const {
            vendorId,
            programId
        } = request.payload;
        const rawSql = `INSERT INTO vendor_registered_programs
                        ( VendorId, ProgramId, IsComplete, RegisteredDate)
                        VALUES ( ${vendorId}, ${programId}, 0, NOW());`;
        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });

            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
    getCurrentRegisteredProgram(request, reply) {
        const {
            program,
            userId
        } = request.query;
        const rawSql = `SELECT tp.Title as title, tp.Description as description, vrp.VendorId as vendorId, IsComplete as iscomplete
        FROM training_programs tp, vendor_registered_programs vrp
        where tp.ProgramId = vrp.ProgramId and VendorId = ${userId} and tp.Inactive = 0 and ForVendor = 1 and vrp.ProgramId = ${program}
        group by tp.ProgramId order by Title`;
        Bookshelf.knex.raw(rawSql)
            .then(result => {
                const data = result[0];
                data[0].iscomplete = bufferToBoolean(data[0].iscomplete);
                if (data[0]) {
                    reply({
                        isSuccess: true,
                        currentRegisteredProgram: data[0]
                    });

                    return;
                }
                reply({
                    isSuccess: false,
                    isNotFound: true
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getCourseandTestbyProgramId(request, reply) {
        const {
            programId
        } = request.query;
        const getCourses = Promise.resolve(Bookshelf.knex.raw(`select distinct tpc.ProgramId, tc.CourseId, tc.Title, vcr.IsComplete, vcr.StartDate, vcr.EndDate 
        from training_courses tc
        inner join training_program_courses tpc on tpc.CourseId = tc.CourseId and tpc.ProgramId = ${programId}
        inner JOIN vendor_courses_result vcr ON vcr.CourseId = tc.CourseId
        group by CourseId;`));
        const getTests = Promise.resolve(Bookshelf.knex.raw(` select distinct tpt.ProgramId, ti.TestId, ti.TestName, vtr.Passed, vtr.StartDate, vtr.EndDate, vtr.TestedNum, vtr.LastTesting, ti.MaxAttempts, ti.Lockdays
        from test_info ti
        inner join training_program_test tpt on tpt.TestId = ti.TestId and tpt.ProgramId = ${programId}
        inner JOIN vendor_test_result vtr ON vtr.TestId = ti.TestId
        group by TestId;`));
        Promise.all([getCourses, getTests]).then(values => {
            const dataresult = {};
            if (values !== null) {
                values.forEach((item, index) => {
                    if (item !== null) {
                        switch (index) {
                            case 0:
                                dataresult.courses = item[0];
                                break;
                            case 1:
                                item[0].forEach(item1 => {
                                    const nowDate = moment().utc();
                                    const lastTestingDate = moment(item1.LastTesting).utc();
                                    const daysDiff = nowDate.diff(lastTestingDate, "days");

                                    if (item1.TestedNum === item1.MaxAttempts && daysDiff < item1.Lockdays) {
                                        item1.isMaxAttempts = true;
                                        item1.numDayRetake = item1.Lockdays = daysDiff;
                                    } else {
                                        item1.isMaxAttempts = false;
                                    }
                                });
                                dataresult.tests = item[0];
                                break;
                        }
                    }

                });
                dataresult.courses.map(item => {
                    item.IsComplete = bufferToBoolean(item.IsComplete);
                });
                dataresult.isSuccess = true;
                reply(dataresult);
            } else {
                reply({
                    isSuccess: false,
                    isNotFound: true
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getCourseOfCurrentProgram(request, reply) {
        const {
            ProgramId,
            CourseId,
            signerId
        } = request.query;
        const newProgramId = (ProgramId === "" || ProgramId === undefined) ? "" : handleSingleQuote(ProgramId);
        const newCourseId = (CourseId === "" || CourseId === undefined) ? "" : handleSingleQuote(CourseId);
        const rawSql = `select distinct tc.CourseId, tc.Title, tc.Description, tc.VideoFile, tc.Document, tc.Duration, tc.CreatedDate, tc.ViewsCount, tc.PosterFile, tc.Downloaded 
        from training_courses tc 
        left join training_program_courses tp on tc.CourseId = tp.CourseId
        left join vendor_registered_programs vr on tp.ProgramId = vr.ProgramId
        where tp.ProgramId = ${newProgramId} and tc.CourseId = ${newCourseId} and vr.VendorId = ${signerId};`;
        Bookshelf.knex.raw(rawSql)
            .then(result => {
                const data = result[0];

                if (data.length !== 0) {
                    const courseOfCurrentProgram = data[0];
                    courseOfCurrentProgram.iscomplete = bufferToBoolean(data[0].iscomplete);
                    courseOfCurrentProgram.VideoFile = courseOfCurrentProgram.VideoFile.substring(63);
                    courseOfCurrentProgram.Document = courseOfCurrentProgram.Document.substring(63);
                    courseOfCurrentProgram.filePathVideo = `${UPLOAD_PATH}/training-course-temp/TEMP-${courseOfCurrentProgram.VideoFile}`;
                    courseOfCurrentProgram.filePathDocument = `${UPLOAD_PATH}/training-course-temp/TEMP-${courseOfCurrentProgram.Document}`;

                    if (courseOfCurrentProgram) {
                        reply({
                            isSuccess: true,
                            courseOfCurrentProgram
                        });
                    }
                }
            }).catch((error) => {
                reply(`"Not found record : " + ${error}`);
            });
    }

    downloadDoc(request, reply) {
        const input = request.query;
        const rawSql = `Update training_courses set Downloaded = ${input.Downloaded} WHERE CourseId = ${input.CourseId}`;

        Bookshelf.knex.raw(rawSql).then(() => {
            const filePath = `${UPLOAD_PATH}/training-course-temp/TEMP-${input.Document}`;

            if (fs.existsSync(filePath)) {
                // serve file
                reply.file(filePath);
            } else {
                reply(Boom.badRequest(`File ${input.Document} is not exists.`));
            }
        });
    }
}

export default new NotaryTraning();