import Boom from "boom";
import Bookshelf from "./../../db/database";
import {
    handleSingleQuote,
    replaceAll,
    bufferToBoolean,
    hasStringValue
} from "../../helper/common-helper";
import sendMailCore from "../../mail/mail-helper";
import OrderProblem from "../../db/model/order-problem";
import Comment from "../../db/model/comment";
import moment from "moment";

class OrderProblemController {
    constructor() { }

    getOrderProblem(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            orderId,
            typeId,
            statusId,
            vendorLastName,
            dateFrom,
            dateTo,
            brokerId,
            agentId
        } = request.query;
        const newVendorLastName = (vendorLastName === "" || vendorLastName === undefined || vendorLastName === null) ? "" : handleSingleQuote(vendorLastName);
        const newDateFrom = (dateFrom === "" || dateFrom === undefined || dateFrom === null || dateFrom === "Invalid date") ? "" : moment(dateFrom).utc().format("YYYY-MM-DD HH:mm:ss").toString();
        const newDateTo = (dateTo === "" || dateTo === undefined || dateTo === null || dateTo === "Invalid date") ? "" : moment(dateTo).add(1, "days").utc().format("YYYY-MM-DD HH:mm:ss").toString();
        const rawSql = `call GetOrdersProblem( '${sortColumn}',
            ${sortDirection},
            ${page}, 
            ${itemPerPage},
            ${(orderId === undefined || orderId === "") ? null : orderId}, 
            ${(typeId === undefined || typeId === "") ? null : typeId}, 
            ${(statusId === undefined || statusId === "") ? null : statusId},
            '${newVendorLastName}', '${newDateFrom}', '${newDateTo}', ${(brokerId === undefined || brokerId === "") ? null : brokerId}, ${(agentId === undefined || agentId === "") ? null : agentId})`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    const datasources = result[0][0];
                    const totalRecords = result[0][1][0].TotalRecords;
                    const status = result[0][2];
                    const types = result[0][3];

                    reply({
                        datasources,
                        totalRecords,
                        status,
                        types
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getOrderProblemsByOrder(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            orderId
        } = request.query;
        if (orderId === undefined || orderId === "") {
            reply({
                isSuccess: false,
                message: "No Order Id!"
            });
        }
        const rawSql = `call GetOrderProblemsByOrder(${orderId}, '${sortColumn}',
            ${sortDirection},
            ${page !== undefined ? page : "null"}, 
            ${itemPerPage !== undefined ? itemPerPage : "null"});`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    const datasources = result[0][0];
                    const totalRecords = result[0][1][0].TotalRecords;

                    reply({
                        datasources,
                        totalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getVendorOrderProblem(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            signerId
        } = request.query;
        Bookshelf.knex.raw(`call GetVendorOrderProblem('${sortColumn}',${sortDirection},${page},${itemPerPage},${signerId});`).then(result => {
            if (result !== null) {
                result[0][0].map((item) => {
                    item.Acknowledged = bufferToBoolean(item.Acknowledged);
                });
                reply({
                    data: result[0][0],
                    totalRecords: result[0][1][0].TotalRecords
                });
                return;
            }
            reply({
                isSuccess: false,
                message: "No record found!"
            });
            return;
        }).catch(error => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    removeOrderProblem(request, reply) {
        const { problemId } = request.payload;

        OrderProblem.where({ problemId }).destroy().then(() => {
            reply({
                isSuccess: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

    }

    async addOrderProblem(request, reply) {
        const { OrderId, Type, SubType, CreatedDate, Mistake, EnteredBy, SignerId,
            isGenerateEmail, comments,
            VendorFirstName, VendorLastName, VendorEmail, AgentFullName, AgentEmail, ProblemType, ProblemSubType,
            TCEFirstName, TCELastName, TCEEmail
        } = request.payload;

        let Description = "";

        const newOrder = new OrderProblem();
        const Comments = Bookshelf.Collection.extend({
            model: Comment
        });
        let problemId = -1;

        await new Promise((resolve, reject) => {
            newOrder.save({
                OrderId,
                Type,
                SubType: SubType !== "" ? SubType : null,
                Date: CreatedDate,
                Mistake,
                EnteredBy,
                SignerId: Mistake ? SignerId : null,
                Status: 1, //Open,
                TenantId: 1
            }, {
                    method: "insert"
                }).then((result) => {
                    if (result && result.attributes) {
                        problemId = result.attributes.id;
                        //add comments
                        if (comments) {
                            comments.forEach(x => {
                                delete x.UserName;
                                delete x.createdDate;
                                delete x.img;
                                delete x.usersId;
                                x.CreatedBy = EnteredBy;
                                x.CreatedDate = CreatedDate;
                                x.OwnerID = problemId;
                                x.TypeId = 3; //Problem comment
                            });
                        }
                        const commentsForge = Comments.forge(comments);
                        commentsForge.invokeThen("save").then(() => {
                            resolve();
                        }).catch(() => {
                            reject();
                        });
                    }
                }).catch(() => {
                    reject();
                });
        });

        if (comments) {
            Description = `<ul>`;
            comments.forEach(item => {
                Description += `<li>${item.Description}</li>`;
            });
            Description += `</ul>`;
        }

        if (problemId > -1) {
            //sendemail
            const rawSqlGetTemplateVendor = `SELECT fromEmail, subject, message FROM notification_templates nt where nt.Purpose='Problem Added - Vendor - Self Service' and Receiver='Vendor\'\'s email'`;
            const rawSqlGetTemplateAgent = `SELECT fromEmail, subject, message FROM notification_templates nt where nt.Purpose='Problem Added - Agent - Self Service' and Receiver='Agent\'\'s email'`;
            const rawSqlGetTemplateTCE = `SELECT fromEmail, subject, message FROM notification_templates nt where nt.Purpose='Problem Added - TCE' and Receiver='CE Staff\'\'s email'`;

            //mail to Agent
            if (hasStringValue(AgentEmail)) {
                await new Promise((resolve, reject) => {
                    Bookshelf.knex.raw(rawSqlGetTemplateAgent)
                        .then(mailResult => {
                            if (mailResult[0][0]) {
                                const templateMail = mailResult[0][0];
                                templateMail.message = replaceAll(templateMail.message, "[orderID]", OrderId);
                                templateMail.message = replaceAll(templateMail.message, "[AgentFullName]", AgentFullName);
                                templateMail.message = replaceAll(templateMail.message, "[ProblemType]", ProblemType);
                                templateMail.message = replaceAll(templateMail.message, "[ProblemSubType]", hasStringValue(ProblemSubType) ? ProblemSubType : "NA");
                                templateMail.message = replaceAll(templateMail.message, "[Description]", Description);
                                const mailOptions = {
                                    from: templateMail.fromEmail,
                                    to: AgentEmail,
                                    subject: replaceAll(templateMail.subject, "[orderID]", OrderId),
                                    html: templateMail.message
                                };

                                sendMailCore(mailOptions, () => {
                                    resolve();
                                });
                            }
                        }).catch(() => {
                            reject();
                        });
                });
            }

            //mail to TCE Staff
            if (hasStringValue(TCEEmail)) {
                await new Promise((resolve, reject) => {
                    //mail to Agent
                    Bookshelf.knex.raw(rawSqlGetTemplateTCE)
                        .then(mailResult => {
                            if (mailResult[0][0]) {
                                const templateMail = mailResult[0][0];
                                templateMail.message = replaceAll(templateMail.message, "[orderID]", OrderId);
                                templateMail.message = replaceAll(templateMail.message, "[FirstName]", TCEFirstName);
                                templateMail.message = replaceAll(templateMail.message, "[LastName]", TCELastName);
                                templateMail.message = replaceAll(templateMail.message, "[ProblemType]", ProblemType);
                                templateMail.message = replaceAll(templateMail.message, "[ProblemSubType]", hasStringValue(ProblemSubType) ? ProblemSubType : "NA");
                                templateMail.message = replaceAll(templateMail.message, "[Description]", Description);
                                const mailOptions = {
                                    from: templateMail.fromEmail,
                                    to: TCEEmail,
                                    subject: replaceAll(templateMail.subject, "[orderID]", OrderId),
                                    html: templateMail.message
                                };

                                sendMailCore(mailOptions, () => {
                                    resolve();
                                });
                            }
                        }).catch(() => {
                            reject();
                        });
                });
            }

            if (isGenerateEmail && Mistake) {
                await new Promise((resolve, reject) => {
                    Bookshelf.knex.raw(rawSqlGetTemplateVendor)
                        .then(mailResult => {
                            if (mailResult[0][0]) {
                                const templateMail = mailResult[0][0];
                                templateMail.message = replaceAll(templateMail.message, "[orderID]", OrderId);
                                templateMail.message = replaceAll(templateMail.message, "[VendorFirstName]", VendorFirstName);
                                templateMail.message = replaceAll(templateMail.message, "[VendorLastName]", VendorLastName);
                                const mailOptions = {
                                    from: templateMail.fromEmail,
                                    to: VendorEmail,
                                    subject: replaceAll(templateMail.subject, "[orderID]", OrderId),
                                    html: templateMail.message
                                };

                                sendMailCore(mailOptions, () => {
                                    resolve();
                                });
                            }
                        }).catch(() => {
                            reject();
                        });
                });
            }

            reply({
                problemId,
                isSuccess: true
            });

        } else {
            reply({ isSuccess: false, message: "No record insert!" });
        }
        return reply;
    }

}

export default new OrderProblemController();