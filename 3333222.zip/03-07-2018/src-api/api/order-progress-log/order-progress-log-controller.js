import Boom from "boom";
import OrderProgressLog from "../../db/model/order-progress-log";
import Bookshelf from "./../../db/database";
import Promise from "bluebird";
import {
    bufferToBoolean
} from "../../helper/common-helper";
import moment from "moment";

class OrderProgressLogController {
    constructor() {}

    addProgressLog(request, reply) {
        const log = request.payload;

        log.DateLog = moment().utc().format("YYYY-MM-DD HH:mm:ss");
        if (log.dateLog) {
            delete log.DateLog;
        }
        const newLog = new OrderProgressLog();
        // add a log to db
        newLog.save(log, {
            method: "insert"
        }).then(() => {
            reply({
                isSuccess: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    addMultiProgressLog(request, reply) {
        const {
            logs
        } = request.payload;

        Bookshelf.transaction((t) => {
            return Promise.map(logs, (log) => {
                return new OrderProgressLog().save(log, {
                    method: "insert",
                    transacting: t
                });
            }).then(t.commit).catch(t.rollback);
        }).then(() => {
            reply({
                isSuccess: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    getOrderProgressLogById(request, reply) {
        const {
            orderId
        } = request.query;

        Bookshelf.knex.raw(`select opl.*, ur.RoleId, u.MappingUserId from order_progress_log opl, user_roles ur, users u where opl.OrderId = (${orderId}) AND opl.UsersId = ur.UsersId AND u.UsersId = ur.UsersId AND (opl.ProgressType <> 5 OR opl.ProgressType IS NULL) ORDER BY DateLog DESC`)
            .then((result) => {
                if (result !== null) {
                    reply({
                        dataProgressLog: result[0]
                    });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }
    //get alert
    getDataAlert(request, reply) {
        const {
            page,
            itemPerPage,
            role,
            clientId
        } = request.query;

        Bookshelf.knex.raw(`call GetAlert(${page},${itemPerPage},'${role}',${clientId})`)
            .then((result) => {
                if (result !== null) {
                    const dataAlert = result[0][0];
                    dataAlert.forEach(item => {
                        item.isRead = bufferToBoolean(item.isRead);
                    });
                    const data = {
                        dataAlert,
                        dataTotalRecords: result[0][1][0].TotalRecords
                    };

                    reply(data);
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
    //update Mask as read or unread
    updateMaskAsReadOrUnread(request, reply) {
        const progressLog = request.payload;
        const isReadUpdate = {
            isRead: progressLog.isRead,
            progressLogId: progressLog.progressLogId
        };

        OrderProgressLog.where({
            ProgressLogId: progressLog.progressLogId
        }).save(isReadUpdate, {
            method: "update"
        }).then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });

            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
        return;
    }
}

export default new OrderProgressLogController();