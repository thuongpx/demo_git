
import IssueReporting from "../../db/model/issue-reporting";
import Boom from "boom";
import Bookshelf from "../../db/database";
import { handleSingleQuote } from "../../helper/common-helper";
class IssueReportingController {
	constructor() { }

	getIssuesReportingById(request, reply) {
		const {
			orderId,
			company,
			vendorLastName,
			typeOrder,
			statusOrder,
			fromDate,
			toDate,
			sortColumn,
			sortDirection,
			page,
			itemPerPage
        } = request.query;

		const rawSql = `call GetOrderIssuesReportingByProblemId(
			${(orderId === undefined || orderId === "") ? null : `${orderId}`},
			'${handleSingleQuote(company)}',
			${handleSingleQuote(vendorLastName) === "" ? null : `'${handleSingleQuote(vendorLastName)}'`},
			'${typeOrder}',
			'${statusOrder}',
			${fromDate === undefined ? null : `'${fromDate}'`},
            ${toDate === undefined ? null : `'${toDate}'`},
            '\`${sortColumn}\`',
            ${sortDirection},
            ${page},
            ${itemPerPage} 
		);`;
		Bookshelf.knex.raw(rawSql)
			.then((result) => {
				if (result !== null) {
					reply({ data: result[0][0], data1: result[0][2], data2: result[0][3], totalRecords: result[0][1][0].TotalRecords });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	updateIssueReporting(request, reply) {
		const issue = request.payload;
		IssueReporting.where({ problemId: issue.problemId }).save(issue, { method: "update" }).then((result) => {
			if (result !== null) {
				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}
}

export default new IssueReportingController();