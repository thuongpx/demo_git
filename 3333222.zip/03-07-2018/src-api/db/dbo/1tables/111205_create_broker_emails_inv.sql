-- Request from HoangNM
-- Add broker email invoice
CREATE TABLE IF NOT EXISTS `broker_emails_inv` (
    `BrokerEmailId` INT(11) NOT NULL AUTO_INCREMENT,
    `BrokerID` INT(11),
    `EName` VARCHAR(75),
    `Email` VARCHAR(300),
    PRIMARY KEY (`BrokerEmailId`)
);