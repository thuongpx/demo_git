ALTER TABLE `agent` 
DROP FOREIGN KEY `TenantId_agent`;
ALTER TABLE `agent` 
CHANGE COLUMN `TenantId` `TenantId` INT(11) NULL ;
ALTER TABLE `agent` 
ADD CONSTRAINT `TenantId_agent`
  FOREIGN KEY (`TenantId`)
  REFERENCES `tenant` (`TenantId`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
