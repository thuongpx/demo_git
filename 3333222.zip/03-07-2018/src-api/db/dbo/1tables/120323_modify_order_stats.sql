ALTER TABLE `order_stats` 
DROP FOREIGN KEY `TenantId_order_stats`;
ALTER TABLE `order_stats` 
CHANGE COLUMN `TenantId` `TenantId` INT(11) NULL ;
ALTER TABLE `order_stats` 
ADD CONSTRAINT `TenantId_order_stats`
  FOREIGN KEY (`TenantId`)
  REFERENCES `tenant` (`TenantId`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
