ALTER TABLE `broker` 
DROP FOREIGN KEY `tenantId_borker`;
ALTER TABLE `broker` 
DROP INDEX `tenantId_borker_idx` ;

ALTER TABLE `broker` 
CHANGE COLUMN `TenantId` `TenantId` INT(11) NULL;

ALTER TABLE `broker_detail` 
DROP FOREIGN KEY `tenantId_broker_detail`;
ALTER TABLE `broker_detail` 
DROP COLUMN `TenantId`,
DROP INDEX `tenantId_broker_detail_idx` ;

ALTER TABLE `broker_fee` 
DROP FOREIGN KEY `tenantId_borker_fee`;
ALTER TABLE `broker_fee` 
CHANGE COLUMN `TenantId` `TenantId` INT(11) NULL ,
DROP INDEX `tenantId_borker_fee_idx` ;
