CREATE TABLE IF NOT EXISTS `signer_docs_archive` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `SignerID` INT NULL,
  `DocTypeID` INT NULL,
  `DocName` VARCHAR(150) NULL,
  `ArchiveDate` DATETIME NULL,
  `ArchiveBy` VARCHAR(50) NULL,
  PRIMARY KEY (`Id`)
  );