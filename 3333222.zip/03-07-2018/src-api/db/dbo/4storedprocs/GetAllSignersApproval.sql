DROP PROCEDURE IF EXISTS `GetAllSignersApproval`;

DELIMITER $$

CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllSignersApproval`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN searchOrderID int,
IN searchStatus varchar(255),
IN searchRequestBy varchar(255)
)
BEGIN
    DECLARE orderIDWhereSql varchar(255);
    DECLARE statusWhereSql varchar(255);
    DECLARE signersApprovalTableSql varchar(255);
    
    DECLARE requestByWhereSql varchar(255);
    DECLARE employeesTableSql varchar(255);
    
    DECLARE searchedTableSql varchar(1000);
    DECLARE resultTableSql varchar(1100);
    
	DECLARE orderSql varchar(255);
	DECLARE sortDirectionSql varchar(255);
    DECLARE limitSql varchar(255);

	IF (searchOrderID IS NULL)
	THEN SET orderIDWhereSql = '';
	ELSE SET orderIDWhereSql = CONCAT(' AND SA.OrderId = ', searchOrderID);
    END IF;
    
    
    SET searchedTableSql = CONCAT('SELECT SA.* FROM signers_approval SA WHERE TRUE', orderIDWhereSql);
    
	-- limit searchResult
    SET limitSql = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ', ', pageSize);
        
    -- sort
	IF (sortDirection = 1) 
		THEN SET sortDirectionSql = ' ASC';
	ELSE SET sortDirectionSql = ' DESC';
    END IF;
	-- SELECT sortDirectionQuery;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderSql = ' ORDER BY RequestDate ';
	ELSE SET orderSql = CONCAT(' ORDER BY ', sortBy, sortDirectionSql);
    END IF;
    
    -- join order and signer table to get more information -> sort
    SET resultTableSql = CONCAT('SELECT SQL_CALC_FOUND_ROWS SA.*,
    S.Email as Email, 
    SO.Distance,
    SO.OfferAmount,
    SA.RequestDate,
    U.UserName,
    UA.UserName AS ApprovedBy,
    CONCAT(S.LastName, " ", S.FirstName) as VendorName, 
    C.Description,
    U.UserName,
    O.City,
    LO.LoanType,
	A.FullName 
    FROM (', searchedTableSql, ') SA 
    LEFT JOIN `order` O ON SA.OrderId = O.OrderId
    LEFT JOIN agent A ON O.AgentId = A.AgentId
    left join comment C on C.commentId = (
    SELECT
      cm2.commentId
    FROM comment cm2
    WHERE cm2.ownerId = SA.approvalId 
    ORDER BY cm2.CreatedDate DESC LIMIT 1 )
	LEFT JOIN `users` U ON SA.RequestBy = U.UsersId
    LEFT JOIN `users` UA ON UA.UsersId = SA.ApprovedBy
    left join `loan_type` LO on O.LoanType = LO.LoanTypeId
    LEFT JOIN `signer_offer` SO ON SO.OfferID = (
    SELECT
      MIN(SO2.OfferID)
    FROM signer_offer SO2
    WHERE SO2.SignerId = SA.SignerId and SA.OrderId = SO2.OrderId
	)
    LEFT JOIN signer S ON S.SignerId = SA.SignerId', orderSql, limitSql,';');
	SET @querySql= resultTableSql;
    
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    SELECT COUNT(*) AS CountOpen FROM signers_approval WHERE Status='Open';
END