DROP procedure IF EXISTS `GetAllManagerInternalUser`;

DELIMITER $$

CREATE PROCEDURE `GetAllManagerInternalUser`(
	IN repId INT(11),
    IN repName varchar(255),
    IN repEmail varchar(255),
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(500);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RepId ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE `roles`.TYPE="Staff" and (IsDeleted=false or IsDeleted is null) ');
    
    IF (repId IS NOT NULL AND repId >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `RepId` = ', repId);
	END IF;
    
    IF (repName IS NOT NULL AND repName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND CONCAT(`employees`.`FirstName`, \' \', `employees`.`LastName`) LIKE ''%', repName, '%''');
	END IF;
    
    IF (repEmail IS NOT NULL AND repEmail <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Email` LIKE ''%', repEmail, '%''');
	END IF;
    
     
     set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS t1.* from (select distinct
									`employees`.RepId as `RepId`,
									CONCAT(`employees`.`FirstName`, \' \', `employees`.`LastName`) as `FullName`,  
									`employees`.Email as `Email`,
                                    `employees`.Ext as `Ext`,
                                    `employees`.Active as `Active`,
                                    `employees`.IsDeleted as `IsDeleted`,
                                    
                                    `roles`.Type as `Type`,
                                    CASE WHEN Dnd = 1 THEN \'Do Not Disturb\' ELSE 
										CASE WHEN LoggedIn = 1 THEN \'Available\' ELSE 
											CASE WHEN OutOfOffice = 1 THEN \'Offline\' ELSE \'Offline\' 
                                            END 
										END 
									END as `Status`,
                                    group_concat(DISTINCT `roles`.RoleName ORDER BY `roles`.RoleName asc separator \',\') as RoleName
							FROM `employees`  
                            INNER JOIN `users` on `employees`.RepId = `users`.MappingUserId
                            INNER JOIN `user_roles` on `users`.UsersId = `user_roles`.UsersId   
							INNER JOIN `roles` on `user_roles`.RoleId = `roles`.RoleId '
                            , whereQuery, 
                            ' GROUP BY `employees`.RepId ', orderQuery,
                            ' ) t1, (SELECT @rownum := 0) r ', limitQuery);
                            
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
    SELECT Id, Description FROM problem_status;
    SELECT Id, Description FROM problem_types;
    
END$$

DELIMITER ;