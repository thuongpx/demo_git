DROP PROCEDURE IF EXISTS `GetAdditionalFeeForOrder`;

DELIMITER $$

CREATE PROCEDURE `GetAllAgents`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN searchText varchar(255),
IN brokerId int
)
BEGIN

    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

    SET whereQuery = ' WHERE 1=1 ';
    
    IF (searchText IS NOT NULL AND searchText <> '')
       THEN SET whereQuery = CONCAT(whereQuery, ' AND (FullName Like ''%', searchText, '%'' OR a.Email Like ''%', searchText, '%'')');
    END IF;
    
    IF (brokerId IS NOT NULL)
       THEN SET whereQuery = CONCAT(whereQuery, ' AND a.BrokerId = ', brokerId, ' OR b.gId= ', brokerId);
    END IF;
    
    SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS 
        AgentId, b.Company, FullName, Ext, a.Email, Fax, a.Direct
        FROM agent AS a
        LEFT JOIN broker AS b ON a.BrokerId = b.BrokerID ', whereQuery , orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;

END$$

DELIMITER ;