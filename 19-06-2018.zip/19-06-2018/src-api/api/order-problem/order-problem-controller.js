import Boom from "boom";
import Bookshelf from "./../../db/database";
import {
    handleSingleQuote,
    bufferToBoolean
} from "../../helper/common-helper";
import moment from "moment";

class OrderProblemController {
    constructor() { }

    getOrderProblem(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            orderId,
            typeId,
            statusId,
            vendorLastName,
            dateFrom,
            dateTo,
            brokerId,
            agentId
        } = request.query;
        const newVendorLastName = (vendorLastName === "" || vendorLastName === undefined || vendorLastName === null) ? "" : handleSingleQuote(vendorLastName);
        const newDateFrom = (dateFrom === "" || dateFrom === undefined || dateFrom === null || dateFrom === "Invalid date") ? "" : moment(dateFrom).utc().format("YYYY-MM-DD HH:mm:ss").toString();
        const newDateTo = (dateTo === "" || dateTo === undefined || dateTo === null || dateTo === "Invalid date") ? "" : moment(dateTo).add(1, "days").utc().format("YYYY-MM-DD HH:mm:ss").toString();
        const rawSql = `call GetOrdersProblem( '${sortColumn}',
            ${sortDirection},
            ${page}, 
            ${itemPerPage},
            ${(orderId === undefined || orderId === "") ? null : orderId}, 
            ${(typeId === undefined || typeId === "") ? null : typeId}, 
            ${(statusId === undefined || statusId === "") ? null : statusId},
            '${newVendorLastName}', '${newDateFrom}', '${newDateTo}', ${(brokerId === undefined || brokerId === "") ? null : brokerId}, ${(agentId === undefined || agentId === "") ? null : agentId})`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    const datasources = result[0][0];
                    const totalRecords = result[0][1][0].TotalRecords;
                    const status = result[0][2];
                    const types = result[0][3];

                    reply({
                        datasources,
                        totalRecords,
                        status,
                        types
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getVendorOrderProblem(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            signerId
        } = request.query;
        Bookshelf.knex.raw(`call GetVendorOrderProblem('${sortColumn}',${sortDirection},${page},${itemPerPage},${signerId});`).then(result => {
            if (result !== null) {
                result[0][0].map((item) => {
                    item.Acknowledged = bufferToBoolean(item.Acknowledged);
                });
                reply({
                    data: result[0][0],
                    totalRecords: result[0][1][0].TotalRecords
                });
                return;
            }
            reply({
                isSuccess: false,
                message: "No record found!"
            });
            return;
        }).catch(error => {
            reply(Boom.badRequest(error));
            return;
        });
    }
}

export default new OrderProblemController();