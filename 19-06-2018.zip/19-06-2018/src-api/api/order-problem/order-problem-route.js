import OrderProblemController from "./order-problem-controller";

const routes = [{
    path: "/orderproblem/getOrderProblem",
    method: "GET",
    handler: OrderProblemController.getOrderProblem
},
{
    path: "/orderproblem/getVendorOrderProblem",
    method: "GET",
    handler: OrderProblemController.getVendorOrderProblem
}
];

export default routes;