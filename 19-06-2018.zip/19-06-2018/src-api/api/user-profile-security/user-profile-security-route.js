import UserProfileSecurityController from "./user-profile-security-controller";

const routes = [{
    path: "/user-profile-security/getUserProfile",
    method: "GET",
    handler: UserProfileSecurityController.getUserProfileSecurity
},
{
    path: "/user-profile-security/updateUserProfileSecurity",
    method: "POST",
    handler: UserProfileSecurityController.saveUserProfileSecurity
}
];

export default routes;