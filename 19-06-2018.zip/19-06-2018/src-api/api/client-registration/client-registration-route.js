import ReturnDocsController from "./return-docs-controller";

const routes = [{
    path: "/client-registration/getReturnDocsDataById",
    method: "GET",
    handler: ReturnDocsController.getReturnDocsData
},
{
    path: "/client-registration/addNewInputData",
    method: "POST",
    handler: ReturnDocsController.addNewReturnDocsData
}];

export default routes;