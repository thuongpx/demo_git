import Boom from "boom";
import Bookshelf from "./../../db/database";
import Order from "./../../db/model/order";
import moment from "moment";

class OrderDateController {
    constructor() { }

    getOrderDate(request, reply) {
        const { orderId } = request.query;

        Bookshelf.knex.raw(`call GetOrderDatesById(${orderId})`)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0][0]
                    });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    updateOrderDate(request, reply) {
        const orderDate = request.payload;

        let obj = {};
        const DropDate = moment(orderDate.DropDate).utc().format("YYYY-MM-DD HH:mm:ss").toString();

        if (orderDate.DropDate !== null) {
            obj = { DropDate };
        } else {
            obj = { DropDate: null };
        }


        Order.where({ OrderId: orderDate.OrderID }).save(obj, { method: "update" }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
        return reply;
    }
}

export default new OrderDateController();