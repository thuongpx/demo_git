import Boom from "boom";
import Bookshelf from "../../db/database";
import OrderFee from "../../db/model/order-fee";
import OrderFeeApprove from "../../db/model/order-fee-approve";
import moment from "moment";

import { hasStringValue } from "../../helper/common-helper";

class OrderFeeController {
    constructor() { }

    // Delete a fee of order
    deleteOrderFee(request, reply) {
        const feeId = request.payload;

        OrderFee.where(feeId).destroy().then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error.message));
            return;
        });
    }

    addOrderFee(request, reply) {
        const fee = request.payload;
        const newFee = new OrderFee();
        // add a fee to db
        newFee.save({
            OrderID: fee.OrderID,
            FeeDescripID: fee.FeeDescripID,
            BrokerFee: fee.BrokerFee,
            SignerFee: fee.SignerFee,
            Date: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        }, { method: "insert" }).then(() => {
            reply(1);
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    // get fees of an order
    getOrderFee(request, reply) {
        const { orderId } = request.query;
        Bookshelf.knex.raw(`call GetOrderFees('${orderId}')`)
            .then((result) => {
                if (result !== null) {
                    reply(result[0][0]);
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    // Get all data for Order Detail Fee screen
    getOrdersFeeData(request, reply) {
        const { orderId } = request.query;

        const getOrderFees = Promise.resolve(Bookshelf.knex.raw(`call GetOrderFees(${orderId})`));
        const getAllFees = Promise.resolve(Bookshelf.knex.raw(`call GetAdditionalFeeForOrder(${orderId})`));
        const getRequestedFees = Promise.resolve(
            Bookshelf.knex.raw(`call GetOrderRequestedFee(${orderId})`));
        const getFeeRequestReason = Promise.resolve(Bookshelf.knex.raw(`call GetAllReasonCodes()`));

        Promise.all([getOrderFees, getAllFees, getRequestedFees, getFeeRequestReason])
            .then(values => {
                const data = {};

                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.orderFeesData = {
                                        orderFees: item[0][0]
                                    };
                                    break;
                                case 1:
                                    data.feesData = {
                                        fees: item[0][0]
                                    };
                                    break;
                                case 2:
                                    data.requestedFeesData = {
                                        fees: item[0][0]
                                    };
                                    break;
                                case 3:
                                    data.feeRequestReasonData = {
                                        reasonList: item[0][0]
                                    };
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    async addOrderRequestedFee(request, reply) {
        const fee = request.payload;

        const rawQuery = `SELECT SUM(SignerFee) AS totalAdditionalFee FROM \`order_fee\` WHERE OrderId = ${fee.orderId} AND FeeDescripID <> ${fee.feeDescripId}`;

        let totalAdditionalFee = 0;

        await new Promise((resolve) => Bookshelf.knex.raw(rawQuery)
            .then(result => {
                if (result !== null && result[0] !== null) {
                    totalAdditionalFee = result[0][0].totalAdditionalFee;
                }
                resolve();
            }));

        if (totalAdditionalFee === null) {
            totalAdditionalFee = 0;
        }

        const newRequestFee = new OrderFeeApprove();
        // add a fee to db
        newRequestFee.save({
            OrderId: fee.orderId,
            FeeDescripId: fee.feeDescripId,
            UsersId: fee.userId,
            ReasonCode: fee.reasonCode,
            FeeReason: hasStringValue(fee.description) ? fee.description : null,
            FeeAmount: fee.proposedFee - totalAdditionalFee,
            OriginalAmount: fee.originalAmount,
            FeeApproved: fee.status,
            DateStamp: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            SignerID: fee.signerId || null
        }, { method: "insert" }).then((result) => {
            reply({
                isSuccess: true,
                feeApprovalId: result.id
            });

            return;
        }).catch(error => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    getOrderRequestedFee(request, reply) {
        const { orderId } = request.query;
        Bookshelf.knex.raw(`call GetOrderRequestedFee('${orderId}')`)
            .then((result) => {
                if (result !== null) {
                    reply(result[0][0]);
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    updateOrderRequestedFee(request, reply) {
        const fee = request.payload;

        const updatedFee = {
            UsersId: fee.userId,
            ReasonCode: fee.reasonCode,
            FeeReason: fee.description,
            FeeAmount: fee.proposedFee,
            OriginalAmount: fee.originalAmount,
            FeeApproved: fee.status,
            DateStamp: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        };

        OrderFeeApprove.where({ OrderId: fee.orderId, FeeDescripId: fee.feeDescripId })
            .save(updatedFee, { method: "update" }).then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    processRequestFee(request, reply) {
        const { orderId, feeApprovalId, feeApproved, offerStatus, signerId, signerFee, feeDescripId, activity, userId, isOveride } = request.payload;

        Bookshelf.knex.raw(`
        call ChangeOrderFeeApproveStatus(${orderId}, ${feeApprovalId}, '${feeApproved}', '${offerStatus}', ${signerId}, ${signerFee}, ${feeDescripId}, '${activity}', ${userId}, ${isOveride || false});`)
            .then((result) => {
                if (result !== null) {
                    reply(result[0][0][0]);
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    updateListOrderAddionalFee(request, reply) {
        const { listAdditionalFee, orderId } = request.payload;

        let listValuesInsert = ``;
        listAdditionalFee.forEach((item) => {
            if (item.FeeId) {
                listValuesInsert = listValuesInsert === `` ? `(${orderId}, ${item.FeeId}, ${item.ClientFee}, ${item.VendorFee}, ${item.VendorFee})` : `${listValuesInsert}, (${orderId}, ${item.FeeId}, ${item.ClientFee}, ${item.VendorFee}, ${item.VendorFee})`;
            }
        });

        OrderFee.where({ OrderID: orderId }).destroy()
            .then(() => {
                if (listAdditionalFee && listAdditionalFee.length > 0) {
                    const rawInsertSql = `INSERT INTO order_fee (OrderID, FeeDescripID, BrokerFee, SignerFee, OriginalSignerFee) VALUES ${listValuesInsert};`;
                    Bookshelf.knex.raw(rawInsertSql).then(() => {
                        reply({ isSuccess: true });
                    }).catch(error => {
                        reply(Boom.badRequest(error));
                    });
                } else {
                    reply({ isSuccess: true });
                }

            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

}

export default new OrderFeeController();