import Boom from "boom";
import Bookshelf from "./../../db/database";
import OrderProgressLog from "../../db/model/order-progress-log";
import Order, { getAdditionalFees, getLoanTypesByCustomerIdBrokerId } from "./../../db/model/order";
import { bufferToBoolean, hasStringValue } from "../../helper/common-helper";
import { ORDER_PROGRESS_ID } from "../../constant/progress-constant";

class OrderStatusController {
    constructor() { }

    getOrderStatusProgressLog(request, reply) {
        const { orderId, sortColumn, sortDirection, page, itemPerPage, accountId } = request.query;
        const rawSql = `call getOrderProgressLog(${orderId}, "${sortColumn}", ${sortDirection}, ${page}, ${itemPerPage}, ${accountId});`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
            }

            return reply;
        }).catch((error) => {
            reply(Boom.badRequest(error));

            return reply;
        });
    }

    getInitDataForOrderStatus(request, reply) {
        const { orderId, accountId } = request.query;
        const getOrderStatusById = Promise.resolve(Bookshelf.knex.raw(`call getOrderDetailtStatus(${orderId});`));
        const getOrderStatusDataDropDown = Promise.resolve(Bookshelf.knex.raw(`call getOrderStatusDropDownData();`));
        const getOrderStatusProgressLog = Promise.resolve(Bookshelf.knex.raw(`call getOrderProgressLog(${orderId}, "DateLog", 0, 1, 25, ${accountId});`));

        Promise.all([getOrderStatusById, getOrderStatusDataDropDown, getOrderStatusProgressLog])
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.orderStatus = item[0][0][0];
                                    break;
                                case 1:
                                    data.initData = {
                                        progress: item[0][0],
                                        deliveryMethod: item[0][1],
                                        staffId: item[0][2],
                                        productType: item[0][3],
                                        defaultProgressSelect: item[0][4][0].defaultProgressSelect
                                    };
                                    break;
                                case 2:
                                    data.listProgressLog = {
                                        data: item[0][0],
                                        totalRecords: item[0][1][0].TotalRecords
                                    };
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });

        return reply;
    }

    updatOrderStatus(request, reply) {
        const orderStatus = request.payload;
        let updateOrderStatus = {};
        if (orderStatus.isClientPlaceOrder) { //check client or staff add/update this order
            updateOrderStatus = {
                CustomerId: orderStatus.CustomerId ? orderStatus.CustomerId : null,
                BrokerId: orderStatus.BrokerId,
                LoanType: orderStatus.LoanType,
                BrokerIdNum: orderStatus.BrokerIdNum,
                AgentId: hasStringValue(orderStatus.AgentId) ? orderStatus.AgentId : null,
                FaxBackReq: orderStatus.FaxBackReq,
                Address: orderStatus.Address || "",
                CCInvEmail: orderStatus.CCInvEmail || "",
                AlwaysCC: orderStatus.AlwaysCC || "",
                Collect1: orderStatus.Collect1 || "",
                Collect2: orderStatus.Collect2 || "",
                Collect3: orderStatus.Collect3 || "",
                Collect4: orderStatus.Collect4 || "",
                Collect5: orderStatus.Collect5 || "",
                Collect6: orderStatus.Collect6 || "",
                Collect7: orderStatus.Collect7 || "",
                Collect8: orderStatus.Collect8 || "",
                Collect9: orderStatus.Collect9 || "",
                Collect10: orderStatus.Collect10 || "",
                EmailCC: orderStatus.EmailCC || "",
                IsSelfService: orderStatus.isSelfService || false,
                IsNeedPreCall: orderStatus.isNeedPreCall || false,
                IsCreatedByClient: true,
                ProgressId: 1, //progress default is Open
                NeedReviewPCResolution: orderStatus.needReviewPCResolution || false
            };
        } else {
            updateOrderStatus = {
                DocDelMethod: orderStatus.deliveryMethod,
                RepId: orderStatus.repId,
                Filledby: orderStatus.filledBy,
                BrokerIdNum: orderStatus.referenceNumber,
                TrackingNumber: orderStatus.trackingNumber,
                CourierAcntNumber: orderStatus.courierAccountNumber,
                TrackingNumber2: orderStatus.additionalTrackingNumber,
                FaxBackReq: orderStatus.faxBackRequired,
                LoanType: orderStatus.LoanType,
                ProgressId: orderStatus.ProgressId,
                Service: orderStatus.Service,
                CustomerId: orderStatus.CustomerId,
                BrokerId: orderStatus.BrokerId,
                IsSelfService: false,
                IsNeedPreCall: orderStatus.isNeedPreCall
            };
        }

        if (orderStatus.CreatedBy) updateOrderStatus.CreatedBy = orderStatus.CreatedBy;

        const rawSql = `Select OrderId From \`order\` WHERE OrderId <> ${orderStatus.OrderId} AND BrokerIdNum='${updateOrderStatus.BrokerIdNum}'`;


        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null && result[0].length > 0 && updateOrderStatus.BrokerIdNum && updateOrderStatus.BrokerIdNum !== null) {
                reply({
                    isSuccess: false,
                    error: {
                        response: {
                            status: 500,
                            data: { message: `A File No: ${updateOrderStatus.BrokerIdNum} already exists. Please re-enter` }
                        }
                    }
                });
            } else {
                Order.where({ OrderId: orderStatus.OrderId })
                    .save(updateOrderStatus, { method: "update" }).then((result) => {
                        if (result !== null) {
                            reply({ isSuccess: true });
                        }
                    }).catch((error) => {
                        reply(Boom.badRequest(error));
                    });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

    }

    getListCustomerByBrokerId(request, reply) {
        const { BrokerId } = request.query;

        const getOrderStatusCustomerByClientId = Promise.resolve(Bookshelf.knex.raw(`select c.CustomerId, c.Email, c.Name from customers c where c.BrokerId = ${BrokerId} and (c.Inactive = false or c.Inactive is null);`));
        const getTotalRecordsOrderStatusCustomerByClientId = Promise.resolve(Bookshelf.knex.raw(`select count(c.CustomerId) as totalRecords from  customers c where c.BrokerId = ${BrokerId} and (c.Inactive = false or c.Inactive is null);`));

        Promise.all([getOrderStatusCustomerByClientId, getTotalRecordsOrderStatusCustomerByClientId])
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.data = item[0];
                                    break;
                                case 1:
                                    data.totalRecords = item[0][0].totalRecords;
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getOrderDetailProductTypeByCustomerId(request, reply) {
        const { customerId, brokerId } = request.query;

        getLoanTypesByCustomerIdBrokerId({ customerId, brokerId }, data => reply(data), err => reply(Boom.badRequest(err)));
    }

    getOrderDetailDropDownData(request, reply) {
        const { brokerId } = request.query;
        const rawSql = `select b.BrokerID, 
                            b.Company, 
                            b.City, 
                            b.State,
                            b.GID
                        from broker b 
                        where (b.Inactive is null OR b.Inactive=false) AND b.IsAvailable=true AND (b.BrokerID=${brokerId} OR b.GID=${brokerId}) order by b.Company;`;
        const rawSqlGetListProduct = `select LoanType, LoanTypeId, ClientFee, VendorFee, FeeId, IndustryId
                                    from (select distinct bf.IndustryId, case when b.IndustryId <> bf.IndustryId THEN CONCAT(i.Description, ' - ', l.LoanType) ELSE l.LoanType END AS LoanType, l.LoanTypeId, bf.BrokerFee as ClientFee, itf.VendorFee, bf.FeeId from loan_type l 
                                        join broker_fee bf on l.LoanTypeId = bf.LoanTypeId
                                        join broker b on b.BrokerID = bf.BrokerId
                                        join industry_transaction_fees itf on bf.SystemFee = itf.FeeId
                                        join industry i on itf.IndustryId = i.IndustryId
                                        where (bf.IsAdditionalFee is null or bf.IsAdditionalFee = false)
                                            and b.BrokerID = (SELECT IF(b1.GID IS NOT NULL AND b1.GID <> 0, b1.GID, ${brokerId}) from broker b1 where b1.BrokerID = ${brokerId})
                                            and bf.IndustryId IN (SELECT i.IndustryId FROM \`industry\` i WHERE (b.IndustryId = i.IndustryId OR b.IndustryId = i.ParentId))
                                    ) t1
                                        left join (
                                        SELECT 
                                        o.LoanType as Id,
                                        COUNT(orderid) AS counter
                                        FROM \`order\` AS o
                                        WHERE o.LoanType IN (SELECT DISTINCT LoanTypeId FROM \`broker_fee\` WHERE BrokerId = (SELECT IF(b1.GID IS NOT NULL AND b1.GID <> 0, b1.GID, ${brokerId}) from broker b1 where b1.BrokerID = ${brokerId}))
                                        GROUP BY o.LoanType
                                        ORDER BY counter DESC
                                        LIMIT 3) AS c ON c.Id = t1.LoanTypeId
                                        ORDER BY (case when counter IS NOT NULL THEN counter END) DESC,
                                        (CASE WHEN counter IS NULL THEN LoanType END ) ASC;`;

        const getOrderDetailDataDropDown = Promise.resolve(Bookshelf.knex.raw(`call getOrderStatusDropDownData();`));
        const getOrderDetailCustomerBranch = Promise.resolve(Bookshelf.knex.raw(rawSql));
        const getListProductTypeDropDown = Promise.resolve(Bookshelf.knex.raw(rawSqlGetListProduct));

        Promise.all([getOrderDetailDataDropDown, getOrderDetailCustomerBranch, getListProductTypeDropDown])
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.initData = {
                                        progress: item[0][0],
                                        defaultProgressSelect: item[0][4][0].defaultProgressSelect
                                    };
                                    break;
                                case 1:
                                    data.initData.listClientBranch = item[0];
                                    break;
                                case 2:
                                    data.initData.productType = item[0];
                                    break;
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getDefaultDataOrderDetails(request, reply) {
        const { orderId } = request.query;
        const rawSql = `SELECT o.OrderId, o.BrokerId, o.CustomerId, o.AgentId, o.FaxBackReq, o.LoanType, o.BrokerIdNum, o.IsNeedPreCall, o.LanguageId, o.CoLanguageId from \`order\` o where o.OrderId = ${orderId}`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                const returnData = result[0][0];
                if (returnData) {
                    returnData.FaxBackReq = bufferToBoolean(returnData.FaxBackReq);
                    returnData.IsNeedPreCall = bufferToBoolean(returnData.IsNeedPreCall);
                }

                reply(returnData);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getListOrderAdditionalFee(request, reply) {
        const { brokerId, orderId } = request.query;

        getAdditionalFees({ brokerId, orderId }, value => reply(value), err => reply(Boom.badRequest(err)));
    }

    changeStatusOnFirstDocUploaded(request, reply) {
        const { orderId } = request.query;

        Order.where({ orderId }).count().then(numOrder => {
            if (numOrder !== 1) {
                reply({ isSuccess: false });
                return;
            }

            OrderProgressLog.where({ orderId }).where("Activity", "LIKE", "%uploaded%").count()
                .then(count => {
                    if (count === 1) {
                        // change order status to pre-peding call
                        Order.where({ orderId }).save({ progressId: ORDER_PROGRESS_ID.PENDING_PRE_CALL }, { method: "update" })
                            .then(() => {
                                reply({ isSuccess: true });
                            })
                            .catch(error => {
                                reply(Boom.badRequest(error));
                            });

                        return;
                    }

                    reply({ isSuccess: false });
                    return;

                })
                .catch(error => {
                    reply(Boom.badRequest(error));
                });

        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }
}

export default new OrderStatusController();