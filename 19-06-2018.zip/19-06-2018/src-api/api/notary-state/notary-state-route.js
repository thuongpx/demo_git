import NotaryStateController from "./notary-state-controller";

const routes = [{
    path: "/notary-state/getDualStatesBySignerId",
    method: "GET",
    handler: NotaryStateController.getDualStatesBySignerId
}];

export default routes;