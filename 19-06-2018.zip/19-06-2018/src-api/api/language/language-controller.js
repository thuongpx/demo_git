import Boom from "boom";
import Language from "./../../db/model/language";

class LanguageController {
    constructor() { }
    getLanguages(request, reply) {
        new Language().fetchAll({ columns: ["languageId", "language"] }).then((languages) => {
            reply(languages);
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}
export default new LanguageController();