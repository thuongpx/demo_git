import VendorHistoryController from "./vendor-history-controller";
const routes = [
    {
        path: "/vendor-history/getVendorHistory",
        method: "GET",
        handler: VendorHistoryController.getVendorHistory
    }
];

export default routes;