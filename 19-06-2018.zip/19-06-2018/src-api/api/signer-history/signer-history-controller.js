import Bookshelf from "../../db/database";
import Boom from "boom";

class SignerHistoryController {
    constructor() { }

    getOrdersSignerHistory(request, reply) {
        const { sortColumn, sortDirection, page, itemPerPage, orderId } = request.query;
        const rawSql = `CALL GetOrdersSignerHistory('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId === "" ? null : orderId});`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    const ordersSignerHistoryList = result[0][0];
                    const totalRecords = result[0][1][0].TotalRecords;

                    reply({
                        ordersSignerHistoryList,
                        totalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
}

export default new SignerHistoryController();