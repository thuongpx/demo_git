import Bookshelf from "../../db/database";
import Boom from "boom";
import Signer from "../../db/model/signers";
import { hasValue } from "../../helper/common-helper";
import { ORDER_PROGRESS_ID } from "./../../constant/progress-constant";
import { OVERALL_RATING_SCALE } from "../../constant/common-constant";

class SignerMobileController {
    constructor() { }

    async getSignersPerformanceRatingsStats(request, reply) {
        const { signerId } = request.query;
        const performanceRatingsStats = {};

        const totalOrderSql = `SELECT COUNT(*) AS orderTotalCount FROM \`order\` WHERE
            signerId=${signerId} AND (progressId <> ${ORDER_PROGRESS_ID.CANCELED} AND progressId <> ${ORDER_PROGRESS_ID.HOLD});`;

        //get total Order
        await new Promise((resolve) =>
            Bookshelf.knex
                .raw(totalOrderSql)
                .then((totalOrderQueryResult) => {
                    performanceRatingsStats.orderTotalCount = totalOrderQueryResult[0][0].orderTotalCount;
                    resolve();
                })
                .catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                })
        );

        if (!hasValue(performanceRatingsStats.orderTotalCount)) {
            performanceRatingsStats.orderTotalCount = 0;
        }
        //get All Others infor
        await new Promise((resolve) =>
            Signer
                .where({ signerId })
                .fetch({ columns: ["mistakesCount", "ordersCount", "avgTurn", "avgFee", "lastSigning"] })
                .then((signerInfo) => {
                    let { mistakesCount, ordersCount, avgTurn, avgFee } = signerInfo.attributes;
                    const { lastSigning } = signerInfo.attributes;
                    mistakesCount = hasValue(mistakesCount) ? mistakesCount : 0;
                    ordersCount = hasValue(ordersCount) ? ordersCount : 0;
                    avgTurn = hasValue(avgTurn) ? avgTurn : 0;
                    avgFee = hasValue(avgFee) ? avgFee : 0;

                    performanceRatingsStats.orderCompletedCount = ordersCount;
                    performanceRatingsStats.orderActiveCount = performanceRatingsStats.orderTotalCount - ordersCount;
                    performanceRatingsStats.mistakesCount = mistakesCount;
                    performanceRatingsStats.mistakesPercent = mistakesCount / ordersCount * 100;
                    performanceRatingsStats.avgTurn = avgTurn;
                    performanceRatingsStats.firstOrderAptDateTime = lastSigning;

                    const mistakesScore = mistakesCount / ordersCount * 7500;
                    const avgTurnScore = (avgTurn - 12) * 5;
                    const avgFeeScore = (avgFee - 50) * 10;
                    const ratingScore = 1000 - (mistakesScore + avgTurnScore + avgFeeScore);

                    performanceRatingsStats.ratingScore = ratingScore;

                    if (ordersCount === 0) {
                        performanceRatingsStats.overallRating = OVERALL_RATING_SCALE.NEW.RATING;
                    } else if (ratingScore >= OVERALL_RATING_SCALE.EXCELLENT.MINSCORE) {
                        performanceRatingsStats.overallRating = OVERALL_RATING_SCALE.EXCELLENT.RATING;
                    } else if (ratingScore >= OVERALL_RATING_SCALE.VERYGOOD.MINSCORE) {
                        performanceRatingsStats.overallRating = OVERALL_RATING_SCALE.VERYGOOD.RATING;
                    } else if (ratingScore >= OVERALL_RATING_SCALE.GOOD.MINSCORE) {
                        performanceRatingsStats.overallRating = OVERALL_RATING_SCALE.GOOD.RATING;
                    } else if (ratingScore >= OVERALL_RATING_SCALE.FAIR.MINSCORE) {
                        performanceRatingsStats.overallRating = OVERALL_RATING_SCALE.FAIR.RATING;
                    } else if (ratingScore >= OVERALL_RATING_SCALE.CAUTION.MINSCORE) {
                        performanceRatingsStats.overallRating = OVERALL_RATING_SCALE.CAUTION.RATING;
                    } else if (ratingScore >= OVERALL_RATING_SCALE.REVIEW.MINSCORE) {
                        performanceRatingsStats.overallRating = OVERALL_RATING_SCALE.REVIEW.RATING;
                    } else {
                        performanceRatingsStats.overallRating = null;
                    }

                    resolve();
                })
                .catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                })
        );

        reply({
            performanceRatingsStats
        });
    }

    async getSignersAttentions(request, reply) {
        const { signerId } = request.query;
        const getSignersAttentions = {};
        //fucking hard code constant
        const closeExpireNumDay = 30;
        let signerState = "";

        await new Promise((resolve) =>
            Signer
                .where({ signerId })
                .fetch({ columns: ["weekdayState"] })
                .then((signerInfo) => {
                    let { weekdayState } = signerInfo.attributes;
                    weekdayState = hasValue(weekdayState) ? weekdayState : "";
                    signerState = weekdayState;
                    resolve();
                })
                .catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                })
        );

        //get missing doc
        const missingDocsSql = `SELECT SDT.docType AS docName FROM signer_doctypes SDT
            WHERE (
                NOT EXISTS (SELECT 1 FROM signer_docs SD WHERE SDT.DocTypeId = SD.DocTypeID AND SD.SignerId = ${signerId})
                AND (SDT.States = 'US' OR FIND_IN_SET('${signerState}', SDT.States))
            );`;

        await new Promise((resolve) =>
            Bookshelf.knex
                .raw(missingDocsSql)
                .then((missingDocsResult) => {
                    getSignersAttentions.missingDocs = missingDocsResult[0];
                    resolve();
                })
                .catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                })
        );

        //get close expired docs
        const closeExpireDocsSql = `SELECT SDT.DocType AS docName, SD.ExpireDate AS expireDate
        FROM
            signer_doctypes SDT
            INNER JOIN signer_docs SD 
            ON SDT.DocTypeID = SD.DocTypeId AND SDT.Expires = 1 
            AND SD.SignerId = ${signerId} AND DATEDIFF(SD.ExpireDate, UTC_TIMESTAMP()) <= ${closeExpireNumDay} AND DATEDIFF(SD.ExpireDate, UTC_TIMESTAMP()) > 0
        ;`;

        await new Promise((resolve) =>
            Bookshelf.knex
                .raw(closeExpireDocsSql)
                .then((closeExpireDocsResult) => {
                    getSignersAttentions.closeExpireDocs = closeExpireDocsResult[0];
                    resolve();
                })
                .catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                })
        );

        //get close expired docs
        const expiredDocsSql = `SELECT SDT.DocType AS docName, SD.ExpireDate AS expireDate
        FROM
            signer_doctypes SDT
            INNER JOIN signer_docs SD 
            ON SDT.DocTypeID = SD.DocTypeId AND SDT.Expires = 1 
            AND SD.SignerId = ${signerId} AND DATEDIFF(SD.ExpireDate, UTC_TIMESTAMP()) <= 0
        ;`;

        await new Promise((resolve) =>
            Bookshelf.knex
                .raw(expiredDocsSql)
                .then((expiredDocsResult) => {
                    getSignersAttentions.expiredDocs = expiredDocsResult[0];
                    resolve();
                })
                .catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                })
        );

        getSignersAttentions.jobAids = [];
        getSignersAttentions.trainingCourses = [];

        reply({ getSignersAttentions });
    }
}
export default new SignerMobileController();