import AnnouncementsControler from "./announcements-controller";

const routes = [{
    path: "/announcements/getAnnouncementsByUserId",
    method: "GET",
    config: {
        auth: false
    },
    handler: AnnouncementsControler.getAnnouncementsByUserId
},
{
    path: "/announcements/addUpdateUserAnnouncements",
    method: "POST",
    config: {
        auth: false
    },
    handler: AnnouncementsControler.addUpdateUserAnnouncements
}, {
    path: "/announcements/getVendorAnnouncements",
    method: "GET",
    config: {
        auth: false
    },
    handler: AnnouncementsControler.getVendorAnnouncements
}
];

export default routes;