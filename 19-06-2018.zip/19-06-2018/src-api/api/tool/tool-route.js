import ToolController from "./tool-controller";
const routes = [
    {
        path: "/tool/getListResource",
        method: "GET",
        handler: ToolController.getListResource
    },
    {
        path: "/tool/getListLink",
        method: "GET",
        handler: ToolController.getListLink
    },
    {
        path: "/tool/getFaqsByQuestion",
        method: "GET",
        handler: ToolController.getFaqsByQuestion
    }
];

export default routes;