import Boom from "boom";
import Resource from "../../db/model/resource";
import appConfig from "../../config/config";
import fs from "fs";
import Bookshelf from "../../db/database";
import Links from "../../db/model/links";
// import Faq from "../../db/model/faq";

class ToolController {
    constructor() { }

    getListResource(request, reply) {
        // new Resource().fetchAll({ columns: ["Title", "Description"] })
        Resource.fetchAll({ columns: ["Title", "Description", "Resource"] })
            .then((result) => {
                if (result !== null) {
                    reply({
                        listResource: result
                    });
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
        return;
    }

    downloadResources(request, reply) {
        const {
            fileName
        } = request.query;

        const filePath = `${appConfig.file.serverPath}/upload/resources/${fileName}`;

        fs.readFile(filePath, (err, data) => {
            if (err) throw err;
            return reply(data)
                .header("content-disposition", `attachment; filename=${fileName}`);
        });
    }

    getListLink(request, reply) {
        new Links().fetchAll({ columns: ["Id", "LinkTitle", "Link", "Description", "Type", "Target"] })
            .then((result) => {
                reply({
                    links: result
                });
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
        return;
    }

    getFaqsByQuestion(request, reply) {
        const { question } = request.query;
        const sqlQuery = `SELECT Id, SectId, Question, Answer, Views
        FROM faq
        WHERE Question LIKE '%${question}%'`;

        Bookshelf.knex.raw(sqlQuery)
            .then((result) => {
                reply({
                    faqs: result[0]
                });
                // console.log(JSON.stringify(result[0][0]));
            }).catch(() => {
                reply("No record found");
            });
    }

}

export default new ToolController();