import Boom from "boom";
import Bookshelf from "../../db/database";
import ClientServicesConfig from "../../db/model/client-services-config";
import ClientServicesConfigLog from "../../db/model/client-services-config-log";
import { handleSingleQuote, replaceAll } from "../../helper/common-helper";
import moment from "moment";
import sendMailCore from "../../mail/mail-helper";

class ClientServicesConfigController {
    getClientServicesConfigData(request, reply) {
        const { createdBy, numRow } = request.query;

        const rawSql = `call GetClientServicesConfigurationData(${+createdBy}, ${+numRow})`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        data: {
                            states: result[0][0],
                            configs: result[0][1]
                        }
                    });
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

    hasPendingServicesConfig(request, reply) {
        const { createdBy } = request.query;

        ClientServicesConfig.where({ createdBy, EffecttiveDate: null }).fetchAll({ columns: ["configId"] }).then(result => {

            reply({ isSuccess: true, hasPendingServicesConfig: result.length > 0, servicesConfigs: result });

        }).catch(error => {
            reply(Boom.badRequest(error));

            return reply;
        });
    }

    // Add new services config
    addServicesConfig(request, reply) {
        const servicesConfig = request.payload;

        servicesConfig.CreatedDate = servicesConfig.UpdatedDate;

        Bookshelf.transaction((t) => {

            return new ClientServicesConfig()
                .save(servicesConfig, { method: "insert", transacting: t })
                .tap(model => {
                    delete servicesConfig.CreatedBy;
                    delete servicesConfig.CreatedDate;
                    delete servicesConfig.ClientID;
                    servicesConfig.ConfigId = model.id;

                    return new ClientServicesConfigLog().save(servicesConfig, { method: "insert", transacting: t });
                });

        }).then(() => {
            reply({ isSuccess: true });

            return;
        }).catch((error) => {
            reply(Boom.badRequest(error));

            return;
        });
    }

    // Update
    updateServicesConfig(request, reply) {
        const servicesConfig = request.payload;
        const configId = servicesConfig.ConfigId;
        delete servicesConfig.ConfigId;

        Bookshelf.transaction((t) => {

            return ClientServicesConfig
                .where({ ConfigId: configId })
                .save(servicesConfig, { method: "update", transacting: t })
                .tap(() => {
                    servicesConfig.ConfigId = configId;

                    return new ClientServicesConfigLog().save(servicesConfig, { method: "insert", transacting: t });
                });

        }).then(() => {
            reply({ isSuccess: true });

            return;
        }).catch((error) => {
            reply(Boom.badRequest(error));

            return;
        });
    }

    getListServiceConfig(request, reply) {
        const { clientName, status, sortColumn, sortDirection, page, itemPerPage } = request.query;

        let requestStatus = status;
        if (!requestStatus) requestStatus = null;

        const rawSql = `call GetListServiceConfigRequest('${handleSingleQuote(clientName)}', ${requestStatus}, '${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage});`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        listService: {
                            data: result[0][0],
                            totalRecords: result[0][1][0].TotalRecords
                        }
                    });
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

    getServiceConfigChange(request, reply) {
        const { configId } = request.query;

        const rawSqlConfig = `SELECT configId, clientId, createdDate, IF(useVolume, OrderPerDay,'') AS orderPerDay, 
                                        IF(UseCalendar, CutoffDate,'') AS cutoffDate,
                                        IF(UseGeography, State1,'') AS state,
                                        IF(UseGeography, MSA1,'') AS msa
                            FROM client_services_config where configId = ${configId};`;

        const replyData = { config: {}, configPre: {} };
        Bookshelf.knex.raw(rawSqlConfig)
            .then(result => {
                if (result[0][0]) {
                    replyData.config = result[0][0] || {};

                    const rawSqlConfigLog = `SELECT configId, IF(useVolume, OrderPerDay,'') AS orderPerDay, 
                                                IF(UseCalendar, CutoffDate,'') AS cutoffDate,
                                                IF(UseGeography, State1,'') AS state,
                                                IF(UseGeography, MSA1,'') AS msa
                                    FROM client_services_config where ClientID = ${replyData.config.clientId || 0} and createdDate < '${moment(replyData.config.createdDate).utc().format("YYYY-MM-DD HH:mm:ss")}'
                                    order by createdDate desc
                                    LIMIT 1;`;
                    Bookshelf.knex.raw(rawSqlConfigLog)
                        .then(previousChange => {
                            if (previousChange[0][0]) {
                                replyData.configPre = previousChange[0][0] || {};
                            }

                            reply(replyData);
                        }).catch((error) => {
                            reply(Boom.badRequest(error));

                            return reply;
                        });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

    async approvalServiceConfig(request, reply) {
        const { approvalConfigId, closeConfigId, accountId, effectiveDate } = request.payload;

        await new Promise(resolve => ClientServicesConfig.where({ ConfigId: approvalConfigId })
            .save({ Status: 2, ApprovedBy: accountId, EffecttiveDate: effectiveDate }, { method: "update" })
            .then(() => {
                if (closeConfigId) {
                    ClientServicesConfig.where({ ConfigId: closeConfigId })
                        .save({ Status: 3 }, { method: "update" })
                        .then(() => {
                            resolve();
                        }).catch((error) => {
                            reply(Boom.badRequest(error));

                            return reply;
                        });
                } else {
                    resolve();
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            })
        );

        const rawSqlGetDataForEmail = `select b.PrimaryContactFirst, b.Email,
        b.PrimaryContactLast, 
        IF(c.useVolume, c.OrderPerDay,'') AS orderPerDay, 
        IF(c.UseCalendar, c.CutoffDate,'') AS cutoffDate,
        IF(c.UseGeography, c.State1,'') AS state,
        IF(c.UseGeography, c.MSA1,'') AS msa from client_services_config c left join broker b on b.BrokerID = c.ClientID where c.ConfigId = ${approvalConfigId};`;

        Bookshelf.knex.raw(rawSqlGetDataForEmail)
            .then(resultEmailData => {
                const emailData = resultEmailData[0][0];
                const rawSqlGetEmailTemplate = `SELECT * FROM notification_templates where Purpose = 'Service Config Approved';`;

                Bookshelf.knex.raw(rawSqlGetEmailTemplate)
                    .then(resultEmailTemplate => {
                        const emailTemplate = resultEmailTemplate[0][0];
                        const subject = emailTemplate.Subject;
                        let message = emailTemplate.Message;
                        message = replaceAll(message, ["[clientFirstName]"], `${emailData.PrimaryContactFirst}`);
                        message = replaceAll(message, ["[clientLastName]"], `${emailData.PrimaryContactLast}`);
                        message = replaceAll(message, ["[numberOfOrder]"], `${emailData.orderPerDay}`);
                        message = replaceAll(message, ["[date]"], `${emailData.cutoffDate ? `1 - ${emailData.cutoffDate}` : ""}`);
                        message = replaceAll(message, ["[state]"], `${emailData.state}`);
                        message = replaceAll(message, ["[msa]"], `${emailData.msa}`);

                        const mailOptions = {
                            from: emailTemplate.FromEmail,
                            to: emailData.Email,
                            subject,
                            html: message
                        };

                        sendMailCore(mailOptions);

                        reply({ isSuccess: true });
                    }).catch((error) => {
                        reply(Boom.badRequest(error));

                        return reply;
                    });
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }
}

export default new ClientServicesConfigController();