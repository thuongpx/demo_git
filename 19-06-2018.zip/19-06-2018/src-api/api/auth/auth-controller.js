import { AUTH } from "../../constant/common-constant";
import Jwt from "../../lib/jwt";
import moment from "moment";
import Boom from "boom";
import Bookshelf from "../../db/database";

import { isBuffer, bufferToBoolean, bookshelfError, hasStringValue, getNextDayUtc, isAfter, hasValue } from "../../helper/common-helper";

import User from "../../db/model/users";
import Employees from "../../db/model/employees";
import Broker from "../../db/model/brokers";
import Signer from "../../db/model/signers";
import Agent from "../../db/model/agents";
import SecAnswers from "../../db/model/sec-answers";

import { guid } from "../../helper/crypto-helper";

class AuthController {
	constructor() { }

	createAnAccount(request, reply) {
		const {
			username,
			password,
			mappingUserId,
			tenantId
		} = request.payload;

		if (username === undefined || username === null || password === undefined || password === null) {
			reply(Boom.badRequest("Missing credentials"));
			return;
		}

		// hash password
		const salt = Jwt.generateSalt();
		const hashedPassword = Jwt.hash(password, salt);

		new User().save({
			Username: username,
			Password: hashedPassword,
			MappingUserId: mappingUserId,
			TenantId: tenantId,
			HashSalt: salt
		}, { method: "insert" })
			.then((rs) => {
				if (rs === null) {
					reply(Boom.badRequest("Can not save account"));
					return;
				}

				const { UserID, TenantID } = rs.attributes;

				reply({
					UserID,
					TenantID
				});
			});
	}

	register(request, reply) {
		const {
			user
		} = request.payload;

		// validate user
		const newUser = new User(user);

		if (newUser.isNew()) {
			// create user
			new User(user)
				.save()
				.then((result) => {
					if (result === null) {
						reply(Boom.badRequest(AUTH.REGISTERED_FAILED));
						return;
					}

					const { UserID, TenantID } = result.attributes;

					reply({
						UserID,
						TenantID
					});
				}, () => {
					reply(Boom.badRequest(AUTH.REGISTERED_FAILED));
					return;
				});
		}
	}

	checkUserNeedToResetPassword(request, reply) {
		const { userId } = request.query;

		User.where({ UsersId: userId, NeedToResetPassword: true }).count("*").then((count) => {
			if (count > 0) {
				reply({ needResetPassword: true, userId });
			} else {
				reply({ needResetPassword: false });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	authorize(request, reply) {
		const {
			grant
		} = request.payload;

		const validateUser = async (user) => {
			let isNeedToResetPassword = false;
			let isExpiredPassword = false;
			let isNeedToSetChallengeQuestion = false;
			let isValid = true;

			const secAnswers = await SecAnswers.where({ UserId: user.UsersId }).count("*");

			// need to change password instantly
			if (user.NeedToResetPassword) {
				isNeedToResetPassword = true;
				isValid = false;
			}

			if (user.LastUpdate !== null) {
				// your password has been expired
				const days = moment().utc().diff(user.LastUpdate, "days");

				if (days > 90) {
					isExpiredPassword = true;
					isValid = false;
				}
			}

			if (secAnswers === 0) {
				isNeedToSetChallengeQuestion = true;
				isValid = false;
			}

			const temporaryToken = guid();

			// save to database to use later
			User.where({ UsersId: user.UsersId }).save({ TemporaryToken: temporaryToken }, { method: "update" });

			return {
				isNeedToResetPassword,
				isNeedToSetChallengeQuestion,
				isExpiredPassword,
				usersId: user.UsersId,
				isValid,
				tempToken: temporaryToken
			};
		};

		const signToken = (userId, username, scope, currentRefreshToken, isFirstLogin, tempToken) => {
			let rft = currentRefreshToken;
			const rftExpires = getNextDayUtc(7); // get expires time

			if (!hasStringValue(rft)) {
				// generate a new one
				rft = Jwt.generateRefershToken();
			}

			// save to database with expires time
			User
				.where({ UsersId: userId })
				.save({
					RefreshToken: rft,
					RefreshTokenExpires: moment(rftExpires).utc().format("YYYY-MM-DD HH:mm:ss")
				}, { method: "update" })
				.then(() => {
					// get token
					const token = Jwt.signIn(username, scope);

					reply({
						isSuccess: true,
						accessToken: token,
						refreshToken: rft,
						isFirstLogin,
						tempToken
					});
				})
				.catch(() => {
					reply(Boom.badRequest("Authorize Failed"));
				});
		};

		const checkUserFirstLogin = (user) => {
			if (!user.needToResetPassword && !user.logged) {
				const newUser = {
					Logged: 1
				};

				User
					.where({ UsersId: user.userId })
					.save(newUser, { method: "update" })
					.catch((error) => {
						reply(Boom.badRequest(error));
					});

				return true;
			}

			return false;
		};

		const checkSignerFirstLogin = (user) => {
			return user.RegistrationStep < 8;
		};

		const mapRoleByUserId = (userId, onSuccess, onError) => {
			const rolesSql = `CALL GetUserRolePermissions(${userId});`;

			const findPermission = (userRole, permission) => {
				return userRole.permissions.find((el) => {
					return el === permission;
				});
			};

			Bookshelf.knex.raw(rolesSql)
				.then((result) => {
					if (result === null) {
						return onError({
							message: `Unable to get role and permissions of user ${userId}`
						});
					}

					const rolePermissions = result[0][0];
					const userRole = {
						roleNames: [],
						permissions: [],
						roleType: ""
					};

					// get role type
					if (rolePermissions && rolePermissions.length > 0) {
						userRole.roleType = rolePermissions[0].Type;

						rolePermissions.forEach((role) => {
							const existingRole = userRole.roleNames.find((e) => {
								return e === role.RoleName;
							});

							if (!existingRole) {
								// get role name
								userRole.roleNames.push(role.RoleName);

								// get permissions
								Object.keys(role).forEach((permission) => {
									const value = role[permission];

									if (isBuffer(value) && bufferToBoolean(value)) {
										const existingPermission = findPermission(userRole, permission);

										if (!existingPermission) {
											userRole.permissions.push(permission);
										}
									}
								});
							}
						});

						return onSuccess(userRole);
					}

					return onError({
						message: `Unable to get role and permissions of user ${userId}`
					});
				}, (err) => {
					return onError({
						message: `Unable to get role and permissions of user ${userId}: ${JSON.stringify(err)}`
					});
				});
		};

		const getUserInformation = (userId, tenantId, mappingUserId, userName, refreshToken, logged, needToResetPassword, tempToken) => {
			// get user information and build a new access token
			mapRoleByUserId(userId, (userRole) => {
				// get his profile based on role type
				switch (userRole.roleType) {
					case "Staff":
						Employees.where({
							tenantId,
							RepId: mappingUserId
						})
							.fetch({ columns: ["RepId", "FirstName", "LastName"] })
							.then((profile) => {
								if (profile === null) {
									reply(Boom.badRequest(AUTH.USER_NOT_FOUND));
									return;
								}

								const { FirstName, LastName, RepId } = profile.attributes;
								signToken(userId, userName, {
									id: userId,
									role: userRole,
									tenantId,
									profile: {
										id: RepId,
										firstName: FirstName,
										lastName: LastName,
										userName,
										userId,
										subRoleType: ""
									}
								}, refreshToken, false, tempToken);
							}).catch((err) => {
								reply(Boom.badRequest(bookshelfError(err)));
								return;
							});
						break;
					case "Client": {
						const isUserFirstLogin = checkUserFirstLogin({ logged, needToResetPassword, userId });

						if (userRole.roleNames[0] === "Agent") {
							Agent
								.where({
									tenantId,
									AgentId: mappingUserId
								})
								.fetch({ columns: ["AgentId", "FullName", "inActive", "BrokerId", "Email"] })
								.then(profile => {
									if (profile === null) {
										reply(Boom.badRequest(AUTH.USER_NOT_FOUND));
										return;
									}

									const inActive = profile.attributes.inActive;
									if (isBuffer(inActive) && bufferToBoolean(inActive)) {
										reply(Boom.badRequest(AUTH.USER_NOT_FOUND));
										return;
									}

									const { FullName, AgentId, BrokerId, Email } = profile.attributes;
									signToken(userId, userName, {
										id: userId,
										role: userRole,
										tenantId,
										profile: {
											id: AgentId,
											firstName: FullName,
											lastName: "",
											userName,
											userId,
											subRoleType: "AGENT",
											brokerId: BrokerId,
											email: Email
										}
									}, refreshToken, isUserFirstLogin, tempToken);
								})
								.catch((err) => {
									reply(Boom.badRequest(bookshelfError(err)));
									return;
								});
						} else {
							Broker
								.where({
									tenantId,
									BrokerID: mappingUserId
								})
								.fetch({ columns: ["BrokerID", "Company", "IndustryId", "GID", "ProfilePicture"] })
								.then((profile) => {
									if (profile === null) {
										reply(Boom.badRequest(AUTH.USER_NOT_FOUND));
										return;
									}

									const { Company, BrokerID, GID, IndustryId, ProfilePicture } = profile.attributes;
									signToken(userId, userName, {
										id: userId,
										role: userRole,
										tenantId,
										profile: {
											id: BrokerID,
											firstName: Company,
											lastName: "",
											userName,
											userId,
											subRoleType: GID !== null && GID > 0 ? "BRANCH" : "CLIENT",
											GID,
											industryId: IndustryId,
											img: hasValue(ProfilePicture) ? ProfilePicture : ""
										}
									}, refreshToken, isUserFirstLogin, tempToken);
								});
						}
						break;
					}
					case "Vendor":
						Signer.where({
							tenantId,
							SignerId: mappingUserId
						})
							.fetch({ columns: ["SignerId", "FirstName", "LastName", "RegistrationStep"] })
							.then((profile) => {
								if (profile === null) {
									reply(Boom.badRequest(AUTH.USER_NOT_FOUND));
									return;
								}

								const { FirstName, LastName, SignerId, RegistrationStep } = profile.attributes;
								signToken(userId, userName, {
									id: userId,
									role: userRole,
									tenantId,
									profile: {
										id: SignerId,
										firstName: FirstName,
										lastName: LastName,
										userName,
										userId,
										subRoleType: ""
									}
								}, refreshToken, checkSignerFirstLogin({ RegistrationStep }), tempToken);
							})
							.catch((err) => {
								reply(Boom.badRequest(bookshelfError(err)));
								return;
							});
						break;
				}
			}, (err) => {
				reply(Boom.badRequest(err.message));
				return;
			});
		};

		const checkSignerOfferGuid = async (signerId, uniqueGuid) => {
			const sql = `select count(*) as Num from signer_offer
			where SignerId = '${signerId}' and GUID = '${uniqueGuid}' and GuidExpiredTime >= '${moment().format("YYYY-MM-DD HH:mm:ss")}'`;

			const matched = await Bookshelf.knex.raw(sql);

			return matched[0][0].Num > 0;
		};

		const authorizePassword = async () => {
			const {
				userId,
				username,
				password,
				GUID,
				tempToken
			} = request.payload;

			let user = null;

			if (!hasStringValue(username) && !hasStringValue(userId)) {
				reply(Boom.badRequest("Invalid Username"));
				return;
			}

			try {
				if (hasStringValue(username)) {
					user = await User
						.query({ where: { UserName: username } })
						.fetch({
							columns: [
								"UsersId", "Password", "HashSalt",
								"MappingUserId", "TenantId", "Inactive",
								"UserName", "NeedToResetPassword", "LastUpdate",
								"Logged", "TemporaryToken"
							]
						});
				} else {
					user = await User
						.query({ where: { UsersId: userId } })
						.fetch({
							columns: [
								"UsersId", "Password", "HashSalt",
								"MappingUserId", "TenantId", "Inactive",
								"UserName", "NeedToResetPassword", "LastUpdate",
								"Logged", "TemporaryToken"
							]
						});
				}

				if (user === null) {
					reply(Boom.badRequest(AUTH.USER_NOT_FOUND));
					return;
				}

				const {
					Password, HashSalt, MappingUserId,
					TenantId, UsersId, Inactive,
					UserName, LastUpdate, NeedToResetPassword,
					Logged, TemporaryToken
				} = user.attributes;

				const isUserInactive = bufferToBoolean(Inactive);
				let isValidUser = false;

				if (hasStringValue(GUID)) {
					isValidUser = await checkSignerOfferGuid(MappingUserId, GUID);
				} else if (hasStringValue(tempToken) && hasStringValue(userId)) {
					isValidUser = TemporaryToken === tempToken;
				} else {
					isValidUser = Jwt.checkPassword(Password, HashSalt, password);
				}

				// check password
				if (isValidUser) {
					// user is valid
					if (isUserInactive) {
						reply(Boom.badRequest(`Inactive account.`));
						return;
					}

					// remove the temporary token
					if (hasStringValue(tempToken) && hasStringValue(userId)) {
						User.where({ UsersId }).save({ TemporaryToken: null }, { method: "update" });
					}

					const validationResult = await validateUser({ LastUpdate, NeedToResetPassword: bufferToBoolean(NeedToResetPassword), UsersId, UserName });
					if (validationResult && validationResult.isValid) {
						getUserInformation(UsersId, TenantId, MappingUserId, UserName, null, Logged, bufferToBoolean(NeedToResetPassword), validationResult.tempToken);
					} else {
						reply(validationResult);
					}
					return;
				} else {
					reply(Boom.badRequest(AUTH.INCORRECT_PASSWORD));
					return;
				}
			} catch (err) {
				reply(Boom.badRequest(AUTH.UNEXPECTED_ERROR));
				return;
			}
		};

		const authorizeRefreshToken = () => {
			const {
				userId,
				refreshToken
			} = request.payload;

			if (!hasStringValue(userId)) {
				reply(Boom.badRequest("Invalid User Id"));
				return;
			}

			// validate refresh token with user id
			User.where({ UsersId: userId, RefreshToken: refreshToken })
				.fetch({ columns: ["UsersId", "Password", "HashSalt", "MappingUserId", "TenantId", "Inactive", "UserName", "RefreshTokenExpires"] })
				.then(rs => {
					if (rs === null) {
						reply(Boom.unauthorized(AUTH.USER_NOT_FOUND));
						return;
					}

					const { RefreshTokenExpires, UsersId, TenantId, MappingUserId, UserName } = rs.attributes;

					const isExpired = isAfter(RefreshTokenExpires);

					if (!isExpired) {
						// refresh token is valid
						getUserInformation(UsersId, TenantId, MappingUserId, UserName, refreshToken);
					} else {
						// refresh token is invalid, announce user to re-login
						reply(Boom.unauthorized(`Expired refresh token`));
					}
				})
				.catch((err) => {
					reply(Boom.badRequest(`Unable to connect to database: ${JSON.stringify(err)}`));
					return;
				});
		};

		const grantType = grant ? grant.toUpperCase() : "";

		switch (grantType) {
			case "REFRESH_TOKEN":
				authorizeRefreshToken();
				break;
			default:
				authorizePassword();
				break;
		}
	}
}

export default new AuthController();