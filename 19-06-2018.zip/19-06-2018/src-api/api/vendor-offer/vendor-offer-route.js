import VendorOfferController from "./vendor-offer-controller";
const routes = [
    {
        path: "/vendor-offer/getVendorOffer",
        method: "GET",

        handler: VendorOfferController.getVendorOffer
    },
    {
        path: "/vendor-offer/addVendorOffer",
        method: "POST",

        handler: VendorOfferController.addVendorOffer
    },
    {
        path: "/vendor-offer/updateStatusVendorOffer",
        method: "POST",

        handler: VendorOfferController.updateStatusVendorOffer
    },
    {
        path: "/vendor-offer/getReasonDeclined",
        method: "GET",

        handler: VendorOfferController.getReasonDeclined
    },
    {
        path: "/vendor-offer/sendRequestFeedback",
        method: "POST",

        handler: VendorOfferController.sendRequestFeedback
    },
    {
        path: "/vendor-offer/inactivatedUser",
        method: "POST",

        handler: VendorOfferController.inactivatedUser
    },
    {
        path: "/vendor-offer/checkExistVendorOffer",
        method: "GET",

        handler: VendorOfferController.checkExistVendorOffer
    },
    {
        path: "/vendor-offer/getVendorOfferByGUID",
        method: "GET",

        handler: VendorOfferController.getVendorOfferByGUID
    },
    {
        path: "/vendor-offer/getAccountbyGUID",
        method: "GET",

        handler: VendorOfferController.getAccountbyGUID
    },
    {
        path: "/mobile/vendor-offer/getOffers",
        method: "GET",
        handler: VendorOfferController.mobileGetOffers
    },
    {
        path: "/mobile/vendor-offer/mobileSendRequestFeedback",
        method: "POST",
        handler: VendorOfferController.mobileSendRequestFeedback
    },
    {
        path: "/mobile/vendor-offer/mobileAcceptOffers",
        method: "POST",
        handler: VendorOfferController.mobileAcceptOffers
    },
    {
        path: "/mobile/vendor-offer/checkExistVendorOffer",
        method: "GET",
        handler: VendorOfferController.checkExistVendorOffer
    }
];

export default routes;