import ClientController from "./client-controller";

const routes = [{
    path: "/client/getClients",
    method: "POST",
    handler: ClientController.getClients
}, {
    path: "/client/getClientManagementData",
    method: "POST",
    handler: ClientController.getClientManagementData
}, {
    path: "/client/addClient",
    method: "POST",
    config: { auth: false },
    handler: ClientController.addClient
}, {
    path: "/client/updateClient",
    method: "POST",
    handler: ClientController.updateClient
}, {
    path: "/client/getClientById",
    method: "GET",
    handler: ClientController.getClientById
}, {
    path: "/client/changeStatusClient",
    method: "GET",
    handler: ClientController.changeStatusClient
}, {
    path: "/client/getClientContactByClientId",
    method: "GET",
    handler: ClientController.getClientContactByClientId
}, {
    path: "/client/getClientOrderByClientId",
    method: "GET",
    handler: ClientController.getClientOrderByClientId
}, {
    path: "/client/getAllClientForDropDown",
    method: "GET",
    handler: ClientController.getAllClientForDropDown
}, {
    path: "/client/updateClientContact",
    method: "POST",
    handler: ClientController.updateClientContact
}, {
    path: "/client/getBranchesByBrokerId",
    method: "GET",
    handler: ClientController.getBranchesByBrokerId
}, {
    path: "/client/getClientStatusReport",
    method: "GET",
    handler: ClientController.getClientStatusReport
}, {
    path: "/client/updateClientIsAvailable",
    method: "POST",
    handler: ClientController.updateClientIsAvailable
}, {
    path: "/client/getSpecialInstrucionOfClient",
    method: "GET",
    handler: ClientController.getSpecialInstrucionOfClient
}];

export default routes;