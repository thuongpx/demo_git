import NotaryTraning from "./vendor-notary-training-controller";

const routes = [
    {
        path: "/notarytraning/getlistPrograms",
        method: "GET",
        handler: NotaryTraning.getlistPrograms
    },
    {
        path: "/notarytraning/getListCourseandTestbyProgramId",
        method: "GET",
        handler: NotaryTraning.getListCourseandTestbyProgramId
    },
    {
        path: "/vendor-notary-training-controller/getListLearningPathProgram",
        method: "GET",
        handler: NotaryTraning.getListLearningPathProgram
    },
    {
        path: "/vendor-notary-training-controller/getListOfPopularPrograms",
        method: "GET",
        handler: NotaryTraning.getListOfPopularPrograms
    }
    // ,
    // {
    //     path: "/notarytraning/getListTestbyProgramId",
    //     method: "GET",
    //     handler: NotaryTraning.getListTestbyProgramId
    // }
];


export default routes;