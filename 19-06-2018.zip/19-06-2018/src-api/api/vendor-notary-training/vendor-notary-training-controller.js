// import Boom from "boom";
import Bookshelf from "../../db/database";
import Boom from "boom";
import {
    bufferToBoolean
} from "../../helper/common-helper";

class NotaryTraning {
    constructor() { }
    getlistPrograms(request, reply) {
        const { program, userId } = request.query;
        const rawSql = `SELECT Id, vp.ProgramId, tp.Title, vp.IsComplete, vp.CompletedDate , Description
        FROM vendor_registered_programs vp
        INNER JOIN training_programs tp on vp.ProgramId = tp.ProgramId
        INNER JOIN signer sg on sg.SignerId = vp.VendorId
        INNER JOIN users us on us.MappingUserId = sg.SignerId
        WHERE Title LIKE '%${program}%' and us.UsersId = ${userId}`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                const data = result[0];
                data.map(item => {
                    item.IsComplete = bufferToBoolean(item.IsComplete);
                });
                reply({
                    listProgram: result[0]
                });
            }).catch((error) => {
                reply(`"Not found record : " + ${error}`);
            });
    }
    getListCourseandTestbyProgramId(request, reply) {
        const { programId } = request.query;
        const rawSql = `SELECT distinct tc.CourseId, ti.TestId, vcr.StartDate as courcestartdate, vcr.EndDate as courseenddate, vcr.IsComplete as coursestatus,
        vtr.StartDate as teststartdate, vtr.EndDate as testenddate, vtr.Passed as teststatus
        FROM tce_dev2.vendor_registered_programs vr
        INNER JOIN training_program_courses tpc on vr.ProgramId = tpc.ProgramId
        INNER JOIN training_program_test tpt on vr.ProgramId = tpt.ProgramId
        INNER JOIN training_courses tc on tc.CourseId = tpc.CourseId
        INNER JOIN vendor_courses_result vcr on vcr.CourseId = tc.CourseId
        INNER JOIN vendor_test_result vtr on vtr.TestId = tpt.TestId
        INNER JOIN test_info ti on ti.TestId = tpt.TestId
        WHERE vr.ProgramId = ${programId}`;
        Bookshelf.knex.raw(rawSql)
            .then(result => {
                reply({
                    listCourseandTestinProgram: result[0]
                });
            }).catch((error) => {
                reply(`"Not found record: " + ${error}`);
            });
    }
    // getListTestbyProgramId(request, reply) {
    //     const { programId } = request.query;
    //     const rawTest = `select distinct ti.TestName, vr.StartDate, vr.EndDate, vr.Passed from vendor_test_result vr, test_info ti where vr.TestId in
    //     (SELECT distinct TestId FROM training_program_test tt
    //     INNER JOIN training_programs tp on tt.ProgramId= tp.ProgramId
    //     INNER JOIN training_program_courses tc on tt.ProgramId = tc.ProgramId
    //     where tp.ProgramId = '${programId}')`;
    //     Bookshelf.knex.raw(rawTest)
    //         .then(result => {
    //             reply({
    //                 listTestinProgram: result[0]
    //             });
    //         }).catch((error) => {
    //             reply(`"Not found record: " + ${error}`);
    //         });
    // }

    getListLearningPathProgram(request, reply) {
        const rawSql = `SELECT lp.LPID, lp.LPName, p.Title, p.ForVendor, p.Inactive, p.IsPublished FROM training_learning_path lp 
        inner join training_lp_programs lpp on lp.LPID = lpp.LPID
        inner join training_programs p on lpp.ProgramId = p.ProgramId
        where p.ForVendor = 1 and p.Inactive = 0 and p.IsPublished = 1;`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                const data = result[0];
                data.map((item) => {
                    item.ForVendor = bufferToBoolean(item.ForVendor);
                    item.Inactive = bufferToBoolean(item.Inactive);
                    item.IsPublished = bufferToBoolean(item.IsPublished);
                });
                reply({
                    listLearningPathProgram: result[0]
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getListOfPopularPrograms(request, reply) {
        const rawSql = `select v.ProgramId, tp.Title, count(v.ProgramId) number 
                        from vendor_registered_programs v, training_programs tp
                        where v.ProgramId = tp.ProgramId
                        group by ProgramId 
                        ORDER BY COUNT(v.ProgramId) DESC
                        LIMIT 10;`;
        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                reply({
                    listOfPopularPrograms: result[0]
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}
export default new NotaryTraning();