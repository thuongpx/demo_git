export default {
    production: {
        serverPath: "./src/content",
        fileExtenstions: ["pdf", "tiff", "doc", "docx", "jpg", "xls", "xlsx"],
        maxBytes: 1024 * 1024 * 20, // max: 50 MB
        maxBytesSignerDoc: 1024 * 1024 * 10 // max: 10 MB
    },
    development: {
        serverPath: "./src/content",
        fileExtensions: ["pdf", "tiff", "doc", "docx", "jpg", "xls", "xlsx"],
        maxBytes: 1024 * 1024 * 20, // max: 50 MB
        maxBytesSignerDoc: 1024 * 1024 * 10 // max: 10 MB
    },
    test: {
        serverPath: "./src/content",
        fileExtensions: ["pdf", "tiff", "doc", "docx", "jpg", "xls", "xlsx"],
        maxBytes: 1024 * 1024 * 20, // max: 50 MB
        maxBytesSignerDoc: 1024 * 1024 * 10 // max: 10 MB
    }
};