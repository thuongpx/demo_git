export default {
    production: {
        apiAccessKey: "AKIAIHKYBNT7QJJ4VSBQ",
        apiSecretKey: "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",
        snsArn: "arn:aws:sns:us-east-1:841040368837:app/APNS/CE-Production",
        snsArnEnv: "APNS"
    },
    development: {
        apiAccessKey: "AKIAIHKYBNT7QJJ4VSBQ",
        apiSecretKey: "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",
        snsArn: "arn:aws:sns:us-east-1:841040368837:app/APNS/CE-Production",
        snsArnEnv: "APNS"
    },
    test: {
        apiAccessKey: "AKIAIHKYBNT7QJJ4VSBQ",
        apiSecretKey: "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",
        snsArn: "arn:aws:sns:us-east-1:841040368837:app/APNS_SANDBOX/CE-Mobile",
        snsArnEnv: "APNS_SANDBOX"
    }
};