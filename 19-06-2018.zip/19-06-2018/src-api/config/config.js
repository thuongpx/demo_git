/* eslint-disable no-console */

import dbConfig from "./db.config";
import envConfig from "./env.config";
import mailConfig from "./mail.config";
import braintreeConfig from "./braintree.config";
import fileConfig from "./file.config";
import awsConfig from "./aws.config";
const env = "development";

console.log(`>> api environment: ${env}`);

console.log(`>> database configurations`);
console.log(`--- host: ${dbConfig[env].host}`);
console.log(`--- user: ${dbConfig[env].user}`);
console.log(`--- database: ${dbConfig[env].database}`);

console.log(`>> mail configurations`);
console.log(`--- host: ${mailConfig[env].host}`);
console.log(`--- port: ${mailConfig[env].port}`);
console.log(`--- timeout: ${mailConfig[env].timeout}`);

module.exports = {
    application: {
        host: envConfig[env].host,
        port: envConfig[env].port,
        secretKey: envConfig[env].secretKey
    },
    database: {
        host: dbConfig[env].host,
        user: dbConfig[env].user,
        password: dbConfig[env].password,
        database: dbConfig[env].database
    },
    server: {
        defaultHost: "http://localhost:8001"
    },
    mail: {
        host: mailConfig[env].host,
        port: mailConfig[env].port,
        timeout: mailConfig[env].timeout,
        user: mailConfig[env].user,
        pass: mailConfig[env].pass,
        form: mailConfig[env].form,
        webOrders: mailConfig[env].webOrders,
        faxBacks: mailConfig[env].faxBacks
    },
    braintree: braintreeConfig[env],
    file: {
        serverPath: fileConfig[env].serverPath,
        fileExtensions: fileConfig[env].fileExtensions,
        maxBytes: fileConfig[env].maxBytes,
        maxBytesSignerDoc: fileConfig[env].maxBytesSignerDoc
    },
    aws: {
        apiAccessKey: awsConfig[env].apiAccessKey,
        apiSecretKey: awsConfig[env].apiSecretKey,
        snsArn: awsConfig[env].snsArn,
        snsArnEnv: awsConfig[env].snsArnEnv
    }
};