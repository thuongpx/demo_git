export default {
	production: {
		host: "10.133.28.217",
		port: 9001,
		secretKey: "AT595r768gqHdSLqzew746hNp5VrpN7a"
	},
	development: {
		host: "localhost",
		port: 3001,
		secretKey: "lF7ioZHOa4iafmUfhcWwkUFRb7P7F09K"
	},
	test: {
		host: "10.133.28.217",
		port: 9001,
		secretKey: "UdeyPg9xXlXVFZc6HZ4yLZcnuNlAV8Ag"
	}
};
