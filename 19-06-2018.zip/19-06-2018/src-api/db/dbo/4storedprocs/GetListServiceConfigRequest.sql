

DROP PROCEDURE IF EXISTS `GetListServiceConfigRequest`;


DELIMITER $$

CREATE PROCEDURE `GetListServiceConfigRequest` (
	IN clientName varchar (255),
    IN requestStatus int,
    IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);  
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY UpdatedDate ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;   
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    SET whereQuery = ' WHERE 1=1';
    IF (clientName IS NOT NULL AND clientName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND t1.clientName LIKE ''%', clientName, '%''');
	END IF;
    IF (requestStatus IS NOT NULL AND requestStatus <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND t1.status = ', requestStatus);
	END IF;
    
    SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from
			(select configId, c.createdDate, updatedDate, clientId, c.status, c.effecttiveDate, Concat(b.PrimaryContactFirst," ", b.PrimaryContactLast) as clientName, u.UserName as requestedBy
			FROM client_services_config c left join broker b on c.ClientID = b.BrokerID
            left join users u on u.UsersId = c.UpdatedBy) t1, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$
 
DELIMITER ;