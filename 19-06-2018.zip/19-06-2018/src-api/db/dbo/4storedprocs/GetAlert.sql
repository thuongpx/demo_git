DROP PROCEDURE IF EXISTS `GetAlert`;

DELIMITER $$
CREATE PROCEDURE `GetAlert`(
	IN pageNumber int,
	IN pageSize int,
    IN role varchar(255),
	IN clientId int
)
BEGIN
	DECLARE orderQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(500);  
    DECLARE andWhereQuery varchar(500);
	IF (role = 'Client') 
		THEN SET andWhereQuery = CONCAT(' AND (o.BrokerId=',clientId,' or o.BrokerId in (select Brokerid from `broker` where `broker`.GID = ',clientId, '))');
	ELSE IF  (role = 'Branch') 
		THEN SET andWhereQuery = CONCAT(' AND o.BrokerId=',clientId);
	ELSE IF (role = 'Agent') 
		THEN SET andWhereQuery = CONCAT(' AND o.AgentId=',clientId);
		END IF;
    END IF;
    END IF;
       
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

    SET whereQuery = CONCAT(' Where op.ProgressType = ', 1, andWhereQuery);
                            
	
	SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS
			op.progressLogId,
			op.orderId,
			op.DateLog,
			op.activity,
            op.isRead,
            o.aptDateTime
            FROM `order` as o
            INNER JOIN zip ON o.Zip = `zip`.Zip
            LEFT JOIN `order_progress_log` as op ON o.OrderId=op.orderId' , whereQuery,' ORDER BY op.DateLog DESC  ', limitQuery);
            

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$
DELIMITER ;