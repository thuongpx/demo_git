DROP procedure IF EXISTS `GetApprovalFeeRequests`;

DELIMITER $$
CREATE PROCEDURE `GetApprovalFeeRequests` (
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN orderId varchar(255),
IN status varchar(255),
IN brokerId varchar(255)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(500);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY date ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = CONCAT(' WHERE (o.brokerid = ', brokerId, ' or o.brokerId in (select brokerId from broker where gid= ',
    brokerId ,')) and (case when o.agentId is null then per.RoleName end =''Vendor'' OR
            case when o.agentId is not null then per.RoleName end =''Agent'')');
	IF (status IS NOT NULL AND status <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND f.FeeApproved = ''', status, '''');
	END IF;
    IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND f.OrderId = ', orderId);
	END IF;
    
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
		f.feeApprovalId as approvalId,
		f.DateStamp AS date,
        f.orderId,
        concat(s.lastname, '' '', s.firstname) as vendorName,
        GetTotalAdditionalFee(f.OrderID, FeeDescripId) + IFNULL(FeeAmount, 0) AS feeAmount,
        f.feeAmount + IFNULL(fee.OriginalSignerFee, 0) as feeUpdate,
        fee.OriginalSignerFee as originalAmount,
        r.ReasonDescription as reason,
        f.FeeApproved as status,
        f.usersId, 
        s.signerId, 
        f.feeDescripId,
        o.aptDateTime, 
        f.offerId
	FROM `order_fee_approve` AS f
    inner join (select orderid, sum(OriginalSignerFee) OriginalSignerFee from `order_fee` group by orderid) fee  on f.OrderId = fee.OrderID
    inner join `order_fee_approve_reason` r on f.ReasonCode = r.ReasonCode
    inner join `order` as o on f.OrderId=o.OrderId
    left join `signer` s on f.signerid = s.signerid
    inner JOIN `users` AS u ON u.UsersId = f.UsersId
    inner join `user_roles` role on u.UsersId=role.UsersId
    inner join `role_permission` per on role.RoleId=per.RoleId, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$
