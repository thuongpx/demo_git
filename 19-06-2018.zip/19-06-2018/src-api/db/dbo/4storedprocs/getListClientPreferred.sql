DROP procedure IF EXISTS `getListClientPreferred`;

DELIMITER $$

CREATE PROCEDURE `getListClientPreferred` (
	IN clientId int,
    IN isCustomerPreferred boolean,
    IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255); 
    DECLARE tableName varchar(30);
    DECLARE idField varchar(15);
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY FirstName ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF; 
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    SET tableName = IF(isCustomerPreferred, 'customer_preferred_vendor', 'broker_preferred_vendor');
    SET idField = IF(isCustomerPreferred, 'customerId', 'brokerId');
    
    SET whereQuery = ' WHERE 1=1';
    
    IF (clientId IS NOT NULL AND clientId <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND t1.clientId = ', clientId);
	END IF;

    
    SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from
			(SELECT id, ',idField,' as clientId, signerId, firstName, lastName, email, taxId, IF(signerId IS NULL, "Inactive", "Active") as status  FROM ',tableName,') t1, 
            (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
            
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;    
END$$

DELIMITER ;