DROP PROCEDURE IF EXISTS `GetDataSendMailApproval`;

DELIMITER $$
CREATE PROCEDURE `GetDataSendMailApproval`(
IN isApproval bit,
IN users_Id int(11),
IN signer_Id int(11),
IN isVendor bit,
IN approval_Id int(11)
)
BEGIN
	declare toAgentEmail varchar(250);
    declare agentName varchar(50);
    declare toVendorEmail varchar(250);
    declare vendorName varchar(50);
    declare loanType varchar(50);
    declare distance float;
    declare city varchar(50);
    declare aptDateTime datetime;
    declare firstName varchar(15);
    declare lastName varchar(25);
    declare originalSignerFee decimal(19,4);
    
    if(isApproval)
    then if(isVendor)
		then select lo.LoanType, 
			69.1*sqrt(POWER((s.Lat - o.Lat), 2) + 0.6*POWER((s.Long - o.Long), 2)) AS distance,
			o.City, o.AptDateTime, s.FirstName, s.LastName, fee.originalSignerFee into loanType, distance, city, aptDateTime, firstName, lastName, originalSignerFee
			FROM signers_approval sa 
			LEFT JOIN `order` o ON sa.OrderId = o.OrderId
            left join (select ofee.orderid, sum(ofee.OriginalSignerFee) originalSignerFee from `order_fee` ofee group by ofee.orderid) fee  on sa.OrderId = fee.OrderID
			left join `loan_type` lo on o.LoanType = lo.LoanTypeId
			LEFT JOIN signer s ON s.SignerId = sa.SignerId
			where s.signerid=signer_Id and sa.ApprovalID = approval_Id;
        else
			select lo.LoanType, 
			69.1*sqrt(POWER((s.Lat - o.Lat), 2) + 0.6*POWER((s.Long - o.Long), 2)) AS distance,
			o.City, o.AptDateTime, s.FirstName, s.LastName into loanType, distance, city, aptDateTime, firstName, lastName
			FROM order_fee_approve ofa
			LEFT JOIN `order` o ON ofa.OrderId = o.OrderId
			left join `loan_type` lo on o.LoanType = lo.LoanTypeId
			LEFT JOIN signer s ON s.SignerId = ofa.SignerId
			where s.signerid=signer_Id and ofa.FeeApprovalId = approval_Id;
        end if;
	end if;
		SELECT ss.email, concat(ss.FirstName, ' ', ss.LastName) into toVendorEmail, vendorName FROM signer ss where ss.signerid=signer_Id;
		select a.Email, a.FullName into toAgentEmail, agentName from users u
		inner join agent a on a.AgentId= u.MappingUserId
		where u.UsersId=users_Id;
	if(isVendor)
		then if(isApproval)
			then SELECT FromEmail,Subject,Message, toAgentEmail, vendorName, agentName FROM notification_templates where Purpose='Vendor Recommendation - Vendor - Approved' and Receiver='Agent''s email';
            SELECT FromEmail,Subject,Message, toVendorEmail, vendorName, loanType, distance, city, aptDateTime, firstName, lastName, originalSignerFee FROM notification_templates where Purpose='Offer Accepted-Vendor' and Receiver='Vendor';
		else 
			SELECT FromEmail,Subject,Message, toAgentEmail, vendorName, agentName FROM notification_templates where Purpose='Vendor Recommendation Rejected' and Receiver='Agent''s email';
		end if;
	else 
		if(isApproval)
			then SELECT FromEmail,Subject,Message, toAgentEmail, vendorName, agentName FROM notification_templates where Purpose='Agent''s Fee Request Approved' and Receiver='Client Agent';
			SELECT FromEmail,Subject,Message, toVendorEmail, vendorName, loanType, distance, city, aptDateTime, firstName, lastName FROM notification_templates where Purpose='Offer Accepted-Vendor' and Receiver='Vendor';
		else 
			SELECT FromEmail,Subject,Message, toAgentEmail, vendorName, agentName FROM notification_templates where Purpose='Agent''s Fee Request Rejected' and Receiver='Client Agent';
            SELECT FromEmail,Subject,Message, toVendorEmail, vendorName, agentName FROM notification_templates where Purpose='Agent''s Fee Request Rejected' and Receiver='Vendor';
		end if;
    end if;
END