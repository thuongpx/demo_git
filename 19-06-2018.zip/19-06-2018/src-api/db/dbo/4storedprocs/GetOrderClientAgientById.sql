DROP PROCEDURE IF EXISTS `getOrderClientAgentById`;
DELIMITER $$
CREATE PROCEDURE `getOrderClientAgentById`(
	IN clientId int(11),
    IN branchId int(11),
    IN searchString varchar(255),
    IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(5000);  
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY a.FullName';
	ELSE SET orderQuery = CONCAT(' ORDER BY a.', sortBy, sortDirectionQuery);
    END IF;
    
    SET whereQuery = 'where (a.Inactive is null OR a.Inactive=false) ';
    IF (branchId IS NOT NULL AND branchId > 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND a.BrokerId = ', branchId);
	ELSE
		SET whereQuery = CONCAT(whereQuery ,' AND (a.BrokerId = ', clientId ,' or a.BrokerId in (select b.BrokerID from broker b where b.GID = ',clientId,')) '); 
	END IF;
    
    IF (searchString IS NOT NULL AND searchString <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND ( a.FullName like "%', searchString ,'%" OR a.Email like "%', searchString ,'%" ) ');
	END IF;
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    IF (pageSize = -1) 
		THEN SET limitQuery= '';
	END IF;
    
    set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS a.AgentId, a.AfterhoursPhone, a.FullName, a.Direct, a.Ext, a.Fax, a.Email from agent a ', whereQuery, orderQuery, limitQuery);
    
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

    SELECT FOUND_ROWS() as TotalRecords;
END$$
DELIMITER ;