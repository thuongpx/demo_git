CREATE DEFINER=`tce`@`%` PROCEDURE `GetAvailableSigner`(
	IN `sortBy` VARCHAR(255),
	IN `sortDirection` BIT,
	IN `pageNumber` INT,
	IN `pageSize` INT,
	IN `whereText` VARCHAR(500),
	IN `brokerId` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN
    DECLARE orderQuery varchar(255);
	DECLARE sortDirectionQuery varchar(255);
    DECLARE limitQuery varchar(255);
    DECLARE whereQuery varchar(1000);

	SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
      
	IF (whereText IS NULL OR whereText = '')
       THEN SET whereQuery = CONCAT('WHERE SignerId NOT IN (SELECT SignerId FROM broker_donotuse WHERE BrokerId = ',brokerId, ')');
	ELSE SET whereQuery = CONCAT(
	 ' WHERE ( s.SignerId = \'',
	 whereText,
	 '%\' OR CONCAT(s.FirstName, " ", s.LastName) LIKE \'%',
	 whereText,
	 '%\'
	  ) AND SignerId NOT IN (SELECT SignerId FROM broker_donotuse WHERE BrokerId = ', brokerId, ')'
	 );
    END IF;    
         
	SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
				s.SignerId,
				concat(s.FirstName, " ", s.LastName) as Name,
				concat(s.WeekdayCity, ", ", s.WeekdayState) as CityState
				FROM signer s
				, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

   SELECT FOUND_ROWS() as TotalRecords;

END