DROP procedure IF EXISTS `GetNotifByNotifID`;

DELIMITER $$
CREATE DEFINER=`tce`@`%` PROCEDURE `GetNotifByNotifID`(	
	IN notificationId int(11)
)
BEGIN
    DECLARE whereQuery varchar(255);
	
    SET whereQuery = ' WHERE 1=1 ';
     
	IF(notificationId IS NOT NULL AND notificationId >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `NotificationId` = ', notificationId);
	END IF;
     
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from ( select distinct `notification_templates`.NotifID as `NotificationId`,
									`notification_templates`.Type as `notificationType`,
									`notification_templates`.Purpose as `purpose`,
                                    `notification_templates`.FromName as `fromName`,
                                    `notification_templates`.FromEmail as `fromEmail`,
                                     `notification_templates`.Receiver as `receiver`,
                                    `notification_templates`.Subject as `subject`,
                                    `notification_templates`.Message as `message`
							FROM `notification_templates`) t1, (SELECT @rownum := 0) r', whereQuery );


    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    
    
    SELECT FOUND_ROWS() as TotalRecords;
END