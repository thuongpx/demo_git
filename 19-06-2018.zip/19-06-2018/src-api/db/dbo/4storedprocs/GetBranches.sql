DROP PROCEDURE IF EXISTS `GetBranches`;

DELIMITER $$

CREATE PROCEDURE `GetBranches`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN brokerID varchar(100),
IN company varchar(500),
IN contactFirst varchar(500),
IN contactLast varchar(500),
IN GID varchar(100)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = ' WHERE IsAvailable=1';
	IF (brokerID IS NOT NULL AND brokerID <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND BrokerID = ', brokerID);
	END IF;
    IF (GID IS NOT NULL AND GID <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND GID = ', GID);
	END IF;
    IF (company IS NOT NULL AND company <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Company LIKE ''%', company, '%''');
	END IF;
    IF (contactFirst IS NOT NULL AND contactFirst <>'')
		THEN
			SET contactFirst = QUOTE(CONCAT('%', contactFirst, '%'));
			SET whereQuery = CONCAT(whereQuery ,' AND PrimaryContactFirst LIKE ', contactFirst);
	END IF;
    IF (contactLast IS NOT NULL AND contactLast <>'')
		THEN
			SET contactLast = QUOTE(CONCAT('%', contactLast, '%'));
			SET whereQuery = CONCAT(whereQuery ,' AND PrimaryContactLast LIKE ', contactLast);
	END IF;

	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			BrokerID,
			Company,
            Phone,
			CONCAT_WS(" ", PrimaryContactFirst, PrimaryContactLast) AS ContactName,
            Email,
            b.Inactive,
            UserName
            FROM `broker` b
            INNER JOIN `users` u ON u.MappingUserId = b.BrokerID
			INNER JOIN `user_roles` ur ON u.UsersId = ur.UsersId AND ur.RoleId = 6
            , (SELECT @rownum := 0) r', whereQuery, orderQuery, limitQuery);
	
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$
DELIMITER ;