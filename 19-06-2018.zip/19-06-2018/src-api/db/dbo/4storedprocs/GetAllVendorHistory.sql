DROP PROCEDURE IF EXISTS `GetAllVendorHistory`;

DELIMITER $$

CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllVendorHistory`(
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN orderId int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY HistoryDate ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE 1=1 ');
    
    IF(orderId IS NOT NULL AND orderId >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `OrderId` = ', orderId);
	END IF;
     
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS t1.* from (select
									`signer_history`.HistoryDate as `HistoryDate`,
                                    `signer_history`.SignerId as `SignerId`,
                                    `signer_history`.OrderId,
                                    CONCAT(`signer`.LastName, " ", `signer`.FirstName) as `SignerName`, 
                                    `signer_history`.Status as `Status`
							FROM `signer_history`  
                            LEFT JOIN `signer` on `signer_history`.SignerId = `signer`.SignerId
                            ) t1, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    END

