DROP PROCEDURE IF EXISTS `DeclinedVendorOffer`;

DELIMITER $$
CREATE PROCEDURE `DeclinedVendorOffer`(
	IN offerID int,
	IN orderId int,
    IN userId int,
    IN signerId int,
    IN selectedReasonOptions int, 
    IN altTime datetime,
    IN typeID int,
    IN offerAmount decimal(19,4),
    IN feeAmount decimal(19,4),
    IN additionalInfo varchar(250)
)
BEGIN
	DECLARE feeDescripID decimal(19,4);
    DECLARE protductTypeOriginalFee decimal(19,4);
    DECLARE maxFeeApprovalId int;
    
    IF (selectedReasonOptions = 2 OR selectedReasonOptions = 3)
    THEN       
		SELECT of.FeeDescripID, of.SignerFee into feeDescripID, protductTypeOriginalFee FROM `order_fee` of
		INNER JOIN `broker_fee` bf ON bf.`FeeId` = of.`FeeDescripID`
		WHERE of.`OrderID` = orderId AND bf.`IsAdditionalFee` = 0;
		
		IF(selectedReasonOptions = 2)
        THEN SET selectedReasonOptions = 8;
        END IF;
        
        IF(selectedReasonOptions = 3)
        THEN SET selectedReasonOptions = 9;
        END IF;
        
		UPDATE `signer_offer`
        SET `OfferStatus` = 'P'
		WHERE `signer_offer`.`OrderId` = orderId
        AND `signer_offer`.`SignerId` = signerId
        AND `signer_offer`.`OfferID` = offerID;
        
        UPDATE `signer_offer`
        SET `OfferStatus` = 'D'
		WHERE `signer_offer`.`OrderId` = orderId
        AND `signer_offer`.`SignerId` = signerId
        AND `signer_offer`.`OfferID` <> offerID;
        
        INSERT INTO `order_fee_approve`(`OrderId`,`UsersId`,`FeeDescripID`,`ReasonCode`,`FeeReason`,`FeeAmount`,`FeeApproved`,`DateStamp`,`OriginalAmount`,`SignerID`, `OfferID`)
        VALUES (orderId,userId,feeDescripID, selectedReasonOptions, additionalInfo, protductTypeOriginalFee + (feeAmount - offerAmount),'Pending', UTC_TIMESTAMP(),protductTypeOriginalFee,signerId, offerID);
		SET maxFeeApprovalId = (SELECT LAST_INSERT_ID());
        
        INSERT INTO `comment`(`Description`,`CreatedDate`,`CreatedBy`,`TypeID`,`OwnerID`,`IsPrivate`)
        VALUES (additionalInfo, UTC_TIMESTAMP(), userId, typeID, maxFeeApprovalId, 0);
	ELSE       
		UPDATE `signer_offer`
        SET `DenialReasonID` = selectedReasonOptions,
			`AltTime` = altTime,
            `AdditionalInfo` = additionalInfo,
            `OfferStatus` = 'D'
		WHERE `signer_offer`.`OrderId` = orderId
        AND `signer_offer`.`SignerId` = signerId;
	END IF;		
END$$
