DROP PROCEDURE IF EXISTS `GetBlackListSignerCustomer`;

DELIMITER $$
CREATE PROCEDURE `GetBlackListSignerCustomer`(
    IN `sortBy` VARCHAR(255),
	IN `sortDirection` BIT,
	IN `pageNumber` INT,
	IN `pageSize` INT,
    IN `customerId` INT
)
BEGIN
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(500);  

	SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
      
	SET whereQuery = CONCAT(' WHERE customerId = ',customerId); 
         
	SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
					b.Id, s.SignerId, CONCAT(s.FirstName, " ", s.LastName) AS Name, 
					CONCAT(s.WeekdayCity, ", ", s.WeekdayState) AS CityState,
					b.Comment, b.Timestamp AS AddedDate
				FROM customer_donotuse b
					LEFT JOIN signer s ON b.SignerId = s.SignerId
				, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	   
    SELECT FOUND_ROWS() AS TotalRecords;
END$$
DELIMITER ;