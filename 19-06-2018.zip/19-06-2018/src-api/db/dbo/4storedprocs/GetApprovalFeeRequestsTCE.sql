DROP procedure IF EXISTS `GetApprovalFeeRequestsTCE`;

DELIMITER $$
CREATE PROCEDURE `GetApprovalFeeRequestsTCE` (
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN orderId varchar(255),
IN status varchar(255),
IN userId int,
IN isClientFee boolean
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(500);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY date ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = CONCAT(' WHERE (o.IsSelfService = 0 OR o.IsSelfService IS NULL) ');
	IF (status IS NOT NULL AND status <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND f.FeeApproved = ''', status, '''');
	END IF;
    
    IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND f.OrderId = ', orderId);
	END IF;
    
    IF(userId IS NOT NULL AND userId <> '' AND !isClientFee)
		THEN SET whereQuery = CONCAT(whereQuery, ' AND ( f.UsersId = ', userId, ' OR o1.RepId = ', userId, ' ) ');
	ELSE
		SET whereQuery = CONCAT(whereQuery, ' AND ( f.UsersId = ', userId,' ) ');
    END IF;
    
	SET @querySql= concat('SELECT DISTINCT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
		f.feeApprovalId as approvalId,
		f.DateStamp AS date,
        f.orderId,
        concat(s.lastname, '' '', s.firstname) as vendorName,
        GetTotalAdditionalFee(f.OrderID, f.FeeDescripId) + IFNULL(FeeAmount, 0) AS feeAmount,
        f.feeAmount + IFNULL(fee.OriginalSignerFee, 0) as feeUpdate,
        of.BrokerFee AS clientFee,
        fee.OriginalSignerFee as originalAmount,
        r.ReasonDescription as reason,
        f.FeeApproved as status,
        f.usersId, 
        s.signerId, 
        f.feeDescripId,
        o.aptDateTime, 
        f.offerId,
        u.UserName as approvedBy,
        u1.UserName as requestedBy
	FROM `order_fee_approve` AS f
    inner join (select orderid, sum(OriginalSignerFee) OriginalSignerFee from `order_fee` group by orderid) fee  on f.OrderId = fee.OrderID
    inner join `order_fee_approve_reason` r on f.ReasonCode = r.ReasonCode
    inner join `order` as o on f.OrderId=o.OrderId
    LEFT JOIN `order_fee` AS of ON of.OrderID=f.OrderId AND of.FeeDescripID = f.FeeDescripId
    LEFT JOIN users as u on u.UsersId = f.ApprovedBy
    LEFT JOIN users as u1 on u1.UsersId = f.UsersId
    left join `signer` s on f.signerid = s.signerid
    left join `order` as o1 on f.SignerID = o1.signerid, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
    
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$