DROP PROCEDURE IF EXISTS `autoVendorOffer`;

DELIMITER $$
CREATE PROCEDURE `autoVendorOffer`(
IN orderId int,
IN isEliteVendor BIT
)
BEGIN
	DECLARE lat1 FLOAT;
    DECLARE long1 FLOAT;
    DECLARE startZip VARCHAR(20);
    DECLARE brokerId INT;
    DECLARE state VARCHAR(2);
    DECLARE amount FLOAT;
    DECLARE languageId INT;
    DECLARE coLanguageId INT;
    DECLARE signerId INT;
    DECLARE customerId INT;
    DECLARE dist FLOAT;
    DECLARE autoProgress VARCHAR(1);
    DECLARE aptDateTime DATETIME;
    DECLARE aptDateTimeUtc DATETIME;
    DECLARE isVenOrCeDefineAdt BIT;
    DECLARE rowFindCount INT DEFAULT 0;
    DECLARE isFinished INTEGER DEFAULT 0;
    DECLARE eliteName VARCHAR(20) DEFAULT 'elite';
    DECLARE mile INT DEFAULT 50;
    DECLARE offerSent INT;
    
	DECLARE myCursor CURSOR FOR
		SELECT sn.signerId, (69.1*sqrt(power(zp.lat-lat1,2)+0.6*power(zp.long-long1,2))) as dist
		FROM signer sn
        LEFT JOIN zip zp ON sn.weekdayZip = zp.zip
		WHERE 
		-- distance signer within miles 50/100
		 (69.1*sqrt(power(zp.lat-lat1,2)+0.6*power(zp.long-long1,2))) < mile AND
		-- signer is active
		 (sn.inActive IS NULL OR sn.inActive = 0) AND
		-- co customer order language must match with signer language
		 (coLanguageId IS NULL OR coLanguageId = 0 OR coLanguageId IN (SELECT sl.languageId FROM signer_language sl WHERE sl.signerId = sn.signerId)) AND
		-- primary customer order language must match with signer language
		 (languageId IS NULL OR languageId = 0 OR languageId IN (SELECT sl.languageId FROM signer_language sl where sn.signerId= sl.signerId)) AND
		-- if vendor rating is new check qualified = "D" or "Q". Rating 6: New. 
		-- And rating must not poor (4) and need improvement (5)
		 (sn.rating NOT IN (4,5,6) OR ( sn.rating = 6 AND (sn.qualified = 'D' or sn.qualified = 'Q'))) AND
		-- signer does not include in DNU list of client/broker
		 sn.signerId NOT IN (SELECT brdnu.signerId FROM broker_donotuse brdnu WHERE brdnu.brokerId = brokerId) AND
		-- signer does not include in DNU list of customer
		 sn.signerId NOT IN (SELECT cusdnu.signerId FROM customer_donotuse cusdnu WHERE cusdnu.customerId = customerId) AND
		-- order’s apt time is not in vendor’s snooze time
		(isVenOrCeDefineAdt = 1 OR ((sn.snooze = 0 OR sn.Snooze IS NULL) 
					OR ((aptDateTimeUtc > sn.snoozeTo OR aptDateTimeUtc < sn.snoozeFrom )))) AND
		-- vendors have not accepted another order having the same aptDate and order progress in (closed, closing, cancelled)
		 (isVenOrCeDefineAdt = 1 OR (aptDateTime NOT IN (SELECT ord.aptDateTime FROM `order` ord 
							  WHERE ord.signerId = sn.signerId AND ord.progressId 
							  NOT IN (6,7,8,9,11) AND ord.orderId <> orderId))) AND
		
		-- order’s appt time is in vendor’s availability (days, evenings, weekends)
		-- (isVenOrCeDefineAdt = 1 OR ((sn.availDays = 1 AND HOUR(aptDateTime) >=8 AND HOUR(aptDateTime) <= 16 
													  -- AND WEEKDAY(aptDateTime) NOT IN (5,6)) 
								 -- OR (sn.availEves = 1 AND HOUR(aptDateTime) >=17 AND HOUR(aptDateTime) <= 10
													  -- AND WEEKDAY(aptDateTime) NOT IN (5,6)) 
								 -- OR (sn.AvailWkEnds = 1 AND (WEEKDAY(aptDateTime) = 5 OR WEEKDAY(aptDateTime) = 6)))) AND 
								  
		-- elite vendor and non-elite vendor
		 (
			-- elite vendor
			(isEliteVendor = 1 AND (((SELECT COUNT(catId) FROM vendor_categories WHERE catName = eliteName) = 0) OR ( 
				-- check min rating
				(sn.rating <= (SELECT vc.minRating FROM vendor_categories vc WHERE vc.catName = eliteName)) AND
				-- check number of order <= signer's complete orders 8 -> closing Completed
				((SELECT vc.minOrder FROM vendor_categories vc WHERE vc.catName = eliteName) 
				 <= (SELECT COUNT(ord.orderId) FROM `order` ord 
					 WHERE sn.signerId= ord.signerId AND ord.progressId = 8 )) AND
				-- vendor must take required tests
				((SELECT COUNT(vct1.testId) FROM vendor_cat_testtaken vct1 
				 WHERE vct1.catId = (SELECT catId FROM vendor_categories WHERE catName = eliteName))
				 = (SELECT COUNT(vct.testId) FROM vendor_cat_testtaken vct 
					  WHERE vct.catId = (SELECT catId FROM vendor_categories WHERE catName = eliteName) AND
					  vct.testId IN (SELECT vtr.testId FROM vendor_test_result vtr 
				  WHERE vtr.passed = 'Y' AND vtr.vendorId = sn.signerId)))
			 ))) OR 
			 -- non-elite vendor
			  (isEliteVendor = 0 AND (((SELECT COUNT(catId) FROM vendor_categories WHERE catName = eliteName) = 0) OR ( 
				-- check min rating
				(sn.rating > (SELECT vc.minRating FROM vendor_categories vc WHERE vc.catName = eliteName)) OR
				-- check number of order <= signer's complete orders 8 -> closing Completed
				((SELECT vc.minOrder FROM vendor_categories vc WHERE vc.catName = eliteName) 
				 > (SELECT COUNT(ord.orderId) FROM `order` ord 
					 WHERE sn.signerId= ord.signerId AND ord.progressId = 8 )) OR
				-- vendor must take required tests
				((SELECT COUNT(vct1.testId) FROM vendor_cat_testtaken vct1 
				 WHERE vct1.catId = (SELECT catId FROM vendor_categories WHERE catName = eliteName))
				 <> (SELECT COUNT(vct.testId) FROM vendor_cat_testtaken vct 
					  WHERE vct.catId = (SELECT catId FROM vendor_categories WHERE catName = eliteName) AND
					  vct.testId IN (SELECT vtr.testId FROM vendor_test_result vtr 
				  WHERE vtr.passed = 'Y' AND vtr.vendorId = sn.signerId)))
			 )))
		)
		
		LIMIT 0,15;
        
     -- handle no signer found
	DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET isFinished = 1;

	-- get zip, brokerId, state, feeAmount from order
    SELECT ord.zip , 
		   ord.brokerId, 
		   ord.state,
		   (SELECT SUM(of.signerFee) FROM order_fee of WHERE of.orderId = ord.orderID),
           ord.languageId,
           ord.coLanguageId,
           ord.customerId,
           ord.aptDateTime,
           DATE_SUB(ord.aptDateTime, INTERVAL z.utc HOUR),
           ord.isVenOrCeDefineAdt,
           ord.autoProgress
	INTO startZip, brokerId, state, amount, languageId, coLanguageId, customerId, aptDateTime, aptDateTimeUtc, isVenOrCeDefineAdt,autoProgress
	FROM `order` ord
    LEFT JOIN zip z on z.zip = ord.zip
	WHERE ord.orderID = orderId;
    
    -- get lat, long by zip of order
	SELECT lat, `long` INTO lat1,long1 FROM zip WHERE zip = startZip LIMIT 0,1;

    Open myCursor;
    IF FOUND_ROWS() < 10
	  THEN
		SET mile = 100;
	END IF;
    
    CLOSE myCursor;
    
    SET isFinished=0;
    
    Open myCursor;
    
    IF (FOUND_ROWS() = 0 AND isEliteVendor = 1)
	  THEN UPDATE `order` ord SET ord.autoProgress = 'F' WHERE ord.orderId = orderId;
	END IF;
    
    IF (FOUND_ROWS() = 0 AND isEliteVendor = 0 AND autoProgress = 'F')
      THEN UPDATE `order` ord SET ord.autoProgress = 'X' WHERE ord.orderId = orderId;
    END IF;
    
	IF (FOUND_ROWS() = 0 AND isEliteVendor = 0 AND autoProgress = 'E')
      THEN UPDATE `order` ord SET ord.autoProgress = 'Y' WHERE ord.orderId = orderId;
    END IF;
    
    IF (FOUND_ROWS() > 0 AND isEliteVendor = 1)
      THEN UPDATE `order` ord SET ord.autoProgress = 'E' WHERE ord.orderId = orderId;
    END IF;
    
    IF (FOUND_ROWS() > 0 AND isEliteVendor = 0)
      THEN UPDATE `order` ord SET ord.autoProgress = 'V' WHERE ord.orderId = orderId;
    END IF;
    
    IF (FOUND_ROWS() = 15 AND isEliteVendor = 1)
	  THEN UPDATE `order` ord SET ord.autoProgress = 'D' WHERE ord.orderId = orderId;
	END IF;
    
    -- send offer loop
    sendOffers: LOOP
		FETCH myCursor INTO signerId, dist;
        IF isFinished = 1 THEN LEAVE sendOffers;
        END IF;
        -- only send maximun 15 offer for non-elite vendor
        IF ( IsEliteVendor = 1 OR
			(SELECT COUNT(DISTINCT OrderId,SignerId) FROM signer_offer so WHERE so.orderId = orderId AND repId = -1 AND so.isEliteVendor = 0) < 15) 
        THEN INSERT INTO signer_offer(orderID,signerID,offerAmount,repID,sentDate,tenantId,isEliteVendor,distance,guid,offerStatus)
			 VALUES (orderId,signerId,amount,-1,UTC_TIMESTAMP(),1,IsEliteVendor,dist,uuid(),'O');
        END IF;
	END LOOP sendOffers;
    CLOSE myCursor;
END

