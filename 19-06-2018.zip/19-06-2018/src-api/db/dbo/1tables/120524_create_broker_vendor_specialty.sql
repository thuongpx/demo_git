CREATE TABLE IF NOT EXISTS `broker_vendor_specialty` (
  `BrokerId` INT NOT NULL,
  `CatId` INT NOT NULL
  );