CREATE TABLE IF NOT EXISTS `user_roles` (
	`Id` INT(11) NOT NULL AUTO_INCREMENT,
    `UsersId` INT(11) NOT NULL,
    `RoleId` INT(11) NOT NULL,
    PRIMARY KEY (`Id`),
    KEY `userid_user_roles_idx` (`UsersId`),
    KEY `roleid_user_roles_idx` (`RoleId`),
    CONSTRAINT `userid_user_roles` FOREIGN KEY (`UsersId`) REFERENCES `users` (`UsersId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `roleid_user_roles` FOREIGN KEY (`RoleId`) REFERENCES `role_permission` (`RoleId`) ON DELETE NO ACTION ON UPDATE NO ACTION    
);