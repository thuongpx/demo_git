CREATE TABLE IF NOT EXISTS `training_program_courses` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ProgramId` int(11) NULL,
  `CourseId` int(11) NULL,
  PRIMARY KEY (`Id`),
  KEY `programId_training_program_courses_idx` (`ProgramId`),
  CONSTRAINT `programId_training_program_courses` FOREIGN KEY (`ProgramId`) REFERENCES `training_programs` (`ProgramId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  KEY `courseId_training_program_courses_idx` (`CourseId`),
  CONSTRAINT `courseId_training_program_courses` FOREIGN KEY (`CourseId`) REFERENCES `training_courses` (`CourseId`) ON DELETE NO ACTION ON UPDATE NO ACTION
)
