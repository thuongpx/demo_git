ALTER TABLE `employees` 
ADD COLUMN `MaxNumOrders` INT(4) NULL AFTER `ProfilePicture`;
