CREATE TABLE IF NOT EXISTS `broker_preferred_vendor` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `BrokerId` INT NOT NULL,
  `SignerId` INT NULL,
  `FirstName` VARCHAR(15) NULL,
  `LastName` VARCHAR(25) NULL,
  `Email` VARCHAR(75) NULL,
  `TaxId` VARCHAR(50) NULL,
  PRIMARY KEY (`Id`)
  );