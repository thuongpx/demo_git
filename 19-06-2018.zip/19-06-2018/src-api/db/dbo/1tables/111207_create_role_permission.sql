use tce_dev;
-- Request from AnNV2
-- Add loan type
CREATE TABLE IF NOT EXISTS `role_permission` (
    `RoleId` INT(11) NOT NULL AUTO_INCREMENT,
    `Description` VARCHAR(150) NOT NULL,
    `Type` VARCHAR(15) NOT NULL,
    PRIMARY KEY (`RoleId`)
);