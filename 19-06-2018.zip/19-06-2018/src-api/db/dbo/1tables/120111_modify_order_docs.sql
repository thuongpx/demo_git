use tce_dev;

ALTER TABLE `order_docs` ADD COLUMN `ReviewDate` DATETIME NULL;
ALTER TABLE `order_docs` ADD COLUMN `ReviewedBy` INT(11) NULL AFTER `ReviewDate`;
ALTER TABLE `order_docs` ADD COLUMN `Comment` VARCHAR(250) NULL AFTER `ReviewedBy`;
ALTER TABLE `order_docs` ADD INDEX `reviewedby_order_doc_idx` (`ReviewedBy` ASC);
ALTER TABLE `order_docs` ADD CONSTRAINT `reviewedby_order_doc` FOREIGN KEY (`ReviewedBy`)
  REFERENCES `users` (`UsersId`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
