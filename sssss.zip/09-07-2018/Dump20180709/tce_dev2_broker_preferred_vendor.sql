-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `broker_preferred_vendor`
--

DROP TABLE IF EXISTS `broker_preferred_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `broker_preferred_vendor` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BrokerId` int(11) NOT NULL,
  `SignerId` int(11) DEFAULT NULL,
  `FirstName` varchar(15) DEFAULT NULL,
  `LastName` varchar(25) DEFAULT NULL,
  `Email` varchar(75) DEFAULT NULL,
  `TaxId` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `broker_preferred_vendor`
--

LOCK TABLES `broker_preferred_vendor` WRITE;
/*!40000 ALTER TABLE `broker_preferred_vendor` DISABLE KEYS */;
INSERT INTO `broker_preferred_vendor` VALUES (1,53,42,'Test','Tester','pavaso01@adb.com','555-11-2222'),(2,53,239,'Khanh1','Le1','pavaso01@ada.com',NULL),(58,76,NULL,'2131','12322','pavso01@abd.com','213123123'),(59,76,320,'khanh2','le2','pavaso01@adb.com','2321'),(61,5,311,'Lam','VT','pavaso01@adb.com','25251325'),(75,5,62,'Ameenah J.','Abdulla','pavaso01@adb.com','471-86-3682'),(76,5,187,'Tammy L.','Sutherland-Abbott','pavaso01@adb.com','525-15-7099'),(77,5,207,'Stuart S.','Cudaback-Cox','pavaso01@adb.com','34-4461272'),(78,5,232,'Paula Y.','Cable','pavaso01@adb.com','587-45-1612'),(79,5,NULL,'adsfadsf','fadf','abcd@gmail.com','1234'),(81,5,NULL,'\'\'\'\'\'\'abc','\'\'\'\'','pavaso01@adb.com','1231231231'),(82,5,NULL,'\'ab','\'bc','pavaso01@adb.com','1233322'),(83,5,NULL,'\"an','dfa\"','pavaso01@adb.com','2131233332'),(84,16,NULL,'\'\\%\\_[]','asdbc','asd@da.com','123'),(85,16,NULL,'\'\"\\\\\\\\\\_[]\\%','Rot','asd@sad.com','12'),(86,16,NULL,'\'\\\\_%[]','dsjkfhajkdf','acb@acb.com','123123123'),(87,16,NULL,'\'_\\%[]','adf','adf@adf.com','12312312');
/*!40000 ALTER TABLE `broker_preferred_vendor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-09 18:39:50
