-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agent`
--

DROP TABLE IF EXISTS `agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent` (
  `AgentId` int(11) NOT NULL AUTO_INCREMENT,
  `TenantId` int(11) DEFAULT NULL,
  `Ext` varchar(5) DEFAULT NULL,
  `Fax` varchar(10) DEFAULT NULL,
  `Email` varchar(70) DEFAULT NULL,
  `AfterhoursPhone` varchar(10) DEFAULT NULL,
  `Inactive` bit(1) DEFAULT NULL,
  `BranchID` int(11) DEFAULT NULL,
  `Direct` varchar(15) DEFAULT NULL,
  `ViewAll` bit(1) DEFAULT NULL,
  `BrokerId` int(11) DEFAULT NULL,
  `FullName` varchar(150) DEFAULT NULL,
  `NeedResetPassword` bit(1) DEFAULT b'0',
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `ProfilePicture` longblob,
  PRIMARY KEY (`AgentId`),
  UNIQUE KEY `AgentId_UNIQUE` (`AgentId`),
  KEY `TenantId_idx` (`TenantId`),
  KEY `brokerid_agent_idx` (`BrokerId`),
  KEY `branch_agent_idx` (`BranchID`),
  CONSTRAINT `TenantId_agent` FOREIGN KEY (`TenantId`) REFERENCES `tenant` (`TenantId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `branch_agent` FOREIGN KEY (`BranchID`) REFERENCES `branches` (`BranchID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `brokerid_agent` FOREIGN KEY (`BrokerId`) REFERENCES `broker` (`BrokerID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent`
--

LOCK TABLES `agent` WRITE;
/*!40000 ALTER TABLE `agent` DISABLE KEYS */;
INSERT INTO `agent` VALUES (1,1,'123','3453454543','pavaso01@adb.com','2132132132','\0',NULL,'1232131231','\0',10,'Agent of Branch FPT3','\0','Agent1','Branch FPT',NULL),(2,1,'','','pavaso01@adb.com','','\0',NULL,'','\0',1,'Helen Swift','\0',NULL,NULL,NULL),(3,1,'','','pavaso01@adb.com','','\0',NULL,'','\0',2,'AgentCompany','\0',NULL,NULL,NULL),(4,1,'','','pavaso01@adb.com','','\0',NULL,'','\0',37,'HangAgent','\0',NULL,NULL,NULL),(5,1,'','','pavaso01@adb.com','0145475454','\0',NULL,'','\0',36,'hue_agent','\0',NULL,NULL,NULL),(6,1,'','','pavaso01@adb.com','','\0',NULL,'','',40,'joe agent test','\0',NULL,NULL,NULL),(7,1,'','','pavaso01@adb.com','','\0',NULL,'','\0',2,'agent 2','\0',NULL,NULL,NULL),(8,1,'','','pavaso01@adb.com','','\0',NULL,'','\0',2,'test agent 3@','\0',NULL,NULL,NULL),(9,1,'43','2453453453','pavaso01@adb.com','4546464645','\0',NULL,'3214234234','',37,'MI Tong_Agent','\0',NULL,NULL,NULL),(10,1,'302','6558987755','pavaso01@adb.com','6148885544','\0',NULL,'6145073255','',19,'Rob Testyman','\0',NULL,NULL,NULL),(11,1,'302','6665555444','pavaso01@adb.com','8885554444','\0',NULL,'8885554444','',19,'Rob William','\0',NULL,NULL,NULL),(12,1,'323','2121212121','huent1@fsg.ins1.vn','1111111111','\0',NULL,'23232323','',45,'FPTAgent','\0',NULL,NULL,NULL),(13,1,'252','','pavaso01@adb.compavaso01@adb.com','7458584554','\0',NULL,'6155556688','',46,'Jana Banhagel','\0',NULL,NULL,NULL),(14,1,'','','pavaso01@adb.com','','\0',NULL,'','\0',31,'Bill Agent','\0',NULL,NULL,NULL),(15,1,'854','6516549846','pavaso01@adb.com','6565651651','\0',NULL,'9566516516','',33,'Tommy Tutone','\0',NULL,NULL,NULL),(16,1,'','','pavaso01@adb.com','','\0',NULL,'4584584588','',8,'Michelle Jacobson','\0',NULL,NULL,NULL),(17,1,'','','pavaso01@adb.com','','\0',NULL,'4564584588','',51,'Michelle Jacobson','\0',NULL,NULL,NULL),(18,1,'','','pavaso01@adb.com','','\0',NULL,'','\0',51,'Meesh Jacobson','\0',NULL,NULL,NULL),(19,1,'123','','pavaso01@adb.com','','\0',NULL,'8888888888','',9,'SSAgent','\0',NULL,NULL,NULL),(20,1,'','','pavaso01@adb.com','','\0',NULL,'','',59,'Michelle Parcell','\0',NULL,NULL,NULL),(21,1,'','','pavaso01@adb.com','','\0',NULL,'','',25,'Meesh Parcell','\0',NULL,NULL,NULL),(22,1,'','','pavaso01@adb.com','','\0',NULL,'1111111111','\0',64,'Hana Mourica-Agent','\0',NULL,NULL,NULL),(23,1,'','','test@mail.com','','\0',NULL,'1111111111','\0',2,'nguyen viet an','\0',NULL,NULL,NULL),(24,1,'','','testagent4@mail.com','','\0',NULL,'','\0',2,'testagent4@mail.com','\0',NULL,NULL,NULL),(25,1,'','','testagent4@mail.com','','\0',NULL,'','\0',2,'testagent5@mail.com','\0',NULL,NULL,NULL),(26,1,'','','testagent6@mail.com','','\0',NULL,'','\0',2,'testagent6@mail.com','\0',NULL,NULL,NULL),(27,1,'','','pavaso01@adb.com','','\0',NULL,'','\0',66,'AgentA','\0',NULL,NULL,NULL),(28,1,'','','annguyen@mail.com','2222222222','\0',NULL,'1111111111','\0',70,'Nguyen An','\0',NULL,NULL,NULL),(29,1,'','','pavaso01@adb.com','1111111111','\0',NULL,'','\0',71,'Agent of the newbranchActive','\0',NULL,NULL,NULL),(30,1,'','','pavaso01@adb.com','','\0',NULL,'','\0',71,'www1','\0',NULL,NULL,NULL),(31,1,'11111','','11@adn.com','','',NULL,'1111111111','\0',25,'www','\0',NULL,NULL,NULL),(32,1,'','','pavaso01@adb.com','','\0',NULL,'1231231231',NULL,76,'KhanhLe Agent','\0',NULL,NULL,NULL),(33,1,'','','pavaso01@adb.com','','\0',NULL,'','\0',77,'khanh le','\0','khanh','le',NULL),(34,1,'22222','2222222222','nguyencongson163@gmail.com','2222222222','\0',NULL,'2222222222','',130,'SOn Nguyen','','SOn','Nguyen',NULL);
/*!40000 ALTER TABLE `agent` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-09 18:39:41
