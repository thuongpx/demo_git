-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `signer_doctypes`
--

DROP TABLE IF EXISTS `signer_doctypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signer_doctypes` (
  `DocTypeID` int(11) NOT NULL AUTO_INCREMENT,
  `DocType` varchar(150) DEFAULT NULL,
  `Expires` bit(1) DEFAULT NULL,
  `States` varchar(50) DEFAULT NULL,
  `FileName` varchar(20) DEFAULT NULL,
  `ExpRef` varchar(20) DEFAULT NULL,
  `RatingCredit` int(11) DEFAULT NULL,
  `IsRequiredDoc` bit(1) DEFAULT NULL,
  PRIMARY KEY (`DocTypeID`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signer_doctypes`
--

LOCK TABLES `signer_doctypes` WRITE;
/*!40000 ALTER TABLE `signer_doctypes` DISABLE KEYS */;
INSERT INTO `signer_doctypes` VALUES (1,'Notary Commision','','US','com','notaryexp',0,NULL),(2,'Attorney Bar Card','','MA,DE,GA','attorney',NULL,0,NULL),(3,'License Title Producer','','VA,MD,DC','titleprod','ltpexp',0,NULL),(4,'Independant Escrow','','IN, VA','indesc',NULL,0,NULL),(5,'Drivers License','\0','US','dl',NULL,0,NULL),(6,'W9','\0','US','w9',NULL,0,NULL),(7,'NNA Certification','','US','certif',NULL,0,NULL),(8,'Background Check','','US','breport','glbexp',0,NULL),(9,'E & O Insurance','','US','errorsom','eoexp',0,NULL),(10,'Bond','','US','bond','bondexp',0,NULL),(11,'References','\0','US','ref',NULL,0,NULL),(12,'Fidelity Release Form','\0','US','fidre',NULL,0,NULL),(13,'Misc','\0','US','misc',NULL,0,NULL),(14,'TRID Self Certification','\0','US','trid',NULL,0,NULL),(15,'Closing Agent License','','MN','titlecom',NULL,0,NULL),(19,'ga',NULL,'US',NULL,NULL,NULL,NULL),(23,'Mew','\0','US',NULL,NULL,NULL,'\0'),(27,'3Bond','','AK,AL,AR,CA',NULL,NULL,NULL,''),(30,'6Bond6','\0','US',NULL,NULL,NULL,'\0'),(31,'7bond7','\0','AL,AR,CO,CT',NULL,NULL,NULL,'\0'),(32,'8bond8','','CA',NULL,NULL,NULL,'\0'),(36,'32423ohoho','\0','US,AR,AZ',NULL,NULL,NULL,'\0'),(37,'2aaa22','','AL',NULL,NULL,NULL,''),(38,'2aaa23','','AR,AZ,CA',NULL,NULL,NULL,''),(39,'1111122ax','\0','AK,AR',NULL,NULL,NULL,'\0'),(40,'111Doc','','AL,AR,AZ',NULL,NULL,NULL,''),(41,'21321311221','\0','AZ',NULL,NULL,NULL,'\0'),(42,'1Mewo','\0','AK,AR,AZ,CA,CT','2Ahihi',NULL,NULL,''),(43,'1Misc','\0','AL,AZ,CA','eoexp',NULL,NULL,'\0'),(44,'111huhu','','AR,AZ,CA','wqw',NULL,NULL,''),(45,'ohoho','','AR,AZ','ahihi',NULL,NULL,'\0'),(46,'111Done','\0','US','11Gaugau',NULL,NULL,''),(47,'111doc1','\0','AK','com1',NULL,NULL,'\0'),(48,'khanh1','\0','US','khanh22',NULL,NULL,'\0'),(49,'khanh2','\0','US','khnh2',NULL,NULL,'\0'),(50,'khanh3','\0','US','khanh3',NULL,NULL,'\0'),(51,'aa1','\0','AL,AR','asdsa',NULL,NULL,'\0'),(52,'233e','\0','AL','2Ahihid',NULL,NULL,'\0');
/*!40000 ALTER TABLE `signer_doctypes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-09 18:39:54
