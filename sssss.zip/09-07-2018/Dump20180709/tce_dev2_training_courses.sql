-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `training_courses`
--

DROP TABLE IF EXISTS `training_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_courses` (
  `CourseId` int(11) NOT NULL AUTO_INCREMENT,
  `TenantId` int(11) DEFAULT NULL,
  `Title` varchar(150) DEFAULT NULL,
  `Description` varchar(500) DEFAULT NULL,
  `VideoFile` varchar(150) DEFAULT NULL,
  `Document` varchar(150) DEFAULT NULL,
  `Duration` int(11) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `ViewsCount` int(11) DEFAULT NULL,
  `PosterFile` varchar(150) DEFAULT NULL,
  `Inactive` bit(1) DEFAULT NULL,
  `Downloaded` int(11) DEFAULT NULL,
  PRIMARY KEY (`CourseId`),
  UNIQUE KEY `CourseId_UNIQUE` (`CourseId`),
  KEY `tenantId_training_courses_idx` (`TenantId`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_courses`
--

LOCK TABLES `training_courses` WRITE;
/*!40000 ALTER TABLE `training_courses` DISABLE KEYS */;
INSERT INTO `training_courses` VALUES (1,NULL,'Course1','testt222','./src/content/upload/training-course-temp/TEMP-20180613091915_Clip_480_5sec_6mbps_h264.mp4','./src/content/upload/training-course-temp/TEMP-UCC7.0 _Manage Vendor_latest.docx',NULL,NULL,1,NULL,'\0',10),(2,NULL,'Course2','test1','./src/content/upload/training-course-temp/TEMP-20180613091915_Clip_480_5sec_6mbps_h264.mp4','./src/content/upload/training-course-temp/TEMP-UCC7.0 _Manage Vendor_latest.docx',NULL,NULL,2,NULL,'\0',2),(3,NULL,'Course3','333','./src/content/upload/training-course-temp/TEMP-20180613091915_Clip_480_5sec_6mbps_h264.mp4','./src/content/upload/training-course-temp/TEMP-UCC7.0 _Manage Vendor_latest.docx',NULL,NULL,3,NULL,'\0',NULL),(4,NULL,'Course4','333','./src/content/upload/training-course-temp/TEMP-20180613091915_Clip_480_5sec_6mbps_h264.mp4','./src/content/upload/training-course-temp/TEMP-UCC7.0 _Manage Vendor_latest.docx',NULL,NULL,3232,NULL,'\0',NULL),(5,NULL,'Course5',NULL,NULL,NULL,NULL,NULL,3,NULL,'\0',NULL),(6,NULL,'Course6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0',NULL),(7,NULL,'Course7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0',NULL),(8,NULL,'Course8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0',NULL),(9,NULL,'Course9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0',NULL),(10,NULL,'Course10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0',NULL),(11,NULL,'Course11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0',NULL),(12,NULL,'Course12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0',NULL),(13,NULL,'Course13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0',NULL),(14,NULL,'Course14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0',NULL),(15,NULL,'AnhNT90','AnhNT90','./src/content/upload/training-course-temp/TEMP-20180703023212_Clip_480_5sec_6mbps_h264.mp4','./src/content/upload/training-course-temp/TEMP-20180703023212_',NULL,NULL,1,NULL,'\0',NULL),(16,NULL,'khanh1','1221','khanh.mp4','UCS19.0 _Generate Invoice.docx',NULL,NULL,NULL,NULL,'\0',NULL),(17,NULL,'ANHNT','ANHNT','anhnt.mp4','UCC1.0_ Client Registration.docx',NULL,NULL,1,NULL,'\0',8),(18,NULL,'EMNT','aa','Clip_480_5sec_6mbps_h264.mp4','',NULL,NULL,NULL,NULL,'\0',NULL);
/*!40000 ALTER TABLE `training_courses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-09 18:39:52
