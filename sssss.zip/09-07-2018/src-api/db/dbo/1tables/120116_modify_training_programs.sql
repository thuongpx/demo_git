ALTER TABLE `training_programs` DROP COLUMN `Trainee`;
ALTER TABLE `training_programs` ADD COLUMN `ForVendor` BIT NULL;
ALTER TABLE `training_programs` ADD COLUMN `ForStaff` BIT NULL;