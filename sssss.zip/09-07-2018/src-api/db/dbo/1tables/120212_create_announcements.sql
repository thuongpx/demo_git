use tce_dev;

CREATE TABLE IF NOT EXISTS `announcements` (
	`AnnouncementID` INT(11) NOT NULL AUTO_INCREMENT,
    `CreatedDate` DATETIME NULL,
    `Title` VARCHAR(100) NULL,
    `Content` VARCHAR(4000) NULL,
    `Audience` VARCHAR(50) NULL,
    `Status` VARCHAR(15) NULL,
    `NumOfAppearance` TINYINT,
    PRIMARY KEY (`AnnouncementID`)
);