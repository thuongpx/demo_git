use tce_dev;

ALTER TABLE `broker_fee` 
DROP FOREIGN KEY `feedesid_broker_fee`;
ALTER TABLE `broker_fee` 
ADD INDEX `feedesid_broker_fee_idx` (`FeeDescripId` ASC),
DROP INDEX `feedesid_broker_fee_idx` ;
ALTER TABLE `broker_fee` 
ADD CONSTRAINT `feedesid_broker_fee`
  FOREIGN KEY (`FeeDescripId`)
  REFERENCES `fee_descriptions` (`FeeDescriptionId`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
  

drop table tce_dev.fee_description;
