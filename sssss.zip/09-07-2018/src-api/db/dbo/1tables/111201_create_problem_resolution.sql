-- create by AnhNT90

CREATE TABLE IF NOT EXISTS `problem_resolution` (
    `ResolutionId` INT(11) NOT NULL AUTO_INCREMENT,
    `ProblemId` INT(11),
    `Resolution` VARCHAR(2000) DEFAULT NULL,
    `CreatedDate` DATETIME NOT NULL,
	`CreatedBy` INT(11) NOT NULL,
    PRIMARY KEY (`ResolutionId`)
)