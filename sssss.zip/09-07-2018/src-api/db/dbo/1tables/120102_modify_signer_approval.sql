ALTER TABLE `signers_approval` 
CHANGE COLUMN `Approved` `Status` VARCHAR(10) NULL DEFAULT NULL ;
