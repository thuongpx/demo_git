DELIMITER $$
CREATE PROCEDURE `alter_table_signer` ()
BEGIN
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'signer' AND 
                            COLUMN_NAME = 'Qualified') THEN
	BEGIN
		ALTER TABLE `signer` CHANGE COLUMN `Qualified` `Qualified` CHAR(1) NULL DEFAULT NULL ;
	END;
	END IF;
END$$

DELIMITER ;

call alter_table_signer();

DROP PROCEDURE IF EXISTS `alter_table_signer`;