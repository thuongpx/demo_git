CREATE TABLE IF NOT EXISTS `training_course_vendor` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT,
  `CatId` INT(11) NOT NULL,
  `CourseId` INT(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `catId_training_course_vendor_idx` (`CatId`),
  KEY `courseId_training_course_vendor_idx` (`CourseId`),
  CONSTRAINT `catid_training_course_vendor` FOREIGN KEY (`CatId`) REFERENCES `vendor_categories` (`CatId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `courseId_training_course_vendor` FOREIGN KEY (`CourseId`) REFERENCES `training_courses` (`CourseId`) ON DELETE NO ACTION ON UPDATE NO ACTION
)


