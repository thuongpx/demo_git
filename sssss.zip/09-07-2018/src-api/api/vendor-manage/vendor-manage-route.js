import VendorManageController from "./vendor-manage-controller";

const routes = [
    {
        path: "/vendorManage/getOrdersVendorList",
        method: "GET",
        handler: VendorManageController.getOrdersVendorList
    },
    {
        path: "/vendorManage/checkClientSatisfiedVendor",
        method: "GET",
        handler: VendorManageController.checkClientSatisfiedVendor
    },
    {
        path: "/vendorManage/getDefaultVendorSearch",
        method: "GET",
        handler: VendorManageController.getDataInit
    }
];

export default routes;