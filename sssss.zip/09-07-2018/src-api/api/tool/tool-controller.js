import Boom from "boom";
import appConfig from "../../config/config";
import fs from "fs";
import Bookshelf from "../../db/database";
import {
    handleSingleQuote
} from "../../helper/common-helper";
import { TOOL_PAGE_DISPLAY } from "../../constant/common-constant";

class ToolController {
    constructor() { }
    getListResource(request, reply) {

        const {
            typePage,
            pageDisplay
        } = request.payload;
        console.log(`type: ${typePage}`);
        console.log(`pageDisplay: ${pageDisplay}`);

        // let listType = ``;

        // typePage.forEach((item, index) => {
        //     if (index === 0) listType = `(`;
        //     listType = `${listType}'${item.key}'`;
        //     if (index < typePage.length - 1) {
        //         listType = `${listType},`;
        //     } else {
        //         listType = `${listType})`;
        //     }
        // });

        if (pageDisplay === true) {
            // const sqlQuery = `SELECT *
            // FROM resources ${typePage.length > 0 ? `WHERE Views in ${listType}` : ""}`;
            const listType = [];

            typePage.forEach((item, index) => {
                listType[index] = item.key;
            });

            console.log(`listTypeFaq: ${JSON.stringify(listType)}`);


            // const sqlQuery = `SELECT Id, Question, Answer, Views
            //     FROM faq ${(typePage.length > 0 && pageDisplay) ? `WHERE Views in ${listType}` : ""}`;
            let sqlQuery = `SELECT * FROM resources`;

            if (listType !== null) {
                listType.forEach((item, index) => {
                    if (index === 0) {
                        sqlQuery = `${sqlQuery} WHERE (find_in_set('${listType[0]}',Views))`;
                    } else {
                        sqlQuery = `${sqlQuery} OR (find_in_set('${listType[index]}',Views))`;
                    }
                });
            }
            console.log(sqlQuery);
            Bookshelf.knex.raw(sqlQuery)
                .then((result) => {
                    if (result !== null) {
                        reply({
                            isSuccess: true,
                            isNotFound: false,
                            isStaff: true,
                            isClient: false,
                            isVendor: false,
                            listResource: result[0]
                        });
                    } else {
                        reply({
                            isSuccess: false, isNotFound: true,
                            isStaff: true,
                            isClient: false,
                            isVendor: false
                        });
                    }
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });

        } else {
            const sqlQuery = `SELECT * FROM resources;`;

            Bookshelf.knex.raw(sqlQuery)
                .then((result) => {
                    if (result !== null) {
                        reply({
                            isSuccess: true,
                            isNotFound: false,
                            isStaff: true,
                            isClient: false,
                            isVendor: false,
                            listResource: result[0]
                        });
                    } else {
                        reply({
                            isSuccess: false,
                            isStaff: true,
                            isClient: false,
                            isVendor: false,
                            isNotFound: true
                        });
                    }
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });

        }
        return;
    }

    downloadResources(request, reply) {
        const {
            fileName
        } = request.query;

        const filePath = `${appConfig.file.serverPath}/upload/resources/${fileName}`;

        if (fs.existsSync(filePath)) {
            fs.readFile(filePath, (err, data) => {
                if (err) reply(Boom.badRequest(err.message));
                return reply(data).header("content-disposition", `attachment; filename=${fileName}`);
            });
        } else {
            reply(Boom.badRequest(`File ${filePath} is not exists.`));
        }
    }


    getListLink(request, reply) {
        const {
            typePage,
            pageDisplay
        } = request.payload;
        console.log(`type: ${typePage}`);
        console.log(`pageDisplay: ${pageDisplay}`);

        let listType = ``;

        typePage.forEach((item, index) => {
            if (index === 0) listType = `(`;
            listType = `${listType}'${item.key}'`;
            if (index < typePage.length - 1) {
                listType = `${listType},`;
            } else {
                listType = `${listType})`;
            }
        });

        console.log(listType);

        if (pageDisplay === true) {
            const sqlQuery = `SELECT Id, LinkTitle, Link, Description, Type, Target
            FROM links ${typePage.length > 0 ? `WHERE Views in ${listType}` : ""}`;
            console.log(sqlQuery);
            Bookshelf.knex.raw(sqlQuery)
                .then((result) => {
                    if (result !== null) {
                        reply({
                            isSuccess: true,
                            isNotFound: false,
                            isStaff: true,
                            isClient: false,
                            isVendor: false,
                            links: result[0]
                        });
                    } else {
                        reply({
                            isSuccess: false, isNotFound: true,
                            isStaff: true,
                            isClient: false,
                            isVendor: false
                        });
                    }
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });
        } else {
            const sqlQuery = `SELECT Id, LinkTitle, Link, Description, Type, Target
            FROM links`;
            console.log("2 cc");
            Bookshelf.knex.raw(sqlQuery)
                .then((result) => {
                    if (result !== null) {
                        reply({
                            isSuccess: true,
                            isNotFound: false,
                            isStaff: false,
                            isClient: false,
                            isVendor: false,
                            links: result[0]
                        });
                    } else {
                        reply({
                            isSuccess: false, isNotFound: true,
                            isStaff: false,
                            isClient: false,
                            isVendor: false
                        });
                    }
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });
        }
        return;

    }

    addResourcesToDataBase(request, reply) {
        const {
            title, resource, description, views
        } = request.payload;


        const sqlQuery = `INSERT INTO resources (Resource, Title, Description, Views)
                VALUES ('${resource}', '${title}', '${description}','${views}');
        `;
        console.log(sqlQuery);
        Bookshelf.knex.raw(sqlQuery).then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });

            }
            reply({
                isSuccess: false,
                isNotFound: true
            });
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }


    deleteResourcesById(request, reply) {
        const {
            Id
        } = request.query;
        console.log(`Id: ${Id}`);

        const sqlQuery = `DELETE FROM resources WHERE Id = ${Id}`;
        console.log(sqlQuery);
        Bookshelf.knex.raw(sqlQuery).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });


    }
    deleteResourceFileById(request, reply) {
        const {
            Id
        } = request.query;
        console.log(`id file :${Id}`);
        fs.unlink(`${appConfig.file.serverPath}/upload/resources/${Id}`, (err) => {
            if (err) {
                reply(Boom.badRequest(err));
                return;
            }
            console.log('File deleted!');
        });
    }

    editResourcesById(request, reply) {
        const {
            resourceId, title, resource, description
        } = request.payload;


        console.log(`Id: ${resourceId}`);

        const sqlQuery = `UPDATE resources SET
        Resource = '${resource}', Title = '${title}', Description = '${description}'
            WHERE Id = ${resourceId}`;
        console.log(sqlQuery);
        Bookshelf.knex.raw(sqlQuery).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    getFaqsByQuestion(request, reply) {
        const { question } = request.query;

        const newQuestion = (question === "" || question === undefined) ? "" : handleSingleQuote(question);

        const sqlQuery = `SELECT Id, Question, Answer, Views
        FROM faq
        WHERE Question LIKE '%${newQuestion}%'`;

        Bookshelf.knex.raw(sqlQuery)
            .then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        faqs: result[0]
                    });
                    return;
                }
                reply({ isSuccess: false, isNotFound: true });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        return;
    }

    getPageDisplayFromConstant(request, reply) {
        // console.log(TOOL_PAGE_DISPLAY);
        reply({
            listPage: TOOL_PAGE_DISPLAY
        });
    }



    getListResourceByViews(request, reply) {
        const {
            typePage
        } = request.query;
        console.log(typePage);
        const sqlQuery = `SELECT * FROM resources WHERE Views = '${typePage}'`;

        Bookshelf.knex.raw(sqlQuery)
            .then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        isNotFound: false,
                        isStaff: true,
                        isClient: false,
                        isVendor: false,
                        listResource: result[0]
                    });
                } else {
                    reply({
                        isSuccess: false, isNotFound: true,
                        isStaff: true,
                        isClient: false,
                        isVendor: false
                    });
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }

    addLinksToDataBase(request, reply) {
        const {
            linkTitle, link, type, target, description, views
        } = request.payload;


        const sqlQuery = `INSERT INTO links (LinkTitle, Link, Description, Type, Target, Views)
                VALUES ('${linkTitle}', '${link}', '${description}', '${type}', '${target}', '${views}');
        `;
        console.log(sqlQuery);
        Bookshelf.knex.raw(sqlQuery).then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });

            }
            reply({
                isSuccess: false,
                isNotFound: true
            });
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }

    deleteLinksById(request, reply) {
        const {
            Id
        } = request.query;
        console.log(`Id: ${Id}`);

        const sqlQuery = `DELETE FROM links WHERE Id = ${Id}`;
        console.log(sqlQuery);
        Bookshelf.knex.raw(sqlQuery).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });

    }

    editLinksById(request, reply) {
        const {
            linkId, Title, Link, type, target, Description, views
        } = request.payload;


        console.log(`Id: ${linkId}`);

        const sqlQuery = `UPDATE links SET
            LinkTitle = '${Title}', Link = '${Link}', Description = '${Description}', Type = '${type}', Target = '${target}', Views = '${views}'
            WHERE Id = ${linkId}`;
        console.log(sqlQuery);
        Bookshelf.knex.raw(sqlQuery).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }
}

export default new ToolController();