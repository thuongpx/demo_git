import SignerDocType from "../../db/model/signer-doctype";
import State from "../../db/model/state";
import Boom from "boom";
import Bookshelf from "../../db/database";
import {
	handleSingleQuote
} from "../../helper/common-helper";

class CredentialDocumentController {
	constructor() { }
	//Check Exist Document Name
	checkExistCredentialDocument(request, reply) {
		const {
			docType
		} = request.query;
		SignerDocType.where({
			docType
		}).count("*").then((count) => {
			const isExist = count > 0;
			reply({
				isExist
			});
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
		return;
	}
	//Get All Loan Type
	getCredentialDocument(request, reply) {
		const {
			docType,
			sortColumn,
			sortDirection,
			page,
			itemPerPage
		} = request.query;
		const rawSql = `call GetAllVendorCredentialDocument(
			${docType === undefined ? null : `'${handleSingleQuote(docType)}'`},
            '\`${sortColumn}\`',
            ${sortDirection},
            ${page},
            ${itemPerPage} 
		);`;
		Bookshelf.knex.raw(rawSql)
			.then((result) => {
				if (result !== null) {
					reply({
						credentialDocuments: result[0][0],
						totalRecords: result[0][1][0].TotalRecords
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		return reply;
	}
	// Delete a Doc Type
	deleteCredentialDocument(request, reply) {
		const docTypeID = request.payload;
		SignerDocType.where(docTypeID).destroy().then((result) => {
			if (result !== null) {
				reply({
					isSuccess: true
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
		return reply;
	}
	// Add Loan Type
	addCredentialDocument(request, reply) {
		const input = request.payload;
		new SignerDocType().save({
			DocType: input.DocType,
			Expires: input.Expires,
			States: input.States,
			IsRequiredDoc: input.IsRequiredDoc,
			FileName: input.FileName
		}, {
				method: "insert"
			}).then(() => reply({ isSuccess: true })).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}
	//Update Loan Type Name
	updateCredentialDocument(request, reply) {
		const input = request.payload;
		SignerDocType.where({
			DocTypeID: input.DocTypeID
		}).save({
			DocType: input.DocType,
			Expires: input.Expires,
			States: input.States,
			IsRequiredDoc: input.IsRequiredDoc
		}, {
				method: "update"
			}).then((result) => {
				if (result !== null) {
					reply({
						isSuccess: true
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}
	//Get List State
	getStates(request, reply) {
		State.fetchAll().then((result) => {
			if (result !== null) {
				reply(result);
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return;
	}
	//Check Exist File Name
	checkExistFileName(request, reply) {
		const {
			fileName
		} = request.query;
		SignerDocType.where({
			fileName
		}).count("*").then((count) => {
			const isExist = count > 0;
			reply({
				isExist
			});
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
		return;
	}
}

export default new CredentialDocumentController();