import Boom from "boom";
import Bookshelf from "../../db/database";
import BrokerSlas from "../../db/model/client-slas";

class ClientSlasController {
    getClientSlasById(request, reply) {
        const { brokerId } = request.query;

        const rawSql = `select Id, BrokerId, SLA, DefaultFrom, DefaultTo, \`From\`, \`To\` from broker_slas where BrokerId = ${brokerId}`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        listClientSlas: result[0]
                    });
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

    updateClientSlasById(request, reply) {
        const { listClientSlasNew } = request.payload;
        if (listClientSlasNew.length > 0) {
            listClientSlasNew.forEach(item => {
                if (item.Id > 0) {
                    BrokerSlas.where({ Id: item.Id }).save(item, { method: "update" }).then(() => {
                        reply({ isSuccess: true });
                    }).catch(error => Boom.badRequest(error));
                }
            });
        }
    }
}
export default new ClientSlasController();