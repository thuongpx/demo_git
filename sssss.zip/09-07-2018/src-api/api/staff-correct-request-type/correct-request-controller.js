import Boom from "boom";
import Bookshelf from "../../db/database";
import {
    handleSingleQuote,
    bufferToBoolean
} from "../../helper/common-helper";
import ProblemTypes from "../../db/model/problem-types";

class CorrectRequestController {
    constructor() {}

    getCorrectionRequestType(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            correctionType
        } = request.query;
        const newCorrectionType = (correctionType === "" || correctionType === undefined) ? "" : handleSingleQuote(correctionType);

        Bookshelf.knex.raw(`call GetCorrectionRequest(
            ${(sortColumn === undefined || sortColumn === "") ? null : `'${sortColumn}'`},
            ${(sortDirection === undefined || sortDirection === "") ? null : `${sortDirection}`},
            ${(page === undefined || page === "") ? null : `${page}`},
            ${(itemPerPage === undefined || itemPerPage === "") ? null : `${itemPerPage}`},
            '${newCorrectionType}'
        );`).then(value => {
            const data = {};

            if (value !== null) {
                const rawData = [];
                value[0][0].map(item => {
                    if (bufferToBoolean(item.IsImportant)) {
                        item.IsImportant = "Yes";
                    } else {
                        item.IsImportant = "No";
                    }
                    rawData.push(item);
                });
                data.data = rawData;
                data.totalRecords = value[0][1][0].TotalRecords;
            }
            reply(data);
            return reply;
        }).catch(err => {
            reply(Boom.badRequest(err));
            return reply;
        });
    }

    deleteCorrectionRequestType(request, reply) {
        const {
            Id
        } = request.payload;

        const rawSql = `DELETE FROM problem_types WHERE Id=${Id};`;

        Bookshelf.knex.raw(rawSql).then(() => {
            reply({
                isSuccess: true
            });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    getCorretionRequestById(request, reply) {
        const {
            Id
        } = request.query;

        const rawSql = `Select * FROM problem_types WHERE Id=${Id};`;

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                const response = [];
                result[0].map(item => {
                    if (bufferToBoolean(item.IsImportant)) {
                        item.IsImportant = true;
                    } else {
                        item.IsImportant = false;
                    }
                    response.push(item);
                });
                reply(response);
            }
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    checkExistCorrectionRequest(request, reply) {
        const {
            Description
        } = request.payload;
        let {
            Id
        } = request.payload;
        if (!Id) {
            Id = 0;
        }
        ProblemTypes.query((qb) => {
            qb.where("Description", "=", `${Description}`).andWhere("Id", "<>", Id);
        }).count("*").then((result) => {
            reply({
                isExist: result > 0
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    addCorrectionRequest(request, reply) {
        const {
            Description,
            IsImportant
        } = request.payload;
        new ProblemTypes({
            Description,
            IsImportant
        }).save(null, {
            method: "insert"
        }).then(() => {
            reply({
                isSuccess: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    updateCorrectionRequest(request, reply) {
        const {
            Description,
            Id,
            IsImportant
        } = request.payload;
        ProblemTypes.where({
            Id
        }).save({
            Description,
            IsImportant
        }, {
            method: "update"
        }).then(() => {
            reply({
                isSuccess: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}

export default new CorrectRequestController();