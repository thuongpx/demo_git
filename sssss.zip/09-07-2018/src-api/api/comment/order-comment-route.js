import OrderCommentController from "../comment/order-comment-controller";

const routes = [{
    path: "/comment/getComments",
    method: "GET",
    handler: OrderCommentController.getComments
},
{
    path: "/comment/deleteComment",
    method: "POST",
    handler: OrderCommentController.deleteComment
},
{
    path: "/comment/addComment",
    method: "POST",
    handler: OrderCommentController.addComment
},
{
    path: "/comment/getCommentByType",
    method: "GET",
    handler: OrderCommentController.getCommentByType
},
{
    path: "/comment/addMultiComment",
    method: "POST",
    handler: OrderCommentController.addMultiComment
},
{
    path: "/comment/getOrderCommentWithUserData",
    method: "GET",
    handler: OrderCommentController.getOrderCommentWithUserData
}];


export default routes;