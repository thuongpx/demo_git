import { AUTH } from "../../constant/common-constant";
import Jwt from "../../lib/jwt";
import Boom from "boom";
import Bookshelf from "../../db/database";

import { hasValue, hasStringValue } from "../../helper/common-helper";
import { guid } from "../../helper/crypto-helper";

import User from "../../db/model/users";

import { authorizePassword } from "./auth";

class AuthController {
	constructor() { }

	createAnAccount(request, reply) {
		const {
			username,
			password,
			mappingUserId,
			tenantId
		} = request.payload;

		if (username === undefined || username === null || password === undefined || password === null) {
			reply(Boom.badRequest("Missing credentials"));
			return;
		}

		// hash password
		const salt = Jwt.generateSalt();
		const hashedPassword = Jwt.hash(password, salt);

		new User().save({
			Username: username,
			Password: hashedPassword,
			MappingUserId: mappingUserId,
			TenantId: tenantId,
			HashSalt: salt
		}, { method: "insert" })
			.then((rs) => {
				if (rs === null) {
					reply(Boom.badRequest("Can not save account"));
					return;
				}

				const { UserID, TenantID } = rs.attributes;

				reply({
					UserID,
					TenantID
				});
			});
	}

	register(request, reply) {
		const {
			user
		} = request.payload;

		// validate user
		const newUser = new User(user);

		if (newUser.isNew()) {
			// create user
			new User(user)
				.save()
				.then((result) => {
					if (result === null) {
						reply(Boom.badRequest(AUTH.REGISTERED_FAILED));
						return;
					}

					const { UserID, TenantID } = result.attributes;

					reply({
						UserID,
						TenantID
					});
				}, () => {
					reply(Boom.badRequest(AUTH.REGISTERED_FAILED));
					return;
				});
		}
	}

	checkUserNeedToResetPassword(request, reply) {
		const { userId } = request.query;

		User.where({ UsersId: userId, NeedToResetPassword: true }).count("*").then((count) => {
			if (count > 0) {
				reply({ needResetPassword: true, userId });
			} else {
				reply({ needResetPassword: false });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	async authorize(request, reply) {
		const {
			supervisor,
			userId,
			username,
			password,
			GUID,
			tempToken
		} = request.payload;

		let result;

		try {
			result = await authorizePassword({
				userId,
				username,
				password,
				GUID,
				tempToken,
				supervisor: supervisor || {}
			});
		} catch (err) {
			return reply(Boom.badRequest(err));
		}

		return reply(result);
	}

	getProfilePicture(request, reply) {
		const { accountId } = request.query;
		const rawSql = `SELECT GetProfilePictureByUserId(${accountId}) AS profilePicture;`;

		Bookshelf.knex.raw(rawSql).then(result => {
			if (result !== null) {
				reply({
					profilePicture: hasValue(result[0][0].profilePicture) ? result[0][0].profilePicture.toString() : ""
				});
			}
		}).catch((err) => {
			reply(Boom.badRequest(err));
			return;
		});
	}

	async loginAsAnotherUser(request, reply) {
		const {
			currentUserId,
			targetUserId
		} = request.payload;

		// validate staff
		const currentUser = await User
			.where({ UsersId: currentUserId })
			.fetch({
				columns: [
					"UsersId", "Password", "HashSalt",
					"MappingUserId", "TenantId", "Inactive",
					"UserName", "NeedToResetPassword", "LastUpdate",
					"Logged", "TemporaryToken"
				]
			}).catch(err => reply(Boom.badRequest(err)));

		const targetUser = await User
			.where({ UsersId: targetUserId })
			.fetch({
				columns: [
					"UsersId", "Password", "HashSalt",
					"MappingUserId", "TenantId", "Inactive",
					"UserName", "NeedToResetPassword", "LastUpdate",
					"Logged", "TemporaryToken"
				]
			}).catch(err => reply(Boom.badRequest(err)));

		if (!currentUser || !targetUser) {
			return reply(Boom.badRequest(`User is not found.`));
		}

		// generate temporary token
		const temporaryToken = guid();

		// save to database to use later
		return await User.where({ UsersId: targetUserId }).save({ TemporaryToken: temporaryToken }, { method: "update" })
			.then(() => {
				reply({
					targetUserId,
					targetUsername: targetUser.get("UserName"),
					currentUserId,
					currentUsername: currentUser.get("UserName"),
					temporaryToken
				});
			})
			.catch(err => reply(Boom.badRequest(err)));
	}
}

export default new AuthController();