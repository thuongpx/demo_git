import Boom from "boom";
import NotaryState from "./../../db/model/notary_state";

class NotaryStateController {
    constructor() { }
    getDualStatesBySignerId(request, reply) {
        const { signerId } = request.query;
        NotaryState.where({ signerId }).fetchAll({ columns: ["state"] }).then((states) => {
            reply(states);
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}
export default new NotaryStateController();