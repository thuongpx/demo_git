import ClientServicesConfigLogController from "./client-services-config-log-controller";
const routes = [{
    path: "/client-services-config-log/getConfigLogByConfigId",
    method: "GET",
    handler: ClientServicesConfigLogController.getConfigLogByConfigId
}];

export default routes;