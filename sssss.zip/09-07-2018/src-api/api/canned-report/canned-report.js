import Bookshelf from "../../db/database";
import { hasStringValue } from "../../helper/common-helper";

export const getOrderTypes = async () => {
    const rawSql = `SELECT LoanType FROM loan_type`;

    const rs = await Bookshelf.knex.raw(rawSql);

    if (rs) {
        return rs[0];
    }

    return [];
};

const _buildSqlWhereClause = (criterias) => {
    const {
        orderStatus,
        orderType
    } = criterias;

    let whereStr = "";
    let tSql = "";
    let isShowAll = true;

    // order type
    if (orderType && orderType.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < orderType.length; i++) {
            tSql += ` OR OrderType LIKE '${orderType[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // order status
    if (orderStatus && orderStatus.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < orderStatus.length; i++) {
            tSql += ` OR OrderStatus LIKE '${orderStatus[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    return {
        whereStr,
        isShowAll
    };
};


export const buildSqlCountQuery = (viewName, criterias) => {
    let sqlStr = `SELECT Count(*) AS Num FROM ${viewName} WHERE 1 = 1`;
    let isShowAll = true;

    const whereObj = _buildSqlWhereClause(criterias);

    isShowAll = whereObj.isShowAll;
    sqlStr += whereObj.whereStr;

    return {
        sqlStr,
        isShowAll
    };
};

export const buildSqlQuery = (viewName, criterias) => {
    const {
        offset,
        limit
    } = criterias;

    let sqlStr = `SELECT * FROM ${viewName} WHERE 1 = 1`;
    let isShowAll = true;

    const whereObj = _buildSqlWhereClause(criterias);

    isShowAll = whereObj.isShowAll;
    sqlStr += whereObj.whereStr;

    // offset and limit
    if (hasStringValue(offset) && hasStringValue(limit)) {
        sqlStr += ` LIMIT ${limit} OFFSET ${offset}`;
    }

    return {
        sqlStr,
        isShowAll
    };
};