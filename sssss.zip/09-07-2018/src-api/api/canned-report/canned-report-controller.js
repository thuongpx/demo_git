import Bookshelf from "../../db/database";
import Boom from "boom";

import { distinctSingleValueArray } from "../../helper/common-helper";
import { getOrderTypes, buildSqlQuery, buildSqlCountQuery } from "./canned-report";

class CannedReportController {
	constructor() { }

	async getInitDataForCannedReport(request, reply) {
		// get order types list
		const orderTypes = await getOrderTypes();

		reply({
			orderTypes: distinctSingleValueArray(orderTypes.map(i => i.LoanType))
		});
	}

	fetchOrderByStatusChartData(request, reply) {
		const sqlResult = buildSqlQuery("open_order_chart_v", request.payload);
		const { sqlStr, isShowAll } = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				const rawData = rs[0];
				const labels = distinctSingleValueArray(rawData.map(i => i.OrderStatus)); // build labels
				const orderTypes = distinctSingleValueArray(rawData.map(i => i.OrderType)); // build datasets

				const datasets = [];

				if (isShowAll) {
					const tData = {
						label: "All Data",
						data: []
					};

					for (let i = 0; i < labels.length; i++) {
						const f = rawData.filter(rd => rd.OrderStatus === labels[i]);
						const r = f.reduce((a, c) => {
							return {
								Count: a.Count + c.Count
							};
						});

						tData.data.push(r.Count);
					}

					datasets.push(tData);
				} else {
					for (let o = 0; o < orderTypes.length; o++) {
						const tData = {
							label: orderTypes[o],
							data: []
						};

						for (let i = 0; i < labels.length; i++) {
							const f = rawData.find(r => {
								return r.OrderType === orderTypes[o] && r.OrderStatus === labels[i];
							});

							tData.data.push(f ? f.Count : 0);
						}

						datasets.push(tData);
					}
				}

				return reply({
					labels,
					datasets
				});
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	fetchOrderByStatusGridData(request, reply) {
		const sqlResult = buildSqlQuery("open_order_drilldown_v", request.payload);
		const { sqlStr } = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs) {
					reply(Boom.badRequest("Empty response"));
					return;
				}

				const data = rs[0];

				reply({
					data
				});
				return;
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	countOrderByStatusGridData(request, reply) {
		const sqlResult = buildSqlCountQuery("open_order_drilldown_v", request.payload);
		const { sqlStr } = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs || rs.length === 0) {
					reply(0);
					return;
				}

				const data = rs[0][0];

				reply(data.Num);
				return;
			})
			.catch(err => reply(Boom.badRequest(err)));
	}
}

export default new CannedReportController();