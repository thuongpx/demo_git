import SignerDocTypeController from "./signer-doctype-controller";

const routes = [{
    path: "/signerDocType/getDocTypeBySignerId",
    method: "GET",
    handler: SignerDocTypeController.getDocTypeBySignerId
}];

export default routes;