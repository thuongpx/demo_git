import RatingController from "./rating-controller";

const routes = [{
    path: "/rating/getRatings",
    method: "GET",
    handler: RatingController.getRatings
}];

export default routes;