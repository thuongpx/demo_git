import NotaryLoopController from "./notary-loop-controller";

const routes = [{
    path: "/notaryloop/addNotaryLoop",
    method: "POST",
    handler: NotaryLoopController.addNotaryLoop
}];

export default routes;