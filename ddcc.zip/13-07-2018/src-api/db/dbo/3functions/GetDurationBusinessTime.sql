DROP FUNCTION IF EXISTS `GetDurationBusinessTime`;

DELIMITER $$

CREATE FUNCTION `GetDurationBusinessTime`(finishAt datetime, startAt datetime) RETURNS bigint(20)
BEGIN
	RETURN (TIMESTAMPDIFF(MINUTE,startAt,finishAt));
    -- get business_hours
    -- find hold day between finishAt and startAt to have total business time
    -- add startAt to CloseTime (if +)
    -- add OpenTime to finishAt (if +)
END$$

DELIMITER ;