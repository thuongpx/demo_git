DROP FUNCTION IF EXISTS `GetProgramForOrderAsmtTrainingLog`;

DELIMITER $$

CREATE FUNCTION `GetProgramForOrderAsmtTrainingLog`(listId VARCHAR(1000)) RETURNS VARCHAR(5000)
BEGIN
    DECLARE returnData VARCHAR(5000);
    
    -- sum of additional fee
    select group_concat(tp.Title) into returnData from training_programs tp where FIND_IN_SET(tp.ProgramId, listId) > 0;
    
    
    RETURN returnData;
END$$

DELIMITER ;