DROP FUNCTION IF EXISTS `CalculateBusinessHourByOffTime`;

DELIMITER $$

CREATE FUNCTION `CalculateBusinessHourByOffTime`(
startTime TIME, 
endTime TIME, 
workStartTime TIME, 
workEndTime TIME, 
offStartTime TIME,
offEndTime TIME
) RETURNS INT
BEGIN
    DECLARE totalMinutes INT DEFAULT 0;
    
    IF(offStartTime < workStartTime)
		THEN SET offStartTime = workStartTime;
	END IF;
    
	IF(offStartTime > workEndTime)
		THEN SET offStartTime = workEndTime;
	END IF;
    
	IF(offEndTime > workEndTime)
		THEN SET offEndTime = workEndTime;
	END IF;
    
	IF(offEndTime < workStartTime)
		THEN SET offEndTime = workStartTime;
	END IF;
        
	IF(startTime < workStartTime)
		THEN SET startTime = workStartTime;
	END IF;
    
	IF(startTime > workEndTime)
		THEN SET offStartTime = workEndTime;
	END IF;
    
	IF(endTime > workEndTime)
		THEN SET endTime = workEndTime;
	END IF;
    
	IF(endTime < workStartTime)
		THEN SET offEndTime = workStartTime;
	END IF;
        
	IF(startTime >= offStartTime AND startTime <= offEndTime AND  endTime >= offEndTime)
		THEN SET totalMinutes = FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, offEndTime))/60);
    
	ELSEIF(endTime >= offStartTime AND endTime <= offEndTime AND startTime <= offStartTime)
		THEN SET totalMinutes =  FLOOR(TIME_TO_SEC(TIMEDIFF(offStartTime, startTime))/60);
    
	ELSEIF(startTime <= offStartTime AND endTime >= offEndTime)
		THEN SET totalMinutes =  FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, startTime))/60) - 
										FLOOR(TIME_TO_SEC(TIMEDIFF(offEndTime, offStartTime))/60);
                                        
	ELSE SET totalMinutes =  FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, startTime))/60);
	END IF;
    
    IF(totalMinutes < 0)
		THEN SET totalMinutes = 0;
	END IF;
    
	RETURN totalMinutes;
END