DROP FUNCTION IF EXISTS `GetTotalAdditionalVendorFee`;

DELIMITER $$

CREATE FUNCTION `GetTotalAdditionalVendorFee`(order_ID INT, fee_id INT) RETURNS DECIMAL
BEGIN
    DECLARE AdditionalFee DECIMAL(19, 4);
    
    -- sum of additional fee
    SELECT SUM(SignerFee)
    INTO AdditionalFee
    FROM `order_fee` AS of
    WHERE of.OrderID = order_ID AND of.FeeDescripID <> fee_id;
    
    IF AdditionalFee IS NULL THEN
		SET AdditionalFee = 0;
	END IF;
    
    RETURN AdditionalFee;
END$$

DELIMITER ;