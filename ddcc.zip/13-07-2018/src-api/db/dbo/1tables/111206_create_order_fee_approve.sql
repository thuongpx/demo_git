-- Request from AnNV2
-- Add loan type
CREATE TABLE IF NOT EXISTS `order_fee_approve` (
    `FeeApprovalId` INT(11) NOT NULL AUTO_INCREMENT,
    `OrderId` INT(11) NOT NULL,
	`FeeDescripId` INT(11) NULL,
	`UsersId` INT(11) NULL,
    `ReasonCode` INT(11) NULL,
	`FeeReason` VARCHAR(250) NULL,
	`FeeAmount` DECIMAL(19, 4) NULL,
	`FeeApproved` VARCHAR(15) NULL,
	`FeeMgr` VARCHAR(25) NULL,
	`DateStamp` DATETIME NULL,
	`DenialReason` VARCHAR(500) NULL,
	`FeeApprovalDate` DATETIME NULL,
    PRIMARY KEY (`FeeApprovalId`),
    CONSTRAINT `ordersId_order_fee_approve` FOREIGN KEY (`OrderId`) REFERENCES `order` (`OrderId`) ON DELETE NO ACTION ON UPDATE NO ACTION
);