CREATE TABLE IF NOT EXISTS `customer_subproduct_type` (
	`Id` INT(11) NOT NULL AUTO_INCREMENT,
    `CustomerId` INT(11) NOT NULL,
    `SubProductType` INT(11) NOT NULL,
    PRIMARY KEY (`Id`),
    KEY `customerid_customer_idx` (`CustomerId`),
    CONSTRAINT `customerid_customer_subproduct_type` FOREIGN KEY (`CustomerId`) 
		REFERENCES `customers` (`CustomerId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
        
    KEY `subproducttype_customer_subproduct_type_idx` (`SubProductType`),
    CONSTRAINT `subproducttype_customer_subproduct_type` FOREIGN KEY (`SubProductType`) 
		REFERENCES `loan_type_sub` (`SubTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
);