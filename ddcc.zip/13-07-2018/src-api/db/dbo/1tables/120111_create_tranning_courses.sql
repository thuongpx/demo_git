DROP TABLE `tranning_video`;

CREATE TABLE IF NOT EXISTS `training_courses` (
  `CourseId` int(11) NOT NULL AUTO_INCREMENT,
  `TenantId` int(11) DEFAULT NULL,
  `Title` varchar(150) DEFAULT NULL,
  `Description` varchar(500) NULL,
  `VideoFile` varchar(150) NULL,
  `Document` varchar(150) NULL,
  `Duration` int(11) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `ViewsCount` int(11) DEFAULT NULL,
  `PosterFile` varchar(150) DEFAULT NULL,
  `IsActive` bit(1) DEFAULT NULL,
  PRIMARY KEY (`CourseId`),
  UNIQUE KEY `CourseId_UNIQUE` (`CourseId`),
  KEY `tenantId_training_courses_idx` (`TenantId`),
  CONSTRAINT `tenantId_training_courses` FOREIGN KEY (`TenantId`) REFERENCES `tenant` (`TenantId`) ON DELETE NO ACTION ON UPDATE NO ACTION
)
