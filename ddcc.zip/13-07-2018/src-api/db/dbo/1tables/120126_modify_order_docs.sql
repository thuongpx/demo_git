use tce_test;

DELIMITER $$
CREATE PROCEDURE `alter_table_order_docs` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order_docs' AND 
                            COLUMN_NAME = 'FileSize') THEN
		ALTER TABLE `order_docs` ADD COLUMN `FileSize` INT;
	END IF;
END$$

DELIMITER ;

call alter_table_order_docs();

DROP PROCEDURE IF EXISTS `alter_table_order_docs`;