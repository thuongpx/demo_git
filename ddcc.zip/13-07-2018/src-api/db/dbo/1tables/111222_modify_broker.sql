ALTER TABLE `broker` ADD COLUMN `AdditionalContactEmail` VARCHAR(70) NULL;
ALTER TABLE `broker` ADD COLUMN `AdditionalContactPhone` VARCHAR(20) NULL;
ALTER TABLE `broker` ADD COLUMN `AdditionalContactExt` VARCHAR(50) NULL;
ALTER TABLE `broker` ADD COLUMN `InvoiceOnly` VARCHAR(25) NULL;
