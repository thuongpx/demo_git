
CREATE TABLE IF NOT EXISTS `announcements_loan_type` (
	`AnnouncementID` INT,
    `LoanTypeId` INT
);