DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	-- rename table
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'bussiness_hours') THEN
	BEGIN
		RENAME TABLE `bussiness_hours` TO `business_hours`;
	END;
    END IF;
    
END$$

DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;