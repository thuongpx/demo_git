use tce_dev;
-- Request from AnNV2
-- Add loan type
-- Modify table users
ALTER TABLE users DROP COLUMN `Type`;
ALTER TABLE users ADD COLUMN `RoleId` INT(11) NOT NULL