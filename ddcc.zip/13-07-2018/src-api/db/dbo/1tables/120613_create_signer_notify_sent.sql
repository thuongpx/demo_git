CREATE TABLE IF NOT EXISTS `signer_notify_sent` (
  `NotifySentID` INT NOT NULL AUTO_INCREMENT,
  `SignerID` INT NULL,
  `NotifID` INT NULL,
  `NotifDate` DATETIME NULL,
  PRIMARY KEY (`NotifySentID`)
  );