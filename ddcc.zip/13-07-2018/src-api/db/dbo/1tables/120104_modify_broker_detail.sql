ALTER TABLE `broker_detail` ADD COLUMN `OvernightDelivery` BIT NULL;
ALTER TABLE `broker_detail` ADD COLUMN `SecureEmailDelivery` BIT NULL;
ALTER TABLE `broker_detail` ADD COLUMN `UploadDocDelivery` BIT NULL;
ALTER TABLE `broker_detail` ADD COLUMN `DocLocationDelivery` BIT NULL;