ALTER TABLE `order` 
DROP FOREIGN KEY `TeanantId`;
ALTER TABLE `order` 
CHANGE COLUMN `TenantId` `TenantId` INT(11) NULL ;
ALTER TABLE `order` 
ADD CONSTRAINT `TeanantId`
  FOREIGN KEY (`TenantId`)
  REFERENCES `tenant` (`TenantId`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
  
  
ALTER TABLE `order` 
CHANGE COLUMN `IsSelfService` `Service` INT(4) NULL DEFAULT NULL ;

