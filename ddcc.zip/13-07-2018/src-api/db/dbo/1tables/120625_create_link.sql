CREATE TABLE IF NOT EXISTS `links` (
    `Id` INT NOT NULL AUTO_INCREMENT,
	`LinkTitle` VARCHAR(50),
	`Link` VARCHAR(200),
	`Description` VARCHAR(1000),
	`Type` VARCHAR(1),
	`Target` VARCHAR(10),
    `Views` VARCHAR(100),
	PRIMARY KEY (`Id`)
);
