DROP PROCEDURE IF EXISTS `alter_table_order_progress_log`;

DELIMITER $$
CREATE PROCEDURE `alter_table_order_progress_log` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_progress_log' AND 
                            COLUMN_NAME = 'IsRead') THEN
	BEGIN
		ALTER TABLE `order_progress_log` 
		ADD COLUMN `IsRead` BIT NULL;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_order_progress_log();

DROP PROCEDURE IF EXISTS `alter_table_order_progress_log`;

