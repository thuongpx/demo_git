DROP PROCEDURE IF EXISTS `alter_table_agent`;

DELIMITER $$
CREATE PROCEDURE `alter_table_agent` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'agent' AND 
                            COLUMN_NAME = 'FirstName') THEN
	BEGIN
		ALTER TABLE `agent` 
		ADD COLUMN `FirstName` VARCHAR(50) NULL;
	END;
    END IF;
    
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'agent' AND 
                            COLUMN_NAME = 'LastName') THEN
	BEGIN
		ALTER TABLE `agent` 
		ADD COLUMN `LastName` VARCHAR(50) NULL;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_agent();

DROP PROCEDURE IF EXISTS `alter_table_agent`;

