DROP PROCEDURE IF EXISTS `alter_table_users`;

DELIMITER $$
CREATE PROCEDURE `alter_table_users` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'users' AND 
                            COLUMN_NAME = 'SecurityCode') THEN
	BEGIN
		ALTER TABLE `users` 
		ADD COLUMN `SecurityCode` VARCHAR(6) NULL;
	END;
    END IF;
    
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'users' AND 
                            COLUMN_NAME = 'SecurityCreatedDate') THEN
	BEGIN
		ALTER TABLE `users` 
		ADD COLUMN `SecurityCreatedDate`DATETIME NULL;
	END;
    END IF;

END$$

DELIMITER ;

call alter_table_users();

DROP PROCEDURE IF EXISTS `alter_table_users`;

