DROP PROCEDURE IF EXISTS `alter_table_Industry`;

DELIMITER $$
CREATE PROCEDURE `alter_table_Industry` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'industry' AND 
                            COLUMN_NAME = 'ParentId') THEN
	BEGIN
		ALTER TABLE `industry` 
		ADD COLUMN `ParentId` INT NULL;
        
        INSERT INTO industry(`IndustryId`, `Description`) VALUES (10, 'Real Estate');
        -- child industry
        UPDATE `industry` SET ParentId = 10 WHERE `IndustryId` IN (1, 2, 3);
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_Industry();

DROP PROCEDURE IF EXISTS `alter_table_Industry`;

