import Bookshelf from "../../db/database";
import Boom from "boom";

import {
	distinctSingleValueArray
} from "../../helper/common-helper";
import {
	getOrderTypes,
	buildSqlQuery,
	buildSqlCountQuery
} from "./canned-report";
import {
	isNullOrUndefined
} from "util";

class CannedReportController {
	constructor() { }

	async getInitDataForCannedReport(request, reply) {
		// get order types list
		const orderTypes = await getOrderTypes();

		reply({
			orderTypes: distinctSingleValueArray(orderTypes.map(i => i.LoanType))
		});
	}

	fetchOrderByStatusChartData(request, reply) {
		const sqlResult = buildSqlQuery("open_order_chart_v", request.payload);
		const {
			sqlStr,
			isShowAll
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				const rawData = rs[0];
				const labels = distinctSingleValueArray(rawData.map(i => i.OrderStatus)); // build labels
				const orderTypes = distinctSingleValueArray(rawData.map(i => i.OrderType)); // build datasets

				const datasets = [];

				if (isShowAll) {
					const tData = {
						label: "All Data",
						data: []
					};

					for (let i = 0; i < labels.length; i++) {
						const f = rawData.filter(rd => rd.OrderStatus === labels[i]);
						const r = f.reduce((a, c) => {
							return {
								Count: a.Count + c.Count
							};
						});

						tData.data.push(r.Count);
					}

					datasets.push(tData);
				} else {
					for (let o = 0; o < orderTypes.length; o++) {
						const tData = {
							label: orderTypes[o],
							data: []
						};

						for (let i = 0; i < labels.length; i++) {
							const f = rawData.find(r => {
								return r.OrderType === orderTypes[o] && r.OrderStatus === labels[i];
							});

							tData.data.push(f ? f.Count : 0);
						}

						datasets.push(tData);
					}
				}
				return reply({
					labels,
					datasets
				});
			})
			.catch(err => reply(Boom.badRequest(err)));
	}
	// vuongdh
	fetchOrderComparisonByBussinessChartData(request, reply) {
		const {
			searchObject
		} = request.payload;
		const {
			month
		} = searchObject;

		const sqlResult = buildSqlQuery("open_order_comparison_by_business_day_chart_v", request.payload);
		const {
			sqlStr
		} = sqlResult;
		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				const rawData = rs[0];
				const sortedMonth = month.sort((a, b) => {
					return parseInt(a.value) - parseInt(b.value);
				});
				const labels = distinctSingleValueArray(sortedMonth.map(item => item.label));
				const labelValue = distinctSingleValueArray(sortedMonth.map(item => item.value));
				const datasets = [];
				const tData = {
					label: "All Data",
					data: []
				};
				for (let i = 0; i < labelValue.length; i++) {
					const f = rawData.filter(rd => (rd.OrderMonth === parseInt(labelValue[i])));

					tData.data.push(f.length);
				}
				datasets.push(tData);
				return reply({
					labels,
					datasets
				});
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	//end
	fetchOrderByStatusGridData(request, reply) {
		const sqlResult = buildSqlQuery("open_order_drilldown_v", request.payload);
		const {
			sqlStr
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs) {
					reply(Boom.badRequest("Empty response"));
					return;
				}

				const data = rs[0];

				reply({
					data
				});
				return;
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	countOrderByStatusGridData(request, reply) {
		const sqlResult = buildSqlCountQuery("open_order_drilldown_v", request.payload);
		const {
			sqlStr
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs || rs.length === 0) {
					reply(0);
					return;
				}

				const data = rs[0][0];

				reply(data.Num);
				return;
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	fetchOpenOrderTrendbyCustomers(request, reply) {
		const sqlResult = buildSqlQuery("open_order_trend_chart_v", request.payload);
		const { sqlStr, isShowAll } = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				const rawData = rs[0];
				const month = distinctSingleValueArray(rawData.map(i => i.OrderMonth)); // build month
				const labels = distinctSingleValueArray(rawData.map(i => i.customerName)); // build labels
				const datasets = [];

				if (isShowAll) {
					for (let a = 0; a < month.length; a++) {
						const tData = {
							label: month[a],
							data: []
						};
						for (let j = 0; j < labels.length; j++) {
							const f = rawData.filter(r => (r.customerName === labels[j] && r.OrderMonth === month[a]));
							tData.data.push(f ? f.length : 0);
						}
						datasets.push(tData);
					}
				}
				return reply({
					labels,
					datasets
				});
			}).catch(error => reply(Boom.badRequest(error)));
	}

	fetchAssignedOrderByAgentChartData(request, reply) {
		const searchObject = request.payload;

		const sqlResult = buildSqlQuery("assigned_order_by_agent_chart_v", searchObject);
		const {
			sqlStr
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(result => {
				const rawData = result[0];
				const labelValue = distinctSingleValueArray(rawData.map(item => item.RepAssignMonth));
				const labels = distinctSingleValueArray(rawData.map(item => item.FullName));
				const datasets = [];
				// const tData = {
				// 	label: "",
				// 	data: []
				// };
				for (let m = 0; m < labelValue.length; m++) {
					const tData = {
						label: labelValue[m],
						data: []
					};
					for (let i = 0; i < labels.length; i++) {
						// const f = rawData.filter(rd => (rd.RepAssignMonth === parseInt(labelValue[m])));
						const f = rawData.filter(r => (r.RepAssignMonth === labelValue[m] && r.FullName === labels[i]));
						// const f = rawData.find(r => {
						// 	return r.RepAssignMonth === labelValue[m] && r.FullName === labels[i];
						// });
						tData.data.push(f ? f.length : 0);
					}
					datasets.push(tData);
				}
				return reply({
					labels,
					datasets
				});

			}).catch(error => reply(Boom.badRequest(error)));
	}

	fetchClosedOrdersByCustomersChartData(request, reply) {
		const searchObject = request.payload;
		const sqlResult = buildSqlQuery("closed_order_by_customer_chart_v", request.payload);
		const { sqlStr, isShowAll } = sqlResult;
		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				const rawData = rs[0];
				const monthOrder = searchObject.month;

				const month = [3, 5, 4, 7];
				const labels = distinctSingleValueArray(rawData.map(i => i.Name));
				const datasets = [];

				if (isShowAll) {
					for (let i = 0; i < month.length; i++) {
						const tData = {
							label: month[i],
							data: []
						};
						for (let j = 0; j < labels.length; j++) {
							const f = rawData.filter(r => (r.Name === labels[j] && r.Month === month[i]));

							tData.data.push(f ? f.length : 0);
						}
						datasets.push(tData);
					}
				}
				return reply({
					labels,
					datasets
				});

			}).catch(error => reply(Boom.badRequest(error)));
	}

	fetchClosingCompletedOrderByClientCharData(request, reply) {
		const sqlResult = buildSqlQuery("client_milestones_chart_v", request.payload);
		const {
			sqlStr
		} = sqlResult;
		const tData = {
			label: "All Data",
			data: []
		};

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				const rawData = rs[0];
				const labels = [1, 25, 50, 100, 250, 500];
				const datasets = [];

				for (let i = 0; i < labels.length; i++) {
					const start = labels[i];
					const end = (i === labels.length - 1) ? -1 : (labels[i + 1] - 1);
					const f = rawData.filter(r => r.TotalClosedOrders >= start && (end === -1 || r.TotalClosedOrders < end));
					tData.data.push(f.length);
				}

				datasets.push(tData);
				return reply({
					labels,
					datasets
				});

			}).catch(error => reply(Boom.badRequest(error)));
	}
}
export default new CannedReportController();