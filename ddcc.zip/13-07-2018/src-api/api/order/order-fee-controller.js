import Boom from "boom";
import Bookshelf from "../../db/database";
import OrderFee from "../../db/model/order-fee";
import OrderFeeApprove from "../../db/model/order-fee-approve";
import moment from "moment";

import { hasStringValue } from "../../helper/common-helper";

class OrderFeeController {
    constructor() { }

    // Delete a fee of order
    deleteOrderFee(request, reply) {
        const feeId = request.payload;

        OrderFee.where(feeId).destroy().then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error.message));
            return;
        });
    }

    addOrderFee(request, reply) {
        const fee = request.payload;
        const newFee = new OrderFee();
        // add a fee to db
        newFee.save({
            OrderID: fee.OrderID,
            FeeDescripID: fee.FeeDescripID,
            BrokerFee: fee.BrokerFee,
            SignerFee: fee.SignerFee,
            Date: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        }, { method: "insert" }).then(() => {
            reply(1);
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    // get fees of an order
    getOrderFee(request, reply) {
        const { orderId } = request.query;
        Bookshelf.knex.raw(`call GetOrderFees('${orderId}')`)
            .then((result) => {
                if (result !== null) {
                    reply(result[0][0]);
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    // Get all data for Order Detail Fee screen
    getOrdersFeeData(request, reply) {
        const { orderId } = request.query;

        const getOrderFees = Promise.resolve(Bookshelf.knex.raw(`call GetOrderFees(${orderId})`));
        const getAllFees = Promise.resolve(Bookshelf.knex.raw(`call GetAdditionalFeeForOrder(${orderId})`));
        const getRequestedFees = Promise.resolve(
            Bookshelf.knex.raw(`call GetOrderRequestedFee(${orderId})`));
        const getFeeRequestReason = Promise.resolve(Bookshelf.knex.raw(`call GetAllReasonCodes()`));

        Promise.all([getOrderFees, getAllFees, getRequestedFees, getFeeRequestReason])
            .then(values => {
                const data = {};

                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.orderFeesData = {
                                        orderFees: item[0][0]
                                    };
                                    break;
                                case 1:
                                    data.feesData = {
                                        fees: item[0][0]
                                    };
                                    break;
                                case 2:
                                    data.requestedFeesData = {
                                        fees: item[0][0]
                                    };
                                    break;
                                case 3:
                                    data.feeRequestReasonData = {
                                        reasonList: item[0][0]
                                    };
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    async addOrderRequestedFee(request, reply) {
        const fee = request.payload;

        if (!fee.orderId) {
            reply(Boom.badRequest(error));
            return;
        }

        const rawQuery = `SELECT SUM(SignerFee) AS totalAdditionalVendorFee, SUM(BrokerFee) AS totalAdditionalClientFee FROM \`order_fee\` WHERE OrderId = ${fee.orderId} AND FeeDescripID <> ${fee.feeDescripId}`;

        let totalAdditionalVendorFee = 0;
        let totalAdditionalClientFee = 0;

        await new Promise((resolve) => Bookshelf.knex.raw(rawQuery)
            .then(result => {
                if (result !== null && result[0] !== null) {
                    totalAdditionalVendorFee = result[0][0].totalAdditionalVendorFee;
                    totalAdditionalClientFee = result[0][0].totalAdditionalClientFee;
                }
                resolve();
            }));

        if (totalAdditionalVendorFee === null) {
            totalAdditionalVendorFee = 0;
        }

        if (totalAdditionalClientFee === null) {
            totalAdditionalClientFee = 0;
        }

        // AnNV2: UCS 26: if the request is for client fee. Need to check if have a client fee request before, just update new fee purpose amount. Not add more than 2 client fee requests.
        let feeApprovalId = 0;

        if (fee.isClientFee) {

            const checkRequestSql = `SELECT FeeApprovalId FROM \`order_fee_approve\` WHERE OrderId=${fee.orderId} AND IsClientFee = true AND FeeApproved='Pending';`;

            const result = await Bookshelf.knex.raw(checkRequestSql);

            if (result && result[0] && result[0][0]) {
                feeApprovalId = Number(result[0][0].FeeApprovalId || 0);
            }
        }

        if (feeApprovalId > 0) {
            // update existing request fee
            const updateRequest = {
                dateStamp: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                feeAmount: fee.proposedFee - totalAdditionalClientFee
            }

            console.log("HERE #1");

            OrderFeeApprove
                .where({ feeApprovalId, feeApproved: ORDER_FEE_VENDOR_REQUEST_STATUS.PENDING, isClientFee: true })
                .save(updateRequest, { method: "update" })
                .then(() => {
                    reply({
                        isSuccess: true,
                        feeApprovalId
                    });
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                });

        } else { // add new request fee
            const newRequestFee = new OrderFeeApprove();
            // add a fee to db
            newRequestFee.save({
                OrderId: fee.orderId,
                FeeDescripId: fee.feeDescripId,
                UsersId: fee.userId,
                ReasonCode: fee.reasonCode,
                FeeReason: hasStringValue(fee.description) ? fee.description : null,
                FeeAmount: fee.isClientFee ? fee.proposedFee - totalAdditionalClientFee : fee.proposedFee - totalAdditionalVendorFee, // detect the request is a client or vendor fee request
                OriginalAmount: fee.originalAmount,
                FeeApproved: fee.status,
                DateStamp: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                SignerID: fee.signerId || null,
                IsClientFee: fee.isClientFee || false
            }, { method: "insert" }).then((result) => {
                reply({
                    isSuccess: true,
                    feeApprovalId: result.id
                });

                return;
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
        }
    }

    getOrderRequestedFee(request, reply) {
        const { orderId } = request.query;
        Bookshelf.knex.raw(`call GetOrderRequestedFee('${orderId}')`)
            .then((result) => {
                if (result !== null) {
                    reply(result[0][0]);
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    getOrderRequestedFeeType(request, reply) {
        const { orderId } = request.query;


        Bookshelf.knex.raw(`call GetOrderRequestedFeeType(${orderId})`)
            .then((result) => {
                const data = {};
                if (result !== null) {
                    var requestedFees = result[0][0];

                    // fees requested by vendor
                    data.vendorFeeRequestedByScheduler = requestedFees.filter((fee) => {
                        return fee.UserType === 'Staff' && fee.IsClientFee === 0
                    });

                    // vendor fee request submit by Tce Scheduler
                    data.vendorFeeRequestedByVendor = requestedFees.filter((fee) => {
                        return fee.UserType === 'Vendor' && fee.IsClientFee === 0
                    });

                    data.clientFeeRequestedByScheduler = requestedFees.filter((fee) => {
                        return fee.UserType === 'Staff' && fee.IsClientFee === 1
                    });;
                }

                reply(data);
                return;
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    updateOrderRequestedFee(request, reply) {
        const fee = request.payload;

        const updatedFee = {
            UsersId: fee.userId,
            ReasonCode: fee.reasonCode,
            FeeReason: fee.description,
            FeeAmount: fee.proposedFee,
            OriginalAmount: fee.originalAmount,
            FeeApproved: fee.status,
            DateStamp: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        };

        OrderFeeApprove.where({ OrderId: fee.orderId, FeeDescripId: fee.feeDescripId })
            .save(updatedFee, { method: "update" }).then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    processRequestFee(request, reply) {
        const { orderId, feeApprovalId, feeApproved, offerStatus, signerId, signerFee, feeDescripId, activity, userId, isOveride } = request.payload;

        Bookshelf.knex.raw(`
        call ChangeOrderFeeApproveStatus(${orderId}, ${feeApprovalId}, '${feeApproved}', '${offerStatus}', ${signerId}, ${signerFee}, ${feeDescripId}, '${activity}', ${userId}, ${isOveride || false});`)
            .then((result) => {
                if (result !== null) {
                    reply(result[0][0][0]);
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    updateListOrderAddionalFee(request, reply) {
        const { listAdditionalFee, orderId } = request.payload;

        let listValuesInsert = ``;
        listAdditionalFee.forEach((item) => {
            if (item.FeeId) {
                listValuesInsert = listValuesInsert === `` ? `(${orderId}, ${item.FeeId}, ${item.ClientFee}, ${item.VendorFee}, ${item.VendorFee})` : `${listValuesInsert}, (${orderId}, ${item.FeeId}, ${item.ClientFee}, ${item.VendorFee}, ${item.VendorFee})`;
            }
        });

        OrderFee.where({ OrderID: orderId }).destroy()
            .then(() => {
                if (listAdditionalFee && listAdditionalFee.length > 0) {
                    const rawInsertSql = `INSERT INTO order_fee (OrderID, FeeDescripID, BrokerFee, SignerFee, OriginalSignerFee) VALUES ${listValuesInsert};`;
                    Bookshelf.knex.raw(rawInsertSql).then(() => {
                        reply({ isSuccess: true });
                    }).catch(error => {
                        reply(Boom.badRequest(error));
                    });
                } else {
                    reply({ isSuccess: true });
                }

            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

}

export default new OrderFeeController();