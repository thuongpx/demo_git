import AreaController from "./area-controller";
const routes = [
    {
        path: "/area/getAreas",
        method: "GET",
        handler: AreaController.getAreas
    },
    {
        path: "/area/getAreasByKeyword",
        method: "GET",
        handler: AreaController.getAreasByKeyword
    },
    {
        path: "/area/getStateByZipCode",
        method: "GET",
        handler: AreaController.getStateByZipCode
    }
];

export default routes;