import Boom from "boom";
import NotaryLoop from "../../db/model/notary-loop";

class NotaryLoopController {
	constructor() { }

	addNotaryLoop(request, reply) {
		const notaryLoop = request.payload;
		const newNotaryLoop = new NotaryLoop(notaryLoop);
		newNotaryLoop.save(null, { method: "insert" }).then((result) => {
			if (result !== null) {
				reply({ NLID: result.attributes.id, isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}
}

export default new NotaryLoopController();