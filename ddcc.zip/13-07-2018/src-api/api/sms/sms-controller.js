import twilio from "twilio";
import SystemSettings from "../../db/model/system-settings";
import Boom from "boom";
import { bookshelfError } from "../../helper/common-helper";

class SmsController {
    constructor() { }

    sendSms(request, reply) {
        const { message, sendTo } = request.payload;

        if (sendTo === undefined || sendTo === "") {
            reply(Boom.badRequest("Missing receiver values"));
            return;
        }

        if (message === undefined || message === "") {
            reply(Boom.badRequest("Missing message body values"));
            return;
        }

        SystemSettings.where({})
            .fetch({ columns: ["TwilioId", "TwilioToken", "TwilioFrom"] })
            .then((settings) => {
                if (settings === null) {
                    reply(Boom.badRequest("The SMS system is not configured"));
                    return;
                }

                const { TwilioId, TwilioToken, TwilioFrom } = settings.attributes;

                if (TwilioId === null || TwilioId === "" || TwilioToken === null || TwilioToken === "" || TwilioFrom === null || TwilioFrom === "") {
                    reply(Boom.badRequest("The SMS system is not configured"));
                    return;
                }

                // this data should be save in db
                // const accountSid = "ACb9501c4b59d1d91b32464a81d5220984"; // Your Account SID from www.twilio.com/console
                // const authToken = "df5e26534b90057b94c45d54e917f59d"; // Your Auth Token from www.twilio.com/console

                const client = new twilio(TwilioId, TwilioToken);

                client.messages.create({
                    body: message,
                    to: sendTo, // Text this number
                    from: TwilioFrom // From a valid Twilio number
                })
                    .then((result) => {
                        reply(result);
                        return;
                    }).catch((error) => {
                        reply(error);
                        return;
                    });
            }).catch((err) => {
                reply(Boom.badRequest(bookshelfError(err)));
                return;
            });

    }
}

export default new SmsController();