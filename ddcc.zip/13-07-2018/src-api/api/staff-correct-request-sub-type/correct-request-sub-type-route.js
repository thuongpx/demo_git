import CorrectRequestSubTypeController from "./correct-request-sub-type-controller";
const routes = [{
        path: "/problem/getCorrectionRequestSubList",
        method: "GET",
        handler: CorrectRequestSubTypeController.getCorrectionRequestSubList
    },
    {
        path: "/problem/getCorretionRequestSubTypeById",
        method: "GET",
        handler: CorrectRequestSubTypeController.getCorretionRequestSubTypeById
    },
    {
        path: "/problem/checkExistCorrectionRequestSubType",
        method: "POST",
        handler: CorrectRequestSubTypeController.checkExistCorrectionRequestSubType
    },
    {
        path: "/problem/addCorrectionRequestSubType",
        method: "POST",
        handler: CorrectRequestSubTypeController.addCorrectionRequestSubType
    },
    {
        path: "/problem/updateCorrectionRequestSubType",
        method: "POST",
        handler: CorrectRequestSubTypeController.updateCorrectionRequestSubType
    }
];

export default routes;