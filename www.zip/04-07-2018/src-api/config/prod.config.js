export default {
    apiAccessKey: "AKIAIHKYBNT7QJJ4VSBQ",
    apiSecretKey: "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",
    snsArn: "arn:aws:sns:us-east-1:841040368837:app/APNS/CE-Production",
    snsArnEnv: "APNS"
};