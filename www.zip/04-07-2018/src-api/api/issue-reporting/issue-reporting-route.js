import IssueReportingController from "./issue-reporting-controller";

const routes = [
    {
        path: "/issueReporting/getIssuesReportingById",
        method: "GET",
        handler: IssueReportingController.getIssuesReportingById
    },

    {
        path: "/issueReporting/updateIssueReporting",
        method: "POST",
        handler: IssueReportingController.updateIssueReporting
    }
];


export default routes;