import Boom from "boom";
import moment from "moment";
import TestInfo from "../../db/model/test-info";
import TestSection from "../../db/model/test-section";
import VendorTestResult from "../../db/model/vendor-test-result";
import TestQa from "../../db/model/test-qa";
import Signers from "../../db/model/signers";
import TrainingProgramTest from "../../db/model/training-program-test";
import { isBuffer, bufferToBoolean } from "../../helper/common-helper";
import Bookshelf from "../../db/database";
import { handleSingleQuote, replaceAll, hasStringValue } from "../../helper/common-helper";
import { NOTIFICATION_TEMPLATE_PURPOSE } from "../../constant/common-constant";
import sendMailCore from "../../mail/mail-helper";
import VendorCatTestTaken from "../../db/model/vendor-cat-testtaken";
class TestInfoController {
    constructor() { }

    async addTestInfo(request, reply) {
        const testInfo = request.payload;
        const { sections } = testInfo;
        delete testInfo.sections;
        let testCount = 0;
        await new Promise((resolve) => TestInfo.count().then((count) => {
            testCount = count;
            resolve();
        }).catch(error => Boom.badRequest(error)));
        new TestInfo(testInfo).save({
            tenantId: 1,
            active: true,
            defaultTest: testCount === 0,
            createdDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        }, { method: "insert" }).then(async (testInfoModel) => {
            const testId = testInfoModel.get("id");

            const addSection = async section => {
                if (section.flag !== "Deleted") {
                    const { questions } = section;
                    delete section.questions;
                    delete section.isShowQuestion;
                    delete section.sectionId;
                    delete section.flag;
                    delete section.isNewAdded;
                    await new Promise((sectionResolve) => new TestSection(section).save({ testId }, { method: "insert" }).then(async sectionModel => {
                        const sectionId = sectionModel.get("id");
                        const addQuestion = async question => {
                            if (question.flag !== "Deleted") {
                                delete question.questionId;
                                delete question.flag;
                                delete question.isNewAdded;
                                const errorAddQuestion = error => Boom.badRequest(error);
                                await new Promise((resolve) => new TestQa(question).save({ tenantId: 1, testId, sectionId }, { method: "insert" }).then(() => {
                                    resolve();
                                }).catch(errorAddQuestion));
                            }
                        };
                        for (const question of questions) {
                            await addQuestion(question);
                        }
                        sectionResolve();
                    }).catch(error => Boom.badRequest(error)));
                }
            };
            for (const section of sections) {
                await addSection(section);
            }
            reply({ isSuccess: true });
        }).catch(error => Boom.badRequest(error));
    }

    getTestInfoById(request, reply) {
        const { testId } = request.query;
        TestInfo.where({ testId }).fetch({ columns: ["testId", "expiredAfter", "testName", "testDesc", "passPercent", "maxAttempts", "lockDays"] }).then(test => {
            TestSection.where({ testId }).orderBy("sortOrder", "ASC").fetchAll({ columns: ["sectionId", "sectionDescription", "sortOrder", "testId"] }).then(sections => {
                TestQa.where({ testId }).orderBy("sortOrder", "ASC").fetchAll({ columns: ["testId", "questionId", "sectionId", "question", "a", "b", "c", "d", "e", "correct", "inActive", "isRotated", "sortOrder"] }).then((questions) => {
                    const handleConvertBufferToBoolean = question => {
                        const handleConvert = (key) => {
                            const value = question.attributes[key];
                            if (isBuffer(value)) {
                                question.attributes[key] = bufferToBoolean(value);
                            }
                        };

                        Object.keys(question.attributes).forEach(handleConvert);
                        return question;
                    };

                    questions = questions.map(handleConvertBufferToBoolean);

                    const addQuestions = section => {
                        section.attributes.questions = [];
                        const addQuestion = question => {
                            if (question.get("sectionId") === section.get("sectionId")) {
                                section.attributes.questions.push(question);
                            }
                        };

                        questions.forEach(addQuestion);
                        return section;
                    };

                    sections = sections.map(addQuestions);
                    test.attributes.sections = sections;
                    reply(test);
                }).catch(error => Boom.badRequest(error));
            }).catch(error => Boom.badRequest(error));
        }).catch(error => Boom.badRequest(error));
    }

    activeDeactiveTestInfo(request, reply) {
        const testInfo = request.payload;
        TestInfo.where({ testId: testInfo.testId }).save(testInfo, { method: "update" }).then(() => {
            if (!testInfo.active) {
                TrainingProgramTest.where({ testId: testInfo.testId }).destroy().then(() => {
                    reply({ isSuccess: true });
                }).catch(error => Boom.badRequest(error));
            } else {
                reply({ isSuccess: true });
            }
        }).catch(error => Boom.badRequest(error));
    }

    async updateTestInfo(request, reply) {
        const testInfo = request.payload;
        const { sections } = testInfo;
        delete testInfo.sections;

        const badRequest = error => Boom.badRequest(error);

        TestInfo.where({ testId: testInfo.testId }).save(testInfo, { method: "update" }).then(async () => {
            if (sections) {
                const handleSection = async section => {
                    const { questions, isNewAdded, flag } = section;
                    delete section.flag;
                    delete section.questions;
                    delete section.isShowQuestion;
                    delete section.isNewAdded;

                    const handleQuestions = async sectionId => {
                        const handleQuestion = async question => {
                            const questionFlag = question.flag;
                            const isNewQuestionAdded = question.isNewAdded;
                            delete question.flag;
                            delete question.isNewAdded;
                            switch (questionFlag) {
                                case "Edited":
                                    await new Promise(resolve => TestQa.where({ questionId: question.questionId }).save(question, { method: "update" }).then(() => resolve()).catch(badRequest));
                                    break;
                                case "Added":
                                    delete question.questionId;
                                    await new Promise(resolve => new TestQa(question).save({ sectionId, tenantId: 1, testId: testInfo.testId }, { method: "insert" }).then(() => resolve()).catch(badRequest));
                                    break;
                                case "Deleted":
                                    if (!isNewQuestionAdded) {
                                        await new Promise(resolve => TestQa.where({ questionId: question.questionId }).destroy().then(() => resolve()).catch(badRequest));
                                    }
                                    break;
                                default:
                                    break;
                            }
                        };

                        for (const question of questions) {
                            await handleQuestion(question);
                        }

                    };

                    switch (flag) {
                        case "Edited":
                            await new Promise(resolve => TestSection.where({ sectionId: section.sectionId }).save(section, { method: "update" }).then(async () => {
                                await handleQuestions(section.sectionId);
                                resolve();
                            }).catch(badRequest));
                            break;
                        case "Added":
                            delete section.sectionId;
                            await new Promise(resolve => new TestSection(section).save({ testId: testInfo.testId }, { method: "insert" }).then(async (sectionModel) => {
                                await handleQuestions(sectionModel.get("id"));
                                resolve();
                            }).catch(badRequest));
                            break;
                        case "Deleted":
                            if (!isNewAdded) {
                                await new Promise(resolve => TestQa.where({ sectionId: section.sectionId }).destroy().then(() => {
                                    TestSection.where({ sectionId: section.sectionId }).destroy().then(() => resolve()).catch(badRequest);
                                }).catch(badRequest));
                            }
                            break;
                        default:
                            break;
                    }
                };

                for (const section of sections) {
                    await handleSection(section);
                }
            }
            reply({ isSuccess: true });
        }).catch(badRequest);
    }

    deleteTestInfo(request, reply) {
        const { testId } = request.payload;
        TestQa.where({ testId }).destroy().then(() => {
            TestSection.where({ testId }).destroy().then(() => {
                TrainingProgramTest.where({ testId }).destroy().then(() => {
                    VendorCatTestTaken.where({ testId }).destroy().then(() => {
                        const doneDeleteTestInfo = () => {
                            reply({ isSuccess: true });
                        };
                        TestInfo.where({ testId }).destroy().then(doneDeleteTestInfo).catch(error => reply(Boom.badRequest(error)));
                    }).catch(error => reply(Boom.badRequest(error)));
                }).catch(error => reply(Boom.badRequest(error)));
            }).catch(error => reply(Boom.badRequest(error)));
        }).catch(error => reply(Boom.badRequest(error)));
    }

    getTestInfos(request, reply) {
        const { testName, isActive, sortColumn, sortDirection, page, itemPerPage } = request.payload;
        Bookshelf.knex.raw(`call GetTestInfos('${handleSingleQuote(testName)}',${isActive},'${sortColumn}',${sortDirection},${page},${itemPerPage})`)
            .then((result) => {
                if (result !== null) {
                    const tests = result[0][0];
                    tests.forEach(test => {
                        if (isBuffer(test.defaultTest)) {
                            test.defaultTest = bufferToBoolean(test.defaultTest);
                        }
                    });

                    reply({ data: tests, totalRecords: result[0][1][0].TotalRecords });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    checkExistTest(request, reply) {
        const { testName } = request.payload;
        let { testId } = request.payload;
        if (!testId) {
            testId = 0;
        }
        TestInfo.query((qb) => {
            qb.where("testName", "=", `${testName}`).andWhere("testId", "<>", testId);
        }).count("*").then((result) => {
            reply({ isExist: result > 0 });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    async getTestSectionsDefaultTest(request, reply) {

        const defaultTest = await TestInfo.where({ defaultTest: 1, active: 1 }).fetch({ columns: ["testId", "testName", "testDesc", "passPercent", "maxAttempts"] });

        if (!defaultTest) {
            reply(Boom.badRequest("No default test found!"));
            return;
        }


        const testId = defaultTest.attributes.testId;
        const numberQuestion = await TestQa.where({ testId }).count();
        defaultTest.attributes.numberQuestion = numberQuestion;

        TestSection.query((ts) => {
            ts.where("TestId", "=", `${testId}`);
        }).fetchAll({ columns: ["SectionId", "SectionDescription"] }).then((result) => {
            if (result !== null) {
                reply({ sections: result, testInfo: defaultTest });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getTestQaBySectionId(request, reply) {
        const { sectionId } = request.query;

        TestQa.query((qa) => {
            qa.where("SectionId", "=", `${sectionId}`);
        }).orderBy("SortOrder").fetchAll({ columns: ["QuestionId", "Question", "A", "B", "C", "D", "E", "Correct", "SortOrder"] }).then((result) => {
            if (result !== null) {
                reply(result);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    async checkTestAnswers(request, reply) {
        const { testId, answers, vendorId, username, programId } = request.payload;

        // make sure all question ids are number
        const questionIds = Object.keys(answers);
        for (let i = 0; i < questionIds.length; i++) {
            const questionId = questionIds[i];

            if (isNaN(questionId)) {
                reply(Boom.badRequest("Invalid data!"));
                return;
            }

            questionIds[i] = +questionId;
        }

        try {
            // get test info and questions
            const questions = await TestQa.where("QuestionId", "in", questionIds).fetchAll({ columns: ["questionId", "correct"] });
            const program = await TrainingProgramTest.where({ testId, programId }).fetch({ columns: ["programId"] });
            const testInfoResult = await TestInfo.where({ testId, active: true }).fetch({ columns: ["passPercent", "maxAttempts", "lockdays"] });
            const testInfo = testInfoResult.attributes;

            if (!program) {
                reply(Boom.badRequest("Program not found!"));
                return;
            }

            // check number answer equal to number question of the test
            if (questionIds.length !== questions.length) {
                reply(Boom.badRequest("Something went wrong!"));
                return;
            }

            // check answers
            const inCorrectAnswers = [];
            questions.forEach(question => {
                const { questionId, correct } = question.attributes;
                if (correct !== answers[questionId]) {
                    inCorrectAnswers.push(questionId);
                }
            });
            const passPercent = Math.floor((1 - (inCorrectAnswers.length / questionIds.length)) * 100);
            const passed = passPercent >= testInfo.passPercent;

            // test result for insert or update
            const testResult = {
                testId,
                vendorId,
                programId: program.attributes.programId,
                percentage: passPercent,
                numCorrect: questionIds.length - inCorrectAnswers.length,
                numInCorrect: inCorrectAnswers.length,
                testedNum: 1,
                passed: passed ? "Y" : "N",
                lastTesting: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                startDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                endDate: passed ? moment().utc().format("YYYY-MM-DD HH:mm:ss") : 0
            };

            // check old test result is existed and update or insert
            const result = await VendorTestResult.where({ testId, vendorId, programId }).fetch({ columns: ["resultId", "testedNum", "lastTesting"] });
            let insertResult = null;
            if (result) {
                testResult.testedNum = result.attributes.testedNum + 1;
                const daysDiff = (new Date() - new Date(result.attributes.lastTesting)) / 1000 / 60 / 60 / 24;
                if (testResult.testedNum > testInfo.maxAttempts && daysDiff < testInfo.lockdays) {
                    reply(Boom.badRequest("Vendor Exam is locked!"));
                    return;
                }

                if (testResult.testedNum > testInfo.maxAttempts) {
                    testResult.testedNum = 1;
                }
                insertResult = await VendorTestResult.where({ resultId: result.attributes.resultId }).save(testResult, { method: "update" });
            } else {
                insertResult = await new VendorTestResult().save(testResult, { method: "insert" });
            }

            if (passed) {
                // update IsPassTest field of signer
                Signers.where({ SignerId: vendorId }).save({ IsPassTest: true }, { method: "update" });

                // send mail passed test
                // eslint-disable-next-line
                new Promise(async () => {
                    // get vendor
                    const resultVendor = await Signers.where({ SignerId: vendorId }).fetch({ columns: ["firstName", "lastName", "email"] });
                    const vendor = resultVendor.attributes;

                    // get email template
                    const rawSqlGetTemplate = `SELECT fromEmail, fromName, subject, Purpose, message FROM notification_templates nt WHERE nt.Purpose = '${handleSingleQuote(NOTIFICATION_TEMPLATE_PURPOSE.SKILL_TEST_PASSED)}' AND nt.Receiver = 'Vendor';`;
                    const resultTemplate = await Bookshelf.knex.raw(rawSqlGetTemplate);
                    const emailTemplate = resultTemplate[0][0];

                    const needReplace = {
                        username,
                        firstName: vendor.firstName,
                        lastName: vendor.lastName,
                        rightAnswers: questionIds.length - inCorrectAnswers.length,
                        totalQuestions: questionIds.length,
                        percent: passPercent
                    };

                    // replace placeholder in template
                    let html = emailTemplate.message;
                    Object.keys(needReplace).forEach(key => {
                        html = replaceAll(html, `[${key}]`, hasStringValue(needReplace[key]) ? needReplace[key] : "");
                    });

                    // send mail
                    const mailOptions = {
                        from: emailTemplate.fromEmail,
                        to: vendor.email,
                        subject: emailTemplate.subject,
                        html
                    };
                    sendMailCore(mailOptions);
                });
            }

            reply({ isSuccess: true, inCorrectAnswers, passPercent, testInfo, passed, insertResult });

        } catch (error) {
            reply({ isSuccess: false, message: "Internal error!", error });
        }
    }

    async isVendorFailedExam(request, reply) {
        const { vendorId } = request.query;
        const testInfo = await TestInfo.where({ defaultTest: 1, active: 1 }).fetch({ columns: ["testId", "testName", "testDesc", "lockdays", "passPercent", "maxAttempts"] });

        if (!testInfo) {
            reply(Boom.badRequest("No default test found!"));
            return;
        }

        // get test result
        const result = await VendorTestResult.where({ testId: testInfo.attributes.testId, vendorId }).fetch({ columns: ["resultId", "testedNum", "percentage", "passed", "lastTesting"] });
        if (!result || result.attributes.passed === "Y" || result.attributes.testedNum < testInfo.attributes.maxAttempts) {
            reply({ isFailed: false, isPassed: result ? result.attributes.passed === "Y" : false });
            return;
        }

        reply({ isFailed: true, testInfo, testResult: result });
        return;
    }

    setDefaultTest(request, reply) {
        const { testId } = request.payload;
        console.log(testId);
        const rawUpdateSql = "update test_info set defaultTest = false;";
        Bookshelf.knex.raw(rawUpdateSql).then(() => {
            TestInfo.where({ testId }).save({ defaultTest: true }, { method: "update" }).then(() => {
                reply({ isSuccess: true });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}

export default new TestInfoController();