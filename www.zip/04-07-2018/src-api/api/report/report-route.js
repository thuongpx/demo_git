import SendReport from "./report-controller";

const routes = [{
    path: "/report/sendReportOrderDetails",
    method: "POST",
    handler: SendReport.sendReportOrderDetails
}, {
    path: "/report/sendReportOrderConfirmation",
    method: "POST",
    handler: SendReport.sendReportOrderConfirmation
}, {
    path: "/report/sendOrderClosedReport",
    method: "GET",
    handler: SendReport.sendOrderClosedReport
}, {
    path: "/report/sendOrderScheduledReport",
    method: "GET",
    handler: SendReport.sendOrderScheduledReport
}];

export default routes;