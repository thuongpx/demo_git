import Boom from "boom";
import Bookshelf from "./../../db/database";
import sendMailCore from "../../mail/mail-helper";
import { replaceAll, handleSingleQuote } from "../../helper/common-helper";

class ClientPreferredVendorController {
    constructor() { }

    addClientPreferredVendor(request, reply) {
        const { listId, isCustomer, clientId } = request.payload;

        let rawSqlGetInitData = `select signerId, email, firstName, lastName, taxID from signer where signerId in (`;

        for (let i = 0; i < listId.length - 1; i++) {
            rawSqlGetInitData = `${rawSqlGetInitData}${listId[i]}, `;
        }

        rawSqlGetInitData = `${rawSqlGetInitData}${listId[listId.length - 1]})`;

        Bookshelf.knex.raw(rawSqlGetInitData).then(result => {
            const listData = result[0];
            let insertSql = `insert into ${isCustomer === true ? "customer_preferred_vendor" : "broker_preferred_vendor"}  (\`${isCustomer === true ? "CustomerId" : "BrokerId"}\`, \`SignerId\`, \`FirstName\`, \`LastName\`, \`Email\`, \`TaxId\`) values `;

            listData.forEach((item, index) => {
                insertSql = `${insertSql} (${clientId}, ${item.signerId}, '${handleSingleQuote(item.firstName)}', '${handleSingleQuote(item.lastName)}', '${handleSingleQuote(item.email)}', '${item.taxID}')`;
                if (index === result[0].length - 1) {
                    insertSql = `${insertSql};`;
                } else {
                    insertSql = `${insertSql},`;
                }
            });

            Bookshelf.knex.raw(insertSql).then(() => {
                reply({ isSuccess: true });
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    addClientPreferredVendorOutsideTCE(request, reply) {
        const { firstName, lastName, email, taxId, clientId, isCustomer } = request.payload;

        const rawSqlCheckSignerExist = `SELECT signerId, email, firstName, lastName, taxID FROM signer where email = "${email}" and taxId = "${taxId}";`;
        Bookshelf.knex.raw(rawSqlCheckSignerExist).then(async result => {
            let insertSql = `insert into ${isCustomer === true ? "customer_preferred_vendor" : "broker_preferred_vendor"}  (\`${isCustomer === true ? "CustomerId" : "BrokerId"}\`, \`SignerId\`, \`FirstName\`, \`LastName\`, \`Email\`, \`TaxId\`) values `;
            let needInsertDb = true;
            if (result[0][0]) {
                const data = result[0][0];

                const rawSqlCheckAddedToListPreferred = `SELECT id  FROM ${isCustomer === true ? "customer_preferred_vendor" : "broker_preferred_vendor"} where signerId = ${data.signerId};`;

                await new Promise(resolve => Bookshelf.knex.raw(rawSqlCheckAddedToListPreferred).then(resultCheck => {
                    if (resultCheck[0][0]) {
                        needInsertDb = false;
                    }
                    resolve();
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                }));

                insertSql = `${insertSql} (${clientId}, ${data.signerId}, '${handleSingleQuote(data.firstName)}', '${handleSingleQuote(data.lastName)}', '${handleSingleQuote(data.email)}', '${handleSingleQuote(data.taxID)}');`;
            } else {
                insertSql = `${insertSql} (${clientId}, null, '${handleSingleQuote(firstName)}', '${handleSingleQuote(lastName)}', '${handleSingleQuote(email)}', '${taxId}');`;

                //send invite email
                let rawSqlGetDataForEmail = `select b.Company as clientName from broker b where b.BrokerID = ${clientId};`;

                if (isCustomer === true) {
                    rawSqlGetDataForEmail = `SELECT \`name\` as clientName FROM customers where customerId = ${clientId};`;
                }

                Bookshelf.knex.raw(rawSqlGetDataForEmail).then(dataClient => {
                    const name = dataClient[0][0].clientName;

                    const rawSqlGetEmailTemplate = `SELECT * FROM notification_templates where Purpose = 'Invitation to Vendor by Client';`;

                    Bookshelf.knex.raw(rawSqlGetEmailTemplate)
                        .then(resultEmailTemplate => {
                            const emailTemplate = resultEmailTemplate[0][0];
                            let subject = emailTemplate.Subject;
                            let message = emailTemplate.Message;
                            message = replaceAll(message, ["[vendortFirstName]"], `${firstName}`);
                            message = replaceAll(message, ["[vendorLastName]"], `${lastName}`);
                            message = replaceAll(message, ["[clientCompany]"], `${name}`);
                            subject = replaceAll(subject, ["[clientCompany]"], `${name}`);

                            const mailOptions = {
                                from: emailTemplate.FromEmail,
                                to: email,
                                subject,
                                html: message
                            };

                            sendMailCore(mailOptions);
                        }).catch((error) => {
                            reply(Boom.badRequest(error));

                            return reply;
                        });
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });
            }

            if (needInsertDb) {
                Bookshelf.knex.raw(insertSql).then(() => {
                    reply({ isSuccess: true });
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });
            } else {
                reply({ isSuccess: true, isExist: true });
            }

        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    deletePreferredVendor(request, reply) {
        const { id, isCustomer } = request.query;

        const rawSql = `DELETE FROM ${isCustomer === "true" ? "customer_preferred_vendor" : "broker_preferred_vendor"} WHERE id=${id};`;

        Bookshelf.knex.raw(rawSql).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    deleteAllClientPreferredVendor(request, reply) {
        const { clientId, isCustomer } = request.query;
        const colName = isCustomer === "true" ? "customerId" : "brokerId";

        const rawSql = `DELETE FROM ${isCustomer === "true" ? "customer_preferred_vendor" : "broker_preferred_vendor"} WHERE ${colName}=${clientId};`;

        Bookshelf.knex.raw(rawSql).then(() => {
            reply({ isSuccess: true });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    isExistsClientPreferred(request, reply) {
        const { clientId, isCustomer, email, taxId } = request.payload;
        const colName = isCustomer === "true" ? "customerId" : "brokerId";

        const rawSql = `Select id FROM ${isCustomer === "true" ? "customer_preferred_vendor" : "broker_preferred_vendor"} WHERE ${colName}=${clientId} and email='${handleSingleQuote(email)}' and taxId= '${handleSingleQuote(taxId)}';`;

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result[0] && result[0][0]) {
                reply({ isExist: true });
            } else {
                reply({ isExist: false });
            }
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }
}

export default new ClientPreferredVendorController();