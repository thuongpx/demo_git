import ToolController from "./tool-controller";
const routes = [
    {
        path: "/tool/getListResource",
        method: "GET",
        handler: ToolController.getListResource
    },
    {
        path: "/tool/getListLink",
        method: "POST",
        handler: ToolController.getListLink
    },
    {
        path: "/tool/getFaqsByQuestion",
        method: "GET",
        handler: ToolController.getFaqsByQuestion
    },
    {
        path: "/tool/downloadResources",
        method: "GET",
        handler: ToolController.downloadResources
    },
    {
        path: "/tool/getPageDisplayFromConstant",
        method: "GET",
        config: {
            auth: false
        },
        handler: ToolController.getPageDisplayFromConstant
    },
    {
        path: "/tool/getListResourceByViews",
        method: "GET",
        config: {
            auth: false
        },
        handler: ToolController.getListResourceByViews
    },
    {
        path: "/tool/addLinksToDataBase",
        method: "POST",
        config: {
            auth: false
        },
        handler: ToolController.addLinksToDataBase
    },
    {
        path: "/tool/deleteLinksById",
        method: "GET",
        config: {
            auth: false
        },
        handler: ToolController.deleteLinksById
    },
    {
        path: "/tool/editLinksById",
        method: "POST",
        config: {
            auth: false
        },
        handler: ToolController.editLinksById
    }
];

export default routes;
