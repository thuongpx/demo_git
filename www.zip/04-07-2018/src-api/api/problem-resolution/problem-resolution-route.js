import ProblemResolutionController from "./problem-resolution-controller";

const routes = [{
        path: "/resolution/getResolutionByProblemId",
        method: "GET",
        handler: ProblemResolutionController.getResolutionByProblemId
    },
    {
        path: "/resolution/AddResolution",
        method: "POST",
        handler: ProblemResolutionController.addResolution
    }
];

export default routes;