import Bookshelf from "../../db/database";

export const getOrderTypes = async () => {
    const rawSql = `SELECT LoanType FROM loan_type`;

    const rs = await Bookshelf.knex.raw(rawSql);

    if (rs) {
        return rs[0];
    }

    return [];
};