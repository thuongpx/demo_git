import CannedReportController from "./canned-report-controller";

const routes = [
    {
        path: "/cannedReport/fetchDataOfOpenOrderChart",
        method: "POST",
        config: {
            auth: false
        },
        handler: CannedReportController.fetchDataOfOpenOrderChart
    },
    {
        path: "/cannedReport/getInitDataForCannedReport",
        method: "GET",
        config: {
            auth: false
        },
        handler: CannedReportController.getInitDataForCannedReport
    }
];

export default routes;