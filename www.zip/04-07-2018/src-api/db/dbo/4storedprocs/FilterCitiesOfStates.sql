DROP PROCEDURE IF EXISTS `FilterCitiesOfStates`;

DELIMITER $$
CREATE PROCEDURE `FilterCitiesOfStates`(
	IN statesString VARCHAR(1000),
    IN citiesString VARCHAR(5000)
)
BEGIN
	declare pos int;           -- Keeping track of the next item's position
	declare item varchar(100); -- A single item of the input
	declare delimiterChar char(1) DEFAULT ';'; -- A single item of the input
	declare breaker int;       -- Safeguard for while loop

	-- Prepare
	SET statesString = REPLACE(statesString, delimiterChar, ','); 

	-- The string must end with the delimiter
	if right(citiesString, 1) <> delimiterChar then
		set citiesString = CONCAT(citiesString, delimiterChar);
	end if;

	DROP TABLE IF EXISTS SelectedCities;
	CREATE TEMPORARY TABLE SelectedCities ( CityName varchar(100) );
	SET breaker = 0;

	WHILE char_length(citiesString) > 1 DO
		-- Iterate looking for the delimiter, add rows to temporary table.
		SET breaker = breaker + 1;
		SET pos = INSTR(citiesString, delimiterChar);
		SET item = LEFT(citiesString, pos - 1);
		SET citiesString = SUBSTRING(citiesString, pos + 1);
		INSERT INTO SelectedCities values(item);
	END WHILE;
      
	SET @sqlQuery = CONCAT('SELECT DISTINCT City as name
		FROM zip z INNER JOIN SelectedCities s ON z.City = s.CityName
        WHERE z.State IN(', statesString, ')');

	PREPARE stmt FROM @sqlQuery;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    DROP TABLE IF EXISTS SelectedCities;
END$$
DELIMITER ;
