DROP procedure IF EXISTS `GetAllLoanType`;

DELIMITER $$

CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllLoanType`()
BEGIN
   SELECT LoanTypeId,LoanType  FROM loan_type order by LoanTypeId;
END $$
DELIMITER ;

