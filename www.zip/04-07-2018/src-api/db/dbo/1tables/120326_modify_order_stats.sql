DROP PROCEDURE IF EXISTS `alter_table_order_stats`;

DELIMITER $$
CREATE PROCEDURE `alter_table_order_stats` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order_stats' AND 
                            COLUMN_NAME = 'SignerID') THEN
	BEGIN
		ALTER TABLE `order_stats` 
		ADD COLUMN `SignerID` INT NULL;
	END;
    END IF;
    
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order_stats' AND 
                            COLUMN_NAME = 'AptDateTime') THEN
	BEGIN
		ALTER TABLE `order_stats` 
		ADD COLUMN `AptDateTime` DATETIME NULL;
	END;
    END IF;
    
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order_stats' AND 
                            COLUMN_NAME = 'Sfees') THEN
	BEGIN
		ALTER TABLE `order_stats` 
		ADD COLUMN `Sfees` DECIMAL(19, 4) NULL;
	END;
    END IF;
    
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order_stats' AND 
                            COLUMN_NAME = 'Sfee') THEN
	BEGIN
		ALTER TABLE `order_stats` 
		ADD COLUMN `Sfee` DECIMAL(19, 4) NULL;
	END;
    END IF;
    
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order_stats' AND 
                            COLUMN_NAME = 'Bfees') THEN
	BEGIN
		ALTER TABLE `order_stats` 
		ADD COLUMN `Bfees` DECIMAL(19, 4) NULL;
	END;
    END IF;

END$$

DELIMITER ;

call alter_table_order_stats();

DROP PROCEDURE IF EXISTS `alter_table_order_stats`;
