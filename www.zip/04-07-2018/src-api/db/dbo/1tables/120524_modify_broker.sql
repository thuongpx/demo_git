DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
    -- drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_testing' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'ReqRateNew') THEN
	BEGIN
		ALTER TABLE `broker` 
		DROP COLUMN `ReqRateNew`;
	END;
    END IF;
    
    -- drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_testing' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'ReqRateGood') THEN
	BEGIN
		ALTER TABLE `broker` 
		DROP COLUMN `ReqRateGood`;
	END;
    END IF;
    
    -- drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_testing' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'ReqRateVeryGood') THEN
	BEGIN
		ALTER TABLE `broker` 
		DROP COLUMN `ReqRateVeryGood`;
	END;
    END IF;
    
    -- drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_testing' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'ReqRateExellent') THEN
	BEGIN
		ALTER TABLE `broker` 
		DROP COLUMN `ReqRateExellent`;
	END;
    END IF;
    
    -- drop column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_testing' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'ReqRating') THEN
	BEGIN
		ALTER TABLE `broker` 
		ADD COLUMN `ReqRating` VARCHAR(50) NULL;
	END;
    END IF;
END$$

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;