use tce_dev;

DROP PROCEDURE IF EXISTS `alter_table_customers`;

DELIMITER $$
CREATE PROCEDURE `alter_table_customers` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'customers' AND 
                            COLUMN_NAME = 'IndustryId') THEN
	BEGIN
		ALTER TABLE `customers` 
		ADD COLUMN `IndustryId` INT NULL,
		ADD INDEX `industry_customer_idx` (`IndustryId` ASC);
		ALTER TABLE `customers` 
		ADD CONSTRAINT `industry_customer`
		  FOREIGN KEY (`IndustryId`)
		  REFERENCES `industry` (`IndustryId`)
		  ON DELETE NO ACTION
		  ON UPDATE NO ACTION;
	END;
    END IF;
    
END$$

DELIMITER ;

call alter_table_customers();

DROP PROCEDURE IF EXISTS `alter_table_customers`;





