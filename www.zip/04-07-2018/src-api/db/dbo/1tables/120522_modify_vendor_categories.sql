DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
    -- change column size
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'vendor_categories' AND 
                            COLUMN_NAME = 'Color') THEN
	BEGIN
		ALTER TABLE `vendor_categories` 
		MODIFY COLUMN `Color` VARCHAR(50) NULL;
	END;
    END IF;
END$$

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;