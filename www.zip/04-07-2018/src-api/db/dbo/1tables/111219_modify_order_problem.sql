ALTER TABLE `order_problem` 
ADD COLUMN `ResolvedBy` INT(11) NULL AFTER `TenantId`;

ALTER TABLE `order_problem` 
CHANGE COLUMN `EnteredBy` `EnteredBy` INT(11) NULL DEFAULT NULL ;
