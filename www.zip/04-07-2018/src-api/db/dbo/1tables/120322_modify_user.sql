DROP PROCEDURE IF EXISTS `alter_table_users`;

DELIMITER $$
CREATE PROCEDURE `alter_table_users` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'users' AND 
                            COLUMN_NAME = 'EmailVerificationToken') THEN
	BEGIN
		ALTER TABLE `users` 
		ADD COLUMN `EmailVerificationToken` VARCHAR(260) NULL;
	END;
    END IF;

END$$

DELIMITER ;

call alter_table_users();

DROP PROCEDURE IF EXISTS `alter_table_users`;

