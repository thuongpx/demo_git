CREATE TABLE IF NOT EXISTS `user_announcement` (
  `UaId` INT NOT NULL AUTO_INCREMENT,
  `UserId` INT NULL,
  `AnnouncementID` INT NULL,
  `NumOfAppearance` TINYINT NULL,
  PRIMARY KEY (`UaId`));
