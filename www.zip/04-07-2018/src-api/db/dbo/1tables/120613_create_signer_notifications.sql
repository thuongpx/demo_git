CREATE TABLE IF NOT EXISTS `signer_notifications` (
  `NotifID` INT NOT NULL AUTO_INCREMENT,
  `NotifDesc` VARCHAR(150) NULL,
  `NotifTemplate` VARCHAR(200) NULL,
  `Subject` VARCHAR(300) NULL,
  `PageTitle` VARCHAR(150) NULL,
  `StartDate` DATETIME NULL,
  `Active` BIT NULL,
  `CompleteDate` DATETIME NULL,
  `Audience` VARCHAR(1) NULL,
  PRIMARY KEY (`NotifID`)
  );