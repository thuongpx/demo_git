
DELIMITER $$
CREATE PROCEDURE `alter_table_signer_offer` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'signer_offer' AND 
                            COLUMN_NAME = 'GuidExpiredTime') THEN
	BEGIN
		ALTER TABLE `signer_offer` 
		ADD COLUMN `GuidExpiredTime` DATETIME NULL DEFAULT NULL;
	END;
    END IF;    
END$$

DELIMITER ;

call alter_table_signer_offer();

DROP PROCEDURE IF EXISTS `alter_table_signer_offer`;





