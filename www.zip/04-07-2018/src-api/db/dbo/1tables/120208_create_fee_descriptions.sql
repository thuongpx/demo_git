CREATE TABLE IF NOT EXISTS `fee_descriptions` (
	`FeeDescriptionId` INT(11) NOT NULL AUTO_INCREMENT,
    `Description` VARCHAR(50) NULL,
    `LongDescription` VARCHAR(200) NULL,
    PRIMARY KEY (`FeeDescriptionId`)
);