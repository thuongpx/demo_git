CREATE TABLE IF NOT EXISTS `faq` (
	`Id` int(11) NOT NULL AUTO_INCREMENT,
	`SectId` INT,
	`Question` VARCHAR(200),
	`Answer` VARCHAR(1000),
	`Views` VARCHAR(10),
	PRIMARY KEY (`Id`)
);
