CREATE TABLE IF NOT EXISTS `faq_sect` (
	`Id` int(11) NOT NULL AUTO_INCREMENT,
	`Section` VARCHAR(100),
	`Description` VARCHAR(500),
	`SiteSect` VARCHAR(12),
	`Page` VARCHAR(1),
	PRIMARY KEY (`Id`)
);
