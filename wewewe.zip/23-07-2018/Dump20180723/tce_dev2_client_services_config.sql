-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client_services_config`
--

DROP TABLE IF EXISTS `client_services_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_services_config` (
  `ConfigId` int(11) NOT NULL AUTO_INCREMENT,
  `ClientID` int(11) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `CreatedBy` int(11) DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `EffecttiveDate` datetime DEFAULT NULL,
  `ApprovedBy` int(11) DEFAULT NULL,
  `UseVolume` bit(1) DEFAULT NULL,
  `OrderPerDay` int(11) DEFAULT NULL,
  `UseCalendar` bit(1) DEFAULT NULL,
  `CutoffDate` tinyint(4) DEFAULT NULL,
  `UseGeography` bit(1) DEFAULT NULL,
  `State1` varchar(200) DEFAULT NULL,
  `MSA1` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ConfigId`),
  KEY `clientid_client_services_config_idx` (`ClientID`),
  CONSTRAINT `clientid_client_services_config` FOREIGN KEY (`ClientID`) REFERENCES `broker` (`BrokerID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_services_config`
--

LOCK TABLES `client_services_config` WRITE;
/*!40000 ALTER TABLE `client_services_config` DISABLE KEYS */;
INSERT INTO `client_services_config` VALUES (1,1,'2018-03-23 10:15:43',5,'2018-05-23 10:15:43',5,3,'2018-03-22 00:00:00',49,'',20,'',22,'','CA;FL',''),(2,1,'2018-03-22 09:01:05',17,'2018-05-23 10:15:43',17,3,'2018-03-30 09:01:05',NULL,'',42,'',16,'','OH','Columbus'),(3,3,'2018-04-04 12:23:16',8,'2018-05-23 10:15:43',8,2,'2018-05-16 00:00:00',49,'',20,'\0',1,'\0','',''),(4,4,'2018-05-15 07:09:30',381,'2018-05-23 10:15:43',381,2,'2018-05-14 00:00:00',49,'',5,'',9,'\0','',''),(6,NULL,NULL,381,'2018-05-23 10:15:43',381,NULL,NULL,NULL,'',5,'',11,'\0','',''),(7,NULL,NULL,5,'2018-05-23 10:15:43',5,2,'2018-05-30 00:00:00',49,'',10,'',5,'','AK;AL','Abbeville;Adamsville'),(9,5,'2018-05-31 02:35:21',5,'2018-05-23 10:15:43',5,3,'2018-05-30 00:00:00',49,'\0',NULL,'',10,'\0','',''),(11,6,'2018-05-31 02:48:15',5,'2018-05-23 10:15:43',5,2,'2018-06-29 17:00:00',49,'\0',NULL,'',12,'\0','',''),(12,11,'2018-06-18 11:39:30',11,'2018-06-18 11:39:30',11,2,'2018-07-17 17:00:00',68,'',11,'',31,'','AL;AR','Mc Williams'),(13,11,'2018-06-18 11:42:30',11,'2018-06-18 11:42:30',11,NULL,NULL,NULL,'',1111,'',31,'','AK;AL','Adamsville;Mc Williams'),(17,9,'2018-06-20 02:15:24',9,'2018-06-20 02:22:22',9,3,'2018-07-19 17:00:00',68,'',9999,'',1,'','AK;AL','Alabaster;Alakanuk'),(18,NULL,NULL,2,'2018-06-20 16:13:44',2,NULL,NULL,NULL,'',11111,'\0',NULL,'\0','',''),(20,9,'2018-06-21 11:26:21',9,'2018-06-21 11:30:40',9,2,'2018-07-20 17:00:00',379,'',12312,'\0',30,'\0','',''),(26,1,'2018-06-25 04:11:53',1,'2018-06-25 04:11:53',1,3,'2018-07-24 17:00:00',68,'',1,'',15,'','AK;AL;AR;AZ',''),(27,1,'2018-06-25 04:12:22',1,'2018-06-25 04:12:38',1,3,'2018-07-24 17:00:00',68,'',12321,'',16,'','AK;AL;AR;AZ',''),(28,1,'2018-06-04 02:46:00',1,'2018-06-25 04:12:22',1,2,'2018-07-04 02:46:07',-1,'',12321,'',1,'','AK;AL;AR',''),(29,6,'2018-07-10 07:23:34',6,'2018-07-10 07:23:34',6,1,NULL,NULL,'\0',NULL,'\0',NULL,'','AZ','');
/*!40000 ALTER TABLE `client_services_config` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-23 17:42:59
