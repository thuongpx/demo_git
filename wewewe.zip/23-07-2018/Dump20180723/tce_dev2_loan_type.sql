-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `loan_type`
--

DROP TABLE IF EXISTS `loan_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_type` (
  `LoanTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `LoanType` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`LoanTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_type`
--

LOCK TABLES `loan_type` WRITE;
/*!40000 ALTER TABLE `loan_type` DISABLE KEYS */;
INSERT INTO `loan_type` VALUES (1,'**Texas Cash Out 1'),(2,'< 20 Pages'),(3,'Acknowledgements'),(4,'Adoptions'),(5,'Application'),(6,'Cash Purchase'),(7,'Conveyance'),(8,'Declarations'),(9,'Deed In Lieu'),(10,'Deed Only'),(11,'Disclosure'),(12,'Full Purchase'),(13,'Gas Land Lease'),(14,'HELOC'),(15,'Inspection'),(16,'Interest Rate Swap Agreement'),(17,'Investment Purchase'),(18,'Investment Refinance'),(19,'Land Lease'),(20,'Lease'),(21,'Loan Modification'),(22,'Medical Release'),(23,'Mineral Deed'),(24,'Misc (Single Doc, Etc)'),(25,'Note Modification'),(26,'Note/Loan Modification'),(27,'Oil Land Lease'),(28,'Paid Up Lease'),(29,'Partnership Agreement'),(30,'Partnership Agreements'),(31,'Power of Attorney'),(32,'Proposed Structured Settlement'),(33,'Purchase'),(34,'Quit Claim'),(35,'Recorded liens'),(36,'Refinance'),(37,'Reverse Mortgage Application'),(38,'Reverse Mortgage Closing'),(39,'Sale of Structured Settlement (lump sum)'),(40,'Schedule K1 (Partnership Income, loss, dividends)'),(41,'Second Mortgage'),(42,'Seller Side Purchase (Sale)'),(43,'Standard Producers 88 Oil and Gas Lease'),(44,'Trusts'),(45,'Wills'),(46,'Seller Side Purchase (Sale)'),(75,'sadsdfds'),(81,'Genk'),(97,'1HoangN7');
/*!40000 ALTER TABLE `loan_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-23 17:43:23
