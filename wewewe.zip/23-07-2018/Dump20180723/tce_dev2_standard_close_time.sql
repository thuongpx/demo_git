-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `standard_close_time`
--

DROP TABLE IF EXISTS `standard_close_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `standard_close_time` (
  `StandardId` int(11) NOT NULL AUTO_INCREMENT,
  `IndustryId` int(11) DEFAULT NULL,
  `LoanTypeId` varchar(250) DEFAULT NULL,
  `StandardTime` int(11) DEFAULT NULL,
  PRIMARY KEY (`StandardId`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standard_close_time`
--

LOCK TABLES `standard_close_time` WRITE;
/*!40000 ALTER TABLE `standard_close_time` DISABLE KEYS */;
INSERT INTO `standard_close_time` VALUES (1,1,'5',90),(2,1,'33',90),(3,1,'42',60),(4,1,'36',90),(5,1,'41',60),(6,1,'14',60),(7,1,'9',60),(8,1,'34',60),(9,1,'11',60),(10,1,'10',60),(11,1,'26',60),(12,1,'17',90),(13,1,'18',90),(14,1,'6',60),(15,1,'1',90),(16,1,'24',45),(17,2,'37',150),(18,2,'38',150),(19,2,'24',60),(20,3,'33',150),(21,3,'36',150),(22,3,'29',150),(23,3,'15',90),(24,3,'24',45),(25,4,'33',45),(26,4,'20',45),(27,4,'36',45),(28,4,'15',45),(29,5,'35',45),(30,5,'30',45),(31,5,'40',45),(32,5,'16',45),(33,5,'8',45),(34,5,'3',45),(35,5,'4',45),(36,5,'45',45),(37,5,'44',45),(38,5,'31',45),(39,5,'22',45),(40,6,'12',60),(41,6,'2',60),(42,6,'10',45),(43,6,'24',45),(44,7,'27',60),(45,7,'13',60),(46,7,'43',60),(47,7,'23',60),(48,7,'28',45),(49,7,'7',45),(50,7,'24',45),(51,8,'32',60),(52,8,'39',60),(53,8,'24',45),(54,9,'19',60),(55,9,'7',45);
/*!40000 ALTER TABLE `standard_close_time` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-23 17:43:26
