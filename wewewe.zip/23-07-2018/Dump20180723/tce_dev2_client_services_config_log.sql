-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client_services_config_log`
--

DROP TABLE IF EXISTS `client_services_config_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_services_config_log` (
  `LogID` int(11) NOT NULL AUTO_INCREMENT,
  `ConfigId` int(11) NOT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `EffecttiveDate` datetime DEFAULT NULL,
  `UseVolume` bit(1) DEFAULT NULL,
  `OrderPerDay` int(11) DEFAULT NULL,
  `UseCalendar` bit(1) DEFAULT NULL,
  `CutoffDate` tinyint(4) DEFAULT NULL,
  `UseGeography` bit(1) DEFAULT NULL,
  `State1` varchar(200) DEFAULT NULL,
  `MSA1` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`LogID`),
  KEY `configid_client_services_config_log_idx` (`ConfigId`),
  CONSTRAINT `configid_client_services_config_log` FOREIGN KEY (`ConfigId`) REFERENCES `client_services_config` (`ConfigId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_services_config_log`
--

LOCK TABLES `client_services_config_log` WRITE;
/*!40000 ALTER TABLE `client_services_config_log` DISABLE KEYS */;
INSERT INTO `client_services_config_log` VALUES (1,1,'2018-03-23 10:15:43',5,NULL,NULL,'',20,'',22,'','CA;FL',''),(2,2,'2018-03-30 09:01:05',17,NULL,NULL,'',42,'',16,'','OH','Columbus'),(3,3,'2018-04-04 12:22:53',8,NULL,NULL,'',20,'',1,'','CA',''),(4,3,'2018-04-04 12:23:16',8,NULL,NULL,'',20,'\0',NULL,'\0','',''),(5,4,'2018-05-15 13:24:52',381,NULL,NULL,'',5,'',15,'\0','',''),(6,4,'2018-05-15 06:29:16',381,NULL,NULL,'',5,'',15,'\0','',''),(7,4,'2018-05-15 06:54:41',381,NULL,NULL,'',5,'',10,'\0','',''),(8,4,'2018-05-15 07:00:39',381,NULL,NULL,'',5,'',15,'\0','',''),(9,4,'2018-05-15 07:09:30',381,NULL,NULL,'',5,'',9,'\0','',''),(11,6,'2018-05-24 03:44:20',381,NULL,NULL,'',5,'',11,'\0','',''),(12,7,'2018-05-31 02:18:11',5,NULL,NULL,'',20,'',16,'','AL;AZ','Akron;Groveoak;Lake Montezuma'),(13,7,'2018-05-31 02:25:16',5,NULL,NULL,'',10,'',5,'','AK;AL','Abbeville;Adamsville'),(14,9,'2018-05-31 02:35:21',5,NULL,NULL,'\0',NULL,'',10,'\0','',''),(15,11,'2018-05-31 02:48:15',5,NULL,NULL,'\0',NULL,'',12,'\0','',''),(16,12,'2018-06-18 11:39:30',11,NULL,NULL,'',11,'',31,'','AL;AR','Mc Williams'),(17,13,'2018-06-18 11:42:30',11,NULL,NULL,'',1,'',31,'','AK;AL','Adamsville;Mc Williams'),(19,17,'2018-06-20 02:15:24',9,NULL,NULL,'',11111,'',1,'','AK;AL;AZ;CA','Adamsville'),(20,17,'2018-06-20 02:16:02',9,NULL,NULL,'',11111,'\0',NULL,'','AK','Alakanuk'),(21,17,'2018-06-20 02:22:22',9,NULL,NULL,'',9999,'',1,'','AK;AL','Alabaster;Alakanuk'),(22,18,'2018-06-20 16:13:44',2,NULL,NULL,'',11111,'\0',NULL,'\0','',''),(24,20,'2018-06-21 11:26:21',9,1,NULL,'',92320,'',30,'','AK;AL;AR','Alakanuk;Alberta;Albertville'),(25,20,'2018-06-21 11:30:28',9,NULL,NULL,'',11111,'\0',NULL,'\0','',''),(26,20,'2018-06-21 11:30:40',9,NULL,NULL,'',12312,'\0',NULL,'\0','',''),(30,20,'2018-06-25 04:07:36',1,1,NULL,'',21313,'\0',NULL,'','AK;AL',''),(33,26,'2018-06-25 04:11:53',1,1,NULL,'',1,'',15,'','AK;AL;AR;AZ',''),(34,27,'2018-06-25 04:12:22',1,1,NULL,'',12321,'',1,'','AK;AL;AR',''),(35,28,'2018-06-25 04:12:22',1,1,NULL,'',12321,'',1,'','AK;AL;AR',''),(36,27,'2018-06-25 04:12:38',1,NULL,NULL,'',12321,'',16,'','AK;AL;AR;AZ',''),(37,27,'2018-06-25 04:12:38',1,NULL,NULL,'',12321,'',16,'','AK;AL;AR;AZ',''),(38,29,'2018-07-10 07:23:34',6,1,NULL,'\0',NULL,'\0',NULL,'','AZ','');
/*!40000 ALTER TABLE `client_services_config_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-23 17:43:51
