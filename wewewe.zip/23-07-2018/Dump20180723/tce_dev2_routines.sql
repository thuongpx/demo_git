-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `closed_order_by_customer_chart_v`
--

DROP TABLE IF EXISTS `closed_order_by_customer_chart_v`;
/*!50001 DROP VIEW IF EXISTS `closed_order_by_customer_chart_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `closed_order_by_customer_chart_v` AS SELECT 
 1 AS `OrderId`,
 1 AS `CustomerId`,
 1 AS `Name`,
 1 AS `ClosedDate`,
 1 AS `OrderMonth`,
 1 AS `OrderDate`,
 1 AS `ProgressDescription`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `economic_drilldown_v`
--

DROP TABLE IF EXISTS `economic_drilldown_v`;
/*!50001 DROP VIEW IF EXISTS `economic_drilldown_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `economic_drilldown_v` AS SELECT 
 1 AS `orderDate`,
 1 AS `orderId`,
 1 AS `originalAmount`,
 1 AS `feeAmount`,
 1 AS `agent`,
 1 AS `approved`,
 1 AS `DateStamp`,
 1 AS `AgentId`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `open_order_by_customer_and_status_v`
--

DROP TABLE IF EXISTS `open_order_by_customer_and_status_v`;
/*!50001 DROP VIEW IF EXISTS `open_order_by_customer_and_status_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `open_order_by_customer_and_status_v` AS SELECT 
 1 AS `CustomerId`,
 1 AS `CustomerName`,
 1 AS `OrderStatus`,
 1 AS `BrokerId`,
 1 AS `OrderDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `daily_counter_report_chart_v`
--

DROP TABLE IF EXISTS `daily_counter_report_chart_v`;
/*!50001 DROP VIEW IF EXISTS `daily_counter_report_chart_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `daily_counter_report_chart_v` AS SELECT 
 1 AS `Count`,
 1 AS `Date`,
 1 AS `IsAutoAssign`,
 1 AS `OrderStatus`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `economic_chart_v`
--

DROP TABLE IF EXISTS `economic_chart_v`;
/*!50001 DROP VIEW IF EXISTS `economic_chart_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `economic_chart_v` AS SELECT 
 1 AS `ReasonCode`,
 1 AS `ReasonDescription`,
 1 AS `DateStamp`,
 1 AS `agentId`,
 1 AS `Approved`,
 1 AS `Rejected`,
 1 AS `Pending`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `open_order_trend_drilldown_v`
--

DROP TABLE IF EXISTS `open_order_trend_drilldown_v`;
/*!50001 DROP VIEW IF EXISTS `open_order_trend_drilldown_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `open_order_trend_drilldown_v` AS SELECT 
 1 AS `BrokerId`,
 1 AS `CustomerId`,
 1 AS `OpenOrder`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `milestones_chart_v`
--

DROP TABLE IF EXISTS `milestones_chart_v`;
/*!50001 DROP VIEW IF EXISTS `milestones_chart_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `milestones_chart_v` AS SELECT 
 1 AS `TotalClosedOrders`,
 1 AS `Name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `assigned_order_by_agents_chart_v`
--

DROP TABLE IF EXISTS `assigned_order_by_agents_chart_v`;
/*!50001 DROP VIEW IF EXISTS `assigned_order_by_agents_chart_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `assigned_order_by_agents_chart_v` AS SELECT 
 1 AS `AgentId`,
 1 AS `OrderId`,
 1 AS `Agents`,
 1 AS `OrderType`,
 1 AS `OrderMonth`,
 1 AS `OrderDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `daily_counter_report_drilldown_v`
--

DROP TABLE IF EXISTS `daily_counter_report_drilldown_v`;
/*!50001 DROP VIEW IF EXISTS `daily_counter_report_drilldown_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `daily_counter_report_drilldown_v` AS SELECT 
 1 AS `TotalOrder`,
 1 AS `OrderStatus`,
 1 AS `Date`,
 1 AS `FilledDate`,
 1 AS `RepAssignDate`,
 1 AS `OrderDate`,
 1 AS `IsAutoAssign`,
 1 AS `SumOfAssignTime`,
 1 AS `AverageOfAssignTime`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `assigned_order_by_scheduler_drilldown_v`
--

DROP TABLE IF EXISTS `assigned_order_by_scheduler_drilldown_v`;
/*!50001 DROP VIEW IF EXISTS `assigned_order_by_scheduler_drilldown_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `assigned_order_by_scheduler_drilldown_v` AS SELECT 
 1 AS `OrderDate`,
 1 AS `AgentId`,
 1 AS `Agents`,
 1 AS `OrderNumber`,
 1 AS `BorrowerLast`,
 1 AS `OrderType`,
 1 AS `Status`,
 1 AS `VendorFee`,
 1 AS `ClientFee`,
 1 AS `Scheduler`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `open_order_comparison_by_business_day_chart_v`
--

DROP TABLE IF EXISTS `open_order_comparison_by_business_day_chart_v`;
/*!50001 DROP VIEW IF EXISTS `open_order_comparison_by_business_day_chart_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `open_order_comparison_by_business_day_chart_v` AS SELECT 
 1 AS `OrderId`,
 1 AS `OrderDate`,
 1 AS `OrderMonth`,
 1 AS `OrderDay`,
 1 AS `OrderYear`,
 1 AS `OrderType`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `open_order_chart_v`
--

DROP TABLE IF EXISTS `open_order_chart_v`;
/*!50001 DROP VIEW IF EXISTS `open_order_chart_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `open_order_chart_v` AS SELECT 
 1 AS `Count`,
 1 AS `OrderType`,
 1 AS `OrderStatus`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `milestones_drilldown_v`
--

DROP TABLE IF EXISTS `milestones_drilldown_v`;
/*!50001 DROP VIEW IF EXISTS `milestones_drilldown_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `milestones_drilldown_v` AS SELECT 
 1 AS `Company`,
 1 AS `TotalOrders`,
 1 AS `TotalClosedOrders`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `all_month_in_year_v`
--

DROP TABLE IF EXISTS `all_month_in_year_v`;
/*!50001 DROP VIEW IF EXISTS `all_month_in_year_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `all_month_in_year_v` AS SELECT 
 1 AS `Month`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `open_order_by_customer_and_status_drilldown_v`
--

DROP TABLE IF EXISTS `open_order_by_customer_and_status_drilldown_v`;
/*!50001 DROP VIEW IF EXISTS `open_order_by_customer_and_status_drilldown_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `open_order_by_customer_and_status_drilldown_v` AS SELECT 
 1 AS `Count`,
 1 AS `CustomerName`,
 1 AS `OrderStatus`,
 1 AS `BrokerId`,
 1 AS `OrderDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `open_order_drilldown_v`
--

DROP TABLE IF EXISTS `open_order_drilldown_v`;
/*!50001 DROP VIEW IF EXISTS `open_order_drilldown_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `open_order_drilldown_v` AS SELECT 
 1 AS `OrderDate`,
 1 AS `OrderType`,
 1 AS `OpenDate`,
 1 AS `OrderNumber`,
 1 AS `ClosingDate`,
 1 AS `TitleCompany`,
 1 AS `AgentFirstName`,
 1 AS `AgentLastName`,
 1 AS `BorrowerLast`,
 1 AS `LoanType`,
 1 AS `OrderStatus`,
 1 AS `VendorFee`,
 1 AS `ClientFee`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `open_order_trend_chart_v`
--

DROP TABLE IF EXISTS `open_order_trend_chart_v`;
/*!50001 DROP VIEW IF EXISTS `open_order_trend_chart_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `open_order_trend_chart_v` AS SELECT 
 1 AS `customerId`,
 1 AS `orderId`,
 1 AS `customerName`,
 1 AS `OrderMonth`,
 1 AS `OrderDay`,
 1 AS `OrderDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `open_order_by_customer_v`
--

DROP TABLE IF EXISTS `open_order_by_customer_v`;
/*!50001 DROP VIEW IF EXISTS `open_order_by_customer_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `open_order_by_customer_v` AS SELECT 
 1 AS `BrokerId`,
 1 AS `CustomerId`,
 1 AS `Name`,
 1 AS `OrderId`,
 1 AS `OrderDate`,
 1 AS `OrderMonth`,
 1 AS `OrderDay`,
 1 AS `OrderStatus`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `closed_order_by_customer_drilldown_v`
--

DROP TABLE IF EXISTS `closed_order_by_customer_drilldown_v`;
/*!50001 DROP VIEW IF EXISTS `closed_order_by_customer_drilldown_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `closed_order_by_customer_drilldown_v` AS SELECT 
 1 AS `OrderId`,
 1 AS `CustomerId`,
 1 AS `Name`,
 1 AS `OrderDate`,
 1 AS `ClosedDate`,
 1 AS `OrderMonth`,
 1 AS `OrderDay`,
 1 AS `OrderStatus`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `closed_order_by_customer_chart_v`
--

/*!50001 DROP VIEW IF EXISTS `closed_order_by_customer_chart_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `closed_order_by_customer_chart_v` AS select `o`.`OrderId` AS `OrderId`,`o`.`CustomerId` AS `CustomerId`,`c`.`Name` AS `Name`,`o`.`ClosedDate` AS `ClosedDate`,month(`o`.`ClosedDate`) AS `OrderMonth`,`o`.`ClosedDate` AS `OrderDate`,`p`.`ProgressDescription` AS `ProgressDescription` from ((`order` `o` join `customers` `c` on((`c`.`CustomerId` = `o`.`CustomerId`))) join `progress` `p` on((`p`.`ProgressId` = `o`.`ProgressId`))) where ((`o`.`CustomerId` = `c`.`CustomerId`) and (`o`.`ClosedDate` is not null) and (`p`.`ProgressDescription` like 'Closing Completed')) group by `o`.`OrderId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `economic_drilldown_v`
--

/*!50001 DROP VIEW IF EXISTS `economic_drilldown_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `economic_drilldown_v` AS select `o`.`OrderDate` AS `orderDate`,`o`.`OrderId` AS `orderId`,`ofa`.`OriginalAmount` AS `originalAmount`,`ofa`.`FeeAmount` AS `feeAmount`,concat(`a`.`FirstName`,' ',`a`.`LastName`) AS `agent`,`ofa`.`FeeApproved` AS `approved`,`ofa`.`DateStamp` AS `DateStamp`,`o`.`AgentId` AS `AgentId` from (((`order_fee_approve` `ofa` join `order_fee_approve_reason` `ofar` on((`ofar`.`ReasonCode` = `ofa`.`ReasonCode`))) join `order` `o` on((`o`.`OrderId` = `ofa`.`OrderId`))) join `agent` `a` on((`a`.`AgentId` = `o`.`AgentId`))) order by `ofar`.`ReasonDescription` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `open_order_by_customer_and_status_v`
--

/*!50001 DROP VIEW IF EXISTS `open_order_by_customer_and_status_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `open_order_by_customer_and_status_v` AS select `ct`.`CustomerId` AS `CustomerId`,`ct`.`Name` AS `CustomerName`,`p`.`ProgressDescription` AS `OrderStatus`,`o`.`BrokerId` AS `BrokerId`,date_format(`GETORDERDATEBYORDERSTATUS`(`p`.`ProgressDescription`,`o`.`OrderId`),'%Y-%m-%d') AS `OrderDate` from (((`order` `o` join `progress` `p` on((`o`.`ProgressId` = `p`.`ProgressId`))) join `broker` `b` on((`o`.`BrokerId` = `b`.`BrokerID`))) join `customers` `ct` on((`o`.`CustomerId` = `ct`.`CustomerId`))) order by `o`.`OrderDate` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `daily_counter_report_chart_v`
--

/*!50001 DROP VIEW IF EXISTS `daily_counter_report_chart_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_counter_report_chart_v` AS select count(0) AS `Count`,date_format(`o`.`OrderDate`,'%Y-%m-%d') AS `Date`,`o`.`IsAutoAssign` AS `IsAutoAssign`,`p`.`ProgressDescription` AS `OrderStatus` from ((`order` `o` join `loan_type` `lt`) join `progress` `p`) where ((`o`.`LoanType` = `lt`.`LoanTypeId`) and (`o`.`ProgressId` = `p`.`ProgressId`)) group by `Date`,`o`.`RepId`,`OrderStatus` order by `o`.`OrderDate` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `economic_chart_v`
--

/*!50001 DROP VIEW IF EXISTS `economic_chart_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `economic_chart_v` AS select `ofa`.`ReasonCode` AS `ReasonCode`,`ofar`.`ReasonDescription` AS `ReasonDescription`,`ofa`.`DateStamp` AS `DateStamp`,`o`.`AgentId` AS `agentId`,if((`ofa`.`FeeApproved` = 'Approved'),1,0) AS `Approved`,if((`ofa`.`FeeApproved` = 'Rejected'),1,0) AS `Rejected`,if((`ofa`.`FeeApproved` = 'Pending'),1,0) AS `Pending` from ((`order_fee_approve` `ofa` join `order_fee_approve_reason` `ofar` on((`ofar`.`ReasonCode` = `ofa`.`ReasonCode`))) join `order` `o` on((`o`.`OrderId` = `ofa`.`OrderId`))) order by `ofar`.`ReasonDescription` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `open_order_trend_drilldown_v`
--

/*!50001 DROP VIEW IF EXISTS `open_order_trend_drilldown_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `open_order_trend_drilldown_v` AS select `c`.`BrokerId` AS `BrokerId`,`c`.`CustomerId` AS `CustomerId`,`COUNTORDERSTATUSBYCUSTOMER`(`c`.`CustomerId`,'') AS `OpenOrder` from `customers` `c` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `milestones_chart_v`
--

/*!50001 DROP VIEW IF EXISTS `milestones_chart_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `milestones_chart_v` AS select count(0) AS `TotalClosedOrders`,`c`.`Name` AS `Name` from (((`order` `o` left join `progress` `p` on((`p`.`ProgressId` = `o`.`ProgressId`))) join `agent` `a` on((`o`.`AgentId` = `a`.`AgentId`))) join `customers` `c` on((`c`.`CustomerId` = `o`.`CustomerId`))) where ((`p`.`ProgressDescription` = 'Closing Completed') and (year(`o`.`OrderDate`) >= (year(curdate()) - 3))) group by `c`.`CustomerId` order by `TotalClosedOrders` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `assigned_order_by_agents_chart_v`
--

/*!50001 DROP VIEW IF EXISTS `assigned_order_by_agents_chart_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `assigned_order_by_agents_chart_v` AS select `a`.`AgentId` AS `AgentId`,`o`.`OrderId` AS `OrderId`,concat(`a`.`FirstName`,' ',`a`.`LastName`) AS `Agents`,`lt`.`LoanType` AS `OrderType`,month(`o`.`OrderDate`) AS `OrderMonth`,`o`.`OrderDate` AS `OrderDate` from (((`order` `o` join `loan_type` `lt` on((`lt`.`LoanTypeId` = `o`.`LoanType`))) join `agent` `a` on((`a`.`AgentId` = `o`.`AgentId`))) join `employees` `e` on((`e`.`RepId` = `o`.`RepId`))) where (`o`.`RepAssignDate` is not null) order by month(`o`.`OrderDate`),`a`.`AgentId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `daily_counter_report_drilldown_v`
--

/*!50001 DROP VIEW IF EXISTS `daily_counter_report_drilldown_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_counter_report_drilldown_v` AS select count(0) AS `TotalOrder`,`p`.`ProgressDescription` AS `OrderStatus`,date_format(`o`.`OrderDate`,'%Y-%m-%d') AS `Date`,`o`.`FilledDate` AS `FilledDate`,`o`.`RepAssignDate` AS `RepAssignDate`,`o`.`OrderDate` AS `OrderDate`,`o`.`IsAutoAssign` AS `IsAutoAssign`,sum(((timestampdiff(SECOND,`o`.`OrderDate`,`o`.`FilledDate`) / 60) / 60)) AS `SumOfAssignTime`,(((timestampdiff(SECOND,`o`.`OrderDate`,`o`.`FilledDate`) / 60) / 60) / count(0)) AS `AverageOfAssignTime` from ((((`order` `o` join `loan_type` `lt`) join `progress` `p`) left join `broker` `b` on((`o`.`BrokerId` = `b`.`BrokerID`))) left join `agent` `a` on((`o`.`AgentId` = `a`.`AgentId`))) where ((`o`.`LoanType` = `lt`.`LoanTypeId`) and (`o`.`ProgressId` = `p`.`ProgressId`)) group by `OrderStatus`,`Date`,`o`.`RepId`,`o`.`FilledDate`,`o`.`OrderDate` order by `o`.`OrderDate` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `assigned_order_by_scheduler_drilldown_v`
--

/*!50001 DROP VIEW IF EXISTS `assigned_order_by_scheduler_drilldown_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `assigned_order_by_scheduler_drilldown_v` AS select `o`.`OrderDate` AS `OrderDate`,`a`.`AgentId` AS `AgentId`,concat(`a`.`FirstName`,' ',`a`.`LastName`) AS `Agents`,`o`.`OrderId` AS `OrderNumber`,`o`.`LastName` AS `BorrowerLast`,`lt`.`LoanType` AS `OrderType`,`p`.`ProgressDescription` AS `Status`,`o`.`SignerFee` AS `VendorFee`,`o`.`BrokerFee` AS `ClientFee`,concat(`e`.`FirstName`,' ',`e`.`LastName`) AS `Scheduler` from ((((`order` `o` join `loan_type` `lt` on((`lt`.`LoanTypeId` = `o`.`LoanType`))) join `agent` `a` on((`a`.`AgentId` = `o`.`AgentId`))) join `progress` `p` on((`p`.`ProgressId` = `o`.`ProgressId`))) join `employees` `e` on((`e`.`RepId` = `o`.`RepId`))) where ((`o`.`IsSelfService` = 0) and (`o`.`RepAssignDate` is not null)) order by `o`.`OrderDate`,concat(`e`.`FirstName`,' ',`e`.`LastName`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `open_order_comparison_by_business_day_chart_v`
--

/*!50001 DROP VIEW IF EXISTS `open_order_comparison_by_business_day_chart_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `open_order_comparison_by_business_day_chart_v` AS select `o`.`OrderId` AS `OrderId`,`o`.`OrderDate` AS `OrderDate`,month(`o`.`OrderDate`) AS `OrderMonth`,dayofmonth(`o`.`OrderDate`) AS `OrderDay`,year(`o`.`OrderDate`) AS `OrderYear`,`lt`.`LoanType` AS `OrderType` from (`order` `o` join `loan_type` `lt` on((`o`.`LoanType` = `lt`.`LoanTypeId`))) order by `o`.`OrderDate` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `open_order_chart_v`
--

/*!50001 DROP VIEW IF EXISTS `open_order_chart_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `open_order_chart_v` AS select count(0) AS `Count`,`lt`.`LoanType` AS `OrderType`,`p`.`ProgressDescription` AS `OrderStatus` from ((`order` `o` join `loan_type` `lt`) join `progress` `p`) where ((`o`.`LoanType` = `lt`.`LoanTypeId`) and (`o`.`ProgressId` = `p`.`ProgressId`)) group by `OrderType`,`OrderStatus` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `milestones_drilldown_v`
--

/*!50001 DROP VIEW IF EXISTS `milestones_drilldown_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `milestones_drilldown_v` AS select `c`.`Name` AS `Company`,count(0) AS `TotalOrders`,count((case when (`p`.`ProgressDescription` = 'Closing Completed') then `o`.`OrderId` else NULL end)) AS `TotalClosedOrders` from (((`order` `o` left join `progress` `p` on((`p`.`ProgressId` = `o`.`ProgressId`))) join `agent` `a` on((`o`.`AgentId` = `a`.`AgentId`))) join `customers` `c` on((`c`.`CustomerId` = `o`.`CustomerId`))) where ((`o`.`AgentId` = `a`.`AgentId`) and (year(`o`.`OrderDate`) >= (year(curdate()) - 3))) group by `c`.`CustomerId` having (count((case when (`p`.`ProgressDescription` = 'Closing Completed') then `o`.`OrderId` else NULL end)) > 0) order by `TotalClosedOrders` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `all_month_in_year_v`
--

/*!50001 DROP VIEW IF EXISTS `all_month_in_year_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `all_month_in_year_v` AS select 1 AS `Month` union select 2 AS `Month` union select 3 AS `Month` union select 4 AS `Month` union select 5 AS `Month` union select 6 AS `Month` union select 7 AS `Month` union select 8 AS `Month` union select 9 AS `Month` union select 10 AS `Month` union select 11 AS `Month` union select 12 AS `Month` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `open_order_by_customer_and_status_drilldown_v`
--

/*!50001 DROP VIEW IF EXISTS `open_order_by_customer_and_status_drilldown_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `open_order_by_customer_and_status_drilldown_v` AS select count(0) AS `Count`,`ct`.`Name` AS `CustomerName`,`p`.`ProgressDescription` AS `OrderStatus`,`o`.`BrokerId` AS `BrokerId`,date_format(`GETORDERDATEBYORDERSTATUS`(`p`.`ProgressDescription`,`o`.`OrderId`),'%Y-%m-%d') AS `OrderDate` from (((`order` `o` join `progress` `p` on((`o`.`ProgressId` = `p`.`ProgressId`))) join `broker` `b` on((`o`.`BrokerId` = `b`.`BrokerID`))) join `customers` `ct` on(((`o`.`CustomerId` = `ct`.`CustomerId`) and (`o`.`BrokerId` = `ct`.`BrokerId`)))) group by `p`.`ProgressDescription`,`o`.`OrderDate` order by `o`.`OrderDate` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `open_order_drilldown_v`
--

/*!50001 DROP VIEW IF EXISTS `open_order_drilldown_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `open_order_drilldown_v` AS select `o`.`OrderDate` AS `OrderDate`,`lt`.`LoanType` AS `OrderType`,`o`.`OrderDate` AS `OpenDate`,`o`.`OrderId` AS `OrderNumber`,`o`.`ClosedDate` AS `ClosingDate`,`b`.`Company` AS `TitleCompany`,`a`.`FirstName` AS `AgentFirstName`,`a`.`LastName` AS `AgentLastName`,`o`.`LastName` AS `BorrowerLast`,`lt`.`LoanType` AS `LoanType`,`p`.`ProgressDescription` AS `OrderStatus`,`o`.`SignerFee` AS `VendorFee`,`o`.`BrokerFee` AS `ClientFee` from ((((`order` `o` join `loan_type` `lt`) join `progress` `p`) left join `broker` `b` on((`o`.`BrokerId` = `b`.`BrokerID`))) left join `agent` `a` on((`o`.`AgentId` = `a`.`AgentId`))) where ((`o`.`LoanType` = `lt`.`LoanTypeId`) and (`o`.`ProgressId` = `p`.`ProgressId`)) order by `o`.`OrderDate` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `open_order_trend_chart_v`
--

/*!50001 DROP VIEW IF EXISTS `open_order_trend_chart_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `open_order_trend_chart_v` AS select `ct`.`CustomerId` AS `customerId`,`o`.`OrderId` AS `orderId`,`ct`.`Name` AS `customerName`,month(`o`.`OrderDate`) AS `OrderMonth`,dayofmonth(`o`.`OrderDate`) AS `OrderDay`,`o`.`OrderDate` AS `OrderDate` from (`customers` `ct` join `order` `o` on((`ct`.`CustomerId` = `o`.`CustomerId`))) where (`o`.`OrderDate` is not null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `open_order_by_customer_v`
--

/*!50001 DROP VIEW IF EXISTS `open_order_by_customer_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `open_order_by_customer_v` AS select `c`.`BrokerId` AS `BrokerId`,`c`.`CustomerId` AS `CustomerId`,`c`.`Name` AS `Name`,`o`.`OrderId` AS `OrderId`,`o`.`OrderDate` AS `OrderDate`,month(`o`.`OrderDate`) AS `OrderMonth`,dayofmonth(`o`.`OrderDate`) AS `OrderDay`,`p`.`ProgressDescription` AS `OrderStatus` from ((`customers` `c` join `order` `o` on((`c`.`CustomerId` = `o`.`CustomerId`))) join `progress` `p` on((`o`.`ProgressId` = `p`.`ProgressId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `closed_order_by_customer_drilldown_v`
--

/*!50001 DROP VIEW IF EXISTS `closed_order_by_customer_drilldown_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tce`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `closed_order_by_customer_drilldown_v` AS select `o`.`OrderId` AS `OrderId`,`o`.`CustomerId` AS `CustomerId`,`c`.`Name` AS `Name`,`o`.`ClosedDate` AS `OrderDate`,`o`.`ClosedDate` AS `ClosedDate`,month(`o`.`ClosedDate`) AS `OrderMonth`,dayofmonth(`o`.`ClosedDate`) AS `OrderDay`,`p`.`ProgressDescription` AS `OrderStatus` from ((`order` `o` join `customers` `c` on((`c`.`CustomerId` = `o`.`CustomerId`))) join `progress` `p` on((`p`.`ProgressId` = `o`.`ProgressId`))) where ((`o`.`ClosedDate` is not null) or (`p`.`ProgressDescription` like 'Canceled')) group by `o`.`OrderId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'tce_dev2'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `event_autoAssignVendor` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`tce`@`%`*/ /*!50106 EVENT `event_autoAssignVendor` ON SCHEDULE EVERY 10 SECOND STARTS '2018-05-09 12:57:01' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
  
	DECLARE autoDateStamp DATETIME;
	DECLARE autoProgress VARCHAR(1);
    DECLARE orderId INT;
    DECLARE isFinished INTEGER DEFAULT 0;
  
	DECLARE myCursor CURSOR FOR SELECT ord.autoDateStamp,
									   ord.autoProgress,
                                       ord.orderId
								FROM `order` ord WHERE ord.autoProgress IN ('P','E','F') AND (ord.inActive = 0 OR ord.inActive IS NULL);
    
    DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET isFinished = 1;
    
    Open myCursor;
    
	autoAssignOrders: LOOP
		FETCH myCursor INTO autoDateStamp, autoProgress, orderId;
        
        IF isFinished = 1 THEN LEAVE autoAssignOrders;
		END IF;
        
        IF autoProgress = 'P'
			THEN 
				-- find and send offer to elite vendor
				CALL autoVendorOffer(orderId,true);
		END IF;
		
        IF (autoProgress = 'F' OR (autoProgress = 'E' AND DATE_ADD(autoDateStamp, INTERVAL 5 MINUTE) < UTC_TIMESTAMP()))
			THEN 
				-- find and send offer to non-elite vendor
				CALL autoVendorOffer(orderId,false);
		END IF;
     
	END LOOP autoAssignOrders;
    CLOSE myCursor;
    
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `event_orderStatusHoldToCancelled` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`tce`@`%`*/ /*!50106 EVENT `event_orderStatusHoldToCancelled` ON SCHEDULE EVERY 10 SECOND STARTS '2018-07-04 10:25:44' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN

    DECLARE holdingDate DATETIME;
    DECLARE orderId INT;
    DECLARE usersId INT;
	DECLARE isFinished INTEGER DEFAULT 0;
    DECLARE myCursor CURSOR FOR SELECT ord.holdingDate,
                                       ord.orderId
								FROM `order` ord WHERE ord.progressId = 10
                                AND (ord.inActive = 0 OR ord.inActive IS NULL);
                                
    DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET isFinished = 1;
    
    Open myCursor;
    
	holdToCancelLoop: LOOP
		FETCH myCursor INTO holdingDate, orderId;
        
        IF isFinished = 1 THEN LEAVE holdToCancelLoop;
		END IF;
        
        SET usersId = (SELECT u.usersId FROM `order` ord 
        JOIN users u ON u.mappingUserId = ord.BrokerId
        JOIN user_roles ur on ur.usersId = u.usersId
        JOIN roles r on r.roleId = ur.roleId
        where ord.orderId = orderId AND r.roleName = 'Client');
        
        IF (UTC_TIMESTAMP() > DATE_ADD(holdingDate, INTERVAL 5 DAY)) 
			THEN UPDATE `order` ord SET ord.progressId = 11 WHERE ord.orderId = orderId;
				 INSERT INTO order_progress_log(orderId,activity,datelog,usersId,progressType) 
							VALUES(orderId,'Pushing this order to Canceled status because of being in ‘Hold’ more than 5 days.',UTC_TIMESTAMP(),usersId,1);
		END IF;
     
	END LOOP holdToCancelLoop;
    CLOSE myCursor;
    
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `event_processHeldOrder` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`tce`@`%`*/ /*!50106 EVENT `event_processHeldOrder` ON SCHEDULE EVERY 1 DAY STARTS '2018-05-11 14:14:09' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    /*
		Once order’s status is changed to “Hold”, system will keep order in this status for 5 days for editting. 
        In case of no editting, system pushes the order to ‘Canceled’ status after the 5th day with comment “Pushing this order to Canceled status because of being in ‘Hold’ more than 5 days.”
    */
    
    UPDATE `order` as o
		SET 
			ProgressId = 11
            , CancellationReason = 'Pushing this order to Canceled status because of being in ‘Hold’ more than 5 days.'
	WHERE ProgressId = 10 
        AND HoldingDate IS NOT NULL
        AND DATE_ADD(HoldingDate, INTERVAL 5 DAY) >= utc_timestamp();
    
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `event_serviceConfigurationAutoApproval` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`tce`@`%`*/ /*!50106 EVENT `event_serviceConfigurationAutoApproval` ON SCHEDULE EVERY 10 SECOND STARTS '2018-07-04 09:01:47' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN

    DECLARE clientId INT;
    DECLARE createdDate DATETIME;
    DECLARE configId INT;
	DECLARE isFinished INTEGER DEFAULT 0;
    DECLARE myCursor CURSOR FOR SELECT csc.configId, csc.clientId, csc.createdDate FROM client_services_config csc 
													WHERE csc.effecttiveDate IS NULL 
													AND csc.`status` = 1;
                                
    DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET isFinished = 1;
    
    Open myCursor;
    
	autoApprovalLoop: LOOP
		FETCH myCursor INTO configId, clientId, createdDate;
        
        IF isFinished = 1 THEN LEAVE autoApprovalLoop;
		END IF;
        
        IF (UTC_TIMESTAMP() >  DATE_ADD(createdDate, INTERVAL 30 DAY))
			THEN UPDATE client_services_config csc SET csc.effecttiveDate = UTC_TIMESTAMP(),csc.`status` = 2, approvedBy = -1
													WHERE csc.configId = configId;
				 UPDATE client_services_config csc SET csc.`status` = 3 WHERE csc.configId <> configId AND csc.clientId = clientId;
		END IF;
     
	END LOOP autoApprovalLoop;
    CLOSE myCursor;
    
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `event_signerQualified` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`tce`@`%`*/ /*!50106 EVENT `event_signerQualified` ON SCHEDULE EVERY 10 SECOND STARTS '2018-05-09 12:56:53' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
  UPDATE signer sn SET sn.qualified = 'N';
 
  UPDATE signer sn SET sn.qualified = 'D' WHERE 
	 (SELECT COUNT(docId) FROM signer_docs
			WHERE docTypeId = 1 AND expireDate > UTC_TIMESTAMP() AND signerId = sn.signerId  AND approved = 1) > 0 AND
	 (SELECT COUNT(docId) FROM signer_docs 
			WHERE docTypeId = 6 AND signerId = sn.signerId  AND approved = 1) > 0 AND
	 (SELECT COUNT(docId) FROM signer_docs 
			WHERE docTypeId = 7 AND expireDate > UTC_TIMESTAMP() AND signerId = sn.signerId  AND approved = 1) > 0 AND
	 (SELECT COUNT(docId) FROM signer_docs
			WHERE docTypeId = 8 AND expireDate > UTC_TIMESTAMP() AND signerId = sn.signerId  AND approved = 1) > 0;
	 
  UPDATE signer sn SET sn.qualified = 'Q' WHERE
		 (SELECT COUNT(docId) FROM signer_docs
			WHERE docTypeId = 1 AND expireDate > UTC_TIMESTAMP() AND signerId = sn.signerId  AND approved = 1) > 0 AND
	 (SELECT COUNT(docId) FROM signer_docs 
			WHERE docTypeId = 6 AND signerId = sn.signerId  AND approved = 1) > 0 AND
	 (SELECT COUNT(docId) FROM signer_docs 
			WHERE docTypeId = 7 AND expireDate > UTC_TIMESTAMP() AND signerId = sn.signerId  AND approved = 1) > 0 AND
	 (SELECT COUNT(docId) FROM signer_docs
			WHERE docTypeId = 8 AND expireDate > UTC_TIMESTAMP() AND signerId = sn.signerId  AND approved = 1) > 0 AND
	 (SELECT COUNT(resultId) FROM vendor_test_result str
			WHERE signerId=sn.signerId AND passed = 'Y') = (SELECT COUNT(testId) FROM test_info WHERE active = 1);
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `event_vendorAppointmentPassed` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`tce`@`%`*/ /*!50106 EVENT `event_vendorAppointmentPassed` ON SCHEDULE EVERY 10 SECOND STARTS '2018-07-03 11:03:57' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN

	DECLARE aptDateTimeUtc DATETIME;
    DECLARE aptDateTime DATETIME;
    DECLARE orderId INT;
    DECLARE aptUtc INT;
	DECLARE isFinished INTEGER DEFAULT 0;
    DECLARE myCursor CURSOR FOR SELECT ord.aptDateTime,
									   ord.aptUtc,
                                       ord.orderId
								FROM `order` ord WHERE ord.progressId in (2,4,5) AND (ord.inActive = 0 OR ord.inActive IS NULL);
                                
    DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET isFinished = 1;
    
    Open myCursor;
    
	vendorAppointmentPassedLoop: LOOP
		FETCH myCursor INTO aptDateTime, aptUtc, orderId;
        
        IF isFinished = 1 THEN LEAVE vendorAppointmentPassedLoop;
		END IF;
        
        SET aptDateTimeUtc = DATE_SUB(aptDateTime, INTERVAL aptUtc HOUR);
        
        IF (aptDateTimeUtc IS NOT NULL AND  aptDateTimeUtc < UTC_TIMESTAMP())
			THEN UPDATE `order` ord SET ord.IsSentVendorAppointmentPassed = 1 WHERE ord.orderId = orderId AND ord.IsSentVendorAppointmentPassed IS NULL;
		END IF;
     
	END LOOP vendorAppointmentPassedLoop;
    CLOSE myCursor;
    
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `event_vendorNoDocumentUploaded` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`tce`@`%`*/ /*!50106 EVENT `event_vendorNoDocumentUploaded` ON SCHEDULE EVERY 10 SECOND STARTS '2018-07-03 11:25:52' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN

	DECLARE aptDateTimeUtc DATETIME;
    DECLARE aptDateTime DATETIME;
    DECLARE orderId INT;
    DECLARE aptUtc INT;
	DECLARE isFinished INTEGER DEFAULT 0;
    DECLARE myCursor CURSOR FOR SELECT ord.aptDateTime,
									   ord.aptUtc,
                                       ord.orderId
								FROM `order` ord WHERE ord.progressId in (2,4,5) 
                                AND ((SELECT COUNT(*) FROM order_fee of 
										LEFT JOIN broker_fee bf 
                                        ON bf.FeeId=of.FeeDescripID AND bf.feeDescription ='Scan backs'
                                        WHERE of.orderId=ord.orderId) > 0) 
                                AND (ord.inActive = 0 OR ord.inActive IS NULL);
                                
    DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET isFinished = 1;
    
    Open myCursor;
    
	vendorNoDocumentUploadedLoop: LOOP
		FETCH myCursor INTO aptDateTime, aptUtc, orderId;
        
        IF isFinished = 1 THEN LEAVE vendorNoDocumentUploadedLoop;
		END IF;
        
        SET aptDateTimeUtc = DATE_SUB(aptDateTime, INTERVAL aptUtc HOUR);
        
        IF (aptDateTimeUtc IS NOT NULL AND  aptDateTimeUtc < DATE_ADD(UTC_TIMESTAMP(), INTERVAL 3 HOUR) AND 
        (SELECT COUNT(*) FROM order_docs od WHERE od.orderId= orderId and od.documentType = 2 AND (od.archive IS NULL OR od.archive = 0)) = 0)
			THEN UPDATE `order` ord SET ord.IsSentVendorNoDocumentUploaded = 1 WHERE ord.orderId = orderId AND ord.IsSentVendorNoDocumentUploaded IS NULL;
		END IF;
     
	END LOOP vendorNoDocumentUploadedLoop;
    CLOSE myCursor;
    
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `event_vendorOneYearNotSigning` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`tce`@`%`*/ /*!50106 EVENT `event_vendorOneYearNotSigning` ON SCHEDULE EVERY 10 SECOND STARTS '2018-07-04 16:00:05' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN

	-- oneYearNotSigningStatus:
		-- null: has signing
        -- 1: no signing in one year
        -- 2: no signing in one year and already send mail remind
        -- 3: account be deactived by no action after 5 days
        -- 4: account be deactived by no action after 5 days and already send mail deactivate
    DECLARE oneYearNotSigningStatus INT;
    DECLARE oneYearNotSigningTimeStamp  DATETIME;
    DECLARE signerId INT;
    DECLARE usersId INT;
    DECLARE dateCreated DATETIME;
	DECLARE isFinished INTEGER DEFAULT 0;
    DECLARE myCursor CURSOR FOR SELECT sn.oneYearNotSigningStatus , sn.signerId, u.usersId, u.dateCreated, sn.oneYearNotSigningTimeStamp 
								FROM signer sn 
                                JOIN users u on u.mappingUserId = sn.signerId
                                JOIN user_roles ur on ur.usersId = u.usersId
                                JOIN roles r on r.roleId = ur.roleId AND r.roleName = 'Vendor'
                                WHERE (sn.inActive = 0 OR sn.inActive IS NULL);
								 					
    DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET isFinished = 1;
    
    Open myCursor;
    
	oneYearNotSigningLoop: LOOP
		FETCH myCursor INTO oneYearNotSigningStatus, signerId, usersId, dateCreated, oneYearNotSigningTimeStamp;
        
        IF isFinished = 1 THEN LEAVE oneYearNotSigningLoop;
		END IF;
        
        IF (oneYearNotSigningStatus IS NULL )
			THEN UPDATE signer sn SET sn.oneYearNotSigningStatus = 1,oneYearNotSigningTimeStamp=UTC_TIMESTAMP()
										   WHERE sn.signerId = signerId AND 
										   ((SELECT COUNT(*) FROM `order` ord WHERE ord.signerId = sn.signerId 
													AND  DATE_ADD(ord.orderDate, INTERVAL 1 YEAR) >= UTC_TIMESTAMP()) = 0 AND
                                                     (DATE_ADD(dateCreated, INTERVAL 1 YEAR) <= UTC_TIMESTAMP()));
		END IF;
        
        IF (oneYearNotSigningStatus = 2 AND DATE_ADD(oneYearNotSigningTimeStamp,INTERVAL 5 DAY) <= UTC_TIMESTAMP())
			THEN UPDATE signer sn SET sn.oneYearNotSigningStatus=3,inActive = 1 WHERE sn.signerId = signerId;
				 UPDATE users u SET u.inActive = 1 WHERE u.usersId = usersId;
		END IF;
        
        IF (oneYearNotSigningStatus = 2 AND DATE_ADD(oneYearNotSigningTimeStamp,INTERVAL 5 DAY) > UTC_TIMESTAMP() AND
        (SELECT COUNT(*) FROM `order` ord WHERE ord.signerId = signerId 
													AND  DATE_ADD(ord.orderDate, INTERVAL 1 YEAR) >= UTC_TIMESTAMP()) > 0)
			THEN UPDATE signer sn SET sn.oneYearNotSigningStatus = NULL WHERE sn.signerId = signerId;
		END IF;
     
	END LOOP oneYearNotSigningLoop;
    CLOSE myCursor;
    
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'tce_dev2'
--
/*!50003 DROP FUNCTION IF EXISTS `CalculateBusinessHourByOffTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `CalculateBusinessHourByOffTime`(
startTime TIME, 
endTime TIME, 
workStartTime TIME, 
workEndTime TIME, 
offStartTime TIME,
offEndTime TIME
) RETURNS int(11)
BEGIN
    DECLARE totalMinutes INT DEFAULT 0;
    
    IF(offStartTime < workStartTime)
		THEN SET offStartTime = workStartTime;
	END IF;
    
	IF(offStartTime > workEndTime)
		THEN SET offStartTime = workEndTime;
	END IF;
    
	IF(offEndTime > workEndTime)
		THEN SET offEndTime = workEndTime;
	END IF;
    
	IF(offEndTime < workStartTime)
		THEN SET offEndTime = workStartTime;
	END IF;
        
	IF(startTime < workStartTime)
		THEN SET startTime = workStartTime;
	END IF;
    
	IF(startTime > workEndTime)
		THEN SET offStartTime = workEndTime;
	END IF;
    
	IF(endTime > workEndTime)
		THEN SET endTime = workEndTime;
	END IF;
    
	IF(endTime < workStartTime)
		THEN SET offEndTime = workStartTime;
	END IF;
        
	IF(startTime >= offStartTime AND startTime <= offEndTime AND  endTime >= offEndTime)
		THEN SET totalMinutes = FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, offEndTime))/60);
    
	ELSEIF(endTime >= offStartTime AND endTime <= offEndTime AND startTime <= offStartTime)
		THEN SET totalMinutes =  FLOOR(TIME_TO_SEC(TIMEDIFF(offStartTime, startTime))/60);
    
	ELSEIF(startTime <= offStartTime AND endTime >= offEndTime)
		THEN SET totalMinutes =  FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, startTime))/60) - 
										FLOOR(TIME_TO_SEC(TIMEDIFF(offEndTime, offStartTime))/60);
                                        
	ELSE SET totalMinutes =  FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, startTime))/60);
	END IF;
    
    IF(totalMinutes < 0)
		THEN SET totalMinutes = 0;
	END IF;
    
	RETURN totalMinutes;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `CalculateBusinessHourByWorkingTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `CalculateBusinessHourByWorkingTime`(
startDateTime DATETIME, 
endDateTime DATETIME, 
workStartTime TIME,
workEndTime TIME
) RETURNS int(11)
BEGIN
    DECLARE startDate DATE;
    DECLARE endDate DATE;
    DECLARE startTime TIME;
    DECLARE endTime TIME;
    DECLARE dailyWorkingTime INT;

    DECLARE totalMinutes INT;
    
    DECLARE currentDate DATE;
    
    SET startDate= DATE(startDateTime);
    SET endDate = DATE(endDateTime);
    
    SET startTime = TIME(startDateTime);
    SET endTime = TIME(endDateTime);
    
    SET dailyWorkingTime = FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, startTime))/60);
    
    IF(startTime < workStartTime)
		THEN SET startTime  = workStartTime;
    END IF;
    
     IF(startTime > workEndTime)
		THEN SET startTime  = workEndTime;
    END IF;
    
    IF(endTime > workEndTime)
		THEN set endTime = workEndTime;
	END IF;
    
    IF(endTime < workStartTime)
		THEN set endTime = workStartTime;
	END IF;
    
	SET currentDate = startDate;
    SET totalMinutes = 0;
    
    WHILE(currentDate <= endDate)
	DO 
		IF(currentDate <> startDate AND currentDate <> endDate)
			THEN SET totalMinutes = totalMinutes + dailyWorkingTime;
		ELSEIF(currentDate =  startDate AND currentDate <> endDate)
			THEN SET totalMinutes = totalMinutes + FLOOR(TIME_TO_SEC(TIMEDIFF(workEndTime, startTime))/60);
		ELSEIF(currentDate <>  startDate AND currentDate = endDate)
			THEN SET totalMinutes = totalMinutes + FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, workStartTime))/60);
		ELSE
			SET totalMinutes = totalMinutes + FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, startTime))/60);
        END IF;
        
        SET currentDate = DATE_ADD(currentDate,INTERVAL 1 DAY);
        
	END WHILE;
    
    IF(totalMinutes < 0)
		THEN SET totalMinutes = 0;
	END IF;
    
	RETURN totalMinutes;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `CheckOrderStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `CheckOrderStatus`(order_status varchar(50), target_status varchar(50)) RETURNS int(11)
BEGIN
	DECLARE orderStatus varchar(50);
	SET orderStatus = '';

	IF order_status IS NOT NULL AND order_status = 'Open' THEN
    BEGIN
		SET orderStatus = 'Open';
	END;
	ELSEIF order_status IS NOT NULL AND order_status = 'Closing Completed' THEN
    BEGIN
		SET orderStatus = 'Closed';
	END;
	ELSEIF order_status IS NOT NULL AND order_status = 'Canceled' THEN
    BEGIN
		SET orderStatus = 'Canceled';
	END;
	ELSE
    BEGIN
		SET orderStatus = 'Pending';
	END;
    END IF;
    
    IF target_status = orderStatus THEN
    BEGIN
		RETURN 1;    
	END;
    END IF;
    
RETURN 0;    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `CountOrderStatusByCustomer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `COUNTORDERSTATUSBYCUSTOMER`(cusId INT, orderStatus VARCHAR(50)) RETURNS int(11)
BEGIN
	DECLARE orderCount INT;
    
    IF (orderStatus IS NOT NULL AND orderStatus <> '') THEN
		SELECT COUNT(OrderId)
		INTO orderCount
		FROM `order` o
		INNER JOIN `progress` p ON o.ProgressId = p.ProgressId
		WHERE o.`CustomerId` = cusId AND p.ProgressDescription = orderStatus;
	ELSE
		SELECT COUNT(OrderId)
		INTO orderCount
		FROM `order` o		
		WHERE o.`CustomerId` = cusId;
    END IF;
    
    IF orderCount IS NULL THEN
		SET orderCount = 0;
    END IF;
    
	RETURN orderCount;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `DetectSelfService` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `DetectSelfService`(
	brokerId INT, 
    orderCity VARCHAR(50), 
    orderState VARCHAR(2)
) RETURNS bit(1)
BEGIN
	DECLARE isUserCalendar BIT;
    DECLARE isUseGeography BIT;
    DECLARE isUseVolume BIT;
    
    DECLARE isValidUseCalendar BIT;
    DECLARE isValidUseVolume BIT;
    DECLARE isValidGeography BIT;

    DECLARE ordersDirectly BIT;
	DECLARE fullFill BIT;
    
    DECLARE totalOrderToday INT;
        
    SELECT 
		`AssignOrdersDirectly`,
        `TceFullFill`
	INTO ordersDirectly, fullFill
	FROM `broker` b
    WHERE b.`BrokerID` = brokerId;
    
    -- return ordersDirectly;
    
    IF (ordersDirectly IS NULL) THEN
		SET ordersDirectly = false;
    END IF;
    
    IF (fullFill IS NULL) THEN
		SET fullFill = false;
    END IF;
	
    IF (NOT ordersDirectly) THEN
		RETURN false;
	END IF;
    
    IF (ordersDirectly AND NOT fullFill) THEN
		RETURN true;
    END IF;
    
    -- count number of order in current day
    SELECT
		COUNT(OrderId)
	INTO totalOrderToday
	FROM `order` o
    WHERE `BrokerID` = brokerId AND DATE(o.OrderDate) = DATE(UTC_TIMESTAMP());
    
    IF (totalOrderToday IS NULL) THEN
		SET totalOrderToday = 0;
    END IF;
    
    -- check config
	SELECT 
		csc.`UseCalendar`,
        csc.`UseGeography`,
        csc.`UseVolume`,
        DAY(UTC_TIMESTAMP()) <= csc.`CutoffDate`,
        totalOrderToday < csc.`OrderPerDay`,
        csc.`State1` LIKE CONCAT('%', orderState, '%') AND IF(csc.`MSA1` IS NOT NULL, csc.`MSA1` LIKE CONCAT('%', orderCity, '%'), TRUE)
	INTO
		isUserCalendar,
        isUseGeography,
        isUseVolume,
        isValidUseCalendar,
        isValidUseVolume,
        isValidGeography
	FROM `client_services_config` csc WHERE csc.ClientID = brokerId AND csc.`EffecttiveDate` IS NOT NULL
    ORDER BY csc.`EffecttiveDate` DESC LIMIT 0,1;
	
    IF (NOT isUserCalendar AND NOT isUseGeography AND NOT isUseVolume) THEN
		RETURN false;
	END IF;
    
    IF (isUserCalendar AND NOT isValidUseCalendar) THEN
		RETURN false;
	END IF;
    
    IF (isUseGeography AND NOT isValidGeography) THEN
		RETURN false;
    END IF;
    
    IF (isUseVolume AND NOT isValidUseVolume) THEN
		RETURN false;
    END IF;    
    
	RETURN true;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetAlertPosition` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetAlertPosition`(
	role varchar(255),
	userId int,
    alertId int,
    accountId int,
    isSelfService int
) RETURNS int(11)
BEGIN
	DECLARE returnPosition INT;
    SET returnPosition = 0;
    
    IF (role = 'Client' and isSelfService = 1) 
		THEN SELECT x.position INTO returnPosition FROM (SELECT t1.*, @rownum := @rownum + 1 AS position FROM (SELECT
			op.progressLogId,
			op.orderId
            FROM `order` as o
            LEFT JOIN `order_progress_log` as op ON o.OrderId=op.orderId 
            Where op.ProgressType = 1 and op.UsersId <> accountId and o.isSelfService = 1
            AND (o.BrokerId=userId or o.BrokerId in (select Brokerid from `broker` where `broker`.GID = userId)) 
            ORDER BY op.DateLog DESC, op.progressLogId DESC) t1, (SELECT @rownum := 0) r) x where x.progressLogId = alertId;
    ELSE IF (role = 'Client' and isSelfService = 0) 
		THEN SELECT x.position INTO returnPosition FROM (SELECT t1.*, @rownum := @rownum + 1 AS position FROM (SELECT
			op.progressLogId,
			op.orderId
            FROM `order` as o
            LEFT JOIN `order_progress_log` as op ON o.OrderId=op.orderId 
            Where op.ProgressType = 1 and op.UsersId <> accountId and o.isSelfService = 0
            AND (o.BrokerId=userId or o.BrokerId in (select Brokerid from `broker` where `broker`.GID = userId)) 
            ORDER BY op.DateLog DESC, op.progressLogId DESC) t1, (SELECT @rownum := 0) r) x where x.progressLogId = alertId;        
	ELSE IF  (role = 'Vendor') 
		THEN SELECT x.position INTO returnPosition FROM (SELECT t1.*, @rownum := @rownum + 1 AS position FROM (SELECT op.progressLogId,
			op.orderId
            FROM `order` as o
            LEFT JOIN `order_progress_log` as op ON o.OrderId=op.orderId
            Where op.ProgressType = 1 and op.UsersId <> accountId and o.SignerId = userId AND op.DateLog >= o.FilledDate
            order by op.DateLog DESC, op.progressLogId DESC) t1, (SELECT @rownum := 0) r) x where x.progressLogId = alertId;
	ELSE IF (role = 'Agent') 
		THEN SET returnPosition = 0;
		END IF;
    END IF;
    END IF;
    END IF;
RETURN returnPosition;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetDateByOrderStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetDateByOrderStatus`(
order_status varchar(50),
order_Id int(11)) RETURNS datetime
BEGIN
 DECLARE orderDateByStatus datetime;
    DECLARE hasEdoc bit;
    DECLARE hasScanBacks bit;
    DECLARE hasPreCall bit;
    DECLARE isNeedReviewPCResolution bit;
    SET hasEdoc = 0;
    SET hasScanBacks = 0;
	SET orderDateByStatus = null;
    SET hasPreCall = null;
    SET isNeedReviewPCResolution = null;
    
    -- hasEdoc
    BEGIN
  SET hasEdoc = (IsOrderRequiredFee(order_Id, 'EDocs'));
    END;
    
    -- hasScanBacks
    BEGIN
  SET hasScanBacks = (IsOrderRequiredFee(order_Id, 'Scan backs'));
    END;
    
    -- hasPreCall
 BEGIN
  SET hasPreCall = (SELECT IsNeedPreCall FROM tce_dev2.`order` where OrderId = order_Id);
    END;
    
    -- isNeedReviewPCResolution
 BEGIN
  SET isNeedReviewPCResolution = (SELECT NeedReviewPCResolution FROM tce_dev2.`order` where OrderId = order_Id);
    END;    
    
    -- open
 IF order_status IS NOT NULL AND order_status = 'Open' THEN
    BEGIN
  SET orderDateByStatus = (select OrderDate FROM tce_dev2.`order` where OrderId = order_Id);  
 END;
    
    -- Assigned to Vendor
    ELSEIF order_status IS NOT NULL AND order_status = 'Assigned to Vendor' THEN
    BEGIN
  SET orderDateByStatus = (Select FilledDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;
    
    -- Appt Confirmed Pending Docs
    ELSEIF order_status IS NOT NULL AND order_status = 'Appt Confirmed Pending Docs' THEN
    BEGIN
  SET orderDateByStatus = (Select TurnAroundDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;
    
    -- Pending Pre-Call not EDocs and pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Pending Pre-Call' AND ( hasEdoc = 0) AND (hasPreCall = 1)
 THEN
    BEGIN
  SET orderDateByStatus = (Select TurnAroundDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;
    -- Pending Pre-Call EDocs and pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Pending Pre-Call' AND hasEdoc = 1 AND ( hasPreCall = 1)
        THEN
    BEGIN
  SET orderDateByStatus = (Select DocumentCompletedDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;
    
    -- Appt Ready not EDocs and pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Appt Ready' AND hasEdoc = 0 AND ( hasPreCall = 1)
        THEN
    BEGIN
  SET orderDateByStatus = (Select TurnAroundDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;    
    -- Appt Ready EDocs and not pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Appt Ready' AND hasEdoc = 0 AND ( hasPreCall != 1)
        THEN
    BEGIN
  SET orderDateByStatus = (Select DocumentCompletedDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;    
    -- Appt Ready EDocs and pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Appt Ready' AND hasEdoc = 0 AND ( hasPreCall = 1)
        THEN
    BEGIN
  SET orderDateByStatus = (Select ApptReadyDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;
    
    -- Closed Pending Review/ PC Resolution Scan backs and pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Closed Pending Review/ PC Resolution' AND hasScanBacks = 0 
    AND ( isNeedReviewPCResolution = 1)
        THEN
    BEGIN
  SET orderDateByStatus = (Select ClosingWorkSheetDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;
    
    -- Closed Pending QC Review Scan backs and pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Closed Pending QC Review' AND hasScanBacks = 0 THEN
    BEGIN
  SET orderDateByStatus = (Select ClosingWorkSheetDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;
    
    -- Closing Completed
    ELSEIF order_status IS NOT NULL AND order_status = 'Closing Completed' THEN
    BEGIN
  SET orderDateByStatus = (Select ClosedDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;
    
    -- Hold
    ELSEIF order_status IS NOT NULL AND order_status = 'Hold' THEN
    BEGIN
  SET orderDateByStatus = (Select HoldingDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;
    
    -- Canceled
    ELSEIF order_status IS NOT NULL AND order_status = 'Canceled' THEN
    BEGIN
  SET orderDateByStatus = (Select CanceledDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;
    
    -- Unsuccessful signing attempt
    ELSEIF order_status IS NOT NULL AND order_status = 'Canceled' THEN
    BEGIN
  SET orderDateByStatus = (Select ClosingWorkSheetDate FROM tce_dev2.`order` where OrderId = order_Id);
 END;
    END IF;
RETURN orderDateByStatus;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetDurationBusinessTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetDurationBusinessTime`(
startDateTime DATETIME, 
endDateTime DATETIME, 
timeZone INT
) RETURNS int(11)
BEGIN
	DECLARE startDateTimeLocal DATETIME;
    DECLARE startDateLocal DATE;
    DECLARE endDateTimeLocal DATETIME;
    DECLARE endDateLocal DATE;
    DECLARE currentDateTime DATETIME;
    DECLARE isClosed BIT;
    DECLARE isHoliday BIT;
    DECLARE isClosedHoliday BIT DEFAULT 0;
    DECLARE dayOfWeek VARCHAR(50);
    
    DECLARE startCalculatedDateTime DATETIME;
    DECLARE endCalculatedDateTime DATETIME;
    DECLARE startOfCurrentDateTime DATETIME;
    DECLARE endOfCurrentDateTime DATETIME;
    
    DECLARE workStartTime TIME;
    DECLARE workEndTime TIME;
    
    DECLARE holidayOffStartTime TIME;
    DECLARE holidayOffEndTime TIME;
    
    DECLARE endCurrentDateTime DATETIME;
    DECLARE startCurrentDateTime DATETIME;
    
    DECLARE currentDate DATE;
    DECLARE currentTime TIME;
    
    DECLARE tempDateTime DATETIME;
    DECLARE IsNegativeMinutes BIT DEFAULT 0;
    
    DECLARE totalMinutes INT DEFAULT 0;
    
    IF(startDateTime > endDateTime)
		THEN SET tempDateTime = startDateTime;
			 SET startDateTime = endDateTime;
             SET endDateTime = tempDateTime;
             SET IsNegativeMinutes = 1;
	END IF;
    
	SET startDateTimeLocal = DATE_ADD(startDateTime, INTERVAL timeZone HOUR);
    SET endDateTimeLocal = DATE_ADD(endDateTime, INTERVAL timeZone HOUR);
    SET endDateLocal =  DATE(endDateTimeLocal);
    SET startDateLocal = DATE(startDateTimeLocal);
    
    SET currentDateTime = startDateTimeLocal;
    
    WHILE(DATE(currentDateTime) <= endDateLocal)
     DO
		SET currentDate = DATE(currentDateTime);
		SET currentTime = TIME(currentDateTime);
        
        SELECT TIME(bh.OpenTime),TIME(bh.CloseTime), bh.isClose
		INTO workStartTime, workEndTime, isClosed
        FROM business_hours bh WHERE bh.dayOfWeek = DAYOFWEEK(currentDateTime);
        
		SET startOfCurrentDateTime= CONVERT(CONCAT(currentDate,' ','00:00:00'), DATETIME);
        SET endOfCurrentDateTime= CONVERT(CONCAT(currentDate,' ','23:59:59'), DATETIME);
		
        SELECT bhe.CloseTime, bhe.OpenTime, bhe.Closed, (CASE WHEN COUNT(bhe.OpenTime) > 0 THEN 1 ELSE 0 END)
        INTO holidayOffEndTime, holidayOffStartTime, isClosedHoliday, isHoliday FROM biz_hours_except bhe 
						WHERE currentDate BETWEEN DATE(bhe.OpenTime) AND DATE(bhe.CloseTime) LIMIT 0,1;
		
		IF(isClosed = 0 OR isClosed IS NULL) 
        THEN
			IF (currentDate <> startDateLocal AND currentDate <> endDateLocal)
				THEN SET startCalculatedDateTime = startOfCurrentDateTime;
					 SET endCalculatedDateTime = endOfCurrentDateTime;
            ELSEIF (currentDate = startDateLocal AND currentDate <> endDateLocal)
				THEN SET startCalculatedDateTime = currentDateTime;
					 SET endCalculatedDateTime = endOfCurrentDateTime;
			ELSEIF (currentDate <> startDateLocal AND currentDate = endDateLocal)
				THEN SET startCalculatedDateTime = startOfCurrentDateTime;
					 SET endCalculatedDateTime = endDateTimeLocal;
			ELSE 	 SET startCalculatedDateTime = currentDateTime;
					 SET endCalculatedDateTime = endDateTimeLocal;
			END IF;	
            
            IF(isHoliday = 1 AND (isClosedHoliday = 0 OR isClosedHoliday IS NULL))
				THEN SET totalMinutes = totalMinutes + 
                CalculateBusinessHourByOffTime(TIME(startCalculatedDateTime),TIME(endCalculatedDateTime),'04:30:00','18:30:00',holidayOffStartTime,holidayOffEndTime);
			ELSEIF(isHoliday = 0) 				
				THEN SET totalMinutes = totalMinutes + 
			    CalculateBusinessHourByWorkingTime(startCalculatedDateTime,endCalculatedDateTime,workStartTime,workEndTime);				
			END IF;
		
		END IF;
		  
        SET currentDateTime = DATE_ADD(currentDateTime,INTERVAL 1 DAY);
        
	END WHILE;
    
    IF(IsNegativeMinutes = 1)
		THEN SET totalMinutes = 0 - totalMinutes;
	END IF;
    
    RETURN totalMinutes;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetFirstComment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetFirstComment`(type_id int(11), owner_id int(11)) RETURNS varchar(250) CHARSET utf8
BEGIN
	DECLARE comment VARCHAR(250);    
	SET comment = '';
    
	IF owner_id IS NOT NULL THEN
    BEGIN
        SELECT c.description
        INTO comment
        FROM `comment` AS c
		WHERE c.typeid = type_id and ownerid = owner_id
        ORDER BY CreatedDate DESC
        LIMIT 1;			
    END;
    END IF;
    
	RETURN comment;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetFullNameByUserId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetFullNameByUserId`(user_Id int(11)) RETURNS varchar(50) CHARSET utf8
BEGIN
	DECLARE userType VARCHAR(15);
    DECLARE fullName VARCHAR(50);
    DECLARE roleName VARCHAR(100);
	SET userType = '';
    SET fullName = '';
    
	IF user_Id IS NOT NULL THEN
    BEGIN
        SELECT r.Type, r.RoleName
        INTO userType, roleName
        FROM user_roles AS u
		INNER JOIN roles AS r ON u.RoleId = r.RoleId
		WHERE u.UsersId = user_Id
        LIMIT 1;
        
        -- if user is staff
        IF userType = 'Staff' THEN
        BEGIN
			SELECT CONCAT(e.FirstName,' ', e.LastName)
            INTO fullName
            FROM employees e
            INNER JOIN users u ON e.RepId = u.MappingUserId
            WHERE u.UsersId = user_Id;
        END;
        END IF;
        
        -- if user is client
        If userType = 'Client' THEN
        BEGIN
			-- client is agent
			IF RoleName = 'Agent' THEN 
            BEGIN
				SELECT a.FullName
				INTO fullName
				FROM agent a
				INNER JOIN users u ON a.AgentId = u.MappingUserId
				WHERE u.UsersId = user_Id;
            END;
            ELSE
            BEGIN
				-- client is broker or branch
				SELECT b.Company
				INTO fullName
				FROM broker b
				INNER JOIN users u ON b.BrokerID = u.MappingUserId
				WHERE u.UsersId = user_Id;
            END;
            END IF;
        END;
        END IF;
        
        -- if user is client
        If userType = 'Vendor' THEN
        BEGIN
			SELECT CONCAT(s.FirstName,' ', s.LastName)
            INTO fullName
            FROM signer s
            INNER JOIN users u ON s.SignerId = u.MappingUserId
            WHERE u.UsersId = user_Id;
        END;
        END IF;
    END;
    END IF;
    
	RETURN fullName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetFullNameOfUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetFullNameOfUser`(user_Id int(11)) RETURNS varchar(50) CHARSET utf8
BEGIN
	DECLARE userType VARCHAR(15);
    DECLARE fullName VARCHAR(50);
    DECLARE roleName VARCHAR(100);
	SET userType = '';
    SET fullName = '';
    
	IF user_Id IS NOT NULL THEN
    BEGIN
        SELECT r.Type, r.RoleName
        INTO userType, roleName
        FROM user_roles AS u
		INNER JOIN role_permission AS r ON u.RoleId = r.RoleId
		WHERE u.UsersId = user_Id
        LIMIT 1;
        
        -- if user is staff
        IF userType = 'Staff' THEN
        BEGIN
			SELECT CONCAT(e.FirstName,' ', e.LastName)
            INTO fullName
            FROM employees e
            INNER JOIN users u ON e.RepId = u.MappingUserId
            WHERE u.UsersId = user_Id;
        END;
        END IF;
        
        -- if user is client
        If userType = 'Client' THEN
        BEGIN
			-- client is agent
			IF RoleName = 'Agent' THEN 
            BEGIN
				SELECT a.FullName
				INTO fullName
				FROM agent a
				INNER JOIN users u ON a.AgentId = u.MappingUserId
				WHERE u.UsersId = user_Id;
            END;
            ELSE
            BEGIN
				-- client is broker or branch
				SELECT b.Company
				INTO fullName
				FROM broker b
				INNER JOIN users u ON b.BrokerID = u.MappingUserId
				WHERE u.UsersId = user_Id;
            END;
            END IF;
        END;
        END IF;
        
        -- if user is client
        If userType = 'Vendor' THEN
        BEGIN
			SELECT CONCAT(s.FirstName,' ', s.LastName)
            INTO fullName
            FROM signer s
            INNER JOIN users u ON s.SignerId = u.MappingUserId
            WHERE u.UsersId = user_Id;
        END;
        END IF;
    END;
    END IF;
    
	RETURN fullName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetMTDFromDate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetMTDFromDate`(user_Id int(11)) RETURNS datetime
BEGIN
	DECLARE FromDate datetime;
	SET FromDate = UTC_TIMESTAMP();
	IF user_Id IS NOT NULL THEN
    BEGIN
		select
			if(mtd.Period is null,
				mtd.FromDate,
				if(mtd.Period='WTD',
					DATE_FORMAT(SUBDATE(UTC_TIMESTAMP(), WEEKDAY(UTC_TIMESTAMP())) ,'%Y-%m-%d 00:00:00'),
                    if(mtd.Period='YTD',
						DATE_FORMAT(UTC_TIMESTAMP() ,'%Y-01-01 00:00:00'),
                        DATE_FORMAT(UTC_TIMESTAMP() ,'%Y-%m-01 00:00:00') -- MTD
					)
				)
			) as FromDate
		INTO FromDate
		FROM client_mtd_config as mtd
        WHERE mtd.UserId = user_Id
        LIMIT 1;
	END;
	END IF;
    RETURN FromDate;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetMTDToDate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetMTDToDate`(user_Id int(11)) RETURNS datetime
BEGIN
	DECLARE ToDate datetime;
	SET ToDate = UTC_TIMESTAMP();
	IF user_Id IS NOT NULL THEN
    BEGIN
		select
			if(mtd.Period is null,
				mtd.ToDate,
                UTC_TIMESTAMP()
			) as ToDate
		INTO ToDate
		FROM client_mtd_config as mtd
        WHERE mtd.UserId = user_Id
        LIMIT 1;
	END;
	END IF;
    RETURN ToDate;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetOrderBrokerFeeById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetOrderBrokerFeeById`(order_id int) RETURNS int(11)
BEGIN
DECLARE brokerFee decimal(19,4);
SET brokerFee =	(SELECT SUM(BrokerFee) FROM order_fee WHERE orderId = order_id);

RETURN brokerFee;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetOrderDateByOrderStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GETORDERDATEBYORDERSTATUS`(
order_status varchar(50),
order_Id int(11)) RETURNS datetime
BEGIN
	DECLARE OrderDateByStatus datetime;
    DECLARE CheckEdoc bit;
    DECLARE CheckScanBacks bit;
    DECLARE CheckPreCall bit;
    DECLARE CheckNeedReviewPCResolution bit;
    SET CheckEdoc = 0;
    SET CheckScanBacks = 0;
	SET OrderDateByStatus = null;
    SET CheckPreCall = null;
    SET CheckNeedReviewPCResolution = null;
    -- checkEdoc
    BEGIN
		SET CheckEdoc = (IsOrderRequiredFee(order_Id, 'EDocs'));
    END;
    -- checkScanBack
    BEGIN
		SET CheckScanBacks = (IsOrderRequiredFee(order_Id, 'Scan backs'));
    END;
    -- CheckPreCall
	BEGIN
		SET CheckPreCall = (SELECT IsNeedPreCall FROM tce_dev2.`order` where OrderId = order_Id);
    END;
    -- CheckNeedReviewPCResolution
	BEGIN
		SET CheckNeedReviewPCResolution = (SELECT NeedReviewPCResolution FROM tce_dev2.`order` where OrderId = order_Id);
    END;
    -- open
	IF order_status IS NOT NULL AND order_status = 'Open' THEN
    BEGIN
		SET OrderDateByStatus = (select OrderDate FROM tce_dev2.`order` where OrderId = order_Id);		
	END;
    -- Assigned to Vendor
    ELSEIF order_status IS NOT NULL AND order_status = 'Assigned to Vendor' THEN
    BEGIN
		SET OrderDateByStatus = (Select FilledDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    -- Appt Confirmed Pending Docs
    ELSEIF order_status IS NOT NULL AND order_status = 'Appt Confirmed Pending Docs' THEN
    BEGIN
		SET OrderDateByStatus = (Select TurnAroundDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    -- Pending Pre-Call not EDocs and pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Pending Pre-Call' AND ( CheckEdoc = 0) AND (CheckPreCall = 1)
	THEN
    BEGIN
		SET OrderDateByStatus = (Select TurnAroundDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    -- Pending Pre-Call EDocs and pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Pending Pre-Call' AND CheckEdoc = 1 AND ( CheckPreCall = 1)
        THEN
    BEGIN
		SET OrderDateByStatus = (Select DocumentCompletedDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    -- Appt Ready not EDocs and pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Appt Ready' AND CheckEdoc = 0 AND ( CheckPreCall = 1)
        THEN
    BEGIN
		SET OrderDateByStatus = (Select TurnAroundDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    -- Appt Ready EDocs and not pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Appt Ready' AND CheckEdoc = 0 AND ( CheckPreCall != 1)
        THEN
    BEGIN
		SET OrderDateByStatus = (Select DocumentCompletedDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    -- Appt Ready EDocs and pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Appt Ready' AND CheckEdoc = 0 AND ( CheckPreCall = 1)
        THEN
    BEGIN
		SET OrderDateByStatus = (Select ApptReadyDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    -- Appt Closed Pending Review/ PC Resolution Scan backs and pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Closed Pending Review/ PC Resolution' AND CheckScanBacks = 0 
    AND ( CheckNeedReviewPCResolution = 1)
        THEN
    BEGIN
		SET OrderDateByStatus = (Select ClosingWorkSheetDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    -- Closed Pending QC Review Scan backs and pre-call required
    ELSEIF order_status IS NOT NULL AND order_status = 'Closed Pending QC Review' AND CheckScanBacks = 0 THEN
    BEGIN
		SET OrderDateByStatus = (Select ClosingWorkSheetDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    -- Closing Completed
    ELSEIF order_status IS NOT NULL AND order_status = 'Closing Completed' THEN
    BEGIN
		SET OrderDateByStatus = (Select ClosedDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    -- Hold
    ELSEIF order_status IS NOT NULL AND order_status = 'Hold' THEN
    BEGIN
		SET OrderDateByStatus = (Select HoldingDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    -- Canceled
    ELSEIF order_status IS NOT NULL AND order_status = 'Canceled' THEN
    BEGIN
		SET OrderDateByStatus = (Select CanceledDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    -- Unsuccessful signing attempt
    ELSEIF order_status IS NOT NULL AND order_status = 'Canceled' THEN
    BEGIN
		SET OrderDateByStatus = (Select ClosingWorkSheetDate FROM tce_dev2.`order` where OrderId = order_Id);
	END;
    END IF;
RETURN OrderDateByStatus;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetOrderSignerFeeById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetOrderSignerFeeById`(order_id int) RETURNS int(11)
BEGIN
DECLARE signerFee decimal(19,4);
SET signerFee =	(SELECT SUM(SignerFee) FROM order_fee WHERE orderId = order_id);

RETURN signerFee;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetProfilePictureByUserId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetProfilePictureByUserId`(user_Id int(11)) RETURNS longblob
BEGIN
	DECLARE userType VARCHAR(15);
    DECLARE roleName VARCHAR(100);
    DECLARE ProfilePicture longblob;
	SET userType = '';
    SET ProfilePicture = NULL;
    
	IF user_Id IS NOT NULL THEN
    BEGIN
        SELECT r.Type, r.RoleName
        INTO userType, roleName
        FROM user_roles AS u
		INNER JOIN roles AS r ON u.RoleId = r.RoleId
		WHERE u.UsersId = user_Id
        LIMIT 1;
        
        -- if user is staff
        IF userType = 'Staff' THEN
        BEGIN
			SELECT e.ProfilePicture
            INTO ProfilePicture
            FROM employees e
            INNER JOIN users u ON e.RepId = u.MappingUserId
            WHERE u.UsersId = user_Id;
        END;
        END IF;
        
        -- if user is client
        If userType = 'Client' THEN
        BEGIN
			-- client is agent
			IF RoleName = 'Agent' THEN 
            BEGIN
				SELECT a.ProfilePicture
				INTO ProfilePicture
				FROM agent a
				INNER JOIN users u ON a.AgentId = u.MappingUserId
				WHERE u.UsersId = user_Id;
            END;
            ELSE
            BEGIN
				-- client is broker or branch
				SELECT b.ProfilePicture
				INTO ProfilePicture
				FROM broker b
				INNER JOIN users u ON b.BrokerID = u.MappingUserId
				WHERE u.UsersId = user_Id;
            END;
            END IF;
        END;
        END IF;
        
        -- if user is client
        If userType = 'Vendor' THEN
        BEGIN
			SELECT s.ProfilePicture
            INTO ProfilePicture
            FROM signer s
            INNER JOIN users u ON s.SignerId = u.MappingUserId
            WHERE u.UsersId = user_Id;
        END;
        END IF;
    END;
    END IF;
    
	RETURN ProfilePicture;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetProgramForOrderAsmtTrainingLog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetProgramForOrderAsmtTrainingLog`(listId VARCHAR(1000)) RETURNS varchar(5000) CHARSET utf8
BEGIN
    DECLARE returnData VARCHAR(5000);
    
    -- sum of additional fee
    select group_concat(tp.Title) into returnData from training_programs tp where FIND_IN_SET(tp.ProgramId, listId) > 0;
    
    
    RETURN returnData;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetSpecialtyForOrderAsmtTrainingLog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetSpecialtyForOrderAsmtTrainingLog`(listId VARCHAR(1000)) RETURNS varchar(5000) CHARSET utf8
BEGIN
    DECLARE returnData VARCHAR(5000);
    
    -- sum of additional fee
    select group_concat(vc.CatName) into returnData from vendor_categories vc where FIND_IN_SET(vc.CatId, listId) > 0;
    
    
    RETURN returnData;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetTotalAdditionalClientFee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetTotalAdditionalClientFee`(order_ID INT, fee_id INT) RETURNS decimal(10,0)
BEGIN
    DECLARE AdditionalFee DECIMAL(19, 4);
    
    -- sum of additional fee
    SELECT SUM(BrokerFee)
    INTO AdditionalFee
    FROM `order_fee` AS of
    WHERE of.OrderID = order_ID AND of.FeeDescripID <> fee_id;
    
    IF AdditionalFee IS NULL THEN
		SET AdditionalFee = 0;
	END IF;
    
    RETURN AdditionalFee;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetTotalAdditionalVendorFee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetTotalAdditionalVendorFee`(order_ID INT, fee_id INT) RETURNS decimal(10,0)
BEGIN
    DECLARE AdditionalFee DECIMAL(19, 4);
    
    -- sum of additional fee
    SELECT SUM(SignerFee)
    INTO AdditionalFee
    FROM `order_fee` AS of
    WHERE of.OrderID = order_ID AND of.FeeDescripID <> fee_id;
    
    IF AdditionalFee IS NULL THEN
		SET AdditionalFee = 0;
	END IF;
    
    RETURN AdditionalFee;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetUserIdByIdAndRole` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetUserIdByIdAndRole`(id int(11), roleType varchar(50) , isAgent boolean) RETURNS varchar(250) CHARSET utf8
BEGIN
	DECLARE userId int(11);    
	SET userId = -1;
    
	IF id IS NOT NULL and roleType IS NOT NULL and roleType <> '' THEN
    BEGIN
        SELECT DISTINCT u.UsersId 
        INTO userId 
        FROM `users` u
		INNER JOIN user_roles ur ON u.UsersId = ur.UsersId
		INNER JOIN roles rl ON ur.RoleId = rl.RoleId
		WHERE u.MappingUserId = id AND LOWER(rl.Type) = LOWER(roleType) AND (IF(isAgent IS NOT NULL AND isAgent = TRUE, LOWER(rl.RoleName) LIKE '%agent%', LOWER(rl.RoleName) NOT LIKE '%agent%'));		
    END;
    END IF;
    
	RETURN userId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetUserNameByIdAndRole` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetUserNameByIdAndRole`(id int(11), roleType varchar(50) , isAgent boolean) RETURNS varchar(250) CHARSET utf8
BEGIN
	DECLARE userName VARCHAR(45);    
	SET userName = '';
    
	IF id IS NOT NULL and roleType IS NOT NULL and roleType <> '' THEN
    BEGIN
        SELECT u.UserName 
        INTO userName 
        FROM `users` u
		INNER JOIN user_roles ur ON u.UsersId = ur.UsersId
		INNER JOIN roles rl ON ur.RoleId = rl.RoleId
		WHERE u.MappingUserId = id AND LOWER(rl.Type) = LOWER(roleType) AND (IF(isAgent IS NOT NULL AND isAgent = TRUE, LOWER(rl.RoleName) LIKE '%agent%', LOWER(rl.RoleName) NOT LIKE '%agent%'));		
    END;
    END IF;
    
	RETURN userName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GetUserType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `GetUserType`(user_Id int(11)) RETURNS varchar(15) CHARSET utf8
BEGIN
	DECLARE userType VARCHAR(15);    
	SET userType = '';
    
	IF user_Id IS NOT NULL THEN
    BEGIN
        SELECT r.Type
        INTO userType
        FROM user_roles AS u
		INNER JOIN roles AS r ON u.RoleId = r.RoleId
		WHERE u.UsersId = user_Id
        LIMIT 1;			
    END;
    END IF;
    
	RETURN userType;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `IsActiveProgram` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `IsActiveProgram`(courseId int(11)) RETURNS bit(1)
BEGIN
DECLARE isActive BIT;    
	SET isActive = 0;
    
	IF courseId IS NOT NULL THEN
    BEGIN
        IF EXISTS (SELECT c.CourseId FROM training_courses AS c
					INNER JOIN training_program_courses AS pc ON c.CourseId = pc.CourseId
                    inner join training_programs p on pc.ProgramId = p.ProgramId
					WHERE c.CourseId = courseId and (p.Inactive = 0 OR p.Inactive is NULL)) THEN
			SET isActive = 1;
		END IF;
    END;
    END IF;
    
	RETURN isActive;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `IsOrderRequiredFee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `IsOrderRequiredFee`(orderId INT, feeDescription VARCHAR(100)) RETURNS bit(1)
BEGIN
	DECLARE requiredFee BIT;    
	SET requiredFee = FALSE;
    
	
	IF EXISTS (SELECT 1 FROM `order_fee` of 
				INNER JOIN `broker_fee` bf ON `of`.`FeeDescripID` = `bf`.`FeeId`
				WHERE `of`.`OrderID` = orderId AND `bf`.`FeeDescription` = feeDescription) THEN
		SET requiredFee = TRUE;
	END IF;
    
	RETURN requiredFee;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `IsPublishedProgram` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `IsPublishedProgram`(courseId int(11)) RETURNS bit(1)
BEGIN
DECLARE isPublished BIT;    
	SET isPublished = 0;
    
	IF courseId IS NOT NULL THEN
    BEGIN
        IF EXISTS (SELECT c.CourseId FROM training_courses AS c
					INNER JOIN training_program_courses AS pc ON c.CourseId = pc.CourseId
                    inner join training_programs p on pc.ProgramId = p.ProgramId
					WHERE c.CourseId = courseId and p.IsPublished = 1) THEN
			SET isPublished = 1;
		END IF;
    END;
    END IF;
    
	RETURN isPublished;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `IsTceScheduler` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `IsTceScheduler`(user_Id int(11)) RETURNS bit(1)
BEGIN
	DECLARE isScheduler BIT;    
	SET isScheduler = 0;
    
	IF user_Id IS NOT NULL THEN
    BEGIN
        IF EXISTS (SELECT id FROM user_roles AS u
					INNER JOIN roles AS r ON u.RoleId = r.RoleId
					WHERE u.UsersId = user_Id AND TYPE='Staff' AND r.RoleId = 3) THEN
			SET isScheduler = 1;
		END IF;
    END;
    END IF;
    
	RETURN isScheduler;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `IsUserVendor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `IsUserVendor`(user_Id int(11)) RETURNS bit(1)
BEGIN
	DECLARE isVendor BIT;    
	SET isVendor = 0;
    
	IF user_Id IS NOT NULL THEN
    BEGIN
        IF EXISTS (SELECT id FROM user_roles AS u
					INNER JOIN roles AS r ON u.RoleId = r.RoleId
					WHERE u.UsersId = user_Id AND TYPE='Vendor') THEN
			SET isVendor = 1;
		END IF;
    END;
    END IF;
    
	RETURN isVendor;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `ValidateOrderBeforeChangeStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` FUNCTION `ValidateOrderBeforeChangeStatus`(orderId INT, newStatus INT) RETURNS int(11)
BEGIN
	/** List of order status:
    * Open 									= 1
	* Assigned to Vendor 					= 2
	* Appt Confirmed Pending Docs 			= 3
	* Pending Pre-call 						= 4
	* Appt Ready 							= 5
	* Closed Pending Review/PC Resolution 	= 6
	* Closed Pending QC Review 				= 7
	* Closing Completed 					= 8
	* Post Close 							= 9
	* Hold 									= 10
	* Canceled 								= 11
	* Unsuccessful signing attempt 			= 12
    */
    
    /** Error Code: 
    * 1: "This order has not been assigned to any vendor yet. Please assign vendor before changing order’s status."
    * 2: "This order requires eDocs, so order’ status should be changed to Appt Confirmed Pending Docs first."
    * 3: "This order requires manual pre-call, so order’ status should be changed to Pending Pre-Call first."
    * 4: "This order’s status must be changed to “Appt Ready” first."
    * 5: "This order requires QC review so status must be changed to "Closed Pending QC Review"."
    * 6: "This order requires Review/PC Resolution so status must be changed to “Closed Pending Review/PC Resolution”."
    * 7: "This order’s status must be changed to Closing Completed."
    * 8: "This order has been closed. In case of any issue, order’s status must be changed to “Post Close”."
    * 9: "This order has been closed and had an issue so order’s status must be changed to “Closed Pending Review/PC Resolution”."
    */
     
    DECLARE currentStatus INT;
    
    DECLARE requiredEdoc BIT;
    DECLARE requiredScanback BIT;
    DECLARE requiredReviewPCResolution BIT;
    DECLARE requiredPreCall BIT;
    
    DECLARE vendorId INT;
    
    /* Edocs is required */
    SELECT IsOrderRequiredFee(orderId, 'Edocs')
    INTO requiredEdoc;
    
    /* Scanback is required */
    SELECT IsOrderRequiredFee(orderId, 'Scan backs')
    INTO requiredScanback;
    
    /* get signer of order, current status (progress) */
    SELECT SignerId, ProgressId, IsNeedPreCall, NeedReviewPCResolution
    INTO vendorId, currentStatus, requiredPreCall, requiredReviewPCResolution
    FROM `order` o
    WHERE `o`.`OrderId` = orderId;
    
    IF (vendorId IS NULL) THEN 
		SET vendorId = 0; 
    END IF;
    
    IF (requiredPreCall IS NULL) THEN 
		SET requiredPreCall = false; 
    END IF;
    
    IF (requiredReviewPCResolution IS NULL) THEN 
		SET requiredReviewPCResolution = false; 
    END IF;
    
    /* If order has not been assiged to any vendor, can not change to other status except Hold/Canceled */
    IF (currentStatus = 1 AND newStatus <> 10 AND newStatus <> 11) THEN
		RETURN 1;
	END IF;
    
    /* If order's status is "Assigned to Vendor" */
     IF (currentStatus = 2) THEN
		/* If Edocs is required, user only can change status to "Appt Confirmed Pending Docs". Others status is rejected. */
		IF (requiredEdoc AND newStatus <> 3) THEN
			RETURN 2;
		END IF;
        
        /* If edocs is not required but manual pre call is required. user only can change status to "Pending Pre-call" */
        IF (NOT requiredEdoc AND requiredPreCall AND newStatus <> 4) THEN
			RETURN 3;
		END IF;
        
        /* if the order is not required both edoc/pre call. user only can change to "Appt Ready" */
        IF (NOT requiredEdoc AND NOT requiredPreCall AND newStatus <> 5) THEN
			RETURN 4;
		END IF;
     END IF;
    /* End "Assigned to Vendor" */
    
	/* If current status is "Appt Confirmed Pending Docs" */
	IF (currentStatus = 3) THEN
		/* If manual pre call is required, user only can change status to "Pending Pre-call" */
        IF (requiredPreCall AND newStatus <> 4) THEN
			RETURN 3;
        END IF;
        
        /* if the order is not required manual pre call. user only can change to "Appt Ready" */
        IF (NOT requiredPreCall AND newStatus <> 5) THEN
			RETURN 4;
		END IF;
	END IF;
    
    /* if current order's status is "Pending Pre-call", user only can change status to "Appt Ready" */
    IF (currentStatus = 4 AND newStatus <> 5) THEN
		RETURN 4;
    END IF;
    
    /* If current order's status is "Appt Ready" */
    IF (currentStatus = 5 AND newStatus <> 12) THEN
		/* if scanbacks is required, user only can change status to "Closed Pending QC Review" */
		IF (requiredScanback AND newStatus<> 7) THEN
			RETURN 5;
        END IF;
        
        /* if scanbacks is not required and Review PC Resolution is required, user only can change status to "Closed Pending Review/PC Resolution" */
		IF (NOT requiredScanback AND requiredReviewPCResolution AND newStatus<> 6) THEN
			RETURN 6;
        END IF;
        
        /* if scanback and Pc resolution are not required, user only can change status to Closing Completed */
        IF (NOT requiredScanback AND NOT requiredReviewPCResolution AND newStatus<> 8) THEN
			RETURN 7;
        END IF;
    END IF;
    
    /* If current order's status is "Closed Pending Review/PC Resolution". user only can change status to "Closing Completed" */
    IF (currentStatus = 6 AND newStatus <> 12 AND newStatus <> 8) THEN
		RETURN 7;
    END IF;
    
    /* If current order's status is "Closed Pending QC Review". user only can change status to "Closing Completed" */
    IF (currentStatus = 7 AND newStatus <> 12 AND newStatus <> 8) THEN
		RETURN 7;
    END IF;
    
    /* If current order's status is "Closing Completed", user only can change status to "Post Close" */
    IF (currentStatus = 8 AND newStatus <> 9) THEN
		RETURN 8;
    END IF;
    
    /* If current order's status is "Post Close", user only can change status to "Closed Pending Review/PC Resolution" */
    IF (currentStatus = 9 AND newStatus <> 6) THEN
		RETURN 9;
    END IF;
    
    /* Can change status */
	RETURN 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `alter_table_order_fee_approve` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `alter_table_order_fee_approve`()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order_fee_approve' AND 
                            COLUMN_NAME = 'OfferID') THEN
	BEGIN
		ALTER TABLE `order_fee_approve` 
		ADD COLUMN `OfferID` INT NULL;
	END;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `autoVendorOffer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `autoVendorOffer`(
IN orderId int,
IN isEliteVendor BIT
)
BEGIN
	DECLARE lat1 FLOAT;
    DECLARE long1 FLOAT;
    DECLARE startZip VARCHAR(20);
    DECLARE brokerId INT;
    DECLARE state VARCHAR(2);
    DECLARE amount FLOAT;
    DECLARE languageId INT;
    DECLARE coLanguageId INT;
    DECLARE signerId INT;
    DECLARE customerId INT;
    DECLARE dist FLOAT;
    DECLARE autoProgress VARCHAR(1);
    DECLARE aptDateTime DATETIME;
    DECLARE aptDateTimeUtc DATETIME;
    DECLARE isVenOrCeDefineAdt BIT;
    DECLARE rowFindCount INT DEFAULT 0;
    DECLARE isFinished INTEGER DEFAULT 0;
    DECLARE eliteName VARCHAR(20) DEFAULT 'elite';
    DECLARE mile INT DEFAULT 50;
    DECLARE offerSent INT;
    
	DECLARE myCursor CURSOR FOR
		SELECT sn.signerId, (69.1*sqrt(power(zp.lat-lat1,2)+0.6*power(zp.long-long1,2))) as dist
		FROM signer sn
        LEFT JOIN zip zp ON sn.weekdayZip = zp.zip
		WHERE 
		-- distance signer within miles 50/100
		 (69.1*sqrt(power(zp.lat-lat1,2)+0.6*power(zp.long-long1,2))) < mile AND
		-- signer is active
		 (sn.inActive IS NULL OR sn.inActive = 0) AND
		-- co customer order language must match with signer language
		 (coLanguageId IS NULL OR coLanguageId = 0 OR coLanguageId IN (SELECT sl.languageId FROM signer_language sl WHERE sl.signerId = sn.signerId)) AND
		-- primary customer order language must match with signer language
		 (languageId IS NULL OR languageId = 0 OR languageId IN (SELECT sl.languageId FROM signer_language sl where sn.signerId= sl.signerId)) AND
		-- if vendor rating is new check qualified = "D" or "Q". Rating 6: New. 
		-- And rating must not poor (4) and need improvement (5)
		 (sn.rating NOT IN (4,5,6) OR ( sn.rating = 6 AND (sn.qualified = 'D' or sn.qualified = 'Q'))) AND
		-- signer does not include in DNU list of client/broker
		 sn.signerId NOT IN (SELECT brdnu.signerId FROM broker_donotuse brdnu WHERE brdnu.brokerId = brokerId) AND
		-- signer does not include in DNU list of customer
		 sn.signerId NOT IN (SELECT cusdnu.signerId FROM customer_donotuse cusdnu WHERE cusdnu.customerId = customerId) AND
		-- order’s apt time is not in vendor’s snooze time
		(isVenOrCeDefineAdt = 1 OR ((sn.snooze = 0 OR sn.Snooze IS NULL) 
					OR ((aptDateTimeUtc > sn.snoozeTo OR aptDateTimeUtc < sn.snoozeFrom )))) AND
		-- vendors have not accepted another order having the same aptDate and order progress in (closed, closing, cancelled)
		 (isVenOrCeDefineAdt = 1 OR (aptDateTime NOT IN (SELECT ord.aptDateTime FROM `order` ord 
							  WHERE ord.signerId = sn.signerId AND ord.progressId 
							  NOT IN (6,7,8,9,11) AND ord.orderId <> orderId))) AND
		
		-- order’s appt time is in vendor’s availability (days, evenings, weekends)
		-- (isVenOrCeDefineAdt = 1 OR ((sn.availDays = 1 AND HOUR(aptDateTime) >=8 AND HOUR(aptDateTime) <= 16 
													  -- AND WEEKDAY(aptDateTime) NOT IN (5,6)) 
								 -- OR (sn.availEves = 1 AND HOUR(aptDateTime) >=17 AND HOUR(aptDateTime) <= 10
													  -- AND WEEKDAY(aptDateTime) NOT IN (5,6)) 
								 -- OR (sn.AvailWkEnds = 1 AND (WEEKDAY(aptDateTime) = 5 OR WEEKDAY(aptDateTime) = 6)))) AND 
								  
		-- elite vendor and non-elite vendor
		 (
			-- elite vendor
			(isEliteVendor = 1 AND (((SELECT COUNT(catId) FROM vendor_categories WHERE catName = eliteName) = 0) OR ( 
				-- check min rating
				(sn.rating <= (SELECT vc.minRating FROM vendor_categories vc WHERE vc.catName = eliteName)) AND
				-- check number of order <= signer's complete orders 8 -> closing Completed
				((SELECT vc.minOrder FROM vendor_categories vc WHERE vc.catName = eliteName) 
				 <= sn.OrdersCount) AND
				-- vendor must take required tests
				((SELECT COUNT(vct1.testId) FROM vendor_cat_testtaken vct1 
				 WHERE vct1.catId = (SELECT catId FROM vendor_categories WHERE catName = eliteName))
				 = (SELECT COUNT(vct.testId) FROM vendor_cat_testtaken vct 
					  WHERE vct.catId = (SELECT catId FROM vendor_categories WHERE catName = eliteName) AND
					  vct.testId IN (SELECT vtr.testId FROM vendor_test_result vtr 
				  WHERE vtr.passed = 'Y' AND vtr.vendorId = sn.signerId)))
			 ))) OR 
			 -- non-elite vendor
			  (isEliteVendor = 0 AND (((SELECT COUNT(catId) FROM vendor_categories WHERE catName = eliteName) = 0) OR ( 
				-- check min rating
				(sn.rating > (SELECT vc.minRating FROM vendor_categories vc WHERE vc.catName = eliteName)) OR
				-- check number of order <= signer's complete orders 8 -> closing Completed
				((SELECT vc.minOrder FROM vendor_categories vc WHERE vc.catName = eliteName) 
				 > sn.OrdersCount) OR
				-- vendor must take required tests
				((SELECT COUNT(vct1.testId) FROM vendor_cat_testtaken vct1 
				 WHERE vct1.catId = (SELECT catId FROM vendor_categories WHERE catName = eliteName))
				 <> (SELECT COUNT(vct.testId) FROM vendor_cat_testtaken vct 
					  WHERE vct.catId = (SELECT catId FROM vendor_categories WHERE catName = eliteName) AND
					  vct.testId IN (SELECT vtr.testId FROM vendor_test_result vtr 
				  WHERE vtr.passed = 'Y' AND vtr.vendorId = sn.signerId)))
			 )))
		)
		
		LIMIT 0,15;
        
     -- handle no signer found
	DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET isFinished = 1;

	-- get zip, brokerId, state, feeAmount from order
    SELECT ord.zip , 
		   ord.brokerId, 
		   ord.state,
		   (SELECT SUM(of.signerFee) FROM order_fee of WHERE of.orderId = ord.orderID),
           ord.languageId,
           ord.coLanguageId,
           ord.customerId,
           ord.aptDateTime,
           DATE_SUB(ord.aptDateTime, INTERVAL z.utc HOUR),
           ord.isVenOrCeDefineAdt,
           ord.autoProgress
	INTO startZip, brokerId, state, amount, languageId, coLanguageId, customerId, aptDateTime, aptDateTimeUtc, isVenOrCeDefineAdt,autoProgress
	FROM `order` ord
    LEFT JOIN zip z on z.zip = ord.zip
	WHERE ord.orderID = orderId;
    
    -- get lat, long by zip of order
	SELECT lat, `long` INTO lat1,long1 FROM zip WHERE zip = startZip LIMIT 0,1;

    Open myCursor;
    IF FOUND_ROWS() < 10
	  THEN
		SET mile = 100;
	END IF;
    
    CLOSE myCursor;
    
    SET isFinished=0;
    
    Open myCursor;
    
    IF (FOUND_ROWS() = 0 AND isEliteVendor = 1)
	  THEN UPDATE `order` ord SET ord.autoProgress = 'F' WHERE ord.orderId = orderId;
	END IF;
    
    IF (FOUND_ROWS() = 0 AND isEliteVendor = 0 AND autoProgress = 'F')
      THEN UPDATE `order` ord SET ord.autoProgress = 'X' WHERE ord.orderId = orderId;
    END IF;
    
	IF (FOUND_ROWS() = 0 AND isEliteVendor = 0 AND autoProgress = 'E')
      THEN UPDATE `order` ord SET ord.autoProgress = 'Y' WHERE ord.orderId = orderId;
    END IF;
    
    IF (FOUND_ROWS() > 0 AND isEliteVendor = 1)
      THEN UPDATE `order` ord SET ord.autoProgress = 'E' WHERE ord.orderId = orderId;
    END IF;
    
    IF (FOUND_ROWS() > 0 AND isEliteVendor = 0)
      THEN UPDATE `order` ord SET ord.autoProgress = 'V' WHERE ord.orderId = orderId;
    END IF;
    
    IF (FOUND_ROWS() = 15 AND isEliteVendor = 1)
	  THEN UPDATE `order` ord SET ord.autoProgress = 'D' WHERE ord.orderId = orderId;
	END IF;
    
    -- send offer loop
    sendOffers: LOOP
		FETCH myCursor INTO signerId, dist;
        IF isFinished = 1 THEN LEAVE sendOffers;
        END IF;
        -- only send maximun 15 offer for non-elite vendor
        IF ( IsEliteVendor = 1 OR
			(SELECT COUNT(DISTINCT OrderId,SignerId) FROM signer_offer so WHERE so.orderId = orderId AND repId = -1 AND so.isEliteVendor = 0) < 15) 
        THEN INSERT INTO signer_offer(orderID,signerID,offerAmount,repID,sentDate,tenantId,isEliteVendor,distance,guid,offerStatus)
			 VALUES (orderId,signerId,amount,-1,UTC_TIMESTAMP(),1,IsEliteVendor,dist,uuid(),'O');
        END IF;
	END LOOP sendOffers;
    CLOSE myCursor;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CalculateBusinessHourTest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `CalculateBusinessHourTest`(
IN startDateTime DATETIME, 
IN endDateTime DATETIME, 
IN timeZone INT
)
BEGIN
	DECLARE startDateTimeLocal DATETIME;
    DECLARE startDateLocal DATE;
    DECLARE endDateTimeLocal DATETIME;
    DECLARE endDateLocal DATE;
    DECLARE currentDateTime DATETIME;
    DECLARE isClosed BIT;
    DECLARE isHoliday BIT;
    DECLARE dayOfWeek VARCHAR(50);
    
    DECLARE startCalculatedDateTime DATETIME;
    DECLARE endCalculatedDateTime DATETIME;
    DECLARE startOfCurrentDateTime DATETIME;
    DECLARE endOfCurrentDateTime DATETIME;
    
    DECLARE workStartTime TIME;
    DECLARE workEndTime TIME;
    
    DECLARE holidayOffStartTime TIME;
    DECLARE holidayOffEndTime TIME;
    
    DECLARE endCurrentDateTime DATETIME;
    DECLARE startCurrentDateTime DATETIME;
    
    DECLARE currentDate DATE;
    DECLARE currentTime TIME;
    
    DECLARE totalMinutes INT DEFAULT 0;
    
	SET startDateTimeLocal = DATE_ADD(startDateTime, INTERVAL timeZone HOUR);
    SET endDateTimeLocal = DATE_ADD(endDateTime, INTERVAL timeZone HOUR);
    SET endDateLocal =  DATE(endDateTimeLocal);
    SET startDateLocal = DATE(startDateTimeLocal);
    
    SET currentDateTime = startDateTimeLocal;
     WHILE(DATE(currentDateTime) <= endDateLocal)
     DO
		SET currentDate = DATE(currentDateTime);
		SET currentTime = TIME(currentDateTime);
		
        SELECT TIME(bh.OpenTime),TIME(bh.CloseTime), bh.isClose
		INTO workStartTime, workEndTime, isClosed
        FROM business_hours bh WHERE bh.dayOfWeek = DAYOFWEEK(currentDateTime);
        
		SET startOfCurrentDateTime= CONVERT(CONCAT(currentDate,' ','00:00:00'), DATETIME);
        SET endOfCurrentDateTime= CONVERT(CONCAT(currentDate,' ','23:59:59'), DATETIME);
		
        SELECT bhe.CloseTime, bhe.OpenTime, (CASE WHEN COUNT(bhe.OpenTime) > 0 THEN 1 ELSE 0 END)
        INTO holidayOffEndTime, holidayOffStartTime, isHoliday FROM biz_hours_except bhe 
						WHERE currentDate BETWEEN DATE(bhe.OpenTime) AND DATE(bhe.CloseTime) LIMIT 0,1;
		
		IF(isClosed = 0 OR isClosed IS NULL) 
        THEN
			IF (currentDate <> startDateLocal AND currentDate <> endDateLocal)
				THEN SET startCalculatedDateTime = startOfCurrentDateTime;
					 SET endCalculatedDateTime = endOfCurrentDateTime;
            ELSEIF (currentDate = startDateLocal AND currentDate <> endDateLocal)
				THEN SET startCalculatedDateTime = currentDateTime;
					 SET endCalculatedDateTime = endOfCurrentDateTime;
			ELSEIF (currentDate <> startDateLocal AND currentDate = endDateLocal)
				THEN SET startCalculatedDateTime = startOfCurrentDateTime;
					 SET endCalculatedDateTime = endDateTimeLocal;
			ELSE 	 SET startCalculatedDateTime = currentDateTime;
					 SET endCalculatedDateTime = endDateTimeLocal;
			END IF;	
            
			SET totalMinutes = totalMinutes + 
			(SELECT CASE WHEN isHoliday = 1 THEN 
				CalculateBusinessHourByOffTime(TIME(startCalculatedDateTime),TIME(endCalculatedDateTime),'04:30:00','18:30:00',holidayOffStartTime,holidayOffEndTime)
					ELSE CalculateBusinessHourByWorkingTime(startCalculatedDateTime,endCalculatedDateTime,workStartTime,workEndTime) END);				
		END IF;
		  
		SELECT currentDate,startCalculatedDateTime,endCalculatedDateTime,workStartTime,workEndTime,isClosed,isHoliday,holidayOffStartTime,holidayOffEndTime,totalMinutes;
		
        SET currentDateTime = DATE_ADD(currentDateTime,INTERVAL 1 DAY);
        
	END WHILE;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ChangeOrderFeeApproveStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `ChangeOrderFeeApproveStatus`(
    IN inOrderId INT,
	IN inFeeApprovalId INT,
    IN inFeeApproved VARCHAR(15),
    IN inOfferStatus VARCHAR(3),
    IN inSignerId INT,
    IN inSignerFee DECIMAL,
    In inFeeDescripId INT,
    IN inActivity VARCHAR(255),
    IN inUserId INT,
    IN inIsOveride BOOLEAN
)
BEGIN
main: BEGIN
	DECLARE isSuccess INT;
    DECLARE anotherOrderId INT;
    DECLARE anotherSignerId INT;
    
	-- ----------------------
	START TRANSACTION;
        
        -- // Check conditions for approve
        IF inFeeApproved = 'Approved' THEN
        
			-- Check vendor is having the same ADT order
			SELECT `OrderId` INTO anotherOrderId
				FROM `order`
				WHERE `OrderId` <> inOrderId
					AND `SignerId` = inSignerId
					AND `AptDateTime` = (SELECT `AptDateTime`
											FROM `order`
											WHERE `OrderId` = inOrderId);
											
			IF anotherOrderId IS NOT null AND anotherOrderId <> ''
			THEN
				SELECT 2 as isSuccess;
				LEAVE main;
			END IF;
			-- //
			
			-- Check order has another assigned Vendor
			SELECT `SignerId` INTO anotherSignerId
				FROM `order`
				WHERE `OrderId` = inOrderId;
			
			IF !inIsOveride AND anotherSignerId IS NOT null AND anotherSignerId <> '' AND anotherSignerId <> inSignerId
			THEN
				BEGIN
				SELECT 3 as isSuccess;
				LEAVE main;
				END;
			END IF;
			-- //
            
        END IF;
    
		-- Change status FeeApproved in order_fee_approve
		UPDATE `order_fee_approve`
			SET `FeeApproved` = inFeeApproved
			WHERE `FeeApprovalId` = inFeeApprovalId;
	
		-- Change status OfferStatus in signer_offer
		UPDATE `signer_offer`
			SET `OfferStatus` = inOfferStatus
			WHERE `OrderId` = inOrderId AND `SignerId` = inSignerId;
            
		-- Update signer Fee in order_fee
        UPDATE `order_fee`
			SET `SignerFee` = inSignerFee
            WHERE `OrderId` = inOrderId AND `FeeDescripId` = inFeeDescripId;
            
		-- Insert to order_progress_log
        INSERT INTO `order_progress_log`
			(`OrderId`, `Activity`, `UsersId`, `DateLog`)
			VALUES
			(inOrderId, inActivity, inUserId, UTC_TIMESTAMP());
            
		-- If status of order_fee_approve is Rejected
			-- OR user request is not a vendor
            -- leave the procedure with success status
		IF inFeeApproved != 'Approved' OR inSignerId IS NULL THEN
			SELECT 1 as isSuccess;
            COMMIT;
            LEAVE main;
		END IF;
        -- //
        
        -- Update SignerId of order
        UPDATE `order`
			SET `SignerId` = inSignerId
			WHERE `OrderId` = inOrderId;
            
		-- PENDING ADD NEW RECORD FOR VENDOR HISTORY
        
	COMMIT;
    SELECT 1 as isSuccess;
END main;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ChangeStatusClient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `ChangeStatusClient`(IN clientId int)
BEGIN
    declare brokerStatus bit;
    declare cancelProgressId int;
    declare	closeProgressId int;
    declare userId int;
    set brokerStatus = (select Inactive from broker where brokerid = clientId);
    set cancelProgressId = (select ProgressId from progress where ProgressDescription = "Canceled");
    set closeProgressId = (select ProgressId from progress where ProgressDescription = "Closing Completed");
    set userId = (select UsersId from Users where MappingUserId = clientId and UserName = concat('CLIENT',clientid));

    UPDATE broker 
    SET 
        Inactive = !brokerStatus
    WHERE
        brokerid = clientId;
    if(brokerStatus = 0) then
    UPDATE broker 
    SET 
        Inactive = 1
    WHERE
        GID = clientId;
    update agent set Inactive = 1 where brokerid = clientId;
    UPDATE `order` 
    SET 
        ProgressId = cancelProgressId
    WHERE
        brokerid = clientId
            AND ProgressId NOT IN (cancelProgressId, closeProgressId);
    end if;
    update users set Inactive = !brokerStatus where UsersId = userId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CheckClientSatisfiedVendor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `CheckClientSatisfiedVendor`(
	IN forOrderId int,
    IN forSignerId int
)
BEGIN
	SELECT BrokerId, CustomerId
	INTO @OrderBrokerId, @OrderCustomerId
	FROM `order` WHERE OrderId = forOrderId;

	DROP TEMPORARY TABLE IF EXISTS reqTrainingTable;
	CREATE TEMPORARY TABLE reqTrainingTable (ProgramId int);

	IF @OrderCustomerId IS NOT NULL
		THEN
			SELECT ReqRating, ReqExperienceNumber INTO @ReqRating, @ReqExperienceNumber FROM customers WHERE CustomerId = @OrderCustomerId;
			INSERT INTO reqTrainingTable
				SELECT CTR.ProgramId FROM
					customer_training_req CTR INNER JOIN training_programs TP ON
						CTR.ProgramId = TP.ProgramId 
						AND CTR.CustomerId = @OrderCustomerId
						AND TP.Inactive = 0
						AND TP.IsPublished = 1
				;
				
		ELSEIF @OrderBrokerId IS NOT NULL
			THEN
				SELECT ReqRating, ReqExperienceNumber INTO @ReqRating, @ReqExperienceNumber FROM broker WHERE BrokerId = @OrderBrokerId;
				INSERT INTO reqTrainingTable 
					SELECT BTR.ProgramId FROM
						broker_training_req BTR INNER JOIN training_programs TP ON
							BTR.ProgramId = TP.ProgramId 
							AND BTR.BrokerId = @OrderBrokerId
							AND TP.Inactive = 0
							AND TP.IsPublished = 1
					;
                    
		ELSE
			SET @ReqRating = NULL;
			SET @ReqExperienceNumber = NULL;
	END IF;

	IF (
		EXISTS
			(SELECT
				S.SignerId, S.Rating, COUNT(O.OrderId) AS NumberOfClosedOrder
			FROM
				signer S
				LEFT JOIN `order` O ON S.SignerId = O.SignerId AND O.ProgressId = 11
			WHERE
				S.SignerId = forSignerId
				AND (find_in_set(S.Rating, @ReqRating) OR @ReqRating IS NULL OR @ReqRating='')
				-- TRAINING REQUIREMENT
				AND (
					NOT EXISTS (
						SELECT RT.ProgramId FROM reqTrainingTable RT WHERE RT.ProgramId NOT IN (
							SELECT VRP.ProgramId FROM vendor_registered_programs VRP WHERE VRP.VendorId = S.SignerId AND VRP.IsComplete =1
						)
					))
			GROUP BY S.SignerId
			HAVING
				-- NUMBER OF CLOSED ORDER REQUIREMENT
				(COUNT(O.OrderId) >= @ReqExperienceNumber OR @ReqExperienceNumber IS NULL)
			)
		)
	THEN 
		SELECT TRUE AS isSatisfied;
	ELSE 
		SELECT FALSE AS isSatisfied;
	END IF;

	DROP TEMPORARY TABLE IF EXISTS reqTrainingTable;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CheckExistVendorOffer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `CheckExistVendorOffer`(
	IN aptDateTime datetime,
    IN signerId int,
    IN orderId int
)
BEGIN
	DECLARE IsValid int;
	DECLARE countOffer int;
    DECLARE getSignerID int;

    SET isValid = 0;

	SET getSignerID = (SELECT `order`.`signerId` AS count
	FROM `order`
	WHERE `order`.`OrderId` = orderId);

	IF getSignerID is null
	THEN IF aptDateTime IS NOT NULL 
		 THEN SET countOffer = (SELECT COUNT(`order`.`OrderId`) AS count
							FROM `order`
							WHERE `order`.`SignerId` = signerId	
							AND DATE_FORMAT(`order`.`AptDateTime`, "%Y%m%d%H%i") = DATE_FORMAT(aptDateTime, "%Y%m%d%H%i"));
		 
			 IF countOffer > 0 THEN SET isValid = 1;
             END IF;
		END IF;
	ELSE IF getSignerID = signerId
		 THEN SET isValid = 3;
		 ELSE SET isValid = 2;
		 END IF;
	END IF;

    SELECT isValid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeclinedVendorOffer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `DeclinedVendorOffer`(
	IN offerID int,
	IN orderId int,
    IN userId int,
    IN signerId int,
    IN selectedReasonOptions int, 
    IN altTime datetime,
    IN typeID int,
    IN offerAmount decimal(19,4),
    IN feeAmount decimal(19,4),
    IN additionalInfo varchar(250)
)
BEGIN
	DECLARE feeDescripID decimal(19,4);
    DECLARE protductTypeOriginalFee decimal(19,4);
    DECLARE maxFeeApprovalId int;
    
    IF (selectedReasonOptions = 2 OR selectedReasonOptions = 3)
    THEN       
		SELECT of.FeeDescripID, of.SignerFee into feeDescripID, protductTypeOriginalFee FROM `order_fee` of
		INNER JOIN `broker_fee` bf ON bf.`FeeId` = of.`FeeDescripID`
		WHERE of.`OrderID` = orderId AND bf.`IsAdditionalFee` = 0;
		
		IF(selectedReasonOptions = 2)
        THEN SET selectedReasonOptions = 8;
        END IF;
        
        IF(selectedReasonOptions = 3)
        THEN SET selectedReasonOptions = 9;
        END IF;
        
		UPDATE `signer_offer`
        SET `OfferStatus` = 'P'
		WHERE `signer_offer`.`OrderId` = orderId
        AND `signer_offer`.`SignerId` = signerId;
        
        INSERT INTO `order_fee_approve`(`OrderId`,`UsersId`,`FeeDescripID`,`ReasonCode`,`FeeReason`,`FeeAmount`,`FeeApproved`,`DateStamp`,`OriginalAmount`,`SignerID`, `OfferID`)
        VALUES (orderId,userId,feeDescripID, selectedReasonOptions, additionalInfo, protductTypeOriginalFee + (feeAmount - offerAmount),'Pending', UTC_TIMESTAMP(),protductTypeOriginalFee,signerId, offerID);
		SET maxFeeApprovalId = (SELECT LAST_INSERT_ID());
        
        INSERT INTO `comment`(`Description`,`CreatedDate`,`CreatedBy`,`TypeID`,`OwnerID`,`IsPrivate`)
        VALUES (additionalInfo, UTC_TIMESTAMP(), userId, typeID, maxFeeApprovalId, 0);
	ELSE       
		UPDATE `signer_offer`
        SET `DenialReasonID` = selectedReasonOptions,
			`AltTime` = altTime,
            `AdditionalInfo` = additionalInfo,
            `OfferStatus` = 'D'
		WHERE `signer_offer`.`OrderId` = orderId
        AND `signer_offer`.`SignerId` = signerId;
	END IF;		
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DelStatesAndLoantypesByAnnID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `DelStatesAndLoantypesByAnnID`(
IN announchement_id int
)
BEGIN

SET SQL_SAFE_UPDATES = 0;
delete  FROM announcements_state where AnnouncementID=announchement_id;
delete  From `announcements_loan_type` where AnnouncementID=announchement_id;
SET SQL_SAFE_UPDATES = 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `FilterCitiesOfStates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `FilterCitiesOfStates`(
	IN statesString VARCHAR(1000),
    IN citiesString VARCHAR(5000)
)
BEGIN
	declare pos int;           -- Keeping track of the next item's position
	declare item varchar(100); -- A single item of the input
	declare delimiterChar char(1) DEFAULT ';'; -- A single item of the input
	declare breaker int;       -- Safeguard for while loop

	-- Prepare
	SET statesString = REPLACE(statesString, delimiterChar, ','); 

	-- The string must end with the delimiter
	if right(citiesString, 1) <> delimiterChar then
		set citiesString = CONCAT(citiesString, delimiterChar);
	end if;

	DROP TABLE IF EXISTS SelectedCities;
	CREATE TEMPORARY TABLE SelectedCities ( CityName varchar(100) );
	SET breaker = 0;

	WHILE char_length(citiesString) > 1 DO
		-- Iterate looking for the delimiter, add rows to temporary table.
		SET breaker = breaker + 1;
		SET pos = INSTR(citiesString, delimiterChar);
		SET item = LEFT(citiesString, pos - 1);
		SET citiesString = SUBSTRING(citiesString, pos + 1);
		INSERT INTO SelectedCities values(item);
	END WHILE;
      
	SET @sqlQuery = CONCAT('SELECT DISTINCT City as name
		FROM zip z INNER JOIN SelectedCities s ON z.City = s.CityName
        WHERE z.State IN(', statesString, ')');

	PREPARE stmt FROM @sqlQuery;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    DROP TABLE IF EXISTS SelectedCities;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAdditionalFeeForOrder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAdditionalFeeForOrder`(
	order_id INT
)
BEGIN
    SELECT 
		b.FeeId,
        b.FeeDescription AS Description,
        b.BrokerFee AS DefaultBrokerFee,
        i.VendorFee AS DefaultSignerFee
	FROM `broker_fee` AS b
    INNER JOIN `industry_transaction_fees` AS i ON b.SystemFee=i.FeeId
    INNER JOIN `order` AS o ON o.BrokerId=b.BrokerId  and o.LoanType=b.LoanTypeId
    WHERE o.OrderId = order_id 
		AND b.IsAdditionalFee = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAgentByOption` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAgentByOption`(
IN brokerId int,
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN agentId int,
IN agentName varchar(255),
IN agentEmail varchar(255),
IN company varchar(255),
IN userName varchar(255)
)
BEGIN

    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

    SET whereQuery = CONCAT(' WHERE 1=1 AND (rp.Type="Client" and rp.RoleName="Agent") AND (a.BrokerId = ', brokerId, ' ', 'OR b.GID = ', brokerId, ' )');

    IF (agentId IS NOT NULL AND agentId > 0)
        THEN SET whereQuery = CONCAT(whereQuery, ' AND agentID = ', agentId , ' ');
    END IF;

    IF (agentName IS NOT NULL AND agentName <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND FullName LIKE ''%', agentName, '%''');
    END IF;

    IF (agentEmail IS NOT NULL AND agentEmail <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND a.Email LIKE ''%', agentEmail, '%''');
    END IF;
    
    IF(company IS NOT NULL AND company <> '') 
		THEN SET whereQuery = CONCAT(whereQuery, ' AND b.Company LIKE ''%', company, '%''');
	END IF;

	IF(userName IS NOT NULL AND userName <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND u.UserName LIKE ''%', userName, '%''');
	END IF;

    SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS 
        a.AgentId, b.Company, a.FullName, a.Ext, a.Email, a.Fax, u.UserName, a.Inactive, a.FirstName, a.LastName
		from agent as a
		INNER JOIN broker AS b ON b.brokerid = a.brokerid
		LEFT JOIN users AS u on u.MappingUserId = a.AgentId
        LEFT JOIN user_roles as ur ON u.UsersId=ur.UsersId
        LEFT JOIN roles as rp ON rp.RoleId=ur.RoleId', 
        whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAgents` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAgents`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';
     
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			AgentId,
			FullName,
            Direct,
            Ext,
            Fax,
            Email,
            AfterhoursPhone,
            CAST(InActive AS unsigned) AS InActive 
            FROM agent, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAgentsByBrokerId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAgentsByBrokerId`(
IN brokerId int,
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE a.BrokerId = ', brokerId, ' OR br.gId= ', brokerId);
   
	SET @querySql= concat('
    SELECT 
    SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			a.AgentId,
			a.FullName,
            a.Direct,
            a.Ext,
            a.Fax,
            a.Email,
            a.AfterhoursPhone,
			(CASE WHEN tbl.isDisabled IS NULL THEN FALSE
            ELSE TRUE END) as isDisabled,
            CAST(a.InActive AS unsigned) AS InActive 
            FROM agent a
            LEFT JOIN broker br ON a.brokerId = br.brokerId 
            LEFT JOIN (SELECT  COUNT(*) as isDisabled , ord.agentId FROM `order` ord 
            WHERE ord.progressId NOT IN (10,12)
            GROUP BY ord.agentId) tbl ON tbl.agentId = a.AgentId
            , (SELECT @rownum := 0) r ',
            whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAlert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAlert`(
	IN pageNumber int,
	IN pageSize int,
    IN role varchar(255),
	IN userId int,
    IN accountId int
)
BEGIN
	DECLARE orderQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(500);  
    DECLARE andWhereQuery varchar(500);
	IF (role = 'Client') 
		THEN SET andWhereQuery = CONCAT(' AND (o.BrokerId=',userId,' or o.BrokerId in (select Brokerid from `broker` where `broker`.GID = ',userId, '))');
	ELSE IF  (role = 'Vendor') 
		THEN SET andWhereQuery = CONCAT(' AND op.DateLog >= o.FilledDate AND o.SignerId =',userId);
	ELSE IF (role = 'Agent') 
		THEN SET andWhereQuery = CONCAT(' AND o.AgentId=',userId);
	ELSE IF (role = 'Branch') 
		THEN SET andWhereQuery = CONCAT(' AND o.BrokerId=',userId);
	ELSE IF (role = 'Staff') 
		THEN SET andWhereQuery = CONCAT(' AND o.RepId=',userId);
		END IF;
	END IF;
	END IF;
    END IF;
    END IF;
       
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    SET whereQuery = CONCAT(' op.UsersId <> ', accountId, andWhereQuery);
	
	SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS
			op.progressLogId,
			op.orderId,
			op.DateLog,
			op.activity,
            op.isRead,
            op.UsersId,
            GetProfilePictureByUserId(op.UsersId) as img,
            o.aptDateTime,
            o.IsSelfService
            FROM `order` as o
            INNER JOIN zip ON o.Zip = `zip`.Zip
            INNER JOIN `order_progress_log` as op ON o.OrderId=op.orderId Where (op.isRead is null or op.isRead = 0) and op.ProgressType = 1 and' , whereQuery,' ORDER BY op.DateLog DESC, op.progressLogId DESC ', limitQuery);
	
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllAlert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllAlert`(
	IN pageNumber int,
	IN pageSize int,
    IN role varchar(255),
	IN userId int,
    IN accountId int,
    IN isSelfService int
)
BEGIN
	DECLARE orderQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(500);  
    DECLARE andWhereQuery varchar(500);
	IF (role = 'Client') 
		THEN SET andWhereQuery = CONCAT(' AND (o.BrokerId=',userId,' or o.BrokerId in (select Brokerid from `broker` where `broker`.GID = ',userId, '))');
	ELSE IF  (role = 'Vendor') 
		THEN SET andWhereQuery = CONCAT(' AND op.DateLog >= o.FilledDate AND o.SignerId =',userId);
	ELSE IF (role = 'Agent') 
		THEN SET andWhereQuery = CONCAT(' AND o.AgentId=',userId);
	ELSE IF (role = 'Branch') 
		THEN SET andWhereQuery = CONCAT(' AND o.BrokerId=',userId);
	ELSE IF (role = 'Staff') 
		THEN SET andWhereQuery = CONCAT(' AND o.RepId=',userId);
		END IF;
	END IF;
	END IF;
    END IF;
    END IF;
    
    IF (isSelfService= 1) 
		THEN SET andWhereQuery = CONCAT(' AND o.IsSelfService = 1', andWhereQuery);
	ELSE IF(isSelfService= 0)
		THEN SET andWhereQuery = CONCAT(' AND o.IsSelfService <> 1', andWhereQuery);
	END IF;
    END IF;
       
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

    SET whereQuery = CONCAT(' and op.UsersId <> ', accountId, andWhereQuery);
                            
	
	SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS
			op.progressLogId,
			op.orderId,
			op.DateLog,
			op.activity,
            op.isRead,
            op.UsersId,
            o.aptDateTime
            FROM `order` as o
            INNER JOIN zip ON o.Zip = `zip`.Zip
            INNER JOIN `order_progress_log` as op ON o.OrderId=op.orderId where op.ProgressType = 1' , whereQuery,' ORDER BY op.DateLog DESC, op.progressLogId DESC ', limitQuery);
	
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllBranch` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllBranch`()
BEGIN
    SELECT `BrokerID`, `Company`, `Phone`, `CONCAT_WS(" ", PrimaryContactLast, PrimaryContactFirst) AS ContactName`, `Email`, `Inactive`
    FROM `broker`;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllCorrectionRequest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllCorrectionRequest`()
BEGIN
    SELECT Id, Description 
	FROM problem_types where ParentId is null
    ORDER BY Description;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllDocs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllDocs`(	
	IN orderId int(11)
)
BEGIN
    DECLARE whereQuery varchar(255);
    DECLARE orderQuery varchar(255);
    
    SET whereQuery = ' WHERE 1=1 ';
    SET orderQuery = ' ORDER BY UploadedDate ASC';
    SET whereQuery = CONCAT(whereQuery, ' AND (od.Archive is null or od.Archive <> 1) AND od.DocumentType=1');
     
	IF(orderId IS NOT NULL AND orderId <> 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND od.OrderId= ', orderId);
	END IF;
     
	set @querySql = CONCAT('select od.DocId as `DocId`,
									od.Description as `Description`,
									od.UploadedDate as `UploadedDate`,
                                    od.DownloadDate as `DownloadDate`,
                                    od.DocumentType as `DocumentType`,
									if(o.DocumentCompletedDate is null, true, false) as `DocumentCompleted`
							FROM (order_docs as od
                            INNER JOIN `order` as o ON od.OrderId = o.OrderId)', whereQuery, orderQuery );


    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllFee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllFee`(
)
BEGIN
    SELECT FeeDescriptionId as FeeId, Description, DefaultBrokerFee, DefaultSignerFee
	FROM fee_description
    WHERE Active = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllLoanType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllLoanType`()
BEGIN
   SELECT LoanTypeId,LoanType  FROM loan_type order by LoanTypeId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllManagerInternalUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllManagerInternalUser`(
	IN repId INT(11),
    IN repName varchar(255),
    IN repEmail varchar(255),
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(500);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RepId ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE `roles`.TYPE="Staff" and (IsDeleted=false or IsDeleted is null) ');
    
    IF (repId IS NOT NULL AND repId >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `RepId` = ', repId);
	END IF;
    
    IF (repName IS NOT NULL AND repName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND CONCAT(`employees`.`FirstName`, \' \', `employees`.`LastName`) LIKE ''%', repName, '%''');
	END IF;
    
    IF (repEmail IS NOT NULL AND repEmail <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Email` LIKE ''%', repEmail, '%''');
	END IF;
    
     
     set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS t1.* from (select distinct
									`employees`.RepId as `RepId`,
									CONCAT(`employees`.`FirstName`, \' \', `employees`.`LastName`) as `FullName`,  
									`employees`.Email as `Email`,
                                    `employees`.Ext as `Ext`,
                                    `employees`.Active as `Active`,
                                    `employees`.IsDeleted as `IsDeleted`,
                                    
                                    `roles`.Type as `Type`,
                                    CASE WHEN Dnd = 1 THEN \'Do Not Disturb\' ELSE 
										CASE WHEN LoggedIn = 1 THEN \'Available\' ELSE 
											CASE WHEN OutOfOffice = 1 THEN \'Offline\' ELSE \'Offline\' 
                                            END 
										END 
									END as `Status`,
                                    group_concat(DISTINCT `roles`.RoleName ORDER BY `roles`.RoleName asc separator \',\') as RoleName
							FROM `employees`  
                            INNER JOIN `users` on `employees`.RepId = `users`.MappingUserId
                            INNER JOIN `user_roles` on `users`.UsersId = `user_roles`.UsersId   
							INNER JOIN `roles` on `user_roles`.RoleId = `roles`.RoleId '
                            , whereQuery, 
                            ' GROUP BY `employees`.RepId ', orderQuery,
                            ' ) t1, (SELECT @rownum := 0) r ', limitQuery);
                            
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
    SELECT Id, Description FROM problem_status;
    SELECT Id, Description FROM problem_types;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllOrderIssuesByVendor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllOrderIssuesByVendor`(
	IN InDescription varchar(3000),
	IN InOrderId int,
	IN InDuration int,
	IN InStatus int,
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       	THEN SET orderQuery = ' ORDER BY Date ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    

	SET whereQuery = 'WHERE order_problem.Mistake=1';

	IF (InOrderId IS NOT NULL) THEN 
		SET whereQuery = CONCAT(whereQuery, ' AND (OrderId=', InOrderId, ')');
	END IF;

     
     set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS order_problem.OrderId, order_problem.ProblemId,
            order_problem.Date, order_problem.Mistake ,
            GetFullNameByUserId(CreatedUser.UsersId) as CreatedBy, CreatedUser.UserName,
            problem_status.Description as Status,
            problem_types.Description as Type
            FROM order_problem
            LEFT JOIN problem_types ON (order_problem.Type=problem_types.Id)
            LEFT JOIN users as CreatedUser ON (order_problem.EnteredBy=CreatedUser.UsersId)
            LEFT JOIN problem_status ON (order_problem.Status=problem_status.id)
            ', whereQuery, orderQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
SELECT FOUND_ROWS() AS TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllProductType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllProductType`(
	IN loanType varchar(255),
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' HAVING 1=1 ');
    
	IF (loanType IS NOT NULL AND loanType <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `LoanType` LIKE ''%', loanType, '%''');
	END IF;
    
     set @querySql = CONCAT('
							SELECT SQL_CALC_FOUND_ROWS `loan_type`.LoanType AS `LoanType`, LoanTypeId, COUNT(`order`.OrderId) AS AmountOfOrder
							FROM `loan_type` LEFT JOIN `order` ON `loan_type`.LoanTypeId = `order`.LoanType GROUP BY LoanType
							', whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllReasonCodes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllReasonCodes`(
)
BEGIN  
	SELECT 
		ReasonCode,
        ReasonDescription
    FROM order_fee_approve_reason
    WHERE `Type` = 'S';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllRolePermission` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllRolePermission`()
BEGIN
    SELECT `RoleName`, `RoleId`
	FROM `roles` where Type in ('Staff');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllSignersApproval` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllSignersApproval`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN searchOrderID int,
IN searchStatus varchar(255),
IN searchRequestBy varchar(255)
)
BEGIN
    DECLARE orderIDWhereSql varchar(255);
    DECLARE statusWhereSql varchar(255);
    DECLARE signersApprovalTableSql varchar(255);
    
    DECLARE requestByWhereSql varchar(255);
    DECLARE employeesTableSql varchar(255);
    
    DECLARE searchedTableSql varchar(1000);
    DECLARE resultTableSql varchar(1100);
    
	DECLARE orderSql varchar(255);
	DECLARE sortDirectionSql varchar(255);
    DECLARE limitSql varchar(255);

	IF (searchOrderID IS NULL)
	THEN SET orderIDWhereSql = '';
	ELSE SET orderIDWhereSql = CONCAT(' AND SA.OrderId = ', searchOrderID);
    END IF;
    
    
    SET searchedTableSql = CONCAT('SELECT SA.* FROM signers_approval SA WHERE TRUE', orderIDWhereSql);
    
	-- limit searchResult
    SET limitSql = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ', ', pageSize);
        
    -- sort
	IF (sortDirection = 1) 
		THEN SET sortDirectionSql = ' ASC';
	ELSE SET sortDirectionSql = ' DESC';
    END IF;
	-- SELECT sortDirectionQuery;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderSql = ' ORDER BY RequestDate ';
	ELSE SET orderSql = CONCAT(' ORDER BY ', sortBy, sortDirectionSql);
    END IF;
    
    -- join order and signer table to get more information -> sort
    SET resultTableSql = CONCAT('SELECT SQL_CALC_FOUND_ROWS SA.*,
    S.Email as Email, 
    SO.Distance,
    SO.OfferAmount,
    SA.RequestDate,
    U.UserName,
    UA.UserName AS ApprovedBy,
    CONCAT(S.LastName, " ", S.FirstName) as VendorName, 
    C.Description,
    U.UserName,
    O.City,
    LO.LoanType,
	A.FullName 
    FROM (', searchedTableSql, ') SA 
    LEFT JOIN `order` O ON SA.OrderId = O.OrderId
    LEFT JOIN agent A ON O.AgentId = A.AgentId
    left join comment C on C.commentId = (
    SELECT
      cm2.commentId
    FROM comment cm2
    WHERE cm2.ownerId = SA.approvalId 
    ORDER BY cm2.CreatedDate DESC LIMIT 1 )
	LEFT JOIN `users` U ON SA.RequestBy = U.UsersId
    LEFT JOIN `users` UA ON UA.UsersId = SA.ApprovedBy
    left join `loan_type` LO on O.LoanType = LO.LoanTypeId
    LEFT JOIN `signer_offer` SO ON SO.OfferID = (
    SELECT
      MIN(SO2.OfferID)
    FROM signer_offer SO2
    WHERE SO2.SignerId = SA.SignerId and SA.OrderId = SO2.OrderId
	)
    LEFT JOIN signer S ON S.SignerId = SA.SignerId', orderSql, limitSql,';');
	SET @querySql= resultTableSql;
    
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    SELECT COUNT(*) AS CountOpen FROM signers_approval WHERE Status='Open';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllState` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllState`()
BEGIN
    SELECT `Code`, `Description` 
	FROM `state`
    ORDER BY Code;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllTrainingLearningPath` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllTrainingLearningPath`(
	IN lPName varchar(255),
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE 1=1 ');
    
	IF (lPName IS NOT NULL AND lPName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `LPName` LIKE ''%', lPName, '%''');
	END IF;
    
     set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS
									`training_learning_path`.LPID as `LPID`,
									`training_learning_path`.LPName as `LPName`,
									`training_learning_path`.Description as `Description`
							FROM training_learning_path', whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllVendorCredentialDocument` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllVendorCredentialDocument`(
	IN docType varchar(255),
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' HAVING 1=1 ');
    
	IF (docType IS NOT NULL AND docType <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `docType` LIKE ''%', docType, '%''');
	END IF;
    
     set @querySql = CONCAT('
							SELECT SQL_CALC_FOUND_ROWS `signer_doctypes`.DocTypeID, DocType,
                            case when Expires then ''Yes'' else ''No'' end as Expires,
                            States,
                            FileName,
                            case when IsRequiredDoc then ''Yes'' else ''No'' end as IsRequiredDoc,
                            COUNT(`signer_docs`.DocId)  AS AmountOfSignerDoc
							FROM `signer_doctypes`
                            LEFT JOIN `signer_docs` ON `signer_doctypes`.DocTypeID = `signer_docs`.DocTypeId GROUP BY DocTypeID
							', whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllVendorHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllVendorHistory`(
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN orderId int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY HistoryDate ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE 1=1 ');
    
    IF(orderId IS NOT NULL AND orderId >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `OrderId` = ', orderId);
	END IF;
     
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS t1.* from (select
									`signer_history`.HistoryDate as `HistoryDate`,
                                    `signer_history`.SignerId as `SignerId`,
                                    `signer_history`.OrderId,
                                    CONCAT(`signer`.FirstName, " ",`signer`.LastName) as `SignerName`, 
                                    `signer_history`.Status as `Status`
							FROM `signer_history`  
                            LEFT JOIN `signer` on `signer_history`.SignerId = `signer`.SignerId
                            ) t1, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllVendorSentOffer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllVendorSentOffer`(
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN orderId int
)
BEGIN
  DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY OfferID ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE 1=1 ');
     
	IF(orderId IS NOT NULL AND orderId >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `OrderId` = ', orderId);
	END IF;
     
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS t1.* from (select
									`signer_offer`.OfferID as `OfferID`,
                                    `signer_offer`.OfferAmount as `OfferAmount`,
                                    `signer`.LastName as `LastName`,
                                    `signer_offer`.OrderId,
									`signer`.FirstName as `FirstName`,
                                    CASE WHEN OfferStatus = "A" THEN \'Accepted\'  
										 WHEN OfferStatus = "D" THEN \'Declined\'  
										 WHEN OfferStatus = "N" THEN \'No Response\'  
										 WHEN OfferStatus = "M" THEN \'Missed\' 
                                         WHEN OfferStatus = "O" THEN \'Open\' 
                                         ELSE ''''
									END as `OfferStatus`,
                                    (CASE WHEN `users`.UserName IS NULL THEN ''System'' ELSE `users`.UserName END) as `RepId`,
                                    `signer_offer`.SentDate as `SentDate`,
                                    `signer_offer`.ResponseDate as `ResponseDate`,
									if(`signer_offer`.Sent = true, "Y", "N") as `Sent`
							FROM `signer_offer`  
                            left join `signer` on `signer_offer`.SignerId = `signer`.SignerId
                            left join `users` on `signer_offer`.RepId = `users`.UsersId
                            ) t1, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAnnouncementInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAnnouncementInfo`(
IN announcement_id int
)
BEGIN
    select annt.State as Code,st.Description from `announcements_state` annt join `state` st on annt.State=st.Code where AnnouncementID=announcement_id;
	select annlt.LoanTypeId, loan_type.LoanType from `announcements_loan_type` annlt join `loan_type` on annlt.LoanTypeId= loan_type.LoanTypeId where AnnouncementID=announcement_id;
	select AnnouncementID,CreatedDate,Title,Content,Audience,`Status`,NumOfAppearance from `announcements` where announcementID=announcement_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAnnouncements` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAnnouncements`(
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN status varchar(255),
	IN audience varchar(50),
    IN title varchar(255)
)
BEGIN	
    DECLARE orderQuery varchar(255) DEFAULT '';
	DECLARE sortDirectionQuery varchar(255);
    DECLARE limitQuery varchar(255) DEFAULT '';  
    DECLARE whereQuery varchar(255) DEFAULT ' WHERE 1 ';
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    SET orderQuery = CONCAT(' ORDER BY announcements.AnnouncementID ',sortDirectionQuery);
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

	IF (status IS NOT NULL AND status!='' ) 
		THEN  SET whereQuery = CONCAT(whereQuery, ' AND announcements.Status = \'', status,'\'');
    END IF;
    
	IF (audience IS NOT NULL AND audience!='') 
		THEN  SET whereQuery = CONCAT(whereQuery, ' AND announcements.Audience = \'', audience,'\'');
    END IF;
    
    IF (title IS NOT NULL AND title!='') 
		THEN  SET whereQuery = CONCAT(whereQuery, ' AND announcements.Title LIKE ''%',title, '%''');
    END IF;
    
	IF (whereQuery=' WHERE 1 ' ) 
		THEN  SET whereQuery = ' ';
    END IF;
       
	SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
    t1.* FROM (
		select AnnouncementID,CreatedDate,Title,Content,Status,Audience,NumOfAppearance 
        from announcements ',
        whereQuery,orderQuery,
        ') AS t1, (SELECT @rownum := 0) r ' ,limitQuery);
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetApprovalFeeRequests` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetApprovalFeeRequests`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN orderId varchar(255),
IN status varchar(255),
IN brokerId varchar(255)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(500);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY date ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = CONCAT(' WHERE (o.brokerid = ', brokerId, ' or o.brokerId in (select brokerId from broker where gid= ',
    brokerId ,')) and (case when o.agentId is null then per.RoleName end =''Vendor'' OR
            case when o.agentId is not null then per.RoleName end =''Agent'')');
	IF (status IS NOT NULL AND status <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND f.FeeApproved = ''', status, '''');
	END IF;
    IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND f.OrderId = ', orderId);
	END IF;
    
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
		f.feeApprovalId as approvalId,
		f.DateStamp AS date,
        f.orderId,
        concat(s.lastname, '' '', s.firstname) as vendorName,
        GetTotalAdditionalVendorFee(f.OrderID, FeeDescripId) + IFNULL(FeeAmount, 0) AS feeAmount,
        f.feeAmount + IFNULL(fee.OriginalSignerFee, 0) as feeUpdate,
        fee.OriginalSignerFee as originalAmount,
        r.ReasonDescription as reason,
        f.FeeApproved as status,
        f.usersId, 
        s.signerId, 
        f.feeDescripId,
        o.aptDateTime, 
        f.offerId,
        u.UserName as approvedBy
	FROM `order_fee_approve` AS f
    inner join (select orderid, sum(OriginalSignerFee) OriginalSignerFee from `order_fee` group by orderid) fee  on f.OrderId = fee.OrderID
    inner join `order_fee_approve_reason` r on f.ReasonCode = r.ReasonCode
    inner join `order` as o on f.OrderId=o.OrderId
    left join `signer` s on f.signerid = s.signerid
    inner join `users` AS u ON u.UsersId = f.UsersId
    inner join `user_roles` role on u.UsersId=role.UsersId
    inner join `roles` per on role.RoleId=per.RoleId, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetApprovalFeeRequestsTCE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetApprovalFeeRequestsTCE`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN orderId varchar(255),
IN status varchar(255),
IN userId int,
IN isClientFee boolean
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(500);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY date ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = CONCAT(' WHERE (o.IsSelfService = 0 OR o.IsSelfService IS NULL) ');
	IF (status IS NOT NULL AND status <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND f.FeeApproved = ''', status, '''');
	END IF;
    
    IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND f.OrderId = ', orderId);
	END IF;
    
    IF(userId IS NOT NULL AND userId <> '' AND !isClientFee)
		THEN SET whereQuery = CONCAT(whereQuery, ' AND ( f.UsersId = ', userId, ' OR o1.RepId = ', userId, ' ) ');
	ELSE
		SET whereQuery = CONCAT(whereQuery, ' AND ( f.UsersId = ', userId,' ) ');
    END IF;
    
	SET @querySql= concat('SELECT DISTINCT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
		f.feeApprovalId as approvalId,
		f.DateStamp AS date,
        f.orderId,
        concat(s.lastname, '' '', s.firstname) as vendorName,
        GetTotalAdditionalVendorFee(f.OrderID, f.FeeDescripId) + IFNULL(FeeAmount, 0) AS feeAmount,
        f.feeAmount + IFNULL(fee.OriginalSignerFee, 0) as feeUpdate,
        of.BrokerFee AS clientFee,
        fee.OriginalSignerFee as originalAmount,
        r.ReasonDescription as reason,
        f.FeeApproved as status,
        f.usersId, 
        s.signerId, 
        f.feeDescripId,
        o.aptDateTime, 
        f.offerId,
        u.UserName as approvedBy,
        u1.UserName as requestedBy
	FROM `order_fee_approve` AS f
    inner join (select orderid, sum(OriginalSignerFee) OriginalSignerFee from `order_fee` group by orderid) fee  on f.OrderId = fee.OrderID
    inner join `order_fee_approve_reason` r on f.ReasonCode = r.ReasonCode
    inner join `order` as o on f.OrderId=o.OrderId
    LEFT JOIN `order_fee` AS of ON of.OrderID=f.OrderId AND of.FeeDescripID = f.FeeDescripId
    LEFT JOIN users as u on u.UsersId = f.ApprovedBy
    LEFT JOIN users as u1 on u1.UsersId = f.UsersId
    left join `signer` s on f.signerid = s.signerid
    left join `order` as o1 on f.SignerID = o1.signerid, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
    
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetApprovalVendorRequests` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetApprovalVendorRequests`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN orderId varchar(255),
IN status varchar(255),
IN requestBy varchar(255),
IN brokerId varchar(255)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY date ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = CONCAT(' WHERE (o.brokerid = ', brokerId, ' or o.brokerId in (select brokerId from broker where gid= ',
    brokerId ,')) and per.RoleName=''Agent''');
	IF (status IS NOT NULL AND status <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND s.status = ''', status, '''');
	END IF;
    IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND s.OrderId = ', orderId);
	END IF;
    IF (requestBy IS NOT NULL AND requestBy <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND u.UserName LIKE ''%', requestBy, '%''');
	END IF;
    
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, 
		s.ApprovalID as approvalId,
		s.RequestDate AS date,
        s.orderId,
        u.UserName AS requestedBy,
        concat(r.LastName, '' '', r.firstname) as vendorName,
        s.Reason as reason,
        s.status,
        s.signerId,
        GetFirstComment(4, s.ApprovalID) as comment,
        u.usersId,
        o.aptDateTime
	FROM `signers_approval` AS s
    inner join `signer` r on s.SignerId = r.SignerId
    inner join `order` o on s.OrderId=o.OrderId
    inner JOIN `users` AS u ON u.UsersId = s.RequestBy
    inner join `user_roles` role on u.UsersId=role.UsersId
    inner join `roles` per on role.RoleId=per.RoleId, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetApprovalVendorRequestsTCE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetApprovalVendorRequestsTCE`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN orderId varchar(255),
IN status varchar(255),
IN requestBy varchar(255)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(500);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY date ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = CONCAT(' WHERE (o.IsSelfService = 0 OR o.IsSelfService IS NULL) ');
	IF (status IS NOT NULL AND status <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND s.status = ''', status, '''');
	END IF;
    IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND s.OrderId = ', orderId);
	END IF;
    IF (requestBy IS NOT NULL AND requestBy <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND u.UserName LIKE ''%', requestBy, '%''');
	END IF;
    
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, 
		s.ApprovalID as approvalId,
		s.RequestDate AS date,
        s.orderId,
        u.UserName AS requestedBy,
        concat(r.LastName, '' '', r.firstname) as vendorName,
        s.Reason as reason,
        s.status,
        s.signerId,
        GetFirstComment(4, s.ApprovalID) as comment,
        u.usersId,
        o.aptDateTime
	FROM `signers_approval` AS s
    inner join `signer` r on s.SignerId = r.SignerId
    inner join `order` o on s.OrderId=o.OrderId
    inner JOIN `users` AS u ON u.UsersId = s.RequestBy, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
    
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAvailableSigner` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAvailableSigner`(
	IN `sortBy` VARCHAR(255),
	IN `sortDirection` BIT,
	IN `pageNumber` INT,
	IN `pageSize` INT,
	IN `whereText` VARCHAR(500),
	IN `brokerId` INT
)
BEGIN
    DECLARE orderQuery varchar(255);
	DECLARE sortDirectionQuery varchar(255);
    DECLARE limitQuery varchar(255);
    DECLARE whereQuery varchar(1000);

	SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
      
	IF (whereText IS NULL OR whereText = '')
       THEN SET whereQuery = CONCAT('WHERE SignerId NOT IN (SELECT SignerId FROM broker_donotuse WHERE BrokerId = ',brokerId, ')');
	ELSE SET whereQuery = CONCAT(
	 ' WHERE ( s.SignerId = \'',
	 whereText,
	 '%\' OR CONCAT(s.FirstName, " ", s.LastName) LIKE \'%',
	 whereText,
	 '%\'
	  ) AND SignerId NOT IN (SELECT SignerId FROM broker_donotuse WHERE BrokerId = ', brokerId, ')'
	 );
    END IF;    
         
	SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
				s.SignerId,
				concat(s.FirstName, " ", s.LastName) as Name,
				concat(s.WeekdayCity, ", ", s.WeekdayState) as CityState
				FROM signer s
				, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

   SELECT FOUND_ROWS() as TotalRecords;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAvailableVendorCustomer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAvailableVendorCustomer`(
    IN `sortBy` VARCHAR(255),
    IN `sortDirection` BIT,
    IN `pageNumber` INT,
    IN `pageSize` INT,
    IN `whereText` VARCHAR(150),
    IN `brokerId` INT,
    IN `customerId` INT
)
BEGIN
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(500);

	IF (pageNumber > 1 )
		THEN SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	ELSE SET limitQuery = '';
    END IF;
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
      
	IF (whereText IS NULL OR whereText = '')
       THEN SET whereQuery = CONCAT('WHERE SignerId NOT IN (SELECT SignerId FROM broker_donotuse WHERE BrokerId = ',brokerId, ')
		AND SignerId NOT IN (SELECT SignerId FROM customer_donotuse WHERE CustomerId = ', customerId, ')');
	ELSE SET whereQuery = CONCAT(
	 ' WHERE ( s.SignerId = \'',
	 whereText,
	 '%\' OR CONCAT(s.FirstName, " ", s.LastName) LIKE \'%',
	 whereText,
	 '%\'
	  ) AND SignerId NOT IN (SELECT SignerId FROM broker_donotuse WHERE BrokerId = ', brokerId, ')
		AND SignerId NOT IN (SELECT SignerId FROM customer_donotuse WHERE CustomerId = ', customerId, ')'
	 );
    END IF;        
	SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
				s.SignerId,
				concat(s.FirstName, " ", s.LastName) as Name,
				concat(s.WeekdayCity, ", ", s.WeekdayState) as CityState
				FROM signer s
				, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

   SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAvailableVendorCustomerDemo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetAvailableVendorCustomerDemo`(
    IN `sortBy` VARCHAR(255),
    IN `sortDirection` BIT,
    IN `pageNumber` INT,
    IN `pageSize` INT,
    IN `whereText` VARCHAR(150),
    IN `brokerId` INT,
    IN `customerId` INT
)
BEGIN
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(500);

    IF (pageNumber > 1)
		THEN SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	ELSE SET limitQuery = '';
	END IF;
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
      
	IF (whereText IS NULL OR whereText = '')
       THEN SET whereQuery = CONCAT('WHERE SignerId NOT IN (SELECT SignerId FROM broker_donotuse WHERE BrokerId = ',brokerId, ')
		AND SignerId NOT IN (SELECT SignerId FROM customer_donotuse WHERE CustomerId = ', customerId, ')');
	ELSE SET whereQuery = CONCAT(
	 ' WHERE ( s.SignerId = \'',
	 whereText,
	 '%\' OR CONCAT(s.FirstName, " ", s.LastName) LIKE \'%',
	 whereText,
	 '%\'
	  ) AND SignerId NOT IN (SELECT SignerId FROM broker_donotuse WHERE BrokerId = ', brokerId, ')
		AND SignerId NOT IN (SELECT SignerId FROM customer_donotuse WHERE CustomerId = ', customerId, ')'
	 );
    END IF;        
	SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
				s.SignerId,
				concat(s.FirstName, " ", s.LastName) as Name,
				concat(s.WeekdayCity, ", ", s.WeekdayState) as CityState
				FROM signer s
				, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

   SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetBizHoursExcept` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetBizHoursExcept`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255); 
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '' OR sortBy='index')
       THEN SET orderQuery = ' ORDER BY exceptId ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	   
	SET @querySql= concat('
    SELECT SQL_CALC_FOUND_ROWS
		ExceptID AS exceptId, Description AS description, OpenTime AS openTime, CloseTime AS closeTime, ExceptDate AS startDate, ExceptDate AS endDate, Closed AS closed FROM biz_hours_except ',
		orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetBlackListSigner` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetBlackListSigner`(
	IN `sortBy` VARCHAR(255),
	IN `sortDirection` BIT,
	IN `pageNumber` INT,
	IN `pageSize` INT,
	IN `brokerId` INT
)
BEGIN

    DECLARE orderQuery varchar(255);  
	 DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  

	SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
      
	SET whereQuery = CONCAT(' WHERE brokerId = ',brokerId); 
         
	SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
					b.Id, s.SignerId, CONCAT(s.FirstName, " ", s.LastName) AS Name, 
					CONCAT(s.WeekdayCity, ", ", s.WeekdayState) AS CityState,
					b.Comment, b.Timestamp AS AddedDate
				FROM broker_donotuse b
					LEFT JOIN signer s ON b.SignerId = s.SignerId
				, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	   
   SELECT FOUND_ROWS() as TotalRecords;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetBlackListSignerCustomer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetBlackListSignerCustomer`(
    IN `sortBy` VARCHAR(255),
	IN `sortDirection` BIT,
	IN `pageNumber` INT,
	IN `pageSize` INT,
    IN `customerId` INT
)
BEGIN
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(500);  

	IF (pageNumber > 1 )
		THEN SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	ELSE SET limitQuery = '';
    END IF;
	
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
      
	SET whereQuery = CONCAT(' WHERE customerId = ',customerId); 
         
	SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
					b.Id, s.SignerId, CONCAT(s.FirstName, " ", s.LastName) AS Name, 
					CONCAT(s.WeekdayCity, ", ", s.WeekdayState) AS CityState,
					b.Comment, b.Timestamp AS AddedDate
				FROM customer_donotuse b
					LEFT JOIN signer s ON b.SignerId = s.SignerId
				, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	   
    SELECT FOUND_ROWS() AS TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetBlackListSignerCustomerDemo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetBlackListSignerCustomerDemo`(
    IN `sortBy` VARCHAR(255),
	IN `sortDirection` BIT,
	IN `pageNumber` INT,
	IN `pageSize` INT,
    IN `customerId` INT
)
BEGIN
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(500);  

	IF (pageNumber > 1 )
	THEN SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	ELSE SET limitQuery = '';
    END IF;
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
      
	SET whereQuery = CONCAT(' WHERE customerId = ',customerId); 
         
	SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
					b.Id, s.SignerId, CONCAT(s.FirstName, " ", s.LastName) AS Name, 
					CONCAT(s.WeekdayCity, ", ", s.WeekdayState) AS CityState,
					b.Comment, b.Timestamp AS AddedDate
				FROM customer_donotuse b
					LEFT JOIN signer s ON b.SignerId = s.SignerId
				, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	   
    SELECT FOUND_ROWS() AS TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetBranches` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetBranches`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN brokerID varchar(100),
IN company varchar(500),
IN contactFirst varchar(500),
IN contactLast varchar(500),
IN GID varchar(100)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(5000);
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = ' WHERE IsAvailable=1';
	IF (brokerID IS NOT NULL AND brokerID <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND BrokerID = ', brokerID);
	END IF;
    IF (GID IS NOT NULL AND GID <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND GID = ', GID);
	END IF;
    IF (company IS NOT NULL AND company <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Company IN (',company, ')');
	END IF;
    IF (contactFirst IS NOT NULL AND contactFirst <>'')
		THEN
			SET contactFirst = QUOTE(CONCAT('%', contactFirst, '%'));
			SET whereQuery = CONCAT(whereQuery ,' AND PrimaryContactFirst LIKE ', contactFirst);
	END IF;
    IF (contactLast IS NOT NULL AND contactLast <>'')
		THEN
			SET contactLast = QUOTE(CONCAT('%', contactLast, '%'));
			SET whereQuery = CONCAT(whereQuery ,' AND PrimaryContactLast LIKE ', contactLast);
	END IF;

	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			BrokerID,
			Company,
            Phone,
			CONCAT_WS(" ", PrimaryContactFirst, PrimaryContactLast) AS ContactName,
            Email,
            b.Inactive,
            UserName
            FROM `broker` b
            INNER JOIN `users` u ON u.MappingUserId = b.BrokerID
			INNER JOIN `user_roles` ur ON u.UsersId = ur.UsersId AND ur.RoleId = 6
            , (SELECT @rownum := 0) r', whereQuery, orderQuery, limitQuery);
	
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetBrokerAddressById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetBrokerAddressById`(
IN brokerId INT(11)
)
BEGIN    
	SELECT `broker.Address`, `broker.City`, `broker.State`, `broker.Zip`
    FROM `broker`
    WHERE BrokerID = brokerId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetBrokerlistTrainingSonNC3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetBrokerlistTrainingSonNC3`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN Company varchar(100),
IN Phone varchar(100),
IN Zip varchar(500),
IN Address varchar(500),
IN City varchar(200),
IN Username varchar(100),
IN LastUpdate datetime,
IN RoleName varchar(100)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = ' WHERE IsAvailable =1';
	IF (clientID IS NOT NULL AND clientID <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND BrokerID = ', clientID);
	END IF;
    IF (clientName IS NOT NULL AND clientName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Company LIKE ''%', clientName, '%''');
	END IF;
    IF (address IS NOT NULL AND address <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Address LIKE ''%', address, '%''');
	END IF;
    IF (city IS NOT NULL AND city <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND City LIKE ''%', city, '%''');
	END IF;
    IF (states IS NOT NULL AND states <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND State = ', '''', states, '''');
	END IF;
    IF (inactive is not null and inactive)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Inactive = 1');
        END IF;
	IF (inactive is not null and !inactive)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND (Inactive = 0', ' OR Inactive IS NULL)');
	END IF;
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			BrokerID,
			Company,
            Address,
            City,
            State,
            Inactive
            FROM broker, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientAdditionalInformation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientAdditionalInformation`(IN UserId int)
BEGIN
	SELECT 
		b.BrokerID,
		b.DefaultCourierID,
        b.AssignOrdersDirectly,
        b.TceFullFill,
		bd.HowHear,
		bd.HowHearShow,
		bd.SocialMedia,
		bd.SigningService,
		bd.SigningServiceUse,
		bd.isMultiCustomer,
		bd.DocDelivery,
		bd.MorningDelivery,
		bd.OtherCourier,
		bd.SignReleased,
		bd.ReturnLabel,
		bd.EmailDelivery,
		bd.DownloadFormat,
		bd.DownloadPassword,
		bd.DownloadSupport,
		bd.DownloadPrint,
		bd.EmailDocsReceived,
		bd.CopyPackage,
		bd.DownloadSite,
		bd.RegisContact,
		bd.PortalPrint,
		bd.TimeReceivedDocs,
		bd.PortalCopyPackage,
		bd.InkColor,
		bd.DocsSpecialInstructions,
		bd.SetApptTime,
		bd.TimeFlexible,
		bd.TimeWindowApp,
		bd.TimeWindow,
		bd.NoConfirmTravel,
		bd.IssueContact,
		bd.AfterHoursPhone,
		bd.DownloadHardware,
        bd.OvernightDelivery,
        bd.SecureEmailDelivery,
        bd.UploadDocDelivery,
        bd.DocLocationDelivery,
        bd.SpecialInstruction1,
		bd.SpecialInstruction2,
		bd.SpecialInstruction3,
		bd.SpecialInstruction4,
        bd.SpecialInstruction5,
        bd.SpecialInstruction6,
        bd.SpecialInstruction7,
        bd.SpecialInstruction8,
        bd.SpecialInstruction9,
        bd.SpecialInstruction10,
        bd.Collect1,
        bd.Collect2,
        bd.Collect3,
        bd.Collect4,
        bd.Collect5,
        bd.Collect6,
		bd.Collect7,
        bd.Collect8,
        bd.Collect9,
        bd.Collect10
		FROM broker b
		LEFT JOIN broker_detail bd ON b.BrokerID = bd.BrokerId
		WHERE b.BrokerID = UserId;
					
	SELECT Courier, CourierID FROM courier;
    
    SELECT tp.ProgramId, tp.Title from `training_programs` tp;
    
    SELECT b.ReqExperienceNumber, b.ReqRating from broker b where b.BrokerId = UserId;
    
    SELECT distinct btr.ProgramId from broker_training_req btr where btr.BrokerId = UserId;

	SELECT * FROM rating;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientBillingInformation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientBillingInformation`(IN user_id INT)
BEGIN
	SELECT b.BrokerID, b.DefaultCourierAcnt, b.DefaultCourierID, 
		bd.APContactEmail, bd.APContactFax, bd.APContactPhone, bd.APEmail,
		bd.APExt, bd.APFax, bd.APFirst, bd.APLast, bd.APRep, bd.APRepPhone,
		bd.APTerms, bd.Inv, 
        p.PaymentId, p.MaskedNumber, p.ExpirationMonth, p.ExpirationYear, p.NameOnCard
	FROM broker b
	LEFT JOIN broker_detail bd ON b.BrokerID = bd.BrokerId
	LEFT JOIN payment p ON bd.PaymentMethodId = p.PaymentId
	WHERE b.BrokerID = user_id;
    
    SELECT CourierID, Courier FROM courier;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientCheckQuickBookSPL` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientCheckQuickBookSPL`(
IN orderId INT
)
BEGIN
	
	SELECT  'SPL' as `!SPL`, ord.orderId as `SPLID`, 'INVOICE' as `TRNSTYPE`, ord.closedDate as `DATE`, 
    bf.feeDescription as `ACCNT`, '' as `NAME`, '' as `CLASS`, 
    CONCAT('-',ROUND(of.brokerFee,2)) as `AMOUNT`, ord.orderId as `DOCNUM`,
	CONCAT(ord.firstName,' ',ord.lastName, '; ',ord.address,', ',ord.city,' ',ord.state,', ', ord.zip) as `MEMO`,
    'N' as `CLEAR`, '' as `QNTY`, ROUND((SELECT SUM(of2.brokerFee) FROM order_fee of2 WHERE of2.orderId = ord.orderId),2) as `PRICE`,
    bf.feeDescription `INVIITEM`, 'N' as `TAXABLE`, '' as `OTHER2`, '0' as `YEARTODATE`, '0' as `WAGEBASE`
	FROM `order` ord
	LEFT JOIN order_fee of on of.orderID = ord.orderId
    LEFT JOIN broker_fee bf on bf.feeId = of.feeDescripID
    LEFT JOIN broker br on br.brokerId = ord.brokerId
    WHERE ord.orderId = orderId AND ord.progressId = 8
    ORDER BY bf.feeId, of.feeId;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientDocuments` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientDocuments`(
IN brokerId int,
IN isAgent bit,
IN orderId varchar(500),
IN documentName varchar(500),
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
   DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';
    
	IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND od.orderId =  ''', orderId, '''');
	END IF;
    
    IF (documentName IS NOT NULL AND documentName <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND od.description LIKE  ''%', documentName, '%''');
	END IF;
    
    IF (isAgent = 1) 
		THEN SET whereQuery = CONCAT(whereQuery, ' AND (o.agentID = ',brokerId,')');
    ELSE
		SET whereQuery = CONCAT(whereQuery, ' AND (br.brokerId= ',brokerId,' or br.gId=',brokerId,')');
	END IF;
    
    SET whereQuery = CONCAT(whereQuery, ' AND (od.archive IS NULL OR od.archive = 0) AND od.documentType=1 ');
   
	SET @querySql= concat('
     SELECT 
     SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			od.docId,
            od.orderId,
            od.description,
            od.uploadedDate,
            od.documentType,
			(CASE 
				WHEN od.viewed IS NULL THEN  ''N''	
				ELSE ''Y'' END) as isDownloadedByVendor
			FROM order_docs od
            JOIN `order` o on od.orderId = o.orderId
            JOIN broker br on br.brokerId = o.brokerId
            , (SELECT @rownum := 0) r
            ',
            whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientFees` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientFees`(
IN brokerId int,
In industry int,
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
    IF (industry is null )
		THEN SET industry = 0;
    END IF;
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY description ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';
     
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t.* from
			(select bf.feeId, bf.brokerFee, bf.feeDescription as description
        from broker_fee bf
        where bf.brokerId= ', brokerId ,' and bf.IndustryId = ',industry,') t, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientInformation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientInformation`(
IN client_id INT(11)
)
BEGIN
	-- client info
    SELECT
		-- company
		b.Company,
        b.Phone,
        b.Address,
        b.Suite,
        b.City,
        b.State,
        b.Zip,
        b.AdministratorFirst,
        b.AdministratorLast,
        b.Administratorext,
        b.AdministratorEmail,
        bd.AfterHoursPhone,
        b.DefaultCourierID,
        -- contact
        b.DefaultCourierAcnt,
        b.PrimaryContactFirst,
        b.PrimaryContactLast,
        b.Email,
        b.PrimaryContactext,
        b.PrimaryContactFax,
        b.EmailOpt,
        b.TextOpt,
        bd.Cell,
        bd.Website,
        b.AdditionalContact,
        b.AdditionalContactEmail,
        b.AdditionalContactPhone,
        b.AdditionalContactExt,
        b.AdditionalContactFirstName,
        b.AdditionalContactLastName,
        b.TeamName,
        b.TransactionOfMonth,
        b.TransactionToTCE,
        bd.AfterHoursPhoneExt
    FROM `broker` AS b
    LEFT JOIN `broker_detail` AS bd ON bd.BrokerId = b.BrokerID
    WHERE b.BrokerID = client_id;
    
    -- return address
    SELECT 
		RaId,
		BrokerId,
		CONCAT(case when r.Department is null then '' else concat(r.Department, ', ') end,
			case when r.Address is null then '' else concat(r.Address, ', ') end,
            case when r.Suite is null then '' else concat(r.Suite, ', ') end,
            case when r.City is null then '' else concat(r.City, ', ') end,
            case when r.State is null then '' else concat(r.State, ' ') end,
            case when r.Zip is null then '' else concat(r.Zip) end) 
		AS FullAddress,
		r.Department,
		r.Address,
		r.Suite,
		r.City,
		r.Zip,
		CASE DefaultAddr WHEN 'Y' THEN TRUE ELSE FALSE END AS DefaultAddr,
		BranchId
	FROM `return_addr` AS r
    WHERE r.BrokerID = client_id;
    
    -- cc invoice email list
    SELECT
		BrokerEmailId,
		BrokerID,
		EName,
		Email,
		case when EmailFor='I' OR EmailFor='B' THEN 1 ELSE 0 END AS ForInvoice,
        case when EmailFor='S' OR EmailFor='B' THEN 1 ELSE 0 END AS ForStatus
	FROM `broker_emails` AS b
    WHERE b.BrokerID = client_id
	ORDER BY b.BrokerEmailId DESC;
        
	-- couriers
    SELECT 
		CourierID,
		Courier
	FROM `courier`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientInvoiceQuickBook` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientInvoiceQuickBook`(
IN fromDate DateTime,
IN toDate DateTime,
IN brokers VARCHAR(5000)
)
BEGIN
	
	SELECT   br.company as `Customer`, DATE_SUB(ord.aptDatetime,INTERVAL z.utc HOUR)  as `Transaction Date`,
    ord.orderId as `RefNumber`, ord.brokerIdNum as `PO Number`, 'Net 15' as `Terms`, '' as `Class`,
    '' as `Template Name`, 'N' as `To Be Printed`, ord.closedDate as `Ship Date`, br.company as `BillTo Line1`,
    br.address as `BillTo Line2`, '' as `BillTo Line3`, '' as `BillTo Line4`, br.city as `BillTo City`,
    br.state as `BillTo State`, br.zip as `BillTo PostalCode`, 'USA' as `BillTo Country`, '' as `ShipTo Line1`,
	'' as `ShipTo Line2`, '' as	`ShipTo Line3`, '' as `ShipTo Line4`, '' as	`ShipTo City`, '' as `ShipTo State`,
	 '' as `ShipTo PostalCode`, '' as `ShipTo Country`, br.phone as `Phone`, '' as `Fax`, br.email as `Email`,
     CONCAT(br.primaryContactFirst,'' '',br.primaryContactLast) as `Contact Name`, '' as `First Name`, '' as `Last Name`,
     '' as `Rep`, DATE_ADD(ord.closedDate, INTERVAL 15 DAY) as `Due Date`, '' as `Ship Method`, '' as `Customer Message`,
     ord.lastName as `Memo`, CONCAT('Notary – ',bf.feeDescription) as `Item` , '' as `Quantity`, 
     CONCAT(ord.lastName, '; ',ord.address,', ',ord.city,', ',ord.state,' ', ord.zip) as `Description`,
     of.brokerFee as `Price`, '' as `Pending`, '' as `Item Line Class`, '' as `Service Date`, '' as `FOB`,
      '' as `Customer Acct No`, 'N' as `Sales Tax Item`, 'N' as `To Be E-Mailed`, '' as `Other`,
       '' as `Other1`, '' as `Other2`,'' as `AR Account`, 'Non' as `Sales Tax Code`
	FROM `order` ord
    LEFT JOIN zip z on z.zip = ord.zip
	LEFT JOIN signer sn on ord.signerId = sn.signerId
	LEFT JOIN order_fee of on of.orderID = ord.orderId
    LEFT JOIN broker_fee bf on bf.feeId = of.feeDescripID
    LEFT JOIN broker br on br.brokerId = ord.brokerId
    WHERE ord.progressId = 8 AND ord.closedDate >= fromDate AND ord.closedDate < DATE_ADD(toDate, INTERVAL 1 DAY)
      AND ((brokers = '' or brokers is null) OR find_in_set(br.brokerId,brokers))
    ORDER BY sn.signerId, ord.closedDate, ord.orderId;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientQuickBookSPL` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientQuickBookSPL`(
IN orderId INT
)
BEGIN
	
	SELECT  'SPL' as `!SPL`, ord.orderId as `SPLID`, 'INVOICE' as `TRNSTYPE`, ord.closedDate as `DATE`, 
    CONCAT('Services:Notary: ', bf.feeDescription) as `ACCNT`, '' as `NAME`, '' as `CLASS`, 
    CONCAT('-',ROUND(of.brokerFee,2)) as `AMOUNT`, ord.orderId as `DOCNUM`,
	CONCAT(ord.firstName,' ',ord.lastName, '; ',ord.address,', ',ord.city,' ',ord.state,', ', ord.zip) as `MEMO`,
    'N' as `CLEAR`, '' as `QNTY`, ROUND((SELECT SUM(of2.brokerFee) FROM order_fee of2 WHERE of2.orderId = ord.orderId),2) as `PRICE`,
    CONCAT('Notary: ',bf.feeDescription) as `INVIITEM`, 'N' as `TAXABLE`, '' as `OTHER2`, '0' as `YEARTODATE`, '0' as `WAGEBASE`
	FROM `order` ord
	LEFT JOIN order_fee of on of.orderID = ord.orderId
    LEFT JOIN broker_fee bf on bf.feeId = of.feeDescripID
    LEFT JOIN broker br on br.brokerId = ord.brokerId
    WHERE ord.orderId = orderId AND ord.progressId = 8
    ORDER BY bf.feeId, of.feeId;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientQuickBookTRNS` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientQuickBookTRNS`(
IN fromDate DateTime,
IN toDate DateTime,
IN brokers VARCHAR(5000)
)
BEGIN
	
	SELECT  'TRNS' as `!TRNS`, ord.orderId as `TRNSID`, 'INVOICE' as `TRNSTYPE`, UTC_TIMESTAMP() as `DATE`, 
    'Accounts Receivable' as `ACCNT`, br.company as `NAME`, '' as `CLASS`, 
    ROUND((SELECT SUM(of.brokerFee) FROM order_fee of WHERE of.orderId = ord.orderId),2) as `AMOUNT`, ord.orderId as `DOCNUM`,
	ord.lastName as `MEMO`, 'N' as `CLEAR`, 'N' as `TOPRINT`,
    'N' as `NAMEISTAXABLE`, br.company as `ADDR1`, br.address as `ADDR2`, 
    CONCAT(br.city,', ',br.state,' ', br.zip) as `ADDR3`, 'NET 15' as `TERM`,
    '' as `SHIPVIA`,  UTC_TIMESTAMP() as `SHIPDATE`, ord.brokerIdNum as `PONUM`, 
    DATE_ADD(ord.ClosedDate, INTERVAL 15 DAY) as `DUEDATE`
	FROM `order` ord
    LEFT JOIN broker br on br.brokerId = ord.brokerId
    WHERE ord.progressId = 8 AND ord.closedDate >= fromDate AND ord.closedDate < DATE_ADD(toDate, INTERVAL 1 DAY)
    AND ((brokers = '' or brokers is null) OR find_in_set(br.brokerId,brokers))
    ORDER BY ord.orderId,ord.brokerId, ord.lastName;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientQuickBookTRNS_Millennia` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientQuickBookTRNS_Millennia`(
IN fromDate DateTime,
IN toDate DateTime
)
BEGIN
	
	SELECT  'TRNS' as `!TRNS`, ord.orderId as `TRNSID`, 'INVOICE' as `TRNSTYPE`, UTC_TIMESTAMP() as `DATE`, 
    'Accounts Receivable' as `ACCNT`, br.company as `NAME`, '' as `CLASS`, 
    ROUND((SELECT SUM(of.brokerFee) FROM order_fee of WHERE of.orderId = ord.orderId),2) as `AMOUNT`, ord.orderId as `DOCNUM`,
	ord.lastName as `MEMO`, 'N' as `CLEAR`, 'N' as `TOPRINT`,
    'N' as `NAMEISTAXABLE`, br.company as `ADDR1`, br.address as `ADDR2`, 
    CONCAT(ord.city,', ',ord.state,' ', ord.zip) as `ADDR3`, 'NET 15' as `TERM`,
    '' as `SHIPVIA`,  UTC_TIMESTAMP() as `SHIPDATE`, ord.brokerIdNum as `PONUM`, 
    DATE_ADD(ord.ClosedDate, INTERVAL 15 DAY) as `DUEDATE`
	FROM `order` ord
    LEFT JOIN broker br on br.brokerId = ord.brokerId
    WHERE ord.progressId = 8 AND br.brokerId = 1 AND ord.closedDate >= fromDate AND ord.closedDate < DATE_ADD(toDate, INTERVAL 1 DAY)
    ORDER BY ord.orderId,ord.brokerId, ord.lastName;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClients` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClients`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN clientID varchar(100),
IN clientName varchar(500),
IN address varchar(500),
IN city varchar(200),
IN states varchar(100),
IN inactive bit
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = ' WHERE IsAvailable =1';
	IF (clientID IS NOT NULL AND clientID <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND BrokerID = ', clientID);
	END IF;
    IF (clientName IS NOT NULL AND clientName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Company LIKE ''%', clientName, '%''');
	END IF;
    IF (address IS NOT NULL AND address <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Address LIKE ''%', address, '%''');
	END IF;
    IF (city IS NOT NULL AND city <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND City LIKE ''%', city, '%''');
	END IF;
    IF (states IS NOT NULL AND states <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND State = ', '''', states, '''');
	END IF;
    IF (inactive is not null and inactive)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Inactive = 1');
        END IF;
	IF (inactive is not null and !inactive)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND (Inactive = 0', ' OR Inactive IS NULL)');
	END IF;
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			BrokerID,
			Company,
            Address,
            City,
            State,
            Inactive
            FROM broker, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientServicesConfigLog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientServicesConfigLog`(
	IN id int
)
BEGIN
	SELECT
        cscl.UpdatedDate,
        DATE_ADD(cscl.UpdatedDate, INTERVAL 30 DAY) as EstimatedEffectiveDate,
        u.UserName as ChangedBy,
        cscl.EffecttiveDate,
        u1.UserName AS ApprovedBy,
		cscl.OrderPerDay,
        CONCAT('1 - ', cscl.CutoffDate) AS DateRange,
        cscl.State1,
        cscl.MSA1
	FROM client_services_config_log cscl
		LEFT JOIN users u ON cscl.UpdatedBy = u.UsersId
        LEFT JOIN client_services_config csc ON cscl.ConfigId = csc.ConfigId
        LEFT JOIN users u1 ON u1.UsersId = csc.ApprovedBy
    WHERE cscl.ConfigId = id
    ORDER BY cscl.UpdatedDate DESC
    ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientServicesConfigurationData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientServicesConfigurationData`(
	IN createdById int,
    IN numRow int
)
BEGIN
	SELECT `Code`, `Description`
    FROM state;

	SELECT
		ConfigId,
		OrderPerDay,
        State1,
        MSA1,
        UpdatedDate,
        DATE_ADD(UpdatedDate, INTERVAL 30 DAY) as EstimatedEffectiveDate,
        EffecttiveDate,
        CONCAT('1 - ', CutoffDate) AS DateRange,
        u.UserName as ChangedBy,
        ab.UserName as ApprovedBy,
        case csc.Status when 1 then 'Open'
						when 2 then 'Approved'
                        when 3 then 'Closed'
                        else ''
		end as status
	FROM client_services_config csc
		LEFT JOIN users u ON csc.UpdatedBy = u.UsersId
        LEFT JOIN users ab ON csc.ApprovedBy = ab.UsersId
        
    WHERE CreatedBy = createdById
    ORDER BY EffecttiveDate DESC
    LIMIT 0, numRow
    ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientStatus`(IN clientId int)
BEGIN
    SELECT 
    o.OrderID,
    o.BrokerIDNum,
    b.Company,
    a.FullName,
    o.LastName,
    o.OrderDate,
    o.AptDateTime,
    o.FilledDate,
    concat(s.FirstName , ' ' , s.LastName) as Signer,
    concat(e.FirstName, ' ', e.LastName) as SaleRep,
    o.closeddate,
    p.ProgressDescription
FROM
    `order` o
        LEFT JOIN
    Signer s ON o.SignerID = s.SignerID
        LEFT JOIN
    Employees e ON o.RepID = e.RepID
        LEFT JOIN
    Progress p ON o.ProgressID = p.ProgressID
        LEFT JOIN
    Broker b ON o.BrokerID = b.BrokerID
        LEFT JOIN
    Agent a ON o.AgentID = a.agentid
    WHERE   o.BrokerID = clientId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetClientsUserByRole` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetClientsUserByRole`(
IN role varchar(255),
IN clientId int
)
BEGIN
	IF (role = 'Client') 
		THEN SET @strQuery = CONCAT('select u.UsersId, b.Company, a.FullName, ur.RoleId, u.Status
			from `users` u
			left join `agent` a on a.AgentId = u.MappingUserId
			left join `broker` b on b.BrokerID = u.MappingUserId
			inner join `user_roles` ur on ur.UsersId = u.UsersId
			where (ur.RoleId=6 or ur.RoleId=7) and (a.BrokerId=',clientId, ' or b.GID=',clientId, ');');
	ELSE IF (role = 'Branch') 
		THEN SET @strQuery = CONCAT('select u.UsersId, a.FullName, "" as Company, ur.RoleId, u.Status
			from `agent` a 
			inner join `users` u on a.AgentId = u.MappingUserId
			inner join `user_roles` ur on ur.UsersId = u.UsersId
			where a.BrokerID=',clientId, ' and ur.RoleId=7');
	ELSE IF (role = 'Agent') 
		THEN SET @strQuery = CONCAT('select u.UsersId, a.FullName, "" as Company, ur.RoleId, u.Status
			from `agent` a 
			inner join `users` u on a.AgentId = u.MappingUserId
			inner join `user_roles` ur on ur.UsersId = u.UsersId
			where a.BrokerID=',clientId, ' and ur.RoleId=7');
		END IF;
    END IF;
    END IF;
    
    PREPARE stmt FROM @strQuery;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetCommentPage` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetCommentPage`(
	IN sortBy VARCHAR(255),
	IN sortDirection BIT,
	IN pageNumber INT,
	IN pageSize INT
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF; 
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS `comment`.CommentID as `CommentID`,
									`comment`.CreatedDate as `CreatedDate`,         
									`comment`.Description as `Description`,                                     
									`comment`.OwnerID as `OwnerID`,                                     
									`comment`.TypeID as `TypeID`,                                    
									`comment`.TenantID as `TenantID`,                                     
                                    `comment`.IsPrivate as `IsPrivate`,
                                    `comment`.CreatedBy as CreatedBy                        
                        FROM `comment`', limitQuery );
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetCorrectionRequest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetCorrectionRequest`(
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN correctionType varchar(255)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(21000);  
    
    IF (sortDirection = true) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = CONCAT(' ORDER BY `Id`', sortDirectionQuery);
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
    
    IF (pageNumber IS NULL OR pageNumber = '') THEN SET pageNumber = 1; END IF;
    IF (pageSize IS NULL OR pageSize = '') THEN SET pageSize = 25; END IF;
	
    SET whereQuery = ' where 1=1 and ParentId is null';

    IF (correctionType IS NOT NULL AND correctionType <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND Description LIKE ''%', correctionType, '%''');
    END IF;

    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    set @querySql = CONCAT('select Id, Description, IsImportant, ParentId
							from problem_types',whereQuery, orderQuery, limitQuery);
	
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
SELECT FOUND_ROWS() AS TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetCorrectionRequestSubType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetCorrectionRequestSubType`(
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN correctionType varchar(255)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(21000);  
    
    IF (sortDirection = true) 
		THEN SET sortDirectionQuery = ',SubType ASC ';
	ELSE SET sortDirectionQuery = ',SubType DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = CONCAT(' ORDER BY `Id`', sortDirectionQuery);
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
    
    IF (pageNumber IS NULL OR pageNumber = '') THEN SET pageNumber = 1; END IF;
    IF (pageSize IS NULL OR pageSize = '') THEN SET pageSize = 25; END IF;
	
    SET whereQuery = ' and 1=1';

    IF (correctionType IS NOT NULL AND correctionType <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND Description LIKE ''%', correctionType, '%''');
    END IF;
    
    IF (correctionType IS NOT NULL AND correctionType <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' OR SubType LIKE ''%', correctionType, '%''');
    END IF;

    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    set @querySql = CONCAT('select t2.* from (Select pt.Id, pt.Description, IF(t1.Description is not null, t1.Description, "") as SubType, t1.SubTypeId
							from problem_types pt 
							left join (select pt2.Id as SubTypeId, pt2.ParentId, pt2.Description from problem_types pt2 where pt2.ParentId is not null and pt2.ParentId > 0) as t1 on t1.ParentId = pt.Id 
                            where pt.ParentId is null or pt.ParentId = 0) as t2 where t2.SubTypeId is not null ',whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
SELECT FOUND_ROWS() AS TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetCustomers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetCustomers`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN customerID varchar(100),
IN customerName varchar(500),
IN brokerId varchar(100)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = CONCAT(' WHERE c.brokerId=', brokerId, ' AND (c.Inactive = 0 or c.Inactive is null)');
	IF (customerID IS NOT NULL AND customerID <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND c.CustomerId = ', customerID);
	END IF;
    IF (customerName IS NOT NULL AND customerName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND c.Name LIKE ''%', customerName, '%''');
	END IF;
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			c.CustomerId,
			c.Name,
            c.Email, 
            c.industryId,
            case when t.ProductType is not null then t.ProductType
            else p.ProductType end as ProductType
            FROM customers c left join 
            (SELECT cpt.CustomerId, group_concat(l.LoanType SEPARATOR '', '') as ProductType
			from customer_product_type cpt
            inner join loan_type l on cpt.ProductType=l.LoanTypeId
			GROUP BY CustomerId
            order by l.LoanType) t on c.CustomerId = t.CustomerId
            left join 
            (SELECT i.IndustryId, group_concat(l.LoanType SEPARATOR '', '') as ProductType
			from industry_transaction_fees i inner join loan_type l on i.LoanTypeId=l.LoanTypeId
            where i.IsAdditionalFee = 0
			GROUP BY i.IndustryId
            order by l.LoanType) p on c.IndustryId = p.IndustryId
            , (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetDataForOrderClosedAndScheduledReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetDataForOrderClosedAndScheduledReport`(

)
BEGIN
	IF (inputOrderId IS NOT NULL AND inputOrderId >= 0)
		THEN 
		SELECT O.orderId, O.toEmail, O.alwaysCC, O.emailCC, O.fullName, O.fax, O.company, O.brokerIdNum, O.signerId, O.trackingNumber, O.courier, O.aptDateTime, O.brokerId, SUM(BF.BrokerFee) AS brokerFees, O.clientName, O.companyAddress, O.companyCityStateZip
        FROM
			(
			SELECT
				O.OrderId AS orderId, A.Email AS toEmail, B.CCEmail as alwaysCC, GROUP_CONCAT(BE.Email SEPARATOR '; ') AS emailCC, O.LastName AS clientName, B.Address AS companyAddress, CONCAT_WS(', ', B.City, B.State, B.Zip) AS companyCityStateZip,
				A.fullName, A.fax, B.company, O.brokerIdNum, O.signerId, O.trackingNumber, C.courier, O.aptDateTime, O.brokerID
			FROM
				(SELECT * from `order` WHERE `orderId` = inputOrderId) O LEFT JOIN
				`agent` A ON O.AgentId = A.AgentId LEFT JOIN
				`broker` B ON O.BrokerID = B.BrokerID LEFT JOIN
				(SELECT * FROM `broker_emails` WHERE EmailFor <> 'I') BE ON O.BrokerID = BE.BrokerID LEFT JOIN
				`courier` C ON C.CourierID = O.CourierID
				GROUP BY O.OrderId
			) O LEFT JOIN
            `broker_fee` BF ON BF.BrokerID = O.BrokerID
		;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetDataForOrderDetailsReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetDataForOrderDetailsReport`(
IN orderId int
)
BEGIN

    select concat(e.FirstName, " ", e.LastName) as employeeName
		, e.Ext as employeeExt
        , e.Email as employeeEmail
        , o.AptDateTime as aptDateTime
        , o.AptUTC as aptUTC
        , lt.LoanType as loanType
        , b.BrokerId as brokerId
        , b.Company as brokerCompanyName
        , b.Phone as brokerPhone
        , o.DocDelMethod as docDelMethod
        , o.FaxBackReq as faxBackRequired
		, a.FullName as agentName
        , a.Direct as agentDirect
        , a.Ext as agentExt
        , a.FullName as agentAfterHoursContact
        , a.AfterhoursPhone as agentAfterHoursPhone
        , b.LenderSpecific as importantCompanyInstruction
        , o.DocstoSignerDate as docsToSignerDate
        , c.Courier as courier
        , o.CourierAcntNumber as courierAcntNumber
        , concat(o.FirstName, " ", o.LastName) as borrowerName
        , o.HomePhone as borrowerHomePhone
        , o.CellPhone as borrowerCellPhone
        , o.WorkPhone as borrowerWorkPhone
        , o.BoWrkext as borrowerExt
        , concat(o.CoFirstName, " ", o.CoLastName) as coBorrowerName
        , o.CoHomePhone as coBorrowerHomePhone
        , o.CoCellPhone as coBorrowerCellPhone
        , o.CoWorkPhone as coBorrowerWorkPhone
        , o.CoBoWrkext as coBorrowerExt
        , o.Address as borrowerAddress
        , concat(o.City, " ", o.State, " ", o.Zip) as borrowerCityStateZip
        , br.County as borrowerCounty
        , o.Collect1 as orderCollect1
        , o.Collect2 as orderCollect2
        , o.Collect3 as orderCollect3
        , o.Collect4 as orderCollect4
        , o.Collect5 as orderCollect5
        , o.Collect6 as orderCollect6
        , o.Collect7 as orderCollect7
        , o.Collect8 as orderCollect8
        , o.Collect9 as orderCollect9
        , o.Collect10 as orderCollect10
        , osi.Instructions1 as orderSpecialInstructions1
        , osi.Instructions2 as orderSpecialInstructions2
        , osi.Instructions3 as orderSpecialInstructions3
        , osi.Instructions4 as orderSpecialInstructions4
        , osi.Instructions5 as orderSpecialInstructions5
        , osi.Instructions6 as orderSpecialInstructions6
        , osi.Instructions7 as orderSpecialInstructions7
        , osi.Instructions8 as orderSpecialInstructions8
        , osi.Instructions9 as orderSpecialInstructions9
        , osi.Instructions10 as orderSpecialInstructions10
    from `order` as o
    left join employees as e on o.Repid = e.Repid
    left join agent as a on o.agentId = a.agentId
    left join broker as b on o.brokerid = b.brokerid
    left join courier as c on b.DefaultCourierID = c.CourierID
    left join loan_type as lt on o.LoanType = lt.LoanTypeId
    left join borrower as br on o.BorrowerId = br.BorrowerId
    left join order_special_instructions as osi on osi.orderid = o.orderid
    where o.orderId = orderId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getDataInitForViewOrders` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `getDataInitForViewOrders`()
BEGIN
	select b.Company from broker b;
	select p.ProgressId, p.ProgressDescription from progress p;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetDataSendMailApproval` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetDataSendMailApproval`(
IN isApproval bit,
IN users_Id int(11),
IN signer_Id int(11),
IN isVendor bit,
IN approval_Id int(11)
)
BEGIN
	declare toAgentEmail varchar(250);
    declare agentName varchar(50);
    declare toVendorEmail varchar(250);
    declare vendorName varchar(50);
    declare loanType varchar(50);
    declare distance float;
    declare city varchar(50);
    declare aptDateTime datetime;
    declare firstName varchar(15);
    declare lastName varchar(25);
    declare originalSignerFee decimal(19,4);
    
    if(isApproval)
    then if(isVendor)
		then select lo.LoanType, 
			69.1*sqrt(POWER((s.Lat - o.Lat), 2) + 0.6*POWER((s.Long - o.Long), 2)) AS distance,
			o.City, o.AptDateTime, s.FirstName, s.LastName, fee.originalSignerFee into loanType, distance, city, aptDateTime, firstName, lastName, originalSignerFee
			FROM signers_approval sa 
			LEFT JOIN `order` o ON sa.OrderId = o.OrderId
            left join (select ofee.orderid, sum(ofee.OriginalSignerFee) originalSignerFee from `order_fee` ofee group by ofee.orderid) fee  on sa.OrderId = fee.OrderID
			left join `loan_type` lo on o.LoanType = lo.LoanTypeId
			LEFT JOIN signer s ON s.SignerId = sa.SignerId
			where s.signerid=signer_Id and sa.ApprovalID = approval_Id;
        else
			select lo.LoanType, 
			69.1*sqrt(POWER((s.Lat - o.Lat), 2) + 0.6*POWER((s.Long - o.Long), 2)) AS distance,
			o.City, o.AptDateTime, s.FirstName, s.LastName into loanType, distance, city, aptDateTime, firstName, lastName
			FROM order_fee_approve ofa
			LEFT JOIN `order` o ON ofa.OrderId = o.OrderId
			left join `loan_type` lo on o.LoanType = lo.LoanTypeId
			LEFT JOIN signer s ON s.SignerId = ofa.SignerId
			where s.signerid=signer_Id and ofa.FeeApprovalId = approval_Id;
        end if;
	end if;
		SELECT ss.email, concat(ss.FirstName, ' ', ss.LastName) into toVendorEmail, vendorName FROM signer ss where ss.signerid=signer_Id;
		select a.Email, a.FullName into toAgentEmail, agentName from users u
		inner join agent a on a.AgentId= u.MappingUserId
		where u.UsersId=users_Id;
	if(isVendor)
		then if(isApproval)
			then SELECT FromEmail,Subject,Message, toAgentEmail, vendorName, agentName FROM notification_templates where Purpose='Vendor Recommendation - Vendor - Approved' and Receiver='Agent''s email';
            SELECT FromEmail,Subject,Message, toVendorEmail, vendorName, loanType, distance, city, aptDateTime, firstName, lastName, originalSignerFee FROM notification_templates where Purpose='Offer Accepted-Vendor' and Receiver='Vendor';
		else 
			SELECT FromEmail,Subject,Message, toAgentEmail, vendorName, agentName FROM notification_templates where Purpose='Vendor Recommendation Rejected' and Receiver='Agent''s email';
		end if;
	else 
		if(isApproval)
			then SELECT FromEmail,Subject,Message, toAgentEmail, vendorName, agentName FROM notification_templates where Purpose='Agent''s Fee Request Approved' and Receiver='Client Agent';
			SELECT FromEmail,Subject,Message, toVendorEmail, vendorName, loanType, distance, city, aptDateTime, firstName, lastName FROM notification_templates where Purpose='Offer Accepted-Vendor' and Receiver='Vendor';
		else 
			SELECT FromEmail,Subject,Message, toAgentEmail, vendorName, agentName FROM notification_templates where Purpose='Agent''s Fee Request Rejected' and Receiver='Client Agent';
            SELECT FromEmail,Subject,Message, toVendorEmail, vendorName, agentName FROM notification_templates where Purpose='Agent''s Fee Request Rejected' and Receiver='Vendor';
		end if;
    end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetDataTocalCulateRatingOrder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetDataTocalCulateRatingOrder`(
	IN orderId int
)
BEGIN
		set @querySqlCriticalErrors = CONCAT('select count(op.ProblemId) as criticalErrors from order_problem op
		inner join problem_types pt on op.ProblemId = pt.Id
		where op.Mistake = 1 and pt.IsImportant = 1 and op.orderID = ',orderId);

		set @querySqlErrors = CONCAT('select count(op.ProblemId) as errors from order_problem op
		inner join problem_types pt on op.ProblemId = pt.Id
		where op.Mistake = 1 and op.orderID = ',orderId);
		-- cau 3
		set @querySqlResponseTime = CONCAT('select timestampdiff(minute, op.`AcknowledgedDate`,op.`Date`) as responseTime from order_problem op
		inner join problem_types pt on op.ProblemId = pt.Id
		where op.Mistake = 1 and op.orderID = ',orderId);

		set @querySqlCompetitivePricing  = CONCAT('select signer.AvgFee, signer.SignerFee from signer
		inner join `order` on signer.SignerId = `order`.SignerId
		where orderID  = ',orderId);

		set @querySqlAcceptingToConfirm  = CONCAT('select ConfirmTurn as acceptingToConfirm from order_stats where OrderId = ',orderId);

		set @querySqlExpectedTimeToSigning = CONCAT('select (os.AptCloseTurn - sct.StandardTime) as expectedTimeToSigning
		from order_stats as os
		inner join `order_fee` of on os.OrderId = of.OrderID
		inner join `broker_fee` bf on of.FeeDescripID = bf.FeeId
		inner join `standard_close_time` sct on sct.IndustryId = bf.IndustryId and sct.LoanTypeId = bf.LoanTypeId
		where bf.IsAdditionalFee = false and os.OrderId = ',orderId);

		set @querySqlSigningCompletionToScanback = CONCAT('select timestampdiff(minute,tempMin.minUploadedDate,`order`.ClosingWorksheetDate) as signingCompletionToScanback from `order`
		inner join (select OrderId, MIN(UploadedDate) as minUploadedDate
			from order_docs where OrderId = ',orderId,' and DocumentType = 2
			GROUP BY OrderId, UploadedDate) as tempMin
		on `order`.OrderId = tempMin.OrderId
		where `order`.OrderId = ', orderId);

		set @querySqlPostCloseErrorCorrection  = CONCAT('select timestampdiff(minute,`FixedTime`, `Date`) as postCloseErrorCorrection from order_problem where OrderId = ',orderId);

		set @querySqlStandardTestings = CONCAT('select vtr.Passed from vendor_test_result vtr
		inner join test_info ti on vtr.TestId = ti.TestId
        inner join `order` as o on vtr.VendorId = o.SignerId
		where ti.TestCategory = 1 and o.OrderId = ',orderId);

		set @querySqlSpecializedTestings = CONCAT('select vtr.Passed from vendor_test_result vtr
		inner join test_info ti on vtr.TestId = ti.TestId
        inner join `order` as o on vtr.VendorId = o.SignerId
		where ti.TestCategory = 2 and o.OrderId = ',orderId);

		set @querySqlAdditionalTrainings = CONCAT('select IsComplete from vendor_registered_programs vrp
		inner join training_programs tp on tp.ProgramId = vrp.ProgramId
        inner join `order` as o on vrp.VendorId = o.SignerId
		where tp.AdditionalProgram = 1 and o.OrderId = ',orderId);

		set @querySqlCustomerFeedback = CONCAT('select  CustomerFeedback from `order`
		where `order`.OrderId = ',orderId);
        
        set @querySqlClientCategoryRating = CONCAT('select vcr.Id, vcr.Category, vcr.Percent, vcr.RatingId, vcr.MaxPoint, vcr.ThresholdFrom, vcr.ThresholdTo, cr.Unit, cr.Description 
        from broker_vendor_categories_rating vcr
		inner join categories_rating cr on vcr.RatingId = cr.Id
		inner join `order` as o on vcr.BrokerId = o.BrokerId
        where o.OrderId = ',orderId);
        
        set @querySqlClientBonus = CONCAT('select vmb.Id, vmb.BonusId, vmb.PointBonus, vmb.PointComplaint, mb.Description 
        from broker_vendor_modifiers_bonus vmb
		inner join modifiers_bonus mb on vmb.bonusId = mb.Id
		inner join `order` as o on vmb.BrokerId = o.BrokerId
        where o.OrderId = ',orderId);
        
        set @querySqlStaffCategoryRating = 'select vcr.Id, vcr.Category, vcr.Percent, vcr.RatingId, vcr.MaxPoint, vcr.ThresholdFrom, vcr.ThresholdTo, cr.Unit, cr.Description 
        from vendor_categories_rating vcr
		inner join categories_rating cr on vcr.RatingId = cr.Id';
        
        set @querySqlStaffBonus = 'select vmb.Id, vmb.BonusId, vmb.PointBonus, vmb.PointComplaint, mb.Description 
        from vendor_modifiers_bonus vmb
		inner join modifiers_bonus mb on vmb.bonusId = mb.Id';

    PREPARE stmt FROM @querySqlCriticalErrors ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlErrors ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlResponseTime ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlCompetitivePricing ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlAcceptingToConfirm ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlExpectedTimeToSigning ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlSigningCompletionToScanback ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlPostCloseErrorCorrection ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlStandardTestings ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlSpecializedTestings ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlAdditionalTrainings ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlCustomerFeedback ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlClientCategoryRating ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlClientBonus ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlStaffCategoryRating ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    PREPARE stmt FROM @querySqlStaffBonus ;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetDocGrid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetDocGrid`(
	IN `sortBy` VARCHAR(250),
	IN `sortDirection` BIT,
	IN `pageNumber` INT,
	IN `pageSize` INT,
	IN `orderId` INT,
	IN `docType` INT
)
BEGIN	
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
	DECLARE limitQuery varchar(255);  
	DECLARE whereQuery varchar(255);  
	DECLARE selectQuery varchar(500);
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY UploadedDate ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
   IF (docType = 1)
   	THEN SET selectQuery = '
			SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
					t.DocId, t.OrderId, t.Description, t.UploadedDate, u.UserName AS UploadedBy, t.Viewed, t.DownloadDate, t.UserId
			FROM order_docs t
			LEFT JOIN users u ON u.UsersId = t.UserId
			, (SELECT @rownum := 0) r';
		ELSE
			SET selectQuery = '
			SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
					t.DocId, t.OrderId, t.Description, t.UploadedDate, u.UserName AS UploadedBy, t.Status, t.Viewed, t.ReviewDate, x.UserName AS ReviewedBy, t.Comment, t.RejectReason, t.UserId
			FROM order_docs t
			LEFT JOIN users u ON u.UsersId = t.UserId
			LEFT JOIN users x ON x.UsersId = t.ReviewedBy
			, (SELECT @rownum := 0) r';
	END IF;
	SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	SET whereQuery = CONCAT(' WHERE UploadedDate >= DATE(UTC_TIMESTAMP()) - INTERVAL 60 DAY AND OrderId = ',orderId,' AND DocumentType = ',docType); 
	
	SET @querySql = CONCAT(selectQuery,whereQuery, orderQuery, limitQuery);

PREPARE stmt FROM @querySql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetEmployeesByRepId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetEmployeesByRepId`(
	IN repId int(11)
)
BEGIN
    DECLARE whereQuery varchar(255);
	
    SET whereQuery = ' WHERE 1=1 and Type like "Staff" ';
    
	IF(repId IS NOT NULL AND repID >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `RepId` = ', repId);
	END IF;
    
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from ( select distinct `employees`.RepId as `RepId`,
									`employees`.FirstName as `FirstName`,
									`employees`.Email as `Email`,
                                    `employees`.LastName as `LastName`,
                                    `employees`.Fax as `Fax`,
                                    `employees`.Ext as `Ext`,
                                    `employees`.Active as `Active`,
                                    `employees`.OutOfOffice as `OutOfOffice`,
                                    `employees`.SRepOrder as `SRepOrder`,
                                     `employees`.MaxNumOrders as `MaxNumOrders`,
                                    `employees`.LoggedIn as `LoggedIn`,
                                    `employees`.Dnd as `Dnd`,
                                    `employees`.ProfilePicture as `ProfilePicture`,
                                    `user_roles`.RoleId as `RoleId`,
                                    `roles`.RoleName as `RoleName`,
                                    `roles`.Type as `Type`,
                                    `sales_reps`.CommissionPercent as `CommissionPercent`,
                                    `sales_reps`.CommissionAmount as `CommissionAmount`,
                                    `users`.UsersId as `UsersId`
							FROM `employees`  
                            LEFT JOIN `users` on `employees`.RepId = `users`.MappingUserId
                            LEFT JOIN `user_roles` on `users`.UsersId = `user_roles`.UsersId   
							LEFT JOIN `roles` on `user_roles`.RoleId = `roles`.RoleId
                            LEFT JOIN `sales_reps` on `employees`.RepId = `sales_reps`.RepID) t1, (SELECT @rownum := 0) r', whereQuery );


    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;    
    
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetFaxbacksOrderDashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetFaxbacksOrderDashboard`(
	IN pageNumber int,
	IN pageSize int,
    IN role varchar(255),
	IN clientId int
)
BEGIN
    DECLARE limitQuery varchar(255);
    DECLARE andWhereQuery varchar(500);
	IF (role = 'Client') 
		THEN SET andWhereQuery = CONCAT(' AND (`order`.BrokerId=',clientId,' or `order`.BrokerId in (select Brokerid from `broker` where `broker`.GID = ',clientId, '))');
	ELSE IF  (role = 'Branch') 
		THEN SET andWhereQuery = CONCAT(' AND `order`.BrokerId=',clientId);
	ELSE IF (role = 'Agent') 
		THEN SET andWhereQuery = CONCAT(' AND `order`.AgentId=',clientId);
		END IF;
    END IF;
    END IF;
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
	SET @querySqlFaxbacks = CONCAT(' SELECT SQL_CALC_FOUND_ROWS `order`.`OrderId` AS `orderId`,
								CONVERT(TIME_FORMAT(TIMEDIFF(UTC_TIMESTAMP(),`order`.AptDateTime - INTERVAL `zip`.UTC HOUR), "%H : %i"), char(10)) AS `time`
								FROM `order`
                                INNER JOIN zip ON `order`.Zip = `zip`.Zip
                                LEFT JOIN `agent` on `order`.AgentId = `agent`.AgentId 
								LEFT JOIN `broker` on `order`.BrokerId = `broker`.BrokerID 
								WHERE `order`.FaxBackReq = 1
								AND `order`.FaxBackAcceptDate IS NULL
                                AND `order`.InActive = 0
								AND HOUR(TIMEDIFF(UTC_TIMESTAMP(),`order`.AptDateTime - INTERVAL `zip`.UTC HOUR)) >= 2
                                AND UTC_TIMESTAMP() > `order`.AptDateTime - INTERVAL `zip`.UTC HOUR ',andWhereQuery,
                                ' ORDER BY `time` ASC ' ,limitQuery);
	PREPARE stmt FROM @querySqlFaxbacks;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecordsFaxbacks;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetFeeRequest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetFeeRequest`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN repId int,
IN statusId int,
IN qCId int,
IN orderId int,
IN feeApproved varchar(100)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = 'WHERE fd.Active = 1 ';
    
    IF (repId IS NOT NULL AND repId <> '') 
		THEN SET whereQuery = CONCAT(whereQuery ,'AND o.RepId = ', repId);
	END IF;
    
    IF (statusId IS NOT NULL AND statusId <> '') 
		THEN SET whereQuery = CONCAT(whereQuery ,' AND o.StatusID = ', statusId);
	END IF;
    
    IF (qCId IS NOT NULL AND qCId <> '') 
		THEN SET whereQuery = CONCAT(whereQuery ,' AND o.QCID = ', qCId);
	END IF;
    
	IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND f.OrderId LIKE ''%', orderId, '%''');
	END IF;
    
    IF (feeApproved IS NOT NULL AND feeApproved <>'All')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND f.FeeApproved = ''', feeApproved, '''');
	END IF;

	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS 
			f.FeeApprovalId,
			f.DateStamp AS RequestDate,
			u.UserName,
            u.UsersId,
            u.MappingUserId AS SignerId,
			f.OriginalAmount AS OriginalFee,
			f.FeeAmount AS ProposedFee,
			r.ReasonDescription,
			f.FeeApproved as Status,
			f.FeeDescripId,
			f.OrderId,
			f.FeeReason,
            o.ProgressId,
            CASE WHEN IsUserVendor(u.UsersId) = 1 THEN \'Vendor\' ELSE \'\' END AS Type,
			fd.Description AS FeeDescription,
			of.BrokerFee AS ClientFee
		FROM `order_fee_approve` AS f
		INNER JOIN `fee_description` AS fd ON fd.FeeDescriptionId = f.FeeDescripId
        LEFT JOIN `order` o ON f.OrderId = o.OrderId
		LEFT JOIN `order_fee` AS of ON of.OrderID=f.OrderId AND of.FeeDescripID=f.FeeDescripId
		LEFT JOIN `order_fee_approve_reason` AS r ON f.ReasonCode = r.ReasonCode
		LEFT JOIN `users` AS u ON u.UsersId = f.UsersId
            ', whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetFeeRequestDemo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetFeeRequestDemo`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
/* IN roleName varchar(255),*/
IN repId int,
IN statusId int,
/*IN qCId int,*/
IN orderId int,
IN feeApproved varchar(100)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = '';
    
    IF (repId IS NOT NULL AND repId <> '') 
		THEN SET whereQuery = CONCAT(whereQuery ,'AND o.RepId = ', repId);
	END IF;
    
    IF (statusId IS NOT NULL AND statusId <> '') 
		THEN SET whereQuery = CONCAT(whereQuery ,' AND o.StatusID = ', statusId);
	END IF;
    
    /*IF (qCId IS NOT NULL AND qCId <> '') 
		THEN SET whereQuery = CONCAT(whereQuery ,' AND o.QCID = ', qCId);
	END IF;*/
    /*IF (roleName IS NOT NULL AND roleName <> '') 
		THEN SET whereQuery = CONCAT(whereQuery ,'AND o.RepId = ', repId);
	END IF;*/
    
	IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,'AND ofa.OrderId = ', orderId);
	END IF;
    
    IF (feeApproved IS NOT NULL AND feeApproved <>'All')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND ofa.FeeApproved = ''', feeApproved, '''');
	END IF;

	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS 
			ofa.FeeApprovalId,
			ofa.DateStamp AS RequestDate,
			u.UserName,
            u.UsersId,
            u.MappingUserId AS SignerId,
			ofa.OriginalAmount AS OriginalFee,
			ofa.FeeAmount AS ProposedFee,
			ofa.FeeApproved as Status,
			ofa.FeeDescripId,
			ofa.OrderId,
			ofa.FeeReason,
            o.ProgressId,
            r.ReasonDescription,
            CASE WHEN IsUserVendor(u.UsersId) = 1 THEN \'Vendor\' ELSE \'\' END AS Type,
			of.FeeDescripID AS FeeDescription,
			of.BrokerFee AS ClientFee
		FROM `order_fee_approve` AS ofa
		LEFT JOIN `order_fee` AS of ON of.FeeDescripID = ofa.FeeDescripId AND of.OrderID=ofa.OrderId 
        LEFT JOIN `order` o ON ofa.OrderId = o.OrderId AND o.IsSelfService = 0
		LEFT JOIN `order_fee_approve_reason` AS r ON ofa.ReasonCode = r.ReasonCode
		LEFT JOIN `users` AS u ON u.UsersId = ofa.UsersId
        WHERE 1=1 
		', whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetFollowingPeople` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetFollowingPeople`(
IN role varchar(255),
IN clientId int,
IN gid int
)
BEGIN
	IF (role = 'Client') 
	THEN 
        select u.UsersId, b.Company, a.FullName, ur.RoleId, u.Status
		from `users` u
		left join `agent` a on a.AgentId = u.MappingUserId
		left join `broker` b on b.BrokerID = u.MappingUserId
		inner join `user_roles` ur on ur.UsersId = u.UsersId
		where (ur.RoleId=6 or ur.RoleId=7) and (a.BrokerId=clientId or b.GID=clientId);
	ELSE IF (role = 'Branch')
    THEN
		(select u.UsersId, a.FullName, "" as Company, ur.RoleId, u.Status
		from `agent` a 
		inner join `users` u on a.AgentId = u.MappingUserId
		inner join `user_roles` ur on ur.UsersId = u.UsersId
		where a.BrokerID=clientId and ur.RoleId=7) 
        union
		(select u.UsersId, "" as FullName, b.Company, ur.RoleId, u.Status
		from `broker` b 
		inner join `users` u on b.BrokerID = u.MappingUserId
		inner join `user_roles` ur on ur.UsersId = u.UsersId
		where b.BrokerID=gid and ur.RoleId=5);
	ELSE IF (role = 'Agent') 
	THEN 
        SET @branchId = (select 
			case when c.BrokerID IS NULL THEN NULL ELSE b.BrokerID END AS BranchId
			from `agent` a
			inner join `broker` b on a.BrokerId = b.BrokerID
			left join `broker` c on c.BrokerID = b.GID
			WHERE a.AgentId = clientId);
            
		SET @clientId = (select 
			case when c.BrokerID IS NULL THEN b.BrokerID ELSE c.BrokerID END AS ClientId
			from `agent` a
			inner join `broker` b on a.BrokerId = b.BrokerID
			left join `broker` c on c.BrokerID = b.GID
			WHERE a.AgentId = clientId);
            
        SELECT u.UsersId, "" as FullName, b.Company, ur.RoleId, u.Status
			FROM `broker` b
			INNER JOIN `users` u ON b.BrokerID = u.MappingUserId
			INNER JOIN `user_roles` ur ON ur.UsersId = u.UsersId 
			WHERE (b.BrokerID = @branchId OR b.BrokerID = @clientId) AND (ur.RoleId = 5 OR ur.RoleId = 6);
	END IF;
    END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetFrequentlyAskedQuestions` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetFrequentlyAskedQuestions`(
	views VARCHAR(250)
)
BEGIN
	-- DECLARE queryStr VARCHAR(1000);
    
    SET @queryStr = CONCAT("SELECT * FROM `faq` WHERE Views IN (", views, ")");
    
    PREPARE stmt1 FROM @queryStr; 
	EXECUTE stmt1; 
	DEALLOCATE PREPARE stmt1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetIndustries` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetIndustries`(
IN industryName varchar(500),
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';
    
    IF (industryName IS NOT NULL AND industryName <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND ind.description LIKE  ''%', industryName, '%''');
	END IF;
    
	SET @querySql= concat('
     SELECT 
     SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			ind.industryId,
            ind.description as industryName,
            (CASE 
				WHEN (SELECT COUNT(*) FROM Broker Where industryId = ind.industryId) = 0 THEN  ''N''	
				ELSE ''Y'' END) as isUsedForBroker
			from industry ind
            , (SELECT @rownum := 0) r
            ',
            whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetInvoiceReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetInvoiceReport`(
IN fromDate VARCHAR(5000),
IN toDate VARCHAR(5000),
IN state VARCHAR(5000),
IN isIncludeBranches BIT,
IN brokerId INT,
IN orderId VARCHAR(5000),
In isSelfService BIT
)
BEGIN
	DECLARE whereQuery varchar(5000);  
    
	SET whereQuery = ' WHERE 1=1 ';
    
    IF (isIncludeBranches = 1) 
		THEN SET whereQuery = CONCAT(whereQuery, ' AND (br.brokerId= ',brokerId,' or br.gId=',brokerId,')');
    ELSE     
	    SET whereQuery = CONCAT(whereQuery, ' AND (br.brokerId = ',brokerId,')');
    END IF;
    
    IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND (ord.orderId= ',orderId,')');
	END IF;
    
	IF (isSelfService IS NOT NULL AND isSelfService = false)
		THEN SET whereQuery = CONCAT(whereQuery, ' AND (ord.isSelfService is null OR ord.isSelfService = 0 )');
	END IF;
    
    IF (isSelfService IS NOT NULL AND isSelfService = true)
		THEN SET whereQuery = CONCAT(whereQuery, ' AND (ord.isSelfService = 1 )');
	END IF;
    
	IF (state IS NOT NULL AND state <> '' AND state <> 'null')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND (ord.state= ''',state,''')');
	END IF;
    
    SET whereQuery = CONCAT(whereQuery, ' AND ord.progressId = 8');
    SET whereQuery = CONCAT(whereQuery, ' AND ROUND((SELECT SUM(of.brokerFee) FROM order_fee of WHERE of.orderId=ord.orderId),2) > 0');

    IF (fromDate IS NULL OR fromDate = '' OR fromDate = 'null')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND ord.closedDate < DATE_ADD(''',toDate,''', INTERVAL 1 DAY) ');
	ELSE 
    SET whereQuery = CONCAT(whereQuery, ' AND ord.closedDate >= ''',fromDate,''' AND ord.closedDate < DATE_ADD(''',toDate,''', INTERVAL 1 DAY) ');
    END IF;
    
	SET @querySql= concat('
    SELECT ord.orderId, ord.closedDate, br.company, cr.courier,
    CONCAT(a.firstName,'' '', a.lastName) as agentFullName,
    br.address, CONCAT(br.city,'', '',br.state,'' '',br.zip) as csz,
    ord.brokerIdNum, CONCAT(ord.firstName,'' '', ord.lastName) as borrower,
    ord.lastName,ord.orderDate,ord.city,ord.state,
    CONCAT(ord.address,'', '',ord.city,'', '',ord.state,'' '',ord.zip) as signAdd,
    DATE_SUB(ord.aptDateTime, INTERVAL ord.aptUtc HOUR) as aptDateTime,ord.trackingNumber, a.fax, 
    ROUND((SELECT SUM(of.brokerFee) FROM order_fee of WHERE of.orderId=ord.orderId),2) as totalFee
	FROM `order` ord
    LEFT JOIN agent a on a.agentId = ord.agentId
    LEFT JOIN courier cr on cr.courierID=ord.courierID
    LEFT JOIN broker br on br.brokerId = ord.brokerId',whereQuery,' ORDER BY ord.closedDate');
	
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getListClientOrderAssignConfigLog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `getListClientOrderAssignConfigLog`(
	IN clientId int,
    IN isCustomerPreferred boolean,
    IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255); 
    DECLARE tableName varchar(30);
    DECLARE idField varchar(15);
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY FirstName ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF; 
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    SET tableName = IF(isCustomerPreferred, 'customer_asgmt_config_log', 'broker_asgmt_config_log');
    SET idField = IF(isCustomerPreferred, 'customerId', 'brokerId');
    
    SET whereQuery = ' WHERE 1=1';
    
    IF (clientId IS NOT NULL AND clientId <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND t1.clientId = ', clientId);
	END IF;
    
    SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from
			(SELECT logId, ',idField,' as clientId, rating, GetSpecialtyForOrderAsmtTrainingLog(log.Specialty) as specialty, experienceNumber, GetProgramForOrderAsmtTrainingLog(log.Training) as training, preferredVendor, changedDate, GetFullNameByUserId(usersId) as changedBy
            FROM ',tableName,' log join users on changedBy = UsersId) t1, 
            (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
            
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getListClientPreferred` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `getListClientPreferred`(
	IN clientId int,
    IN isCustomerPreferred boolean,
    IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255); 
    DECLARE tableName varchar(30);
    DECLARE idField varchar(15);
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY FirstName ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF; 
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    SET tableName = IF(isCustomerPreferred, 'customer_preferred_vendor', 'broker_preferred_vendor');
    SET idField = IF(isCustomerPreferred, 'customerId', 'brokerId');
    
    SET whereQuery = ' WHERE 1=1';
    
    IF (clientId IS NOT NULL AND clientId <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND t1.clientId = ', clientId);
	END IF;

    
    SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from
			(SELECT id, ',idField,' as clientId, signerId, firstName, lastName, email, taxId, IF(signerId IS NULL, "Inactive", "Active") as status  FROM ',tableName,') t1, 
            (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetListServiceConfigRequest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetListServiceConfigRequest`(
	IN clientName varchar (255),
    IN requestStatus int,
    IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);  
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY UpdatedDate ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;   
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    SET whereQuery = ' WHERE 1=1';
    IF (clientName IS NOT NULL AND clientName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND t1.clientName LIKE ''%', clientName, '%''');
	END IF;
    IF (requestStatus IS NOT NULL AND requestStatus <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND t1.status = ', requestStatus);
	END IF;
    
    SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from
			(select configId, c.createdDate, updatedDate, clientId, c.status, c.effecttiveDate, b.Company as clientName, u.UserName as requestedBy
			FROM client_services_config c left join broker b on c.ClientID = b.BrokerID
            left join users u on u.UsersId = c.UpdatedBy) t1, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
            
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetManageInternalUsers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetManageInternalUsers`(
	IN repId int(11),
    IN repName varchar(255),
    IN repEmail varchar(255)
)
BEGIN
    DECLARE whereQuery varchar(255);
	
    SET whereQuery = ' WHERE 1=1 and Type like "Staff" ';
    
	IF(repId IS NOT NULL AND repID >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `RepId` = ', repId);
	END IF;
    
	IF (repName IS NOT NULL AND repName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `FirstName` LIKE ''%', repName, '%''');
	END IF;
    
    IF (repEmail IS NOT NULL AND repEmail <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Email` LIKE ''%', repEmail, '%''');
	END IF;
    
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from ( select distinct `employees`.RepId as `RepId`,
									`employees`.FirstName as `FirstName`,
									`employees`.Email as `Email`,
                                    `employees`.LastName as `LastName`,
                                    `employees`.Fax as `Fax`,
                                    `employees`.Ext as `Ext`,
                                    `employees`.Active as `Active`,
                                    `employees`.SRepOrder as `SRepOrder`,
									`employees`.MaxNumOrders as `MaxNumOrders`,
									`employees`.Dnd as `Dnd`,
									`employees`.LoggedIn as `LoggedIn`,
									`employees`.ProfilePicture as `ProfilePicture`,
                                    `user_roles`.RoleId as `RoleId`,
                                    `role_permission`.RoleName as `RoleName`,
                                    `role_permission`.Type as `Type`,
                                    `users`.UsersId as `UsersId`
							FROM `employees`  
                            LEFT JOIN `users` on `employees`.RepId = `users`.MappingUserId
                            LEFT JOIN `user_roles` on `users`.UsersId = `user_roles`.UsersId   
							LEFT JOIN `role_permission` on `user_roles`.RoleId = `role_permission`.RoleId) t1, (SELECT @rownum := 0) r', whereQuery );


    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetNotifByNotifID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetNotifByNotifID`(	
	IN notificationId int(11)
)
BEGIN
    DECLARE whereQuery varchar(255);
	
    SET whereQuery = ' WHERE 1=1 ';
     
	IF(notificationId IS NOT NULL AND notificationId >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `NotificationId` = ', notificationId);
	END IF;
     
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from ( select distinct `notification_templates`.NotifID as `NotificationId`,
									`notification_templates`.Type as `notificationType`,
									`notification_templates`.Purpose as `purpose`,
                                    `notification_templates`.FromName as `fromName`,
                                    `notification_templates`.FromEmail as `fromEmail`,
                                     `notification_templates`.Receiver as `receiver`,
                                    `notification_templates`.Subject as `subject`,
                                    `notification_templates`.Message as `message`
							FROM `notification_templates`) t1, (SELECT @rownum := 0) r', whereQuery );


    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetNotificationManagement` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetNotificationManagement`(
    IN notificationType varchar(255),
    IN purpose varchar(255),
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY NotifID ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE 1=1 ');
    
    IF (notificationType IS NOT NULL AND notificationType <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `NotificationType` LIKE ''%', notificationType, '%''');
	END IF;
    
    IF(purpose IS NOT NULL AND purpose <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Purpose LIKE ''%', purpose, '%''');
	END IF;
     set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from (select distinct 
									`notification_templates`.NotifID as `NotificationId`,
									`notification_templates`.Type as `NotificationType`,  
									`notification_templates`.Receiver as `Receiver`,
                                    `notification_templates`.Purpose as `Purpose`
							FROM `notification_templates`
                            ) t1, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getOrderClientAgentById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `getOrderClientAgentById`(
	IN clientId int(11),
    IN branchId int(11),
    IN searchString varchar(255),
    IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(5000);  
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY a.FullName';
	ELSE SET orderQuery = CONCAT(' ORDER BY a.', sortBy, sortDirectionQuery);
    END IF;
    
    SET whereQuery = 'where (a.Inactive is null OR a.Inactive=false) ';
    IF (branchId IS NOT NULL AND branchId > 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND a.BrokerId = ', branchId);
	ELSE
		SET whereQuery = CONCAT(whereQuery ,' AND (a.BrokerId = ', clientId ,' or a.BrokerId in (select b.BrokerID from broker b where b.GID = ',clientId,')) '); 
	END IF;
    
    IF (searchString IS NOT NULL AND searchString <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND ( a.FullName like "%', searchString ,'%" OR a.Email like "%', searchString ,'%" ) ');
	END IF;
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    IF (pageSize = -1) 
		THEN SET limitQuery= '';
	END IF;
    
    set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS a.AgentId, a.AfterhoursPhone, a.FullName, a.Direct, a.Ext, a.Fax, a.Email from agent a ', whereQuery, orderQuery, limitQuery);
    
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderCollectById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderCollectById`(
IN orderId INT(11)
)
BEGIN
	SELECT oc.Item1 as `1`, oc.Item2 as `2`, oc.Item3 as `3`, oc.Item4 as `4`, oc.Item5 as `5`
	FROM `order_collect` AS oc
	LEFT JOIN `order` AS o ON o.CollectID = oc.CollectID AND o.TenantID = oc.TenantID
	WHERE o.OrderID = orderId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderComment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderComment`(
	IN sortBy VARCHAR(255),
	IN sortDirection BIT,
	IN pageNumber INT,
	IN pageSize INT,
    IN order_id INT,
    IN roleType varchar(15)
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE 1=1 and OwnerID=', order_id, ' and TypeID=1 and ');
    SET whereQuery = CONCAT(whereQuery, '(IsPrivate IS NULL or IsPrivate=0 or ');
    SET whereQuery = CONCAT(whereQuery, '(IsPrivate=1 and GetUserType(CreatedBy)=\'', roleType, '\'))');
    
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from ( select `comment`.CommentID as `CommentID`,
									`comment`.CreatedDate as `CreatedDate`,         
									`comment`.Description as `Description`,                                     
									`comment`.OwnerID as `OwnerID`,                                     
									`comment`.TypeID as `TypeID`,                                    
									`comment`.TenantID as `TenantID`,                                     
                                    `comment`.IsPrivate as `IsPrivate`,
                                    `comment`.CreatedBy as CreatedBy,
									`roles`.Type as Type,                             
									CONCAT(`employees`.LastName, `employees`.FirstName) as `FirstName`,                                     
									CONCAT(`broker`.PrimaryContactFirst,`broker`.PrimaryContactLast) as PrimaryContact,                                     
									CONCAT(`signer`.FirstName, `signer`.LastName) as `CreateBySigner`                                            
                        FROM `comment`                             
									LEFT JOIN `users` on `comment`.CreatedBy = `users`.UsersId 
                                    LEFT JOIN `user_roles` on `users`.UsersId = `user_roles`.UsersId   
									LEFT JOIN `roles` on `user_roles`.RoleId = `roles`.RoleId                           
									LEFT JOIN `employees` on `users`.MappingUserId = `employees`.RepId                             
									LEFT JOIN `broker` on `users`.MappingUserId = `broker`.BrokerID        
									LEFT JOIN `signer` on `users`.MappingUserId = `signer`.SignerId) t1, (SELECT @rownum := 0) r', whereQuery, orderQuery, limitQuery );
	
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderDatesById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderDatesById`(
IN orderId INT(11)
)
BEGIN    
	SELECT o.OrderDate, o.FilledDate, o.AptDateTime, o.LocalAptDateTime, o.OriginalOrderDate, o.ClosedDate, o.CommentDate, o.DropDate
	FROM `order` AS o
    WHERE o.OrderId = orderId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getOrderDetailtStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `getOrderDetailtStatus`(
in order_Id int(11)
)
BEGIN
	select `order`.OrderId,
       `order`.DocDelMethod as `deliveryMethod`,
       `order`.RepId as `repId`,
       `order`.Filledby as `filledBy`,
       `order`.BrokerIdNum as `referenceNumber`,
       courier.Courier as `courier`,
       `order`.TrackingNumber as `trackingNumber`,
       broker.DefaultCourierAcnt as `courierAccountNumber`,
       `order`.TrackingNumber2 as `additionalTrackingNumber`,
       `order`.FaxBackReq as `faxBackRequired`,
       `order`.LoanType,
       `order`.ProgressId,
       `order`.Service,
       `order`.CustomerId,
       `order`.BrokerId,
       concat(employees.FirstName,' ', employees.LastName) as RepName
	from `order` left join broker on `order`.BrokerId = broker.BrokerID 
    left join courier on broker.DefaultCourierID = courier.CourierID 
    left join employees on `order`.RepId = employees.RepId
    where `order`.OrderId = order_Id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderFeeApproveGridView` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderFeeApproveGridView`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN orderId int,
IN feeApproved varchar(100)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = '';
	IF (orderId IS NOT NULL)
		THEN SET whereQuery = CONCAT(whereQuery ,' WHERE f.OrderId = ', orderId);
	END IF;

    IF (feeApproved IS NOT NULL AND feeApproved <>'All')
		THEN
			IF (whereQuery <> '')
				THEN
					SET whereQuery = CONCAT(whereQuery ,' AND');
				ELSE
					SET whereQuery = CONCAT(whereQuery ,' WHERE');
			END IF;
			SET whereQuery = CONCAT(whereQuery ,' f.FeeApproved = ''', feeApproved, '''');
	END IF;

	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS 
			f.FeeApprovalId,
			f.DateStamp AS RequestDate,
			u.UserName,
            u.UsersId,
            u.MappingUserId AS SignerId,
			f.OriginalAmount AS OriginalFee,
			f.FeeAmount AS ProposedFee,
			r.ReasonDescription,
			f.FeeApproved as Status,
			f.FeeDescripId,
			f.OrderId,
			f.FeeReason,
            o.ProgressId,
            CASE WHEN IsUserVendor(u.UsersId) = 1 THEN \'Vendor\' ELSE \'\' END AS Type,
			fd.Description AS FeeDescription,
			of.BrokerFee AS ClientFee
		FROM `order_fee_approve` AS f
		INNER JOIN `fee_description` AS fd ON fd.FeeDescriptionId = f.FeeDescripId
        LEFT JOIN `order` o ON f.OrderId = o.OrderId
		LEFT JOIN `order_fee` AS of ON of.OrderID=f.OrderId AND of.FeeDescripID=f.FeeDescripId
		LEFT JOIN `order_fee_approve_reason` AS r ON f.ReasonCode = r.ReasonCode
		LEFT JOIN `users` AS u ON u.UsersId = f.UsersId
            ', whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderFees` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderFees`(
IN order_Id INT(11)
)
BEGIN    
	SELECT 
        o.FeeId, 
        o.FeeDescripID,
        b.FeeDescription AS Description,
        o.BrokerFee, 
        o.SignerFee, 
        o.Comment,
        o.OrderID
	FROM order_fee AS o
	LEFT JOIN broker_fee AS b ON o.FeeDescripID = b.FeeId
    WHERE o.OrderID = order_Id
    ORDER BY Date;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderIssuesByOrderId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderIssuesByOrderId`(
	IN orderId int,
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE op.OrderID = ',orderId);
     
     set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
									op.ProblemID as ProblemId,
									pt.Description as Type,
                                    op.Date as Date,
                                    op.EnteredBy as EnteredBy, 
									u.UserName as UserName,                                     
                                    CASE op.Mistake
										WHEN 1 THEN  ''Y''										
										ELSE ''N''
									END as Mistake,
                                    op.OrderID as OrderID,
                                    ps.Description as Status
							FROM order_problem op
                            left join users u on u.UsersId = op.EnteredBy 
                            left join problem_types pt on op.type=pt.id
							left join problem_status ps on ps.Id = op.Status, 
                            (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderIssuesByVendorFilters` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderIssuesByVendorFilters`(
	IN InOrderId int,
	IN InStatus int,
	IN InProblemType int,
	IN InFromDate varchar(255),
	IN InToDate varchar(255),
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       	THEN SET orderQuery = ' ORDER BY Date ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

	SET whereQuery = 'WHERE order_problem.Mistake=1';

	IF (InOrderId IS NOT NULL) THEN 
		SET whereQuery = CONCAT(whereQuery, ' AND (order_problem.OrderId=', InOrderId, ')');
	END IF;

	IF (InStatus IS NOT NULL) THEN 
		SET whereQuery = CONCAT(whereQuery, ' AND (order_problem.Status=', InStatus, ')');
	END IF;
     
	IF (InProblemType IS NOT NULL) THEN 
		SET whereQuery = CONCAT(whereQuery, ' AND (order_problem.Type=', InProblemType, ')');
	END IF;
     
	IF (InFromDate IS NOT NULL) THEN 
		SET whereQuery = CONCAT(whereQuery, ' AND (order_problem.Date>= ''', InFromDate, ''')');
	END IF;
     
	IF (InToDate IS NOT NULL) THEN 
		SET whereQuery = CONCAT(whereQuery, ' AND (order_problem.Date <= ''', InToDate, ''')');
	END IF;
     
     set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS order_problem.OrderId, order_problem.ProblemID,
            c.Description as Description, order_problem.Date, b2.Company as BrokerCompanyName,
            problem_types.Description as ProblemType,
            GetFullNameByUserId(CreatedUser.UsersId) as CreatedBy, 
            problem_status.Description as Status
            FROM order_problem
            LEFT JOIN users as CreatedUser ON (order_problem.EnteredBy=CreatedUser.UsersId)
            LEFT JOIN problem_types ON (order_problem.Type=problem_types.Id)
            LEFT JOIN `order` as o ON (order_problem.OrderId=o.OrderId)
            LEFT JOIN `zip` on o.Zip = `zip`.Zip 
            LEFT JOIN \`broker\` b2 ON o.BrokerId = b2.BrokerID
            LEFT JOIN problem_status ON (order_problem.Status=problem_status.id)
            LEFT JOIN (select OwnerID, Description from comment as cm inner join (SELECT MIN(t.CreatedDate) AS min_CreatedDate FROM comment as t WHERE t.TypeID = 3 group by t.OwnerID) as m on m.min_CreatedDate = cm.CreatedDate) as c  ON (order_problem.OrderId=c.OwnerID)
            ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
SELECT FOUND_ROWS() AS TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderIssuesReportingByProblemId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderIssuesReportingByProblemId`(
	IN orderId int(12), 
    IN company varchar(255),
    IN vendorLastName varchar(255), 
    IN typeOrder varchar(255),
    IN statusOrder varchar(255),
    IN fromDate datetime,
	IN toDate datetime,
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(5000);  
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY `Order Date`';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
    
    SET whereQuery = ' WHERE 1=1 ';
    IF (orderID IS NOT NULL AND orderID >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `OrderId` = ', orderId);
	END IF;
    
	IF (company IS NOT NULL AND company <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Company` LIKE ''%', company, '%''');
	END IF;
    
    IF (vendorLastName IS NOT NULL AND vendorLastName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `VendorLastName` LIKE ''%', vendorLastName, '%''');
	END IF;
    
    IF (typeOrder IS NOT NULL AND typeOrder <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Type` LIKE ''%', typeOrder, '%''');
	END IF;
    
    IF (statusOrder IS NOT NULL AND statusOrder <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Status` LIKE ''%', statusOrder, '%''');
	END IF;
    
    IF (fromDate IS NOT NULL AND fromDate <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND date(`Date`) >= date("', fromDate,'")');
	END IF;
    
    IF (toDate IS NOT NULL AND toDate <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND date(`Date`) <= date("', toDate,'")');
	END IF;
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS `#`, t1.* from (select `signer`.LastName as `VendorLastName`,
									CONCAT(`signer`.FirstName, '' '', `signer`.LastName) as `VendorName`, op.RepId as VendorId,
									op.OrderId as OrderId,
                                    br.Company as Company,
                                    op.ProblemId as ProblemId,
									pt.Description as Type,
                                    op.Date as Date,
                                    CONCAT(`employees`.FirstName, '' '', `employees`.LastName) as `FirstName`,
                                    op.EnteredBy as EnteredBy, 
									u.UserName as UserName,                                     
                                    CASE op.Mistake
										WHEN 1 THEN  ''Y''										
										ELSE ''N''
									END as Mistake,
                                    ps.Description as Status
							FROM order_problem op
                            LEFT JOIN `signer` on op.RepId = `signer`.SignerId  
                            left join users u on u.UsersId = op.EnteredBy 
                            left join broker br on op.RepId = br.BrokerID 
                            left join employees on op.RepId = employees.RepId
                            left join problem_types pt on op.type=pt.id
							left join problem_status ps on ps.Id = op.Status) t1, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
                   
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

    SELECT FOUND_ROWS() as TotalRecords;
    
    SELECT Id, Description FROM problem_status;
    SELECT Id, Description FROM problem_types;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderProblemsByOrder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderProblemsByOrder`(
	IN orderId int,
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY ProblemId ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;

	IF (pageSize IS NOT NULL) THEN
		IF (pageNumber IS NULL) THEN SET pageNumber = 1;
        END IF;
		SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	ELSE
		SET limitQuery = ' ';
	END IF;
	
    SET whereQuery = CONCAT(' WHERE op.OrderId=', orderId, ' ');
     
     set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS
									op.ProblemId,
									`signer`.LastName as `VendorLastName`,
									op.OrderId as OrderId,
                                    br.Company as Company,
                                    op.ProblemId as ProblemId,
									pt.Description as Type,
                                    op.Date as Date,
                                    CONCAT(`employees`.FirstName, " " ,`employees`.LastName) as `FirstName`,
                                    op.EnteredBy as EnteredBy, 
									u.UserName as UserName,                                     
                                    CASE op.Mistake
										WHEN 1 THEN  ''Y''										
										ELSE ''N''
									END as Mistake,
                                    op.OrderID as OrderID,
                                    ps.Description as Status
							FROM order_problem op
							LEFT JOIN `signer` on op.RepId = `signer`.SignerId 
                            left join users u on u.UsersId = op.EnteredBy 
							left join broker br on op.RepId = br.BrokerID 
                            left join employees on op.RepId = employees.RepId
                            left join problem_types pt on op.type=pt.id
							left join problem_status ps on ps.Id = op.Status ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderProgressClient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderProgressClient`(
IN role varchar(255),
IN clientId int,
IN progressGroup varchar(255),
IN sortColumn varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	DECLARE selectQuery varchar(5000);
	DECLARE joinQuery varchar(5000);
	DECLARE andWhereQuery varchar(5000);
    DECLARE orderQuery varchar(255);
    DECLARE sortDirectionQuery varchar(255);
    DECLARE limitQuery varchar(255);
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortColumn IS NULL OR sortColumn = '')
       THEN SET orderQuery = ' ORDER BY OrderId DESC ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortColumn, sortDirectionQuery);        
    END IF; 
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
	IF (role = 'Client') 
		THEN SET andWhereQuery = CONCAT(' and (o.BrokerId=',clientId,' or (o.BrokerId in (select Brokerid from `broker` where `broker`.GID = ',clientId, ')))');
	ELSE IF  (role = 'Branch') 
		THEN SET andWhereQuery = CONCAT(' and o.BrokerId=',clientId);
	ELSE IF (role = 'Agent') 
		THEN SET andWhereQuery = CONCAT(' and o.AgentId=',clientId);
		END IF;
    END IF;
    END IF;
    
    SET selectQuery = 'o.OrderId, `broker`.Company as BranchName, `agent`.FullName Agent, CONCAT(`signer`.LastName, \" \", `signer`.FirstName) as Vendor, `customers`.Name as Customer, 
    o.OrderDate, o.AptDateTime,`zip`.Utc as AptUtc ,o.ProgressId,o.CommentDate,o.InActive as InactiveStatus, o.OrderId as TheOrderId, 
    (CASE WHEN TIMEDIFF(DATE_ADD(o.AptDateTime, Interval -`zip`.UTC Hour),UTC_TIMESTAMP()) < 0 THEN NULL ELSE TIMEDIFF(DATE_ADD(o.AptDateTime, Interval -`zip`.UTC Hour),UTC_TIMESTAMP()) END) as Signing,
    o.State, o.ProgressId as Stage, p.ProgressDescription as Status, (CASE WHEN o.IsSelfService <> 0 THEN \"Self service\" ELSE \"Full Service\" END) as Service,
    (CASE WHEN TIMEDIFF(UTC_TIMESTAMP(),o.LastUpdatedDate) < 0 THEN NULL ELSE ROUND(SUBSTRING_INDEX(TIMEDIFF(UTC_TIMESTAMP(),o.LastUpdatedDate), \":\", 1)/24,0) END) as LastActivity';
    SET joinQuery = 'LEFT JOIN `signer` on o.SignerId = `signer`.SignerId  
LEFT JOIN `borrower` on o.BorrowerId = `borrower`.BorrowerId 
LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
LEFT JOIN `broker` on o.BrokerId = `broker`.BrokerID 
LEFT JOIN `branches` on `agent`.BranchID = `branches`.BranchID 
LEFT JOIN `progress` as p on o.ProgressId = p.ProgressId
LEFT JOIN `employees` on o.RepId = `employees`.RepId
LEFT JOIN `customers` on o.CustomerId = `customers`.CustomerId
LEFT JOIN `zip` on o.Zip = `zip`.Zip';
    
    IF (progressGroup = 'Unassigned')
		THEN SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS ',selectQuery,' FROM `order` as o ',joinQuery,'
WHERE p.ProgressDescription = "Open" and o.RepId is null and o.SignerId is null and o.IsSelfService <> 1', andWhereQuery,orderQuery,limitQuery);
	ELSE IF (progressGroup = 'Unfilled')
		THEN SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS ',selectQuery,' FROM `order` as o ',joinQuery,'
WHERE p.ProgressDescription = "Open" and o.RepId is null and o.SignerId is null', andWhereQuery,orderQuery,limitQuery);
	ELSE IF (progressGroup = 'Unconfirmed')
		THEN SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS ',selectQuery,' FROM `order` as o ',joinQuery,'
WHERE p.ProgressDescription not IN ("Closing Completed","Hold","Canceled") and o.SignerId is not null and o.TurnAroundDate is null
	and (time_to_sec(TIMEDIFF(UTC_TIMESTAMP(), o.FilledDate))/60)>=120', andWhereQuery,orderQuery,limitQuery);
	ELSE IF (progressGroup = 'PendingDocs')
		THEN SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS ',selectQuery,' FROM `order` as o ',joinQuery,'
WHERE p.ProgressDescription = "Appt Confirmed Pending Docs" and DATE_ADD(o.AptDateTime, Interval -`zip`.UTC Hour)<DATE_ADD(UTC_TIMESTAMP(), Interval 180 Minute)', andWhereQuery,orderQuery,limitQuery);
	ELSE IF (progressGroup = 'Incomplete')
		THEN SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS ',selectQuery,' FROM `order` as o ',joinQuery,'
WHERE p.ProgressDescription = "Appt Ready" and (time_to_sec(TIMEDIFF(UTC_TIMESTAMP(),DATE_ADD(o.AptDateTime, Interval -`zip`.UTC Hour)))/60>60)', andWhereQuery,orderQuery,limitQuery);
	ELSE IF (progressGroup = 'FaxBacks')
		THEN SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS ',selectQuery,' FROM `order` as o ',joinQuery,'
WHERE o.FaxBackReq=1 and o.FaxBackAcceptDate is null and (time_to_sec(TIMEDIFF(UTC_TIMESTAMP(),DATE_ADD(o.AptDateTime, Interval -`zip`.UTC Hour)))/60>120)', andWhereQuery,orderQuery,limitQuery);
	END IF; END IF; END IF; END IF; END IF; END IF;
	
    PREPARE stmtCount FROM @querySql;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;

	SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderProgressClientDashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderProgressClientDashboard`(
IN role varchar(255),
IN clientId int
)
BEGIN
	DECLARE andWhereQuery varchar(21000);
	IF (role = 'Client') 
		THEN SET andWhereQuery = CONCAT(' and (o.BrokerId=',clientId,' or (o.BrokerId in (select Brokerid from `broker` where `broker`.GID = ',clientId, ')))');
	ELSE IF  (role = 'Branch') 
		THEN SET andWhereQuery = CONCAT(' and o.BrokerId=',clientId);
	ELSE IF (role = 'Agent') 
		THEN SET andWhereQuery = CONCAT(' and o.AgentId=',clientId);
		END IF;
    END IF;
    END IF;

	set @queryUnassignedSql = CONCAT('SELECT count(*) as COUNT, MAX(ROUND(time_to_sec(TIMEDIFF(UTC_TIMESTAMP(), o.OrderDate))/60,0)) as MAX FROM `order` as o
LEFT JOIN `progress` as p on o.ProgressId = p.ProgressId
LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
LEFT JOIN `broker` on o.BrokerId = `broker`.BrokerID 
WHERE p.ProgressDescription = "Open" and o.RepId is null and o.SignerId is null and o.IsSelfService <> 1', andWhereQuery);

	set @queryUnfilledSql = CONCAT('SELECT count(*) as COUNT, (CASE WHEN o.IsSelfService = 1 THEN MAX(ROUND(time_to_sec(TIMEDIFF(UTC_TIMESTAMP(), o.OrderDate))/60,0)) ELSE MAX(ROUND(time_to_sec(TIMEDIFF(UTC_TIMESTAMP(), o.RepAssignDate))/60,0)) END) as MAX FROM `order` as o
LEFT JOIN `progress` as p on o.ProgressId = p.ProgressId
LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
LEFT JOIN `broker` on o.BrokerId = `broker`.BrokerID 
WHERE p.ProgressDescription = "Open" and o.RepId is null and o.SignerId is null', andWhereQuery);

	set @queryUnconfirmedSql = CONCAT('SELECT count(*) as COUNT, MAX(ROUND(time_to_sec(TIMEDIFF(UTC_TIMESTAMP(), o.FilledDate))/60,0)) as MAX FROM `order` as o
LEFT JOIN `progress` as p on o.ProgressId = p.ProgressId
LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
LEFT JOIN `broker` on o.BrokerId = `broker`.BrokerID 
WHERE p.ProgressDescription not IN ("Closing Completed","Hold","Canceled") and o.SignerId is not null and o.TurnAroundDate is null
	and (time_to_sec(TIMEDIFF(UTC_TIMESTAMP(), o.FilledDate))/60)>=120', andWhereQuery);
    
	set @queryPendingDocsSql = CONCAT('SELECT count(*) as COUNT, MIN(ROUND(time_to_sec(TIMEDIFF(DATE_ADD(o.AptDateTime, Interval -`zip`.UTC Hour),UTC_TIMESTAMP()))/60,0)) as MAX FROM `order` as o
LEFT JOIN `progress` as p on o.ProgressId = p.ProgressId
LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
LEFT JOIN `broker` on o.BrokerId = `broker`.BrokerID 
LEFT JOIN `zip` on o.Zip = `zip`.Zip
WHERE p.ProgressDescription = "Appt Confirmed Pending Docs" and DATE_ADD(o.AptDateTime, Interval -`zip`.UTC Hour)<DATE_ADD(UTC_TIMESTAMP(), Interval 180 Minute)', andWhereQuery);

	set @queryIncompleteSql = CONCAT('SELECT count(*) as COUNT, MAX(ROUND(time_to_sec(TIMEDIFF(UTC_TIMESTAMP(),DATE_ADD(o.AptDateTime, Interval -`zip`.UTC Hour)))/60,0)) as MAX FROM `order` as o
LEFT JOIN `progress` as p on o.ProgressId = p.ProgressId
LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
LEFT JOIN `broker` on o.BrokerId = `broker`.BrokerID 
LEFT JOIN `zip` on o.Zip = `zip`.Zip
WHERE p.ProgressDescription = "Appt Ready" and (time_to_sec(TIMEDIFF(UTC_TIMESTAMP(),DATE_ADD(o.AptDateTime, Interval -`zip`.UTC Hour)))/60>60)', andWhereQuery);

	set @queryFaxBacksSql = CONCAT('SELECT count(*) as COUNT, MAX(ROUND(time_to_sec(TIMEDIFF(UTC_TIMESTAMP(),DATE_ADD(o.AptDateTime, Interval -`zip`.UTC Hour)))/60,0)) as MAX FROM `order` as o
LEFT JOIN `progress` as p on o.ProgressId = p.ProgressId
LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
LEFT JOIN `broker` on o.BrokerId = `broker`.BrokerID 
LEFT JOIN `zip` on o.Zip = `zip`.Zip
WHERE o.FaxBackReq=1 and o.FaxBackAcceptDate is null and (time_to_sec(TIMEDIFF(UTC_TIMESTAMP(),DATE_ADD(o.AptDateTime, Interval -`zip`.UTC Hour)))/60>120)', andWhereQuery);

	PREPARE stmtCount FROM @queryUnassignedSql;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryUnfilledSql;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryUnconfirmedSql;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingDocsSql;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryIncompleteSql;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryFaxBacksSql;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getOrderProgressLog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `getOrderProgressLog`(
	IN OrderId int(11),
    IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN accountId int(11)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY opl.DateLog ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';
    IF (OrderId IS NOT NULL AND OrderId >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND opl.OrderId = ', OrderId);
	END IF;
    
    SET whereQuery = CONCAT(whereQuery,' AND (opl.IsPrivate = 0 or opl.UsersId = ',accountId,'  or "Vendor" IN (select distinct rp.Type from user_roles ur join roles rp on ur.RoleId = rp.RoleId where ur.UsersId = opl.UsersId )) ');
    
    SET @querySql = concat('select  SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,opl.ProgressLogId, opl.DateLog as Date, opl.Activity, u.UserName as Actor
									from order_progress_log opl
									left join users u on u.UsersId = opl.UsersId
                                    ,(SELECT @rownum := 0) r ',
						  whereQuery, orderQuery, limitQuery);
                          
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderRating` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderRating`(
IN pageNumber int,
IN pageSize int,
IN agentId int,
IN managerId int,
IN signerId int
)
BEGIN
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);  
    DECLARE totalAgentId varchar(255);

    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
	SET whereQuery = CONCAT(' WHERE o.ProgressId = 8 AND o.signerId = ', signerId);
	
	IF(agentId IS NOT NULL AND agentId <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND o.AgentId = ', agentId);
	END IF;
	
	IF(managerId IS NOT NULL AND managerId <> '')
		THEN 
			SELECT GROUP_CONCAT(a.AgentId) INTO totalAgentId FROM agent a WHERE a.BrokerId = managerId;
			SET whereQuery = CONCAT(whereQuery, ' AND o.BrokerId = ', managerId, ' OR o.AgentId IN (',totalAgentId,') ');
	END IF;
    
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS r.Rating AS rating, o.OrderId AS orderId, o.ClientRatingDate AS clientRatingDate from `order` o
	LEFT JOIN rating r ON r.RatingID = o.RatingId ', whereQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;    
    
	SELECT FOUND_ROWS() AS TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderRequestedFee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderRequestedFee`(
IN order_Id INT(11)
)
BEGIN
	DECLARE originalVendorFee DECIMAL(19, 4);
    DECLARE originalClientFee DECIMAL(19, 4);
    DECLARE currentVendorFee DECIMAL(19, 4);
    
    SELECT SUM(of.OriginalSignerFee), SUM(of.SignerFee)
    INTO originalVendorFee, currentVendorFee
    FROM `order_fee`AS of
    WHERE of.OrderID = order_id;
    
    SELECT SUM(of.BrokerFee)
    INTO originalClientFee
    FROM `order_fee`AS of
    WHERE of.OrderID = order_id;
    
    SELECT
		`f`.`FeeApprovalId`,
		`f`.`DateStamp` AS `RequestDate`,
        `u`.`UserName`,
        originalVendorFee AS `OriginalVendorFee`,
        originalClientFee AS `OriginalClientFee`,
        currentVendorFee AS `CurrentVendorFee`,
        CASE WHEN `f`.`IsClientFee` = true THEN 0 ELSE GetTotalAdditionalVendorFee(`f`.`OrderID`, `FeeDescripId`) + IFNULL(`FeeAmount`, 0) END AS `ProposedVendorFee`,
        CASE WHEN `f`.`IsClientFee` = true THEN GetTotalAdditionalClientFee(`f`.`OrderID`, `FeeDescripId`) + IFNULL(`FeeAmount`, 0) ELSE 0 END AS `ProposedClientFee`,
        `r`.`ReasonDescription`,
        `f`.`FeeApproved` as `Status`,
        `f`.`FeeDescripId`,
        `f`.`OrderId`,
        `f`.`FeeReason`,
        `b`.`FeeDescription`,
        'Site' AS `RequestedFrom`,
        `f`.`SignerId`,
        CONCAT_WS(' ', `s`.`FirstName`, `s`.`LastName`) AS `VendorName`,
        `OfferId`,
        `FeeAmount`,
        `u`.`UsersId` AS `RequestedBy`,
        `o`.`agentId`,
        GetUserType(`f`.`UsersId`) AS `UserType`,
        IF(`f`.`IsClientFee` = true, 1, 0) AS `IsClientFee`,
        GetFullNameByUserId(`f`.`ApprovedBy`) AS ApprovedBy
	FROM `order_fee_approve` AS f
    INNER JOIN `broker_fee` AS b ON b.FeeId = f.FeeDescripId
    LEFT JOIN `order_fee_approve_reason` AS r ON f.ReasonCode = r.ReasonCode
    LEFT JOIN `users` AS u ON u.UsersId = f.UsersId
    LEFT JOIN `order` AS o ON o.orderId = f.orderId
    LEFT JOIN `signer` AS s ON s.SignerId = f.SignerID
    WHERE f.OrderID = order_Id AND (GetUserType(f.UsersId) = 'Staff' OR GetUserType(f.UsersId) = 'Vendor')
    ORDER BY f.DateStamp DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderRequestedFeeTypeDemo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderRequestedFeeTypeDemo`(
IN order_Id INT(11),
IN type_Submitted varchar(250)
)
BEGIN
	DECLARE OriginalFee DECIMAL(19, 4);
    DECLARE whereQuery varchar(5000);
    
    SELECT SUM(of.OriginalSignerFee)
    INTO OriginalFee
    FROM `order_fee`AS of
    WHERE of.OrderID = order_id;
    
    SET whereQuery = CONCAT(' WHERE f.OrderID = ', order_Id);
    
    IF (type_Submitted = 'ByVendor')
       THEN SET whereQuery = CONCAT(whereQuery, ' and GetUserType(f.UsersId)=''Vendor''');
    END IF;
    IF (type_Submitted = 'ByScheduler_Vendor')
       THEN SET whereQuery = CONCAT(whereQuery, ' and GetUserType(f.UsersId)<>''Vendor'' and f.IsClientFee=0');
    END IF;
    IF (type_Submitted = 'ByScheduler_Client')
       THEN SET whereQuery = CONCAT(whereQuery, ' and GetUserType(f.UsersId)<>''Vendor'' and f.IsClientFee=1');
    END IF;
    
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS 
		f.FeeApprovalId,
		f.DateStamp AS RequestDate,
        u.UserName,
        ',OriginalFee,',
        GetTotalAdditionalFee(f.OrderID, FeeDescripId) + IFNULL(FeeAmount, 0) AS ProposedFee,
        r.ReasonDescription,
        f.FeeApproved as Status,
        f.FeeDescripId,
        f.OrderId,
        f.FeeReason,
        f.IsClientFee,
        CASE WHEN IsUserVendor(u.UsersId) = 1 THEN ''Vendor'' ELSE '''' END AS Type,
        b.FeeDescription,
        ''Site'' AS RequestedFrom,
        f.SignerID,
        b.BrokerFee,
        b.VendorFee,
        CONCAT_WS('' '', s.FirstName, s.LastName) AS VendorName,
        OfferId,
        FeeAmount,
        u.UserName AS RequestedBy,
        o.agentId
	FROM `order_fee_approve` AS f
    INNER JOIN `broker_fee` AS b ON b.FeeId = f.FeeDescripId
    LEFT JOIN `order_fee_approve_reason` AS r ON f.ReasonCode = r.ReasonCode
    LEFT JOIN `users` AS u ON u.UsersId = f.UsersId
    LEFT JOIN `order` AS o ON o.orderId = f.orderId
    LEFT JOIN `signer` AS s ON s.SignerId = f.SignerID', whereQuery, '
    ORDER BY f.DateStamp DESC;');
    
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

	SELECT FOUND_ROWS() AS TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrders` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrders`(
	IN sortBy varchar(255),
	IN sortDirection bit,
    IN andWhere varchar(21000),
	IN pageNumber int,
	IN pageSize int,
    IN groupStatus varchar(255),
    IN orderId int,
    IN vendorLastName varchar(255),
    IN customerLastName varchar(255),
    IN companyBranch int,
    IN agentName varchar(255),
    IN statusOrder int,
    IN AptDateFrom varchar(255),
    IN AptDateTo varchar(255),
    IN OrderDateFrom varchar(255),
    IN OrderDateTo varchar(255)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(21000);  
    
    IF (sortDirection = true) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = CONCAT(' ORDER BY `OrderId`', sortDirectionQuery);
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
    
    IF (pageNumber IS NULL OR pageNumber = '') THEN SET pageNumber = 1; END IF;
    IF (pageSize IS NULL OR pageSize = '') THEN SET pageSize = 25; END IF;
    
    SET whereQuery = CONCAT(' WHERE o.InActive = false AND o.IsSelfService = 0 and (o.OrderDate > adddate(UTC_TIMESTAMP(), ''-120'') or o.OrderDate is null) ', andWhere);
    
    IF (orderId IS NOT NULL)
        THEN SET whereQuery = CONCAT(whereQuery, ' AND o.OrderId=', orderId);
    END IF;
    IF (vendorLastName IS NOT NULL AND vendorLastName <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND `signer`.LastName LIKE ''%', vendorLastName, '%''');
    END IF;
    IF (customerLastName IS NOT NULL AND customerLastName <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND `borrower`.LastName LIKE ''%', customerLastName, '%''');
    END IF;
    IF (companyBranch IS NOT NULL)
        THEN SET whereQuery = CONCAT(whereQuery, ' AND `broker`.BrokerID=', companyBranch);
    END IF;
    IF (agentName IS NOT NULL AND agentName <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND `agent`.FullName LIKE ''%', agentName, '%''');
    END IF;
    IF (statusOrder IS NOT NULL)
        THEN SET whereQuery = CONCAT(whereQuery, ' AND o.ProgressId=', statusOrder);
    END IF;
    IF (AptDateFrom IS NOT NULL AND AptDateFrom <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND DATE(DATE_ADD(o.AptDateTime, Interval `zip`.UTC Hour)) >= ''', AptDateFrom, '''');
    END IF;
    IF (AptDateTo IS NOT NULL AND AptDateTo <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND DATE(DATE_ADD(o.AptDateTime, Interval `zip`.UTC Hour)) <= ''', AptDateTo, '''');
    END IF;
    IF (OrderDateFrom IS NOT NULL AND OrderDateFrom <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND DATE(o.OrderDate) >= ''', OrderDateFrom, '''');
    END IF;
    IF (OrderDateTo IS NOT NULL AND OrderDateTo <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND DATE(o.OrderDate) <= ''', OrderDateTo, '''');
    END IF;

    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    set @querySqlCount = CONCAT('select `progress`.ProgressDescription as Status, Count(*) as Total
from `order` as o
LEFT JOIN `signer` on o.SignerId = `signer`.SignerId  
LEFT JOIN `borrower` on o.BorrowerId = `borrower`.BorrowerId 
LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
LEFT JOIN `broker` on `agent`.BrokerId = `broker`.BrokerID
LEFT JOIN `progress` on o.ProgressId = `progress`.ProgressId
LEFT JOIN `employees` on o.RepId = `employees`.RepId
LEFT JOIN `customers` on o.CustomerId = `customers`.CustomerId
LEFT JOIN `zip` on o.Zip = `zip`.Zip ', whereQuery,' GROUP BY `progress`.ProgressId');
    PREPARE stmtCount FROM @querySqlCount;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
    
    IF (groupStatus = 'Null') THEN SET whereQuery = CONCAT(whereQuery, ' and `progress`.ProgressDescription IS NULL');
    ELSE IF (groupStatus IS NOT NULL) THEN SET whereQuery = CONCAT(whereQuery, ' and `progress`.ProgressDescription IN (', groupStatus, ')');
		END IF;
    END IF;
    
    set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, `borrower`.LastName as CLast, `signer`.LastName as VLast, `agent`.FullName Agent,`borrower`.LastName as Customer,
    `broker`.Company as CB, `progress`.ProgressDescription as Status, o.OrderDate as ODate, o.AptDateTime, DATE_ADD(o.AptDateTime, Interval `zip`.UTC Hour) as LocalDateTime,
    o.State as ST, `employees`.LastName as Rep, TIMESTAMPDIFF(MINUTE,o.OrderDate,o.FilledDate) as TCEFill,
    TIMESTAMPDIFF(MINUTE,o.RepAssignDate,o.FilledDate) as Fill, if(o.DocsToNot = true, ''Y'', ''N'') as Docs, if(o.FaxBackReq = true, ''Y'', ''N'') as FB,
    if(o.FaxBackAcceptDate > UTC_TIMESTAMP(), ''Y'', ''N'') as FBDocs, 
    o.signerId, o.CommentDate, o.repId
from `order` as o
LEFT JOIN `signer` on o.SignerId = `signer`.SignerId  
LEFT JOIN `borrower` on o.BorrowerId = `borrower`.BorrowerId 
LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
LEFT JOIN `broker` on `agent`.BrokerId = `broker`.BrokerID
LEFT JOIN `progress` on o.ProgressId = `progress`.ProgressId
LEFT JOIN `employees` on o.RepId = `employees`.RepId
LEFT JOIN `customers` on o.CustomerId = `customers`.CustomerId
LEFT JOIN `zip` on o.Zip = `zip`.Zip ',whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

SELECT FOUND_ROWS() AS TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrdersClientStaff` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrdersClientStaff`(
	IN sortBy varchar(255),
	IN sortDirection bit,
    IN andWhere varchar(21000),
	IN pageNumber int,
	IN pageSize int,
    IN groupStatus varchar(255),
    IN orderId int,
    IN vendorLastName varchar(255),
    IN customerLastName varchar(255),
    IN companyBranch int,
    IN agentName varchar(255),
    IN statusOrder int,
    IN AptDateFrom varchar(255),
    IN AptDateTo varchar(255),
    IN OrderDateFrom varchar(255),
    IN OrderDateTo varchar(255)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(21000);  
    
    IF (sortDirection = true) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = CONCAT(' ORDER BY o.`OrderId`', sortDirectionQuery);
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
    
    IF (pageNumber IS NULL OR pageNumber = '') THEN SET pageNumber = 1; END IF;
    IF (pageSize IS NULL OR pageSize = '') THEN SET pageSize = 25; END IF;
    
    SET whereQuery = CONCAT(' WHERE (o.ProgressId is not null Or o.InActive is not null) and (o.OrderDate > adddate(UTC_TIMESTAMP(), ''-120'') or o.OrderDate is null) ', andWhere);
    
    IF (orderId IS NOT NULL)
        THEN SET whereQuery = CONCAT(whereQuery, ' AND o.OrderId=', orderId);
    END IF;
    IF (vendorLastName IS NOT NULL AND vendorLastName <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND `signer`.LastName LIKE ''%', vendorLastName, '%''');
    END IF;
    IF (customerLastName IS NOT NULL AND customerLastName <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND `borrower`.LastName LIKE ''%', customerLastName, '%''');
    END IF;
    IF (companyBranch IS NOT NULL)
        THEN SET whereQuery = CONCAT(whereQuery, ' AND `broker`.BrokerID=', companyBranch);
    END IF;
    IF (agentName IS NOT NULL AND agentName <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND `agent`.FullName LIKE ''%', agentName, '%''');
    END IF;
    IF (statusOrder IS NOT NULL)
        THEN SET whereQuery = CONCAT(whereQuery, ' AND o.ProgressId=', statusOrder);
    END IF;
    IF (AptDateFrom IS NOT NULL AND AptDateFrom <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND DATE(DATE_ADD(o.AptDateTime, Interval `zip`.UTC Hour)) >= ''', AptDateFrom, '''');
    END IF;
    IF (AptDateTo IS NOT NULL AND AptDateTo <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND DATE(DATE_ADD(o.AptDateTime, Interval `zip`.UTC Hour)) <= ''', AptDateTo, '''');
    END IF;
    IF (OrderDateFrom IS NOT NULL AND OrderDateFrom <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND DATE(o.OrderDate) >= ''', OrderDateFrom, '''');
    END IF;
    IF (OrderDateTo IS NOT NULL AND OrderDateTo <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND DATE(o.OrderDate) <= ''', OrderDateTo, '''');
    END IF;
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    set @querySqlCount = CONCAT('select `progress`.ProgressDescription as Status, Count(*) as Total
							from `order` as o
								LEFT JOIN `signer` on o.SignerId = `signer`.SignerId  
                                LEFT JOIN `borrower` on o.BorrowerId = `borrower`.BorrowerId 
                                LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
                                LEFT JOIN `broker` on o.BrokerId = `broker`.BrokerID 
                                LEFT JOIN `branches` on `agent`.BranchID = `branches`.BranchID 
                                LEFT JOIN `progress` on o.ProgressId = `progress`.ProgressId
                                LEFT JOIN `employees` on o.RepId = `employees`.RepId
                                LEFT JOIN `customers` on o.CustomerId = `customers`.CustomerId
                                LEFT JOIN `zip` on o.Zip = `zip`.Zip ',
                                whereQuery, 
                                ' GROUP BY `progress`.ProgressId'
    );
    PREPARE stmtCount FROM @querySqlCount;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
    
    IF (groupStatus = 'Null') THEN SET whereQuery = CONCAT(whereQuery, ' and `progress`.ProgressDescription IS NULL');
    ELSE IF (groupStatus IS NOT NULL) THEN SET whereQuery = CONCAT(whereQuery, ' and `progress`.ProgressDescription IN (', groupStatus, ')');
		END IF;
    END IF;
    
    set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId,`broker`.Company as BranchName,`agent`.FullName Agent,CONCAT(`signer`.LastName, '' '', `signer`.FirstName) as Vendor,
                                `borrower`.LastName as Customer,o.OrderDate,o.AptDateTime,o.State,o.ProgressId as Stage,(o.ProgressId + 1) as NextAction,
                                `progress`.ProgressDescription as Status,
                                (CASE WHEN o.IsSelfService <> 0 THEN ''Self service'' ELSE ''Full Service'' END) as Service,
                                (CASE WHEN TIMEDIFF(DATE_ADD(o.AptDateTime, Interval `zip`.UTC Hour),UTC_TIMESTAMP()) < 0 THEN NULL ELSE TIMEDIFF(DATE_ADD(o.AptDateTime, Interval `zip`.UTC Hour),UTC_TIMESTAMP()) END) as Signing,
                                (CASE WHEN TIMEDIFF(UTC_TIMESTAMP(),o.LastUpdatedDate) < 0 THEN NULL ELSE ROUND(SUBSTRING_INDEX(TIMEDIFF(UTC_TIMESTAMP(),o.LastUpdatedDate), '':'', 1)/24,0) END) as LastActivity,
								`zip`.Utc as AptUtc,o.ProgressId,o.CommentDate, o.InActive as InactiveStatus, o.OrderId as TheOrderId,
                                o.signerId, o.repId, DATE_SUB(o.aptDateTime,Interval `zip`.Utc HOUR) as LocalAptDateTime
							from `order` as o
								LEFT JOIN `signer` on o.SignerId = `signer`.SignerId  
                                LEFT JOIN `borrower` on o.BorrowerId = `borrower`.BorrowerId 
                                LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
                                LEFT JOIN `broker` on o.BrokerId = `broker`.BrokerID 
                                LEFT JOIN `branches` on `agent`.BranchID = `branches`.BranchID 
                                LEFT JOIN `progress` on o.ProgressId = `progress`.ProgressId
                                LEFT JOIN `employees` on o.RepId = `employees`.RepId
                                LEFT JOIN `customers` on o.CustomerId = `customers`.CustomerId
                                LEFT JOIN `zip` on o.Zip = `zip`.Zip ',
                                whereQuery, orderQuery, limitQuery
    );
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

SELECT FOUND_ROWS() AS TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrdersInfoClientDashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrdersInfoClientDashboard`(
IN role varchar(255),
IN clientId int,
IN timeZone int
)
BEGIN
	DECLARE andWhereQuery varchar(21000);
    DECLARE andSelfService varchar(50);
    DECLARE andFullService varchar(50);
    DECLARE fromTables varchar(200);
    
	IF (role = 'Client') 
		THEN SET andWhereQuery = CONCAT(' and (o.BrokerId=',clientId,' or (o.BrokerId in (select Brokerid from `broker` where `broker`.GID = ',clientId, ')))');
	ELSE IF  (role = 'Branch') 
		THEN SET andWhereQuery = CONCAT(' and o.BrokerId=',clientId);
	ELSE IF (role = 'Agent') 
		THEN SET andWhereQuery = CONCAT(' and o.AgentId=',clientId);
		END IF;
    END IF;
    END IF;
    
    SET andSelfService = ' and o.IsSelfService=1';
    SET andFullService = ' and o.IsSelfService<>1';
    SET fromTables = ' FROM `order` as o
LEFT JOIN `progress` as p on o.ProgressId = p.ProgressId
LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
LEFT JOIN `broker` on o.BrokerId = `broker`.BrokerID';

-- SELFSERVICE
	-- OPEN ------------------------------------------------------------------------------------------------------------------------------------------------------------------
	set @queryOpenSelfService = CONCAT('SELECT Count(o.OrderId) as OpenSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery);
	-- broker_slas table
	set @queryOpenSLAApproachingSelfService = CONCAT('SELECT Count(o.OrderId) as OpenSLAApproachingSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
		and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 1 (Fill)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);
	-- broker_slas table
	set @queryOpenSLAOutOfSelfService = CONCAT('SELECT Count(o.OrderId) as OpenSLAOutOfSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
		and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 1 (Fill)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);


	-- ASSIGNED ------------------------------------------------------------------------------------------------------------------------------------------------------------------
	set @queryUnconfirmedSelfService = CONCAT('select Count(o.OrderId) as UnconfirmedSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=2 and o.OrderDate IS NOT NULL',
        andFullService, andWhereQuery);
	set @queryUnconfirmedSLAApproachingSelfService = CONCAT('select Count(o.OrderId) as UnconfirmedSLAApproachingSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=2 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(o.FilledDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 2 (Confirm)'' and a.BrokerId=', clientId,')',
        andFullService, andWhereQuery);
	set @queryUnconfirmedSLAOutOfSelfService = CONCAT('select Count(o.OrderId) as UnconfirmedSLAOutOfSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=2 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(o.FilledDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 2 (Confirm)'' and a.BrokerId=', clientId,')',
        andFullService, andWhereQuery);
	set @queryPendingDocsSelfService = CONCAT('select Count(o.OrderId) as PendingDocsSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=3 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery);
	set @queryPendingDocsSLAApproachingSelfService = CONCAT('select Count(o.OrderId) as PendingDocsSLAApproachingSelfService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=3 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval z.UTC Hour), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 3 (Pending Docs)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);
	set @queryPendingDocsSLAOutOfSelfService = CONCAT('select Count(o.OrderId) as PendingDocsSLAOutOfSelfService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=3 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval z.UTC Hour), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 3 (Pending Docs)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);
	set @queryNeedingPreCallSelfService = CONCAT('select Count(o.OrderId) as NeedingPreCallSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=4 and o.OrderDate IS NOT NULL',
        andSelfService, andWhereQuery);
	set @queryNeedingPreCallSLAApproachingSelfService = CONCAT('select Count(o.OrderId) as NeedingPreCallSLAApproachingSelfService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=4 and o.OrderDate IS NOT NULL
        and (TIMESTAMPDIFF(MINUTE, UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval (z.UTC - 24) Hour))) <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 4 (Pending Pre-Call)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);
	set @queryNeedingPreCallSLAOutOfSelfService = CONCAT('select Count(o.OrderId) as NeedingPreCallSLAOutOfSelfService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=4 and o.OrderDate IS NOT NULL
        and (TIMESTAMPDIFF(MINUTE, UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval (z.UTC - 24) Hour))) > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 4 (Pending Pre-Call)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);

	-- APPTREADY ------------------------------------------------------------------------------------------------------------------------------------------------------------------
	set @queryApptReadySelfService = CONCAT('select Count(o.OrderId) as ApptReadySelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery);
	set @queryApptReadySLAApproachingSelfService = CONCAT('select Count(o.OrderId) as ApptReadySLAApproachingSelfService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(DATE_ADD(o.AptDateTime, Interval z.UTC Hour), UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 5 (Appointment Ready)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);
	set @queryApptReadySLAOutOfSelfService = CONCAT('select Count(o.OrderId) as ApptReadySLAOutOfSelfService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(DATE_ADD(o.AptDateTime, Interval z.UTC Hour), UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 5 (Appointment Ready)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);

	-- CLOSEPENDING ------------------------------------------------------------------------------------------------------------------------------------------------------------------
	set @queryPendingReviewPCSelfService = CONCAT('select Count(o.OrderId) as PendingReviewPCSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=6 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery);
	set @queryPendingReviewPCSLAApproachingSelfService = CONCAT('select Count(o.OrderId) as PendingReviewPCSLAApproachingSelfService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(o.ClosingWorksheetDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 6 (Closed Pending Review/PC Resolution)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);
	set @queryPendingReviewPCSLAOutOfSelfService = CONCAT('select Count(o.OrderId) as PendingReviewPCSLAOutOfSelfService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(o.ClosingWorksheetDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 6 (Closed Pending Review/PC Resolution)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);
	set @queryAwaitingScanbacksSelfService = CONCAT('select Count(o.OrderId) as AwaitingScanbacksSelfService', fromTables, '
		inner join order_fee of on o.OrderId = of.OrderID
		inner JOIN broker_fee bf ON of.FeeDescripID = bf.FeeId
		left join(SELECT OrderId, Count(OrderId) as CountDoc FROM tce_dev2.order_docs where (Archive is null or Archive <> 1) and DocumentType=2 group by OrderId) as doc on o.OrderId=doc.OrderId
		WHERE o.InActive = 0 and p.ProgressId=7 and bf.FeeDescription=''Scan backs'' and o.OrderDate IS NOT NULL
		and doc.CountDoc is null', andSelfService, andWhereQuery);
	set @queryPendingQCReviewSelfService = CONCAT('select Count(o.OrderId) as PendingQCReviewSelfService', fromTables, '
		inner join order_fee of on o.OrderId = of.OrderID
		inner JOIN broker_fee bf ON of.FeeDescripID = bf.FeeId
		inner join order_fee of2 on o.OrderId = of2.OrderID
		inner JOIN broker_fee bf2 ON of2.FeeDescripID = bf2.FeeId
		WHERE o.InActive = 0 and p.ProgressId=7 and bf.FeeDescription=''QC Review of Docs'' and bf2.FeeDescription=''Scan backs'' and o.OrderDate IS NOT NULL',
        andSelfService, andWhereQuery);
	set @queryPendingQCReviewSLAApproachingSelfService = CONCAT('select Count(o.OrderId) as PendingQCReviewSLAApproachingSelfService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip
		inner join order_fee of on o.OrderId = of.OrderID
		inner JOIN broker_fee bf ON of.FeeDescripID = bf.FeeId
		inner join order_fee of2 on o.OrderId = of2.OrderID
		inner JOIN broker_fee bf2 ON of2.FeeDescripID = bf2.FeeId
		WHERE o.InActive = 0 and p.ProgressId=7 and bf.FeeDescription=''QC Review of Docs'' and bf2.FeeDescription=''Scan backs'' and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(DATE_ADD(o.AptDateTime, Interval z.UTC Hour), UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 7 (Closed Pending QC Review)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);
	set @queryPendingQCReviewSLAOutOfSelfService = CONCAT('select Count(o.OrderId) as PendingQCReviewSLAOutOfSelfService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip
		inner join order_fee of on o.OrderId = of.OrderID
		inner JOIN broker_fee bf ON of.FeeDescripID = bf.FeeId
		inner join order_fee of2 on o.OrderId = of2.OrderID
		inner JOIN broker_fee bf2 ON of2.FeeDescripID = bf2.FeeId
		WHERE o.InActive = 0 and p.ProgressId=7 and bf.FeeDescription=''QC Review of Docs'' and bf2.FeeDescription=''Scan backs'' and o.OrderDate IS NOT NULL
		and GetDurationBusinessTime(DATE_ADD(o.AptDateTime, Interval z.UTC Hour), UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 7 (Closed Pending QC Review)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);


	-- CLOSINGCOMPLETE ------------------------------------------------------------------------------------------------------------------------------------------------------------------
	set @queryClosedMTDSelfService = CONCAT('select Count(o.OrderId) as ClosedMTDSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=8 and o.OrderDate IS NOT NULL
		and o.ClosedDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')',
        andSelfService, andWhereQuery);
	set @queryPostCloseIssueSelfService = CONCAT('select Count(o.OrderId) as PostCloseIssueSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=9 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery);
	set @queryPostCloseIssueSLAApproachingSelfService = CONCAT('select Count(o.OrderId) as PostCloseIssueSLAApproachingSelfService', fromTables, '
		INNER JOIN (SELECT OrderId, Min(op.Date) as ProblemDate FROM order_problem op where op.Status in (1) group by OrderId) as op ON o.OrderId=op.OrderId
		WHERE o.InActive = 0 and p.ProgressId=9 and o.OrderDate IS NOT NULL
		and GetDurationBusinessTime(op.ProblemDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 8 (Post Close)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);
	set @queryPostCloseIssueSLAOutOfSelfService = CONCAT('select Count(o.OrderId) as PostCloseIssueSLAOutOfSelfService', fromTables, '
		INNER JOIN (SELECT OrderId, Min(op.Date) as ProblemDate FROM order_problem op where op.Status in (1) group by OrderId) as op ON o.OrderId=op.OrderId
		WHERE o.InActive = 0 and p.ProgressId=9 and o.OrderDate IS NOT NULL
		and GetDurationBusinessTime(op.ProblemDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 8 (Post Close)'' and a.BrokerId=', clientId,')',
        andSelfService, andWhereQuery);


	-- DID NOT CLOSE------------------------------------------------------------------------------------------------------------------------------------------------------------------
	set @queryCanceledByClientMTDSelfService = CONCAT('select Count(o.OrderId) as CanceledByClientMTDSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=11 and o.OrderDate IS NOT NULL
		and o.CanceledDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
		', andSelfService, andWhereQuery);
	set @queryUnsuccessfulMTDSelfService = CONCAT('select Count(o.OrderId) as UnsuccessfulMTDSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=12 and o.OrderDate IS NOT NULL
		and o.ClosingWorksheetDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
		', andSelfService, andWhereQuery);
	set @queryPlacedOnHoldMTDSelfService = CONCAT('select Count(o.OrderId) as PlacedOnHoldMTDSelfService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=10 and o.OrderDate IS NOT NULL
		and o.HoldingDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
		', andSelfService, andWhereQuery);




-- FULLSERVICE
	-- OPEN ------------------------------------------------------------------------------------------------------------------------------------------------------------------
	set @queryOpenFullService = CONCAT('SELECT Count(o.OrderId) as OpenFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL', andFullService, andWhereQuery);
	-- broker_slas table
	set @queryOpenSLAApproachingFullService = CONCAT('SELECT Count(o.OrderId) as OpenSLAApproachingFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
		and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 1 (Fill)'')',
        andFullService, andWhereQuery);
	-- broker_slas table
	set @queryOpenSLAOutOfFullService = CONCAT('SELECT Count(o.OrderId) as OpenSLAOutOfFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
		and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 1 (Fill)'')',
        andFullService, andWhereQuery);


	-- ASSIGNED ------------------------------------------------------------------------------------------------------------------------------------------------------------------
	set @queryUnconfirmedFullService = CONCAT('select Count(o.OrderId) as UnconfirmedFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=2 and o.OrderDate IS NOT NULL',
        andFullService, andWhereQuery);
	set @queryUnconfirmedSLAApproachingFullService = CONCAT('select Count(o.OrderId) as UnconfirmedSLAApproachingFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=2 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(o.FilledDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 2 (Confirm)'')',
        andFullService, andWhereQuery);
	set @queryUnconfirmedSLAOutOfFullService = CONCAT('select Count(o.OrderId) as UnconfirmedSLAOutOfFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=2 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(o.FilledDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 2 (Confirm)'')',
        andFullService, andWhereQuery);
	set @queryPendingDocsFullService = CONCAT('select Count(o.OrderId) as PendingDocsFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=3 and o.OrderDate IS NOT NULL', andFullService, andWhereQuery);
	set @queryPendingDocsSLAApproachingFullService = CONCAT('select Count(o.OrderId) as PendingDocsSLAApproachingFullService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=3 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval z.UTC Hour), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 3 (Pending Docs)'')',
        andFullService, andWhereQuery);
	set @queryPendingDocsSLAOutOfFullService = CONCAT('select Count(o.OrderId) as PendingDocsSLAOutOfFullService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=3 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval z.UTC Hour), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 3 (Pending Docs)'')',
        andFullService, andWhereQuery);
	set @queryNeedingPreCallFullService = CONCAT('select Count(o.OrderId) as NeedingPreCallFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=4 and o.OrderDate IS NOT NULL',
        andFullService, andWhereQuery);
	set @queryNeedingPreCallSLAApproachingFullService = CONCAT('select Count(o.OrderId) as NeedingPreCallSLAApproachingFullService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=4 and o.OrderDate IS NOT NULL
        and (TIMESTAMPDIFF(MINUTE, UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval (z.UTC - 24) Hour))) <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 4 (Pending Pre-Call)'')',
        andFullService, andWhereQuery);
	set @queryNeedingPreCallSLAOutOfFullService = CONCAT('select Count(o.OrderId) as NeedingPreCallSLAOutOfFullService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=4 and o.OrderDate IS NOT NULL
        and (TIMESTAMPDIFF(MINUTE, UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval (z.UTC - 24) Hour))) > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 4 (Pending Pre-Call)'')',
        andFullService, andWhereQuery);

	-- APPTREADY ------------------------------------------------------------------------------------------------------------------------------------------------------------------
	set @queryApptReadyFullService = CONCAT('select Count(o.OrderId) as ApptReadyFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL', andFullService, andWhereQuery);
	set @queryApptReadySLAApproachingFullService = CONCAT('select Count(o.OrderId) as ApptReadySLAApproachingFullService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(DATE_ADD(o.AptDateTime, Interval z.UTC Hour), UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 5 (Appointment Ready)'')',
        andFullService, andWhereQuery);
	set @queryApptReadySLAOutOfFullService = CONCAT('select Count(o.OrderId) as ApptReadySLAOutOfFullService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(DATE_ADD(o.AptDateTime, Interval z.UTC Hour), UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 5 (Appointment Ready)'')',
        andFullService, andWhereQuery);

	-- CLOSEPENDING ------------------------------------------------------------------------------------------------------------------------------------------------------------------
	set @queryPendingReviewPCFullService = CONCAT('select Count(o.OrderId) as PendingReviewPCFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=6 and o.OrderDate IS NOT NULL', andFullService, andWhereQuery);
	set @queryPendingReviewPCSLAApproachingFullService = CONCAT('select Count(o.OrderId) as PendingReviewPCSLAApproachingFullService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(o.ClosingWorksheetDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 6 (Closed Pending Review/PC Resolution)'')',
        andFullService, andWhereQuery);
	set @queryPendingReviewPCSLAOutOfFullService = CONCAT('select Count(o.OrderId) as PendingReviewPCSLAOutOfFullService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip 
		WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(o.ClosingWorksheetDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 6 (Closed Pending Review/PC Resolution)'')',
        andFullService, andWhereQuery);
	set @queryAwaitingScanbacksFullService = CONCAT('select Count(o.OrderId) as AwaitingScanbacksFullService', fromTables, '
		inner join order_fee of on o.OrderId = of.OrderID
		inner JOIN broker_fee bf ON of.FeeDescripID = bf.FeeId
		left join(SELECT OrderId, Count(OrderId) as CountDoc FROM tce_dev2.order_docs where (Archive is null or Archive <> 1) and DocumentType=2 group by OrderId) as doc on o.OrderId=doc.OrderId
		WHERE o.InActive = 0 and p.ProgressId=7 and bf.FeeDescription=''Scan backs'' and o.OrderDate IS NOT NULL
		and doc.CountDoc is null', andFullService, andWhereQuery);
	set @queryPendingQCReviewFullService = CONCAT('select Count(o.OrderId) as PendingQCReviewFullService', fromTables, '
		inner join order_fee of on o.OrderId = of.OrderID
		inner JOIN broker_fee bf ON of.FeeDescripID = bf.FeeId
		inner join order_fee of2 on o.OrderId = of2.OrderID
		inner JOIN broker_fee bf2 ON of2.FeeDescripID = bf2.FeeId
		WHERE o.InActive = 0 and p.ProgressId=7 and bf.FeeDescription=''QC Review of Docs'' and bf2.FeeDescription=''Scan backs'' and o.OrderDate IS NOT NULL',
        andFullService, andWhereQuery);
	set @queryPendingQCReviewSLAApproachingFullService = CONCAT('select Count(o.OrderId) as PendingQCReviewSLAApproachingFullService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip
		inner join order_fee of on o.OrderId = of.OrderID
		inner JOIN broker_fee bf ON of.FeeDescripID = bf.FeeId
		inner join order_fee of2 on o.OrderId = of2.OrderID
		inner JOIN broker_fee bf2 ON of2.FeeDescripID = bf2.FeeId
		WHERE o.InActive = 0 and p.ProgressId=7 and bf.FeeDescription=''QC Review of Docs'' and bf2.FeeDescription=''Scan backs'' and o.OrderDate IS NOT NULL
        and GetDurationBusinessTime(DATE_ADD(o.AptDateTime, Interval z.UTC Hour), UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 7 (Closed Pending QC Review)'')',
        andFullService, andWhereQuery);
	set @queryPendingQCReviewSLAOutOfFullService = CONCAT('select Count(o.OrderId) as PendingQCReviewSLAOutOfFullService', fromTables, '
		LEFT JOIN `zip` as z on o.Zip = z.Zip
		inner join order_fee of on o.OrderId = of.OrderID
		inner JOIN broker_fee bf ON of.FeeDescripID = bf.FeeId
		inner join order_fee of2 on o.OrderId = of2.OrderID
		inner JOIN broker_fee bf2 ON of2.FeeDescripID = bf2.FeeId
		WHERE o.InActive = 0 and p.ProgressId=7 and bf.FeeDescription=''QC Review of Docs'' and bf2.FeeDescription=''Scan backs'' and o.OrderDate IS NOT NULL
		and GetDurationBusinessTime(DATE_ADD(o.AptDateTime, Interval z.UTC Hour), UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 7 (Closed Pending QC Review)'')',
        andFullService, andWhereQuery);


	-- CLOSINGCOMPLETE ------------------------------------------------------------------------------------------------------------------------------------------------------------------
	set @queryClosedMTDFullService = CONCAT('select Count(o.OrderId) as ClosedMTDFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=8 and o.OrderDate IS NOT NULL
		and o.ClosedDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')',
        andFullService, andWhereQuery);
	set @queryPostCloseIssueFullService = CONCAT('select Count(o.OrderId) as PostCloseIssueFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=9 and o.OrderDate IS NOT NULL', andFullService, andWhereQuery);
	set @queryPostCloseIssueSLAApproachingFullService = CONCAT('select Count(o.OrderId) as PostCloseIssueSLAApproachingFullService', fromTables, '
		INNER JOIN (SELECT OrderId, Min(op.Date) as ProblemDate FROM order_problem op where op.Status in (1) group by OrderId) as op ON o.OrderId=op.OrderId
		WHERE o.InActive = 0 and p.ProgressId=9 and o.OrderDate IS NOT NULL
		and GetDurationBusinessTime(op.ProblemDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 8 (Post Close)'')',
        andFullService, andWhereQuery);
	set @queryPostCloseIssueSLAOutOfFullService = CONCAT('select Count(o.OrderId) as PostCloseIssueSLAOutOfFullService', fromTables, '
		INNER JOIN (SELECT OrderId, Min(op.Date) as ProblemDate FROM order_problem op where op.Status in (1) group by OrderId) as op ON o.OrderId=op.OrderId
		WHERE o.InActive = 0 and p.ProgressId=9 and o.OrderDate IS NOT NULL
		and GetDurationBusinessTime(op.ProblemDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 8 (Post Close)'')',
        andFullService, andWhereQuery);


	-- DID NOT CLOSE------------------------------------------------------------------------------------------------------------------------------------------------------------------
	set @queryCanceledByClientMTDFullService = CONCAT('select Count(o.OrderId) as CanceledByClientMTDFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=11 and o.OrderDate IS NOT NULL
		and o.CanceledDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
		', andFullService, andWhereQuery);
	set @queryUnsuccessfulMTDFullService = CONCAT('select Count(o.OrderId) as UnsuccessfulMTDFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=12 and o.OrderDate IS NOT NULL
		and o.ClosingWorksheetDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
		', andFullService, andWhereQuery);
	set @queryPlacedOnHoldMTDFullService = CONCAT('select Count(o.OrderId) as PlacedOnHoldMTDFullService', fromTables, '
		WHERE o.InActive = 0 and p.ProgressId=10 and o.OrderDate IS NOT NULL
		and o.HoldingDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
		', andFullService, andWhereQuery);

-- SELF SERVICE ------------------------------------------------
	PREPARE stmtCount FROM @queryOpenSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryOpenSLAApproachingSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryOpenSLAOutOfSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryUnconfirmedSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryUnconfirmedSLAApproachingSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryUnconfirmedSLAOutOfSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingDocsSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingDocsSLAApproachingSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingDocsSLAOutOfSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryNeedingPreCallSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryNeedingPreCallSLAApproachingSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryNeedingPreCallSLAOutOfSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryApptReadySelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryApptReadySLAApproachingSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryApptReadySLAOutOfSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingReviewPCSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingReviewPCSLAApproachingSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingReviewPCSLAOutOfSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryAwaitingScanbacksSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingQCReviewSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingQCReviewSLAApproachingSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingQCReviewSLAOutOfSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryClosedMTDSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPostCloseIssueSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPostCloseIssueSLAApproachingSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPostCloseIssueSLAOutOfSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryCanceledByClientMTDSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryUnsuccessfulMTDSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPlacedOnHoldMTDSelfService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;

-- FULL SERVICE ------------------------------------------------
	PREPARE stmtCount FROM @queryOpenFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryOpenSLAApproachingFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryOpenSLAOutOfFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryUnconfirmedFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryUnconfirmedSLAApproachingFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryUnconfirmedSLAOutOfFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingDocsFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingDocsSLAApproachingFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingDocsSLAOutOfFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryNeedingPreCallFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryNeedingPreCallSLAApproachingFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryNeedingPreCallSLAOutOfFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryApptReadyFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryApptReadySLAApproachingFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryApptReadySLAOutOfFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingReviewPCFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingReviewPCSLAApproachingFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingReviewPCSLAOutOfFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryAwaitingScanbacksFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingQCReviewFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingQCReviewSLAApproachingFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPendingQCReviewSLAOutOfFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryClosedMTDFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPostCloseIssueFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPostCloseIssueSLAApproachingFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPostCloseIssueSLAOutOfFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryCanceledByClientMTDFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryUnsuccessfulMTDFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
	PREPARE stmtCount FROM @queryPlacedOnHoldMTDFullService;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrdersInfoDetailClientDashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrdersInfoDetailClientDashboard`(
IN role varchar(255),
IN clientId int,
IN service varchar(20),
IN statusGroup varchar(50),
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN timeZone int
)
BEGIN
	DECLARE andWhereQuery varchar(21000);
    DECLARE andSelfService varchar(50);
    DECLARE andFullService varchar(50);
    DECLARE fromTables varchar(200);
    DECLARE orderQuery varchar(255);  
    DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    
    IF (sortDirection = true) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
     IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = CONCAT(' ORDER BY `OrderId`', sortDirectionQuery);
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
    
    IF (pageNumber IS NULL OR pageNumber = '') THEN SET pageNumber = 1; END IF;
    IF (pageSize IS NULL OR pageSize = '') THEN SET pageSize = 25; END IF;
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
	IF (role = 'Client') 
		THEN SET andWhereQuery = CONCAT(' and (o.BrokerId=',clientId,' or (o.BrokerId in (select Brokerid from `broker` where `broker`.GID = ',clientId, ')))');
	ELSE IF  (role = 'Branch') 
		THEN SET andWhereQuery = CONCAT(' and o.BrokerId=',clientId);
	ELSE IF (role = 'Agent') 
		THEN SET andWhereQuery = CONCAT(' and o.AgentId=',clientId);
		END IF;
    END IF;
    END IF;

    SET andSelfService = ' and o.IsSelfService=1';
    SET andFullService = ' and o.IsSelfService<>1';
    SET fromTables = ' FROM `order` as o
LEFT JOIN `progress` as p on o.ProgressId = p.ProgressId
LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
LEFT JOIN `broker` on o.BrokerId = `broker`.BrokerID';

	IF (service = 'Self') THEN
        -- ------------------------------------------------------------------------------------------------------------------------------------------------------------------
		IF (statusGroup = 'OpenAll') THEN
			set @queryOpen = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);

			set @queryOpenSLAApproaching = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') as SLAApproaching', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
				and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 1 (Fill)'' and a.BrokerId=', clientId,')', andSelfService, andWhereQuery, orderQuery, limitQuery);

			set @queryOpenSLAOutOf = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') as SLAOutOf', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
				and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 1 (Fill)'' and a.BrokerId=', clientId,')', andSelfService, andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryOpen;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
			
			PREPARE stmt FROM @queryOpenSLAApproaching;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;

			PREPARE stmt FROM @queryOpenSLAOutOf;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Open') THEN
			set @queryOpen = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryOpen;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'OpenSLAApproaching') THEN
			set @queryOpenSLAApproaching = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') as SLAApproaching', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
				and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 1 (Fill)'' and a.BrokerId=', clientId,')', andSelfService, andWhereQuery, orderQuery, limitQuery);
			
			PREPARE stmt FROM @queryOpenSLAApproaching;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'OpenSLAOutOf') THEN
			set @queryOpenSLAOutOf = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') as SLAOutOf', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
				and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM broker_slas as a WHERE a.SLA=''SLA 1 (Fill)'' and a.BrokerId=', clientId,')', andSelfService, andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryOpenSLAOutOf;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        -- OK ------------------------------------------------------------------------------------------------------------------------------------------------------------------

		IF (statusGroup = 'Assigned') THEN
			set @queryUnconfirmed = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.FilledDate, UTC_TIMESTAMP(), ',timeZone,') as DurationMinute', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=2 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);
			set @queryPendingDocs = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval z.UTC Hour), ',timeZone,') as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=3 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);
			set @queryNeedingPreCall = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, (TIMESTAMPDIFF(MINUTE, UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval (z.UTC - 24) Hour))) as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=4 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);
			-- broker_sla
            -- set @queryBrokerSLA = CONCAT('SELECT * FROM broker_slas as a WHERE a.BrokerId=', clientId,'');
			PREPARE stmt FROM @queryUnconfirmed;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;

			PREPARE stmt FROM @queryPendingDocs;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;

			PREPARE stmt FROM @queryNeedingPreCall;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Unconfirmed') THEN
			set @queryUnconfirmed = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.FilledDate, UTC_TIMESTAMP(), ',timeZone,') as DurationMinute', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=2 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryUnconfirmed;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        IF (statusGroup = 'Pending Docs') THEN
			set @queryPendingDocs = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval z.UTC Hour), ',timeZone,') as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=3 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);
			PREPARE stmt FROM @queryPendingDocs;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        IF (statusGroup = 'Needing Pre-call') THEN
			set @queryNeedingPreCall = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, (TIMESTAMPDIFF(MINUTE, UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval (z.UTC - 24) Hour))) as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=4 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);
			PREPARE stmt FROM @queryNeedingPreCall;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
         -- OK------------------------------------------------------------------------------------------------------------------------------------------------------------------
       
        IF (statusGroup = 'Appt Ready') THEN
			set @queryApptReady = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);
			PREPARE stmt FROM @queryApptReady;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        -- OK------------------------------------------------------------------------------------------------------------------------------------------------------------------
        
        -- PendingReviewPCDate
        IF (statusGroup = 'Closed Pending') THEN
			set @queryPendingReviewPC = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.PendingReviewPCDate, UTC_TIMESTAMP(), ',timeZone,') as DurationMinute', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=6 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);
			set @queryAwaitingScanbacks = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(DATE_ADD(o.AptDateTime, Interval z.UTC Hour), UTC_TIMESTAMP(), ',timeZone,') as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
                inner join order_fee of on o.OrderId = of.OrderID
				inner JOIN broker_fee bf ON of.FeeDescripID = bf.FeeId
                left join(SELECT OrderId, count(*) as CountDoc FROM tce_dev2.order_docs where (Archive is null or Archive <> 1) group by OrderId) as doc on o.OrderId=doc.OrderId
				WHERE o.InActive = 0 and p.ProgressId in (6,7) and bf.FeeDescription=''Scan backs'' and o.OrderDate IS NOT NULL
                and doc.CountDoc is null', andSelfService, andWhereQuery, orderQuery, limitQuery);
			set @queryPendingQCReview = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(DATE_ADD(o.AptDateTime, Interval z.UTC Hour), UTC_TIMESTAMP(), ',timeZone,') as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
                inner join order_fee of on o.OrderId = of.OrderID
				inner JOIN broker_fee bf ON of.FeeDescripID = bf.FeeId
				inner join order_fee of2 on o.OrderId = of2.OrderID
				inner JOIN broker_fee bf2 ON of2.FeeDescripID = bf2.FeeId
				WHERE o.InActive = 0 and p.ProgressId=7 and bf.FeeDescription=''QC Review of Docs'' and bf2.FeeDescription=''Scan backs'' and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryPendingReviewPC;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;

			PREPARE stmt FROM @queryAwaitingScanbacks;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;

			PREPARE stmt FROM @queryPendingQCReview;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        IF (statusGroup = 'PendingReviewPC') THEN
			set @queryPendingReviewPC = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.PendingReviewPCDate, UTC_TIMESTAMP(), ',timeZone,') as DurationMinute', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=6 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryPendingReviewPC;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        IF (statusGroup = 'AwaitingScanbacks') THEN
			set @queryAwaitingScanbacks = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(DATE_ADD(o.AptDateTime, Interval z.UTC Hour), UTC_TIMESTAMP(), ',timeZone,') as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
                inner join order_fee of on o.OrderId = of.OrderID
				inner JOIN broker_fee bf ON of.FeeDescripID = bf.FeeId
                left join(SELECT OrderId, count(*) as CountDoc FROM tce_dev2.order_docs where (Archive is null or Archive <> 1) and DocumentType=2 group by OrderId) as doc on o.OrderId=doc.OrderId
				WHERE o.InActive = 0 and p.ProgressId=7 and bf.FeeDescription=''Scan backs'' and o.OrderDate IS NOT NULL
                and doc.CountDoc is null', andSelfService, andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryAwaitingScanbacks;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        IF (statusGroup = 'PendingQCReview') THEN
			set @queryPendingQCReview = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(DATE_ADD(o.AptDateTime, Interval z.UTC Hour), UTC_TIMESTAMP(), ',timeZone,') as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
                inner join order_fee of on o.OrderId = of.OrderID
				inner JOIN broker_fee bf ON of.FeeDescripID = bf.FeeId
				inner join order_fee of2 on o.OrderId = of2.OrderID
				inner JOIN broker_fee bf2 ON of2.FeeDescripID = bf2.FeeId
				WHERE o.InActive = 0 and p.ProgressId=7 and bf.FeeDescription=''QC Review of Docs'' and bf2.FeeDescription=''Scan backs'' and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryPendingQCReview;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        -- ------------------------------------------------------------------------------------------------------------------------------------------------------------------
        

        IF (statusGroup = 'Closing Complete') THEN
			set @queryClosedMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=8 and o.OrderDate IS NOT NULL
                and o.ClosedDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andSelfService, andWhereQuery, orderQuery, limitQuery);
			set @queryPostCloseIssue = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=9 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryClosedMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
			PREPARE stmt FROM @queryPostCloseIssue;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        IF (statusGroup = 'Closed MTD') THEN
			set @queryClosedMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=8 and o.OrderDate IS NOT NULL
                and o.ClosedDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andSelfService, andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryClosedMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        IF (statusGroup = 'Post Close Issue') THEN
			set @queryPostCloseIssue = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=9 and o.OrderDate IS NOT NULL', andSelfService, andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryPostCloseIssue;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        -- OK------------------------------------------------------------------------------------------------------------------------------------------------------------------
        
		IF (statusGroup = 'Did Not Close') THEN
			set @queryCanceledByClientMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=11 and o.OrderDate IS NOT NULL
                and o.CanceledDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andSelfService, andWhereQuery, orderQuery, limitQuery);
			set @queryUnsuccessfulMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=12 and o.OrderDate IS NOT NULL
                and o.ClosingWorksheetDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andSelfService, andWhereQuery, orderQuery, limitQuery);
			set @queryPlacedOnHoldMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=10 and o.OrderDate IS NOT NULL
                and o.HoldingDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andSelfService, andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryCanceledByClientMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
			PREPARE stmt FROM @queryUnsuccessfulMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
			PREPARE stmt FROM @queryPlacedOnHoldMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Canceled By Client') THEN
			set @queryCanceledByClientMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=11 and o.OrderDate IS NOT NULL
                and o.CanceledDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andSelfService, andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryCanceledByClientMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Unsuccessful') THEN
			set @queryUnsuccessfulMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=12 and o.OrderDate IS NOT NULL
                and o.ClosingWorksheetDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andSelfService, andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryUnsuccessfulMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Placed On Hold') THEN
			set @queryPlacedOnHoldMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=10 and o.OrderDate IS NOT NULL
                and o.HoldingDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andSelfService, andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryPlacedOnHoldMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        -- OK ------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
	END IF;
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    -- FULL SERVICE ------------------------------------------------------------------------------------------------------------------------------------------------------------
	IF (service = 'Full') THEN
        -- ------------------------------------------------------------------------------------------------------------------------------------------------------------------
		IF (statusGroup = 'OpenAll') THEN
			set @queryOpen = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL', andFullService, andWhereQuery, orderQuery, limitQuery);

			set @queryOpenSLAApproaching = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') as SLAApproaching', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
				and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 1 (Fill)'')', andFullService, andWhereQuery, orderQuery, limitQuery);

			set @queryOpenSLAOutOf = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') as SLAOutOf', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
				and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 1 (Fill)'')', andFullService, andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryOpen;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
			
			PREPARE stmt FROM @queryOpenSLAApproaching;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;

			PREPARE stmt FROM @queryOpenSLAOutOf;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
		END IF;
		IF (statusGroup = 'Open') THEN
			set @queryOpen = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL', andFullService, andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryOpen;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
		END IF;
		IF (statusGroup = 'OpenSLAApproaching') THEN
			set @queryOpenSLAApproaching = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') as SLAApproaching', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
				and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 1 (Fill)'')', andFullService, andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryOpenSLAApproaching;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
		END IF;
		IF (statusGroup = 'OpenSLAOutOf') THEN
			set @queryOpenSLAOutOf = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') as SLAOutOf', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
				and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 1 (Fill)'')', andFullService, andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryOpenSLAOutOf;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
		END IF;
        -- OK ------------------------------------------------------------------------------------------------------------------------------------------------------------------

		IF (statusGroup = 'Assigned') THEN
			set @queryUnconfirmed = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.FilledDate, UTC_TIMESTAMP(), ',timeZone,') as DurationMinute', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=2 and o.OrderDate IS NOT NULL', andFullService, andWhereQuery, orderQuery, limitQuery);
			set @queryPendingDocs = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval z.UTC Hour), ',timeZone,') as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=3 and o.OrderDate IS NOT NULL', andFullService, andWhereQuery, orderQuery, limitQuery);
			set @queryNeedingPreCall = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, (TIMESTAMPDIFF(MINUTE, UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval (z.UTC - 24) Hour))) as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=4 and o.OrderDate IS NOT NULL', andFullService, andWhereQuery, orderQuery, limitQuery);
			-- sla
            -- set @queryBrokerSLA = CONCAT('SELECT * FROM slas as a');
			PREPARE stmt FROM @queryUnconfirmed;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;

			PREPARE stmt FROM @queryPendingDocs;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;

			PREPARE stmt FROM @queryNeedingPreCall;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Unconfirmed') THEN
			set @queryUnconfirmed = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.FilledDate, UTC_TIMESTAMP(), ',timeZone,') as DurationMinute', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=2 and o.OrderDate IS NOT NULL', andFullService, andWhereQuery, orderQuery, limitQuery);
			PREPARE stmt FROM @queryUnconfirmed;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        IF (statusGroup = 'Pending Docs') THEN
			set @queryPendingDocs = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval z.UTC Hour), ',timeZone,') as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=3 and o.OrderDate IS NOT NULL', andFullService, andWhereQuery, orderQuery, limitQuery);
			PREPARE stmt FROM @queryPendingDocs;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        IF (statusGroup = 'Needing Pre-call') THEN
			set @queryNeedingPreCall = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, (TIMESTAMPDIFF(MINUTE, UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval (z.UTC - 24) Hour))) as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=4 and o.OrderDate IS NOT NULL', andFullService, andWhereQuery, orderQuery, limitQuery);
			PREPARE stmt FROM @queryNeedingPreCall;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        
		IF (statusGroup = 'Appt Ready') THEN
			set @queryApptReady = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval z.UTC Hour), ',timeZone,') as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL', andFullService, andWhereQuery, orderQuery, limitQuery);
			PREPARE stmt FROM @queryApptReady;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;



		IF (statusGroup = 'Did Not Close') THEN
			set @queryCanceledByClientMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=11 and o.OrderDate IS NOT NULL
                and o.CanceledDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andFullService, andWhereQuery, orderQuery, limitQuery);
			set @queryUnsuccessfulMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=12 and o.OrderDate IS NOT NULL
                and o.ClosingWorksheetDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andFullService, andWhereQuery, orderQuery, limitQuery);
			set @queryPlacedOnHoldMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=10 and o.OrderDate IS NOT NULL
                and o.HoldingDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andFullService, andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryCanceledByClientMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
			PREPARE stmt FROM @queryUnsuccessfulMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
			PREPARE stmt FROM @queryPlacedOnHoldMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Canceled By Client') THEN
			set @queryCanceledByClientMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=11 and o.OrderDate IS NOT NULL
                and o.CanceledDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andFullService, andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryCanceledByClientMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Unsuccessful') THEN
			set @queryUnsuccessfulMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=12 and o.OrderDate IS NOT NULL
                and o.ClosingWorksheetDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andFullService, andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryUnsuccessfulMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Placed On Hold') THEN
			set @queryPlacedOnHoldMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=10 and o.OrderDate IS NOT NULL
                and o.HoldingDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andFullService, andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryPlacedOnHoldMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
    END IF;














    -- ALL SERVICE ------------------------------------------------------------------------------------------------------------------------------------------------------------
	IF (service = 'All') THEN
		IF (statusGroup = 'OpenAll') THEN
			set @queryOpen = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL', andWhereQuery, orderQuery, limitQuery);

			set @queryOpenSLAApproaching = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') as SLAApproaching', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
				and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 1 (Fill)'')', andWhereQuery, orderQuery, limitQuery);

			set @queryOpenSLAOutOf = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') as SLAOutOf', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
				and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 1 (Fill)'')', andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryOpen;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
			
			PREPARE stmt FROM @queryOpenSLAApproaching;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;

			PREPARE stmt FROM @queryOpenSLAOutOf;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
		END IF;
		IF (statusGroup = 'Open') THEN
			set @queryOpen = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL', andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryOpen;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
		END IF;
		IF (statusGroup = 'OpenSLAApproaching') THEN
			set @queryOpenSLAApproaching = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') as SLAApproaching', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
				and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') <= (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 1 (Fill)'')', andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryOpenSLAApproaching;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
		END IF;
		IF (statusGroup = 'OpenSLAOutOf') THEN
			set @queryOpenSLAOutOf = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') as SLAOutOf', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=1 and o.RepId is null and o.SignerId is null and o.OrderDate IS NOT NULL
				and GetDurationBusinessTime(o.OrderDate, UTC_TIMESTAMP(), ',timeZone,') > (SELECT CASE WHEN a.To IS NOT NULL THEN a.`To` ELSE a.DefaultTo END AS `To` FROM slas as a WHERE a.SLA=''SLA 1 (Fill)'')', andWhereQuery, orderQuery, limitQuery);

			PREPARE stmt FROM @queryOpenSLAOutOf;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
		END IF;

		IF (statusGroup = 'Assigned') THEN
			set @queryUnconfirmed = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.FilledDate, UTC_TIMESTAMP(), ',timeZone,') as DurationMinute', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=2 and o.OrderDate IS NOT NULL', andWhereQuery, orderQuery, limitQuery);
			set @queryPendingDocs = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval z.UTC Hour), ',timeZone,') as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=3 and o.OrderDate IS NOT NULL', andWhereQuery, orderQuery, limitQuery);
			set @queryNeedingPreCall = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, (TIMESTAMPDIFF(MINUTE, UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval (z.UTC - 24) Hour))) as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=4 and o.OrderDate IS NOT NULL', andWhereQuery, orderQuery, limitQuery);
			-- sla
            -- set @queryBrokerSLA = CONCAT('SELECT * FROM slas as a');
			PREPARE stmt FROM @queryUnconfirmed;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;

			PREPARE stmt FROM @queryPendingDocs;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;

			PREPARE stmt FROM @queryNeedingPreCall;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Unconfirmed') THEN
			set @queryUnconfirmed = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(o.FilledDate, UTC_TIMESTAMP(), ',timeZone,') as DurationMinute', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=2 and o.OrderDate IS NOT NULL', andWhereQuery, orderQuery, limitQuery);
			-- broker_sla
            -- set @queryBrokerSLA = CONCAT('SELECT * FROM broker_slas as a WHERE a.BrokerId=', clientId,'');
			PREPARE stmt FROM @queryUnconfirmed;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
			-- sla
			-- set @querySLA = CONCAT('SELECT * FROM slas as a');
        IF (statusGroup = 'Pending Docs') THEN
			set @queryPendingDocs = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval z.UTC Hour), ',timeZone,') as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=3 and o.OrderDate IS NOT NULL', andWhereQuery, orderQuery, limitQuery);
			PREPARE stmt FROM @queryPendingDocs;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        IF (statusGroup = 'Needing Pre-call') THEN
			set @queryNeedingPreCall = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, (TIMESTAMPDIFF(MINUTE, UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval (z.UTC - 24) Hour))) as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=4 and o.OrderDate IS NOT NULL', andWhereQuery, orderQuery, limitQuery);
			PREPARE stmt FROM @queryNeedingPreCall;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
        
		IF (statusGroup = 'Appt Ready') THEN
			set @queryApptReady = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId, GetDurationBusinessTime(UTC_TIMESTAMP(), DATE_ADD(o.AptDateTime, Interval z.UTC Hour), ',timeZone,') as DurationMinute', fromTables, '
				LEFT JOIN `zip` as z on o.Zip = z.Zip 
				WHERE o.InActive = 0 and p.ProgressId=5 and o.OrderDate IS NOT NULL', andWhereQuery, orderQuery, limitQuery);
			PREPARE stmt FROM @queryApptReady;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;




		IF (statusGroup = 'Did Not Close') THEN
			set @queryCanceledByClientMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=11 and o.OrderDate IS NOT NULL
                and o.CanceledDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andWhereQuery, orderQuery, limitQuery);
			set @queryUnsuccessfulMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=12 and o.OrderDate IS NOT NULL
                and o.ClosingWorksheetDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andWhereQuery, orderQuery, limitQuery);
			set @queryPlacedOnHoldMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=10 and o.OrderDate IS NOT NULL
                and o.HoldingDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryCanceledByClientMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
			PREPARE stmt FROM @queryUnsuccessfulMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
			PREPARE stmt FROM @queryPlacedOnHoldMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Canceled By Client') THEN
			set @queryCanceledByClientMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=11 and o.OrderDate IS NOT NULL
                and o.CanceledDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryCanceledByClientMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Unsuccessful') THEN
			set @queryUnsuccessfulMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=12 and o.OrderDate IS NOT NULL
                and o.ClosingWorksheetDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryUnsuccessfulMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;
		IF (statusGroup = 'Placed On Hold') THEN
			set @queryPlacedOnHoldMTD = CONCAT('select SQL_CALC_FOUND_ROWS o.OrderId as OrderId', fromTables, '
				WHERE o.InActive = 0 and p.ProgressId=10 and o.OrderDate IS NOT NULL
                and o.HoldingDate between GetMTDFromDate(',clientId,') AND GetMTDToDate(',clientId,')
                ', andWhereQuery, orderQuery, limitQuery);
                
			PREPARE stmt FROM @queryPlacedOnHoldMTD;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
			SELECT FOUND_ROWS() AS TotalRecords;
        END IF;

    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrderSpecificData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderSpecificData`(
IN order_Id INT(11)
)
BEGIN    
	-- order data
	SELECT
		AlwaysCC,
        EmailCC,
        CCInvEmail,
        Collect1,
        Collect2,
        Collect3,
        Collect4,
        Collect5,
        Collect6,
        Collect7,
        Collect8,
        Collect9,
        Collect10,
        ReturnAddress,
        BrokerId,
        OrderId
    FROM `order` AS o
    WHERE o.OrderID = order_Id;
    
    -- lender Specific from broker
    SELECT
        b.LenderSpecific
    FROM `order` AS o
    INNER JOIN `broker` AS b ON b.BrokerID = o.BrokerId
    WHERE OrderID = order_Id;
    
    -- order special instructions list
    SELECT
		`Instructions1`,
		`Instructions2`,
		`Instructions3`,
		`Instructions4`,
		`Instructions5`,
		`Instructions6`,
		`Instructions7`,
		`Instructions8`,
		`Instructions9`,
		`Instructions10`
	FROM `order_special_instructions`
    WHERE OrderID = order_Id;
    
    -- cc email list
    SELECT
		b.Email
	FROM `broker_emails` AS b
    INNER JOIN `order` AS o ON b.BrokerID = o.BrokerId
    WHERE o.OrderId = order_Id
		AND (EmailFor='S' OR EmailFor='B')
	ORDER BY b.Email;
    
    -- cc invoice email list
    SELECT
		b.Email
	FROM `broker_emails` AS b
    INNER JOIN `order` AS o ON b.BrokerID = o.BrokerId
    WHERE o.OrderId = order_Id
		AND (EmailFor='I' OR EmailFor='B')
	ORDER BY b.Email;
    
    -- return address list
    select  
		CONCAT(case when r.Department is null then '' else concat(r.Department, ', ') end,
			case when r.Address is null then '' else concat(r.Address, ', ') end,
            case when r.Suite is null then '' else concat(r.Suite, ', ') end,
            case when r.City is null then '' else concat(r.City, ', ') end,
            case when r.State is null then '' else concat(r.State, ' ') end,
            case when r.Zip is null then '' else concat(r.Zip) end) 
		AS ReturnAddr,
		r.Department,
		r.Address,
		r.Suite,
		r.City,
		r.Zip,
        r.State
    from `return_addr` as r
    inner join `broker` as b on b.BrokerID = r.BrokerID
    inner join `order` as o on b.BrokerID = o.BrokerId
    WHERE o.OrderId = order_Id
    ORDER BY ReturnAddr;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrdersProblem` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrdersProblem`(
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
	IN orderId int,
	IN typeId int,
    IN statusId int,
    IN vendorLastName varchar(255),
    IN dateFrom varchar(255),
    IN dateTo varchar(255),
    IN brokerId int,
    IN agentId int
)
BEGIN    
	DECLARE orderSql varchar(255);
	DECLARE sortDirectionSql varchar(255);
    DECLARE limitSql varchar(255);
    DECLARE whereQuery varchar(255);
    
    -- CIRTERIA GO HERE
		-- limit result
		SET limitSql = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ', ', pageSize);
			
		-- sort
		IF (sortDirection = 1) 
			THEN SET sortDirectionSql = ' ASC';
		ELSE SET sortDirectionSql = ' DESC';
		END IF;
		
		IF (sortBy IS NULL OR sortBy = '')
			THEN SET orderSql = ' ORDER BY Date ';
		ELSE SET orderSql = CONCAT(' ORDER BY ', sortBy, sortDirectionSql);
		END IF;
        
	-- NEED VALUE TO FILTER
		SET whereQuery = 'WHERE 1=1';
		-- OrderID
        IF(orderId IS NOT NULL AND orderId <> '')
			THEN SET whereQuery = CONCAT(whereQuery,' AND op.OrderId = ', orderId);
		END IF;
        
        -- Type
        IF(typeId IS NOT NULL AND typeId <> '')
			THEN SET whereQuery = CONCAT(whereQuery,' AND op.Type = ', typeId); 
		END IF;
        
        -- Status
        IF(statusId IS NOT NULL AND statusId <> '')
			THEN SET whereQuery = CONCAT(whereQuery,' AND op.Status = ', statusId); 
		END IF;
        
        -- Vendor Last Name        
        IF(vendorLastName IS NOT NULL AND vendorLastName <> '')
			THEN SET whereQuery = CONCAT(whereQuery, ' AND s.LastName like ''%', vendorLastName,'%''');
		END IF;
        
        -- Date Submitted
        IF(dateFrom IS NOT NULL AND dateFrom <> '')
			THEN SET whereQuery = CONCAT(whereQuery, ' AND op.Date >= ''', dateFrom, '''');
		END IF;
        
        IF(dateTo IS NOT NULL AND dateTo <> '')
			THEN SET whereQuery = CONCAT(whereQuery, ' AND op.Date < ''', dateTo,'''');
		END IF;
        
        IF(brokerId IS NOT NULL AND brokerId <> '')
			THEN SET whereQuery = CONCAT(whereQuery, ' AND (br.BrokerID= ',brokerId,' or br.GID=',brokerId,')');
		END IF;
        
        IF(agentId IS NOT NULL AND agentId <> '')
			THEN SET whereQuery = CONCAT(whereQuery, ' AND ag.AgentId= ',agentId);
		END IF;
        
	SET @query= CONCAT('
		SELECT 
			op.OrderId AS orderId, op.ProblemId AS problemId, op.Date AS `date`, op.Resolution AS resolution,op.TrackingNumber AS trackingNumber,
            CASE op.Mistake
				WHEN 1 THEN  ''Y''										
				ELSE ''N''
				END as vendorMistake
                , op.Type AS typeId, op.Status AS statusId,
			(SELECT ps.Description FROM problem_status ps WHERE ps.id = op.Status) AS `status`,
			(SELECT pt.Description FROM problem_types pt WHERE pt.id = op.Type) AS problemType, 
			s.LastName AS vendorLastName,s.SignerId,
			(SELECT u.UserName as fullName FROM users u WHERE u.UsersId = op.EnteredBy) AS createBy
		FROM order_problem op 
        LEFT JOIN `order` o ON op.OrderId = o.OrderId 
		LEFT JOIN signer s ON s.SignerId = op.SignerId
        LEFT JOIN broker br ON br.BrokerID = o.BrokerId
        LEFT JOIN agent ag ON ag.AgentId = o.AgentId ', whereQuery, orderSql, limitSql, ';' );
        
	PREPARE stmt FROM @query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
	SELECT Id, Description FROM problem_status;
    SELECT Id, Description FROM problem_types;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrdersProcessGroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrdersProcessGroup`(
	IN userId int,
	IN clientId int,
	IN role varchar(255)
)
BEGIN
	DECLARE whereQuery varchar(5000);
    
    IF (role = 'Client') THEN SET whereQuery = CONCAT('(o.BrokerId=',clientId,' or (o.BrokerId in (select Brokerid from `broker` where `broker`.GID=',clientId,')) and O.InActive = false)'); END IF;
    IF (role = 'Branch') THEN SET whereQuery = CONCAT('o.BrokerId=',clientId); END IF;
    IF (role = 'Agent') THEN SET whereQuery = CONCAT('o.AgentId=',clientId); END IF;
        
	set @querySqlCount = CONCAT('select `progress`.ProgressDescription as Status, Count(*) as Total
from `order` as o
LEFT JOIN `signer` on o.SignerId = `signer`.SignerId  
LEFT JOIN `borrower` on o.BorrowerId = `borrower`.BorrowerId 
LEFT JOIN `agent` on o.AgentId = `agent`.AgentId 
LEFT JOIN `broker` on `agent`.BrokerId = `broker`.BrokerID
LEFT JOIN `progress` on o.ProgressId = `progress`.ProgressId
LEFT JOIN `employees` on o.RepId = `employees`.RepId
WHERE ', whereQuery,' GROUP BY `progress`.ProgressId');
    PREPARE stmtCount FROM @querySqlCount;
	EXECUTE stmtCount;
	DEALLOCATE PREPARE stmtCount;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrdersSentOffers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrdersSentOffers`(
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
	IN searchOrderID int
)
BEGIN
	DECLARE orderIDWhereSql varchar(255);
    DECLARE searchedTableSql varchar(1000);
    DECLARE resultTableSql varchar(1000);
    
	DECLARE orderSql varchar(255);
	DECLARE sortDirectionSql varchar(255);
    DECLARE limitSql varchar(255);

    -- search condition for OrderID
    IF (searchOrderID IS NULL)
      THEN SET orderIDWhereSql = '';
	ELSE SET orderIDWhereSql = CONCAT(' AND OrderId = ', searchOrderID);
    END IF;

    SET searchedTableSql = CONCAT('SELECT * FROM signer_offer WHERE TRUE' , orderIDWhereSql);
    
    -- limit searchResult
    SET limitSql = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ', ', pageSize);
        
    -- sort
	IF (sortDirection = 1) 
		THEN SET sortDirectionSql = ' ASC';
	ELSE SET sortDirectionSql = ' DESC';
    END IF;
	-- SELECT sortDirectionQuery;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderSql = ' ORDER BY OfferID ';
	ELSE SET orderSql = CONCAT(' ORDER BY ', sortBy, sortDirectionSql);
    END IF;
    
    -- join order and signer table to get more information -> sort
    SET resultTableSql = CONCAT('SELECT SQL_CALC_FOUND_ROWS SO.OfferID, SO.OfferAmount,
		S.LastName, S.FirstName, SO.RepId, SO.SentDate, SO.ResponseDate,
        	CASE SO.OfferStatus
				WHEN ''M'' THEN ''Missed''
				WHEN ''A'' THEN ''Accepted''
				WHEN ''D'' THEN ''Declined''
				WHEN ''N'' THEN ''No Response''
				ELSE null
			END AS OfferStatus,
            
            CASE SO.TextSent
				WHEN 1 THEN ''Y''
				WHEN 0 THEN ''N''
				ELSE null
			END AS TextSent
		FROM (', searchedTableSql, ') SO LEFT JOIN signer S ON S.SignerId = SO.SignerId', orderSql, limitSql,';');
    
	SET @querySql= resultTableSql;
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getOrderStatusDropDownData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `getOrderStatusDropDownData`()
BEGIN
	select * from progress;
	SELECT * FROM delivery_method;
	select e.RepId, concat(e.FirstName, ' ', e.LastName) as `RepID` from employees e where Active;
	select * from loan_type;
    select p.ProgressId as `defaultProgressSelect` from progress p where p.ProgressDescription = "Open";
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOrdersVendorList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrdersVendorList`(
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN isAdvancedSearch bit,
	IN forOrderId int,
    IN searchVendorName varchar(255),
    IN searchDistance int,
    IN searchLanguageId int,
    IN searchNumberOfClosedOrder int,
    IN searchSystemRatingId int,
    IN searchCity varchar(255),
    IN searchStateId varchar(10),
    IN searchZip varchar(10),
    IN searchPhoneNumber varchar(20),
    IN filterVendorCategories varchar(3000)
)
BEGIN    
	DECLARE orderSql varchar(255);
	DECLARE sortDirectionSql varchar(255);
    DECLARE limitSql varchar(255);
    DECLARE filterSpecialty varchar(255); 
    DECLARE resultTableSql varchar(9999);
	DECLARE resultTableSql1 varchar(9999);
    DECLARE signerIds varchar(9999);
    
    SET signerIds = '';
    
    -- CIRTERIA GO HERE
		-- limit result
		SET limitSql = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ', ', pageSize);
			
		-- sort
		IF (sortDirection = 1) 
			THEN SET sortDirectionSql = ' ASC';
		ELSE SET sortDirectionSql = ' DESC';
		END IF;
		
		IF (sortBy IS NOT NULL AND sortBy <> '')
			THEN SET orderSql = CONCAT(' ORDER BY ', sortBy, sortDirectionSql, ', signerId ASC');
		ELSE
			SET orderSql= CONCAT( 'ORDER BY SortOrder ASC, distance ', sortDirectionSql, ', signerId ASC');
		END IF;
    
    -- NEED VALUE FOR FILTER
		-- order value
		SELECT LanguageId, CoLanguageId, AptDateTime, BrokerId, CustomerId, IsVenOrCEDefineADT, Zip
		INTO @OrderLanguageId, @OrderCoLanguageId, @OrderAptDateTime, @OrderBrokerId, @OrderCustomerId, @OrderIsVenOrCEDefineADT, @OrderZip
		FROM `order` WHERE OrderId = forOrderId;
		
		SELECT `Long`, Lat INTO @OrderLong, @OrderLat FROM zip WHERE Zip = @OrderZip;
        
		-- broker or customer requirement value
		DROP TEMPORARY TABLE IF EXISTS reqTrainingTable;
		CREATE TEMPORARY TABLE reqTrainingTable (ProgramId int);

		IF @OrderCustomerId IS NOT NULL
			THEN
				SELECT ReqRating, ReqExperienceNumber INTO @ReqRating, @ReqExperienceNumber FROM customers WHERE CustomerId = @OrderCustomerId;
                SELECT GROUP_CONCAT(CVS.CatId) INTO @Specialty FROM customer_vendor_specialty CVS WHERE CVS.CustomerId =  @OrderCustomerId;
				INSERT INTO reqTrainingTable
					SELECT CTR.ProgramId FROM
						customer_training_req CTR INNER JOIN training_programs TP ON
							CTR.ProgramId = TP.ProgramId 
							AND CTR.CustomerId = @OrderCustomerId
							AND (TP.Inactive = 0 OR TP.Inactive IS NULL)
							AND TP.IsPublished = 1
					;
					
			ELSEIF @OrderBrokerId IS NOT NULL
				THEN
					SELECT ReqRating, ReqExperienceNumber INTO @ReqRating, @ReqExperienceNumber FROM broker WHERE BrokerId = @OrderBrokerId;
                    SELECT GROUP_CONCAT(BVS.CatId) INTO @Specialty FROM broker_vendor_specialty BVS WHERE BVS.BrokerId =  @OrderBrokerId;
					INSERT INTO reqTrainingTable 
						SELECT BTR.ProgramId FROM
							broker_training_req BTR INNER JOIN training_programs TP ON
								BTR.ProgramId = TP.ProgramId 
								AND BTR.BrokerId = @OrderBrokerId
								AND (TP.Inactive = 0 OR TP.Inactive IS NULL)
								AND TP.IsPublished = 1
						;
		
			ELSE
				SET @ReqRating = NULL;
				SET @ReqExperienceNumber = NULL;
		END IF;
        
	-- SET filter vendor categories
		IF(filterVendorCategories IS NOT NULL AND filterVendorCategories <> '')
			THEN SET filterSpecialty = CONCAT_WS(",",@Specialty,filterVendorCategories);
		ELSE SET filterSpecialty = @Specialty;
		END IF;
        
	-- client preferred table
		DROP TEMPORARY TABLE IF EXISTS clientPreferredTable;
		CREATE TEMPORARY TABLE clientPreferredTable (SignerId int, ClientPreferredId int);
		
		IF @OrderCustomerId IS NOT NULL
			THEN 
				INSERT INTO clientPreferredTable(
					SELECT CPV.SignerId, CPV.Id AS ClientPreferredId
					FROM customer_preferred_vendor CPV
					WHERE CPV.CustomerId = @OrderCustomerId
				);
		ELSEIF @OrderBrokerId IS NOT NULL
			THEN 
				INSERT INTO clientPreferredTable(
					SELECT BPV.SignerId, BPV.Id AS ClientPreferredId
					FROM broker_preferred_vendor BPV
					WHERE BPV.BrokerId = @OrderBrokerId
				);		
		END IF;
 
    -- BASIC CONDITIONS AND ALWAYS ON SEARCH FITLER
    DROP TEMPORARY TABLE IF EXISTS basicConditionsSignerTable;
    CREATE TEMPORARY TABLE basicConditionsSignerTable (SignerId int, Rating int, WeekdayCity varchar(25), WeekdayState varchar(2), WeekdayZip varchar(5), Mobile varchar(15), VendorName varchar(100), Distance double, NumberOfClosedOrder int, NumberOfClosedReverseOrder int);
    
    INSERT INTO basicConditionsSignerTable (
		SELECT
			S.SignerId, S.Rating, S.WeekdayCity, S.WeekdayState, S.WeekdayZip, S.Mobile,
            CONCAT_WS(" ",S.FirstName, S.LastName) AS VendorName,
            (69.1*SQRT(POWER(Z.Lat-@OrderLat, 2)+0.6*POWER(Z.`Long`-@OrderLong, 2))) AS Distance,
            S.OrdersCount AS NumberOfClosedOrder, COUNT(BO.OrderId) AS NumberOfClosedReverseOrder
		FROM 
			signer S
            -- LANGUAGUE CONDITIONS
			INNER JOIN signer_language SL1 ON SL1.SignerId = S.SignerId AND SL1.LanguageId = @OrderLanguageId
			INNER JOIN signer_language SL2 ON SL2.SignerId = S.SignerId AND SL2.LanguageId = @OrderCoLanguageId
            -- LANGUAGUE SEARCH
            INNER JOIN signer_language SL3 ON SL3.SignerId = S.SignerId AND SL3.LanguageId = searchLanguageId
            LEFT JOIN zip Z ON Z.Zip = S.WeekdayZip
            LEFT JOIN `order` O ON S.SignerId = O.SignerId AND O.ProgressId = 8
			LEFT JOIN (
						SELECT O.OrderId, O.SignerId
						FROM
							`order` O INNER JOIN broker B ON O.BrokerId = B.BrokerId AND B.IndustryId = 2 AND O.ProgressId = 8
					) BO ON S.SignerId = BO.SignerId
		WHERE
			-- SNOOZE TIME CONDITIONS
			(NOT S.Snooze OR @OrderIsVenOrCEDefineADT OR @OrderAptDateTime IS NULL OR @OrderAptDateTime NOT BETWEEN S.SnoozeFrom AND S.SnoozeTo)
            -- RATING AND NEW VENDOR CONDITIONS
			AND (((S.Rating <> 4 AND S.Rating <> 5 AND S.Rating <> 6) OR (S.Rating = 6 AND ((S.Qualified = 'D' OR S.Qualified = 'Q') OR EXISTS(SELECT vts.ResultId FROM vendor_test_result vts WHERE vts.VendorId = S.SignerId AND vts.Passed = 'N' AND vts.TestId = (SELECT DISTINCT ti.TestId FROM test_info ti WHERE ti.DefaultTest = 1))))))
            -- CLIENT DO NOT USE CONDITIONS
			AND (NOT EXISTS (SELECT Id FROM broker_donotuse BDN WHERE BDN.BrokerId = @OrderBrokerId AND BDN.SignerId = S.SignerId))
			AND (NOT EXISTS (SELECT Id FROM customer_donotuse CDN WHERE CDN.CustomerId = @OrderCustomerId AND CDN.SignerId = S.SignerId))
        
			-- APTDATETIME CONDITION- EXIST ORDER HAVE SAME APTDATETIME AND HAVEN'T CLOSED YET
			AND (@OrderIsVenOrCEDefineADT OR NOT EXISTS (
				SELECT OrderId FROM `order` O 
					WHERE O.SignerId = S.SignerId
					AND O.AptDateTime = @OrderAptDateTime
					AND (O.ProgressId < 6 OR O.ProgressId = 10)
            ))
            -- VENDOR NAME SEARCH
            AND (CONCAT_WS(" ", S.FirstName, S.LastName) LIKE CONCAT('%', searchVendorName, '%') OR searchVendorName IS NULL OR searchVendorName = '')
            -- DISTANCE SEARCH
			AND ((69.1*SQRT(POWER(Z.Lat-@OrderLat, 2)+0.6*POWER(Z.`Long`-@OrderLong, 2))) <= searchDistance OR searchDistance IS NULL OR searchDistance = '')
		GROUP BY S.SignerId
	)
	;
    
    
    DROP TEMPORARY TABLE IF EXISTS searchedSignerTable;
    CREATE TEMPORARY TABLE searchedSignerTable (SignerId int, VendorName varchar(100), Distance double, Rating int, NumberOfClosedOrder int);
    
    IF (NOT isAdvancedSearch)
	THEN
		-- BASIC SEARCH GO HERE - HAVE CLIENT REQUIREMENTS
        INSERT INTO searchedSignerTable (
			SELECT S.SignerId, S.VendorName, S.Distance, S.Rating, S.NumberOfClosedOrder
			FROM
				basicConditionsSignerTable S
			WHERE
				-- RATING REQUIREMENT
				(find_in_set(S.Rating, @ReqRating) OR @ReqRating IS NULL OR @ReqRating='')
				-- NUMBER OF CLOSED ORDER REQUIREMENT
                AND	(S.NumberOfClosedOrder >= @ReqExperienceNumber OR @ReqExperienceNumber IS NULL)
				-- TRAINING REQUIREMENT
				AND (
					NOT EXISTS (
						SELECT RT.ProgramId FROM reqTrainingTable RT WHERE RT.ProgramId NOT IN (
							SELECT VRP.ProgramId FROM vendor_registered_programs VRP WHERE VRP.VendorId = S.SignerId AND VRP.IsComplete =1
						)
					))
        );

	ELSE
		-- ADVANCED SEARCH GO HERE
        INSERT INTO searchedSignerTable (
			SELECT S.SignerId, S.VendorName, S.Distance, S.Rating, S.NumberOfClosedOrder
			FROM
				basicConditionsSignerTable S
			WHERE
				(S.Rating = searchSystemRatingId OR searchSystemRatingId IS NULL)
				AND (S.WeekdayCity LIKE CONCAT('%', searchCity,'%') OR searchCity IS NULL OR searchCity = '')
				AND (S.WeekdayState LIKE CONCAT('%', searchStateId,'%') OR searchStateId IS NULL OR searchStateId = '')
				AND (S.WeekdayZip LIKE CONCAT('%',searchZip ,'%') OR searchZip IS NULL OR searchZip = '')
				AND (S.Mobile LIKE CONCAT('%',searchPhoneNumber ,'%') OR searchPhoneNumber IS NULL OR searchPhoneNumber = '')
				AND	(S.NumberOfClosedOrder >= searchNumberOfClosedOrder OR searchNumberOfClosedOrder IS NULL)
        );
    END IF;
    
    -- VENDOR CATEGORIES FILTER
	DROP TEMPORARY TABLE IF EXISTS filteredSignerTable;
    CREATE TEMPORARY TABLE filteredSignerTable (SignerId int, VendorName varchar(100), Distance double, Rating int, NumberOfClosedOrder int, NumberOfClosedReverseOrder int);
    
    IF (filterSpecialty IS NULL OR filterSpecialty = '')
		THEN
			-- LIST CATEGORIES IS NULL -> DOES NOT CHECK CONDITION
			INSERT INTO filteredSignerTable(
				SELECT
					S.*, COUNT(BO.OrderId) AS NumberOfClosedReverseOrder
				FROM
					searchedSignerTable S
					LEFT JOIN (
						SELECT O.OrderId, O.SignerId
						FROM
							`order` O INNER JOIN broker B ON O.BrokerId = B.BrokerId AND B.IndustryId = 2 AND O.ProgressId = 8
					) BO ON S.SignerId = BO.SignerId
				GROUP BY S.SignerId
			);
        ELSE
			-- FILTER CONDITIONS GO HERE
            
			SELECT MAX(VC.MinOrder), MIN(VC.MinRating), MAX(VC.MinRMOrder) INTO @TotalMinOrder, @TotalMinRating, @TotalMinRMOrder
            FROM vendor_categories VC WHERE FIND_IN_SET(VC.CatId, filterSpecialty) > 0;
        
			INSERT INTO filteredSignerTable(
				SELECT
					S.*, COUNT(BO.OrderId) AS NumberOfClosedReverseOrder
				FROM
					searchedSignerTable S
					LEFT JOIN (
						SELECT O.OrderId, O.SignerId
						FROM
							`order` O INNER JOIN broker B ON O.BrokerId = B.BrokerId AND B.IndustryId = 2 AND O.ProgressId = 8
					) BO ON S.SignerId = BO.SignerId
				WHERE
					S.NumberOfClosedOrder >= @TotalMinOrder
					AND S.Rating <= @TotalMinRating
                    AND (
						NOT EXISTS (
							SELECT VCT.TestId
							FROM vendor_cat_testtaken VCT
							WHERE 
								FIND_IN_SET(VCT.CatId, filterSpecialty) > 0
								AND VCT.TestId NOT IN (
									SELECT VTS.TestId FROM vendor_test_result VTS WHERE VTS.VendorId = S.SignerId AND VTS.Passed LIKE 'Y')
						)
					)
				GROUP BY S.SignerId
				HAVING COUNT(BO.OrderId) >= @TotalMinRMOrder
			);
    END IF;
	
-- VENDOR CATEGORIES FILTER PREFERRED
	DROP TEMPORARY TABLE IF EXISTS filteredPreferredSignerTable;
    CREATE TEMPORARY TABLE filteredPreferredSignerTable (SignerId int, VendorName varchar(100), Distance double, Rating int, NumberOfClosedOrder int, NumberOfClosedReverseOrder int);
    
    IF (filterVendorCategories IS NULL OR filterVendorCategories = '')
		THEN
			-- LIST CATEGORIES IS NULL -> DOES NOT CHECK CONDITION
			INSERT INTO filteredPreferredSignerTable(
				SELECT
					S.*, COUNT(BO.OrderId) AS NumberOfClosedReverseOrder
				FROM
					searchedSignerTable S
					LEFT JOIN (
						SELECT O.OrderId, O.SignerId
						FROM
							`order` O INNER JOIN broker B ON O.BrokerId = B.BrokerId AND B.IndustryId = 2 AND O.ProgressId =8
					) BO ON S.SignerId = BO.SignerId
				GROUP BY S.SignerId
			);
        ELSE
			-- FILTER CONDITIONS GO HERE
            
			SELECT MAX(VC.MinOrder), MIN(VC.MinRating), MAX(VC.MinRMOrder) INTO @TotalMinOrder, @TotalMinRating, @TotalMinRMOrder
            FROM vendor_categories VC WHERE FIND_IN_SET(VC.CatId, filterVendorCategories) > 0;
        
			INSERT INTO filteredPreferredSignerTable(
				SELECT
					S.*, COUNT(BO.OrderId) AS NumberOfClosedReverseOrder
				FROM
					searchedSignerTable S
					LEFT JOIN (
						SELECT O.OrderId, O.SignerId
						FROM
							`order` O INNER JOIN broker B ON O.BrokerId = B.BrokerId AND B.IndustryId = 2 AND O.ProgressId = 8
					) BO ON S.SignerId = BO.SignerId
				WHERE
					S.NumberOfClosedOrder >= @TotalMinOrder
					AND S.Rating <= @TotalMinRating
                    AND (
						NOT EXISTS (
							SELECT VCT.TestId
							FROM vendor_cat_testtaken VCT
							WHERE 
								FIND_IN_SET(VCT.CatId, filterVendorCategories) > 0
								AND VCT.TestId NOT IN (
									SELECT VTS.TestId FROM vendor_test_result VTS WHERE VTS.VendorId = S.SignerId AND VTS.Passed LIKE 'Y')
						)
					)
				GROUP BY S.SignerId
				HAVING COUNT(BO.OrderId) >= @TotalMinRMOrder
			);
    END IF;	
	
	-- CLIENT PREFERRED
	DROP TEMPORARY TABLE IF EXISTS clientPreferredSignerTable;
    CREATE TEMPORARY TABLE clientPreferredSignerTable (SignerId int, VendorName varchar(100), Distance double, AvgFee double, WeekdayCity varchar(25), WeekdayState varchar(2), SystemRating varchar(20), ClientRating varchar(20), HomePhone varchar(15), Mobile varchar(15), VendorGroups varchar(100), vendorCatGroups varchar(100), VendorGroupsColor varchar(100), RatingId int, NumberOfClosedOrder int, NumberOfClosedReverseOrder int, VendorLat double, VendorLong double, OrderLat double, OrderLong double, email varchar(75), FirstName varchar(25), LastName varchar(25));
		INSERT INTO clientPreferredSignerTable(
			SELECT
				SQL_CALC_FOUND_ROWS
				BS.SignerId AS signerId, BS.VendorName AS vendorName, BS.Distance AS distance,
				S.AvgFee AS avgFee, S.WeekdayCity AS city, S.WeekdayState AS state,
				R1.Rating AS systemRating, R.Rating AS clientRating,
				S.HomePhone AS homePhone, S.Mobile AS mobile,
				GROUP_CONCAT(CatId SEPARATOR ';') AS vendorGroups,
				GROUP_CONCAT(CatName SEPARATOR ';') AS vendorCatGroups,
				GROUP_CONCAT(Color SEPARATOR ';') AS vendorGroupsColor,
				BS.Rating AS ratingId, BS.NumberOfClosedOrder AS numberOfClosedOrder, BS.NumberOfClosedReverseOrder AS numberOfClosedReverseOrder,
				Z.Lat AS vendorLat, Z.Long AS vendorLong,
				@OrderLat AS orderLat, @OrderLong AS orderLong,
				S.email AS vendorEmail, S.FirstName AS firstName, S.LastName AS lastName
			FROM
				filteredPreferredSignerTable BS
				INNER JOIN clientPreferredTable CP ON CP.SignerId = BS.SignerId
				LEFT JOIN signer S ON BS.SignerId = S.SignerId
				LEFT JOIN rating R1 ON R1.RatingID = S.Rating
				LEFT JOIN rating R ON R.RatingID = S.ClientRating
				LEFT JOIN zip Z ON Z.Zip = S.WeekdayZip
				LEFT JOIN vendor_categories VC ON (
					BS.NumberOfClosedOrder >= VC.MinOrder
					AND BS.NumberOfClosedReverseOrder >= MinRMOrder
					AND BS.Rating <= VC.MinRating
					AND (
							NOT EXISTS (
								SELECT VCT.TestId
								FROM vendor_cat_testtaken VCT
								WHERE 
									VCT.CatId = VC.CatId 
									AND VCT.TestId NOT IN (
										SELECT VTS.TestId FROM vendor_test_result VTS WHERE VTS.VendorId = BS.SignerId AND VTS.Passed LIKE 'Y')
							)
						)
					)
			GROUP BY BS.SignerId
		);
		
-- CLIENT REQUIREMENTS
	DROP TEMPORARY TABLE IF EXISTS clientRequirementsSignerTable;
    CREATE TEMPORARY TABLE clientRequirementsSignerTable (SignerId int, VendorName varchar(100), Distance double, AvgFee double, WeekdayCity varchar(25), WeekdayState varchar(2), SystemRating varchar(20), ClientRating varchar(20), HomePhone varchar(15), Mobile varchar(15), VendorGroups varchar(100), vendorCatGroups varchar(100), VendorGroupsColor varchar(100), RatingId int, NumberOfClosedOrder int, NumberOfClosedReverseOrder int, VendorLat double, VendorLong double, OrderLat double, OrderLong double, email varchar(75), FirstName varchar(25), LastName varchar(25));
		INSERT INTO clientRequirementsSignerTable(
			SELECT
				SQL_CALC_FOUND_ROWS
				SS.SignerId AS signerId, SS.VendorName AS vendorName, SS.Distance AS distance,
				S.AvgFee AS avgFee, S.WeekdayCity AS city, S.WeekdayState AS state,
				R1.Rating AS systemRating, R.Rating AS clientRating,
				S.HomePhone AS homePhone, S.Mobile AS mobile,
				GROUP_CONCAT(CatId SEPARATOR ';') AS vendorGroups,
				GROUP_CONCAT(CatName SEPARATOR ';') AS vendorCatGroups,
				GROUP_CONCAT(Color SEPARATOR ';') AS vendorGroupsColor,
				SS.Rating AS ratingId, SS.NumberOfClosedOrder AS numberOfClosedOrder, SS.NumberOfClosedReverseOrder AS numberOfClosedReverseOrder,
				Z.Lat AS vendorLat, Z.Long AS vendorLong,
				@OrderLat AS orderLat, @OrderLong AS orderLong,
				S.email AS vendorEmail, S.FirstName AS firstName, S.LastName AS lastName
			FROM
				filteredSignerTable SS
				LEFT JOIN signer S ON SS.SignerId = S.SignerId
				LEFT JOIN rating R1 ON R1.RatingID = S.Rating
				LEFT JOIN rating R ON R.RatingID = S.ClientRating
				LEFT JOIN zip Z ON Z.Zip = S.WeekdayZip
				LEFT JOIN vendor_categories VC ON (
					SS.NumberOfClosedOrder >= VC.MinOrder
					AND SS.NumberOfClosedReverseOrder >= MinRMOrder
					AND SS.Rating <= VC.MinRating
					AND (
							NOT EXISTS (
								SELECT VCT.TestId
								FROM vendor_cat_testtaken VCT
								WHERE 
									VCT.CatId = VC.CatId 
									AND VCT.TestId NOT IN (
										SELECT VTS.TestId FROM vendor_test_result VTS WHERE VTS.VendorId = SS.SignerId AND VTS.Passed LIKE 'Y')
							)
						)
					)
				LEFT JOIN clientPreferredSignerTable CP ON CP.SignerId = SS.SignerId
			GROUP BY SS.SignerId
		);
        
	SELECT group_concat(cps.signerId) INTO @signerIds FROM clientPreferredSignerTable cps;
    IF(@signerIds IS NULL)
		THEN SET signerIds = '0';
	ELSE 
		SET signerIds = @signerIds;
    END IF;
        		
    SET resultTableSql = CONCAT('SELECT SQL_CALC_FOUND_ROWS * FROM (
    SELECT 
		CPS.SignerId AS signerId, CPS.VendorName AS vendorName, CPS.Distance AS distance,
        CPS.AvgFee AS avgFee, CPS.WeekdayCity AS city, CPS.WeekdayState AS state,
        CPS.SystemRating AS systemRating, CPS.ClientRating AS clientRating,
        CPS.HomePhone AS homePhone, CPS.Mobile AS mobile,
        CPS.VendorGroups AS vendorGroups,
        CPS.vendorCatGroups AS vendorCatGroups,
        CPS.VendorGroupsColor AS vendorGroupsColor,
        CPS.RatingId AS ratingId, CPS.NumberOfClosedOrder AS numberOfClosedOrder, CPS.NumberOfClosedReverseOrder AS numberOfClosedReverseOrder,
        CPS.VendorLat AS vendorLat, CPS.VendorLong AS vendorLong,
        CPS.OrderLat AS orderLat, CPS.OrderLong AS orderLong,
        CPS.email AS vendorEmail, CPS.FirstName AS firstName, CPS.LastName AS lastName,
        0 as SortOrder, 0 as isSelected
	FROM clientPreferredSignerTable CPS
	UNION ALL
	SELECT 
		CRS.SignerId AS signerId, CRS.VendorName AS vendorName, CRS.Distance AS distance,
        CRS.AvgFee AS avgFee, CRS.WeekdayCity AS city, CRS.WeekdayState AS state,
        CRS.SystemRating AS systemRating, CRS.ClientRating AS clientRating,
        CRS.HomePhone AS homePhone, CRS.Mobile AS mobile,
        CRS.VendorGroups AS vendorGroups,
        CRS.vendorCatGroups AS vendorCatGroups,
        CRS.VendorGroupsColor AS vendorGroupsColor,
        CRS.RatingId AS ratingId, CRS.NumberOfClosedOrder AS numberOfClosedOrder, CRS.NumberOfClosedReverseOrder AS numberOfClosedReverseOrder,
        CRS.VendorLat AS vendorLat, CRS.VendorLong AS vendorLong,
        CRS.OrderLat AS orderLat, CRS.OrderLong AS orderLong,
        CRS.email AS vendorEmail, CRS.FirstName AS firstName, CRS.LastName AS lastName,
        1 as SortOrder, 0 as isSelected
    FROM clientRequirementsSignerTable CRS WHERE CRS.SignerId NOT IN (',signerIds,') ) t ', orderSql, limitSql,';');
	    
	SET @querySql= resultTableSql;
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
	SELECT FOUND_ROWS() AS TotalRecords;

    DROP TEMPORARY TABLE IF EXISTS reqTrainingTable;
    DROP TEMPORARY TABLE IF EXISTS basicConditionsSignerTable;
    DROP TEMPORARY TABLE IF EXISTS searchedSignerTable;
    DROP TEMPORARY TABLE IF EXISTS filteredSignerTable;
    DROP TEMPORARY TABLE IF EXISTS clientPreferredTable;
    DROP TEMPORARY TABLE IF EXISTS clientPreferredSignerTable;
    DROP TEMPORARY TABLE IF EXISTS clientRequirementsSignerTable;
    DROP TEMPORARY TABLE IF EXISTS filteredPreferredSignerTable;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetPendingOrderDashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetPendingOrderDashboard`(
	IN pageNumber int,
	IN pageSize int,
    IN role varchar(255),
	IN clientId int
)
BEGIN
    DECLARE limitQuery varchar(255);
	DECLARE andWhereQuery varchar(500);
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

	IF (role = 'Client') 
		THEN SET andWhereQuery = CONCAT(' AND (`order`.BrokerId=',clientId,' or `order`.BrokerId in (select Brokerid from `broker` where `broker`.GID = ',clientId, ')) ');
	ELSE IF  (role = 'Branch') 
		THEN SET andWhereQuery = CONCAT(' AND `order`.BrokerId=',clientId);
	ELSE IF (role = 'Agent') 
		THEN SET andWhereQuery = CONCAT(' AND `order`.AgentId=',clientId);
		END IF;
    END IF;
    END IF;
    
	SET @querySqlPendingApproaching = CONCAT(' SELECT SQL_CALC_FOUND_ROWS `order`.`OrderId` AS `orderId`,
								CONVERT(TIME_FORMAT(TIMEDIFF(AptDateTime - INTERVAL `zip`.UTC HOUR,UTC_TIMESTAMP()), "%H : %i"), char(10)) AS `time`
								FROM `order`
                                INNER JOIN zip ON `order`.Zip = `zip`.Zip
                                LEFT JOIN `agent` on `order`.AgentId = `agent`.AgentId 
								LEFT JOIN `broker` on `order`.BrokerId = `broker`.BrokerID 
								WHERE `order`.ProgressId = 3
                                AND `order`.InActive = 0
								AND HOUR(TIMEDIFF(AptDateTime - INTERVAL `zip`.UTC HOUR,UTC_TIMESTAMP())) < 3
                                AND `order`.AptDateTime - INTERVAL `zip`.UTC HOUR > UTC_TIMESTAMP() ',andWhereQuery,
                                ' ORDER BY `time` ASC ' ,limitQuery);
	PREPARE stmt FROM @querySqlPendingApproaching;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecordsPendingApproaching;
    
    SET @querySqlPendingOut = CONCAT(' SELECT SQL_CALC_FOUND_ROWS `order`.`OrderId` AS `orderId`,
								CONVERT(TIME_FORMAT(TIMEDIFF(UTC_TIMESTAMP(),`order`.AptDateTime - INTERVAL `zip`.UTC HOUR), "%H : %i"), char(10)) AS `time`
								FROM `order` 
                                INNER JOIN zip ON `order`.Zip = `zip`.Zip
                                LEFT JOIN `agent` on `order`.AgentId = `agent`.AgentId 
								LEFT JOIN `broker` on `order`.BrokerId = `broker`.BrokerID 
								WHERE `order`.ProgressId = 3
                                AND `order`.InActive = 0
								AND UTC_TIMESTAMP() > `order`.AptDateTime - INTERVAL `zip`.UTC HOUR ',andWhereQuery,
                                ' ORDER BY `time` ASC '  ,limitQuery);

	PREPARE stmt FROM @querySqlPendingOut;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecordsPendingOut;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetRecentOrdersByBrokerId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetRecentOrdersByBrokerId`(
	IN `sortBy` VARCHAR(255),
	IN `sortDirection` BIT,
	IN `pageNumber` INT,
	IN `pageSize` INT,
	IN `recentDay` INT,
	IN `brokerId` INT

)
BEGIN

    DECLARE orderQuery varchar(255);  
	 DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  

	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE o.OrderDate >= DATE(UTC_TIMESTAMP()) - INTERVAL ',recentDay,' DAY AND o.brokerId =', brokerId);
         
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
				o.OrderId, b.LastName as ClientLast, s.LastName as VendorLast, c.Company, p.ProgressDescription, o.OrderDate, o.AptDateTime
            FROM 
					`order` o
					LEFT JOIN `borrower` b ON
						o.BorrowerId = b.BorrowerId
					LEFT JOIN `signer` s ON 
						o.SignerId = s.SignerId
					LEFT JOIN `broker` c ON
						o.BrokerId = c.BrokerID
					LEFT JOIN `progress` p ON
						o.ProgressId = p.ProgressId
				, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
   PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetRolesPermission` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetRolesPermission`(
	IN roleType VARCHAR(10)
)
BEGIN
	DECLARE whereQuery varchar(255); 
    
	SET whereQuery = CONCAT(' WHERE ApplyFor = ''', roleType, '''');
    
    SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* FROM ( SELECT 
								p.PermissionId, p.Description,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=1) THEN 1 ELSE 0 END AS Admin,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=2) THEN 1 ELSE 0 END AS OperationalManager,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=3) THEN 1 ELSE 0 END AS Scheduler,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=4) THEN 1 ELSE 0 END AS StatusRep,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=5) THEN 1 ELSE 0 END AS Client,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=6) THEN 1 ELSE 0 END AS Branch,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=7) THEN 1 ELSE 0 END AS Agent,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=9) THEN 1 ELSE 0 END AS ContentManager,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=10) THEN 1 ELSE 0 END AS TrainingManager,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=11) THEN 1 ELSE 0 END AS AccountingManager,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=12) THEN 1 ELSE 0 END AS QualityControl,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=13) THEN 1 ELSE 0 END AS Sale,
								CASE WHEN EXISTS (SELECT RoleId FROM `role_permissions` rp WHERE rp.PermissionId=p.PermissionId AND rp.RoleId=14) THEN 1 ELSE 0 END AS SubAdmin
							FROM `permissions` p', whereQuery, ' ORDER BY p.PermissionId ) AS t1, (SELECT @rownum := 0) r ');

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetSignerAdditionalInforRecentOrders` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetSignerAdditionalInforRecentOrders`(
IN signerId varchar(500),
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';
    
	SET whereQuery = CONCAT(whereQuery, ' AND ord.signerId= ',signerId);
    SET whereQuery = CONCAT(whereQuery, ' AND ord.orderDate >= UTC_TIMESTAMP() - INTERVAL ', '3 YEAR');
   
	SET @querySql= concat('
     SELECT 
     SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
            ord.orderId,
            ord.lastName,
            br.company,
            concat(em.firstName, '' '', em.lastName) as repName,
            pr.progressDescription,
            (SELECT sum(signerFee) from order_fee of where of.orderId = ord.orderId) as totalFee,
            ord.orderDate,
            ord.aptDatetime,
            ord.aptUtc,
            (CASE 
				WHEN (SELECT COUNT(*) from order_problem op where op.signerId=',signerId,' and op.orderId=ord.orderId ) > 0 THEN  ''Yes''	
				ELSE ''No'' END) as hasMistakes
			FROM `order` ord
            LEFT JOIN employees em on em.repId = ord.repId
			LEFT JOIN broker br on br.brokerId = ord.brokerId
            LEFT JOIN progress pr on ord.progressId = pr.progressId
            , (SELECT @rownum := 0) r
            ',
            whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getSignerOfferTest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `getSignerOfferTest`(
IN orderId int,
IN isEliteVendor BIT
)
BEGIN
	DECLARE lat1 FLOAT;
    DECLARE long1 FLOAT;
    DECLARE startZip VARCHAR(20);
    DECLARE brokerId INT;
    DECLARE state VARCHAR(2);
    DECLARE amount FLOAT;
    DECLARE languageId INT;
    DECLARE coLanguageId INT;
    DECLARE signerId INT;
    DECLARE customerId INT;
    DECLARE dist FLOAT;
    DECLARE autoProgress VARCHAR(1);
    DECLARE aptDateTime DATETIME;
    DECLARE isVenOrCeDefineAdt BIT;
    DECLARE rowFindCount INT DEFAULT 0;
    DECLARE isFinished INTEGER DEFAULT 0;
    DECLARE eliteName VARCHAR(20) DEFAULT 'elite';
    DECLARE mile INT DEFAULT 50;
    DECLARE offerSent INT;

	-- get zip, brokerId, state, feeAmount from order
    SELECT ord.zip , 
		   ord.brokerId, 
		   ord.state,
           -- auto = brk.autoOrder, 
		   (SELECT SUM(of.signerFee) FROM order_fee of WHERE of.orderId = ord.orderID),
           ord.languageId,
           ord.coLanguageId,
           ord.customerId,
           ord.aptDateTime,
           ord.isVenOrCeDefineAdt,
           ord.autoProgress
	INTO startZip, brokerId, state, amount, languageId, coLanguageId, customerId, aptDateTime, isVenOrCeDefineAdt,autoProgress
	FROM `order` ord
	JOIN broker brk ON brk.brokerID = ord.brokerid 
	WHERE ord.orderID = orderId;
    
    -- get lat, long by zip of order
	SELECT lat, `long` INTO lat1,long1 FROM zip WHERE zip = startZip LIMIT 0,1;
    
   	SELECT sn.signerId,  (69.1*sqrt(power(zp.lat-lat1,2)+0.6*power(zp.long-long1,2))) as dist
		FROM signer sn
        LEFT JOIN zip zp ON sn.weekdayZip = zp.zip
		WHERE 
		-- distance signer within miles 50/100
		 (69.1*sqrt(power(zp.lat-lat1,2)+0.6*power(zp.long-long1,2))) < 100 AND
		-- signer is active
		 (sn.inActive IS NULL OR sn.inActive = 0) AND
		-- co customer order language must match with signer language
		 (coLanguageId IS NULL OR coLanguageId = 0 OR coLanguageId IN (SELECT sl.languageId FROM signer_language sl WHERE sl.signerId = sn.signerId)) AND
		-- primary customer order language must match with signer language
		 (languageId IS NULL OR languageId = 0 OR languageId IN (SELECT sl.languageId FROM signer_language sl where sn.signerId= sl.signerId)) AND
		-- if vendor rating is new check qualified = "D" or "Q". Rating 7: New. 
		-- And rating must not poor (4) and need improvement (5)
		 (sn.rating NOT IN (4,5,6) OR ( sn.rating = 6 AND (sn.qualified = 'D' or sn.qualified = 'Q'))) AND
		-- signer does not include in DNU list of client/broker
		 sn.signerId NOT IN (SELECT brdnu.signerId FROM broker_donotuse brdnu WHERE brdnu.brokerId = brokerId) AND
		-- signer does not include in DNU list of customer
		  sn.signerId NOT IN (SELECT cusdnu.signerId FROM customer_donotuse cusdnu WHERE cusdnu.customerId = customerId) AND
		-- order’s apt time is not in vendor’s snooze time
		  (isVenOrCeDefineAdt = 1 OR ((sn.snooze = 0 OR sn.Snooze IS NULL) OR ((aptDateTime > sn.snoozeTo OR aptDateTime < sn.snoozeFrom )))) AND
		-- vendors have not accepted another order having the same aptDate and order progress in (closed, closing, cancelled)
		  (isVenOrCeDefineAdt = 1 OR (aptDateTime NOT IN (SELECT ord.aptDateTime FROM `order` ord 
							   WHERE ord.signerId = sn.signerId AND ord.progressId 
							   NOT IN (7,8,9,10,12) AND ord.orderId <> orderId))) AND
								  
		-- elite vendor and non-elite vendor
		 (
			-- elite vendor
			(isEliteVendor = 1 AND (((SELECT COUNT(catId) FROM vendor_categories WHERE catName = eliteName) = 0) OR ( 
				-- check min rating
				(sn.rating <= (SELECT vc.minRating FROM vendor_categories vc WHERE vc.catName = eliteName)) AND
				-- check number of order <= signer's complete orders 10 -> closing Completed
				((SELECT vc.minOrder FROM vendor_categories vc WHERE vc.catName = eliteName) 
				 <= (SELECT COUNT(ord.orderId) FROM `order` ord 
					 WHERE sn.signerId= ord.signerId AND ord.progressId IN (7,8,9,10) )) AND
				-- vendor must take required tests
				((SELECT COUNT(vct1.testId) FROM vendor_cat_testtaken vct1 
				 WHERE vct1.catId = (SELECT catId FROM vendor_categories WHERE catName = eliteName))
				 = (SELECT COUNT(vct.testId) FROM vendor_cat_testtaken vct 
					  WHERE vct.catId = (SELECT catId FROM vendor_categories WHERE catName = eliteName) AND
					  vct.testId IN (SELECT vtr.testId FROM vendor_test_result vtr 
				  WHERE vtr.passed = 'Y' AND vtr.vendorId = sn.signerId)))
			 ))) OR 
			 -- non-elite vendor
			  (isEliteVendor = 0 AND (((SELECT COUNT(catId) FROM vendor_categories WHERE catName = eliteName) = 0) OR ( 
				-- check min rating
				(sn.rating > (SELECT vc.minRating FROM vendor_categories vc WHERE vc.catName = eliteName)) OR
				-- check number of order <= signer's complete orders 10 -> closing Completed
				((SELECT vc.minOrder FROM vendor_categories vc WHERE vc.catName = eliteName) 
				 > (SELECT COUNT(ord.orderId) FROM `order` ord 
					 WHERE sn.signerId= ord.signerId AND ord.progressId  IN (7,8,9,10) )) OR
				-- vendor must take required tests
				((SELECT COUNT(vct1.testId) FROM vendor_cat_testtaken vct1 
				 WHERE vct1.catId = (SELECT catId FROM vendor_categories WHERE catName = eliteName))
				 <> (SELECT COUNT(vct.testId) FROM vendor_cat_testtaken vct 
					  WHERE vct.catId = (SELECT catId FROM vendor_categories WHERE catName = eliteName) AND
					  vct.testId IN (SELECT vtr.testId FROM vendor_test_result vtr 
				  WHERE vtr.passed = 'Y' AND vtr.vendorId = sn.signerId)))
			 )))
		)
		
		LIMIT 0,15;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetSignersApproval` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetSignersApproval`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN searchOrderID int,
IN searchStatus varchar(255),
IN searchRequestBy varchar(255)
)
BEGIN
    DECLARE orderIDWhereSql varchar(255);
    DECLARE statusWhereSql varchar(255);
    DECLARE signersApprovalTableSql varchar(255);
    
    DECLARE requestByWhereSql varchar(255);
    DECLARE employeesTableSql varchar(255);
    
    DECLARE searchedTableSql varchar(1000);
    DECLARE resultTableSql varchar(1000);
    
	DECLARE orderSql varchar(255);
	DECLARE sortDirectionSql varchar(255);
    DECLARE limitSql varchar(255);
    
    
    -- THIS COMMENT IS BETTER QUERY
    -- search condition for OrderID and Status
    -- IF (searchOrderID IS NULL)
    --   THEN SET orderIDWhereSql = '';
	-- ELSE SET orderIDWhereSql = CONCAT(' AND OrderId = ', searchOrderID);
    -- END IF;
    -- IF (searchStatus IS NULL OR searchStatus = '' OR searchStatus = 'All')
    --   THEN SET statusWhereSql = '';
	-- ELSE SET statusWhereSql = CONCAT(' AND Status = ''', searchStatus,'''');
    -- END IF;

    -- query that return all search rows of table SIGNER APPROVAL
    -- SET signersApprovalTableSql = CONCAT('SELECT * FROM signers_approval WHERE TRUE' , orderIDWhereSql, statusWhereSql);

	-- search condition for RequestBy
	-- IF (searchRequestBy IS NULL OR searchRequestBy = '')
    --   THEN SET requestByWhereSql = '';
	-- ELSE SET requestByWhereSql = CONCAT(' AND CONCAT_WS(" ",FirstName, LastName) LIKE ''%', searchRequestBy,'%''');
    -- END IF;
    
	-- query that return all search rows of table EMPLOYEES
    -- SET employeesTableSql = CONCAT('SELECT RepId, FirstName, LastName FROM employees WHERE TRUE', requestByWhereSql);
    
    -- join two table to get search result
    -- SET searchedTableSql = CONCAT('SELECT SA.*, CONCAT_WS(" ",E.FirstName, E.LastName) AS RequesterName FROM (', signersApprovalTableSql, ') SA JOIN (', employeesTableSql, ') E ON E.RepId = SA.RequestBy');
    -- THIS COMMENT IS BETTER QUERY
    
	IF (searchOrderID IS NULL)
	THEN SET orderIDWhereSql = '';
	ELSE SET orderIDWhereSql = CONCAT(' AND SA.OrderId = ', searchOrderID);
    END IF;
    
    IF (searchStatus IS NULL OR searchStatus = '' OR searchStatus = 'All')
       THEN SET statusWhereSql = '';
	ELSE SET statusWhereSql = CONCAT(' AND SA.Status = ''', searchStatus,'''');
    END IF;
    
    IF (searchRequestBy IS NULL OR searchRequestBy = '')
       THEN SET requestByWhereSql = '';
	ELSE SET requestByWhereSql = CONCAT(' AND CONCAT_WS(" ", E.LastName, E.FirstName) LIKE ''%', searchRequestBy,'%''');
    END IF;
    
    SET searchedTableSql = CONCAT('SELECT SA.*, CONCAT_WS(" ", E.LastName, E.FirstName) AS RequesterName FROM signers_approval SA LEFT JOIN employees E ON E.RepId = SA.RequestBy WHERE TRUE', orderIDWhereSql, statusWhereSql, requestByWhereSql);
    
	-- limit searchResult
    SET limitSql = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ', ', pageSize);
        
    -- sort
	IF (sortDirection = 1) 
		THEN SET sortDirectionSql = ' ASC';
	ELSE SET sortDirectionSql = ' DESC';
    END IF;
	-- SELECT sortDirectionQuery;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderSql = ' ORDER BY OrderId ';
	ELSE SET orderSql = CONCAT(' ORDER BY ', sortBy, sortDirectionSql);
    END IF;
    
    -- join order and signer table to get more information -> sort
    SET resultTableSql = CONCAT('SELECT SQL_CALC_FOUND_ROWS SA.*, CONCAT_WS(" ", S.LastName, S.FirstName) AS VendorName FROM (', searchedTableSql, ') SA LEFT JOIN signer S ON S.SignerId = SA.SignerId', orderSql, limitSql,';');
    
	SET @querySql= resultTableSql;
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    SELECT COUNT(*) AS CountOpen FROM signers_approval WHERE Status='Open';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetSignersApprovalById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetSignersApprovalById`(	
	IN identifier int(11),
    IN sortBy varchar(255),
    IN sortDirection bit
)
BEGIN
	DECLARE orderQuery varchar(255);  
    DECLARE whereQuery varchar(255);
	DECLARE sortDirectionQuery varchar(255);
    SET whereQuery = ' WHERE 1=1 ';
     
	IF(identifier IS NOT NULL AND identifier >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `ApprovalID` = ', identifier);
	END IF;
   IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY CreatedDate ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;  
    
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from ( select distinct `signers_approval`.OrderId,
									`signers_approval`.Status,
                                    `signers_approval`.ApprovalID,
                                    `signers_approval`.SignerId,
                                    `signers_approval`.MgrReason,
                                    `signers_approval`.Reason,
                                    `loan_type`.LoanType,
                                    `order`.City,
                                    `signer`.Email,
									`agent`.FullName,
                                    `signer_offer`.Distance,
                                    `signer_offer`.OfferAmount,
                                    `signer`.FirstName,
                                    `signer`.LastName,
                                    CONCAT(`signer`.LastName, " ", `signer`.FirstName) as `VendorName`,
                                    `comment`.TypeID,
									`comment`.Description,
                                    `comment`.CreatedDate,
                                     CONCAT(`employees`.LastName, " ", `employees`.FirstName) as `RequestedBy`
							FROM `signers_approval`  
                            left join `comment` on `comment`.OwnerID = `signers_approval`.ApprovalID AND `TypeID`=4 
                            left join `employees` on `signers_approval`.RequestBy = `employees`.RepId
							left join `signer_offer` on `signers_approval`.SignerId = `signer_offer`.SignerId
                            left join `order` on `signers_approval`.OrderId = `order`.OrderId
                            left join `loan_type` on `order`.LoanType = `loan_type`.LoanTypeId
							left join `agent` on `order`.AgentId = `agent`.AgentId
                            left join `signer` on `signer`.SignerId = `signers_approval`.SignerId) t1, (SELECT @rownum := 0) r', whereQuery, orderQuery );
    
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetSignerServiceData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetSignerServiceData`(
	IN `signerIdInput` INT(11)

)
BEGIN
	DECLARE coverageAreasIds varchar(1500);
    DECLARE sqlQuery varchar(255);
    
    SELECT `PickupDocs`, `CoverageArea`
	FROM `signer`
    WHERE `SignerId` = signerIdInput
    ;
    
    SELECT `CoverageArea` INTO coverageAreasIds
	FROM `signer`
    WHERE `SignerId` = signerIdInput
    ;
    
    IF coverageAreasIds IS NOT NULL AND coverageAreasIds <> ''
    THEN
		SET @sqlQuery = CONCAT('SELECT `Zip`, `City`, `AreaCode`
		FROM `zip`
		WHERE `Zip` IN(', coverageAreasIds, ')');
		
		PREPARE stmt FROM @sqlQuery;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
	END IF;
    
    -- SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetStaffVendors` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetStaffVendors`(
IN signerId varchar(500),
IN signerName varchar(500),
IN languages varchar(500),
IN city varchar(500),
IN state varchar(500),
IN zip varchar(500),
IN numberOfOrderMoreThan varchar(500),
IN rating varchar(500),
IN phone varchar(500),
IN email varchar(500),
IN categories varchar(500),
IN sortBy varchar(500),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
    DECLARE orderQuery varchar(500);  
	DECLARE sortDirectionQuery varchar(500);  
    DECLARE limitQuery varchar(500);  
    DECLARE whereQuery varchar(5000);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';
    
	IF (signerId IS NOT NULL AND signerId <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND sn.signerId =  ''', signerId, '''');
	END IF;
    
	IF (signerName IS NOT NULL AND signerName <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND concat(sn.firstName, '' '', sn.lastName) LIKE  ''%', signerName, '%''');
	END IF;
    
    
	IF (city IS NOT NULL AND city <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND sn.weekdayCity LIKE  ''%', city, '%''');
	END IF;
    
    IF (state IS NOT NULL AND state <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND sn.weekdayState LIKE  ''%', state, '%''');
	END IF;
    
    IF (zip IS NOT NULL AND zip <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND sn.weekdayZip LIKE  ''%', zip, '%''');
	END IF;
    
	IF (phone IS NOT NULL AND phone <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND (sn.homePhone LIKE  ''%', phone, '%''',
        ' OR sn.mobile LIKE  ''%', phone, '%''',' OR sn.workPhone LIKE  ''%', phone, '%'')');
	END IF;
    
	IF (email IS NOT NULL AND email <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND sn.email LIKE  ''%', email, '%''');
	END IF;
    
    IF (rating IS NOT NULL AND rating <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND sn.rating =  ''', rating, '''');
	END IF;
    
	IF (numberOfOrderMoreThan IS NOT NULL AND numberOfOrderMoreThan <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND (select count(*) from `order` ord 
				where ord.progressId = 8 and ord.signerId = sn.signerId) > ', numberOfOrderMoreThan);
	END IF;
    
    SET whereQuery = CONCAT(whereQuery, ' AND (sn.inActive IS NULL OR sn.inActive = 0)');
    
	IF (categories IS NOT NULL AND categories <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND ( 
				(sn.rating <= (SELECT MIN(vc.minRating) FROM vendor_categories vc WHERE find_in_set(vc.catId,''',categories,'''))) AND
				-- check number of order <= signer complete orders 8 -> closing Completed
				((SELECT Max(vc.minOrder) FROM vendor_categories vc WHERE find_in_set(vc.catId,''',categories,''')) 
				 <= (SELECT COUNT(ord.orderId) FROM `order` ord 
					 WHERE sn.signerId= ord.signerId AND ord.progressId = 8 )) AND
				-- vendor must take required tests
				((SELECT COUNT(vct1.testId) FROM vendor_cat_testtaken vct1 
				 WHERE vct1.catId IN (SELECT catId FROM vendor_categories vc WHERE find_in_set(vc.catId,''',categories,''')))
				 = (SELECT COUNT(vct.testId) FROM vendor_cat_testtaken vct 
					  WHERE vct.catId IN (SELECT catId FROM vendor_categories vc WHERE find_in_set(vc.catId,''',categories,''')) AND
					  vct.testId IN (SELECT vtr.testId FROM vendor_test_result vtr 
				  WHERE vtr.passed = ''Y'' AND vtr.vendorId = sn.signerId))) AND
				-- check number of order <= signer complete orders 8 -> closing Completed and industry order is reverse mortgage
				((SELECT MAX(vc.minRMOrder) FROM vendor_categories vc WHERE find_in_set(vc.catId,''',categories,''')) 
				 <= (SELECT COUNT(ord.orderId) FROM `order` ord left join broker br on br.brokerId = ord.brokerId
					 WHERE sn.signerId= ord.signerId AND ord.progressId = 8 and br.industryId = 2 )
                     OR (SELECT MAX(vc.minRMOrder) FROM vendor_categories vc WHERE find_in_set(vc.catId,''',categories,''')) IS NULL) 
			 )');
	END IF;
    
    IF (languages IS NOT NULL AND languages <> '')
		THEN SET whereQuery = CONCAT(whereQuery, '
					AND ( SELECT COUNT(sl.slId) from signer_language sl 
						WHERE
							FIND_IN_SET(sl.languageId, ''',languages,''')
							AND sn.signerId = sl.signerId )  = (LENGTH(''',languages,''') - LENGTH(REPLACE(''',languages,''', '','', ''''))+1) ');
	END IF;
 
	SET @querySql= concat('
     SELECT 
     SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			sn.signerId,
            concat(sn.firstName, '' '', sn.lastName) as signerName,
            rtc.rating as clientRating,
            sn.weekdayCity,
            sn.weekdayState,
            sn.weekdayZip,
            rt.rating,
            sn.homePhone,
            sn.workPhone,
            sn.email,
            sn.mobile,
            sn.avgFee,
            -- get group color specialty
            (SELECT 
					group_concat(vc.color separator ''; '') 
					FROM vendor_categories vc
					WHERE 
						-- check min rating
						(sn.rating <= vc.minRating AND
						-- check number of order <= signer complete orders 8 -> closing Completed
						(vc.minOrder <= (SELECT COUNT(ord.orderId) FROM `order` ord 
							 WHERE sn.signerId= ord.signerId AND ord.progressId = 8 )) AND
						-- vendor must take required tests
						((SELECT COUNT(vct1.testId) FROM vendor_cat_testtaken vct1 
						 WHERE vct1.catId = vc.CatId)
						 = (SELECT COUNT(vct.testId) FROM vendor_cat_testtaken vct 
							  WHERE vct.catId = vc.CatId AND
							  vct.testId IN (SELECT vtr.testId FROM vendor_test_result vtr 
						  WHERE vtr.passed = ''Y'' AND vtr.vendorId = sn.signerId))) AND
						-- check number of order <= signer complete orders 8 -> closing Completed and industry order is reverse mortgage
						(vc.minRMOrder <= (SELECT COUNT(ord.orderId) FROM `order` ord left join broker br on br.brokerId = ord.brokerId
							 WHERE sn.signerId= ord.signerId AND ord.progressId = 8 and br.industryId = 2 ) OR vc.minRMOrder is null) 
					)) as vendorGroupsColor
			FROM signer sn
            LEFT JOIN rating rt on sn.rating = rt.ratingId
            LEFT JOIN rating rtc on sn.clientRating = rtc.ratingId
            , (SELECT @rownum := 0) r
            ',
            whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetTestInfos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetTestInfos`(
IN testName varchar(150),
IN active int,
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
   DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';
    
	IF (active <> 0)
    THEN
		IF(active = 1)
		   THEN SET whereQuery = CONCAT(whereQuery, ' AND active = 1 ');
		ELSE SET whereQuery = CONCAT(whereQuery, ' AND (active IS NULL OR active = 0) ');
        END IF;
	END IF;
    
    IF (testName IS NOT NULL AND testName <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND testName LIKE  ''%', testName, '%''');
	END IF;
   
	SET @querySql= concat('
    SELECT 
    SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			ti.testId,
			ti.testName,
            ti.testDesc,
            ti.defaultTest,
			CASE tp.inActive
			WHEN 0 THEN  ''Y''	
            WHEN NULL THEN ''N''
			ELSE ''N'' END as isProgramActive,
            CASE ti.active
			WHEN 1 THEN  ''Y''										
			ELSE ''N'' END as isActive,
			CASE tp3.isPublished
			WHEN 1 THEN  ''Y''										
			ELSE ''N'' END as published
            FROM test_info ti
            LEFT JOIN training_programs tp ON tp.programId = (
			SELECT tpi.programId
			FROM training_program_test tpi 
            LEFT JOIN training_programs tp2 on tp2.programId=tpi.programId
			WHERE tpi.testId = ti.testId AND (tp2.inActive IS NULL OR tp2.inActive = 0)
			LIMIT 1 )
			LEFT JOIN training_programs tp3 ON tp3.programId = (
			SELECT tpi.programId
			FROM training_program_test tpi 
            LEFT JOIN training_programs tp2 on tp2.programId=tpi.programId
			WHERE tpi.testId = ti.testId AND tp2.isPublished = 1
			LIMIT 1 )
            , (SELECT @rownum := 0) r ',
            whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getTotalVendorPool` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `getTotalVendorPool`(
IN numberOfOrderMoreThan varchar(500),
IN rating varchar(500),
IN categories varchar(500),
IN training varchar(500),
IN clientId int,
IN isCustomer boolean,
In isUseClientPreferred boolean
)
BEGIN
	
    DECLARE whereQuery varchar(5000);  
    DECLARE tableClientName varchar(30);
    DECLARE idFieldClient varchar(30);
    
    set tableClientName = IF(isCustomer, 'customer_preferred_vendor','broker_preferred_vendor');
    set idFieldClient = IF(isCustomer, 'customerId','brokerId');

	
    SET whereQuery = ' WHERE (1=1 ';

    
    IF (rating IS NOT NULL AND rating <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND sn.rating in (', rating,') ');
	END IF;
    
	IF (numberOfOrderMoreThan IS NOT NULL AND numberOfOrderMoreThan <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND (select count(*) from `order` ord 
				where ord.progressId = 8 and ord.signerId = sn.signerId) > ', numberOfOrderMoreThan);
	END IF;
    
    SET whereQuery = CONCAT(whereQuery, ' AND (sn.inActive IS NULL OR sn.inActive = 0)');
    
	IF (categories IS NOT NULL AND categories <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND ( 
				(sn.rating <= (SELECT MIN(vc.minRating) FROM vendor_categories vc WHERE find_in_set(vc.catId,''',categories,'''))) AND
				-- check number of order <= signer complete orders 8 -> closing Completed
				((SELECT Max(vc.minOrder) FROM vendor_categories vc WHERE find_in_set(vc.catId,''',categories,''')) 
				 <= (SELECT COUNT(ord.orderId) FROM `order` ord 
					 WHERE sn.signerId= ord.signerId AND ord.progressId = 8 )) AND
				-- vendor must take required tests
				((SELECT COUNT(vct1.testId) FROM vendor_cat_testtaken vct1 
				 WHERE vct1.catId IN (SELECT catId FROM vendor_categories vc WHERE find_in_set(vc.catId,''',categories,''')))
				 = (SELECT COUNT(vct.testId) FROM vendor_cat_testtaken vct 
					  WHERE vct.catId IN (SELECT catId FROM vendor_categories vc WHERE find_in_set(vc.catId,''',categories,''')) AND
					  vct.testId IN (SELECT vtr.testId FROM vendor_test_result vtr 
				  WHERE vtr.passed = ''Y'' AND vtr.vendorId = sn.signerId))) AND
				-- check number of order <= signer complete orders 8 -> closing Completed and industry order is reverse mortgage
				((SELECT MAX(vc.minRMOrder) FROM vendor_categories vc WHERE find_in_set(vc.catId,''',categories,''')) 
				 <= (SELECT COUNT(ord.orderId) FROM `order` ord left join broker br on br.brokerId = ord.brokerId
					 WHERE sn.signerId= ord.signerId AND ord.progressId = 8 and br.industryId = 2 )
                     OR (SELECT MAX(vc.minRMOrder) FROM vendor_categories vc WHERE find_in_set(vc.catId,''',categories,''')) IS NULL) 
			 )');
	END IF;
 
	IF (training IS NOT NULL AND training <> '')
		THEN SET whereQuery = CONCAT(whereQuery, '
					AND ( SELECT COUNT(sl.ProgramId) from vendor_registered_programs sl 
						WHERE
							FIND_IN_SET(sl.ProgramId, ''',training,''')
							AND sn.signerId = sl.VendorId AND sl.IsComplete = true )  = (LENGTH(''',training,''') - LENGTH(REPLACE(''',training,''', '','', ''''))+1) ');
 
	END IF;
    
    SET whereQuery = CONCAT(whereQuery, '
					) OR ( sn.signerId in (select pv.SignerId from ',tableClientName,' pv where pv.',idFieldClient,' = ',clientId,' and ', isUseClientPreferred ,')) ');
    
	SET @querySql= concat('
     SELECT 
     SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			sn.signerId
			FROM signer sn
            LEFT JOIN rating rt on sn.rating = rt.ratingId
            LEFT JOIN rating rtc on sn.clientRating = rtc.ratingId
            , (SELECT @rownum := 0) r
            ',
            whereQuery, " LIMIT 1,1 ");

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetTrainingCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetTrainingCourses`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN courseName varchar(150),
IN courseStatus varchar(2)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY title ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = CONCAT(' WHERE 1=1');
	IF (courseStatus IS NOT NULL AND courseStatus <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND c.InActive = ', courseStatus);
	END IF;
    IF (courseName IS NOT NULL AND courseName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND c.Title LIKE ''%', courseName, '%''');
	END IF;
	SET @querySql= concat('select SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			c.courseId,
			c.title,
            c.description, 
            c.document as document,
            c.videoFile as videoFile,
            c.InActive,
            IsActiveProgram(c.courseId) as isActiveProgram,
            case when IsPublishedProgram(c.courseId) then ''Y'' else ''N'' end as isPublishedProgram
            FROM training_courses c 
            , (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getTrainingPrograms` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `getTrainingPrograms`(
	IN sortColumn varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN programName varchar(250),
    IN programStatus tinyint
)
BEGIN	
    DECLARE orderQuery varchar(255);
	DECLARE sortDirectionQuery varchar(255);
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(500);
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortColumn IS NULL OR sortColumn = '')
       THEN SET orderQuery = ' ORDER BY Title DESC ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortColumn, sortDirectionQuery);        
    END IF; 
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    SET whereQuery = ' WHERE 1 = 1 ';

	IF (programName IS NULL OR programName <> '' )
    THEN SET whereQuery = CONCAT(whereQuery, ' AND tp.`Title` LIKE ''%', programName, '%''' );
    END IF;
    
    IF( programStatus = 0)
    THEN SET whereQuery = CONCAT(whereQuery, ' AND (tp.`IsPublished` = ', programStatus, ' OR tp.`IsPublished` IS NULL)');
    END IF;
    
    IF( programStatus = 1)
    THEN SET whereQuery = CONCAT(whereQuery, ' AND tp.`IsPublished` = ', programStatus);
    END IF;

	SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* 
    FROM (
		SELECT  tp.`ProgramId` AS `programId`,
				tp.`Title` AS `programName`,
				tp.`Description` AS `description`,
				tp.`ForVendor` AS `forVendor`,
                tp.`ForStaff` AS `forStaff`,
				tp.`IsPublished` AS `isPublished`,
                tp.`Inactive` AS `inactive`,
                ( case when (select count(*) 
                from vendor_test_result vtr where vtr.programId = tp.programId ) > 0 then ''Yes'' else ''No'' end) as isTestTaken,
                ( case when (select count(*) 
                from vendor_courses_result vcr where vcr.programId = tp.programId ) > 0 then ''Yes'' else ''No'' end) as isCourseTaken,
                tp.`AdditionalProgram` as additionalProgram
        FROM `training_programs` tp',
        whereQuery, orderQuery,
        ') AS t1, (SELECT @rownum := 0) r ' ,limitQuery);

	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetUnfilledOrderDashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetUnfilledOrderDashboard`(
	IN pageNumber int,
	IN pageSize int,
    IN role varchar(255),
	IN clientId int
)
BEGIN
    DECLARE limitQuery varchar(255);
    DECLARE andWhereQuery varchar(500);
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    IF (role = 'Client') 
		THEN SET andWhereQuery = CONCAT(' AND (`order`.BrokerId=',clientId,' or `order`.BrokerId in (select Brokerid from `broker` where `broker`.GID = ',clientId, ')) ');
	ELSE IF  (role = 'Branch') 
		THEN SET andWhereQuery = CONCAT(' AND `order`.BrokerId=',clientId);
	ELSE IF (role = 'Agent') 
		THEN SET andWhereQuery = CONCAT(' AND `order`.AgentId=',clientId);
		END IF;
    END IF;
    END IF;
    
	SET @querySqlUnfilledApproaching = CONCAT('SELECT `order`.`OrderId` AS `orderId`,
							CONVERT(TIME_FORMAT(TIMEDIFF(UTC_TIMESTAMP(),`order`.RepAssignDate), "%H : %i"), char(10)) AS `time`
							FROM `order`
                            INNER JOIN zip ON `order`.Zip = `zip`.Zip
                            LEFT JOIN `agent` on `order`.AgentId = `agent`.AgentId 
							LEFT JOIN `broker` on `order`.BrokerId = `broker`.BrokerID
							WHERE `order`.ProgressId = 1
							AND `order`.RepAssignDate IS NOT NULL
                            AND `order`.RepId IS NULL
                            AND `order`.SignerId IS NULL
                            AND `order`.InActive = 0
                            AND UTC_TIMESTAMP() < `order`.AptDateTime - INTERVAL `zip`.UTC HOUR
							AND (`order`.IsSelfService <> 1 AND HOUR(TIMEDIFF(UTC_TIMESTAMP(),`order`.RepAssignDate)) < 2) ', andWhereQuery ,
							' UNION
							SELECT `order`.`OrderId` AS `orderId`,
							CONVERT(TIME_FORMAT(TIMEDIFF(UTC_TIMESTAMP(),`order`.OrderDate), "%H : %i"), char(10)) AS `time`
							FROM `order`
                            INNER JOIN zip ON `order`.Zip = `zip`.Zip
                            LEFT JOIN `agent` on `order`.AgentId = `agent`.AgentId 
							LEFT JOIN `broker` on `order`.BrokerId = `broker`.BrokerID 
							WHERE `order`.ProgressId = 1
                            AND `order`.RepId IS NULL
                            AND `order`.SignerId IS NULL
							AND `order`.OrderDate IS NOT NULL
                            AND `order`.InActive = 0
                            AND UTC_TIMESTAMP() < `order`.AptDateTime - INTERVAL `zip`.UTC HOUR
							AND (`order`.IsSelfService = 1 AND HOUR(TIMEDIFF(UTC_TIMESTAMP(), `order`.OrderDate)) < 2) ', andWhereQuery ,
							' ORDER BY `time` ASC ' ,limitQuery);

	PREPARE stmt FROM @querySqlUnfilledApproaching;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecordsUnfilledApproaching;
    
    SET @querySqlUnfilledOut = CONCAT(' SELECT SQL_CALC_FOUND_ROWS `order`.`OrderId` AS `orderId`,
										CONVERT(TIME_FORMAT(TIMEDIFF(UTC_TIMESTAMP(),`order`.AptDateTime - INTERVAL `zip`.UTC HOUR), "%H : %i"), char(10)) AS `time`
										FROM `order`
                                        INNER JOIN zip ON `order`.Zip = `zip`.Zip
                                        LEFT JOIN `agent` on `order`.AgentId = `agent`.AgentId 
										LEFT JOIN `broker` on `order`.BrokerId = `broker`.BrokerID 
										WHERE `order`.ProgressId = 1
										AND `order`.RepId IS NULL
										AND `order`.SignerId IS NULL
										AND UTC_TIMESTAMP() > `order`.AptDateTime - INTERVAL `zip`.UTC HOUR ', andWhereQuery ,
										' ORDER BY `time` ASC '  ,limitQuery);

	PREPARE stmt FROM @querySqlUnfilledOut;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecordsUnfilledOut;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetUserAdditionalInfoList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetUserAdditionalInfoList`(
	IN `signerIdInput` INT
)
BEGIN
	DECLARE coverageAreasIds varchar(1500);
    DECLARE sqlQuery varchar(255);
    
	SELECT * FROM `loan_type`;
	SELECT * FROM `language`;
	SELECT @row := @row + 1 as Seq, t.*	FROM `state` t, (SELECT @row := 0) r;
    
	SELECT `CoverageArea` INTO coverageAreasIds
	FROM `signer`
	WHERE `SignerId` = signerIdInput;

    IF coverageAreasIds IS NOT NULL AND coverageAreasIds <> ''
    THEN
		
		SET @sqlQuery = CONCAT('SELECT `Zip`, `City`, `AreaCode`
		FROM `zip`
		WHERE `Zip` IN(', coverageAreasIds, ')');
		
		PREPARE stmt FROM @sqlQuery;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
	END IF;
    
    -- SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetUserReadAnnouncements` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetUserReadAnnouncements`(
    IN sortColumn varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN userId int,
    IN fromDate datetime,
	IN toDate datetime,
	IN title varchar(100)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
       
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
	SET orderQuery = CONCAT(' ORDER BY ', sortColumn, sortDirectionQuery);
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    SET whereQuery = ' WHERE uan.Viewed = 1 ';
    IF(fromDate <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND uan.SendDate >= \'', fromDate,'\'');
	END IF;
	IF(toDate <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND uan.SendDate <= \'', toDate,'\'');
	END IF;
	IF(title <> '')
	THEN SET whereQuery = CONCAT(whereQuery, ' AND an.Title like \'%', title,'%\'');
    END IF;


    set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS
							an.AnnouncementID,
							an.Title,
							uan.SendDate,
							uan.Viewed
							FROM announcements AS an
							LEFT JOIN user_announcement uan 
							ON an.AnnouncementID = uan.AnnouncementID 
							AND uan.UserId =  ', userId, whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetUserRolePermissions` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetUserRolePermissions`(
IN user_Id int
)
BEGIN  
	SELECT DISTINCT r.RoleId, r.RoleName, r.Type, r.Description,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 1) THEN 1 ELSE 0 END AS AdditionalServices,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 2) THEN 1 ELSE 0 END AS BonusCalculation,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 3) THEN 1 ELSE 0 END AS BusinessHours,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND 
		CASE r.Type WHEN 'STAFF' THEN rp.PermissionId = 4 ELSE rp.PermissionId = 41 END )  THEN 1 ELSE 0 END AS Chatting,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 5) THEN 1 ELSE 0 END AS ClientFeeRequests,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 6) THEN 1 ELSE 0 END AS ContentManagementSystem,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 7) THEN 1 ELSE 0 END AS Dashboard,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 8) THEN 1 ELSE 0 END AS FAQs,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 9) THEN 1 ELSE 0 END AS Fees,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 10) THEN 1 ELSE 0 END AS Industries,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 11) THEN 1 ELSE 0 END AS Invoices,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND 
		CASE r.Type WHEN 'STAFF' THEN rp.PermissionId = 12 ELSE rp.PermissionId = 47 END ) THEN 1 ELSE 0 END AS Links,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 13) THEN 1 ELSE 0 END AS ManageAccounts,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 14) THEN 1 ELSE 0 END AS ManageClients,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 15) THEN 1 ELSE 0 END AS ManageVendors,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 16) THEN 1 ELSE 0 END AS NotificationManagement,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 17) THEN 1 ELSE 0 END AS ParentIndustries,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND 
		CASE r.Type WHEN 'STAFF' THEN rp.PermissionId = 18 ELSE rp.PermissionId = 52 END ) THEN 1 ELSE 0 END AS PlaceOrder,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 19) THEN 1 ELSE 0 END AS ProblemReporting,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 20) THEN 1 ELSE 0 END AS ProblemSubType,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 21) THEN 1 ELSE 0 END AS ProblemType,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 22) THEN 1 ELSE 0 END AS ProductTypes,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND 
		CASE r.Type WHEN 'STAFF' THEN rp.PermissionId = 23 ELSE rp.PermissionId = 54 END ) THEN 1 ELSE 0 END AS ProfileAndSettings,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 24) THEN 1 ELSE 0 END AS QBClientCheckExport,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 25) THEN 1 ELSE 0 END AS QBClientExport,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 26) THEN 1 ELSE 0 END AS QBClientInvoiceExport,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 27) THEN 1 ELSE 0 END AS QBVendorBillExport,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 28) THEN 1 ELSE 0 END AS QBVendorCheckExport,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 29) THEN 1 ELSE 0 END AS QBVendorExport,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 30) THEN 1 ELSE 0 END AS Reports,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND 
		CASE r.Type WHEN 'STAFF' THEN rp.PermissionId = 31 ELSE rp.PermissionId = 56 END ) THEN 1 ELSE 0 END AS Resources,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND 
		CASE r.Type WHEN 'STAFF' THEN rp.PermissionId = 32 ELSE rp.PermissionId = 57 END ) THEN 1 ELSE 0 END AS RoleAndPermission,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 33) THEN 1 ELSE 0 END AS ServiceConfigurationApproval,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 34) THEN 1 ELSE 0 END AS TrainingAndTesting,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 35) THEN 1 ELSE 0 END AS VendorClassificationSettings,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 36) THEN 1 ELSE 0 END AS VendorCredentialDocuments,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 37) THEN 1 ELSE 0 END AS VendorFeeRequests,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND
		CASE r.Type WHEN 'STAFF' THEN rp.PermissionId = 38 ELSE rp.PermissionId = 62 END ) THEN 1 ELSE 0 END AS VendorRatingSettings,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 39) THEN 1 ELSE 0 END AS VendorRequests,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND
		CASE r.Type WHEN 'STAFF' THEN rp.PermissionId = 40 ELSE rp.PermissionId = 63 END ) THEN 1 ELSE 0 END AS ViewOrders,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 42) THEN 1 ELSE 0 END AS ClientDashboard,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 43) THEN 1 ELSE 0 END AS ClientRegistration,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 44) THEN 1 ELSE 0 END AS DocumentManagement,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 45) THEN 1 ELSE 0 END AS FAQ,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 46) THEN 1 ELSE 0 END AS FeeVendorApproval,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 48) THEN 1 ELSE 0 END AS ManageAgents,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 49) THEN 1 ELSE 0 END AS ManageBranches,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 50) THEN 1 ELSE 0 END AS ManageCustomers,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 51) THEN 1 ELSE 0 END AS OrderAssignmentConfiguration,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 53) THEN 1 ELSE 0 END AS Problems,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 55) THEN 1 ELSE 0 END AS Reporting,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 58) THEN 1 ELSE 0 END AS ServiceConfiguration,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 59) THEN 1 ELSE 0 END AS SLAConfiguration,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 60) THEN 1 ELSE 0 END AS VendorDonotUse,
		CASE WHEN EXISTS (SELECT rp.PermissionId FROM role_permissions rp WHERE rp.RoleId = r.RoleId AND rp.PermissionId = 61) THEN 1 ELSE 0 END AS VendorFeeConfiguration
	FROM `permissions` p
		INNER JOIN role_permissions rp1 ON p.PermissionId = rp1.PermissionId
		RIGHT JOIN roles r ON r.RoleId = rp1.RoleId
		INNER JOIN user_roles ur ON ur.RoleId = r.RoleId
	WHERE ur.UsersId = user_Id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetUserRoles` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetUserRoles`(IN userId int)
BEGIN
	SELECT DISTINCT rp.RoleId, rp.RoleName, rp.Type, rp.Description FROM user_roles ur
	JOIN roles rp ON ur.RoleId = rp.RoleId
	WHERE ur.UsersId = userId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetUsersByRepId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetUsersByRepId`(	
	IN repId int(11)
)
BEGIN
    DECLARE whereQuery varchar(255);
	
    SET whereQuery = ' WHERE 1=1 and Type like "Staff" ';
     
	IF(repId IS NOT NULL AND repID >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `RepId` = ', repId);
	END IF;
     
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from ( select distinct `employees`.RepId as `RepId`,
									`employees`.FirstName as `FirstName`,
									`employees`.Email as `Email`,
                                    `employees`.LastName as `LastName`,
                                    `employees`.Fax as `Fax`,
                                     `employees`.MaxNumOrders as `MaxNumOrders`,
                                    `employees`.Ext as `Ext`,
                                    `employees`.Active as `Active`,
                                    `employees`.SRepOrder as `SRepOrder`,
                                    `user_roles`.RoleId as `RoleId`,
                                    `roles`.RoleName as `RoleName`,
                                    `roles`.Type as `Type`,
                                    `users`.UsersId as `UsersId`
							FROM `employees`  
                            LEFT JOIN `users` on `employees`.RepId = `users`.MappingUserId
                            LEFT JOIN `user_roles` on `users`.UsersId = `user_roles`.UsersId   
							LEFT JOIN `roles` on `user_roles`.RoleId = `roles`.RoleId) t1, (SELECT @rownum := 0) r', whereQuery );


    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetUserUnreadAnnouncements` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetUserUnreadAnnouncements`(
    IN sortColumn varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN userId int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
       
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
	SET orderQuery = CONCAT(' ORDER BY ', sortColumn, sortDirectionQuery);
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

    set @querySql = CONCAT('SELECT 
								SQL_CALC_FOUND_ROWS
								an.AnnouncementID,
								an.Title,
								an.Content,
								an.PublishedDate AS SendDate,
								uan.Viewed
							FROM announcements AS an
							INNER JOIN
							(SELECT CASE
										WHEN rp.RoleId = 1 THEN "TCE Admins/Managers"
										WHEN rp.RoleId = 2 THEN "TCE Admins/Managers"
										WHEN rp.RoleId = 3 THEN "TCE Agents"
										WHEN rp.RoleId = 4 THEN "TCE Agents"
										WHEN rp.RoleId = 5 THEN "Client Admins/Managers"
										WHEN rp.RoleId = 6 THEN "Client Admins/Managers"
										WHEN rp.RoleId = 7 THEN "Client Agents"
										WHEN rp.RoleId = 8 THEN "Vendors"
										WHEN rp.RoleId = 9 THEN "TCE Admins/Managers"
										WHEN rp.RoleId = 10 THEN "TCE Admins/Managers"
										WHEN rp.RoleId = 11 THEN "TCE Admins/Managers"
										WHEN rp.RoleId = 12 THEN "TCE Agents"
									END as Audience,
								u.UsersId as UsersId
							FROM users u 
							INNER JOIN user_roles ur ON u.UsersId = ur.UsersId
							INNER JOIN roles rp ON ur.RoleId = rp.RoleId
							WHERE u.UsersId = ',userId,' ) AS userRole ON an.Audience = userRole.Audience
							LEFT JOIN user_announcement AS uan ON an.AnnouncementID = uan.AnnouncementID AND uan.UserId = ',userId,'
							 WHERE (uan.Viewed = 0 OR uan.Viewed IS NULL) AND Status = \'Published\' ', orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorAnnouncements` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorAnnouncements`(
    IN sortColumn varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN signerId int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
       
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
	SET orderQuery = CONCAT(' ORDER BY ', sortColumn, sortDirectionQuery);
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

    set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS
							an.AnnouncementID,
							an.Title,
							an.Content,
							an.PublishedDate AS SendDate,
							uan.Viewed
							FROM announcements AS an
							LEFT JOIN user_announcement uan 
							ON an.AnnouncementID = uan.AnnouncementID 
							AND uan.UserId = (SELECT u.UsersId AS UserId FROM users u 
												INNER JOIN signer s ON u.MappingUserId = s.SignerId
												INNER JOIN user_roles ur ON u.UsersId = ur.UsersId
												INNER JOIN roles rp ON ur.RoleId = rp.RoleId AND ur.RoleId = 8
												WHERE s.SignerId = ',signerId,') 
                            WHERE an.Audience = \'Vendors\' AND Status = \'Published\'', orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorBillQuickBook` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorBillQuickBook`(
IN fromDate DateTime,
IN toDate DateTime,
IN signers VARCHAR(5000)
)
BEGIN
	
	SELECT   concat(sn.firstName, '' '', sn.lastName) as Vendor,
    ord.closedDate as `Transaction Date`, ord.orderId as RefNumber,
    DATE_ADD(ord.ClosedDate, INTERVAL 30 DAY) as `Bill Due`,
    "Net 30" as Term, ord.lastName as Memo, 
    concat(sn.firstName, '' '', sn.lastName) as `Address Line 1`,
    sn.weekdayStreet as `Address Line 2`,
    '' as `Address Line 3`,
    '' as `Address Line 4`,
    sn.weekdayCity as `Address City`,
    sn.weekdayState as `Address State`,
    sn.weekdayZip as `Address PostalCode`,
    'USA' as `Address Country`,
    sn.taxID as `Vendor Acct No`,
	concat('Notary - ',bf.feeDescription) as  `Expenses Account`,
    of.signerFee as `Expenses Amount`,
    '' as `Expenses Memo`, '' as `Expenses Class`,
    br.company as `Expenses Customer`, 'Y' as `Expenses Billable`,
    '' as `Items Item`, '' as `Items Qty`, '' as `Items Description`,
    '' as `Items Cost`, '' as `Items Class`, '' as `Items Customer`,
    '' as `Items Billable`, '' as `AP Account`
	FROM `order` ord
	LEFT JOIN signer sn on ord.signerId = sn.signerId
	LEFT JOIN order_fee of on of.orderID = ord.orderId
    LEFT JOIN broker_fee bf on bf.feeId = of.feeDescripID
    LEFT JOIN broker br on br.brokerId = ord.brokerId
    WHERE ord.progressId = 8 AND of.signerFee>0 AND ord.closedDate >= fromDate AND ord.closedDate < DATE_ADD(toDate, INTERVAL 1 DAY)
      AND ((signers = '' or signers is null) OR find_in_set(sn.signerId,signers))
    ORDER BY sn.signerId, ord.closedDate, ord.orderId;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorCheckQuickBookSPL` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorCheckQuickBookSPL`(
IN orderId INT
)
BEGIN
	
	SELECT  'SPL' as `!SPL`, ord.orderId as `SPLID`, 'CHECK' as `TRNSTYPE`, ord.closedDate as `DATE`, 
    bf.feeDescription as `ACCNT`, '' as `NAME`, 'new class' as `CLASS`, 
    CONCAT(ROUND(of.signerFee,2)) as `AMOUNT`, ord.orderId as `DOCNUM`,
	CONCAT(ord.firstName,' ',ord.lastName, '; ',ord.address,', ',ord.city,' ',ord.state,', ', ord.zip) as `MEMO`,
    'N' as `CLEAR`, '' as `QNTY`, ROUND((SELECT SUM(of2.signerFee) FROM order_fee of2 WHERE of2.orderId = ord.orderId),2) as `PRICE`,
    bf.feeDescription as `REIMBEXP`, 'N' as `TAXABLE`, '' as `OTHER2`, '0' as `YEARTODATE`, '0' as `WAGEBASE`
	FROM `order` ord
	LEFT JOIN order_fee of on of.orderID = ord.orderId
    LEFT JOIN broker_fee bf on bf.feeId = of.feeDescripID
    LEFT JOIN broker br on br.brokerId = ord.brokerId
    WHERE ord.orderId = orderId AND ord.progressId = 8
    ORDER BY bf.feeId, of.feeId;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorCheckQuickBookTRNS` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorCheckQuickBookTRNS`(
IN fromDate DateTime,
IN toDate DateTime,
IN signers VARCHAR(5000)
)
BEGIN
	
	SELECT  `!TRNS`, group_concat( `TRNSID` SEPARATOR ', ') as `TRNSID`, `TRNSTYPE`,  `DATE`, `ACCNT`, `NAME`, `CLASS`, 
SUM(`AMOUNT`) as `AMOUNT`, group_concat(`DOCNUM` SEPARATOR ', ') as `DOCNUM`,`MEMO`, 
    `CLEAR`, `TOPRINT`, `NAMEISTAXABLE`, `ADDR1`,`ADDR2`, `ADDR3`, `TERM`, `SHIPVIA`, `SHIPDATE`, 
    group_concat( `PONUM` SEPARATOR ', ') as `PONUM`
FROM (
SELECT  'TRNS' as `!TRNS`, ord.orderId as `TRNSID`, 'CHECK' as `TRNSTYPE`, UTC_TIMESTAMP() as `DATE`,
    'Cash - CT&S Chase Checking' as `ACCNT`, concat(sn.firstName, '' '', sn.lastName) as `NAME`, '' as `CLASS`, 
    ROUND((SELECT SUM(of.signerFee) FROM order_fee of WHERE of.orderId = ord.orderId),2) as `AMOUNT`, ord.orderId as `DOCNUM`,
	'Orders: Please see check stub' as `MEMO`, 'N' as `CLEAR`, 'Y' as `TOPRINT`,
    'N' as `NAMEISTAXABLE`,  concat(sn.firstName, '' '', sn.lastName) as `ADDR1`, sn.weekdayStreet as `ADDR2`, 
    CONCAT(sn.weekdayCity,', ',sn.weekdayState,' ', sn.weekdayZip) as `ADDR3`, 'NET 15' as `TERM`,
    '' as `SHIPVIA`,  UTC_TIMESTAMP() as `SHIPDATE`, ord.brokerIdNum as `PONUM`
	FROM `order` ord
    LEFT JOIN signer sn on sn.signerId = ord.signerId
    WHERE ord.progressId = 8 AND ord.closedDate >= fromDate AND ord.closedDate < DATE_ADD(toDate, INTERVAL 1 DAY)
    AND ((signers = '' or signers is null) OR find_in_set(sn.signerId,signers))
    ORDER BY ord.signerId,ord.closedDate) tx
GROUP BY  `!TRNS`, `TRNSTYPE`,  `DATE`, `ACCNT`, `NAME`, `CLASS`,
    `CLEAR`, `TOPRINT`, `NAMEISTAXABLE`, `ADDR1`,`ADDR2`, `ADDR3`, `TERM`, `SHIPVIA`, `SHIPDATE`;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorManagement` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorManagement`(
    IN state varchar(255),
    IN vendorName varchar(255),
    IN city varchar(255),
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY SignerId ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE 1=1 ');
    
    IF (state IS NOT NULL AND state <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `State` LIKE ''%', state, '%''');
	END IF;
    
    IF (vendorName IS NOT NULL AND vendorName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND VendorName LIKE ''%', vendorName, '%''');
	END IF;
    
    IF(city IS NOT NULL AND city <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND City LIKE ''%', city, '%''');
	END IF;
    
    set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from (select distinct 
									s.SignerId as `VendorID`,
									CONCAT(s.FirstName," ",s.LastName) as `VendorName`,
                                    s.WeekdayCity as `City`,
                                    s.WeekdayState as `State`,
                                    s.Email as `Email`,
                                    s.WorkPhone as `WorkPhone`,
									s.Fax as `Fax`,
                                    u.UserName as `UserName`
							FROM signer s, users u, user_roles ur WHERE s.SignerId = u.MappingUserId and u.UsersId = ur.UsersId and ur.RoleId = 8 and s.InActive = 1
                            ) t1, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorNotifications` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorNotifications`(
	IN sortColumn varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN signerId int
)
BEGIN 
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
	SET orderQuery = CONCAT(' ORDER BY ', sortColumn, sortDirectionQuery);

    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE sns.SignerId = ',signerId);
    
    set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS
							sn.NotifDesc, sn.NotifTemplate,sns.NotifDate
							FROM  signer_notifications AS sn
							INNER JOIN signer_notify_sent AS sns ON sn.NotifID = sns.NotifID ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorOffer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorOffer`(
	IN signerId int,
	IN sortColumn varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN orderID int,
    IN daysBack int,
    IN offerStatus varchar(3)
)
BEGIN	
    DECLARE orderQuery varchar(255);
	DECLARE sortDirectionQuery varchar(255);
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortColumn IS NULL OR sortColumn = '')
       THEN SET orderQuery = ' ORDER BY FIELD(`signer_offer`.`OfferStatus`, \'P\',null,\'O\',\'A\', \'D\',\'E\',\'M\'), `SentDate` DESC ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortColumn, sortDirectionQuery);        
    END IF; 
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

	CASE daysBack
	  WHEN 365 THEN SET whereQuery = CONCAT(' WHERE `signer_offer`.`SentDate` >= UTC_TIMESTAMP() - INTERVAL ', '1 YEAR');
	  WHEN 730 THEN SET whereQuery = CONCAT(' WHERE `signer_offer`.`SentDate` >= UTC_TIMESTAMP() - INTERVAL ', '2 YEAR');
	  ELSE SET whereQuery = CONCAT(' WHERE `signer_offer`.`SentDate` >= UTC_TIMESTAMP() - INTERVAL ', daysBack, ' DAY');
	END CASE;
        
	IF (orderID <> 0 )
    THEN SET whereQuery = CONCAT(whereQuery, ' AND `signer_offer`.`OrderID` = ', orderID);
    END IF;
    
    IF( offerStatus <> '0')
    THEN IF(offerStatus = 'O') THEN SET whereQuery = CONCAT(whereQuery, ' AND (`signer_offer`.`OfferStatus` = \'', offerStatus, '\' OR `signer_offer`.`OfferStatus` IS NULL) ');
		 ELSE SET whereQuery = CONCAT(whereQuery, ' AND `signer_offer`.`OfferStatus` = \'', offerStatus, '\' ');
         END IF;
    END IF;

    SET whereQuery = CONCAT(whereQuery, ' AND `signer_offer`.`SignerId` = ', signerId);
    
	SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* 
    FROM (
		SELECT 	`signer_offer`.`OfferID` AS `OfferID`,
				`signer_offer`.`OrderID` AS `OrderID`,
                `signer_offer`.`SentDate` AS `SentDate`,
                `employees`.`Email` AS `EmployeesEmail`,
				`loan_type`.`LoanType` AS `LoanType`,
				`order`.`AptDateTime` AS `AptDateTime`,
				`order`.`City` AS `City`,
				`order`.`Zip` AS `Zip`,
                `order`.`BrokerIdNum` AS `BrokerIdNum`,
                `order`.`LastName` AS `BorrowerLastName`,
                 69.1*sqrt(POWER((`signer`.`Lat` - `order`.`Lat`), 2) + 0.6*POWER((`signer`.`Long` - `order`.`Long`), 2)) AS `distance`,
				`signer`.`Lat` AS vendorLat,
				`signer`.`Long` AS vendorLong,
				`order`.`Lat` AS orderLat,
				`order`.`Long` AS orderLong,
				`signer`.`Mobile` AS `VendorMobile`,
				`signer`.`Email` AS `VendorEmail`,
				`signer`.`FirstName` AS `VendorFirstName`,
				`signer`.`LastName` AS `VendorLastName`,
                `agent`.`Email` AS `AgentEmail`,
                `agent`.`FullName` AS `AgentFullName`,
                `signer_offer`.`OfferAmount` AS `OfferAmount`,
				`signer_offer`.`OfferStatus` AS `OfferStatus`,
                `bilingual`.`FeeDescription` AS `Bilingual`,
                `scanbacks`.`FeeDescription` AS `Scanbacks`
        FROM `signer_offer`
		INNER JOIN `order` ON `signer_offer`.`OrderID` = `order`.`OrderID`
        INNER JOIN `loan_type` ON `order`.`LoanType` = `loan_type`.`LoanTypeID`
		INNER JOIN `signer` ON `signer_offer`.`SignerId` = `signer`.`SignerId`
        LEFT JOIN `employees` ON `signer_offer`.`RepId` = `employees`.`RepId`
        LEFT JOIN `agent` ON `order`.`AgentId` = `agent`.`AgentId`
        LEFT JOIN (SELECT `broker_fee`.`FeeId` , `broker_fee`.`FeeDescription`, `order_fee`.`OrderID` FROM `broker_fee` 
				   INNER JOIN `order_fee` ON `order_fee`.`FeeDescripID` =  `broker_fee`.`FeeId` 
                   WHERE `broker_fee`.`FeeDescription` = \'Bi-Lingual Vendor\') AS `bilingual` ON `signer_offer`.`OrderID` =  `bilingual`.`OrderID`
        LEFT JOIN (SELECT `broker_fee`.`FeeId` , `broker_fee`.`FeeDescription`,`order_fee`.`OrderID` FROM `broker_fee` 
				   INNER JOIN `order_fee` ON `order_fee`.`FeeDescripID` =  `broker_fee`.`FeeId` 
                   WHERE `broker_fee`.`FeeDescription` = \'Scan backs\') AS `scanbacks` ON `signer_offer`.`OrderID` =  `scanbacks`.`OrderID` ',
        whereQuery, orderQuery,
        ') AS t1, (SELECT @rownum := 0) r ' ,limitQuery);

	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorOfferByGUID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorOfferByGUID`(
	IN paramGUID char(36) 
)
BEGIN	
    DECLARE whereQuery varchar(255);

    SET whereQuery = CONCAT('WHERE `signer_offer`.`GUID` = \'', paramGUID, '\'');
    
	SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* 
    FROM (
		SELECT 	`signer_offer`.`OfferID` AS `OfferID`,
				`signer_offer`.`OrderID` AS `OrderID`,
                `signer_offer`.`SentDate` AS `SentDate`,
                `employees`.`Email` AS `EmployeesEmail`,
				`loan_type`.`LoanType` AS `LoanType`,
				`order`.`AptDateTime` AS `AptDateTime`,
				`order`.`City` AS `City`,
				`order`.`Zip` AS `Zip`,
                `order`.`BrokerIdNum` AS `BrokerIdNum`,
                `order`.`LastName` AS `BorrowerLastName`,
                 69.1*sqrt(POWER((`signer`.`Lat` - `order`.`Lat`), 2) + 0.6*POWER((`signer`.`Long` - `order`.`Long`), 2)) AS `distance`,
				`signer`.`Lat` AS vendorLat,
				`signer`.`Long` AS vendorLong,
				`order`.`Lat` AS orderLat,
				`order`.`Long` AS orderLong,
				`signer`.`Mobile` AS `VendorMobile`,
				`signer`.`Email` AS `VendorEmail`,
				`signer`.`FirstName` AS `VendorFirstName`,
				`signer`.`LastName` AS `VendorLastName`,
                `agent`.`Email` AS `AgentEmail`,
                `agent`.`FullName` AS `AgentFullName`,
                `signer_offer`.`OfferAmount` AS `OfferAmount`,
				`signer_offer`.`OfferStatus` AS `OfferStatus`,
                `bilingual`.`FeeDescription` AS `Bilingual`,
                `scanbacks`.`FeeDescription` AS `Scanbacks`
        FROM `signer_offer`
		INNER JOIN `order` ON `signer_offer`.`OrderID` = `order`.`OrderID`
        INNER JOIN `loan_type` ON `order`.`LoanType` = `loan_type`.`LoanTypeID`
		INNER JOIN `signer` ON `signer_offer`.`SignerId` = `signer`.`SignerId`
        LEFT JOIN `employees` ON `signer_offer`.`RepId` = `employees`.`RepId`
        LEFT JOIN `agent` ON `order`.`AgentId` = `agent`.`AgentId`
        LEFT JOIN (SELECT `broker_fee`.`FeeId` , `broker_fee`.`FeeDescription`, `order_fee`.`OrderID` FROM `broker_fee` 
				   INNER JOIN `order_fee` ON `order_fee`.`FeeDescripID` =  `broker_fee`.`FeeId` 
                   WHERE `broker_fee`.`FeeDescription` = \'Bi-Lingual Vendor\') AS `bilingual` ON `signer_offer`.`OrderID` =  `bilingual`.`OrderID`
        LEFT JOIN (SELECT `broker_fee`.`FeeId` , `broker_fee`.`FeeDescription`,`order_fee`.`OrderID` FROM `broker_fee` 
				   INNER JOIN `order_fee` ON `order_fee`.`FeeDescripID` =  `broker_fee`.`FeeId` 
                   WHERE `broker_fee`.`FeeDescription` = \'Scan backs\') AS `scanbacks` ON `signer_offer`.`OrderID` =  `scanbacks`.`OrderID` ',
        whereQuery,
        ') AS t1, (SELECT @rownum := 0) r ');
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorOrderProblem` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorOrderProblem`(
	IN sortColumn varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN signerId int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortColumn IS NULL OR sortColumn = '')
       THEN SET orderQuery = ' ORDER BY `order_problem`.`ProblemId` DESC';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortColumn, sortDirectionQuery);        
    END IF; 
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE `order_problem`.SignerId = ',signerId, ' AND `order_problem`.`Date` >= UTC_TIMESTAMP() - INTERVAL 3 YEAR ');
    
    set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS
								ProblemId,
								problem_types.Description AS Type,
								Acknowledged,
								AcknowledgedDate,
								users.UserName
							FROM order_problem
                            INNER JOIN problem_types ON order_problem.Type = problem_types.Id
                            INNER JOIN users ON users.UsersId = order_problem.EnteredBy', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorOrders` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorOrders`(
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN orderId int,
    IN firstName varchar(255),
    IN lastName varchar(255),
    IN fileNumber varchar(255),
    IN statusOrder int,
    IN daySelected int,
    IN userId int,
    IN active boolean
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(21000);  
    
    IF (sortDirection = true) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = CONCAT(' ORDER BY `OrderId`', sortDirectionQuery);
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
    
    IF (pageNumber IS NULL OR pageNumber = '') THEN SET pageNumber = 1; END IF;
    IF (pageSize IS NULL OR pageSize = '') THEN SET pageSize = 25; END IF;
	
    SET whereQuery = 'and 1=1';
    SET whereQuery = CONCAT(whereQuery, ' AND u.UsersId=', userId);
    
    IF (orderId IS NOT NULL)
        THEN SET whereQuery = CONCAT(whereQuery, ' AND o.OrderId=', orderId);
    END IF;

    IF (firstName IS NOT NULL AND firstName <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND o.FirstName LIKE ''%', firstName, '%''');
    END IF;

    IF (lastName IS NOT NULL AND lastName <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND o.LastName LIKE ''%', lastName, '%''');
    END IF;
    
    IF (fileNumber IS NOT NULL AND fileNumber <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND o.BrokerIdNum LIKE ''%', fileNumber, '%''');
    END IF;

    IF (statusOrder IS NOT NULL)
        THEN SET whereQuery = CONCAT(whereQuery, ' AND o.ProgressId=', statusOrder);
    END IF;

    CASE daySelected
	  WHEN 365 THEN SET whereQuery = CONCAT(whereQuery, ' and OrderDate >= UTC_TIMESTAMP() - INTERVAL ', '1 YEAR');
      WHEN 730 THEN SET whereQuery = CONCAT(whereQuery, ' and OrderDate >= UTC_TIMESTAMP() - INTERVAL ', '2 YEAR');
	  ELSE SET whereQuery = CONCAT(whereQuery, ' and OrderDate >= UTC_TIMESTAMP() - INTERVAL ', daySelected, ' DAY');
	END CASE;
    
    IF(active)
		THEN SET whereQuery = CONCAT(whereQuery, ' AND o.ProgressId NOT IN (8, 10, 11)');
	END IF;   

    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS
							OrderId, AptDateTime, AptUTC, FirstName, LastName, ProgressId, OrderDate
							from ((`order` o
							left join users u on u.MappingUserId = o.SignerId) 
							left join user_roles ur on ur.UsersId = u.UsersId) where ur.RoleId in(8)',whereQuery, orderQuery, limitQuery);
	
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

SELECT FOUND_ROWS() AS TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorQuickBookSPL` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorQuickBookSPL`(
IN orderId INT
)
BEGIN
	
	SELECT  'SPL' as `!SPL`, ord.orderId as `SPLID`, 'CHECK' as `TRNSTYPE`, ord.closedDate as `DATE`, 
    CONCAT('Notary Exp: ', bf.feeDescription) as `ACCNT`, '' as `NAME`, 'new class' as `CLASS`, 
    CONCAT(ROUND(of.signerFee,2)) as `AMOUNT`, ord.orderId as `DOCNUM`,
	CONCAT(ord.firstName,' ',ord.lastName, '; ',ord.address,', ',ord.city,' ',ord.state,', ', ord.zip) as `MEMO`,
    'N' as `CLEAR`, '' as `QNTY`, ROUND((SELECT SUM(of2.signerFee) FROM order_fee of2 WHERE of2.orderId = ord.orderId),2) as `PRICE`,
    'Nothing' as `REIMBEXP`, 'N' as `TAXABLE`, '' as `OTHER2`, '0' as `YEARTODATE`, '0' as `WAGEBASE`
	FROM `order` ord
	LEFT JOIN order_fee of on of.orderID = ord.orderId
    LEFT JOIN broker_fee bf on bf.feeId = of.feeDescripID
    LEFT JOIN broker br on br.brokerId = ord.brokerId
    WHERE ord.orderId = orderId AND ord.progressId = 8
    ORDER BY bf.feeId, of.feeId;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorQuickBookTRNS` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorQuickBookTRNS`(
IN fromDate DateTime,
IN toDate DateTime,
IN signers VARCHAR(5000)
)
BEGIN
	SELECT  `!TRNS`, group_concat( `TRNSID` SEPARATOR ', ') as `TRNSID`, `TRNSTYPE`,  `DATE`, `ACCNT`, `NAME`, `CLASS`, 
SUM(`AMOUNT`) as `AMOUNT`, group_concat(`DOCNUM` SEPARATOR ', ') as `DOCNUM`,
concat('Orders: ',group_concat(`MEMO` SEPARATOR ', ')) as `MEMO`, 
    `CLEAR`, `TOPRINT`, `NAMEISTAXABLE`, `ADDR1`,`ADDR2`, `ADDR3`, `TERM`, `SHIPVIA`, `SHIPDATE`, 
    group_concat( `PONUM` SEPARATOR ', ') as `PONUM`
FROM (
SELECT  'TRNS' as `!TRNS`, ord.orderId as `TRNSID`, 'CHECK' as `TRNSTYPE`, UTC_TIMESTAMP() as `DATE`,
    'Wells Fargo' as `ACCNT`, concat(sn.firstName, '' '', sn.lastName) as `NAME`, '' as `CLASS`, 
    ROUND((SELECT SUM(of.signerFee) FROM order_fee of WHERE of.orderId = ord.orderId),2) as `AMOUNT`, ord.orderId as `DOCNUM`,
	ord.orderId as `MEMO`, 'N' as `CLEAR`, 'N' as `TOPRINT`,
    'N' as `NAMEISTAXABLE`,  concat(sn.firstName, '' '', sn.lastName) as `ADDR1`, sn.weekdayStreet as `ADDR2`, 
    CONCAT(sn.weekdayCity,', ',sn.weekdayState,' ', sn.weekdayZip) as `ADDR3`, 'NET 15' as `TERM`,
    '' as `SHIPVIA`,  UTC_TIMESTAMP() as `SHIPDATE`, ord.brokerIdNum as `PONUM`
	FROM `order` ord
    LEFT JOIN signer sn on sn.signerId = ord.signerId
    WHERE ord.progressId = 8 AND ord.closedDate >= fromDate AND ord.closedDate < DATE_ADD(toDate, INTERVAL 1 DAY)
    AND ((signers = '' or signers is null) OR find_in_set(sn.signerId,signers))
    ORDER BY ord.signerId,ord.closedDate) tx
GROUP BY  `!TRNS`, `TRNSTYPE`,  `DATE`, `ACCNT`, `NAME`, `CLASS`,
    `CLEAR`, `TOPRINT`, `NAMEISTAXABLE`, `ADDR1`,`ADDR2`, `ADDR3`, `TERM`, `SHIPVIA`, `SHIPDATE`;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetVendorRegisterPrograms` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetVendorRegisterPrograms`(
	IN pageNumber int,
	IN pageSize int,
    IN signerId int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
       
	SET orderQuery = ' ORDER BY ProgramName '; 
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE `vendor_registered_programs`.VendorId = ',signerId);
    
    set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS
								training_programs.ProgramId AS ProgramId,
								training_programs.Title AS ProgramName,
								training_programs.Description AS Description,
								vendor_registered_programs.IsComplete AS Status,
								vendor_registered_programs.CompletedDate AS CompletedDate
							FROM vendor_registered_programs
							INNER JOIN training_programs on vendor_registered_programs.ProgramId = vendor_registered_programs.ProgramId ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InitSearchOrdersClient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `InitSearchOrdersClient`()
BEGIN
	set @queryBranch = 'SELECT BrokerID, Company FROM broker order by Company ASC';
    set @queryStatus = 'SELECT ProgressId, ProgressDescription FROM progress order by ProgressId ASC';
    
    PREPARE stmtInit FROM @queryBranch;
	EXECUTE stmtInit;
	DEALLOCATE PREPARE stmtInit;
	PREPARE stmtInit FROM @queryStatus;
	EXECUTE stmtInit;
	DEALLOCATE PREPARE stmtInit;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mobileGetOffers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `mobileGetOffers`(
IN orderId int,
IN signerId int,
IN daysBack int,
IN offerStatus varchar(255),
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY orderId ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';

    IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND orderId LIKE  ''%', orderId, '%''');
	END IF;
    
    IF (signerId IS NOT NULL AND signerId <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND signerId = ', signerId, '');
	END IF;
    
	IF (offerStatus IS NOT NULL AND offerStatus <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND offerStatus =  ''', offerStatus, '''');
	END IF;
    
    IF (daysBack IS NOT NULL AND daysBack <> '')
		THEN
			CASE daysBack
			  WHEN 365 THEN SET whereQuery = CONCAT(whereQuery, ' AND sentDate >= UTC_TIMESTAMP() - INTERVAL ', '1 YEAR');
			  WHEN 730 THEN SET whereQuery = CONCAT(whereQuery, ' AND sentDate >= UTC_TIMESTAMP() - INTERVAL ', '2 YEAR');
			  ELSE SET whereQuery = CONCAT(whereQuery, ' AND sentDate >= UTC_TIMESTAMP() - INTERVAL ', daysBack, ' DAY');
			END CASE;
    END IF;
   
	SET @querySql= concat('
   SELECT offerStatus,signerId,loanType,suite,orderId,state,city,homePhone,
		  zip,address,aptDatetime,distance,offerAmount,sentDate,`status`,progressId,offerId,aptUtc
   FROM ( 		SELECT 		
			''O'' as offerStatus,
            so.signerId,
			lt.loanType,
            o.suite,
            o.orderId,
            o.city,
            o.state,
            o.zip,
            o.address,
            o.aptDatetime,
            so.distance,
            so.offerAmount,
            so.sentDate,
            so.offerStatus as status,
            null as progressId,
            so.offerId,
            z.utc as aptUtc,
            o.homePhone
            FROM signer_offer so
            LEFT JOIN `order` o ON o.orderId = so.orderId
            LEFT JOIN loan_type lt on lt.loanTypeId = o.loanType 
            LEFT JOIN zip z on  z.zip = o.zip
	UNION 
			SELECT 	
            ''A'' as offerStatus,
            o.signerId,
			lt.loanType,
            o.suite,
            o.orderId,
            o.city,
            o.state,
            o.zip,
            o.address,
            o.aptDatetime,
            (69.1*sqrt(power(o.lat-sn.lat,2)+0.6*power(o.`long`-sn.`long`,2))),
			of.offerAmount,
            o.orderDate as sentDate,
            null as status,
            o.progressId,
            null as offerId,
            z.utc as aptUtc,
            o.homePhone
            FROM `order` o
            LEFT JOIN loan_type lt on lt.loanTypeId = o.loanType 
            LEFT JOIN (SELECT SUM(signerFee) as offerAmount,of.orderId FROM order_fee of GROUP BY of.orderId) of 
						ON of.orderId=o.orderId
			LEFT JOIN zip z on  z.zip = o.zip
            LEFT JOIN signer sn on sn.signerId = o.signerId) tx ',
            whereQuery, orderQuery, limitQuery);
	
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TestBusinessHours` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `TestBusinessHours`(
IN startDateTime DATETIME, 
IN endDateTime DATETIME, 
IN timeZone INT,
IN workStartTime TIME,
IN workEndTime TIME
)
BEGIN
	
    DECLARE startDateTimeLocal DATETIME;
    DECLARE endDateTimeLocal DATETIME;
    DECLARE startDate DATE;
    DECLARE endDate DATE;
    DECLARE startTime TIME;
    DECLARE endTime TIME;
    DECLARE dailyWorkingTime INT;

    DECLARE totalMinutes INT;
    
    DECLARE currentDate DATE;
    
    SET startDateTimeLocal = DATE_SUB(startDateTime, INTERVAL timeZone HOUR);
    SET endDateTimeLocal = DATE_SUB(endDateTime, INTERVAL timeZone HOUR);
    
    SET startDate= DATE(startDateTimeLocal);
    SET endDate = DATE(endDateTimeLocal);
    
    SET startTime = TIME(startDateTimeLocal);
    SET endTime = TIME(endDateTimeLocal);
    
    SET dailyWorkingTime = FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, startTime))/60);
    
    IF(startTime < workStartTime)
		THEN SET startTime  = workStartTime;
    END IF;
    
     IF(startTime > workEndTime)
		THEN SET startTime  = workEndTime;
    END IF;
    
    IF(endTime > workEndTime)
		THEN set endTime = workEndTime;
	END IF;
    
    IF(endTime < workStartTime)
		THEN set endTime = workStartTime;
	END IF;
    
	SET currentDate = startDate;
    SET totalMinutes = 0;
    
    SELECT currentDate, startDate, endDate, startTime, endTime, workStartTime, workEndTime, dailyWorkingTime;
    
    WHILE(currentDate <= endDate)
	DO 
		IF(currentDate <> startDate AND currentDate <> endDate)
			THEN SET totalMinutes = totalMinutes + dailyWorkingTime;
            SELECT 1;
		ELSEIF(currentDate =  startDate AND currentDate <> endDate)
			THEN SET totalMinutes = totalMinutes + FLOOR(TIME_TO_SEC(TIMEDIFF(workEndTime, startTime))/60);
            SELECT 2;
		ELSEIF(currentDate <>  startDate AND currentDate = endDate)
			THEN SET totalMinutes = totalMinutes + FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, workStartTime))/60);
            SELECT 3;
		ELSE
			SET totalMinutes = totalMinutes + FLOOR(TIME_TO_SEC(TIMEDIFF(endTime, startTime))/60);
            SELECT 4;
        END IF;
        
        SET currentDate = DATE_ADD(currentDate,INTERVAL 1 DAY);
        
	END WHILE;
    
    IF(totalMinutes < 0)
		THEN SET totalMinutes = 0;
	END IF;
    
    SELECT totalMinutes;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TestBusinessHoursFull` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `TestBusinessHoursFull`(
IN startDateTime DATETIME, 
IN endDateTime DATETIME, 
IN timeZone INT
)
BEGIN
	DECLARE startDateTimeLocal DATETIME;
    DECLARE endDateTimeLocal DATETIME;
    DECLARE currentDateTime DATETIME;
    DECLARE closed BIT;
    DECLARE dayOfWeek VARCHAR(50);
    
    DECLARE workStartTime TIME;
    DECLARE workEndTime TIME;
    
    DECLARE endCurrentDateTime DATETIME;
    DECLARE startCurrentDateTime DATETIME;
    
    DECLARE totalMinutes INT DEFAULT 0;
    
	SET startDateTimeLocal = DATE_ADD(startDateTime, INTERVAL timeZone HOUR);
    SET endDateTimeLocal = DATE_ADD(endDateTime, INTERVAL timeZone HOUR);
    
    SET currentDateTime = startDateTimeLocal;
    
    WHILE(DATE(currentDateTime)<=DATE(endDateTimeLocal))
     DO
		SELECT TIME(bh.OpenTime),TIME(bh.CloseTime)
		INTO workStartTime, workEndTime
        FROM business_hours bh WHERE bh.dayOfWeek = DAYOFWEEK(currentDateTime);
		
        IF((SELECT COUNT(*) FROM biz_hours_except bhe 
					WHERE DATE(currentDateTime) BETWEEN DATE(bhe.OpenTime) AND DATE(bhe.CloseTime)) > 0)
			THEN SET totalMinutes = 0;
		ELSEIF (DATE(currentDateTime) < DATE(endDateTimeLocal))
        THEN
            SET endCurrentDateTime= CONVERT(CONCAT(DATE(currentDateTime),' ','23:59:00'), DATETIME);
            SET startCurrentDateTime= CONVERT(CONCAT(DATE(endDateTimeLocal),' ','00:00:00'), DATETIME);
			
			SET totalMinutes = totalMinutes + 
						CalculateBusinessHourByWorkingTime(currentDateTime,endCurrentDateTime,workStartTime,workEndTime);
			SELECT 1,totalMinutes,endCurrentDateTime,startCurrentDateTime,workStartTime,workEndTime;
		ELSE
			SET totalMinutes = totalMinutes + 
						CalculateBusinessHourByWorkingTime(startCurrentDateTime,endDateTimeLocal,workStartTime,workEndTime);
			SELECT 2,totalMinutes,startCurrentDateTime,endDateTimeLocal,workStartTime,workEndTime;
		END IF;		
		  
        SET currentDateTime = DATE_ADD(currentDateTime,INTERVAL 1 DAY);
        
	END WHILE;
    
    IF(totalMinutes < 0)
		THEN SET totalMinutes = 0;
	END IF;
    
    SELECT totalMinutes;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateOrderFeeApproval` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `UpdateOrderFeeApproval`(
IN order_Id int(11),
IN signer_Id int(11),
IN progress_Id int(11),
IN feeDescrip_Id int(11),
IN signer_Fee decimal(19,4),
IN offer_Id int(11),
IN isApproval bit,
IN approval_id INT
)
BEGIN
	declare orderRequestPending int(11);
    declare offer_status varchar(3);
    declare signer_Fees decimal(19,4); 
	
    if(isApproval)
		then set offer_status = 'A';
	else
		set offer_status = 'D';
	end if;
    
    -- update order
	if(signer_Id is not null and signer_Id <> 0) then 
		update `order` 
        set Signerid = signer_Id, ProgressId = progress_Id 
        where Orderid = order_id;
	end if;
    
    -- update singer fee
    UPDATE `order_fee` AS of
		set of.SignerFee = (SELECT ofa.FeeAmount FROM `order_fee_approve` AS ofa WHERE ofa.FeeApprovalId = approval_id)
	WHERE of.OrderId = order_id 
		AND of.FeeDescripId = feeDescrip_Id;
    
	select count(FeeApprovalId) as numberFee 
    into orderRequestPending 
    from `order_fee_approve` 
    where OrderId = order_Id 
		and FeeApproved = 'Pending';
    
	if(orderRequestPending > 0)
		then update `order_fee_approve` set OrderId = order_Id, FeeApproved = 'Rejected' where OrderId = order_Id and FeeApproved = 'Pending';
	end if;
    
    if(offer_Id is not null and  offer_Id <> 0) then 
		update signer_offer sof 
        set sof.OfferStatus = offer_status, sof.OfferAmount = signer_Fee
        where sof.OfferID = offer_Id;
    end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ViewOrders` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tce`@`%` PROCEDURE `ViewOrders`(
	IN orderID int(11), 
	IN vendorLastName varchar(255), 
	IN borrLastName varchar(255),
	IN companyBranch varchar(255),
	IN apptDate datetime,
	IN fromDate datetime,
	IN toDate datetime,
	IN loanAgent varchar(255),
	IN statusOrder varchar(255),
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(5000);  
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY `Order Date`';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
    
    SET whereQuery = ' WHERE 1=1 AND InActive = false ';
    IF (orderID IS NOT NULL AND orderID >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Order ID` = ', orderId);
	END IF;
    IF (vendorLastName IS NOT NULL AND vendorLastName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Vendor Last` LIKE ''%', vendorLastName, '%''');
	END IF;
    IF (borrLastName IS NOT NULL AND borrLastName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Client Last` LIKE ''%', borrLastName, '%''');
	END IF;
    IF (companyBranch IS NOT NULL AND companyBranch <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Company/Branch` like "%', companyBranch ,'%"');
	END IF;
    IF (apptDate IS NOT NULL AND apptDate <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND date(`Appt. Date`) = date("', apptDate,'")');
	END IF;
    IF (fromDate IS NOT NULL AND fromDate <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND date(`Order Date`) >= date("', fromDate,'")');
	END IF;
    IF (toDate IS NOT NULL AND toDate <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND date(`Order Date`) <= date("', toDate,'")');
	END IF;
    IF (loanAgent IS NOT NULL AND loanAgent <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Loan Agent` LIKE ''%', loanAgent, '%''');
	END IF;
    IF (statusOrder IS NOT NULL AND statusOrder <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Status` like "%', statusOrder,'%"');
	END IF;
    
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS `#`, t1.* from (select `order`.OrderId as `Order ID`,
                                    `borrower`.LastName as `Client Last`,
                                    `signer`.LastName as `Vendor Last`,
                                    `broker`.Company as `Company/Branch`,
                                    `progress`.ProgressDescription as `Status`,
                                    `order`.OrderDate as `Order Date`,
                                    `order`.AptDateTime as `Appt. Date`,
                                    `order`.LocalAptDateTime as `Local Time`,
                                    `order`.State as `ST`,
                                    `employees`.LastName as `Rep`,
                                    `agent`.FullName as `Loan Agent`,
                                    TIMESTAMPDIFF(MINUTE,`order`.OrderDate,`order`.FilledDate) as `TCE Fill`,
									TIMESTAMPDIFF(MINUTE,`order`.RepAssignDate,`order`.FilledDate) as `Fill`,
                                    if(`order`.DocsToNot = true, "Y", "N") as `Docs`,
                                    if(`order`.FaxBackReq = true, "Y", "N") as `FB`,
                                    if(`order`.FaxBackAcceptDate > UTC_TIMESTAMP(), "Y", "N") as `FB Docs`,
                                    `order`.CommentDate,
                                    `order`.InActive
							from `order` 
								LEFT JOIN `signer` on `order`.SignerId = `signer`.SignerId  
                                LEFT JOIN `borrower` on `order`.BorrowerId = `borrower`.BorrowerId 
                                LEFT JOIN `agent` on `order`.AgentId = `agent`.AgentId 
                                LEFT JOIN `broker` on `agent`.BrokerId = `broker`.BrokerID
                                LEFT JOIN `progress` on `order`.ProgressId = `progress`.ProgressId
                                LEFT JOIN `employees` on `order`.RepId = `employees`.RepId) t1, (SELECT @rownum := 0) r ',
                                whereQuery, orderQuery, limitQuery
    );
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

    SELECT FOUND_ROWS() as TotalRecords;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-23 17:43:53
