-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `carriers`
--

DROP TABLE IF EXISTS `carriers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carriers` (
  `CarrierID` int(11) NOT NULL AUTO_INCREMENT,
  `Carrier` varchar(50) DEFAULT NULL,
  `SMSAddress` varchar(50) DEFAULT NULL,
  `LastUpdate` datetime DEFAULT NULL,
  PRIMARY KEY (`CarrierID`),
  UNIQUE KEY `CarrierID_UNIQUE` (`CarrierID`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carriers`
--

LOCK TABLES `carriers` WRITE;
/*!40000 ALTER TABLE `carriers` DISABLE KEYS */;
INSERT INTO `carriers` VALUES (1,'AT&T','@txt.att.net',NULL),(2,'Sprint','@messaging.sprintpcs.com',NULL),(3,'T-Mobile','@tmomail.net',NULL),(4,'Verizon Wireless','@vtext.com',NULL),(5,'Virgin Mobile','@vmobl.com',NULL),(6,'US Cellular','@email.uscc.net',NULL),(7,'Metro PCS','@mymetropcs.com',NULL),(8,'Boost Mobile','@myboostmobile.com',NULL),(9,'Sprint Nextel','@messaging.nextel.com',NULL),(10,'Qwest','@qwestmp.com',NULL),(11,'Telus','@msg.telus.com',NULL),(12,'Cellular South','@csouth1.com',NULL),(13,'Centennial Wireless','@cwemail.com',NULL),(14,'Cricket Wireless','@mms.cricketwireless.net',NULL),(15,'Alltel','@message.alltel.com',NULL),(16,'ACS Wireless','@paging.acswireless.com',NULL),(17,'Bluegrass Cellular','@sms.bluecell.com',NULL),(18,'Carolina West Wireless','@cwwsms.com',NULL),(19,'Cincinnati Bell','@cbw.com',NULL),(20,'Clearnet','@msg.clearnet.com',NULL),(21,'Corr Wireless Communications','@corrwireless.net',NULL),(22,'Illinois Valley Cellular','@ivctext.com',NULL),(23,'Inland Cellular Telephone','@inlandlink.com',NULL),(24,'Rogers','@pcs.rogers.com',NULL),(25,'West Central Wireless','@sms.wcc.net',NULL),(26,'Clear Talk','@sms.cleartalk.us',NULL),(27,'Straight Talk','@vtext.com',NULL),(28,'ogle Project Fi','@msg.fi.ogle.com',NULL);
/*!40000 ALTER TABLE `carriers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-23 17:43:42
