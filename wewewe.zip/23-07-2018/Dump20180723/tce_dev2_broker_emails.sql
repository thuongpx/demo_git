-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `broker_emails`
--

DROP TABLE IF EXISTS `broker_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `broker_emails` (
  `BrokerEmailId` int(11) NOT NULL AUTO_INCREMENT,
  `BrokerID` int(11) DEFAULT NULL,
  `EName` varchar(75) DEFAULT NULL,
  `Email` varchar(300) DEFAULT NULL,
  `EmailFor` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`BrokerEmailId`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `broker_emails`
--

LOCK TABLES `broker_emails` WRITE;
/*!40000 ALTER TABLE `broker_emails` DISABLE KEYS */;
INSERT INTO `broker_emails` VALUES (1,1,NULL,'closingcompany@gmail.com','S'),(2,10,NULL,'test@theclosingexchange.com','I'),(3,11,NULL,'test@theclosingexchange.com','I'),(4,12,NULL,'test@theclosingexchange.com','I'),(5,13,NULL,'test@theclosingexchange.com','I'),(6,38,'mi','mi@email.com','I'),(7,46,'Jamie','jesus@yahoo.com','B'),(8,52,'ss','sseitzinger@theclosingexchange.com','B'),(9,75,'Anh Em','anh@g.com','I'),(12,86,'1','1@1.com','B'),(13,87,'3','3@3.com','B'),(14,87,'4','4@4.com','B'),(16,87,'3','323@3.com','I'),(17,87,'4','4@4.com','S'),(18,87,'5','5@5.com','B'),(19,33,'454545','gfgfg@ghgh.com','B'),(20,16,'tgfgfgf','pavaso01@adb.com','S'),(21,16,'abc','pavaso01@adb.com','S');
/*!40000 ALTER TABLE `broker_emails` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-23 17:42:56
