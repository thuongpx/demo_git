-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `training_programs`
--

DROP TABLE IF EXISTS `training_programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_programs` (
  `ProgramId` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(250) NOT NULL,
  `Inactive` bit(1) DEFAULT NULL,
  `SortOrder` tinyint(4) DEFAULT NULL,
  `CreatedBy` int(11) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `IsPublished` bit(1) DEFAULT NULL,
  `Description` varchar(250) DEFAULT NULL,
  `ForVendor` bit(1) DEFAULT NULL,
  `ForStaff` bit(1) DEFAULT NULL,
  `AdditionalProgram` bit(1) DEFAULT NULL,
  PRIMARY KEY (`ProgramId`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_programs`
--

LOCK TABLES `training_programs` WRITE;
/*!40000 ALTER TABLE `training_programs` DISABLE KEYS */;
INSERT INTO `training_programs` VALUES (100,'Program','\0',1,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','','\0',NULL),(101,'Program1','\0',NULL,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','','',NULL),(102,'Program2','\0',NULL,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','',NULL,NULL),(103,'Program3','\0',NULL,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','','',NULL),(104,'Program4','\0',NULL,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','',NULL,NULL),(105,'Program5','\0',NULL,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','',NULL,NULL),(106,'Program6','\0',NULL,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','',NULL,NULL),(107,'Program7','\0',NULL,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','',NULL,NULL),(108,'Program8','\0',NULL,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','',NULL,NULL),(109,'Program9','\0',NULL,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','',NULL,NULL),(110,'Program10','\0',NULL,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','',NULL,NULL),(111,'Program11','\0',NULL,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','',NULL,NULL),(112,'Program12','\0',NULL,NULL,'2018-06-06 06:10:34','','Default Training Program for vendor after sign up','',NULL,NULL),(113,'Program13','\0',NULL,NULL,'2018-06-06 06:10:34','\0','Default Training Program for vendor after sign up','',NULL,NULL),(114,'Program14','\0',NULL,NULL,NULL,'','Khanh Program','',NULL,NULL),(115,'Program15','',NULL,NULL,NULL,NULL,'d','',NULL,NULL),(116,'Program16','\0',NULL,NULL,NULL,'','ANHANH','',NULL,NULL),(117,'Em','',NULL,NULL,NULL,NULL,'Em','','',NULL),(118,'aaa','',NULL,NULL,NULL,NULL,'aaa',NULL,'',''),(119,'dddddddddddd','',NULL,NULL,NULL,NULL,'aaaaaaaaaaaaa',NULL,'',''),(120,'bbbbbbbbb','',NULL,NULL,NULL,NULL,'aaaaa','',NULL,'');
/*!40000 ALTER TABLE `training_programs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-23 17:43:42
