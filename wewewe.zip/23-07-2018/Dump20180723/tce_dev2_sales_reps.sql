-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sales_reps`
--

DROP TABLE IF EXISTS `sales_reps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_reps` (
  `SalesRepId` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(30) DEFAULT NULL,
  `LastName` varchar(30) DEFAULT NULL,
  `CommissionPercent` float DEFAULT NULL,
  `CommissionAmount` decimal(19,4) DEFAULT NULL,
  `RepID` int(11) DEFAULT NULL,
  PRIMARY KEY (`SalesRepId`),
  KEY `repid_sales_reps_employee_idx` (`RepID`),
  CONSTRAINT `repid_sales_reps_employee` FOREIGN KEY (`RepID`) REFERENCES `employees` (`RepId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_reps`
--

LOCK TABLES `sales_reps` WRITE;
/*!40000 ALTER TABLE `sales_reps` DISABLE KEYS */;
INSERT INTO `sales_reps` VALUES (1,'TestName','TestName',NULL,NULL,35),(2,'TestName','TestName',NULL,NULL,36),(3,'Test','Test',NULL,NULL,37),(4,'Test','Test',45,450.0000,38),(5,'NamNV','NamNV',46.4,570.5000,39),(6,'NamNV','Test',0,0.0000,40),(7,'Nam','Nguyen',0,0.0000,41),(8,'Nam','Test',0,0.0000,42),(9,'A','Test',444,444.0000,43),(10,'Nam','Test1',0,0.0000,44),(11,'Test','Test',55,0.0000,45),(12,'A','A',443,443.0000,46),(13,'aaaa','aaa',123,NULL,47),(14,'AAA','AA',43,56.0000,48),(15,'AAAAAAA','AAAAAAA',45,54.0000,49),(16,'bbbbbb','bbbbbb',NULL,NULL,50),(17,'aaaaaaaaawqweqweqweqweqwe','ewewew',55,55.0000,51),(18,'111111112111111111111nam','1111111111111111111111111',50,NULL,53);
/*!40000 ALTER TABLE `sales_reps` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-23 17:43:43
