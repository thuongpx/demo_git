-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `LinkTitle` varchar(50) DEFAULT NULL,
  `Link` varchar(200) DEFAULT NULL,
  `Description` varchar(1000) DEFAULT NULL,
  `Type` varchar(1) DEFAULT NULL,
  `Target` varchar(10) DEFAULT NULL,
  `Views` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
INSERT INTO `links` VALUES (1,'CFPB TILA/RESPA Resources','http://www.consumerfinance.gov/regulatory-implementation/tila-respa/','Link to CFPB TRID training and resources.','G','_blank','HOME_PAGE'),(2,'www.infragardawareness.com/demo/presentation.html','http://www.infragardawareness.com/demo/presentation.html','Infragard Security Awareness Training','G','_blank','CLIENT'),(3,'Page Separator','http://www.shareasale.com/r.cfm?b=348323&u=842719&m=37072&urllink=&afftrack=','Printing letter and legal documents has never been easier. Avoid the print page size hassle - use Page Separator!','G','_blank','CLIENT'),(4,'State Notary Pages','/company.asp?page=statepages','Secretary of State Notary Pages','G','_blank','VENDOR'),(20,'ThanhOccc','asdas','aasdasdaaaa','G','_self','VENDOR'),(21,'sieungu','asdas','asdas','G','_blank','VENDOR'),(23,'ThienNgu','asdasd.ngu','aaaaaa','G','_blank','CLIENT'),(24,'Abcd','asdasd','1532','G','_blank','HOME_PAGE'),(28,'googl','http://www.youtube.com','youtube','V','_self','HOME_PAGE'),(29,'zing','mp3.zing.vn','Link Nhac','G','_blank','HOME_PAGE'),(30,'nhaccuatui.com','Client','undefined','G','_blank','CLIENT'),(32,'Thien ngu si thua con heo','ThienNguSi.com','bbbbbb','G','_blank','CLIENT'),(33,'son dep trai','http://localhost:3000/staff-links','hehe','G','_blank','VENDOR'),(35,'Son ddddark dep trai cccccc','abcxyz.com','son fix bug gium ta','G','_blank','VENDOR'),(37,'Thanh cho dien','Thanh.com','abcxyz_xxx','G','_blank','HOME_PAGE'),(38,'choi long ga','banphagia.com','abcxxx','C','_blank','HOME_PAGE'),(39,'Son Trac Bu Du do treo cay dua','tracbudu.com','lot bu du 100k','G','_blank','HOME_PAGE'),(40,'sieu dddddark','http://csgo.com','13211','G','_blank','HOME_PAGE'),(41,'How to Trac Bu Du','http://sonbudu.com','trac bu du theo cach cua Son','C','_blank','HOME_PAGE'),(44,'ThanhCCCCCCCCCCCCCCC','a;djsajkdhaskhd','dalsdhkjasdkh','G','_blank','CLIENT'),(45,'SDc','dasdasdasd','asdsadas','G','_blank','HOME_PAGE'),(46,'ADCarry','sadasdasd','32132143','G','_blank','HOME_PAGE'),(47,'AdCarry','kjashdjkasgdjkasgd','hihi chao Thien','G','_blank','CLIENT'),(49,'some body','asdaslkdjaslkdjlajd','aosdjalksdjlj','G','_blank','CLIENT');
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-23 17:43:39
