ALTER TABLE `sales_reps` 
ADD COLUMN `RepID` INT(11) NULL,
ADD INDEX `repid_sales_reps_employee_idx` (`RepID` ASC);
ALTER TABLE `sales_reps` 
ADD CONSTRAINT `repid_sales_reps_employee`
  FOREIGN KEY (`RepID`)
  REFERENCES `employees` (`RepId`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;