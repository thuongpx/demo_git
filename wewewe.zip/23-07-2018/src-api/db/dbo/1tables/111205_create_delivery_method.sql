-- Request from LamVT
-- Add delivery method
CREATE TABLE IF NOT EXISTS `delivery_method` (
    `DelMethodId` INT(11) NOT NULL AUTO_INCREMENT,
    `DelMethodDescription` VARCHAR(100),
    PRIMARY KEY (`DelMethodId`)
);
