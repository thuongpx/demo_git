ALTER TABLE `broker` 
ADD COLUMN `IsAvailable` BIT(1) NULL AFTER `ProfilePicture`;