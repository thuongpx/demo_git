import VendorDashboardController from "./vendor-dashboard-controller";
const routes = [
    {
        path: "/vendor-dashboard/getDataVendorDashboard",
        method: "GET",
        handler: VendorDashboardController.getDataVendorDashboard
    },
    {
        path: "/vendor-dashboard/deactivateVendor",
        method: "POST",
        handler: VendorDashboardController.deactivateVendor
    },
    {
        path: "/vendor-dashboard/getDocumentExpireBySignerId",
        method: "GET",
        handler: VendorDashboardController.getDocumentExpireBySignerId
    }
];

export default routes;