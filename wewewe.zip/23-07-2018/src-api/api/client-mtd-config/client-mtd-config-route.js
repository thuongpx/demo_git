import ClientMTDConfigController from "./client-mtd-config-controller";

const routes = [
    {
        path: "/clientMTDConfig/getClientMTDConfigByUserId",
        method: "GET",
        handler: ClientMTDConfigController.getClientMTDConfigByUserId
    },
    {
        path: "/clientMTDConfig/addClientMTDConfig",
        method: "POST",
        handler: ClientMTDConfigController.addClientMTDConfig
    }
];

export default routes;