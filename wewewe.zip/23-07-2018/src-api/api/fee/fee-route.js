import FeeController from "./fee-controller";
import FeeRequestReason from "./fee-request-reason";

const routes = [{
    path: "/fee/getFee",
    method: "GET",
    handler: FeeController.getAllFee
},
{
    path: "/fee/getFeeRequestReason",
    method: "GET",
    handler: FeeRequestReason.getReasonCode
}];


export default routes;