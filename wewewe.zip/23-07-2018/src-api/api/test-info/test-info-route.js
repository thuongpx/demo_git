import TestInfoController from "./test-info-controller";

const routes = [{
    path: "/testInfo/addTestInfo",
    method: "POST",
    handler: TestInfoController.addTestInfo
},
{
    path: "/testInfo/getTestInfos",
    method: "POST",
    handler: TestInfoController.getTestInfos
},
{
    path: "/testInfo/updateTestInfo",
    method: "POST",
    handler: TestInfoController.updateTestInfo
},
{
    path: "/testInfo/activeDeactiveTestInfo",
    method: "POST",
    handler: TestInfoController.activeDeactiveTestInfo
},
{
    path: "/testInfo/deleteTestInfo",
    method: "POST",
    handler: TestInfoController.deleteTestInfo
},
{
    path: "/testInfo/getTestInfoById",
    method: "GET",
    handler: TestInfoController.getTestInfoById
},
{
    path: "/testInfo/checkExistTest",
    method: "POST",
    handler: TestInfoController.checkExistTest
},
{
    path: "/testInfo/getTestSectionsDefaultTest",
    method: "GET",
    config: { auth: false },
    handler: TestInfoController.getTestSectionsDefaultTest
},
{
    path: "/testInfo/getTestQaBySectionId",
    method: "GET",
    config: { auth: false },
    handler: TestInfoController.getTestQaBySectionId
},
{
    path: "/testInfo/checkTestAnswers",
    method: "POST",
    config: { auth: false },
    handler: TestInfoController.checkTestAnswers
},
{
    path: "/testInfo/checkDefaultTestAnswers",
    method: "POST",
    config: { auth: false },
    handler: TestInfoController.checkDefaultTestAnswers
},
{
    path: "/testInfo/isVendorFailedExam",
    method: "GET",
    config: { auth: false },
    handler: TestInfoController.isVendorFailedExam
},
{
    path: "/testInfo/setDefaultTest",
    method: "POST",
    handler: TestInfoController.setDefaultTest
},
{
    path: "/testInfo/getTestCategory",
    method: "GET",
    handler: TestInfoController.getTestCategory
}
];

export default routes;