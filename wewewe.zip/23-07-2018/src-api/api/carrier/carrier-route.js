import CarrierController from "./carrier-controller";

const routes = [{
    path: "/carrier/getAllCarriersForDropDown",
    method: "GET",
    config: {
        auth: false
    },
    handler: CarrierController.getAllCarriersForDropDown
}];

export default routes;