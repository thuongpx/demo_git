import SignerHistoryController from "./signer-history-controller";

const routes = [{
    path: "/signerHistory/getOrdersSignerHistory",
    method: "GET",
    handler: SignerHistoryController.getOrdersSignerHistory
}];

export default routes;