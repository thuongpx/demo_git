import VendorCategoryController from "./vendor-category-controller";

const routes = [{
    path: "/vendor-category/getCategories",
    method: "GET",
    handler: VendorCategoryController.getCategories
}];

export default routes;