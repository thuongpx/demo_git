import Bookshelf from "../../db/database";
import Boom from "boom";

import {
    distinctSingleValueArray
} from "../../helper/common-helper";
import {
    buildSqlQuery,
    buildSqlCountQuery
} from "./canned-report";

class CustomerReportController {
    constructor() { }

    // Assigned Orders by Schedulers
    fetchAssignedOrderBySchedulerGridData(request, reply) {
        const sqlResult = buildSqlQuery("assigned_order_by_scheduler_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];

                reply({
                    data
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countAssignedOrderBySchedulerGridData(request, reply) {
        const sqlResult = buildSqlCountQuery("assigned_order_by_scheduler_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];
                reply(
                    data.Num
                );
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchAssignedOrderBySchedulerChartData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            month,
            scheduler,
            showTop10
        } = searchObject;
        const sqlResult = buildSqlQuery("assigned_order_by_scheduler_chart_v", request.payload);
        const { sqlStr } = sqlResult;

        const rawSql =
            `SELECT *, Count(*) AS Num FROM (${sqlStr}) v
        GROUP BY RepId, OrderMonth`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                const rawData = result[0];

                const sortedMonth = month.sort((a, b) => {
                    return parseInt(a.value) - parseInt(b.value);
                });

                const labelMonth = distinctSingleValueArray(sortedMonth.map(item => item.label));
                const labelValue = distinctSingleValueArray(sortedMonth.map(item => item.value));

                let labels = [];

                if (showTop10) {
                    labels = distinctSingleValueArray(rawData.map(item => item.FullName));
                } else {
                    labels = distinctSingleValueArray(scheduler.map(item => item.label));
                }
                const datasets = [];

                for (let m = 0; m < labelMonth.length; m++) {
                    const tData = {
                        label: labelMonth[m],
                        data: []
                    };

                    for (let i = 0; i < labels.length; i++) {
                        // eslint-disable-next-line
                        const f = rawData.find(r => (r.OrderMonth === parseInt(labelValue[m]) && r.FullName === labels[i]));

                        tData.data.push(f ? f.Num : 0);
                    }

                    datasets.push(tData);
                }

                // prepare temporary datasets to count total
                const totalDatasets = datasets[0].data.map(i => {
                    return {
                        value: i,
                        label: ""
                    };
                });

                // count total
                for (let i = 0; i < datasets.length; i++) {
                    for (let j = 0; j < totalDatasets.length; j++) {
                        if (i === 0) {
                            totalDatasets[j].label = labels[j];
                        } else {
                            totalDatasets[j].value += datasets[i].data[j];
                        }
                    }
                }

                // sort
                totalDatasets.sort((a, b) => {
                    if (a.value > b.value) {
                        return -1;
                    }

                    if (a.value < b.value) {
                        return 1;
                    }

                    return 0;
                });

                const sortedLabels = totalDatasets.map(i => i.label);

                // sort data of datasets
                if (showTop10) {
                    for (let i = 0; i < datasets.length; i++) {
                        const oldData = datasets[i].data;
                        const newData = [];

                        for (let j = 0; j < 10; j++) {
                            const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                            newData.push(oldData[oldIndex]);
                        }

                        datasets[i].data = newData;
                    }
                    labels = sortedLabels.filter((i, index) => index < 10);
                } else {
                    for (let i = 0; i < datasets.length; i++) {
                        const oldData = datasets[i].data;
                        const newData = [];

                        for (let j = 0; j < sortedLabels.length; j++) {
                            const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                            newData.push(oldData[oldIndex]);
                        }

                        datasets[i].data = newData;
                    }
                }

                return reply({
                    labels,
                    datasets
                });

            }).catch(error => reply(Boom.badRequest(error)));

    }
}

export default new CustomerReportController();