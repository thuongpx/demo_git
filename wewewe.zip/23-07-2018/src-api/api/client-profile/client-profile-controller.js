import Boom from "boom";
import Bookshelf from "./../../db/database";
import Broker from "../../db/model/brokers";
import ClientDetail from "../../db/model/client-detail";
import ReturnAddress from "../../db/model/return-addr";
import BrokerEmails from "../../db/model/broker-emails";
import BrokerDetail from "../../db/model/broker-detail";

class ClientProfileController {
    constructor() {}

    getClientProfiles(request, reply) {
        const {
            clientId
        } = request.query;

        const getOrderCollectById = Promise.resolve(Bookshelf.knex.raw(`call GetClientInformation(${clientId})`));
        const getAllState = Promise.resolve(Bookshelf.knex.raw(`call GetAllState`));

        Promise.all([getOrderCollectById, getAllState])
            .then(values => {
                const data = {};

                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.clientProfiles = item[0][0];
                                    data.returnAddresses = item[0][1];
                                    data.emailsList = item[0][2];
                                    data.couriersList = item[0][3];
                                    break;
                                case 1:
                                    data.stateList = item[0][0];
                                    break;
                            }
                        }
                    });
                    reply(data);
                } else {
                    reply(Boom.badRequest({
                        message: "Could not connect to server"
                    }));
                }

            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }

    updateClientProfiles(request, reply) {
        const {
            brokerInfo,
            brokerDetailInfo,
            updatedAddressList,
            newAddressList,
            remainedAddressList,
            newEmailsList,
            updatedEmailsList,
            remainedEmailsList
        } = request.payload;
        if (brokerInfo === undefined || brokerDetailInfo === undefined) {
            reply(Boom.badRequest("Missing required values"));
            return reply;
        }

        const brokerId = brokerInfo.BrokerId;
        if (brokerId <= 0) {
            reply(Boom.badRequest("Missing Broker ID value"));
            return reply;
        }

        const updateBroker = Promise.resolve(Broker.where({
            BrokerId: brokerId
        }).save(brokerInfo, {
            method: "update"
        }));
        const updateBrokerDetail = Promise.resolve(ClientDetail.where({
            BrokerId: brokerId
        }).save(brokerDetailInfo, {
            method: "update"
        }));

        const queue = [updateBroker, updateBrokerDetail];

        // delete
        if (remainedAddressList.length > 0) {
            const delAddressSql = `DELETE FROM return_addr WHERE BrokerId=${brokerId} AND RaId NOT IN ${remainedAddressList}`;
            queue.push(Promise.resolve(Bookshelf.knex.raw(delAddressSql)));
        }

        // add new return address
        if (newAddressList !== undefined && newAddressList.length > 0) {
            newAddressList.map((addr) => {
                queue.push(Promise.resolve(new ReturnAddress(addr).save(null, {
                    method: "insert"
                })));
            });
        }

        // update existing return address
        if (updatedAddressList !== undefined && updatedAddressList.length > 0) {
            updatedAddressList.map((addr) => {
                queue.push(Promise.resolve(ReturnAddress.where({
                    RaId: addr.RaId
                }).save(addr, {
                    method: "update"
                })));
            });
        }

        // delete email
        if (remainedEmailsList.length > 0) {
            const delEmailSql = `DELETE FROM broker_emails WHERE BrokerID=${brokerId} AND BrokerEmailId NOT IN ${remainedEmailsList}`;
            queue.push(Promise.resolve(Bookshelf.knex.raw(delEmailSql)));
        }

        // add new email
        if (newEmailsList !== undefined && newEmailsList.length > 0) {
            newEmailsList.map((email) => {
                queue.push(Promise.resolve(new BrokerEmails(email).save(null, {
                    method: "insert"
                })));
            });
        }

        // update existing email
        if (updatedEmailsList !== undefined && updatedEmailsList.length > 0) {
            updatedEmailsList.map((email) => {
                queue.push(Promise.resolve(BrokerEmails.where({
                    BrokerEmailId: email.BrokerEmailId
                }).save(email, {
                    method: "update"
                })));
            });
        }

        // if

        Promise.all(queue).then(() => {
            reply({
                isSuccess: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

        return reply;
    }

    updateClientBillingDetail(request, reply) {
        const {
            brokerDetailInfo
        } = request.payload;
        if (brokerDetailInfo === undefined) {
            reply(Boom.badRequest("Missing required values"));
            return reply;
        }

        const brokerId = brokerDetailInfo.BrokerId;
        if (brokerId <= 0) {
            reply(Boom.badRequest("Missing Broker ID value"));
            return reply;
        }

        BrokerDetail.where({
                BrokerId: brokerId
            }).save(brokerDetailInfo, {
                method: "update"
            })
            .then(() => {
                reply({
                    isSuccess: true
                });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });

        return reply;
    }
}

export default new ClientProfileController();