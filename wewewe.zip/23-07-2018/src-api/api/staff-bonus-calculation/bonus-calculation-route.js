import BonusCalculationController from "./bonus-calculation-controller";

const routes = [{
    path: "/bonus/apiGetBonusCalculationData",
    method: "GET",
    handler: BonusCalculationController.getBonusCalculationData
}];

export default routes;