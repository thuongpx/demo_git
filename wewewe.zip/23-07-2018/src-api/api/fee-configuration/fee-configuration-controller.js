import Boom from "boom";
import Bookshelf from "../../db/database";
import Industry from "../../db/model/industry";
import LoanType from "../../db/model/loan-type";
import IndustryTransactionFees from "../../db/model/industry_transaction_fees";
import BrokerFee from "../../db/model/broker-fee";
class FeeConfiguration {
    constructor() { }

    getInitDataForMatrix(request, reply) {
        const { actor } = request.query;
        const getIndustryList = Promise.resolve(Industry.forge().orderBy("Description").fetchAll());
        const apiGetProductList = Promise.resolve(LoanType.forge().orderBy("LoanType").fetchAll());

        const apiGetFeeDescriptionList = actor === "Admin" ?
            Promise.resolve(Bookshelf.knex.raw(`select distinct itf.FeeDescription from industry_transaction_fees itf where itf.IsAdditionalFee = 1 order by itf.FeeDescription`)) :
            Promise.resolve(Bookshelf.knex.raw(`select distinct itf.FeeDescription from broker_fee itf where itf.IsAdditionalFee = 1 order by itf.FeeDescription`));

        const apiGetFeeTransactionList = actor === "Admin" ?
            Promise.resolve(Bookshelf.knex.raw(`Select itf.FeeDescription,itf.ClientFee,itf.VendorFee,itf.DefaultClientFee,itf.DefaultVendorFee, itf.Feeid,itf.LoanTypeId,itf.IndustryId,
                (case when itf.IsAdditionalFee = 0 then 0 else 1 end) as IsAdditionalFee
                from industry_transaction_fees itf
                order by itf.FeeDescription;`)) :
            Promise.resolve(Bookshelf.knex.raw(`Select itf.FeeDescription,itf.SelfServiceVendorFee as VendorFee, itf.DefaultSelfServiceVendorFee as DefaultVendorFee, itf.Feeid,itf.LoanTypeId,itf.IndustryId,
                (case when itf.IsAdditionalFee = 0 then 0 else 1 end) as IsAdditionalFee
                from broker_fee itf
                order by itf.FeeDescription`));

        Promise.all([apiGetFeeTransactionList, apiGetFeeDescriptionList, apiGetProductList, getIndustryList])
            .then(value => {
                const data = {};
                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.feeTransactions = item[0];
                                    break;
                                case 1:
                                    data.feeDescriptions = item[0];
                                    break;
                                case 2:
                                    data.products = item;
                                    break;
                                case 3:
                                    data.industries = item;
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
        return reply;
    }

    saveFee(request, reply) {
        const { industryId, remove, save, actor, actorId } = request.payload;
        //save by Admin
        const subTaskSaveByAdmin = Promise.resolve(
            save.forEach(s => {
                if (!remove.includes(s.LoanTypeId)) {
                    if (s.Feeid === null) {
                        new IndustryTransactionFees().save({
                            IndustryId: industryId,
                            LoanTypeId: s.LoanTypeId,
                            FeeDescription: s.FeeDescription,
                            // Client/Vendor Fee
                            ClientFee: s.ClientFee,
                            VendorFee: s.VendorFee,
                            DefaultClientFee: s.ClientFee,
                            DefaultVendorFee: s.VendorFee,
                            IsAdditionalFee: s.IsAdditionalFee
                        }, {
                                method: "insert"
                            }).then(() => {
                            }).catch((error) => {
                                return error;
                            });
                    } else {
                        IndustryTransactionFees.where({
                            FeeId: s.Feeid
                        }).save({
                            ClientFee: s.ClientFee,
                            VendorFee: s.VendorFee
                        }, {
                                method: "update"
                            }).then(() => {
                            }).catch((error) => {
                                return error;
                            });
                    }
                }
            })
        );
        //save by Client
        const subTaskSaveByClient = Promise.resolve(
            save.forEach(s => {
                if (!remove.includes(s.LoanTypeId)) {
                    if (s.Feeid === null) {
                        new BrokerFee().save({
                            IndustryId: industryId,
                            LoanTypeId: s.LoanTypeId,
                            FeeDescription: s.FeeDescription,
                            // SelfServiceVendorFee
                            SelfServiceVendorFee: s.VendorFee,
                            DefaultSelfServiceVendorFee: s.VendorFee,
                            IsAdditionalFee: s.IsAdditionalFee,
                            BrokerId: actorId
                        }, {
                                method: "insert"
                            }).then(() => {
                            }).catch((error) => {
                                return error;
                            });
                    } else {
                        BrokerFee.where({
                            FeeId: s.Feeid
                        }).save({
                            SelfServiceVendorFee: s.VendorFee
                        }, {
                                method: "update"
                            }).then(() => {
                            }).catch((error) => {
                                return error;
                            });
                    }
                }
            })
        );
        //remove by Admin
        const subTaskRemoveByAdmin = Promise.resolve(
            remove.forEach(r => {
                IndustryTransactionFees.where({
                    LoanTypeId: r
                }).destroy().then(() => {
                }).catch((error) => {
                    return error;
                });
            })
        );
        //promiseall
        const subTaskSave = actor === "Admin" ? subTaskSaveByAdmin : subTaskSaveByClient;
        const arrayTaskToDo = actor === "Admin" ? [subTaskSave, subTaskRemoveByAdmin] : [subTaskSave];

        Promise.all(arrayTaskToDo)
            .then(value => {
                if (value !== null) {
                    reply({
                        isSuccess: true
                    });
                } else {
                    reply({
                        isSuccess: false
                    });
                }
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getRefreshData(request, reply) {
        const { actor, industryId } = request.query;
        const rawSql = actor === "Admin" ?
            `
            UPDATE industry_transaction_fees 
            SET ClientFee = DefaultClientFee, VendorFee = DefaultVendorFee where IndustryId = ${industryId} 
        ` :
            `
            UPDATE broker_fee 
            SET SelfServiceVendorFee = DefaultSelfServiceVendorFee where IndustryId = ${industryId} 
        `;
        Bookshelf.knex.raw(rawSql)
            .then(() => {
                reply({
                    isSuccess: true
                });
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }
}

export default new FeeConfiguration();