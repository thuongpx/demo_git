import Bookshelf from "../../db/database";
import Boom from "boom";
import RolePermissions from "../../db/model/role-permissions";

class RolePermissionController {


    updateRolePermissions(request, reply) {
        const { data, roleType } = request.payload;
        const deleteSql = `DELETE FROM role_permissions WHERE RoleId ${roleType === "Staff" ? "" : "NOT"} IN (1, 2, 3, 4, 9, 10, 11, 12, 13) AND RpId <> 0`;
        const RolePermissionsAdd = Bookshelf.Collection.extend({
            model: RolePermissions
        });
        const permissions = RolePermissionsAdd.forge(data);

        Bookshelf.knex.raw(deleteSql).then(() => {
            //delete all success
            permissions.invokeThen("save").then((result) => {
                // ... all models in the collection have been saved
                if (result !== null) {
                    reply({ isSuccess: true });
                }
            });
        }).catch(() => {
        });
    }

    getRolesPermissions(request, reply) {
        const { roleType } = request.query;
        const rawSql = `CAll GetRolesPermission('${roleType}')`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                reply({
                    permissions: result[0][0]
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

}

export default new RolePermissionController();