import ClientDashboardController from "./client-dashboard-controller";

const routes = [{
    path: "/client-dashboard/getUnfilledOrderDashboard",
    method: "GET",
    handler: ClientDashboardController.getUnfilledOrderDashboard
},
{
    path: "/client-dashboard/getPendingOrderDashboard",
    method: "GET",
    handler: ClientDashboardController.getPendingOrderDashboard
},
{
    path: "/client-dashboard/getFaxbacksOrderDashboard",
    method: "GET",
    handler: ClientDashboardController.getFaxbacksOrderDashboard
},
{
    path: "/client-dashboard/getOrdersInfoClientDashboard",
    method: "GET",
    handler: ClientDashboardController.getOrdersInfoClientDashboard
},
{
    path: "/client-dashboard/getOrdersInfoDetailClientDashboard",
    method: "GET",
    handler: ClientDashboardController.getOrdersInfoDetailClientDashboard
},
{
    path: "/client-dashboard/getSLADashboard",
    method: "GET",
    handler: ClientDashboardController.getSLADashboard
}
];

export default routes;