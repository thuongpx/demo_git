-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `signer_changes`
--

DROP TABLE IF EXISTS `signer_changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signer_changes` (
  `ChangeId` int(11) NOT NULL AUTO_INCREMENT,
  `SignerId` int(11) NOT NULL,
  `WeekdayStreet` varchar(40) DEFAULT NULL,
  `WeekdaySuite` varchar(50) DEFAULT NULL,
  `WeekdayCity` varchar(25) DEFAULT NULL,
  `WeekdayState` varchar(2) DEFAULT NULL,
  `WeekdayZip` varchar(10) DEFAULT NULL,
  `WeekendStreet` varchar(40) DEFAULT NULL,
  `WeekendSuite` varchar(50) DEFAULT NULL,
  `WeekendCity` varchar(25) DEFAULT NULL,
  `WeekendState` varchar(2) DEFAULT NULL,
  `WeekendZip` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ChangeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signer_changes`
--

LOCK TABLES `signer_changes` WRITE;
/*!40000 ALTER TABLE `signer_changes` DISABLE KEYS */;
INSERT INTO `signer_changes` VALUES (1,4,'111111111111','11111','New York','NY','10021','555555','11111','New York','NY','10020'),(2,10,'1212','1212','New York','NY','10010','1212','1212','New York','NY','10010'),(3,7,'111','1234','New York','NY','10010','111','1234','New York','NY','10010');
/*!40000 ALTER TABLE `signer_changes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-12 18:58:18
