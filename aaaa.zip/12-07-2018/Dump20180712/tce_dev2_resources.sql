-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `resources`
--

DROP TABLE IF EXISTS `resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resources` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Resource` varchar(50) DEFAULT NULL,
  `Title` varchar(50) DEFAULT NULL,
  `Description` varchar(2000) DEFAULT NULL,
  `Lender` bit(1) DEFAULT b'0',
  `Notary` bit(1) DEFAULT b'0',
  `MemOnly` bit(1) DEFAULT b'0',
  `Views` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resources`
--

LOCK TABLES `resources` WRITE;
/*!40000 ALTER TABLE `resources` DISABLE KEYS */;
INSERT INTO `resources` VALUES (1,'CommonAbbreviations062013.pdf','Common Abbreviations','A list of common abbreviations you may see or hear when working with mortgage documents.','\0','','','HOME_PAGE_COMPANY_PROFILE'),(3,'LoanSigning062013.pdf','Loan Signing Process','A high level overview of the Notary Direct Loan Signing process.','\0','','','HOME_PAGE_COMPANY_PROFILE'),(4,'WitnessRequirements062013.pdf','Witness Requirements by state','A list of states that require witnesses for mortgage document signings. ','\0','','','HOME_PAGE_CLIENT'),(5,'StateHomePages07022013.pdf','Notary Sites by State','Links to each state\'s notary resource page.','\0','','','HOME_PAGE_CLIENT'),(6,'CommonMtgDotsWithAppendices07152013.pdf','Common Mortgage Documents (Updated)','A description of some of the more common mortgage docs found in signing packages, with signing instructions and samples. ','\0','','','HOME_PAGE_CLIENT'),(7,'Acknowledgement and Jurats.pdf','Acknowledgments and Jurats','A description of these certificates, and when and how to use them. ','\0','','','HOME_PAGE_VENDOR'),(8,'fw9.pdf','Independent Contractor W9','Notary Direct requires all of our notaries to complete and provide a copy of IRS Document W-9.  ','\0','','','HOME_PAGE_VENDOR'),(9,'AdobeUpdate.pdf','Keeping Adobe Current','Short description of steps to keep Adobe current. ','\0','','','HOME_PAGE_VENDOR'),(10,'CodeofConduct.pdf','Signing Agent Code of Conduct','Certified Signing Agent Code of Conduct, used with the permission of the Signing Professionals Workgroup.','\0','','\0','CLIENT'),(11,'SigningAgentMemo.pdf','July 2016 Technology and Operational updates','Explanation of updates to the website profile, operational changes regarding errors, training opportunities and increased communication channels. ','\0','','','CLIENT'),(12,'RESCISSIONCALENDAR2017.pdf','2017 Rescission Calendar','For use with Right to Cancel ','\0','','','VENDOR'),(13,'asda','asd','Manasd','','\0','\0','CLIENT'),(32,'UCS17.0 _Tools (1).docx','asdas','asdasd','\0','\0','\0','VENDOR'),(35,'faq-sect-.docx','sonNC3 mau M te gieng','son oc cho','\0','\0','\0','CLIENT,VENDOR,HOME_PAGE_VENDOR'),(36,'faq-sect-.docx','sieu pho mai dau bo` oc cho','HI(HIHIHIHIHI','\0','\0','\0','HOME_PAGE_COMPANY_PROFILE,CLIENT,HOME_PAGE_VENDOR'),(37,'CEPhase2_Set Up Source Code.docx','Son te song','asdasd','\0','\0','\0','CLIENT'),(38,'CEPhase2_Set Up Source Code.docx','asd','asdasd','\0','\0','\0','CLIENT'),(39,'UCS17.0 _Tools (1).docx','asdas','asdas','\0','\0','\0','HOME_PAGE_CLIENT'),(40,'UCS17.0 _Tools (1).docx','sonajsdjasdj','asdas','\0','\0','\0','HOME_PAGE_CLIENT'),(42,'faq-sect-.docx','son dau bo oc cho hihi','asdsadasd','\0','\0','\0','HOME_PAGE_CLIENT'),(44,'UCS17.0 _Tools.docx','son te cay mia','132131','\0','\0','\0','HOME_PAGE_CLIENT');
/*!40000 ALTER TABLE `resources` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-12 18:58:10
