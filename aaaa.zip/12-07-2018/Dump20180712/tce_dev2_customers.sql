-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `CustomerId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(40) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `BrokerId` int(11) NOT NULL,
  `ReqRating` varchar(50) DEFAULT NULL,
  `ReqExperienceNumber` smallint(6) DEFAULT NULL,
  `Inactive` bit(1) DEFAULT NULL,
  `IndustryId` int(11) DEFAULT NULL,
  PRIMARY KEY (`CustomerId`),
  KEY `industry_customer_idx` (`IndustryId`),
  CONSTRAINT `industry_customer` FOREIGN KEY (`IndustryId`) REFERENCES `industry` (`IndustryId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Title Company','thetitlecompany@gmail.com',1,'',NULL,NULL,1),(2,'Helen','hienlt13@fsoft.com.vn',1,'',NULL,NULL,1),(3,'Mi_Customer','mi@email.com',37,NULL,0,NULL,9),(4,'FPTCustomer','huent6@fsoft.com.vn',45,NULL,0,'',9),(5,'FPTCustomer edit','huent6@fsoft.com.vn',45,NULL,0,'',9),(6,'HueTest','huent6@fsoft.com.vn',45,NULL,0,'',4),(7,'Hue','huent6@fsoft.com.vn',45,NULL,0,'',9),(8,'test','huent6@fsoft.com.vn',45,NULL,NULL,'',4),(9,'FPTCustomer','huent6@fsoft.com.vn',45,NULL,0,'',4),(10,'Hue-Customer','huent6@fsoft.com.vn',45,NULL,0,NULL,4),(11,'Test Customer','testcustomer@gmail.com',2,NULL,20,NULL,10),(12,'chase','chase@chase.com',8,NULL,NULL,NULL,1),(13,'hana','pavaso01@adb.com',1,'',NULL,NULL,1),(14,'helen Customer1111','pavaso01@adb.com',1,'',NULL,NULL,1),(15,'customer 456','customer456@gmail.com',2,NULL,NULL,NULL,10),(16,'khanh cus','khanh@gamil.com',76,NULL,NULL,NULL,1),(17,'Kuro','kuro@gmail.com',5,NULL,NULL,NULL,1),(18,'hello','hello@gmail.com',1,NULL,NULL,'',1),(19,'Son nguyen','nguyencongson163@gmai.com',6,'',NULL,NULL,1);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-12 18:58:11
