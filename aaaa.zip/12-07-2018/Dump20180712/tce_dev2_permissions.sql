-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `PermissionId` int(11) NOT NULL AUTO_INCREMENT,
  `Description` varchar(150) DEFAULT NULL,
  `Url` varchar(250) DEFAULT NULL,
  `ApplyFor` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`PermissionId`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'Additional Services',NULL,'STAFF'),(2,'Bonus Calculation',NULL,'STAFF'),(3,'Business Hours',NULL,'STAFF'),(4,'Chatting',NULL,'STAFF'),(5,'Client Fee Requests',NULL,'STAFF'),(6,'Content Management System',NULL,'STAFF'),(7,'Dashboard',NULL,'STAFF'),(8,'FAQs',NULL,'STAFF'),(9,'Fees ',NULL,'STAFF'),(10,'Industries',NULL,'STAFF'),(11,'Invoices',NULL,'STAFF'),(12,'Links',NULL,'STAFF'),(13,'Manage Accounts',NULL,'STAFF'),(14,'Manage Clients',NULL,'STAFF'),(15,'Manage Vendors',NULL,'STAFF'),(16,'Notification Management',NULL,'STAFF'),(17,'Parent Industries',NULL,'STAFF'),(18,'Place Order',NULL,'STAFF'),(19,'Problem Reporting',NULL,'STAFF'),(20,'Problem Sub Type',NULL,'STAFF'),(21,'Problem Type',NULL,'STAFF'),(22,'Product Types',NULL,'STAFF'),(23,'Profile & Settings',NULL,'STAFF'),(24,'QB Client Check Export',NULL,'STAFF'),(25,'QB Client Export',NULL,'STAFF'),(26,'QB Client Invoice Export',NULL,'STAFF'),(27,'QB Vendor Bill Export',NULL,'STAFF'),(28,'QB Vendor Check Export',NULL,'STAFF'),(29,'QB Vendor Export',NULL,'STAFF'),(30,'Reports',NULL,'STAFF'),(31,'Resources',NULL,'STAFF'),(32,'Role & Permission',NULL,'STAFF'),(33,'Service Configuration Approval',NULL,'STAFF'),(34,'Training & Testing',NULL,'STAFF'),(35,'Vendor Classification Settings',NULL,'STAFF'),(36,'Vendor Credential Documents',NULL,'STAFF'),(37,'Vendor Fee Requests',NULL,'STAFF'),(38,'Vendor Rating Settings',NULL,'STAFF'),(39,'Vendor Requests',NULL,'STAFF'),(40,'View Orders',NULL,'STAFF'),(41,'Chatting',NULL,'CLIENT'),(42,'Client Dashboard',NULL,'CLIENT'),(43,'Client Registration',NULL,'CLIENT'),(44,'Document Management',NULL,'CLIENT'),(45,'FAQ',NULL,'CLIENT'),(46,'Fee/Vendor Approval',NULL,'CLIENT'),(47,'Links',NULL,'CLIENT'),(48,'Manage Agents',NULL,'CLIENT'),(49,'Manage Branches',NULL,'CLIENT'),(50,'Manage Customers',NULL,'CLIENT'),(51,'Order Assignment Configuration',NULL,'CLIENT'),(52,'Place Order',NULL,'CLIENT'),(53,'Problems',NULL,'CLIENT'),(54,'Profile & Settings',NULL,'CLIENT'),(55,'Reporting',NULL,'CLIENT'),(56,'Resources',NULL,'CLIENT'),(57,'Role & Permission',NULL,'CLIENT'),(58,'Service Configuration',NULL,'CLIENT'),(59,'SLA Configuration',NULL,'CLIENT'),(60,'Vendor Do not Use',NULL,'CLIENT'),(61,'Vendor Fee Configuration',NULL,'CLIENT'),(62,'Vendor Rating Settings',NULL,'CLIENT'),(63,'View Orders',NULL,'CLIENT');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-12 18:58:14
