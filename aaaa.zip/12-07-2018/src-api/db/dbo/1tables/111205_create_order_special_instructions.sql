-- Request from HoangNM
-- Add broker emails
CREATE TABLE IF NOT EXISTS `order_special_instructions` (
    `SpecialInsId` INT(11) NOT NULL AUTO_INCREMENT,
    `OrderId` INT(11),
    `Instructions` VARCHAR(2000),
    `Permanently` VARCHAR(1) NULL DEFAULT 'N',
    PRIMARY KEY (`SpecialInsId`)
);