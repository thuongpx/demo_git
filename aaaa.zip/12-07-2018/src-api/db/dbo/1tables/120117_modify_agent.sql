ALTER TABLE `agent` ADD COLUMN `NeedResetPassword` BIT NULL DEFAULT b'0';
