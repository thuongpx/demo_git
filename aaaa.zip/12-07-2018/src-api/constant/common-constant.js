export const ORDER_PROGRESS_LOG_ACTIVITIES = {
    FEE_REQUEST_SENT: "Fee Request Sent",
    FEE_REQUEST_APPROVED: "Fee Request Approved",
    FEE_REQUEST_REJECTED: "Fee Request Rejected",
    COMMENT_ADDED: "Comment Added",
    VENDOR_REQUEST_APPROVED: "Assigned to Vendor",
    VENDOR_REQUEST_REJECTED: "Rejected to Vendor"

};

export const ORDER_REQUEST_STATUS = {
    OPEN: "Pending",
    APPROVED: "Approved",
    REJECTED: "Rejected"
};

export const OFFER_STATUS = {
    ACCEPTED: "A",
    DECLINED: "D",
    EXPIRED: "E",
    MISSED: "M",
    PENDING: "P"
};

export const ORDER_FEE_VENDOR_REQUEST_STATUS = {
    PENDING: "Pending",
    APPROVED: "Approved",
    REJECTED: "Rejected"
};

export const ORDER_OWNER_TYPE = {
    CLIENT_ADMIN: "Client Admin",
    CLIENT_MANAGER: "Client Manager",
    CLIENT_AGENT: "Client Agent"
};

export const UPDATE_VENDOR_FEE_TYPE = {
    EXCEED: "EXCEED",
    UPDATE: "UPDATE",
    IGNORE: "IGNORE"
};

export const NOTIFICATION_TEMPLATE_PURPOSE = {
    SEND_CONFIRM_AND_BASIC_INFORMATION_SHARED_TO_PRIMARY_CUSTOMER: "Basic Information Shared to Primary Customer",
    SEND_CONFIRM_AND_BASIC_INFORMATION_SHARED_TO_CO_CUSTOMER: "Basic Information Shared to Co-Customer",
    PLACE_NEW_ORDER: "New Order Placed",
    CLOSE_ORDER_HAVING_TRACKING_NUMBER: "Close Request for Order_Having tracking #",
    CLOSE_ORDER_HAVE_NO_TRACKING_NUMBER: "Close Request for Order_Having no Tracking #",
    OFFER_ACCEPTED_VENDOR: "Offer Accepted-Vendor",
    VENDOR_RECOMMENDATION_REQUEST: "Vendor Recommendation request",
    RECOMMENDATION_REJECT_TO_VENDOR: "Recommendation Rejected To Vendor",
    REJECTE_FEE_REQUEST_BY_VENDOR: "Agent's Fee Request Rejected",
    APPROVE_FEE_REQUEST_BY_AGENT: "Agent's Fee Request Approved",
    VENDOR_RECOMMENDATION_APPROVED: "Vendor Recommendation - Vendor - Approved",
    VENDOR_EMAIL_VERIFICATION: "Activating Vendor Account",
    FORGOT_PASSWORD_VERIFICATION: "Forgot password email – Client",
    ARRIVED_AT_APPOINTMENT_AGENT: "Arrived at Appointment - Agent",
    SKILL_TEST_PASSED: "Skill Test Passed",
    CLIENT_SEND_INVITE: "Sent Invites",
    ORDER_DOCUMENTS_REJECTED: "Order Documents Rejected - Vendor"
};

export const OVERALL_RATING_SCALE = {
    PERFECT: {
        MINSCORE: 1500,
        RATING: "Perfect"
    },
    EXCELLENT: {
        MINSCORE: 800,
        RATING: "Excellent"
    },
    VERYGOOD: {
        MINSCORE: 600,
        RATING: "Very Good"
    },
    GOOD: {
        MINSCORE: 500,
        RATING: "Good"
    },
    FAIR: {
        MINSCORE: 400,
        RATING: "Fair"
    },
    CAUTION: {
        MINSCORE: 300,
        RATING: "Caution"
    },
    REVIEW: {
        MINSCORE: 0,
        RATING: "Review"
    },
    NEW: {
        RATING: "New"
    }
};

export const LIST_TIMEZONE_US = [{
    zone: "(UTC -10:00) Hawaii",
    UTC: "-10",
    abv: "HAST"
},
{
    zone: "(UTC -9:00) Alaska",
    UTC: "-9",
    abv: "AKST"
},
{
    zone: "(UTC -8:00) Pacific",
    UTC: "-8",
    abv: "PST"
},
{
    zone: "(UTC -7:00) Mountain",
    UTC: "-7",
    abv: "MST"
},
{
    zone: "(UTC -6:00) Central",
    UTC: "-6",
    abv: "CST"
},
{
    zone: "(UTC -5:00) Eastern",
    UTC: "-5",
    abv: "EST"
},
{
    zone: "(UTC -4:00) Atlantic",
    UTC: "-4",
    abv: "AST"
},
{
    zone: "(UTC +10:00)",
    UTC: "+10"
},
{
    zone: "(UTC +11:00)",
    UTC: "+11"
},
{
    zone: "(UTC +12:00)",
    UTC: "+12"
}
];

export const CRYPTO = {
    AES_256_CBC_ENCRYPTION_KEY: "50377888ae7cc4113b63c081ef17f026b1e59255ac8b79b90369838bf486889e",
    IV: "a2xhcgAAAAAAAAAA"
};

export const SECURITY = {
    TOKEN_EXPIRATION_TIME: "86400000",
    SECURITY_CODE_EXPIRATION_TIME: "900000"
};

export const AUTH = {
    USER_NOT_FOUND: "The specified user was not found",
    INCORRECT_PASSWORD: "Incorrect password",
    REGISTERED_FAILED: "Register failed",
    UNEXPECTED_ERROR: "Unexpected error"
};

export const TIMEZONE_US = [{
    zone: "(UTC -10:00) Hawaii",
    UTC: "-10",
    abv: "HAST"
},
{
    zone: "(UTC -9:00) Alaska",
    UTC: "-9",
    abv: "AKST"
},
{
    zone: "(UTC -8:00) Pacific",
    UTC: "-8",
    abv: "PST"
},
{
    zone: "(UTC -7:00) Mountain",
    UTC: "-7",
    abv: "MST"
},
{
    zone: "(UTC -6:00) Central",
    UTC: "-6",
    abv: "CST"
},
{
    zone: "(UTC -5:00) Eastern",
    UTC: "-5",
    abv: "EST"
},
{
    zone: "(UTC -4:00) Atlantic",
    UTC: "-4",
    abv: "AST"
},
{
    zone: "(UTC +10:00)",
    UTC: "+10"
},
{
    zone: "(UTC +11:00)",
    UTC: "+11"
},
{
    zone: "(UTC +12:00)",
    UTC: "+12"
}
];

//order document type
export const DOC_DELIVERY = {
    UPLOAD: 1,
    EMAIL_DIRECTLY_TO_VENDOR: 2,
    OVERNIGHT_TO_CUSTOMER: 3,
    OVERNIGHT_TO_VNENDOR: 4,
    OVERNIGHT_COURIER_TO_CLOSING_LOCATION: 5,
    PRINTED_AT_CLOSING_LOCATION: 6,
    CUSTOMER_HAS_DOCUMENTS: 7,
    E_SIGN: 8
};

export const COMMENT_TYPE = {
    OrderCommentType: 1,
    RequestFeeCommentType: 2,
    OrderIssueCommentType: 3,
    VendorApprovalCommentType: 4
};

export const RATING = {
    Excellent: 1,
    VeryGood: 2,
    Good: 3,
    New: 6
};

export const RATINGID = {
    1: "Excellent",
    2: "VeryGood",
    3: "Good",
    6: "New"
};

export const URL_REPORT = "./src/content/reports/";

export const TOOL_PAGE_DISPLAY = [
    {
        key: "HOME_PAGE_COMPANY_PROFILE",
        text: "Home Page – Company Profile"
    },
    {
        key: "HOME_PAGE_CLIENT",
        text: "Home Page – Client"
    },
    {
        key: "HOME_PAGE_VENDOR",
        text: "Home Page – Vendor"
    },
    {
        key: "CLIENT",
        text: "Client"
    },
    {
        key: "VENDOR",
        text: "Vendor"
    }
];

export const TOOL_LINK_DISPLAY = [
    {
        key: "HOME_PAGE",
        text: "Home Page"
    },
    {
        key: "CLIENT",
        text: "Client"
    },
    {
        key: "VENDOR",
        text: "Vendor"
    }
];