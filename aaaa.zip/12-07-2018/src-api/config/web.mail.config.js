export default {
        host: "10.133.28.50",
        port: 25,
        timeout: 10,
        user: "pavaso01",
        pass: "abc123"
};