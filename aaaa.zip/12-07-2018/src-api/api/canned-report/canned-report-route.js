import CannedReportController from "./canned-report-controller";

const routes = [
    {
        path: "/cannedReport/fetchOrderByStatusChartData",
        method: "POST",
        config: {
            auth: false
        },
        handler: CannedReportController.fetchOrderByStatusChartData
    },
    {
        path: "/cannedReport/getInitDataForCannedReport",
        method: "GET",
        config: {
            auth: false
        },
        handler: CannedReportController.getInitDataForCannedReport
    },
    {
        path: "/cannedReport/fetchOrderByStatusGridData",
        method: "POST",
        config: {
            auth: false
        },
        handler: CannedReportController.fetchOrderByStatusGridData
    },
    {
        path: "/cannedReport/countOrderByStatusGridData",
        method: "POST",
        config: {
            auth: false
        },
        handler: CannedReportController.countOrderByStatusGridData
    },
    {
        path: "/cannedReport/fetchOrderComparisonByBussinessChartData",
        method: "POST",
        config: {
            auth: false
        },
        handler: CannedReportController.fetchOrderComparisonByBussinessChartData
    },
    {
        path: "/cannedReport/fetchAssignedOrderByAgentChartData",
        method: "POST",
        config: {
            auth: false
        },
        handler: CannedReportController.fetchAssignedOrderByAgentChartData
    }
];

export default routes;