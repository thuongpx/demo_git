import Bookshelf from "../../db/database";
import Boom from "boom";

import { distinctSingleValueArray } from "../../helper/common-helper";
import { getOrderTypes, buildSqlQuery, buildSqlCountQuery } from "./canned-report";

class CannedReportController {
	constructor() { }

	async getInitDataForCannedReport(request, reply) {
		// get order types list
		const orderTypes = await getOrderTypes();

		reply({
			orderTypes: distinctSingleValueArray(orderTypes.map(i => i.LoanType))
		});
	}

	fetchOrderByStatusChartData(request, reply) {
		const sqlResult = buildSqlQuery("open_order_chart_v", request.payload);
		const { sqlStr, isShowAll } = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				const rawData = rs[0];
				const labels = distinctSingleValueArray(rawData.map(i => i.OrderStatus)); // build labels
				const orderTypes = distinctSingleValueArray(rawData.map(i => i.OrderType)); // build datasets

				const datasets = [];

				if (isShowAll) {
					const tData = {
						label: "All Data",
						data: []
					};

					for (let i = 0; i < labels.length; i++) {
						const f = rawData.filter(rd => rd.OrderStatus === labels[i]);
						const r = f.reduce((a, c) => {
							return {
								Count: a.Count + c.Count
							};
						});

						tData.data.push(r.Count);
					}

					datasets.push(tData);
				} else {
					for (let o = 0; o < orderTypes.length; o++) {
						const tData = {
							label: orderTypes[o],
							data: []
						};

						for (let i = 0; i < labels.length; i++) {
							const f = rawData.find(r => {
								return r.OrderType === orderTypes[o] && r.OrderStatus === labels[i];
							});

							tData.data.push(f ? f.Count : 0);
						}

						datasets.push(tData);
					}
				}
				return reply({
					labels,
					datasets
				});
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	fetchOrderComparisonByBussinessChartData(request, reply) {
		const { searchObject } = request.payload;
		const { month } = searchObject;

		const sqlResult = buildSqlQuery("open_order_comparison_by_business_day_chart_v", request.payload);
		const { sqlStr } = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				const rawData = rs[0];
				const sortedMonth = month.sort((a, b) => { return parseInt(a.value) - parseInt(b.value); });
				const labels = distinctSingleValueArray(sortedMonth.map(item => item.label));
				const labelValue = distinctSingleValueArray(sortedMonth.map(item => item.value));
				const datasets = [];
				const tData = {
					label: "All Data",
					data: []
				};

				for (let i = 0; i < labelValue.length; i++) {
					const f = rawData.filter(rd => (rd.OrderMonth === parseInt(labelValue[i])));

					tData.data.push(f.length);
				}

				datasets.push(tData);

				return reply({
					labels,
					datasets
				});
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	fetchOrderByStatusGridData(request, reply) {
		const sqlResult = buildSqlQuery("open_order_drilldown_v", request.payload);
		const { sqlStr } = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs) {
					reply(Boom.badRequest("Empty response"));
					return;
				}

				const data = rs[0];

				reply({
					data
				});
				return;
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	countOrderByStatusGridData(request, reply) {
		const sqlResult = buildSqlCountQuery("open_order_drilldown_v", request.payload);
		const { sqlStr } = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs || rs.length === 0) {
					reply(0);
					return;
				}

				const data = rs[0][0];

				reply(data.Num);
				return;
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	//sieutnm
	fetchAssignedOrderByAgentChartData(request, reply) {
		const searchObject = request.payload;

		const sqlResult = buildSqlQuery("assigned_order_by_agent_chart_v", searchObject);
		const { sqlStr } = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(result => {
				const rawData = result[0];
				const labels = distinctSingleValueArray(rawData.map(item => item.FullName));
				const orderTypes = rawData.map(item => item.OrderType); // build datasets
				const datasets = [];
				// const tData = {
				// 	label: "",
				// 	data: []
				// };
				for (let repId = 0; repId < labels.length; repId++) {
					const tData = {
						label: labels[repId],
						data: []
					};

					for (let i = 0; i < orderTypes.length; i++) {
						const f = rawData.find(r => {
							return r.FullName === labels[repId] && r.OrderType === orderTypes[i];
						});
						// console.log(`========: ${JSON.stringify(f)}`);
						tData.data.push(f ? f : 0);
					}

					datasets.push(tData);
				}
				return reply({
					labels,
					datasets
				});

			}).catch(error => reply(Boom.badRequest(error)));
	}
	//sieu end
}

export default new CannedReportController();