import LanguageController from "./language-controller";

const routes = [{
    path: "/language/getLanguages",
    method: "GET",
    config: {
        auth: false
    },
    handler: LanguageController.getLanguages
}];

export default routes;