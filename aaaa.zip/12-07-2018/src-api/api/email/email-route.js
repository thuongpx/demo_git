import EmailController from "./email-controller";

const routes = [{
    path: "/mail/sendMail",
    method: "POST",
    handler: EmailController.sendMail
}, {
    path: "/mobile/mail/sendEmailToUs",
    method: "POST",
    config: {
        auth: false
    },
    handler: EmailController.mobileVendorSendEmailToUs
},
{
    path: "/mobile/mail/sendEmailToTCE",
    method: "POST",
    handler: EmailController.mobileSendEmailToTCE
},
{
    path: "/mobile/mobileArrivedAtAppt",
    method: "POST",
    config: { auth: false },
    handler: EmailController.mobileArrivedAtAppt
},
//send email for vendor communication
{
    path: "/mail/sendEmailToVendorCommunication",
    method: "POST",
    config: { auth: false },
    handler: EmailController.sendEmailToVendorCommunication
},
// send sms for vendor communication
{
    path: "/sms/sendSmsToVendorCommunication",
    method: "POST",
    config: { auth: false },
    handler: EmailController.sendSmsToVendorCommunication
},
//send Email To TCE Communication
{
    path: "/mail/sendEmailToTCECommunication",
    method: "POST",
    config: { auth: false },
    handler: EmailController.sendEmailToTCECommunication
},
//send Email To Client Communication
{
    path: "/mail/sendEmailToClientCommunication",
    method: "POST",
    config: { auth: false },
    handler: EmailController.sendEmailToClientCommunication
},
// sendSendCloseSuccessfully
{
    path: "/mail/sendSendCloseSuccessfully",
    method: "POST",
    config: { auth: false },
    handler: EmailController.sendSendCloseSuccessfully
},
//sendSendCloseUnsuccessfully
{
    path: "/mail/sendSendCloseUnsuccessfully",
    method: "POST",
    config: { auth: false },
    handler: EmailController.sendSendCloseUnsuccessfully
}
];

export default routes;