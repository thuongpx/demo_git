import ZipController from "./zip-controller";
const routes = [{
    path: "/zip/getZipsByKeyword",
    method: "GET",
    handler: ZipController.getZipsByKeyword
},
{
    path: "/zip/getStateByZipCode",
    method: "GET",
    handler: ZipController.getStateByZipCode
},
{
    path: "/zip/getCitiesByStates",
    method: "POST",
    handler: ZipController.getCitiesByStates
},
{
    path: "/zip/filterCitiesOfStates",
    method: "POST",
    handler: ZipController.filterCitiesOfStates
},
{
    path: "/zip/getTimeZoneByZip",
    method: "GET",
    handler: ZipController.getTimeZoneByZip
}
];

export default routes;