import OrderProgressLogController from "./order-progress-log-controller";

const routes = [{
    path: "/orderprogress/addProgressLog",
    method: "POST",

    handler: OrderProgressLogController.addProgressLog
},
{
    path: "/orderprogress/addMultiProgressLog",
    method: "POST",

    handler: OrderProgressLogController.addMultiProgressLog
},
{
    path: "/orderprogress/getOrderProgressLogById",
    method: "GET",

    handler: OrderProgressLogController.getOrderProgressLogById
},
{
    path: "/orderprogress/getDataAlert",
    method: "GET",
    handler: OrderProgressLogController.getDataAlert
},
{
    path: "/orderprogress/updateMaskAsReadOrUnread",
    method: "POST",
    handler: OrderProgressLogController.updateMaskAsReadOrUnread
}
];

export default routes;