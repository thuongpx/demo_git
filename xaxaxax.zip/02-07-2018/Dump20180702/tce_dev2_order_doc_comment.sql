-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `order_doc_comment`
--

DROP TABLE IF EXISTS `order_doc_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_doc_comment` (
  `CommentId` int(11) NOT NULL AUTO_INCREMENT,
  `DocId` int(11) NOT NULL,
  `CommentBy` int(11) NOT NULL,
  `Comment` varchar(250) DEFAULT NULL,
  `CommentDate` datetime DEFAULT NULL,
  PRIMARY KEY (`CommentId`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_doc_comment`
--

LOCK TABLES `order_doc_comment` WRITE;
/*!40000 ALTER TABLE `order_doc_comment` DISABLE KEYS */;
INSERT INTO `order_doc_comment` VALUES (1,63,5,'test additional comment 1','2018-05-22 09:42:30'),(2,63,5,'test 2','2018-05-22 10:03:51'),(3,63,5,'test num 3 thich the','2018-05-22 10:17:24'),(4,63,5,'test num 4 xem max length\nlamvt','2018-05-22 10:29:12'),(5,63,5,'test num 5555555555555555555555555555555555555555555555555555555555555','2018-05-22 10:29:33'),(6,63,5,'test de ve nha an com','2018-05-22 11:02:47'),(7,63,5,'test phat nua roi ve','2018-05-22 11:09:59'),(8,62,5,'test comment','2018-05-23 02:26:51'),(9,62,5,'test maxlength textboxtest maxlength textboxtest maxlength textboxtest maxlength textboxtest maxlength textboxtest maxlength textboxtest maxlength textboxtest maxlength textboxtest maxlength textboxtest maxlength textboxtest maxlength textboxtest max','2018-05-23 02:32:54'),(10,62,5,'test scroll bottom','2018-05-23 06:26:10'),(11,62,5,'test lan nua','2018-05-23 06:26:17'),(12,62,5,'test add comment','2018-05-23 06:28:09'),(13,62,5,'add comment lan cuoi','2018-05-23 06:35:42'),(14,62,5,'thich add lan nua day','2018-05-23 06:35:58'),(15,62,5,'add phat nua','2018-05-23 06:43:09'),(16,62,5,'add phat nua luon','2018-05-23 06:57:26'),(17,61,5,'add first comment to test maxlength add first comment to test maxlength add first comment to test maxlength add first comment to test maxlength add first comment to test maxlength add first comment to test maxlength add first comment to test maxlengt','2018-05-23 08:36:07'),(18,61,5,'add comment test time','2018-05-29 06:56:25'),(19,61,5,'add thang nua xem','2018-05-29 07:00:21'),(20,61,5,'add them test thang nua','2018-05-29 07:03:46'),(21,61,5,'test thang nua luon. cu lua cmnr','2018-05-29 07:04:02'),(22,61,5,'cu lua nua','2018-05-29 07:27:22'),(23,181,381,'5','2018-06-07 08:41:43'),(24,181,381,'78','2018-06-07 08:41:47'),(25,181,381,'123','2018-06-07 10:08:43'),(26,181,381,'213','2018-06-07 10:08:46'),(27,259,381,'123213','2018-06-08 10:00:47'),(28,259,381,'123','2018-06-08 10:01:15'),(29,259,381,'123','2018-06-08 10:01:17'),(30,259,381,'123','2018-06-08 10:01:21');
/*!40000 ALTER TABLE `order_doc_comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-02 19:09:13
