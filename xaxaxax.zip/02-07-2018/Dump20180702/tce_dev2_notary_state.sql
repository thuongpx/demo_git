-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notary_state`
--

DROP TABLE IF EXISTS `notary_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notary_state` (
  `SignerId` int(11) DEFAULT NULL,
  `State` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notary_state`
--

LOCK TABLES `notary_state` WRITE;
/*!40000 ALTER TABLE `notary_state` DISABLE KEYS */;
INSERT INTO `notary_state` VALUES (245,'AK'),(245,'AL'),(245,'AR'),(246,'AK'),(246,'AL'),(246,'AR'),(247,'AK'),(247,'AL'),(247,'AR'),(248,'AK'),(248,'AL'),(248,'AR'),(249,'AK'),(249,'AL'),(249,'AR'),(250,'AK'),(250,'AL'),(250,'AR'),(259,'AK'),(259,'AL'),(260,'AL'),(260,'AK'),(265,'AR'),(265,'AL'),(265,'AZ'),(271,'1'),(272,'1'),(273,'1'),(274,'1'),(275,'1'),(276,'1'),(277,'1'),(279,'1'),(280,'1'),(281,'1'),(282,'1'),(283,'1'),(284,'1'),(285,'1'),(286,'1'),(19,'AK'),(19,'AL'),(19,'AR'),(287,'1'),(288,'1'),(289,'1'),(290,'1'),(293,'AL'),(293,'AR'),(298,'AK'),(298,'AZ'),(299,'AL'),(300,'AK'),(300,'AR'),(301,'AL'),(301,'AR'),(302,'AL'),(303,'AL'),(303,'AR'),(304,'AL'),(304,'AR'),(305,'AL'),(305,'AR'),(306,'AL'),(306,'AR'),(307,'AK'),(307,'AR'),(308,'AR'),(308,'AL'),(309,'AK'),(309,'AL'),(1,'AK'),(1,'AL'),(1,'AR'),(316,'AL'),(316,'AK'),(319,'AL'),(319,'AK'),(319,'AR'),(319,'AZ'),(319,'CO'),(319,'CT'),(319,'CA'),(319,'DC'),(319,'DE'),(319,'FL'),(319,'GA'),(319,'HI'),(319,'IA'),(319,'ID'),(319,'IL'),(319,'IN'),(319,'KY'),(319,'LA'),(319,'MA'),(239,'AK'),(239,'AL'),(239,'AR'),(239,'TX'),(322,'AK'),(322,'CO'),(322,'CT'),(321,'AK'),(321,'AL'),(321,'AZ'),(321,'CA'),(321,'CO'),(321,'CT'),(321,'AR'),(321,'DC'),(321,'DE'),(321,'FL'),(321,'GA'),(321,'IA'),(321,'ID'),(321,'IL'),(321,'HI'),(321,'IN'),(320,'AK'),(320,'AL'),(320,'AR');
/*!40000 ALTER TABLE `notary_state` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-02 19:09:03
