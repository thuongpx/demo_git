-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `broker_asgmt_config_log`
--

DROP TABLE IF EXISTS `broker_asgmt_config_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `broker_asgmt_config_log` (
  `LogId` int(11) NOT NULL AUTO_INCREMENT,
  `BrokerId` int(11) NOT NULL,
  `Rating` varchar(50) DEFAULT NULL,
  `Specialty` varchar(100) DEFAULT NULL,
  `ExperienceNumber` smallint(6) DEFAULT NULL,
  `Training` varchar(100) DEFAULT NULL,
  `PreferredVendor` varchar(250) DEFAULT NULL,
  `ChangedDate` datetime DEFAULT NULL,
  `ChangedBy` int(11) DEFAULT NULL,
  PRIMARY KEY (`LogId`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `broker_asgmt_config_log`
--

LOCK TABLES `broker_asgmt_config_log` WRITE;
/*!40000 ALTER TABLE `broker_asgmt_config_log` DISABLE KEYS */;
INSERT INTO `broker_asgmt_config_log` VALUES (1,5,'New, Good','Elite, Reverse, Mortgage, aaaaa, rrrrr ',50,'','Khanh1 Le1; \'test TESTTEST; MFATest MFANotary; Test Notary; NotaryTest  Test; kuro kami; An Victor; Marvin Test; phuong ttm; Lam VT;','2018-06-06 00:22:31',5),(2,5,'New, Good','Elite, Reverse, Mortgage, aaaaa, rrrrr ',50,'\'Cousre\', \'Cousre1\' ','Khanh1 Le1; \'test TESTTEST; MFATest MFANotary; Test Notary; NotaryTest  Test; kuro kami; An Victor; Marvin Test; phuong ttm; Lam VT; ','2018-06-06 00:27:43',5),(3,5,'New, Good','',50,'\'Cousre\', \'Cousre1\' ','Khanh1 Le1; \'test TESTTEST; MFATest MFANotary; Test Notary; NotaryTest  Test; kuro kami; An Victor; Marvin Test; phuong ttm; Lam VT; ','2018-06-06 00:28:51',5),(4,5,'New, Good, VeryGood, Exellent','Elite, Reverse, Mortgage, aaaaa, rrrrr ',25,'\'Cousre\'','Khanh1 Le1; \'test TESTTEST; MFATest MFANotary; Test Notary; NotaryTest  Test; kuro kami; An Victor; Marvin Test; phuong ttm; Lam VT; ','2018-06-06 01:45:13',5),(5,5,'','Elite, Reverse, Mortgage, aaaaa, rrrrr ',0,'','','2018-06-06 10:34:51',5),(6,76,'New,Good,VeryGood,Excellent','Elite, Reverse, Mortgage, aaaaa, rrrrr ',10,'\'Cousre\', \'Cousre1\' ','Khanh1 Le1, khanh le ','2018-06-13 01:53:57',381),(7,76,'New,Good,VeryGood,Excellent','Elite, Reverse, Mortgage, aaaaa, rrrrr ',10,'\'Cousre\', \'Cousre1\' ','Khanh1 Le1, khanh le ','2018-06-13 01:54:22',381),(8,76,'New,Good,VeryGood,Excellent','Elite, Reverse, Mortgage, aaaaa, rrrrr ',10,'\'Cousre\', \'Cousre1\' ','Khanh1 Le1, khanh le ','2018-06-13 02:10:18',381),(9,76,'New,Good,VeryGood,Excellent','Elite, Reverse, Mortgage, aaaaa, rrrrr ',10,'\'Cousre\', \'Cousre1\' ','Khanh1 Le1, khanh le ','2018-06-13 02:10:19',381),(10,76,'New,Good,VeryGood,Excellent','Elite, Reverse, Mortgage, aaaaa, rrrrr ',10,'\'Cousre\', \'Cousre1\' ','Khanh1 Le1, khanh le ','2018-06-13 02:10:22',381),(11,76,'New,Good,VeryGood,Excellent','Elite, Reverse, Mortgage, aaaaa, rrrrr ',10,'\'Cousre\', \'Cousre1\' ','Khanh1 Le1, khanh le ','2018-06-13 02:10:23',381),(12,76,'New,Good,VeryGood,Excellent','Elite, Reverse, Mortgage, aaaaa, rrrrr ',10,'\'Cousre\', \'Cousre1\' ','Khanh1 Le1, khanh le ','2018-06-13 02:10:23',381),(13,76,'New,Good,VeryGood,Excellent','Elite, Reverse, Mortgage, aaaaa, rrrrr ',10,'\'Cousre\', \'Cousre1\' ','khanhlv 2','2018-06-13 02:39:58',381),(14,76,'New,Good,VeryGood,Excellent','Elite, Reverse, Mortgage, aaaaa, rrrrr ',10,'\'Cousre\', \'Cousre1\' ','khanhlv 2','2018-06-13 02:39:58',381),(15,76,'New,Good,VeryGood,Excellent','Elite, Reverse, Mortgage, aaaaa, rrrrr ',10,'\'Cousre\', \'Cousre1\' ','khanhlv 2','2018-06-13 02:39:58',381),(16,76,'Good','',NULL,'','','2018-06-13 02:40:08',381),(17,76,'','',NULL,'','','2018-06-20 02:38:04',381),(18,5,'','',NULL,'Program,  Program1 ','','2018-06-20 03:18:21',5),(19,5,'','',NULL,'Program,  Program1 ','','2018-06-20 05:31:32',5),(20,5,'','',NULL,'Program,  Program1 ','','2018-06-20 05:31:42',5),(21,5,'','',NULL,'Program,  Program1 ','Lam VT','2018-06-20 05:32:20',5),(22,5,'','',NULL,'Program,  Program1 ','Lam VT, Tu Huynh ','2018-06-20 06:19:56',5),(23,5,'','',NULL,'','','2018-06-20 06:48:00',5),(24,76,'','',100,'Program1','2131 12322, khanh le ','2018-06-20 07:42:15',381),(25,5,'','',NULL,'Khanh Program','abcd abcd, Lam VT','2018-06-20 08:09:23',5),(26,5,'New, Good','',NULL,'Khanh Program','Khanh Program, Lam VT','2018-06-20 08:10:36',5),(27,5,'Good','Reverse Mortgage, aaaaa',100,'Khanh Program, Program1','Khanh Program, Program1, Lam VT','2018-06-20 08:10:56',5),(28,1,'','',NULL,'',', aaaaa aaaaaa','2018-06-27 04:02:00',1),(29,1,'','',NULL,'',', aaaaa aaaaaa','2018-06-27 04:02:00',1),(30,5,'Good','2,4,1',25,'114,101','82,83','2018-06-28 09:44:15',5),(31,5,'Good','Reverse Mortgage, aaaaa, Elite',25,'Khanh Program, Program1, Program, Program2','Khanh Program, Program1, Program, Program2, \"an dfa\"','2018-06-28 13:43:40',5),(32,5,'Good, New, VeryGood','2,4,1,40,41',25,'114,101,100,102','\'ab \'bc, \"an dfa\"','2018-06-28 13:57:51',5),(33,5,'Good, New, VeryGood','2,4,1,40,41',25,'','\'ab \'bc, \"an dfa\"','2018-06-28 14:23:24',5),(34,5,'Good, New, VeryGood','2,4,1,40,41',25,'','Lam VT, Ameenah J. Abdulla, Tammy L. Sutherland-Abbott, Stuart S. Cudaback-Cox, Paula Y. Cable, adsfadsf fadf, \'\'\'\'\'\'abc \'\'\'\', \'ab \'bc, \"an dfa\"','2018-06-28 14:27:58',5),(35,5,'Good, New, VeryGood','2,4,1,40,41',25,'100,101,102,103','Lam VT, Ameenah J. Abdulla, Tammy L. Sutherland-Abbott, Stuart S. Cudaback-Cox, Paula Y. Cable, adsfadsf fadf, \'\'\'\'\'\'abc \'\'\'\', \'ab \'bc, \"an dfa\"','2018-06-28 14:28:13',5),(36,5,'Good, New, VeryGood','2,4,1,40,41',25,'100,101,102,103,104','Lam VT, Ameenah J. Abdulla, Tammy L. Sutherland-Abbott, Stuart S. Cudaback-Cox, Paula Y. Cable, adsfadsf fadf, \'\'\'\'\'\'abc \'\'\'\', \'ab \'bc, \"an dfa\"','2018-06-28 14:56:58',5);
/*!40000 ALTER TABLE `broker_asgmt_config_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-02 19:08:55
