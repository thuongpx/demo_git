CREATE TABLE IF NOT EXISTS `training_programs` (
	`ProgramId` INT(11) NOT NULL AUTO_INCREMENT,
	`Title` VARCHAR(250) NOT NULL,
	`IsActive` BIT NULL,
	`SortOrder` TINYINT NULL,
    `CreatedBy` INT,
    `CreatedDate` DATETIME,
    PRIMARY KEY (`ProgramId`)
);