use tce_dev;

CREATE TABLE IF NOT EXISTS `notification_templates` (
	`NotifID` INT(11) NOT NULL AUTO_INCREMENT,
    `Type` VARCHAR(15) NULL,
    `Purpose` VARCHAR(50) NULL,
    `FromName` VARCHAR(100) NULL,
    `FromEmail` VARCHAR(100) NULL,
    `Receiver` VARCHAR(50) NULL,
    `Subject` VARCHAR(300) NULL,
    `Message` VARCHAR(4000) NULL,
    PRIMARY KEY (`NotifID`)
);