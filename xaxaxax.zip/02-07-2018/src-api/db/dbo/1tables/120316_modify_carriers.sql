
ALTER TABLE `carriers` 
DROP FOREIGN KEY `TeanantId_carriers`;
ALTER TABLE `carriers` 
DROP COLUMN `TenantId`,
DROP INDEX `TeanantId_carriers_idx` ;

ALTER TABLE `courier` 
DROP FOREIGN KEY `tenantID_courier`;
ALTER TABLE `courier` 
DROP COLUMN `TenantId`,
DROP INDEX `tenantID_courier_idx` ;
