CREATE TABLE IF NOT EXISTS `customer_donotuse` (
	`Id` INT(11) NOT NULL AUTO_INCREMENT,
    `CustomerId` INT(11) NOT NULL,
    `SignerId` INT(11) NOT NULL,
    `Comment` VARCHAR(2000),
    `Timestamp` DATETIME,
    PRIMARY KEY (`Id`)
);