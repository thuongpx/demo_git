import Boom from "boom";
import Bookshelf from "../../db/database";
import BrokerFee from "../../db/model/broker-fee";

class BrokerFeeController {
    constructor() { }

    getBrokerFeeByBrokerId(request, reply) {
        const { brokerId } = request.query;
        const rawSql = `
        select 
        bf.feeId, bf.brokerFee, bf.feeDescription as description
        from broker_fee bf
        where brokerId= ${brokerId} `;
        Bookshelf.knex.raw(rawSql).then((result) => {
            reply(result[0]);
        }).catch(error => reply(Boom.badRequest(error)));

    }

    updateBrokerFee(request, reply) {
        const brokerFee = request.payload;
        BrokerFee.where({ feeId: brokerFee.feeId }).save(brokerFee, { method: "update" })
            .then(() => {
                reply({ isSuccess: true });
            }).catch(error => reply(Boom.badRequest(error)));
    }

}

export default new BrokerFeeController();