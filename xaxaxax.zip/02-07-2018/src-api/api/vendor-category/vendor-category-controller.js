import Boom from "boom";
import VendorCategory from "./../../db/model/vendor-categories";

class VendorCategoryController {
    constructor() { }
    getCategories(request, reply) {
        new VendorCategory().fetchAll({ columns: ["catId", "catName", "minOrder", "minRating", "minRMOrder", "color"] }).then((categories) => {
            reply(categories);
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}
export default new VendorCategoryController();