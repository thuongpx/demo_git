import LoanType from "../../db/model/loan-type";
import SubLoanTypes from "../../db/model/sub-loan-types";
import IndustryTransactionFees from "../../db/model/industry_transaction_fees";
import BrokerFee from "../../db/model/broker-fee";
import CustomerProductType from "../../db/model/customer-product-type";
import AnnouncementLoanType from "../../db/model/announcement-loan-type";

import Boom from "boom";
import Bookshelf from "../../db/database";
import {
	handleSingleQuote
} from "../../helper/common-helper";

class ProductTypeController {
	constructor() { }
	//Check Exist Loan Type
	checkExistProductType(request, reply) {
		const {
			loanType
		} = request.query;
		LoanType.where({
			loanType
		}).count("*").then((count) => {
			const isExist = count > 0;
			reply({
				isExist
			});
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
		return;
	}
	//Get All Loan Type
	getProductType(request, reply) {
		const {
			loanTypeName,
			sortColumn,
			sortDirection,
			page,
			itemPerPage
		} = request.query;
		const rawSql = `call GetAllProductType(
			${loanTypeName === undefined ? null : `'${handleSingleQuote(loanTypeName)}'`},
            '\`${sortColumn}\`',
            ${sortDirection},
            ${page},
            ${itemPerPage} 
		);`;
		Bookshelf.knex.raw(rawSql)
			.then((result) => {
				if (result !== null) {
					reply({
						productTypes: result[0][0],
						totalRecords: result[0][1][0].TotalRecords
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		return reply;
	}
	//Sub task delete main item from LoanType table
	deleteLoanTypeItem(loanTypeId, reply) {
		//Delete item in loan_type
		LoanType.where(loanTypeId).destroy().then((result) => {
			if (result !== null) {
				LoanType.where(loanTypeId).destroy().then(() => {
					if (result !== null) {
						reply({
							isSuccess: true
						});
					}
				}).catch((error) => {
					reply(Boom.badRequest(error));
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
		return reply;
	}
	// Delete a Loan Type
	deleteProductType(request, reply) {
		const loanTypeId = request.payload;
		//Delete item in announcements_loan_type
		AnnouncementLoanType.where(loanTypeId).destroy().then((resultAnnouncementLoanType) => {
			if (resultAnnouncementLoanType !== null) {
				//Delete item in broker_fee
				BrokerFee.where(loanTypeId).destroy().then((resultBrokerFee) => {
					if (resultBrokerFee !== null) {
						//Delete item in customer_product_type
						CustomerProductType.where({ productType: loanTypeId.loanTypeId }).destroy().then((resultCustomerProductType) => {
							if (resultCustomerProductType !== null) {
								//Delete item in industry_transaction_fees
								IndustryTransactionFees.where(loanTypeId).destroy().then((resultIndustryTransactionFees) => {
									if (resultIndustryTransactionFees !== null) {
										//Delete item in loan_type_sub
										SubLoanTypes.where(loanTypeId).destroy().then((resultSubLoanTypes) => {
											if (resultSubLoanTypes !== null) {
												//Delete main item
												//START Delete item in loan_type
												LoanType.where(loanTypeId).destroy().then((result) => {
													if (result !== null) {
														LoanType.where(loanTypeId).destroy().then(() => {
															if (result !== null) {
																reply({
																	isSuccess: true
																});
															}
														}).catch((error) => {
															reply(Boom.badRequest(error));
														});
													}
												}).catch((error) => {
													reply(Boom.badRequest(error));
												});
												return reply;
												//END Delete item in loan_type
											}
										}).catch((error) => {
											reply(Boom.badRequest(error));
										});
									}
								}).catch((error) => {
									reply(Boom.badRequest(error));
								});
							}
						}).catch((error) => {
							reply(Boom.badRequest(error));
						});
					}
				}).catch((error) => {
					reply(Boom.badRequest(error));
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}
	// Add Loan Type
	addProductType(request, reply) {
		const input = request.payload;
		new LoanType().save({
			LoanTypeId: input.LoanTypeId,
			LoanType: input.LoanType
		}, {
				method: "insert"
			}).then(() => reply({ isSuccess: true })).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}
	//Update Loan Type Name
	updateProductType(request, reply) {
		const input = request.payload;
		LoanType.where({
			LoanTypeId: input.LoanTypeId
		}).save({
			LoanType: input.LoanType
		}, {
				method: "update"
			}).then((result) => {
				if (result !== null) {
					reply({
						isSuccess: true
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}
}

export default new ProductTypeController();