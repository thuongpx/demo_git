import Boom from "boom";
import Bookshelf from "../../db/database";
// import VendorTestResult from "../../db/model/vendor-test-result";
// import moment from "moment";

class VendorNotaryExam {
    constructor() { }

    async getCheckValidExamAndGetTestQaByTestId(request, reply) {
        const { programId, testId, vendorId } = request.query;
        let isValid = true;
        let data = [];

        const rawSqlCheck = `select count(t.TestId) AS countTestId from training_program_test as tpt
                            inner join test_info as t on t.TestId = tpt.TestId
                            inner join test_sections as ts on ts.TestId = t.TestId
                            inner join test_qa as tq on tq.SectionId = ts.SectionId and tq.TestId = ts.TestId
                            where tpt.TestId = ${testId} and tpt.ProgramId = ${programId} ;`;
        await new Promise(resolve => {
            Bookshelf.knex.raw(rawSqlCheck).then((result) => {
                if (result !== null) {
                    if (result[0][0].countTestId === 0) {
                        isValid = false;
                    } else {
                        isValid = true;
                    }
                } else {
                    isValid = false;
                }
                resolve();
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        });

        if (isValid === true) {
            const rawSqlCheckPass = `select count(t.MaxAttempts) AS countMaxAttempts, t.MaxAttempts, t.Lockdays, vtr.LastTesting, vtr.Passed, vtr.TestedNum from training_program_test as tpt
                                        inner join test_info as t on t.TestId = tpt.TestId
                                        inner join vendor_test_result as vtr on vtr.TestId = t.TestId and vtr.ProgramId = tpt.ProgramId
                                        where tpt.TestId = ${testId} and tpt.ProgramId = ${programId} and vtr.VendorId = ${vendorId};`;
            await new Promise(resolve => {
                Bookshelf.knex.raw(rawSqlCheckPass)
                    .then((result) => {
                        if (result[0][0].MaxAttempts !== 0) {
                            const daysDiff = (new Date() - new Date(result[0][0].LastTesting)) / 1000 / 60 / 60 / 24;
                            if (result[0][0].Passed === "Y" || (result[0][0].Passed === "N" && result[0][0].TestedNum >= result[0][0].MaxAttempts && daysDiff < result[0][0].Lockdays)) {
                                isValid = false;
                            } else {
                                isValid = true;
                            }
                        } else {
                            isValid = true;
                        }
                        resolve();
                    }).catch((error) => {
                        reply(Boom.badRequest(error));
                    });
            });
        }
        const rawSql = `select t.TestName, t.TestDesc, t.PassPercent, t.MaxAttempts, t.Lockdays, tq.QuestionId, tq.Question, tq.A, tq.B, tq.C, tq.D, tq.E from training_program_test as tpt
                            inner join test_info as t on t.TestId = tpt.TestId
                            inner join test_sections as ts on ts.TestId = t.TestId
                            inner join test_qa as tq on tq.SectionId = ts.SectionId and tq.TestId = ts.TestId
                            where tpt.TestId = ${testId} and tpt.ProgramId = ${programId}`;
        await new Promise(resolve => {
            Bookshelf.knex.raw(rawSql)
                .then((result) => {
                    if (result !== null) {
                        data = result[0];
                    }
                    resolve();
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                });
        });
        reply({ isValid, data });
    }
}
export default new VendorNotaryExam();