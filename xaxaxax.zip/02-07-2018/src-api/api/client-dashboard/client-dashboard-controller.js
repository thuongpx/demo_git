import Boom from "boom";
import Bookshelf from "./../../db/database";

class ClientDashboardController {
    constructor() { }

    getUnfilledOrderDashboard(request, reply) {
        const {
            page,
            itemPerPage,
            role,
            clientId
        } = request.query;
        const rawSqlUnfilledOrder = `call GetUnfilledOrderDashboard(${page},${itemPerPage},'${role}',${clientId})`;

        Bookshelf.knex.raw(rawSqlUnfilledOrder)
            .then((result) => {
                if (result !== null) {
                    reply({
                        unfilledOrdersApproachingList: result[0][0],
                        unfilledOrdersApproachingTotalRecord: result[0][1][0].TotalRecordsUnfilledApproaching,
                        unfilledOrdersOutList: result[0][2],
                        unfilledOrdersOutTotalRecord: result[0][3][0].TotalRecordsUnfilledOut
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getPendingOrderDashboard(request, reply) {
        const {
            page,
            itemPerPage,
            role,
            clientId
        } = request.query;
        const rawSqlPendingOrder = `call GetPendingOrderDashboard(${page},${itemPerPage},'${role}',${clientId})`;

        Bookshelf.knex.raw(rawSqlPendingOrder)
            .then((result) => {
                if (result !== null) {
                    reply({
                        pendingOrdersApproachingList: result[0][0],
                        pendingOrdersApproachingTotalRecord: result[0][1][0].TotalRecordsPendingApproaching,
                        pendingOrdersOutList: result[0][2],
                        pendingOrdersOutTotalRecord: result[0][3][0].TotalRecordsPendingOut
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getFaxbacksOrderDashboard(request, reply) {
        const {
            page,
            itemPerPage,
            role,
            clientId
        } = request.query;
        const rawSqlFaxbacksOrder = `call GetFaxbacksOrderDashboard(${page},${itemPerPage},'${role}',${clientId})`;

        Bookshelf.knex.raw(rawSqlFaxbacksOrder)
            .then((result) => {
                if (result !== null) {
                    reply({
                        faxbacksOrdersList: result[0][0],
                        faxbacksOrdersTotalRecord: result[0][1][0].TotalRecordsFaxbacks
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
}

export default new ClientDashboardController();