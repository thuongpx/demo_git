import CarrierController from "./carrier-controller";

const routes = [{
    path: "/carrier/getAllCarriersForDropDown",
    method: "GET",
    handler: CarrierController.getAllCarriersForDropDown
}];

export default routes;