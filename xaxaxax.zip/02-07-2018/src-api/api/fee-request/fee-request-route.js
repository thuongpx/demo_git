import GetFeeRequest from "./fee-request-controller";

const routes = [
    {
        path: "/feeRequest/getFeeRequest",
        method: "GET",
        handler: GetFeeRequest.getFeeRequest
    }
];

export default routes;