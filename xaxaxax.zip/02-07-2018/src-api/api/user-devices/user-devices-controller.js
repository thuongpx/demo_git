import Boom from "boom";
import UserDevice from "../../db/model/user-device";
import Order from "../../db/model/order";
import moment from "moment";
class UserDevicesController {
    signInOutDevice(request, reply) {
        let { isSignedIn } = request.payload;
        const { usersId, deviceId } = request.payload;
        isSignedIn = isSignedIn.toLowerCase() === "true";
        if (isSignedIn) {
            UserDevice.where({ usersId, deviceId }).count("usersId").then((count) => {
                if (count === 0) {
                    new UserDevice().save({ usersId, deviceId, isSignedIn }, { method: "insert" }).then(() => {
                        reply({ isSuccess: true });
                    });
                } else {
                    UserDevice.where({ usersId, deviceId }).save({ isSignedIn }, { method: "update" }).then(() => {
                        reply({ isSuccess: true });
                    }).catch(err => reply(Boom.badRequest(err)));
                }
            }).catch(err => reply(Boom.badRequest(err)));
        }
        else {
            UserDevice.where({ usersId, deviceId }).save({ isSignedIn }, { method: "update" }).then(() => {
                reply({ isSuccess: true });
            }).catch(err => reply(Boom.badRequest(err)));
        }
    }
}

export default new UserDevicesController();