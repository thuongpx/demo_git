import Boom from "boom";
import Bookshelf from "./../../db/database";
import Broker from "../../db/model/brokers";
import Order from "../../db/model/order";
import OrderSpecificIns from "../../db/model/order_special_instructions";
import { hasStringValue } from "../../helper/common-helper";
import ReturnAddress from "../../db/model/return-addr";

class OrderSpecController {
    constructor() { }

    getOrderSpecificsData(request, reply) {
        const { orderId } = request.query;

        const getOrderCollectById = Promise.resolve(Bookshelf.knex.raw(`call GetOrderSpecificData(${orderId})`));
        const getAllState = Promise.resolve(Bookshelf.knex.raw(`call GetAllState`));

        Promise.all([getOrderCollectById, getAllState])
            .then(values => {
                const data = {};

                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.orderSpecificData = item[0][0];
                                    data.lenderSpecific = "";

                                    if (item[0][1].length > 0) {
                                        data.lenderSpecific = item[0][1][0].LenderSpecific;
                                    }

                                    data.orderInstructionsList = item[0][2];
                                    data.ccEmailsList = item[0][3];
                                    data.ccInvEmailsList = item[0][4];
                                    data.returnAddressList = item[0][5];
                                    break;
                                case 1:
                                    data.stateList = item[0][0];
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });

        return reply;
    }

    updateOrderSpecific(request, reply) {
        const { instructionInfo, orderSpecInfo, brokerSpecificInfo, address } = request.payload;

        if (orderSpecInfo === undefined || brokerSpecificInfo === undefined) {
            reply(Boom.badRequest("Missing required values"));
            return reply;
        }

        //update order specific
        const orderId = orderSpecInfo.OrderId;
        const brokerId = orderSpecInfo.BrokerId;

        if (!hasStringValue(orderId)) {
            reply(Boom.badRequest("Missing order id value"));
            return reply;
        }
        // new return address
        const newAddress = new ReturnAddress({
            BrokerId: brokerId,
            Address: address.Address,
            City: address.City,
            State: address.State,
            Zip: address.Zip,
            DefaultAddr: address.DefaultAddr,
            BranchId: address.BranchId
        });

        // udpate order data
        const updateOrder = Promise.resolve(Order.where({ OrderId: orderId })
            .save(orderSpecInfo, { method: "update" }));

        // update construction
        const updateConstruction = Promise.resolve(OrderSpecificIns.where({ OrderId: orderId })
            .save(instructionInfo, { method: "update" }));

        // list of task need to do
        const queue = [updateOrder, updateConstruction];

        // if the order has a broker, the lender specific will be updated for the broker
        if (brokerId > 0) {
            // update broker lender specific
            const updateBroker = Promise.resolve(Broker.where({ BrokerID: brokerId })
                .save(brokerSpecificInfo, { method: "update" }));
            queue.push(updateBroker);
        }

        // if new return address is defined, add it to DB and set for order
        if (address.IsNewAddress && brokerId > 0) {
            queue.push(Promise.resolve(newAddress.save(null, { method: "insert" })));
        }

        // execute update order data
        Promise.all(queue).then(() => {
            reply({ isSuccess: true });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

        return reply;
    }

    updateOrderSpecialIns(request, reply) {
        const specInsData = request.payload;
        const rawData = {};
        rawData.Instructions1 = specInsData.Instructions1 || "";
        rawData.Instructions2 = specInsData.Instructions2 || "";
        rawData.Instructions3 = specInsData.Instructions3 || "";
        rawData.Instructions4 = specInsData.Instructions4 || "";
        rawData.Instructions5 = specInsData.Instructions5 || "";
        rawData.Instructions6 = specInsData.Instructions6 || "";
        rawData.Instructions7 = specInsData.Instructions7 || "";
        rawData.Instructions8 = specInsData.Instructions8 || "";
        rawData.Instructions9 = specInsData.Instructions9 || "";
        rawData.Instructions10 = specInsData.Instructions10 || "";

        OrderSpecificIns.where({ OrderId: specInsData.orderId }).count("*")
            .then(count => {
                if (count) {
                    OrderSpecificIns.where({ OrderId: specInsData.orderId }).save(rawData, { method: "update" })
                        .then(() => {
                            reply({ isSuccess: true });
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                } else {
                    rawData.OrderId = specInsData.orderId;
                    new OrderSpecificIns(rawData).save(null, { method: "insert" })
                        .then(() => {
                            reply({ isSuccess: true });
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                }
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }
}

export default new OrderSpecController();