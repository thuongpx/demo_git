import Boom from "boom";
import Bookshelf from "./../../db/database";
import moment from "moment";
import { bufferToBoolean, getUsersIdByMappingUserIdAndRoleName, replaceAll } from "../../helper/common-helper";
import { sendSNSMessage } from "../../helper/sns-helper";
import OrderDocs from "../../db/model/order-docs";
import { UPLOAD_PATH } from "../../helper/file-helper";
import fs from "fs";
import Order from "./../../db/model/order";
import OrderProgressLog from "./../../db/model/order-progress-log";
import { NOTIFICATION_TEMPLATE_PURPOSE } from "../../constant/common-constant";
import sendMailCore from "../../mail/mail-helper";
import { handleSingleQuote } from "../../helper/common-helper";
import OrderDocComment from "../../db/model/order-doc-comment";
import Agent from "../../db/model/agents";
import Broker from "../../db/model/brokers";
import Signer from "../../db/model/signers";
import NotificationTemplate from "../../db/model/notification-management";
import config from "../../config/config";

class OrderDocController {
    constructor() { }

    getOrderDoc(request, reply) {
        const {
            orderId
        } = request.query;

        Bookshelf.knex.raw(`select * from order_docs where UploadedDate >= DATE(UTC_TIMESTAMP()) - INTERVAL 60 DAY and OrderId = (${orderId})`)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0]
                    });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    getDocGrid(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            orderId,
            docType
        } = request.query;

        const rawSql = `call GetDocGrid('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId}, ${docType})`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    const data = result[0][0];

                    result[0][0].forEach((item) => {

                        item.Viewed = bufferToBoolean(item.Viewed);
                        item.UploadedDate = item.UploadedDate ? moment(item.UploadedDate).format("MM/DD/YY HH:mm:ss") : "";
                        item.DownloadDate = item.DownloadDate ? moment(item.DownloadDate).format("MM/DD/YY HH:mm:ss") : "";
                        item.ReviewDate = item.ReviewDate ? moment(item.ReviewDate).format("MM/DD/YY HH:mm:ss") : "";
                    });
                    const obj = { data };
                    obj[`totalRecords${docType}`] = result[0][1][0].TotalRecords;
                    reply(obj);

                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return;
            });

        return reply;
    }


    getDocGridMultiple(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            orderId
        } = request.query;
        const rawSql1 = Promise.resolve(Bookshelf.knex.raw(`call GetDocGrid('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId}, ${1})`));
        const rawSql2 = Promise.resolve(Bookshelf.knex.raw(`call GetDocGrid('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId}, ${2})`));
        Promise.all([rawSql1, rawSql2])
            .then(value => {
                const result = {};
                if (value !== null) {
                    // reply(value);
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    item[0][0].forEach((itemSub) => {

                                        itemSub.Viewed = bufferToBoolean(itemSub.Viewed);
                                        itemSub.UploadedDate = itemSub.UploadedDate ? moment(itemSub.UploadedDate).format("MM/DD/YY HH:mm:ss") : "";
                                        itemSub.DownloadDate = itemSub.DownloadDate ? moment(itemSub.DownloadDate).format("MM/DD/YY HH:mm:ss") : "";
                                        itemSub.ReviewDate = itemSub.ReviewDate ? moment(itemSub.ReviewDate).format("MM/DD/YY HH:mm:ss") : "";
                                    });

                                    result.data1 = item[0][0];
                                    result.totalRecords1 = item[0][1][0].TotalRecords;

                                    break;
                                case 1:
                                    item[0][0].forEach((itemSub) => {

                                        itemSub.Viewed = bufferToBoolean(itemSub.Viewed);
                                        itemSub.UploadedDate = itemSub.UploadedDate ? moment(itemSub.UploadedDate).format("MM/DD/YY HH:mm:ss") : "";
                                        itemSub.DownloadDate = itemSub.DownloadDate ? moment(itemSub.DownloadDate).format("MM/DD/YY HH:mm:ss") : "";
                                        itemSub.ReviewDate = itemSub.ReviewDate ? moment(itemSub.ReviewDate).format("MM/DD/YY HH:mm:ss") : "";
                                    });

                                    result.data2 = item[0][0];
                                    result.totalRecords2 = item[0][1][0].TotalRecords;
                            }
                        }
                    });
                }
                reply(result);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    insertOrderDoc(request, reply) {
        const data = request.payload;

        const newOrderDoc = new OrderDocs();
        newOrderDoc.save({
            OrderId: data.OrderId,
            TenantId: data.TenantId,
            Description: data.Description,
            DocumentType: data.DocumentType,
            UserId: data.UserId,
            FileSize: data.FileSize,
            UploadedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        }, { method: "insert" }).then(async () => {
            let signerId = 0;
            await new Promise((resolve => Order.where({ orderId: data.OrderId }).fetch({ columns: ["signerId"] }).then((model) => {
                signerId = model.get("signerId");
                resolve();
            })));
            if (signerId !== null) {
                const activity = `Order ${data.OrderId} has new docs uploaded and ready to be downloaded.`;
                const usersId = await getUsersIdByMappingUserIdAndRoleName(signerId, "Vendor");
                await new Promise((resolve => new OrderProgressLog().save({ orderId: data.OrderId, dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"), progressType: 5, activity, usersId }, { method: "insert" }).then(() => {
                    resolve();
                })));
                sendSNSMessage(usersId, `{\\"aps\\":{\\"alert\\":\\"${activity}\\",\\"type\\":\\"document\\",\\"orderId\\":\\"${data.OrderId}\\"}}`);
            }
            reply(1);
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    archiveOrderDoc(request, reply) {
        const { docId } = request.payload;
        OrderDocs.where({ docId }).save(
            { archive: true }, { method: "update" }).then((result) => {
                if (result !== null) {
                    OrderDocs.where({ docId }).fetch({ columns: ["docId", "description", "orderId", "documentType"] }).then((doc) => {
                        const description = doc.get("description");
                        const orderId = doc.get("orderId");
                        const documentType = doc.get("documentType");
                        const fileName = description;
                        const archivedFileName = `ARCHIVED-${docId}-${description}`;
                        const docFolderName = documentType.toString() === "1" ? "uploadedDocs" : "signedDocs";
                        console.log(documentType);
                        const folderPath = `${config.file.serverPath}/upload/orderDocs/${docFolderName}/${orderId}/`;
                        fs.rename(`${folderPath}${fileName}`, `${folderPath}${archivedFileName}`, (err) => {
                            if (err) console.log(err);
                            reply({ isSuccess: true });
                        });
                    }).catch((error) => {
                        reply(Boom.badRequest(error));
                    });

                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    updateOrderDoc(request, reply) {
        const data = request.payload;
        delete data.userName;
        OrderDocs.where({ DocId: data.DocId }).save(
            data, { method: "update" }).then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
    deleteOrderDoc(request, reply) {
        const { docId } = request.payload;
        OrderDocs.where({ DocId: docId }).fetch({ columns: ["DocId", "OrderId", "DocumentType", "Description"] }).then((orderDoc) => {
            if (orderDoc !== null) {
                const orderId = orderDoc.get("OrderId");
                const docType = orderDoc.get("DocumentType");
                let docName = orderDoc.get("Description");
                docName = `ARCHIVED-${orderDoc.get("DocId")}-${docName}`;
                //delete db data
                OrderDocs.where({ DocId: docId }).destroy().then(() => {
                    //find patch
                    let filePath = `${UPLOAD_PATH}/orderDocs/uploadedDocs/${orderId}/${docName}`;
                    if (docType === `2`) {
                        filePath = `${UPLOAD_PATH}/orderDocs/signedDocs/${orderId}/${docName}`;
                    }
                    //delete raw file
                    try {
                        fs.unlinkSync(filePath);
                    } catch (error) {
                        // do nothing
                    }
                    //show result
                    reply({ isSuccess: true });
                }).catch((error) => reply(Boom.badRequest(error)));
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
        return reply;
    }

    deleteMultipleOrderDoc(request, reply) {
        const docList = request.payload;
        OrderDocs.where("DocId", "in", docList).destroy().then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    downloadOrderDoc(request, reply) {
        const { docId, docType } = request.query;
        OrderDocs.where({ docId }).fetch({ columns: ["OrderId", "DocId", "Description", "Archive"] }).then((orderDoc) => {
            const orderId = orderDoc.get("OrderId");
            let docName = orderDoc.get("Description");
            const archive = bufferToBoolean(orderDoc.get("Archive"));
            // const fileName = `${docName}`;
            if (archive) {
                docName = `ARCHIVED-${orderDoc.get("DocId")}-${docName}`;
            }
            let filePath = `${UPLOAD_PATH}/orderDocs/uploadedDocs/${orderId}/${docName}`;
            if (Number(docType) === 2) {
                filePath = `${UPLOAD_PATH}/orderDocs/signedDocs/${orderId}/${docName}`;
            }

            if (fs.existsSync(filePath)) {
                // serve file
                reply.file(filePath);
            } else {
                reply(Boom.badRequest(`File ${docName} is not exists.`));
            }
        }).catch((error) => reply(Boom.badRequest(error)));
    }

    checkDocName(request, reply) {
        const {
            orderId,
            docType,
            docName
        } = request.query;
        const listName = docName.split(",");
        const Queue = [];
        listName.forEach((nameItem, index) => {
            const p = Promise.resolve(Bookshelf.knex.raw(`select ${index} as Pos, FileSize, Description, DocId, Status from order_docs where OrderId = ${orderId} and (archive is null or archive =0) and  DocumentType = ${docType} and Description like '${nameItem}%'`));
            Queue.push(p);
        });
        const p = Promise.resolve(Bookshelf.knex.raw(`select sum(FileSize) as oldSize from order_docs where OrderId = ${orderId} and DocumentType = ${docType}`));
        Queue.push(p);
        Promise.all(Queue)
            .then(value => {
                const fileName = [];
                const fileSize = [];
                const fileId = [];
                const fileStatus = [];
                const oldSize = value.pop()[0][0].oldSize;
                for (let i = 0; i < listName.length; i++) {
                    fileName.push([]);
                    fileSize.push([]);
                    fileId.push([]);
                    fileStatus.push([]);
                }
                if (value !== null) {
                    value.forEach((item) => {
                        if (item !== null) {
                            const subListName = [];
                            const subListSize = [];
                            const subListId = [];
                            const subListStatus = [];
                            item[0].forEach((x) => {
                                subListName.push(x.Description);
                                subListSize.push(x.FileSize ? x.FileSize : 0);
                                subListId.push(x.DocId ? x.DocId : -1);
                                subListStatus.push(x.Status);
                            });
                            if (item[0][0]) {
                                fileName[item[0][0].Pos] = subListName;
                                fileSize[item[0][0].Pos] = subListSize;
                                fileId[item[0][0].Pos] = subListId;
                                fileStatus[item[0][0].Pos] = subListStatus;
                            }
                        }
                    });
                }
                reply({ fileName, fileSize, fileId, oldSize, fileStatus });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    shareAllDocsByOrderId(request, reply) {
        let { orderId } = request.query;

        if (isNaN(orderId)) {
            reply(Boom.badRequest("Invalid parameters"));

            return;
        }

        orderId = +orderId;

        const sqlUpdate = `UPDATE order_docs SET shared = 1 WHERE orderId = ${orderId} AND shared = 0 AND (Archive IS NULL or Archive <> 1)`;

        Bookshelf.knex.raw(sqlUpdate).then(result => {
            const affectedRows = result[0].affectedRows;

            if (affectedRows > 0) {
                reply({ isSuccess: true, affectedRows });
                return;
            }
            reply(Boom.badRequest("No row affected!"));
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }

    getListRejectReason(request, reply) {
        const rawSql = "Select * from docs_denial_reasons;";

        Bookshelf.knex.raw(rawSql).then(result => {
            const listRejectCode = result[0];

            reply({ listRejectCode });
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }

    async sendEmailRejectSignedDoc(request, reply) {
        const { docId, orderId } = request.query;
        let data = {};
        let templateMail = {};
        let listComment = [];

        //get data to send mail by docId
        const rawSqlGetOrderData = `SELECT o.OrderId, s.FirstName, s.LastName, od.Description, ddr.ReasonCode, od.Comment, s.Email FROM order_docs od 
        join \`order\` o on o.OrderId = od.OrderId
        join \`signer\` s on o.SignerId = s.SignerId
        join \`docs_denial_reasons\` ddr on ddr.ReasonID = od.RejectReason
        where o.orderid = ${orderId} and DocumentType =2 and od.DocId = ${docId};`;

        await new Promise(resolve => Bookshelf.knex.raw(rawSqlGetOrderData)
            .then(result => {
                if (result[0][0]) data = result[0][0];
                resolve();
            }).catch(err => {
                reply(Boom.badRequest(err));
            })
        );

        //get comment data
        const rawSqlGetCommentData = `SELECT comment FROM order_doc_comment where DocId = ${docId};`;

        await new Promise(resolve => Bookshelf.knex.raw(rawSqlGetCommentData)
            .then(result => {
                if (result[0][0]) listComment = result[0];
                resolve();
            }).catch(err => {
                reply(Boom.badRequest(err));
            })
        );
        let commentStr = ``;

        listComment.forEach(item => {
            commentStr = `${commentStr} <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;${item.comment}`;
        });

        //get template mail to send
        const rawSqlGetTemplate = `SELECT * FROM notification_templates nt WHERE nt.Purpose = '${NOTIFICATION_TEMPLATE_PURPOSE.ORDER_DOCUMENTS_REJECTED}';`;
        await new Promise(resolve => Bookshelf.knex.raw(rawSqlGetTemplate)
            .then(result => {
                if (result[0][0]) templateMail = result[0][0];
                resolve();
            }).catch(err => {
                reply(Boom.badRequest(err));
            })
        );

        //render email content and subject
        const subject = templateMail.Subject.replace("[OrderID]", orderId);
        let htmlContent = templateMail.Message;

        htmlContent = replaceAll(htmlContent, "[vendor_first_name]", data.FirstName);
        htmlContent = replaceAll(htmlContent, "[vendor_last_name]", data.LastName);
        htmlContent = replaceAll(htmlContent, "[document_name_be_rejected]", data.Description);
        htmlContent = replaceAll(htmlContent, "[reason_descrip]", data.ReasonCode);
        htmlContent = replaceAll(htmlContent, "[additional_comment]", commentStr ? commentStr : "N/A");

        const mailOptions = {
            from: templateMail.FromEmail || "weborders@notarydirect.com",
            to: data.Email,
            subject,
            html: htmlContent
        };

        sendMailCore(mailOptions, (result) => {
            reply(result.error ? {
                error: result.error
            } : {
                    isSuccess: true
                });
        });
    }

    getClientDocuments(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            brokerId,
            orderId,
            documentName,
            isAgent
        } = request.payload;

        const rawSql = `call GetClientDocuments(${brokerId},${isAgent},'${orderId}','${handleSingleQuote(documentName)}','${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage})`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getListOrderDocComments(request, reply) {
        const { docId } = request.query;

        const rawSql = `SELECT odc.*, u.UserName, GetFullNameByUserId(odc.CommentBy) as FullName, u.ProfilePicture FROM order_doc_comment odc left join users u on u.UsersId = odc.CommentBy where odc.DocId = ${docId} order by odc.CommentDate asc;`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({ listComments: result[0] || [] });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    addOrderDocAdditionalComment(request, reply) {
        const data = request.payload;

        new OrderDocComment().save(
            data, { method: "insert" }).then(() => {
                reply({ isSuccess: true });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getSignerDocs(request, reply) {
        const { orderId } = request.query;
        const rawSql = `select od.docId, od.description, od.shared,
        (case when od.status is null or od.status = 'O' then 'Open' 
                              when od.status = 'R' then 'Rejected'
                              ELSE 'Approved' end) as status,
        (case when od.viewed = true then 'Viewed' else '' end) as viewed,
        od.uploadedDate, od.reviewDate,od.rejectReason,GetFullNameByUserId(od.userId) uploadedBy,
        GetFullNameByUserId(od.reviewedBy) as reviewedBy
        from  order_docs od 
        where od.orderId=${orderId} and od.documentType = 2 
        and (od.archive is null or od.archive = 0) order by od.uploadedDate`;
        Bookshelf.knex.raw(rawSql).then((result) => {
            const docs = result[0];
            docs.forEach(doc => {
                doc.shared = bufferToBoolean(doc.shared);
            });
            reply(docs);
        }).catch(error => reply(Boom.badRequest(error)));
    }

    shareAllSignerDoc(request, reply) {
        const { orderId } = request.payload;
        OrderDocs.where({ orderId, DocumentType: 2 }).save({ shared: true }, { method: "update" }).then(() => {

            Order.where({ orderId }).fetch({ columns: ["agentId", "brokerId", "brokerIdNum", "signerId", "isSelfService"] }).then(async (order) => {
                const agentId = order.get("agentId");
                const brokerId = order.get("brokerId");
                const brokerIdNum = order.get("brokerIdNum");
                const signerId = order.get("signerId");
                const isSelfService = bufferToBoolean(order.get("isSelfService"));

                let signerFirstName = "";
                let signerLastName = "";
                let agentFirstName = "";
                let agentLastName = "";
                let emailPurpose = "";
                let toEmail = "";

                if (agentId > 0) {
                    await new Promise((resolve) => Agent.where({ agentId }).fetch({ columns: ["firstName", "lastName", "email"] }).then(agent => {
                        agentFirstName = agent.get("firstName");
                        agentLastName = agent.get("lastName");
                        toEmail = agent.get("email");
                        resolve();
                    }).catch(error => reply(Boom.badRequest(error))));
                } else {
                    await new Promise((resolve) => Broker.where({ brokerId }).fetch({ columns: ["company", "email"] }).then(broker => {
                        agentFirstName = broker.get("company");
                        toEmail = broker.get("email");
                        resolve();
                    }).catch(error => reply(Boom.badRequest(error))));
                }

                await new Promise((resolve) => Signer.where({ signerId }).fetch({ columns: ["firstName", "lastName"] }).then(signer => {
                    signerFirstName = signer.get("firstName");
                    signerLastName = signer.get("lastName");
                    resolve();
                }).catch(error => reply(Boom.badRequest(error))));

                if (isSelfService) {
                    emailPurpose = "Signed Document Uploaded - Agent";
                } else {
                    emailPurpose = "Signed Document Uploaded – TCE";
                    toEmail = config.mail.faxBacks;
                }

                NotificationTemplate.where({
                    purpose: emailPurpose
                }).fetch({
                    columns: ["message", "subject", "fromEmail"]
                }).then(async (template) => {
                    let subject = template.get("subject");
                    let message = template.get("message");

                    subject = replaceAll(subject, ["[OrderID]"], `${orderId}`);
                    message = replaceAll(message, ["[OrderID]"], `${orderId}`);
                    message = replaceAll(message, ["[SignerFirstName]"], `${signerFirstName}`);
                    message = replaceAll(message, ["[SignerLastName]"], `${signerLastName}`);
                    message = replaceAll(message, ["[AgentFirstName]"], `${agentFirstName}`);
                    message = replaceAll(message, ["[AgentLastName]"], `${agentLastName}`);
                    message = replaceAll(message, ["[Reference]"], `${brokerIdNum}`);
                    const mailOptions = {
                        from: template.get("fromEmail"),
                        to: toEmail,
                        subject,
                        html: message
                    };
                    sendMailCore(mailOptions);
                });

            }).catch(error => reply(Boom.badRequest(error)));

            reply({ isSuccess: true });
        }).catch(error => reply(Boom.badRequest(error)));
    }
}


export default new OrderDocController();