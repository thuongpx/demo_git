import Boom from "boom";
import Bookshelf from "./../../db/database";
import Order from "./../../db/model/order";
import moment from "moment";
import { handleSingleQuote, bufferToBoolean } from "../../helper/common-helper";

class OrderClientController {
    getOrderClientBranchDropdownDataByClientId(request, reply) {
        const { clientId } = request.query;

        Bookshelf.knex.raw(`select b.BrokerID as BranchID, b.Company as BranchName, b.City, b.State from broker b where b.GID = ${clientId};`)
            .then(value => {
                const data = {};
                if (value !== null) {
                    data.branches = value[0];
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getRecentVendorData(request, reply) {
        const { orderId } = request.query;

        Bookshelf.knex.raw(`SELECT SignerId, CONCAT_WS(" ", FirstName, LastName) AS Name FROM signer WHERE SignerId IN(select SignerId from signer_history where OrderId = ${orderId} union select SignerId FROM signer_offer where OrderId = ${orderId} union select SignerId FROM \`order\` where OrderId = ${orderId});`)
            .then(value => {
                const data = value[0].map((entry) => {
                    return {
                        id: entry.SignerId,
                        name: entry.Name
                    };
                });

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getOrderClientAgentData(request, reply) {
        const {
            clientId,
            branchId,
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            searchString
        } = request.query;

        Bookshelf.knex.raw(`call getOrderClientAgentById(${clientId},${branchId ? branchId : 0},'${searchString}','${sortColumn}',${sortDirection},${page},${itemPerPage});`)
            .then(value => {
                const data = {};

                if (value !== null) {
                    data.agents = value[0][0];
                    data.totalRecords = value[0][1][0].TotalRecords;
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getOrderClientById(request, reply) {
        const {
            orderId
        } = request.query;
        const rawSql = `select o.AgentId, o.OrderId, o.BrokerId, a.BranchID, a.FullName, a.Direct, a.Ext, a.Fax, a.Email, b.AdditionalContact,  b.AdditionalContactEmail, b.AdditionalContactExt, b.AdditionalContactPhone  from \`order\` o left join agent a on o.AgentId = a.AgentId 
                       left join broker b on b.BrokerID = o.BrokerId where o.OrderId = ${orderId};`;

        Bookshelf.knex.raw(rawSql)
            .then(value => {
                if (value !== null) reply({ defaultOrderClient: value[0][0] });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    updateOrderDetailClient(request, reply) {
        const orderDetailClient = request.payload;

        const newData = {
            BrokerId: orderDetailClient.BrokerId,
            AgentId: orderDetailClient.AgentId
        };

        Order.where({ OrderId: orderDetailClient.OrderId })
            .save(newData, { method: "update" })
            .then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                }
            }).catch((error) => {
                reply(error);
            });

        return reply;
    }

    getOrdersClientStaff(request, reply) {
        const {
            sortColumn,
            groupStatus,
            sortDirection,
            page,
            itemPerPage,
            userId,
            clientId,
            role,
            orderId,
            vendorLastName,
            customerLastName,
            companyBranch,
            agentName,
            statusOrder,
            AptDateFrom,
            AptDateTo,
            OrderDateFrom,
            OrderDateTo
        } = request.query;
        // searchValue = (searchValue !== undefined) ? handleSingleQuote(searchValue) : "";
        const newOrderId = (orderId === "" || orderId === undefined) ? null : parseInt(orderId);
        const newVendorLastName = (vendorLastName === "" || vendorLastName === undefined) ? "" : handleSingleQuote(vendorLastName);
        const newCustomerLastName = (customerLastName === "" || customerLastName === undefined) ? "" : handleSingleQuote(customerLastName);
        const newCompanyBranch = (companyBranch === "" || companyBranch === undefined) ? null : parseInt(companyBranch);
        const newAgentName = (agentName === "" || agentName === undefined) ? "" : handleSingleQuote(agentName);
        const newStatusOrder = (statusOrder === "" || statusOrder === undefined) ? null : parseInt(statusOrder);
        const newAptDateFrom = (AptDateFrom === "" || AptDateFrom === undefined) ? "" : moment(handleSingleQuote(AptDateFrom)).format("YYYY-MM-DD").toString();
        const newAptDateTo = (AptDateTo === "" || AptDateTo === undefined) ? "" : moment(handleSingleQuote(AptDateTo)).format("YYYY-MM-DD").toString();
        const newOrderDateFrom = (OrderDateFrom === "" || OrderDateFrom === undefined) ? "" : moment(handleSingleQuote(OrderDateFrom)).format("YYYY-MM-DD").toString();
        const newOrderDateTo = (OrderDateTo === "" || OrderDateTo === undefined) ? "" : moment(handleSingleQuote(OrderDateTo)).format("YYYY-MM-DD").toString();
        let andWhere = "AND (1=1";

        let groupsQuery = "";
        switch (groupStatus) {
            case "Open":
                groupsQuery = `"Open"`;
                break;
            case "Assigned":
                groupsQuery = `"Assigned to Vendor", "Appt Confirmed Pending Docs", "Pending Pre-call"`;
                break;
            case "Appt Ready":
                groupsQuery = `"Appt Ready"`;
                break;
            case "Closed Pending":
                groupsQuery = `"Closed Pending Review/PC Resolution", "Closed Pending QC Review"`;
                break;
            case "Closing Complete":
                groupsQuery = `"Closing Completed", "Post Close"`;
                break;
            case "Did Not Close":
                groupsQuery = `"Hold", "Canceled", "Unsuccessful signing attempt"`;
                break;
            default:
                groupsQuery = "";
                break;
        }

        if (role === "Agent") {
            Bookshelf.knex.raw(`select ViewAll, BrokerId from \`agent\` where AgentId=${clientId}`)
                .then(valueAgent => {
                    const ViewAll = bufferToBoolean(valueAgent[0][0].ViewAll);
                    if (ViewAll) {
                        andWhere += ` and (o.AgentId in (select AgentId from \`agent\` where BrokerId=${valueAgent[0][0].BrokerId})`;
                    } else {
                        andWhere += ` and (o.AgentId=${clientId}`;
                    }

                    andWhere += ` or o.CreatedBy = ${(userId !== undefined) ? userId : -1}))`;

                    Bookshelf.knex.raw(`call GetOrdersClientStaff(
                            ${(sortColumn === undefined || sortColumn === "") ? null : `'${sortColumn}'`},
                            ${(sortDirection === undefined || sortDirection === "") ? null : `${sortDirection}`},
                            '${andWhere}',
                            ${(page === undefined || page === "") ? null : `${page}`},
                            ${(itemPerPage === undefined || itemPerPage === "") ? null : `${itemPerPage}`},
                            ${(groupsQuery === "") ? null : `'${groupsQuery}'`},
                            ${newOrderId},
                            '${newVendorLastName}',
                            '${newCustomerLastName}',
                            ${newCompanyBranch},
                            '${newAgentName}',
                            ${newStatusOrder},
                            '${newAptDateFrom}',
                            '${newAptDateTo}',
                            '${newOrderDateFrom}',
                            '${newOrderDateTo}'
                        );`)
                        .then(value => {
                            const data = {};

                            if (value !== null) {
                                data.groupStatus = value[0][0];
                                data.data = value[0][1];
                                data.totalRecords = value[0][2][0].TotalRecords;
                            }
                            reply(data);
                        }).catch(err => {
                            reply(Boom.badRequest(err));
                        });
                });
        } else {
            switch (role) {
                case "Client":
                    andWhere += ` and ((o.BrokerId=${clientId} or (o.BrokerId in (select Brokerid from \`broker\` where \`broker\`.GID = ${clientId})) and o.InActive = false)`;
                    break;
                case "Branch":
                    andWhere += ` and (o.BrokerId=${clientId}`;
                    break;
                // case "Agent":
                //     andWhere += ` and (o.AgentId=${clientId}`;
                //     break;
                default:
                    andWhere += " and (false";
            }

            andWhere += ` or o.CreatedBy = ${(userId !== undefined) ? userId : -1}))`;

            Bookshelf.knex.raw(`call GetOrdersClientStaff(
                    ${(sortColumn === undefined || sortColumn === "") ? null : `'${sortColumn}'`},
                    ${(sortDirection === undefined || sortDirection === "") ? null : `${sortDirection}`},
                    '${andWhere}',
                    ${(page === undefined || page === "") ? null : `${page}`},
                    ${(itemPerPage === undefined || itemPerPage === "") ? null : `${itemPerPage}`},
                    ${(groupsQuery === "") ? null : `'${groupsQuery}'`},
                    ${newOrderId},
                    '${newVendorLastName}',
                    '${newCustomerLastName}',
                    ${newCompanyBranch},
                    '${newAgentName}',
                    ${newStatusOrder},
                    '${newAptDateFrom}',
                    '${newAptDateTo}',
                    '${newOrderDateFrom}',
                    '${newOrderDateTo}'
                );`)
                .then(value => {
                    const data = {};

                    if (value !== null) {
                        data.groupStatus = value[0][0];
                        data.data = value[0][1];
                        data.totalRecords = value[0][2][0].TotalRecords;
                    }
                    reply(data);
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });

        }


    }

    getInitSearchOrdersClient(request, reply) {
        Bookshelf.knex.raw(`call InitSearchOrdersClient();`)
            .then(value => {
                const data = {};
                if (value !== null) {
                    data.branches = value[0][0];
                    data.statuses = value[0][1];
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getOrderProgressClient(request, reply) {
        // let { searchValue } = request.query;
        const {
            progressGroup,
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            clientId,
            role
        } = request.query;
        // searchValue = (searchValue !== undefined) ? handleSingleQuote(searchValue) : "";

        Bookshelf.knex.raw(`call GetOrderProgressClient(
            '${handleSingleQuote(role)}',
            ${handleSingleQuote(clientId)},
            '${handleSingleQuote(progressGroup)}',
            ${(sortColumn === undefined || sortColumn === "") ? null : `'${sortColumn}'`},
            ${(sortDirection === undefined || sortDirection === "") ? null : `${sortDirection}`},
            ${(page === undefined || page === "") ? null : `${page}`},
            ${(itemPerPage === undefined || itemPerPage === "") ? null : `${itemPerPage}`})
            ;`)
            .then(value => {
                const data = {};

                if (value !== null) {
                    data.data = value[0][0];
                    data.totalRecords = value[0][1][0].TotalRecords;
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }
}

export default new OrderClientController();