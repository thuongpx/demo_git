import NotaryTraning from "./vendor-notary-training-controller";

const routes = [{
    path: "/notarytraning/getlistRegisteredPrograms",
    method: "GET",
    handler: NotaryTraning.getlistRegisteredPrograms
},
{
    path: "/vendor-notary-training-controller/getListLearningPath",
    method: "GET",
    handler: NotaryTraning.getListLearningPath
},
{
    path: "/vendor-notary-training-controller/getListPopularProgram",
    method: "GET",
    handler: NotaryTraning.getListPopularProgram
},
{
    path: "/notarytraning/getlistAllPrograms",
    method: "GET",
    handler: NotaryTraning.getlistAllPrograms
},
{
    path: "/vendor-notary-training-controller/registerPopularProgram",
    method: "POST",
    handler: NotaryTraning.registerPopularProgram
},
{
    path: "/notarytraning/getCurrentRegisteredPrograms",
    method: "GET",
    handler: NotaryTraning.getCurrentRegisteredProgram
},
{
    path: "/notarytraning/getCourseandTestbyProgramId",
    method: "GET",
    config: {
        auth: false
    },
    handler: NotaryTraning.getCourseandTestbyProgramId
},
{
    path: "/notarytraning/getListCourseandTestbyProgramId",
    method: "GET",
    handler: NotaryTraning.getListCourseandTestbyProgramId
},
{
    path: "/vendor-notary-training-controller/getListRecentCourses",
    method: "GET",
    handler: NotaryTraning.getListRecentCourses
},
{
    path: "/vendor-training-controller/getCourseOfCurrentProgram",
    method: "GET",
    handler: NotaryTraning.getCourseOfCurrentProgram
}
];


export default routes;