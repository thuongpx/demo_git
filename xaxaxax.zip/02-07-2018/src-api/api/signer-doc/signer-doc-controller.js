import SignerDoc from "../../db/model/signer-doc";
import SignerDocArchive from "../../db/model/signer-docs-archive";
import Boom from "boom";
import Bookshelf from "../../db/database";
import moment from "moment";
import { isBuffer, bufferToBoolean, replaceAll } from "../../helper/common-helper";
import appConfig from "../../config/config";
import fs from "fs";
import Signer from "../../db/model/signers";
import NotificationTemplate from "../../db/model/notification-management";
import sendMailCore from "../../mail/mail-helper";

class SignerDocController {
	constructor() { }

	downloadSignerDocument(request, reply) {
		const { docId } = request.query;
		SignerDoc.where({ docId }).fetch({ columns: ["signerId", "docName"] }).then((signerDoc) => {
			const signerId = signerDoc.get("signerId");
			const docName = signerDoc.get("docName");
			const fileName = `TEMP-${signerId}_${docName}`;
			const filePath = `${appConfig.file.serverPath}/upload/notary-docs-temp/${fileName}`;
			fs.readFile(filePath, (err, data) => {
				if (err) throw err;
				return reply(data)
					.header("content-disposition", `attachment; filename=${fileName}`);
			});
		}).catch((error) => reply(Boom.badRequest(error)));
	}

	downloadSignerDocumentArchive(request, reply) {
		const { Id } = request.query;
		SignerDocArchive.where({ Id }).fetch({ columns: ["signerId", "docName"] }).then((signerDoc) => {
			const signerId = signerDoc.get("signerId");
			const docName = signerDoc.get("docName");
			const fileName = `ARCHIVED-${Id}-TEMP-${signerId}_${docName}`;
			const filePath = `${appConfig.file.serverPath}/upload/notary-docs-temp/${fileName}`;
			fs.readFile(filePath, (err, data) => {
				if (err) throw err;
				return reply(data)
					.header("content-disposition", `attachment; filename=${fileName}`);
			});
		}).catch((error) => reply(Boom.badRequest(error)));
	}

	uploadSignerDocument(request, reply) {
		const payload = request.payload;
		const file = payload.file;
		const signerDoc = {
			number: payload.number,
			docName: payload.docName,
			issuedDate: payload.issuedDate,
			expireDate: payload.expireDate,
			signerId: payload.signerId,
			docTypeId: payload.docTypeId,
			state: payload.state,
			referencePhoneNumber: payload.referencePhoneNumber,
			referenceName: payload.referenceName
		};
		for (const key in signerDoc) {
			if (signerDoc[key] === "null" || signerDoc[key] === "") {
				signerDoc[key] = null;
			}
		}
		const fileName = `TEMP-${signerDoc.signerId}_${signerDoc.docName}`;
		const filePath = `${appConfig.file.serverPath}/upload/notary-docs-temp/${fileName}`;

		const dir = `${appConfig.file.serverPath}/upload/notary-docs-temp/`;

		if (!fs.existsSync(dir)) {
			fs.mkdirSync(dir);
		}

		const insertSignerDoc = () => {
			new SignerDoc(signerDoc).save({ uploadDate: moment().utc().format("YYYY-MM-DD HH:mm:ss") }, { method: "insert" }).then(() => {
				if (file) {
					const fileStream = fs.createWriteStream(filePath);
					file.pipe(fileStream);
					file.on("end", () => {
						reply({ isSuccess: true });
					});
				} else {
					reply({ isSuccess: true });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		};
		SignerDoc.where({ signerId: signerDoc.signerId, state: signerDoc.state, docTypeId: signerDoc.docTypeId }).count("*").then(count => {
			if (count > 0) {
				SignerDoc.where({ state: signerDoc.state, docTypeId: signerDoc.docTypeId }).destroy().then(() => {
					insertSignerDoc();
				});
			} else {
				insertSignerDoc();
			}
		}).catch(error => reply(Boom.badRequest(error)));
	}

	checkSignerDocExisting(request, reply) {
		const { signerId, docTypeId, state } = request.query;
		SignerDoc.where({ signerId, state, docTypeId }).fetch({ columns: ["expireDate"] }).then(model => {
			if (model !== null) {
				const expireDate = model.get("expireDate");
				reply({ isExist: expireDate === null || moment(expireDate) > moment() });
			} else {
				reply({ isExist: false });
			}
		}).catch(error => reply(Boom.badRequest(error)));
	}

	getSignerDocBySignerId(request, reply) {
		const { signerId } = request.query;
		const rawSql = `SELECT sdt.docType, sd.referencePhoneNumber, sd.referenceName, sd.docId, sd.number, sd.issuedDate,
		sd.state, sd.expireDate, sd.docName, sd.docTypeId,
		sd.approved, sd.rejected, sd.rejectReason
		FROM signer_docs sd
		JOIN signer_doctypes sdt on sd.docTypeId = sdt.docTypeId WHERE sd.signerId = ${signerId} `;
		Bookshelf.knex.raw(rawSql).then(result => {
			const signDocs = result[0];
			signDocs.map(signDoc => {
				Object.keys(signDoc).forEach((key) => {
					const value = signDoc[key];
					if (isBuffer(value)) {
						signDoc[key] = bufferToBoolean(value);
					}
				});
				return signDoc;
			});
			reply(signDocs);
		}).catch(error => reply(Boom.badRequest(error)));
	}

	getSignerDocsStatus(request, reply) {
		const { signerId } = request.query;

		Signer.where({ signerId }).fetch({ columns: ["weekDayState"] }).then(signer => {
			const weekDayState = signer.attributes.weekDayState;
			const rawSql = `select sdt.docTypeId,sdt.docType,sd.state,( case when sd.signerId is null then 'No' else 'Yes' end) as isUploaded,sd.expireDate from signer_doctypes sdt
			left outer join signer_docs sd on sdt.DocTypeID = sd.DocTypeId and sd.signerId =
			 ${signerId} where sdt.states like '%${weekDayState}%' or sdt.states='US' order by sdt.docTypeId`;
			Bookshelf.knex.raw(rawSql).then(signerDocs => {
				reply(signerDocs[0]);
			}).catch(error => reply(Boom.badRequest(error)));
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getVendorDocsStatusById(request, reply) {
		const { signerId } = request.query;

		const rawSql = `select
							sd.DocId,
							sd.DocName,
							sdt.DocTypeId,
							sdt.DocType,
							sd.State,
							sd.ExpireDate,
							u.UserName as ApprovedBy,
							sd.ApprovedDate,
							case when Approved = 1 then 'Approved'
								when Rejected = 1 then 'Rejected'
								else 'Open'
							end as Status,
							sd.RejectReason,
							sd.Number,
							sd.IssuedDate,
							sd.ReferenceName,
							sd.ReferencePhoneNumber
						from signer_docs as sd
						left join signer_doctypes as sdt on sd.DocTypeId = sdt.DocTypeId
						left join users as u on sd.ApprovedBy = u.UsersId
						where sd.SignerId = ${signerId};`;
		Bookshelf.knex.raw(rawSql).then(signerDocs => {
			reply(signerDocs[0]);
		}).catch(error => reply(Boom.badRequest(error)));
	}

	aprroveVendorDoc(request, reply) {
		const { docId, userId } = request.payload;

		SignerDoc.where({
			DocId: docId
		}).save({ ApprovedBy: userId, Approved: 1, ApprovedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss") }, {
			method: "update"
		}).then((result) => {
			if (result !== null) {
				reply({
					isSuccess: true
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	rejectVendorDoc(request, reply) {
		const { docId, rejectReason, userId, signerId } = request.payload;

		SignerDoc.where({
			DocId: docId
		}).save({ ApprovedBy: userId, Rejected: 1, RejectReason: rejectReason, ApprovedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss") }, {
			method: "update"
		}).then((result) => {
			if (result !== null) {
				NotificationTemplate.where({
					purpose: "Credential Document Rejected"
				}).fetch({
					columns: ["message", "subject", "fromEmail"]
				}).then(async (template) => {
					const subject = template.get("subject");
					let message = template.get("message");
					let signerFirstName = "";
					let signerLastName = "";
					let toEmail = "";
					await new Promise(resolve => Signer.where({
						signerId
					}).fetch({
						columns: ["firstName", "lastName", "email"]
					}).then((signer) => {
						signerFirstName = signer.get("firstName");
						signerLastName = signer.get("lastName");
						toEmail = signer.get("email");
						resolve();
					}));

					message = replaceAll(message, ["[SignerFirstName]"], `${signerFirstName}`);
					message = replaceAll(message, ["[SignerLastName]"], `${signerLastName}`);
					message = replaceAll(message, ["[RejectReason]"], `${rejectReason}`);

					const mailOptions = {
						from: template.get("fromEmail"),
						to: toEmail,
						subject,
						html: message
					};
					sendMailCore(mailOptions);
				});
				reply({
					isSuccess: true
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	archiveVendorDoc(request, reply) {
		const docData = request.payload;
		new SignerDocArchive().save({
			SignerID: docData.SignerId,
			DocTypeID: docData.DocTypeId,
			DocName: docData.DocName,
			ArchiveDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
			ArchiveBy: docData.UserId

		}, { method: "insert" }).then((result) => {
			const archivedId = result.get("id");
			const fileName = `TEMP-${docData.SignerId}_${docData.DocName}`;
			const archivedFileName = `ARCHIVED-${archivedId}-${fileName}`;
			const folderPath = `${appConfig.file.serverPath}/upload/notary-docs-temp/`;
			fs.rename(`${folderPath}${fileName}`, `${folderPath}${archivedFileName}`, (err) => {
				if (err) console.log(err);
				SignerDoc.where({ DocId: docData.DocId }).destroy().then((respone) => {
					if (respone !== null) {
						reply({ isSuccess: true });
					}
				}).catch((error) => {
					reply(Boom.badRequest(error));
				});
			});
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getVendorDocsArchiveById(request, reply) {
		const { signerId } = request.query;
		const rawSql = `select Id, DocName, ArchiveDate from signer_docs_archive where SignerId = ${signerId};`;

		Bookshelf.knex.raw(rawSql).then(signerDocArchive => {
			reply(signerDocArchive[0]);
		}).catch(error => reply(Boom.badRequest(error)));
	}

	async deleteVendorDoc(request, reply) {
		const docArchiveData = request.payload;
		let documentName = "";
		let archivedId = 0;
		let signerId = 0;
		await new Promise(resolve => SignerDocArchive.where({ Id: docArchiveData.Id }).fetch({ columns: ["docName", "id", "signerId"] }).then((model) => {
			documentName = model.get("docName");
			archivedId = model.get("id");
			signerId = model.get("signerId");
			resolve();

		}).catch(error => reply(Boom.badRequest(error))));
		const archivedFileName = `ARCHIVED-${archivedId}-TEMP-${signerId}_${documentName}`;

		SignerDocArchive.where({ Id: docArchiveData.Id }).destroy().then((respone) => {
			if (respone !== null) {
				const filePath = `${appConfig.file.serverPath}/upload/notary-docs-temp/${archivedFileName}`;
				try {
					fs.unlinkSync(filePath);
				} catch (error) {
					console.log(error);
				}
				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

	}
}

export default new SignerDocController();