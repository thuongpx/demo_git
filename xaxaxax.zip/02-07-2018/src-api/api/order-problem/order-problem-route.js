import OrderProblemController from "./order-problem-controller";

const routes = [{
    path: "/orderproblem/getOrderProblem",
    method: "GET",
    handler: OrderProblemController.getOrderProblem
},
{
    path: "/orderproblem/removeOrderProblem",
    method: "POST",
    handler: OrderProblemController.removeOrderProblem
},
{
    path: "/orderproblem/getOrderProblemsByOrder",
    method: "GET",
    handler: OrderProblemController.getOrderProblemsByOrder
},
{
    path: "/orderproblem/addOrderProblem",
    method: "POST",
    handler: OrderProblemController.addOrderProblem
},
{
    path: "/orderproblem/getVendorOrderProblem",
    method: "GET",
    handler: OrderProblemController.getVendorOrderProblem
}
];

export default routes;