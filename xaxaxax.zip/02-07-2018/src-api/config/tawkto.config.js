export default {
    apiKey: "c73523b6bc8bcaada1bfa138495e21ba0af76d15",
    hashAlgorithm: "sha256"
};