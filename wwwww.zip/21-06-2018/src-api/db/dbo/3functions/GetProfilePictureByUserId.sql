DROP FUNCTION IF EXISTS `GetProfilePictureByUserId`;

DELIMITER $$

CREATE FUNCTION `GetProfilePictureByUserId`(user_Id int(11)) RETURNS longblob
BEGIN
	DECLARE userType VARCHAR(15);
    DECLARE roleName VARCHAR(100);
    DECLARE ProfilePicture longblob;
	SET userType = '';
    SET ProfilePicture = NULL;
    
	IF user_Id IS NOT NULL THEN
    BEGIN
        SELECT r.Type, r.RoleName
        INTO userType, roleName
        FROM user_roles AS u
		INNER JOIN role_permission AS r ON u.RoleId = r.RoleId
		WHERE u.UsersId = user_Id
        LIMIT 1;
        
        -- if user is staff
        IF userType = 'Staff' THEN
        BEGIN
			SELECT e.ProfilePicture
            INTO ProfilePicture
            FROM employees e
            INNER JOIN users u ON e.RepId = u.MappingUserId
            WHERE u.UsersId = user_Id;
        END;
        END IF;
        
        -- if user is client
        If userType = 'Client' THEN
        BEGIN
			-- client is agent
			IF RoleName = 'Agent' THEN 
            BEGIN
				SELECT a.ProfilePicture
				INTO ProfilePicture
				FROM agent a
				INNER JOIN users u ON a.AgentId = u.MappingUserId
				WHERE u.UsersId = user_Id;
            END;
            ELSE
            BEGIN
				-- client is broker or branch
				SELECT b.ProfilePicture
				INTO ProfilePicture
				FROM broker b
				INNER JOIN users u ON b.BrokerID = u.MappingUserId
				WHERE u.UsersId = user_Id;
            END;
            END IF;
        END;
        END IF;
        
        -- if user is client
        If userType = 'Vendor' THEN
        BEGIN
			SELECT s.ProfilePicture
            INTO ProfilePicture
            FROM signer s
            INNER JOIN users u ON s.SignerId = u.MappingUserId
            WHERE u.UsersId = user_Id;
        END;
        END IF;
    END;
    END IF;
    
	RETURN ProfilePicture;
END