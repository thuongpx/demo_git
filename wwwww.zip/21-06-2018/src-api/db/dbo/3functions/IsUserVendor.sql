DROP FUNCTION IF EXISTS `IsUserVendor`;

DELIMITER $$
CREATE FUNCTION `IsUserVendor` (user_Id int(11))
RETURNS BIT
BEGIN
	DECLARE isVendor BIT;    
	SET isVendor = 0;
    
	IF user_Id IS NOT NULL THEN
    BEGIN
        IF EXISTS (SELECT id FROM user_roles AS u
					INNER JOIN role_permission AS r ON u.RoleId = r.RoleId
					WHERE u.UsersId = user_Id AND TYPE='Vendor') THEN
			SET isVendor = 1;
		END IF;
    END;
    END IF;
    
	RETURN isVendor;
END
