DROP PROCEDURE IF EXISTS `GetAdditionalFeeForOrder`;

DELIMITER $$
CREATE PROCEDURE `GetAdditionalFeeForOrder` (
	order_id INT
)
BEGIN
    SELECT 
		b.FeeId,
        b.FeeDescription AS Description,
        b.BrokerFee AS DefaultBrokerFee,
        i.VendorFee AS DefaultSignerFee
	FROM `broker_fee` AS b
    INNER JOIN `industry_transaction_fees` AS i ON b.SystemFee=i.FeeId
    INNER JOIN `order` AS o ON o.BrokerId=b.BrokerId  and o.LoanType=b.LoanTypeId
    WHERE o.OrderId = order_id 
		AND b.IsAdditionalFee = 1;
END$$

DELIMITER ;