DROP procedure IF EXISTS `DelStatesAndLoantypesByAnnID`;

DELIMITER $$

CREATE DEFINER=`tce`@`%` PROCEDURE `DelStatesAndLoantypesByAnnID`(
IN announchement_id int
)
BEGIN

SET SQL_SAFE_UPDATES = 0;
delete  FROM announcements_state where AnnouncementID=announchement_id;
delete  From `announcements_loan_type` where AnnouncementID=announchement_id;
SET SQL_SAFE_UPDATES = 1;

END$$
DELIMITER ;