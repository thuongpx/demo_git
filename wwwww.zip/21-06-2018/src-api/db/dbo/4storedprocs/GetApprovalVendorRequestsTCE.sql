DROP procedure IF EXISTS `GetApprovalVendorRequestsTCE`;

DELIMITER $$
CREATE PROCEDURE `GetApprovalVendorRequestsTCE` (
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN orderId varchar(255),
IN status varchar(255),
IN requestBy varchar(255)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(500);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY date ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = CONCAT(' WHERE (o.IsSelfService = 0 OR o.IsSelfService IS NULL) ');
	IF (status IS NOT NULL AND status <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND s.status = ''', status, '''');
	END IF;
    IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND s.OrderId = ', orderId);
	END IF;
    IF (requestBy IS NOT NULL AND requestBy <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND u.UserName LIKE ''%', requestBy, '%''');
	END IF;
    
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, 
		s.ApprovalID as approvalId,
		s.RequestDate AS date,
        s.orderId,
        u.UserName AS requestedBy,
        concat(r.LastName, '' '', r.firstname) as vendorName,
        s.Reason as reason,
        s.status,
        s.signerId,
        GetFirstComment(4, s.ApprovalID) as comment,
        u.usersId,
        o.aptDateTime
	FROM `signers_approval` AS s
    inner join `signer` r on s.SignerId = r.SignerId
    inner join `order` o on s.OrderId=o.OrderId
    inner JOIN `users` AS u ON u.UsersId = s.RequestBy, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
    
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$
