DROP PROCEDURE IF EXISTS `GetClientServicesConfigurationData`;

DELIMITER $$
CREATE PROCEDURE `GetClientServicesConfigurationData`(
	IN createdById int,
    IN numRow int
)
BEGIN
	SELECT `Code`, `Description`
    FROM state;

	SELECT
		ConfigId,
		OrderPerDay,
        State1,
        MSA1,
        UpdatedDate,
        DATE_ADD(UpdatedDate, INTERVAL 30 DAY) as EstimatedEffectiveDate,
        EffecttiveDate,
        CONCAT('1 - ', CutoffDate) AS DateRange,
        u.UserName as ChangedBy,
        ab.UserName as ApprovedBy,
        case csc.Status when 1 then 'Open'
						when 2 then 'Approved'
                        when 3 then 'Closed'
                        else ''
		end as status
	FROM client_services_config csc
		LEFT JOIN users u ON csc.UpdatedBy = u.UsersId
        LEFT JOIN users ab ON csc.ApprovedBy = ab.UsersId
        
    WHERE CreatedBy = createdById
    ORDER BY EffecttiveDate DESC
    LIMIT 0, numRow
    ;
END$$
DELIMITER ;