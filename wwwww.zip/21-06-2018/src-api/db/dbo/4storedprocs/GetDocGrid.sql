DROP PROCEDURE IF EXISTS `GetDocGrid`;

DELIMITER $$
CREATE PROCEDURE `GetDocGrid`(
	IN `sortBy` VARCHAR(250),
	IN `sortDirection` BIT,
	IN `pageNumber` INT,
	IN `pageSize` INT,
	IN `orderId` INT,
	IN `docType` INT
)
BEGIN	
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
	DECLARE limitQuery varchar(255);  
	DECLARE whereQuery varchar(255);  
	DECLARE selectQuery varchar(500);
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY UploadedDate ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
   IF (docType = 1)
   	THEN SET selectQuery = '
			SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
					t.DocId, t.OrderId, t.Description, t.UploadedDate, u.UserName AS UploadedBy, t.Viewed, t.DownloadDate, t.UserId
			FROM order_docs t
			LEFT JOIN users u ON u.UsersId = t.UserId
			, (SELECT @rownum := 0) r';
		ELSE
			SET selectQuery = '
			SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
					t.DocId, t.OrderId, t.Description, t.UploadedDate, u.UserName AS UploadedBy, t.Status, t.ReviewDate, x.UserName AS ReviewedBy, t.Comment, t.Viewed, t.RejectReason, t.UserId
			FROM order_docs t
			LEFT JOIN users u ON u.UsersId = t.UserId
			LEFT JOIN users x ON x.UsersId = t.ReviewedBy
			, (SELECT @rownum := 0) r';
	END IF;
	SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	SET whereQuery = CONCAT(' WHERE UploadedDate >= DATE(UTC_TIMESTAMP()) - INTERVAL 60 DAY AND OrderId = ',orderId,' AND DocumentType = ',docType); 
	
	SET @querySql = CONCAT(selectQuery,whereQuery, orderQuery, limitQuery);

PREPARE stmt FROM @querySql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 
    SELECT FOUND_ROWS() as TotalRecords;
END$$
DELIMITER ;
