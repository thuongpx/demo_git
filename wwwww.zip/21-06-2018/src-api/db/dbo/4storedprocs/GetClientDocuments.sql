DELIMITER $$
 
DROP PROCEDURE IF EXISTS `GetClientDocuments`$$
 
CREATE PROCEDURE `GetClientDocuments`(
IN brokerId int,
IN isAgent bit,
IN orderId varchar(500),
IN documentName varchar(500),
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
   DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';
    
	IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND od.orderId =  ''', orderId, '''');
	END IF;
    
    IF (documentName IS NOT NULL AND documentName <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND od.description LIKE  ''%', documentName, '%''');
	END IF;
    
    IF (isAgent = 1) 
		THEN SET whereQuery = CONCAT(whereQuery, ' AND (o.agentID = ',brokerId,')');
    ELSE
		SET whereQuery = CONCAT(whereQuery, ' AND (br.brokerId= ',brokerId,' or br.gId=',brokerId,')');
	END IF;
    
    SET whereQuery = CONCAT(whereQuery, ' AND (od.archive IS NULL OR od.archive = 0) AND od.documentType=1 ');
   
	SET @querySql= concat('
     SELECT 
     SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			od.docId,
            od.orderId,
            od.description,
            od.uploadedDate,
            od.documentType,
			(CASE 
				WHEN od.viewed IS NULL THEN  ''N''	
				ELSE ''Y'' END) as isDownloadedByVendor
			FROM order_docs od
            JOIN `order` o on od.orderId = o.orderId
            JOIN broker br on br.brokerId = o.brokerId
            , (SELECT @rownum := 0) r
            ',
            whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END$$
 
DELIMITER ;

