DROP PROCEDURE IF EXISTS `GetAllTrainingLearningPath`;

DELIMITER $$
CREATE PROCEDURE `GetAllTrainingLearningPath`(
	IN lPName varchar(255),
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE 1=1 ');
    
	IF (lPName IS NOT NULL AND lPName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `LPName` LIKE ''%', lPName, '%''');
	END IF;
    
     set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS
									`training_learning_path`.LPID as `LPID`,
									`training_learning_path`.LPName as `LPName`,
									`training_learning_path`.Description as `Description`
							FROM training_learning_path', whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    SELECT FOUND_ROWS() as TotalRecords;
END$$
DELIMITER ;
