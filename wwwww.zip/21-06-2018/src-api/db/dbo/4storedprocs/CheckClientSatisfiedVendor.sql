DROP procedure IF EXISTS `CheckClientSatisfiedVendor`;

DELIMITER $$
CREATE PROCEDURE `CheckClientSatisfiedVendor` (
	IN forOrderId int,
    IN forSignerId int
)
BEGIN
	SELECT BrokerId, CustomerId
	INTO @OrderBrokerId, @OrderCustomerId
	FROM `order` WHERE OrderId = forOrderId;

	DROP TEMPORARY TABLE IF EXISTS reqTrainingTable;
	CREATE TEMPORARY TABLE reqTrainingTable (ProgramId int);

	IF @OrderCustomerId IS NOT NULL
		THEN
			SELECT ReqRating, ReqExperienceNumber INTO @ReqRating, @ReqExperienceNumber FROM customers WHERE CustomerId = @OrderCustomerId;
			INSERT INTO reqTrainingTable
				SELECT CTR.ProgramId FROM
					customer_training_req CTR INNER JOIN training_programs TP ON
						CTR.ProgramId = TP.ProgramId 
						AND CTR.CustomerId = @OrderCustomerId
						AND TP.Inactive = 0
						AND TP.IsPublished = 1
				;
				
		ELSEIF @OrderBrokerId IS NOT NULL
			THEN
				SELECT ReqRating, ReqExperienceNumber INTO @ReqRating, @ReqExperienceNumber FROM broker WHERE BrokerId = @OrderBrokerId;
				INSERT INTO reqTrainingTable 
					SELECT BTR.ProgramId FROM
						broker_training_req BTR INNER JOIN training_programs TP ON
							BTR.ProgramId = TP.ProgramId 
							AND BTR.BrokerId = @OrderBrokerId
							AND TP.Inactive = 0
							AND TP.IsPublished = 1
					;
                    
		ELSE
			SET @ReqRating = NULL;
			SET @ReqExperienceNumber = NULL;
	END IF;

	IF (
		EXISTS
			(SELECT
				S.SignerId, S.Rating, COUNT(O.OrderId) AS NumberOfClosedOrder
			FROM
				signer S
				LEFT JOIN `order` O ON S.SignerId = O.SignerId AND O.ProgressId = 11
			WHERE
				S.SignerId = forSignerId
				AND (find_in_set(S.Rating, @ReqRating) OR @ReqRating IS NULL OR @ReqRating='')
				-- TRAINING REQUIREMENT
				AND (
					NOT EXISTS (
						SELECT RT.ProgramId FROM reqTrainingTable RT WHERE RT.ProgramId NOT IN (
							SELECT VRP.ProgramId FROM vendor_registered_programs VRP WHERE VRP.VendorId = S.SignerId AND VRP.IsComplete =1
						)
					))
			GROUP BY S.SignerId
			HAVING
				-- NUMBER OF CLOSED ORDER REQUIREMENT
				(COUNT(O.OrderId) >= @ReqExperienceNumber OR @ReqExperienceNumber IS NULL)
			)
		)
	THEN 
		SELECT TRUE AS isSatisfied;
	ELSE 
		SELECT FALSE AS isSatisfied;
	END IF;

	DROP TEMPORARY TABLE IF EXISTS reqTrainingTable;
END$$

DELIMITER ;