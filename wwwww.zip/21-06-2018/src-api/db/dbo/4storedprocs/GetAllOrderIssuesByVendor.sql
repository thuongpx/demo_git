DROP PROCEDURE IF EXISTS `GetAllOrderIssuesByVendor`;

DELIMITER $$

CREATE PROCEDURE `GetAllOrderIssuesByVendor`(
	IN InDescription varchar(3000),
	IN InOrderId int,
	IN InDuration int,
	IN InStatus int,
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       	THEN SET orderQuery = ' ORDER BY Date ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    

	SET whereQuery = 'WHERE order_problem.Mistake=1';

	IF (InOrderId IS NOT NULL) THEN 
		SET whereQuery = CONCAT(whereQuery, ' AND (OrderId=', InOrderId, ')');
	END IF;

     
     set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS order_problem.OrderId, order_problem.ProblemId,
            order_problem.Date, order_problem.Mistake ,
            GetFullNameByUserId(CreatedUser.UsersId) as CreatedBy, 
            problem_status.Description as Status,
            problem_types.Description as Type
            FROM order_problem
            LEFT JOIN problem_types ON (order_problem.Type=problem_types.Id)
            LEFT JOIN users as CreatedUser ON (order_problem.EnteredBy=CreatedUser.UsersId)
            LEFT JOIN problem_status ON (order_problem.Status=problem_status.id)
            LEFT JOIN (select OwnerID, Description from comment  as cm inner join (SELECT MIN(t.CreatedDate) AS min_CreatedDate FROM comment as t WHERE t.TypeID = 3 group by t.OwnerID) as m on m.min_CreatedDate = cm.CreatedDate) as c  ON (order_problem.OrderId=c.OwnerID)
            ', whereQuery, orderQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
SELECT FOUND_ROWS() AS TotalRecords;
END$$
DELIMITER ;