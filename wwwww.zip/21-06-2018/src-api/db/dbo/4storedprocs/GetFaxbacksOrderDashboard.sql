DROP PROCEDURE IF EXISTS `GetFaxbacksOrderDashboard`;

DELIMITER $$
CREATE PROCEDURE `GetFaxbacksOrderDashboard`(
	IN pageNumber int,
	IN pageSize int,
    IN role varchar(255),
	IN clientId int
)
BEGIN
    DECLARE limitQuery varchar(255);
    DECLARE andWhereQuery varchar(500);
	IF (role = 'Client') 
		THEN SET andWhereQuery = CONCAT(' AND (`order`.BrokerId=',clientId,' or `order`.BrokerId in (select Brokerid from `broker` where `broker`.GID = ',clientId, '))');
	ELSE IF  (role = 'Branch') 
		THEN SET andWhereQuery = CONCAT(' AND `order`.BrokerId=',clientId);
	ELSE IF (role = 'Agent') 
		THEN SET andWhereQuery = CONCAT(' AND `order`.AgentId=',clientId);
		END IF;
    END IF;
    END IF;
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
	SET @querySqlFaxbacks = CONCAT(' SELECT SQL_CALC_FOUND_ROWS `order`.`OrderId` AS `orderId`,
								CONVERT(TIME_FORMAT(TIMEDIFF(UTC_TIMESTAMP(),`order`.AptDateTime - INTERVAL `zip`.UTC HOUR), "%H : %i"), char(10)) AS `time`
								FROM `order`
                                INNER JOIN zip ON `order`.Zip = `zip`.Zip
                                LEFT JOIN `agent` on `order`.AgentId = `agent`.AgentId 
								LEFT JOIN `broker` on `order`.BrokerId = `broker`.BrokerID 
								WHERE `order`.FaxBackReq = 1
								AND `order`.FaxBackAcceptDate IS NULL
                                AND `order`.InActive = 0
								AND HOUR(TIMEDIFF(UTC_TIMESTAMP(),`order`.AptDateTime - INTERVAL `zip`.UTC HOUR)) >= 2
                                AND UTC_TIMESTAMP() > `order`.AptDateTime - INTERVAL `zip`.UTC HOUR ',andWhereQuery,
                                ' ORDER BY `time` ASC ' ,limitQuery);
	PREPARE stmt FROM @querySqlFaxbacks;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecordsFaxbacks;
    
END$$
