DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
    -- drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev2' AND
						TABLE_NAME = 'customers' AND 
                            COLUMN_NAME = 'ReqRateNew') THEN
	BEGIN
		ALTER TABLE `customers` 
		DROP COLUMN `ReqRateNew`;
	END;
    END IF;
    
    -- drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev2' AND
						TABLE_NAME = 'customers' AND 
                            COLUMN_NAME = 'ReqRateGood') THEN
	BEGIN
		ALTER TABLE `customers` 
		DROP COLUMN `ReqRateGood`;
	END;
    END IF;
    
    -- drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev2' AND
						TABLE_NAME = 'customers' AND 
                            COLUMN_NAME = 'ReqRateVeryGood') THEN
	BEGIN
		ALTER TABLE `customers` 
		DROP COLUMN `ReqRateVeryGood`;
	END;
    END IF;
    
    -- drop column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev2' AND
						TABLE_NAME = 'customers' AND 
                            COLUMN_NAME = 'ReqRateExellent') THEN
	BEGIN
		ALTER TABLE `customers` 
		DROP COLUMN `ReqRateExellent`;
	END;
    END IF;
    
    -- add column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev2' AND
						TABLE_NAME = 'customers' AND 
                            COLUMN_NAME = 'ReqRating') THEN
	BEGIN
		ALTER TABLE `customers` 
		ADD COLUMN `ReqRating` VARCHAR(50) NULL;
	END;
    END IF;
END$$

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;