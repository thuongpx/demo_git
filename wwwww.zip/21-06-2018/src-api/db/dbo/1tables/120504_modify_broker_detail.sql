DROP PROCEDURE IF EXISTS `alterTableBrokerDetail`;

DELIMITER $$
CREATE PROCEDURE `alterTableBrokerDetail` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_detail' AND 
                            COLUMN_NAME = 'AfterHoursPhoneExt') THEN
	BEGIN
		ALTER TABLE `broker_detail` 
		ADD COLUMN `AfterHoursPhoneExt` VARCHAR(50);
	END;
    END IF;
END$$

DELIMITER ;

call alterTableBrokerDetail();

DROP PROCEDURE IF EXISTS `alterTableBrokerDetail`;

