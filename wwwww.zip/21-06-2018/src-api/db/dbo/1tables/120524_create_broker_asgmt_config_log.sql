-- create by AnNV2
CREATE TABLE IF NOT EXISTS `broker_asgmt_config_log` (
	`LogId` INT NOT NULL AUTO_INCREMENT,
	`BrokerId` INT NOT NULL,
	`Rating` VARCHAR(50) NULL,
	`Specialty` VARCHAR(100),
    `ExperienceNumber` SMALLINT,
    `Training` VARCHAR(100),
    `PreferredVendor` VARCHAR(250),
    `ChangedDate` DATETIME,
    `ChangedBy` INT,
    PRIMARY KEY(`LogId`)
);
