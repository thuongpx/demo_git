CREATE TABLE IF NOT EXISTS `broker_donotuse`(
	Id INT(11) NOT NULL AUTO_INCREMENT,
	BrokerId INT(11) NULL,
	SignerId INT(11) NULL,
    Comment VARCHAR(2500),
	Timestamp DATETIME NULL
)