DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'announcements' AND 
                            COLUMN_NAME = 'PublicDate') THEN
	BEGIN
		ALTER TABLE `announcements` 
		ADD COLUMN `PublicDate` datetime;
	END;
    END IF;

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;