CREATE TABLE IF NOT EXISTS `customer_preferred_vendor` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `CustomerId` INT NOT NULL,
  `SignerId` INT NULL,
  `FirstName` VARCHAR(15) NULL,
  `LastName` VARCHAR(25) NULL,
  `Email` VARCHAR(75) NULL,
  `TaxId` VARCHAR(50) NULL,
  PRIMARY KEY (`Id`)
  );