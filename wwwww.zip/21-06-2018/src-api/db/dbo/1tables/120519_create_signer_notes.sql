CREATE TABLE IF NOT EXISTS `signer_notes` (
  `NoteId` INT NOT NULL AUTO_INCREMENT,
  `SignerId` INT NOT NULL,
  `Note` VARCHAR(250) NULL,
  `CreatedDate` DATETIME NULL,
  `CreatedBy` INT NOT NULL,
  PRIMARY KEY (`NoteId`));