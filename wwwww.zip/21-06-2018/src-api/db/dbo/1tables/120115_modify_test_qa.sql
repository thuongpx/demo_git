ALTER TABLE `test_qa` 
CHANGE COLUMN `TestSection` `SectionId` INT(11) NULL DEFAULT NULL ,
ADD INDEX `sectionid_test_qa_idx` (`SectionId` ASC);

ALTER TABLE `test_qa` 
ADD CONSTRAINT `sectionid_test_qa`
  FOREIGN KEY (`SectionId`)
  REFERENCES `test_sections` (`SectionId`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
