import BrokerEmailsController from "./broker-emails-controller";

const routes = [{
    path: "/broker-emails/addCcEmail",
    method: "POST",
    handler: BrokerEmailsController.addCcEmail
},
{
    path: "/broker-emails/deleteCcEmail",
    method: "GET",
    handler: BrokerEmailsController.deleteCcEmail
},
{
    path: "/broker-emails/updateCcEmail",
    method: "POST",
    handler: BrokerEmailsController.updateCcEmail
}];

export default routes;