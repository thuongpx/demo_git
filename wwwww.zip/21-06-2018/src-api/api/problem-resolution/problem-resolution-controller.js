import Boom from "boom";
import Bookshelf from "./../../db/database";
import ProblemResolution from "../../db/model/problem-resolution";
import moment from "moment";
import {
    hasValue
} from "../../helper/common-helper";

class ProblemResolutionController {
    constructor() { }

    getResolutionByProblemId(request, reply) {
        const {
            problemId
        } = request.query;

        const rawSql = `Select ResolutionId AS resolutionId, ProblemId AS problemId, Resolution AS resolution, CreatedDate AS createdDate, CreatedBy AS createdBy, u.UserName AS userName, u.ProfilePicture as img FROM problem_resolution ps INNER JOIN users AS u ON u.UsersId=ps.CreatedBy WHERE ps.ProblemId = ${problemId}`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                result[0].map(item => {
                    item.img = hasValue(item.img) ? item.img : "";
                });
                reply(result[0]);
            }
        }, (error) => reply(Boom.badRequest(error)));
    }


    // Add Resolution MySQL
    addResolution(request, reply) {
        const resolution = request.payload;
        new ProblemResolution().save({
            Resolution: resolution.resolution,
            CreatedBy: resolution.createdBy,
            CreatedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            ProblemId: resolution.problemId
        }, {
                method: "insert"
            }).then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true
                    });

                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return;
            });
    }

}

export default new ProblemResolutionController();