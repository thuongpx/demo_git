import OrderController from "./order-controller";
import OrderFeeController from "./order-fee-controller";
import OrderCollectController from "./order-collect-controller";
import OrderStatusController from "./order-status-controller";
import OrderSpecController from "./order-spec-controller";
import OrderClientController from "./order-client-controller";
import OrderCustomerController from "./order-customer-controller";
import OrderDateController from "./order-date-controller";
import OrderDocController from "./order-docs-controller";
import OrderFeeApproveController from "./order-fee-approve-controller";

const routes = [{
    path: "/order/getOrders",
    method: "GET",
    handler: OrderController.getOrders
},
{
    path: "/order/getOrdersFeeData",
    method: "GET",
    handler: OrderFeeController.getOrdersFeeData
},
{
    path: "/order/getInitData",
    method: "GET",
    handler: OrderController.getInitDataForViewOrders
},
{
    path: "/order/getOrderStatusInitData",
    method: "GET",
    handler: OrderStatusController.getInitDataForOrderStatus
},
{
    path: "/order/getOrderCollect",
    method: "GET",
    handler: OrderCollectController.getOrderCollectById
},
{
    path: "/order/deleteOrderFee",
    method: "POST",
    handler: OrderFeeController.deleteOrderFee
},
{
    path: "/order/getOrderFee",
    method: "GET",
    handler: OrderFeeController.getOrderFee
},
{
    path: "/order/addOrderFee",
    method: "POST",
    handler: OrderFeeController.addOrderFee
},
{
    path: "/order/getOrderStatusProgressLog",
    method: "GET",
    handler: OrderStatusController.getOrderStatusProgressLog
},
{
    path: "/order/getOrderSpecificsData",
    method: "GET",
    handler: OrderSpecController.getOrderSpecificsData
},
{
    path: "/order/getOrderProgressLogByOrderId",
    method: "GET",
    handler: OrderController.getOrderProgressLogByOrderId
},
{
    path: "/order/addOrderRequestedFee",
    method: "POST",
    handler: OrderFeeController.addOrderRequestedFee
},
{
    path: "/order/getOrderRequestedFee",
    method: "GET",
    handler: OrderFeeController.getOrderRequestedFee
},
{
    path: "/order/updateOrderRequestedFee",
    method: "POST",
    handler: OrderFeeController.updateOrderRequestedFee
},
{
    path: "/order/processRequestFee",
    method: "POST",
    handler: OrderFeeController.processRequestFee
},
{
    path: "/order/getOrderClientDropdownDataByClientId",
    method: "GET",
    handler: OrderClientController.getOrderClientBranchDropdownDataByClientId
},
{
    path: "/order/getRecentVendorData",
    method: "GET",
    handler: OrderClientController.getRecentVendorData
},
{
    path: "/order/getOrderClientAgentData",
    method: "GET",
    handler: OrderClientController.getOrderClientAgentData
},
{
    path: "/order/getOrderClientById",
    method: "GET",
    handler: OrderClientController.getOrderClientById
},
{
    path: "/order/getInitDataForOrderCustomer",
    method: "GET",
    handler: OrderCustomerController.getInitDataForOrderDetailCustomer
},
{
    path: "/order/getOrderDatesById",
    method: "GET",
    handler: OrderDateController.getOrderDate
},
{
    path: "/order/updateOrderDetailStatus",
    method: "POST",
    handler: OrderStatusController.updatOrderStatus
},
{
    path: "/order/updateOrderDetailClient",
    method: "POST",
    handler: OrderClientController.updateOrderDetailClient
},
{
    path: "/order/updateOrderDetailCustomer",
    method: "POST",
    handler: OrderCustomerController.updateOrderDetailCustomer
},
{
    path: "/order/addOrder",
    method: "POST",
    handler: OrderController.addOrder
},
{
    path: "/order/updateOrderDate",
    method: "POST",
    handler: OrderDateController.updateOrderDate
},
{
    path: "/order/getDefaultDataForOrderDetailHeader",
    method: "GET",
    handler: OrderController.getDefaultDataForOrderDetailHeader
},
{
    path: "/order/updateOrderSpecific",
    method: "POST",
    handler: OrderSpecController.updateOrderSpecific
},
{
    path: "/order/getListCustomerByBrokerId",
    method: "GET",
    handler: OrderStatusController.getListCustomerByBrokerId
},
{
    path: "/order/getOrderDetailProductTypeByCustomerId",
    method: "GET",
    handler: OrderStatusController.getOrderDetailProductTypeByCustomerId
},
{
    path: "/order/getOrderDocsByOrderId",
    method: "GET",
    handler: OrderDocController.getOrderDoc
},
{
    path: "/order/getInitRequiredTabForOrderDetail",
    method: "GET",
    handler: OrderController.getInitRequiredTabForOrderDetail
},
{
    path: "/order/getOrdersFeeApproveData",
    method: "GET",
    handler: OrderFeeApproveController.getOrdersFeeApproveData
},
{
    path: "/order/checkInCompleteOrder",
    method: "GET",
    handler: OrderController.checkInCompleteOrder
},
{
    path: "/order/removeInCompleteOrder",
    method: "GET",
    handler: OrderController.removeInCompleteOrder
},
{
    path: "/order/changeOrderFeeApproveStatus",
    method: "POST",
    handler: OrderFeeApproveController.changeOrderFeeApproveStatus
},
{
    path: "/order/setActiveOrder",
    method: "GET",
    handler: OrderController.setActiveOrder
},
{
    path: "/order/setCurrentTabOfInCompleteOrder",
    method: "GET",
    handler: OrderController.setCurrentTabOfInCompleteOrder
},
{
    path: "/order/getDocGrid",
    method: "GET",
    handler: OrderDocController.getDocGrid
},
{
    path: "/order/getDocGridMultiple",
    method: "GET",
    handler: OrderDocController.getDocGridMultiple
},
{
    path: "/order/insertOrderDoc",
    method: "POST",
    handler: OrderDocController.insertOrderDoc
},
{
    path: "/order/updateOrderDoc",
    method: "POST",
    handler: OrderDocController.updateOrderDoc
},
{
    path: "/order/archiveOrderDoc",
    method: "POST",
    handler: OrderDocController.archiveOrderDoc
},
{
    path: "/order/downloadOrderDoc",
    method: "GET",
    handler: OrderDocController.downloadOrderDoc
},
{
    path: "/mobile/order/downloadOrderDoc",
    method: "GET",
    handler: OrderDocController.downloadOrderDoc
},
{
    path: "/mobile/order/getOrderDetail",
    method: "GET",
    handler: OrderController.mobileGetOrderDetail
},
{
    path: "/mobile/order/setSigningTime",
    method: "POST",
    handler: OrderController.mobileSetSigningTime
},
{
    path: "/order/setOrderProgress",
    method: "POST",
    handler: OrderController.setOrderProgress
},
{
    path: "/order/setOrderAgent",
    method: "POST",
    handler: OrderController.setOrderAgent
},
{
    path: "/mobile/order/setOrderStatus",
    method: "POST",
    handler: OrderController.mobileSetOrderStatus
},
{
    path: "/order/deleteOrderDoc",
    method: "POST",
    handler: OrderDocController.deleteOrderDoc
},
{
    path: "/order/checkDocName",
    method: "GET",
    handler: OrderDocController.checkDocName
},
{
    path: "/order/deleteMultipleOrderDoc",
    method: "POST",
    handler: OrderDocController.deleteMultipleOrderDoc
},
{
    path: "/order/getOrderDetailDropDownDataForClientPlaceOrder",
    method: "GET",
    handler: OrderStatusController.getOrderDetailDropDownData
},
{
    path: "/order/getDefaultDataOrderDetails",
    method: "GET",
    handler: OrderStatusController.getDefaultDataOrderDetails
},
{
    path: "/order/getInitDataOfCustomerInfoForClientPlaceOrder",
    method: "GET",
    handler: OrderCustomerController.getInitDataOfCustomerInfoForClientPlaceOrder
},
{
    path: "/order/updateClientPlaceOrderCustomerData",
    method: "POST",
    handler: OrderCustomerController.updateClientPlaceOrderCustomerData
},
{
    path: "/order/assignVendor",
    method: "POST",
    handler: OrderController.assignVendor
},
{
    path: "/order/autoAssign",
    method: "POST",
    handler: OrderController.autoAssign
},
{
    path: "/order/cancelAutoAssign",
    method: "POST",
    handler: OrderController.cancelAutoAssign
},
{
    path: "/order/getVendorLog",
    method: "GET",
    handler: OrderController.getVendorLog
},
{
    path: "/order/removeVendorFromOrder",
    method: "POST",
    handler: OrderController.removeVendorFromOrder
},
{
    path: "/order/getOrderAutoProgress",
    method: "GET",
    handler: OrderController.getOrderAutoProgress
},
{
    path: "/order/updateAppointmentDetailsData",
    method: "POST",
    handler: OrderController.updateAppointmentDetailsData
},
{
    path: "/order/updateOrderSpecialIns",
    method: "POST",
    handler: OrderSpecController.updateOrderSpecialIns
},
{
    path: "/order/getListOrderAdditionalFee",
    method: "GET",
    handler: OrderStatusController.getListOrderAdditionalFee
},
{
    path: "/order/updateListOrderAddionalFee",
    method: "POST",
    handler: OrderFeeController.updateListOrderAddionalFee
},
{
    path: "/order/getOrderDetailLeftPanelInitData",
    method: "GET",
    handler: OrderController.getOrderDetailLeftPanelInitData
},
{
    path: "/order/getVendorOrderDetailLeftPanelInitData",
    method: "GET",
    handler: OrderController.getVendorOrderDetailLeftPanelInitData
},
{
    path: "/order/getVendorOrderDetailMainPanelInitData",
    method: "GET",
    handler: OrderController.getVendorOrderDetailMainPanelInitData
},
{
    path: "/order/getAppointmentDetailsInitData",
    method: "GET",
    handler: OrderController.getAppointmentDetailsInitData
},
{
    path: "/order/checkGeneralInfoOfClientWhenPlaceOrder",
    method: "GET",
    handler: OrderController.checkGeneralInfoOfClientWhenPlaceOrder
},
{
    path: "/order/checkOrderService",
    method: "GET",
    handler: OrderController.checkOrderService
},
{
    path: "/order/getOrdersFeeApprovalRequest",
    method: "GET",
    handler: OrderFeeApproveController.getOrdersFeeApprovalRequest
},
{
    path: "/order/getOrdersClientStaff",
    method: "GET",
    handler: OrderClientController.getOrdersClientStaff
},
{
    path: "/order/updateOrdersFeeApprove",
    method: "POST",
    handler: OrderFeeApproveController.updateOrdersFeeApprove
},
{
    path: "/order/checkOrderStatusForApprove",
    method: "GET",
    handler: OrderController.checkOrderStatusForApprove
},
{
    path: "/order/getOrderDetailLeftPanelFeeInitData",
    method: "GET",
    handler: OrderController.getOrderDetailLeftPanelFeeInitData
},
{
    path: "/order/getOrderDetailLeftPanelShippingInitData",
    method: "GET",
    handler: OrderController.getOrderDetailLeftPanelShippingInitData
},
{
    path: "/order/saveLeftPanelFees",
    method: "POST",
    handler: OrderController.saveLeftPanelFees
},
{
    path: "/order/updateLeftPanel",
    method: "POST",
    handler: OrderController.updateLeftPanel
},
{
    path: "/order/updateAppointment",
    method: "POST",
    handler: OrderController.updateAppointment
},
{
    path: "/order/sendOrderConfirmAndBasicInfo",
    method: "POST",
    handler: OrderController.sendOrderConfirmAndBasicInfo
},
{
    path: "/order/sendEmailCloseRequestForOrder",
    method: "GET",
    handler: OrderController.sendEmailCloseRequestForOrder
},
{
    path: "/order/getOrdersProgressId",
    method: "GET",
    handler: OrderController.getOrdersProgressId
},
{
    path: "/order/getRightPanelDocsData",
    method: "GET",
    handler: OrderController.getRightPanelDocsData
},
{
    path: "/order/updateProgressManually",
    method: "POST",
    handler: OrderController.updateProgressManually
},
{
    path: "/order/checkValidOrderId",
    method: "GET",
    handler: OrderController.checkValidOrderId
},
{
    path: "/order/getAllProblemTypes",
    method: "GET",
    handler: OrderController.getAllProblemTypes
},
{
    path: "/order/checkIsSelfService",
    method: "GET",
    handler: OrderController.checkIsSelfService
},
{
    path: "/order/shareAllDocsByOrderId",
    method: "GET",
    handler: OrderDocController.shareAllDocsByOrderId
},
{
    path: "/order/changeStatusOnFirstDocUploaded",
    method: "GET",
    handler: OrderStatusController.changeStatusOnFirstDocUploaded
},
{
    path: "/order/getOrderProgressClientDashboard",
    method: "GET",
    handler: OrderController.getOrderProgressClientDashboard
},
{
    path: "/order/getOrderProgressClient",
    method: "GET",
    handler: OrderClientController.getOrderProgressClient
},
{
    path: "/order/getInitSearchOrdersClient",
    method: "GET",
    handler: OrderClientController.getInitSearchOrdersClient
},
{
    path: "/order/updateOrder",
    method: "POST",
    handler: OrderController.updateOrder
},
{
    path: "/order/getListDocRejectReason",
    method: "GET",
    handler: OrderDocController.getListRejectReason
},
{
    path: "/order/sendEmailRejectSignedDoc",
    method: "GET",
    handler: OrderDocController.sendEmailRejectSignedDoc
},
{
    path: "/order/getClientDocuments",
    method: "POST",
    handler: OrderDocController.getClientDocuments
},
{
    path: "/order/getListOrderDocComments",
    method: "GET",
    handler: OrderDocController.getListOrderDocComments
},
{
    path: "/order/addOrderDocAdditionalComment",
    method: "POST",
    handler: OrderDocController.addOrderDocAdditionalComment
},
{
    path: "/order/getUserNameScheduler",
    method: "GET",
    config: {
        auth: false
    },
    handler: OrderController.getUserNameScheduler
},
{
    path: "/order/getFaxBackReq",
    method: "GET",
    handler: OrderController.getFaxBackReq
},
{
    path: "/order/getSignerDocs",
    method: "GET",
    handler: OrderDocController.getSignerDocs
},
{
    path: "/order/shareAllSignerDoc",
    method: "POST",
    handler: OrderDocController.shareAllSignerDoc
}
];


export default routes;