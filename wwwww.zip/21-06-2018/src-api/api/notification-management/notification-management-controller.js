import Boom from "boom";
import Bookshelf from "../../db/database";
import moment from "moment";
import NotificationManagement from "../../db/model/notification-management";
import sendMailCore from "../../mail/mail-helper";
import Announcement from "../../db/model/announcement";
import AnnouncementState from "../../db/model/announcement-state";
import AnnouncementLoanType from "../../db/model/announcement-loan-type";
import SmsController from "../sms/sms-controller";
import {
    handleSingleQuote
} from "../../helper/common-helper";

class NotificationManagementController {

    getAllNotificationManagement(request, reply) {
        const {
            notificationType,
            purpose,
            sortColumn,
            sortDirection,
            page,
            itemPerPage
        } = request.query;

        const newPurpose = (purpose === "" || purpose === undefined) ? "" : handleSingleQuote(purpose);
        const rawSql = `call GetNotificationManagement(
			'${notificationType}',
            '${newPurpose}',
            '${sortColumn}',
            ${sortDirection},
            ${page},
            ${itemPerPage}
        )`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getNotifByNotifID(request, reply) {
        const {
            notificationId
        } = request.query;

        const rawSql = `call GetNotifByNotifID(${notificationId})`;
        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                const rawData = [];
                result[0][0].map((item) => {
                    const rawItem = item;
                    rawData.push(rawItem);
                });
                reply({
                    notif: rawData
                });
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
    }
    updateNotif(request, reply) {
        const input = request.payload;
        NotificationManagement.where({
            NotifID: input.notificationId
        }).save({
            Type: input.notificationType,
            Purpose: input.purpose,
            FromEmail: input.fromEmail,
            Receiver: input.receiver,
            Subject: input.subject,
            Message: input.message
        }, {
                method: "update"
            }).then((result) => {
                if (result === null) {
                    reply(Boom.badRequest(`Data is null`));
                    return;
                } else {
                    reply({
                        status: true
                    });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    sendEMail(request, reply) {
        const options = request.payload;

        const mailOptions = {
            from: options.from,
            to: options.to,
            subject: options.subject,
            text: options.text || "",
            html: options.html
        };

        sendMailCore(mailOptions, (result) => {
            return reply(result);
        });
    }

    sendSms(request, reply) {
        SmsController.sendSms(request, reply);
    }

    // Annoucements Controller
    getAnnoucements(request, reply) {
        const {
            sortDirection,
            page,
            itemPerPage,
            status,
            audiences,
            title
        } = request.query;

        const newTitle = (title === "" || title === undefined) ? "" : handleSingleQuote(title);
        const rawSql = `call GetAnnouncements( ${sortDirection},${page},${itemPerPage},'${status}','${audiences}','${newTitle}')`;
        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        announcements: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

    }

    addNewAnnouncement(request, reply) {
        const {
            title,
            audiences,
            disappearTime,
            content,
            status,
            statesSelected,
            productsSelected
        } = request.payload;

        const AnnouncementStates = Bookshelf.Collection.extend({
            model: AnnouncementState
        });
        const AnnouncementLoanTypes = Bookshelf.Collection.extend({
            model: AnnouncementLoanType
        });
        new Announcement().save({
            Title: title,
            Content: content,
            Status: status,
            Audience: audiences,
            NumOfAppearance: disappearTime,
            CreatedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        }, {
                method: "insert"
            }).then((result) => {
                const addingStatus = result === null || result === undefined ? false : true;
                const announcement = result;
                const statesWillBeInsert = [];
                if (statesSelected.length > 0) {
                    statesSelected.forEach((stateItem) => {
                        statesWillBeInsert.push({
                            AnnouncementID: announcement.id,
                            State: stateItem.value
                        });
                    });
                }
                AnnouncementStates.forge(statesWillBeInsert).invokeThen("save")
                    .then((statesResult) => {

                        const loanTypesWillBeInsert = [];
                        if (productsSelected.length > 0) {
                            productsSelected.forEach((loanItem) => {
                                loanTypesWillBeInsert.push({
                                    AnnouncementID: announcement.id,
                                    LoanTypeId: loanItem.value
                                });
                            });
                        }

                        AnnouncementLoanTypes.forge(loanTypesWillBeInsert).invokeThen("save")
                            .then(
                            (loanResult) => {
                                reply({
                                    status: addingStatus,
                                    Announcement: announcement,
                                    statesResult,
                                    loanResult
                                });
                            });
                    });
            })
            .catch((error) => {
                reply(Boom.badRequest(error));
            });

    }

    updateAnnouncement(request, reply) {
        const {
            announcementID,
            title,
            audiences,
            disappearTime,
            content,
            status,
            statesSelected,
            productsSelected
        } = request.payload;
        const AnnouncementStates = Bookshelf.Collection.extend({
            model: AnnouncementState
        });
        const AnnouncementLoanTypes = Bookshelf.Collection.extend({
            model: AnnouncementLoanType
        });
        const statesWillBeInsert = [];
        if (statesSelected.length > 0) {
            statesSelected.forEach((stateItem) => {
                statesWillBeInsert.push({
                    AnnouncementID: announcementID,
                    State: stateItem.value
                });
            });
        }
        const loanTypesWillBeInsert = [];
        if (productsSelected.length > 0) {
            productsSelected.forEach((loanItem) => {
                loanTypesWillBeInsert.push({
                    AnnouncementID: announcementID,
                    LoanTypeId: loanItem.value
                });
            });
        }

        const insertNewStatesAndLoanTypes = (statusBeRep, announcement) => {
            AnnouncementStates.forge(statesWillBeInsert).invokeThen("save").then((stateRS) => {
                if (stateRS) {
                    AnnouncementLoanTypes.forge(loanTypesWillBeInsert).invokeThen("save").then(((loanRs) => {
                        if (loanRs) {
                            reply({
                                status: statusBeRep,
                                announcement,
                                stateRS,
                                loanRs
                            });
                        }

                    }));
                }
            });
        };

        new Announcement().where({
            AnnouncementID: announcementID
        }).save({
            Title: title,
            Content: content,
            Status: status,
            Audience: audiences,
            NumOfAppearance: disappearTime
        }, {
                method: "update"
            }).then((result) => {
                const updatingStatus = result === null || result === undefined ? false : true;
                const deltatesAndLoanTypesOfAnnSQL = `call DelStatesAndLoantypesByAnnID(${announcementID})`;
                Bookshelf.knex.raw(deltatesAndLoanTypesOfAnnSQL)
                    .then((delRs) => {
                        if (delRs) {
                            insertNewStatesAndLoanTypes(updatingStatus, result);
                        } else {
                            reply({
                                status: false
                            });
                        }
                    }).catch((error) => {
                        reply(Boom.badRequest(error));
                    });

            })
            .catch((error) => {
                reply(Boom.badRequest(error));
            });

    }

    updateAnnouncementStatus(request, reply) {
        const {
            announcementID,
            status
        } = request.payload;
        new Announcement().where({
            AnnouncementID: announcementID
        }).save({
            Status: status,
            PublicDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        }, {
                method: "update"
            })
            .then((result) => {
                const updatingStatus = result === null || result === undefined ? false : true;
                reply({
                    status: updatingStatus,
                    Announcement: result
                });
            })
            .catch((error) => {
                reply(Boom.badRequest(error));
            });

    }

    deleteAnnouncement(request, reply) {
        const {
            announcementID
        } = request.query;

        const deltatesAndLoanTypesOfAnnSQL = `call DelStatesAndLoantypesByAnnID(${announcementID})`;
        Bookshelf.knex.raw(deltatesAndLoanTypesOfAnnSQL)
            .then((delRs) => {
                if (delRs !== null) {
                    Announcement.where({
                        AnnouncementID: announcementID
                    }).destroy()
                        .then((result) => {
                            if (result !== null) {
                                reply({
                                    status: true
                                });
                            } else {
                                reply({
                                    status: false
                                });
                            }
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                }

            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getLoanTypeAndState(request, reply) {
        const getStateSql = "call GetAllState";
        const getLoanSql = "call GetAllLoanType()";
        Bookshelf.knex.raw(getStateSql)
            .then((stateResult) => {
                const states = stateResult[0][0];
                Bookshelf.knex.raw(getLoanSql).then(loanResult => {
                    const loanTypes = loanResult[0][0];
                    reply({
                        states,
                        loanTypes
                    });
                }).catch(lError => {
                    reply(Boom.badRequest(lError));
                });
            }).catch((sError) => {
                reply(Boom.badRequest(sError));
            });

    }

    getAnnouncementInfo(request, reply) {
        const {
            announcementID
        } = request.query;

        const getStateSql = `call GetAnnouncementInfo(${announcementID})`;
        Bookshelf.knex.raw(getStateSql)
            .then((result) => {
                const states = result[0][0];
                const loanTypes = result[0][1];
                const announcement = result[0][2][0];
                announcement.states = states;
                announcement.loanTypes = loanTypes;

                reply({
                    announcement
                });
            }).catch((sError) => {
                reply(Boom.badRequest(sError));
            });

    }
}
export default new NotificationManagementController();