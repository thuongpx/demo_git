import NotaryTraning from "./vendor-notary-training-controller";

const routes = [
    {
        path: "/notarytraning/getlistRegisteredPrograms",
        method: "GET",
        handler: NotaryTraning.getlistRegisteredPrograms
    },
    {
        path: "/notarytraning/getListCourseandTestbyProgramId",
        method: "GET",
        handler: NotaryTraning.getListCourseandTestbyProgramId
    },
    {
        path: "/vendor-notary-training-controller/getListLearningPath",
        method: "GET",
        handler: NotaryTraning.getListLearningPath
    },
    {
        path: "/vendor-notary-training-controller/getListOfPopularPrograms",
        method: "GET",
        handler: NotaryTraning.getListOfPopularPrograms
    },
    {
        path: "/notarytraning/getlistAllPrograms",
        method: "GET",
        handler: NotaryTraning.getlistAllPrograms
    },
    {
        path: "/vendor-notary-training-controller/getListRecentlyCourseByVendorId",
        method: "GET",
        handler: NotaryTraning.getListRecentlyCourseByVendorId
    }

    // ,
    // {
    //     path: "/notarytraning/getListTestbyProgramId",
    //     method: "GET",
    //     handler: NotaryTraning.getListTestbyProgramId
    // }
];


export default routes;