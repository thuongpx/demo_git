import Boom from "boom";
import Bookshelf from "./../../db/database";
import ReturnAddress from "./../../db/model/return-addr";

class OrderDateController {
    constructor() { }

    getReturnDocsData(request, reply) {
        Bookshelf.knex.raw(`call GetAllState`)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0]
                    });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    addNewReturnDocsData(request, reply) {
        const newReturnDocsAddress = request.payload;

        new ReturnAddress().save({
            BrokerId: newReturnDocsAddress.BrokerId,
            Department: newReturnDocsAddress.departmentInput,
            Address: newReturnDocsAddress.addressInput,
            Suite: newReturnDocsAddress.suiteNumberInput,
            City: newReturnDocsAddress.cityInput,
            State: newReturnDocsAddress.stateInput,
            Zip: newReturnDocsAddress.zipInput,
            DefaultAddr: "Y"
        },
            { method: "insert" }).then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });

                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }
}

export default new OrderDateController();