import Boom from "boom";
import Bookshelf from "../../db/database";
import Agent from "../../db/model/agents";
import User from "../../db/model/users";
import UserRole from "../../db/model/user-roles";
import RolePermission from "../../db/model/role-permission";
import Jwt from "../../lib/jwt";
import moment from "moment";
import {
	handleSingleQuote,
	isBuffer,
	bufferToBoolean
} from "../../helper/common-helper";

class AgentController {
	constructor() {}

	getAgentById(request, reply) {
		const {
			agentId
		} = request.query;

		Bookshelf.knex.select("agent.AgentId", "agent.TenantId", "agent.Ext", "agent.Fax", "agent.Email",
				"agent.AfterhoursPhone", "agent.Inactive", "agent.BranchID", "agent.Direct",
				"agent.ViewAll", "agent.BrokerId", "agent.FirstName", "agent.LastName", "agent.NeedResetPassword", "broker.Company", "agent.FirstName", "agent.LastName")
			.from("agent")
			.innerJoin("broker", "agent.BrokerId", "=", "broker.BrokerID")
			.where("AgentId", agentId)
			.then((result) => {
				if (result.length > 0) {
					const agent = result[0];
					Object.keys(agent).forEach((key) => {
						const value = agent[key];
						if (isBuffer(value)) {
							agent[key] = bufferToBoolean(value);
						}
					});
					reply(agent);
				} else {
					reply(Boom.badRequest("Agent not found"));
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});

		return;
	}

	getAgentsByBrokerId(request, reply) {
		const {
			brokerId,
			sortColumn,
			sortDirection,
			page,
			itemPerPage
		} = request.query;

		Bookshelf.knex.raw(`call GetAgentsByBrokerId(${brokerId},'${sortColumn}',${sortDirection},${page},
			${itemPerPage})`)
			.then((result) => {
				if (result !== null) {
					reply({
						data: result[0][0],
						totalRecords: result[0][1][0].TotalRecords
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		return reply;
	}

	addAgent(request, reply) {
		const agent = request.payload.agent;
		const user = request.payload.user;
		const username = user.Username;
		const password = user.Password;
		delete agent.BranchID;

		User.where({
			username
		}).count("*").then((count) => {
			if (count === 0) {
				const newAgent = new Agent(agent);
				newAgent.save(null, {
					method: "insert"
				}).then((result) => {
					if (result && result.attributes) {

						const newAgentId = result.attributes.id;
						let roleId = 1;

						const addUserSuccess = (userModel) => {
							const usersId = userModel.get("id");
							new UserRole().save({
								UsersId: usersId,
								RoleId: roleId
							}, {
								method: "insert"
							}).then(() => {
								return reply({
									isSuccess: true
								});
							}).catch(error => reply(Boom.badRequest(error)));
						};

						RolePermission.where({
							RoleName: "Agent",
							Type: "Client"
						}).fetch().then((roleResult) => {
							if (roleResult && roleResult.attributes) {
								roleId = roleResult.attributes.RoleId;
							}

							const salt = Jwt.generateSalt();
							const hashedPassword = Jwt.hash(password, salt);

							new User().save({
									Username: username,
									Password: hashedPassword,
									MappingUserId: newAgentId,
									HashSalt: salt,
									DateCreated: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
									TenantId: 1
								}, {
									method: "insert"
								})
								.then(addUserSuccess).catch((error) => {
									return reply(Boom.badRequest(error));
								});
						}).catch((error) => {
							return reply(Boom.badRequest(error));
						});
					}
				}).catch((error) => {
					return reply(Boom.badRequest(error));
				});
			} else {
				return reply({
					isSuccess: false
				});
			}
		});
	}

	updateAgent(request, reply) {
		const agent = request.payload;
		delete agent.BranchID;
		delete agent.Company;

		Agent.where({
			AgentId: agent.AgentId
		}).save(agent, {
			method: "update"
		}).then((result) => {
			if (result !== null) {
				reply({
					isSuccess: true
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	deactivateAgent(request, reply) {
		const {
			agentId,
			inActive
		} = request.payload;
		Agent.where({
			agentId
		}).save({
			inActive
		}, {
			method: "update"
		}).then(() => {
			reply({
				isSuccess: true
			});
		}).catch(error => reply(Boom.badRequest(error)));
	}

	disableOrActiveAgent(request, reply) {
		const agent = request.payload;

		Agent.where({
			AgentId: agent.AgentId
		}).save(agent, {
			method: "update"
		}).then((result) => {
			if (result !== null) {

				const findUserSql = `
				SELECT U.UsersId
				FROM \`users\` U
				JOIN \`user_roles\` UL ON U.UsersId = UL.UsersId AND UL.RoleId = 7
				WHERE MappingUserId = ${agent.AgentId};`;

				Bookshelf.knex.raw(findUserSql)
					.then(findUserResult => {
						if (findUserResult !== null) {
							const inactiveUsersSql = `UPDATE \`users\` SET Inactive = ${agent.Inactive} WHERE UsersId = ${findUserResult[0][0].UsersId}`;

							Bookshelf.knex.raw(inactiveUsersSql)
								.then(inactiveUsersResult => {
									if (inactiveUsersResult !== null) {
										reply({
											isSuccess: true
										});
									}
									return;
								}).catch((error) => {
									reply(Boom.badRequest(error));
									return;
								});
						}
						return;
					}).catch((error) => {
						reply(Boom.badRequest(error));
						return;
					});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
			return;
		});
	}

	getAgentByOption(request, reply) {
		const {
			brokerId,
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			agentId,
			agentName,
			agentEmail,
			company,
			userName
		} = request.query;
		const newAgentId = (agentId === "" || agentId === undefined) ? null : agentId;
		const newAgentName = (agentName === "" || agentName === undefined) ? "" : handleSingleQuote(agentName);
		const newAgentEmail = (agentEmail === "" || agentEmail === undefined) ? "" : handleSingleQuote(agentEmail);
		const newCompany = (company === "" || company === undefined) ? "" : handleSingleQuote(company);
		const newUserName = (userName === "" || userName === undefined) ? "" : handleSingleQuote(userName);
		const rawSql = `call GetAgentByOption( ${brokerId}, '${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${newAgentId}, '${newAgentName}', '${newAgentEmail}', '${newCompany}', '${newUserName}')`;

		Bookshelf.knex.raw(rawSql)
			.then((result) => {
				if (result !== null) {
					reply({
						data: result[0][0],
						totalRecords: result[0][1][0].TotalRecords
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

}

export default new AgentController();