import AgentController from "./agent-controller";

const routes = [{
    path: "/agent/getAgentsByBrokerId",
    method: "GET",
    handler: AgentController.getAgentsByBrokerId
},
{
    path: "/agent/addAgent",
    method: "POST",
    handler: AgentController.addAgent
},
{
    path: "/agent/updateAgent",
    method: "POST",
    handler: AgentController.updateAgent
},
{
    path: "/agent/getAgentById",
    method: "GET",
    handler: AgentController.getAgentById
},
{
    path: "/agent/deactivateAgent",
    method: "POST",
    config: { auth: false },
    handler: AgentController.deactivateAgent
},
{
    path: "/agent/getAgentByOption",
    method: "GET",
    handler: AgentController.getAgentByOption
},
{
    path: "/agent/disableOrActiveAgent",
    method: "POST",
    handler: AgentController.disableOrActiveAgent
}
];

export default routes;