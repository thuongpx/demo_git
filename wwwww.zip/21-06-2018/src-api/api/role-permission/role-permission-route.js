import RolePermissionController from "./role-permission-controller";

const routes = [{
    path: "/rolePermission/getRolePermissions",
    method: "GET",
    handler: RolePermissionController.getRolePermission
},
{
    path: "/rolePermission/getConsoleStaffUser",
    method: "GET",
    handler: RolePermissionController.getConsoleStaffUser
},
{
    path: "/rolePermission/updateRolePermissions",
    method: "PUT",
    handler: RolePermissionController.updateRolePermissions
}];

export default routes;