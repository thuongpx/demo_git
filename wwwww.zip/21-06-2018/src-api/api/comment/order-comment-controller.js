import Comment from "../../db/model/comment";
import Boom from "boom";
import Bookshelf from "../../db/database";
import moment from "moment";
import {
    hasValue
} from "../../helper/common-helper";

class OrderCommentController {

    // Get Comment MySQL
    getComments(request, reply) {

        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            orderId,
            roleType
        } = request.query;
        const rawSql = `call GetOrderComment('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId === undefined ? null : `${orderId}`}, '${roleType}')`;
        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });

                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return;
            });

        return reply;
    }

    // Add Comment MySQL
    addComment(request, reply) {
        const comment = request.payload;
        new Comment().save({
            Description: comment.Description,
            CreatedBy: comment.CreatedBy, // ? userId
            TypeID: comment.TypeID, // ? constants
            OwnerID: comment.OwnerID, // ? orderId
            ParentID: comment.ParentID,
            CreatedDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            IsPrivate: comment.IsPrivate ? comment.IsPrivate : 0
        }, {
                method: "insert"
            }).then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true
                    });

                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return;
            });
    }

    addMultiComment(request, reply) {
        const data = request.payload;
        const Comments = Bookshelf.Collection.extend({
            model: Comment
        });

        if (data) {
            data.forEach(x => {
                x.CreatedDate = moment().utc().format("YYYY-MM-DD HH:mm:ss");
            });
        }

        const comments = Comments.forge(data);

        comments.invokeThen("save").then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });
            }
        }).catch(error => {
            reply(Boom.badRequest(`${error.code}: ${error.sqlMessage}`));
        });

    }

    deleteComment(request, reply) {
        const CommentID = request.payload;
        Comment.where(CommentID).destroy().then((result) => {

            if (result !== null) {
                reply({
                    isSuccess: true
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getCommentByType(request, reply) {
        const {
            typeId,
            ownerId
        } = request.query;

        const rawSql = `SELECT Description, CommentID, CreatedDate, u.UserName As UserName, u.ProfilePicture As img, u.UsersId AS usersId ` +
            `FROM comment AS c INNER JOIN users AS u ON u.UsersId=c.CreatedBy ` +
            `WHERE TypeID=${typeId} AND OwnerID=${ownerId} ORDER BY CommentID ASC`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    result[0].map(item => {
                        item.img = hasValue(item.img) ? item.img : "";
                    });
                    reply(result[0]);
                    console.log(result[0]);
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getOrderCommentWithUserData(request, reply) {
        const {
            typeId,
            ownerId
        } = request.query;

        const rawSql = `
            SELECT C.commentID, C.description, C.IsPrivate, C.createdDate, U.userName, GetProfilePictureByUserId(U.UsersId) as img, GetFullNameByUserId(U.UsersId) AS fullName, U.usersId
            FROM
                comment C
                INNER JOIN users U
                    ON U.UsersId=C.CreatedBy 
                    AND C.TypeID=${typeId} AND C.OwnerID=${ownerId}
            ORDER BY CreatedDate ASC;`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    result[0].map(item => {
                        item.img = hasValue(item.img) ? item.img.toString() : "";
                    });
                    reply({
                        orderComments: result[0]
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
}

export default new OrderCommentController();