export default {
	production: {
		port: process.env.PORT,
		secretKey: "AT595r768gqHdSLqzew746hNp5VrpN7a"
	},
	development: {
		host: "0.0.0.0",
		port: 8000,
		secretKey: "lF7ioZHOa4iafmUfhcWwkUFRb7P7F09K"
	},
	test: {
		port: process.env.PORT,
		secretKey: "UdeyPg9xXlXVFZc6HZ4yLZcnuNlAV8Ag"
	}
};
