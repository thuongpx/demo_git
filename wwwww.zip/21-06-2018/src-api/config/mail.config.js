export default {
        production: {
                host: "10.133.28.50",
                port: 25,
                timeout: 10,
                user: "pavaso01",
                pass: "abc123",
                webOrders: "weborders@theclosingexchange.com",
                faxBacks: "faxbacks@theclosingexchange.com "
        },
        development: {
                host: "10.133.28.50",
                port: 25,
                timeout: 10,
                user: "pavaso01",
                pass: "abc123",
                webOrders: "pavaso01@adb.com",
                faxBacks: "pavaso01@adb.com"
        },
        test: {
                host: "10.133.28.50",
                port: 25,
                timeout: 10,
                user: "pavaso01",
                pass: "abc123",
                webOrders: "weborders@theclosingexchange.com",
                faxBacks: "faxbacks@theclosingexchange.com "
        }
};