export default {
        production: {
                host: "notarydirect-com.mail.protection.outlook.com",
                port: 25,
                timeout: 10
        },
        development: {
                host: "notarydirect-com.mail.protection.outlook.com",
                port: 25,
                timeout: 10
        },
        test: {
                host: "notarydirect-com.mail.protection.outlook.com",
                port: 25,
                timeout: 10
        }
};