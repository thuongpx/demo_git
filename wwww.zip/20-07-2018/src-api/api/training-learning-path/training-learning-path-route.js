import TrainingLearningPathController from "./training-learning-path-controller";
const routes = [
    {
        path: "/training-learning-path/getTrainingLearningPath",
        method: "GET",
        handler: TrainingLearningPathController.getTrainingLearningPath
    },
    {
        path: "/training-learning-path/deleteTrainingLearningPath",
        method: "POST",
        handler: TrainingLearningPathController.deleteTrainingLearningPath
    },
    {
        path: "/training-learning-path/addLearningPath",
        method: "POST",
        handler: TrainingLearningPathController.addLearningPath
    },
    {
        path: "/training-learning-path/getRequiredPrograms",
        method: "GET",
        handler: TrainingLearningPathController.getRequiredProgramOfLearningPath
    },
    {
        path: "/training-learning-path/updateLearningPath",
        method: "POST",
        handler: TrainingLearningPathController.updateLearningPath
    },
    {
        path: "/training-learning-path/checkExistLearningPath",
        method: "GET",
        handler: TrainingLearningPathController.checkExistLearningPath
    }
];

export default routes;