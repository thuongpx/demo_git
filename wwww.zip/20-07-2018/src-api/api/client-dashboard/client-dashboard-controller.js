import Boom from "boom";
import Bookshelf from "./../../db/database";

class ClientDashboardController {
    constructor() { }

    getUnfilledOrderDashboard(request, reply) {
        const {
            page,
            itemPerPage,
            role,
            clientId
        } = request.query;
        const rawSqlUnfilledOrder = `call GetUnfilledOrderDashboard(${page},${itemPerPage},'${role}',${clientId})`;

        Bookshelf.knex.raw(rawSqlUnfilledOrder)
            .then((result) => {
                if (result !== null) {
                    reply({
                        unfilledOrdersApproachingList: result[0][0],
                        unfilledOrdersApproachingTotalRecord: result[0][1][0].TotalRecordsUnfilledApproaching,
                        unfilledOrdersOutList: result[0][2],
                        unfilledOrdersOutTotalRecord: result[0][3][0].TotalRecordsUnfilledOut
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getPendingOrderDashboard(request, reply) {
        const {
            page,
            itemPerPage,
            role,
            clientId
        } = request.query;
        const rawSqlPendingOrder = `call GetPendingOrderDashboard(${page},${itemPerPage},'${role}',${clientId})`;

        Bookshelf.knex.raw(rawSqlPendingOrder)
            .then((result) => {
                if (result !== null) {
                    reply({
                        pendingOrdersApproachingList: result[0][0],
                        pendingOrdersApproachingTotalRecord: result[0][1][0].TotalRecordsPendingApproaching,
                        pendingOrdersOutList: result[0][2],
                        pendingOrdersOutTotalRecord: result[0][3][0].TotalRecordsPendingOut
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getFaxbacksOrderDashboard(request, reply) {
        const {
            page,
            itemPerPage,
            role,
            clientId
        } = request.query;
        const rawSqlFaxbacksOrder = `call GetFaxbacksOrderDashboard(${page},${itemPerPage},'${role}',${clientId})`;

        Bookshelf.knex.raw(rawSqlFaxbacksOrder)
            .then((result) => {
                if (result !== null) {
                    reply({
                        faxbacksOrdersList: result[0][0],
                        faxbacksOrdersTotalRecord: result[0][1][0].TotalRecordsFaxbacks
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getOrdersInfoClientDashboard(request, reply) {
        const {
            role,
            clientId,
            timeZone
        } = request.query;
        const rawSqlFaxbacksOrder = `call GetOrdersInfoClientDashboard('${role}',${clientId},${timeZone})`;

        Bookshelf.knex.raw(rawSqlFaxbacksOrder)
            .then((result) => {
                if (result !== null) {
                    reply({
                        OpenSelfService: result[0][0][0].OpenSelfService,
                        OpenSLAApproachingSelfService: result[0][1][0].OpenSLAApproachingSelfService,
                        OpenSLAOutOfSelfService: result[0][2][0].OpenSLAOutOfSelfService,
                        OpenFullService: result[0][3][0].OpenFullService,
                        OpenSLAApproachingFullService: result[0][4][0].OpenSLAApproachingFullService,
                        OpenSLAOutOfFullService: result[0][5][0].OpenSLAOutOfFullService
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getOrdersInfoDetailClientDashboard(request, reply) {
        const {
            role,
            clientId,
            service,
            statusGroup,
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            timeZone
        } = request.query;
        const rawSqlOrders = `call GetOrdersInfoDetailClientDashboard('${role}',${clientId}, '${service}', '${statusGroup}',
        '${sortColumn}',${sortDirection},${page},${itemPerPage},${timeZone})`;

        Bookshelf.knex.raw(rawSqlOrders)
            .then((result) => {
                if (result !== null) {
                    switch (service) {
                        case "Self": {
                            if (statusGroup === "OpenAll") {
                                reply({
                                    OpenOrders: result[0][0],
                                    OpenOrdersTotal: result[0][1][0].TotalRecords,
                                    OpenOrdersSLAApproaching: result[0][2],
                                    OpenOrdersSLAApproachingTotal: result[0][3][0].TotalRecords,
                                    OpenOrdersSLAOutOf: result[0][4],
                                    OpenOrdersSLAOutOfTotal: result[0][5][0].TotalRecords
                                });
                            }
                            if (statusGroup === "Open") {
                                reply({
                                    OpenOrders: result[0][0],
                                    OpenOrdersTotal: result[0][1][0].TotalRecords
                                });
                            }
                            if (statusGroup === "OpenSLAApproaching") {
                                reply({
                                    OpenOrdersSLAApproaching: result[0][0],
                                    OpenOrdersSLAApproachingTotal: result[0][1][0].TotalRecords
                                });
                            }
                            if (statusGroup === "OpenSLAOutOf") {
                                reply({
                                    OpenOrdersSLAOutOf: result[0][0],
                                    OpenOrdersSLAOutOfTotal: result[0][1][0].TotalRecords
                                });
                            }
                            break;
                        }
                        case "Full": {
                            if (statusGroup === "Open") {
                                reply({
                                    OpenOrders: result[0][0],
                                    OpenOrdersTotal: result[0][1][0].TotalRecords,
                                    OpenOrdersSLAApproaching: result[0][2],
                                    OpenOrdersSLAApproachingTotal: result[0][3][0].TotalRecords,
                                    OpenOrdersSLAOutOf: result[0][4],
                                    OpenOrdersSLAOutOfTotal: result[0][5][0].TotalRecords
                                });
                            }
                            break;
                        }
                        default: {
                            reply({
                                isSuccess: false
                            });
                            break;
                        }
                    }
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
}

export default new ClientDashboardController();