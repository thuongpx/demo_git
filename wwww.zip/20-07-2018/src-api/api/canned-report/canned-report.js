import Bookshelf from "../../db/database";
import {
    hasStringValue
} from "../../helper/common-helper";

export const getOrderTypes = async () => {
    const rawSql = `SELECT LoanType FROM loan_type`;

    const rs = await Bookshelf.knex.raw(rawSql);

    if (rs) {
        return rs[0];
    }

    return [];
};

const _buildSqlWhereClause = (searchObject) => {
    const {
        orderStatus,
        orderType,
        dayFrom,
        dayTo,
        month,
        year,
        scheduler,
        customerName,
        date,
        milestone
    } = searchObject;
    let whereStr = "";
    let tSql = "";
    let isShowAll = true;

    // order type
    if (orderType && orderType.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < orderType.length; i++) {
            tSql += ` OR OrderType LIKE '${orderType[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // order status
    if (orderStatus && orderStatus.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < orderStatus.length; i++) {
            tSql += ` OR OrderStatus LIKE '${orderStatus[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // month
    // day from
    // day to
    if (month && month.length > 0) {
        tSql = "1 != 1";

        for (let i = 0; i < month.length; i++) {
            const fromDate = `${year}-${month[i].value}-${dayFrom}`;
            const toDate = `${year}-${month[i].value}-${dayTo}`;

            tSql += ` OR (OrderDate >= '${fromDate}' AND OrderDate <= '${toDate}')`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    // day to
    if (date) {
        tSql = "1 != 1";
        tSql += ` OR (Date LIKE '${date}')`;

        whereStr += ` AND (${tSql})`;
    }

    //scheduler
    if (scheduler && scheduler.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < scheduler.length; i++) {
            tSql += ` OR RepId LIKE '${scheduler[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }
    //customer
    if (customerName && customerName.length > 0) {
        tSql = "1 != 1";
        for (let i = 0; i < customerName.length; i++) {
            tSql += `OR customerName LIKE '${customerName[i].value || ""}'`;
        }

        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }
    // milestone
    if (milestone && milestone.length > 0) {
        tSql = "1 != 1";
        switch (milestone) {
            case "1":
                tSql += ` OR TotalClosedOrders >= 1 AND TotalClosedOrders < 25`;
                break;
            case "25":
                tSql += ` OR TotalClosedOrders >= 25 AND TotalClosedOrders < 50`;
                break;
            case "50":
                tSql += ` OR TotalClosedOrders >= 50 AND TotalClosedOrders < 100`;
                break;
            case "100":
                tSql += ` OR TotalClosedOrders >= 100 AND TotalClosedOrders < 250`;
                break;
            case "250":
                tSql += ` OR TotalClosedOrders >= 250 AND TotalClosedOrders < 500`;
                break;
            case "500":
                tSql += ` OR TotalClosedOrders >= 250 AND TotalClosedOrders < 500`;
                break;
        }
        whereStr += ` AND (${tSql})`;
        isShowAll = false;
    }

    return {
        whereStr,
        isShowAll
    };
};


export const buildSqlCountQuery = (viewName, criterias) => {
    const {
        searchObject
    } = criterias;

    let sqlStr = `SELECT Count(*) AS Num FROM ${viewName} WHERE 1 = 1`;
    let isShowAll = true;

    const whereObj = _buildSqlWhereClause(searchObject);

    isShowAll = whereObj.isShowAll;
    sqlStr += whereObj.whereStr;

    return {
        sqlStr,
        isShowAll
    };
};

export const buildSqlQuery = (viewName, criterias, listFetchColumn = []) => {
    const {
        searchObject,
        options
    } = criterias;

    let sqlStr = "";
    let isShowAll = true;

    if (Array.isArray(listFetchColumn) && listFetchColumn.length > 0) {
        let fetchColumnStr = ``;
        for (let i = 0; i < listFetchColumn.length; i++) {
            fetchColumnStr = `${fetchColumnStr}${listFetchColumn[i]}`;
            if (i < listFetchColumn.length - 1) fetchColumnStr = `${fetchColumnStr}, `;
        }

        sqlStr = `SELECT ${fetchColumnStr} FROM ${viewName} WHERE 1 = 1`;
    } else {
        sqlStr = `SELECT * FROM ${viewName} WHERE 1 = 1`;
    }
    const whereObj = _buildSqlWhereClause(searchObject);

    isShowAll = whereObj.isShowAll;
    sqlStr += whereObj.whereStr;

    if (options) {
        const {
            // sortColumn,
            // sortDirection,
            page,
            itemPerPage,
            groupBy
        } = options;

        //Group
        if (hasStringValue(groupBy)) {
            sqlStr += ` GROUP BY ${groupBy} `;
        }

        // offset and limit
        if (hasStringValue(page) && hasStringValue(itemPerPage)) {
            sqlStr += ` LIMIT ${itemPerPage} OFFSET ${(page - 1) * itemPerPage}`;
        }
    }

    // eslint-disable-next-line
    console.log(`SQL string:= ${sqlStr}`);

    return {
        sqlStr,
        isShowAll
    };
};

export const getScheduler = async () => {
    const rawSql = `SELECT CONCAT(e.FirstName, " ", e.LastName) AS FullName,
                        e.RepId AS RepId
                    FROM employees e
                    WHERE 
                        e.Status = 0
                        AND e.Accounting = 0
                        AND e.Manager is null
                        AND e.Active = 1;`;

    const rs = await Bookshelf.knex.raw(rawSql);
    if (rs) {
        return rs[0];
    }


    return [];
};