import CannedReportController from "./canned-report-controller";
import CustomerReportController from "./customer-report-controller";

const routes = [{
    path: "/cannedReport/fetchOrderByStatusChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchOrderByStatusChartData
},
{
    path: "/cannedReport/getInitDataForCannedReport",
    method: "GET",
    config: {
        auth: false
    },
    handler: CannedReportController.getInitDataForCannedReport
},
{
    path: "/cannedReport/fetchOrderByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchOrderByStatusGridData
},
{
    path: "/cannedReport/countOrderByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.countOrderByStatusGridData
},
{
    path: "/cannedReport/fetchOrderComparisonByBussinessChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchOrderComparisonByBussinessChartData
},
{
    path: "/cannedReport/fetchClosedOrdersByCustomersChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchClosedOrdersByCustomersChartData
},
{
    path: "/cannedReport/fetchOpenOrderTrendbyCustomers",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchOpenOrderTrendbyCustomers
},
{
    path: "/cannedReport/fetchAssignedOrderByAgentChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchAssignedOrderByAgentChartData
},
{
    path: "/cannedReport/fetchMilestonesChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchMilestonesChartData
},
{
    path: "/cannedReport/fetchMilestonesGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchMilestonesGridData
},
{
    path: "/cannedReport/countMilestonesGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countMilestonesGridData
},
{
    path: "/cannedReport/fetchDailyAutoAssignOrdersByStatusChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchDailyAutoAssignOrdersByStatusChartData
},
{
    path: "/cannedReport/fetchDailyAutoAssignOrdersByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchDailyAutoAssignOrdersByStatusGridData
},
{
    path: "/cannedReport/countDailyAutoAssignOrdersByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.countDailyAutoAssignOrdersByStatusGridData
},
{
    path: "/cannedReport/fetchDailyManualAssignOrdersByStatusChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchDailyManualAssignOrdersByStatusChartData
},
{
    path: "/cannedReport/fetchDailyManualAssignOrdersByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchDailyManualAssignOrdersByStatusGridData
},
{
    path: "/cannedReport/countDailyManualAssignOrdersByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.countDailyManualAssignOrdersByStatusGridData
},
{
    path: "/cannedReport/fetchEconomicChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchEconomicChartData
},
{
    path: "/cannedReport/countAssignedOrderListGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.countAssignedOrderListGridData
},
//
{
    path: "/cannedReport/addTemplateReport",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.addTemplateReport
}
];

export default routes;