import Bookshelf from "../../db/database";
import Boom from "boom";

import {
    buildSqlQuery,
    buildSqlCountQuery
} from "./canned-report";

class CustomerReportController {
    constructor() { }

    fetchMilestonesChartData(request, reply) {
        const sqlResult = buildSqlQuery("milestones_chart_v", request.payload);
        const { sqlStr } = sqlResult;
        const tData = {
            label: "All Data",
            data: []
        };

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                const labels = [1, 25, 50, 100, 250, 500];
                const datasets = [];

                for (let i = 0; i < labels.length; i++) {
                    const start = labels[i];
                    const end = (i === labels.length - 1) ? -1 : (labels[i + 1] - 1);
                    const f = rawData.filter(r => r.TotalClosedOrders >= start && (end === -1 || r.TotalClosedOrders < end));

                    tData.data.push(f.length);
                }

                datasets.push(tData);

                return reply({
                    labels,
                    datasets
                });

            }).catch(error => reply(Boom.badRequest(error)));
    }

    fetchMilestonesGridData(request, reply) {
        const sqlResult = buildSqlQuery("milestones_drilldown_v", request.payload);
        const { sqlStr } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];

                reply({ data });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countMilestonesGridData(request, reply) {
        const sqlResult = buildSqlCountQuery("milestones_drilldown_v", request.payload);
        const { sqlStr } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }
}

export default new CustomerReportController();