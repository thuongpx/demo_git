import BusinessHoursController from "./business-hours-controller";

const routes = [
    {
        path: "/business-hours/updateBusinessHours",
        method: "POST",
        handler: BusinessHoursController.updateBusinessHours
    },
    {
        path: "/business-hours/getBusinessHours",
        method: "GET",
        handler: BusinessHoursController.getBusinessHours
    },
    {
        path: "/biz-hours-except/addBizHoursExcept",
        method: "POST",
        handler: BusinessHoursController.addBizHoursExcept
    },
    {
        path: "/biz-hours-except/getBizHoursExcept",
        method: "GET",
        handler: BusinessHoursController.getBizHoursExcept
    },
    {
        path: "/biz-hours-except/deleteBizHoursExcept",
        method: "POST",
        handler: BusinessHoursController.deleteBizHoursExcept
    }];

export default routes;