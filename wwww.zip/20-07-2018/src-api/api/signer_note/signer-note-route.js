import SignerNoteController from "./signer-note-controller";


const routes = [{
    path: "/signer-note/getSignerNotes",
    method: "GET",
    handler: SignerNoteController.getSignerNotes
}, {
    path: "/signer-note/addSignerNote",
    method: "POST",
    handler: SignerNoteController.addSignerNote
}];


export default routes;