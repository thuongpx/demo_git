import User from "../../db/model/users";
import Boom from "boom";
import Broker from "../../db/model/brokers";
import { AUTH } from "../../constant/common-constant";
import Jwt from "../../lib/jwt";
import { hasStringValue, hasValue } from "../../helper/common-helper";


class ClientProfileCredentialsController {
    constructor() { }

    getUserProfileCredentials(request, reply) {
        const { accountId, userId } = request.query;

        User.where({
            UsersId: accountId
        }).fetch({ column: ["UsersId", "UserName", "MappingUserId", "Password"] })
            .then((account) => {
                if (account === null) {
                    reply(Boom.badRequest(AUTH.USER_NOT_FOUND));
                    return;
                }
                const { RoleId, UserName, Password } = account.attributes;
                // get broker information
                Broker.where({
                    BrokerID: userId
                }).fetch({ columns: ["BrokerID", "Email", "SecondEmail"] })
                    .then((credentials) => {
                        if (credentials === null) {
                            reply(Boom.badRequest(AUTH.USER_NOT_FOUND));
                            return;
                        }

                        const { Email, SecondEmail } = credentials.attributes;

                        reply({
                            roleId: RoleId,
                            userName: UserName,
                            email: Email,
                            email2: SecondEmail,
                            currentPassword: Password
                        });
                        return;
                    })
                    .catch((error) => {
                        reply(error);
                        return;
                    });
            });
    }

    updateUserProfileCredentials(request, reply) {
        const { userId, accountId, credentials } = request.payload;

        if (!hasValue(credentials) || !hasStringValue(userId) || !hasStringValue(accountId)) {
            reply(Boom.badRequest("Missing required value"));
            return;
        }

        const broker = {
            Email: credentials.email,
            SecondEmail: credentials.email2
        };

        const updateBroker = () => {
            Broker.where({ BrokerID: userId }).save(broker, { method: "update" }).then(() => {
                reply({
                    isSuccess: true
                });
                return;
            }).catch(error => {
                reply(Boom.badRequest(error));
            });
        };

        if (hasStringValue(credentials.currentPassword) || hasStringValue(credentials.newPassword) || hasStringValue(credentials.confirmPassword)) {
            // check current password first
            User.where({ UsersId: accountId }).fetch({ columns: ["HashSalt", "Password"] })
                .then((user) => {
                    if (user === null) {
                        reply(Boom.badRequest("Can not find this user"));
                        return;
                    }
                    const { HashSalt, Password } = user.attributes;

                    if (Jwt.checkPassword(Password, HashSalt, credentials.currentPassword)) {
                        // current password is correct
                        // then, update new password
                        User.where({ UsersId: accountId }).save({
                            Password: Jwt.hash(credentials.newPassword, HashSalt)
                        }, { method: "update" }).then((rs) => {
                            if (rs !== null) {
                                // done update password => update broker
                                updateBroker();
                            }
                            return;
                        });
                    } else {
                        reply(Boom.badRequest("Password is not matched"));
                        return;
                    }
                }).catch(error => reply(Boom.badRequest(error)));
        } else {
            // update only broker
            updateBroker();
        }
    }
}

export default new ClientProfileCredentialsController();