import VendorSentOfferController from "./vendor-sent-offer-controller";
const routes = [
    {
        path: "/vendor-sent-offer/getVendorSentOffer",
        method: "GET",
        handler: VendorSentOfferController.getVendorSentOffer
    }
];

export default routes;