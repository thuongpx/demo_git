import Boom from "boom";
import Bookshelf from "../../db/database";

class VendorHistoryController {

    getVendorHistory(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            orderId
        } = request.query;
        const rawSql = `call GetAllVendorHistory('${sortColumn}',${sortDirection},${page}, ${itemPerPage}, ${orderId})`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

    }

}
export default new VendorHistoryController();