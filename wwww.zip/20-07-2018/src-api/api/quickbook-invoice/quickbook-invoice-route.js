import QuickbookInvoiceController from "./quickbook-invoice-controller";

const routes = [{
    path: "/quickbook-invoice/exportQuickBook",
    method: "POST",
    handler: QuickbookInvoiceController.exportQuickBook
}, {
    path: "/quickbook-invoice/getQuickBooks",
    method: "POST",
    handler: QuickbookInvoiceController.getQuickBooks
}, {
    path: "/quickbook-invoice/deleteQuickBookInvoice",
    method: "POST",
    handler: QuickbookInvoiceController.deleteQuickBookInvoice
}, {
    path: "/quickbook-invoice/downloadQuickBookInvoice",
    method: "GET",
    handler: QuickbookInvoiceController.downloadQuickBookInvoice
}, {
    path: "/quickbook-invoice/getVendorList",
    method: "GET",
    handler: QuickbookInvoiceController.getVendorList
}, {
    path: "/quickbook-invoice/getBrokerList",
    method: "GET",
    handler: QuickbookInvoiceController.getBrokerList
}, {
    path: "/quickbook-invoice/getInvoiceReports",
    method: "POST",
    handler: QuickbookInvoiceController.getInvoiceReports
}];

export default routes;