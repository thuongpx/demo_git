import Bookshelf from "../../db/database";
import Boom from "boom";
import Client from "../../db/model/clients";
import State from "../../db/model/state";
import Courier from "../../db/model/courier";
import Employees from "../../db/model/employees";
import SalesRep from "../../db/model/sales-reps";
import Fee from "../../db/model/fees";
import BrokerFee from "../../db/model/broker-fee";
import Users, { sendEmailHelper, resetPassword } from "../../db/model/users";
import {
	handleSingleQuote,
	hasStringValue,
	bufferToBoolean,
	isBuffer
} from "../../helper/common-helper";
import pdf from "html-pdf";
import moment from "moment";
import {
	STORE_PATH
} from "../../helper/file-helper";
import fs from "fs";

class ClientController {
	constructor() { }

	getClientById(request, reply) {
		const brokerId = request.query;
		const rawSql = `SELECT b.BrokerID, b.Company, b.Inactive FROM broker b where (b.GID is null or b.GID = 0) and (b.Inactive is null or b.Inactive = 0) and b.IsAvailable = 1 and b.BrokerID !=${brokerId.brokerId};`;
		const getAllClientActive = Promise.resolve(Bookshelf.knex.raw(rawSql));
		const getAllCourier = Promise.resolve(Courier.fetchAll({
			columns: ["CourierID", "Courier"]
		}));
		const getAllStates = Promise.resolve(State.fetchAll({
			columns: ["Code", "Description"]
		}));
		const getAllEmployees = Promise.resolve(Employees.fetchAll({
			columns: ["RepId", "FirstName", "LastName"]
		}));
		const getAllSaleReps = Promise.resolve(SalesRep.fetchAll({
			columns: ["SalesRepId", "FirstName", "LastName", "CommissionPercent", "CommissionAmount"]
		}));
		const ralSqlGetAllIndustry = "select industryId, description, parentId from industry order by Description;";
		const getAllIndustry = Promise.resolve(Bookshelf.knex.raw(ralSqlGetAllIndustry));
		let promiseData;
		if (brokerId !== 0 || brokerId !== undefined) {
			const getClient = Promise.resolve(Client.where(brokerId).fetch({
				columns: ["BrokerID", "Company", "Address", "City", "State", "Zip",
					"Phone", "DefaultCourierID", "DefaultCourierAcnt", "RepId", "Email",
					"TermsAccept", "LenderSpecific", "Ccemail", "AutoOrders",
					"TenantId", "Program", "SalesRepId", "Suite", "Inactive", "GID", "InvoiceOnly", "industryId"
				]
			}));
			const getExistUser = Promise.resolve(Bookshelf.knex.raw(`select GetUserNameByIdAndRole(${brokerId.brokerId}, 'client', null) as userName, GetUserIdByIdAndRole(${brokerId.brokerId}, 'client', null) as userId;`));
			const getExistOrderOpen = Promise.resolve(Bookshelf.knex.raw(`select count(OrderId) as NumberOrderOpen from \`order\` where BrokerId=${brokerId.brokerId} and ProgressId=1`));
			const getExistSecAnswer = Promise.resolve(Bookshelf.knex.raw(`select count(AnswerId) as NumberAnswer from sec_answers s inner join users u on s.UserId = u.UsersId where u.UserName = GetUserNameByIdAndRole(${brokerId.brokerId}, 'Client', false)`));

			promiseData = Promise.all([getAllClientActive, getAllCourier, getAllStates, getAllEmployees, getAllSaleReps, getAllIndustry, getClient, getExistUser, getExistOrderOpen, getExistSecAnswer]);
		} else {
			promiseData = Promise.all([getAllClientActive, getAllCourier, getAllStates, getAllEmployees, getAllSaleReps, getAllIndustry]);
		}
		promiseData
			.then(values => {
				const data = {};
				if (values !== null) {
					values.forEach((item, index) => {
						if (item !== null) {
							switch (index) {
								case 0:
									data.listClients = item;
									break;
								case 1:
									data.listCourier = item;
									break;
								case 2:
									data.listStates = item;
									break;
								case 3:
									data.listEmployees = item;
									break;
								case 4:
									data.listSalesRep = item;
									break;
								case 5:
									data.listIndustry = item[0];
									break;
								case 6:
									data.clientDetails = item;
									break;
								case 7:
									data.username = item[0][0].userName;
									data.userId = item[0][0].userId;
									break;
								case 8:
									data.isExistOrderOpen = item[0][0].NumberOrderOpen > 0 ? true : false;
									break;
								case 9:
									data.isExistSecAnswer = item[0][0].NumberAnswer > 0 ? true : false;
									break;
							}
						}
					});
				}
				reply(data);
			}).catch(err => {
				reply(Boom.badRequest(err));
			});

		return reply;
	}
	getClients(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			clientID,
			clientName,
			address,
			city,
			state,
			inactive
		} = request.payload;

		Bookshelf.knex.raw(`call GetClients('${sortColumn}',${sortDirection},${page},
		${itemPerPage},'${clientID}','${handleSingleQuote(clientName)}','${handleSingleQuote(address)}','${handleSingleQuote(city)}','${state}',${inactive === "" ? null : inactive})`)
			.then((result) => {
				if (result !== null) {
					const data = {};
					data.listClient = {
						clients: result[0][0],
						totalRecords: result[0][1][0].TotalRecords
					};
					reply(data);
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		return reply;
	}

	getClientManagementData(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			clientID,
			clientName,
			address,
			city,
			state,
			inactive
		} = request.payload;

		const getClients = Promise.resolve(Bookshelf.knex.raw(
			`call GetClients('${sortColumn}',${sortDirection},${page},
			${itemPerPage},'${clientID}','${clientName}','${address}','${city}','${state}',${inactive})`));
		const getAllStates = Promise.resolve(State.fetchAll({
			columns: ["Code", "Description"]
		}));

		Promise.all([getClients, getAllStates])
			.then(values => {
				const data = {};

				if (values !== null) {
					values.forEach((item, index) => {
						if (item !== null) {
							switch (index) {
								case 0:
									data.listClient = {
										clients: item[0][0],
										totalRecords: item[0][1][0].TotalRecords
									};
									break;
								case 1:
									data.listState = item;
									break;
							}
						}
					});
				}
				reply(data);
			}).catch(err => {
				reply(Boom.badRequest(err));
			});

		return reply;
	}

	addClient(request, reply) {
		const client = request.payload;

		const newClient = new Client(client);
		newClient.save({
			isAvailable: false
		}, {
				method: "insert"
			}).then((result) => {
				if (result !== null) {
					const brokerId = result.attributes.id;
					reply({
						brokerId,
						isSuccess: true
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	updateClient(request, reply) {
		const client = request.payload;
		Client.where({
			BrokerId: client.BrokerID
		}).save(client, {
			method: "update"
		}).then(() => {
			reply({
				isSuccess: true
			});
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	updateClientContact(request, reply) {
		const client = request.payload;

		Client.where({
			BrokerId: client.BrokerID
		}).save(client, {
			method: "update"
		}).then(() => {
			reply({
				isSuccess: true
			});
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	updateClientIsAvailable(request, reply) {
		const client = request.payload;

		Client.where({
			brokerId: client.brokerId
		}).fetch({
			columns: ["company", "primaryContactFirst"]
		}).then((model) => {
			const company = model.get("company");
			const primaryContactFirst = model.get("primaryContactFirst");
			client.isAvailable = company && company.length > 0 && primaryContactFirst && primaryContactFirst.length > 0;
			Client.where({
				brokerId: client.brokerId
			}).save(client, {
				method: "update"
			}).then(() => {
				reply({
					isAvailable: client.isAvailable
				});
				resetPassword(client.brokerId, 5, (identity) => {
					Bookshelf.knex.raw(`select company, email, primaryContactLast from broker where BrokerID = ${client.brokerId};`)
						//eslint-disable-next-line
						.then((returnClient) => {
							const {
								email,
								primaryContactLast
							} = returnClient[0][0];
							const emailParams = {
								email,
								emailPurpose: "Invites New Client",
								receiver: "Client",
								needBindData: {
									ClientName: `${primaryContactFirst} ${primaryContactLast}`,
									Username: identity.username,
									Password: identity.newPass
								}
							};
							sendEmailHelper(emailParams);
							//eslint-disable-next-line
						}).catch((error) => {
							reply(Boom.badRequest(error));
						});
				}, (err) => reply(Boom.badRequest(err)));
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		});
	}

	changeStatusClient(request, reply) {
		const {
			brokerId
		} = request.query;
		Bookshelf.knex.raw(`call ChangeStatusClient('${brokerId}')`).then((result) => {
			if (result !== null) {
				reply({
					isSuccess: true
				});
				Bookshelf.knex.raw(`select inactive, company, email, primaryContactFirst, primaryContactLast, GetUserNameByIdAndRole(BrokerID, 'client', false) as username from broker where BrokerID = ${brokerId};`)
					.then((client) => {
						const {
							email,
							primaryContactFirst,
							primaryContactLast,
							username,
							inactive
						} = client[0][0];
						const check = bufferToBoolean(inactive);
						if (check) {
							const emailParams = {
								email,
								emailPurpose: "Account Deactivated by TCE - Client",
								receiver: "Client",
								needBindData: {
									ClientName: `${primaryContactFirst} ${primaryContactLast}`,
									Username: username
								}
							};
							sendEmailHelper(emailParams);
						}
					});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
		return reply;
	}

	getAllClientForDropDown(request, reply) {
		const rawSql = `select b.BrokerID, 
						b.Company, 
						b.City, 
						b.State,
						b.AdditionalContact, 
						b.AdditionalContactEmail, 
						b.AdditionalContactExt, 
						b.AdditionalContactPhone,
						b.DefaultCourierAcnt,
						c.Courier
					from broker b 
					left join courier c on b.DefaultCourierID = c.CourierID 
					where (b.Inactive is null OR b.Inactive=false) AND b.IsAvailable=true AND (b.GID is null or b.GID = 0) order by b.Company;`;

		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null) {
					reply(result[0]);
				}

				return reply;
			}).catch((error) => {
				reply(Boom.badRequest(error));

				return reply;
			});
	}

	getClientContactByClientId(request, reply) {
		const client = request.query;
		Client.where({
			brokerId: client.brokerId
		}).fetch({
			columns: ["BrokerID", "additionalContact", "additionalContactEmail", "additionalContactPhone", "additionalContactExt", "primaryContactFirst", "primaryContactLast", "primaryContactExt", "primaryContactFax", "contactNotes"]
		}).then((result) => {
			reply(result);
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getClientOrderByClientId(request, reply) {
		const client = request.query;
		Client.where({
			brokerId: client.brokerId
		}).fetch({
			columns: ["BrokerId", "firstContactDate", "lastContactDate", "firstOrderDate", "lastOrderDate", "ytdOrders", "mtdOrders", "totalOrders"]
		}).then((result) => {
			reply(result);
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getBranchesByBrokerId(request, reply) {
		const {
			brokerId
		} = request.query;
		Client.where({
			gid: brokerId
		}).fetchAll({
			columns: ["brokerId", "gId", "company"]
		}).then(branches => {
			reply(branches);
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getClientStatusReport(request, reply) {
		const { clientId } = request.query;
		let htmlBody = "";
		Bookshelf.knex.raw(`call GetClientStatus(${clientId})`).then((result) => {
			if (result !== null) {
				result[0][0].map((item) => {
					htmlBody = htmlBody.concat(`<tr><td>${item.OrderID}</td>
					<td>${item.BrokerIDNum}</td>
					<td>${item.FullName}</td>
					<td>${item.LastName}</td>
					<td>${item.OrderDate ? moment(item.OrderDate).format("MM/DD/YYYY") : ""}</td>
					<td>${item.AptDateTime ? moment(item.AptDateTime).utc().format("MM/DD/YYYY") : ""}</td>
					<td>${item.AptDateTime ? moment(item.FilledDate).utc().format("MM/DD/YYYY") : ""}</td>
					<td>${item.Signer}</td>
					<td>${item.SaleRep}</td>
					<td>${item.closeddate ? moment(item.closeddate).utc().format("MM/DD/YYYY") : ""}</td>
					<td>${item.ProgressDescription}</td></tr>`);
				});
				const options = {
					"height": "10.5in",
					"width": "8in",
					"format": "A4",
					"orientation": "portrait",
					"footer": {
						"height": "12mm",
						"contents": {
							default: `<hr/><span style="color: #444; font-size: 8pt; padding-left: 20px;">${moment().format("dddd, MMMM D, YYYY")}</span><span style="color: #444; font-size: 8pt; padding-right: 20px; float:right;">Page {{page}} of {{pages}}</span>`
						}
					}
				};
				const html = `<html><body>
				<br />
				<h1 style="text-align: center">Client Status Report</h1><hr/>
				<table border=1 cellspacing=0 style="font-size: 8pt; width: 90%; margin-left: 5%;">
					<thead bgcolor="#56a1ff">
						<th >Order ID</th>
						<th >Loan #</th>
						<th >Contact</th>
						<th >Signer</th>
						<th >Order Date</th>
						<th >Scheduled</th>
						<th >Assigned</th>
						<th >Signing Agent</th>
						<th >TCE Rep</th>
						<th >Date Closed</th>
						<th >Progress</th>
					</thead> 
					<tbody>
						${htmlBody}
					</tbody>
				</table>
				</body></html>`;

				const storePath = `${STORE_PATH}/ReportStatus-${moment().format("YYYYMMDDHHmmss")}.pdf`;

				pdf.create(html, options).toFile(storePath, (err) => {
					if (err === null || err.code === "EPIPE") {
						if (fs.existsSync(storePath)) {
							// serve file
							reply.file(storePath);
						}
					} else {
						reply(Boom.badRequest(err.message));
					}
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getSpecialInstrucionOfClient(request, reply) {
		const {
			orderId,
			brokerId
		} = request.query;
		const rawSqlGetSpecialInsOfClient = `select bd.SpecialInstruction1,bd.SpecialInstruction2,bd.SpecialInstruction3,bd.SpecialInstruction4,bd.SpecialInstruction5,
											bd.SpecialInstruction6,bd.SpecialInstruction7,bd.SpecialInstruction8,bd.SpecialInstruction9,bd.SpecialInstruction10,
											bd.Collect1,bd.Collect2,bd.Collect3,bd.Collect4,bd.Collect5,bd.Collect6,bd.Collect7,bd.Collect8,bd.Collect9,bd.Collect10
											from broker_detail bd where bd.BrokerId=${brokerId};`;
		const rawSqlGetListEmailStatus = `select be.BrokerEmailId, be.Email from broker_emails be where be.BrokerID=${brokerId} and be.EmailFor='S';`;
		const rawSqlGetListEmailInvoice = `select be.BrokerEmailId, be.Email from broker_emails be where be.BrokerID=${brokerId} and be.EmailFor='I';`;
		const rawSqlGetDefaltDataIfHas = `select o.AlwaysCC, o.CCInvEmail, o.EmailCC, o.ReturnAddress as Address, osi.Instructions1, osi.Instructions2, osi.Instructions3, osi.Instructions4, osi.Instructions5,
										osi.Instructions6, osi.Instructions7, osi.Instructions8, osi.Instructions9, osi.Instructions10, o.Collect1, o.Collect2, o.Collect3, o.Collect4,
										o.Collect5, o.Collect6, o.Collect7, o.Collect8, o.Collect9, o.Collect10
									from \`order\` o join order_special_instructions osi on o.OrderId = osi.OrderId where o.OrderId = ${orderId};`;
		const rawSqlGetReturnAddress = `select ra.Address, ra.Department, ra.RaId, ra.City, ra.State, ra.Zip from return_addr ra where ra.BrokerId=${brokerId};`;
		const specialInsOfClient = Promise.resolve(Bookshelf.knex.raw(rawSqlGetSpecialInsOfClient));
		const listEmailsStatus = Promise.resolve(Bookshelf.knex.raw(rawSqlGetListEmailStatus));
		const listEmailsInvoice = Promise.resolve(Bookshelf.knex.raw(rawSqlGetListEmailInvoice));
		const defaultDataIfHas = Promise.resolve(Bookshelf.knex.raw(rawSqlGetDefaltDataIfHas));
		const getReturnAddress = Promise.resolve(Bookshelf.knex.raw(rawSqlGetReturnAddress));

		Promise.all([specialInsOfClient, listEmailsStatus, listEmailsInvoice, defaultDataIfHas, getReturnAddress])
			.then(value => {
				const data = {};

				if (value !== null) {
					value.forEach((item, index) => {
						if (item !== null) {
							switch (index) {
								case 0:
									data.specialInsOfClient = item[0][0];
									break;
								case 1:
									data.listEmailsStatus = item[0];
									break;
								case 2:
									data.listEmailsInvoice = item[0];
									break;
								case 3:
									data.defaultDataIfHas = item[0][0];
									break;
								case 4:
									data.listReturnAddress = item[0];
									break;
							}
						}
					});
				}

				reply(data);
			}).catch(err => {
				reply(Boom.badRequest(err));
			});
	}

	getClientBranchDropDown(request, reply) {
		const rawSql = "SELECT br.brokerId, br.company from broker br where (br.inactive is null or br.inactive=0) and isAvailable=true;";
		Bookshelf.knex.raw(rawSql).then(result => {
			reply(result[0]);
		}).catch(err => {
			reply(Boom.badRequest(err));
		});
	}

	getHybridQuestionData(request, reply) {
		const { brokerId } = request.query;

		const rawSql = `select assignOrdersDirectly, tceFullFill  from broker where brokerid = ${brokerId};`;

		Bookshelf.knex.raw(rawSql).then(result => {
			const returnData = {};

			if (result[0] && result[0][0]) {
				returnData.assignOrdersDirectly = bufferToBoolean(result[0][0].assignOrdersDirectly);
				returnData.tceFullFill = bufferToBoolean(result[0][0].tceFullFill);
			}

			reply(returnData || {});
		}).catch(err => {
			reply(Boom.badRequest(err));
		});
	}

	sendMailUpdateInfoClient(request, reply) {
		const { brokerId, oldData, newData } = request.payload;
		let changeDataStr = ``;
		let isChanged = false;

		Object.keys(oldData).map(item => {
			let old = oldData[item];
			let changedData = newData[item];
			if (isBuffer(old)) {
				old = bufferToBoolean(old);
			}

			if (isBuffer(changedData)) {
				changedData = bufferToBoolean(changedData);
			}

			if (changedData !== old) {
				changeDataStr = `${changeDataStr}<tr><td></td><td>-</td><td>${item}: ${hasStringValue(old) ? old : ""} is updated to ${changedData} </td></tr>`;
				isChanged = true;
			}
		});

		if (!isChanged) {
			reply();
			return;
		}

		Bookshelf.knex.raw(`select company, email, primaryContactFirst, primaryContactLast from broker where BrokerID = ${brokerId};`)
			.then((client) => {
				const {
					email,
					primaryContactFirst,
					primaryContactLast
				} = client[0][0];
				const emailParams = {
					email,
					emailPurpose: "Client Profile Updated by TCE",
					receiver: "Client",
					needBindData: {
						ClientName: `${primaryContactFirst} ${primaryContactLast}`,
						ChangeInfor: changeDataStr
					}
				};
				sendEmailHelper(emailParams);
			});
		reply();
	}
}

export default new ClientController();