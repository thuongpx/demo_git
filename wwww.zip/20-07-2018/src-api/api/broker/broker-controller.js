import Boom from "boom";
import Bookshelf from "../../db/database";

import Broker from "../../db/model/brokers";
import ClientDetail from "../../db/model/client-detail";
import { hasStringValue } from "../../helper/common-helper";
import CustomerAsgmtConfigLog from "../../db/model/customer_asgmt_config_log";
import BrokerAsgmtConfigLog from "../../db/model/broker_asgmt_config_log";
import moment from "moment";
import { RATING, RATINGID } from "../../constant/common-constant";

class BrokerController {
    constructor() { }

    getBrokerAddressById(request, reply) {
        const { brokerId } = request.query;

        Bookshelf.knex.raw(`call GetBrokerAddressById(${brokerId})`)
            .then((result) => {
                if (result !== null) {
                    reply({ Location: result[0][0][0] });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        return reply;
    }

    updateBrokerById(request, reply) {
        const broker = request.payload;

        Broker.where({ BrokerID: broker.BrokerID }).save({
            AdditionalContact: broker.AdditionalContact,
            AdditionalContactEmail: broker.AdditionalContactEmail,
            AdditionalContactExt: broker.AdditionalContactExt,
            AdditionalContactPhone: broker.AdditionalContactPhone,
            Address: broker.Address,
            BrokerID: broker.BrokerID,
            City: broker.City,
            Email: broker.Email,
            EmailOpt: broker.EmailOpt,
            Phone: broker.Phone,
            PrimaryContactExt: broker.PrimaryContactExt,
            PrimaryContactFax: broker.PrimaryContactFax,
            PrimaryContactFirst: broker.PrimaryContactFirst,
            PrimaryContactLast: broker.PrimaryContactLast,
            State: broker.State,
            Suite: broker.Suite,
            TextOpt: broker.TextOpt,
            Zip: broker.Zip
        }, { method: "update" }).then((success) => {
            if (success !== null) {
                reply({ isSuccess: true });
            }

            // done updating Broker
            // update/create Broker Detail
            ClientDetail.where({ BrokerId: broker.BrokerID }).fetch().then((result) => {
                if (result !== null) {
                    ClientDetail.where({ BrokerId: broker.BrokerID }).save(
                        {
                            Cell: broker.Cell,
                            Website: broker.Website
                        },
                        { method: "update" }).then(() => {
                            //success
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                } else {
                    new ClientDetail({
                        BrokerId: broker.BrokerID,
                        TenantId: 1,
                        Cell: broker.Cell,
                        Website: broker.Website
                    }).save(null,
                        { method: "insert" }).then((response) => {
                            if (response !== null) {
                                reply({
                                    isSuccess: true
                                });
                            }
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getBrokerInfoDefault(request, reply) {
        const { brokerId } = request.query;

        Bookshelf.knex.raw(`call GetPrimaryContactInformation(${brokerId})`)
            .then((result) => {
                if (result !== null) {
                    reply(result[0][0][0]);
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        return reply;
    }

    getBrokerById(request, reply) {
        const { brokerId } = request.query;
        Broker.where({ BrokerID: brokerId }).fetch({ columns: ["AdministratorFirst", "AdministratorLast", "Administratorext", "AdministratorEmail"] }).then((result) => {
            if (result !== null) {
                reply(result);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

        return;
    }

    getBrokerDataById(request, reply) {
        const { brokerId, listColumns } = request.payload;
        Broker.where({ BrokerID: brokerId }).fetch({ columns: listColumns }).then((result) => {
            if (result !== null) {
                reply(result.attributes || {});
            }

            reply({});
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getBrokerAdminById(request, reply) {
        const { brokerId } = request.query;

        const getBranchAdmin = Promise.resolve(
            Broker.where({ BrokerId: brokerId }).fetch({
                columns: [
                    "AdministratorFirst", "AdministratorLast", "AdministratorExt", "AdministratorEmail"
                ]
            })
        );

        const getBranchAdminReturnAddr = Promise.resolve(Bookshelf.knex.raw(`select BranchId, City, DefaultAddr, Department, State, Suite, Zip from return_addr where BrokerId = ${brokerId}`));

        const getAllState = Promise.resolve(Bookshelf.knex.raw(`select Code from state`));

        const promiseData = Promise.all([getBranchAdmin, getBranchAdminReturnAddr, getAllState]);
        promiseData
            .then(values => {
                const data = {};
                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.admin = item;
                                    break;
                                case 1:
                                    data.returnAddr = item[0];
                                    break;
                                case 2:
                                    data.state = item[0];
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
        return reply;
    }

    getAllBrokers(request, reply) {
        Broker.fetchAll().then((result) => {
            if (result !== null) {
                reply(result);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

        return;
    }

    getBrokerBranchById(request, reply) {
        const { brokerId } = request.query;

        const getBranch = Promise.resolve(
            Broker.where({ BrokerId: brokerId }).fetch({
                columns: [
                    "Company", "Phone", "Address", "Suite", "City", "State", "Zip",
                    "AdministratorFirst", "AdministratorLast", "AdministratorExt", "AdministratorEmail",
                    "PrimaryContactFirst", "PrimaryContactLast", "Email", "PrimaryContactExt", "PrimaryContactFax",
                    "DefaultCourierID", "DefaultCourierAcnt"
                ]
            })
        );

        const getReturnAddr = Promise.resolve(Bookshelf.knex.raw(`select * from return_addr where BrokerId = ${brokerId}`));

        const getCcEmail = Promise.resolve(Bookshelf.knex.raw(`select * from broker_emails where BrokerId = ${brokerId}`));

        const getAllState = Promise.resolve(Bookshelf.knex.raw(`select Code from state`));

        const promiseData = Promise.all([getBranch, getReturnAddr, getCcEmail, getAllState]);
        promiseData
            .then(values => {
                const data = {};
                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.branch = item;
                                    break;
                                case 1:
                                    data.returnAddr = item[0];
                                    break;
                                case 2:
                                    data.ccEmail = item[0];
                                    break;
                                case 3:
                                    data.state = item[0];
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
        return reply;
    }

    getApprovalRequestNumber(request, reply) {
        const { brokerId, userId } = request.query;
        const rawSqlClientFee = `select count( distinct f.feeApprovalId) as clientFeeRequestCount
        from order_fee_approve AS f
        inner join (select orderid, sum(OriginalSignerFee) OriginalSignerFee from order_fee group by orderid) fee  on f.OrderId = fee.OrderID
        inner join order_fee_approve_reason r on f.ReasonCode = r.ReasonCode
        inner join `
            + "`order`" +
            ` as o on f.OrderId=o.OrderId
        inner join `
            + "`order`" +
            ` as o1 on o1.signerId = f.signerID
        where (o.IsSelfService = 0 OR o.IsSelfService is null)
        and f.FeeApproved = 'Pending' and f.usersId = ${userId};`;
        const getApprovalRequestClientFee = Promise.resolve(Bookshelf.knex.raw(rawSqlClientFee));
        let rawSqlFee = "";
        let rawSqlVendor = "";
        let getApprovalRequestFee;
        let getApprovalRequestVendor;

        if (brokerId !== "0") {
            rawSqlFee = `SELECT count(f.feeApprovalId) as feeRequestCount
            FROM order_fee_approve AS f
            inner join `
                + "`order`" +
                ` as o on f.OrderId=o.OrderId
            inner JOIN users AS u ON u.UsersId = f.UsersId
            inner join user_roles role on u.UsersId=role.UsersId
            inner join roles per on role.RoleId=per.RoleId
            where (case when o.agentId is null then per.RoleName end ='Vendor' OR
            case when o.agentId is not null then per.RoleName end ='Agent')  and f.FeeApproved='Pending' and (o.brokerid=${brokerId} 
            or o.brokerId in (select brokerId from broker where gid=${brokerId}))  ;`;

            getApprovalRequestFee = Promise.resolve(Bookshelf.knex.raw(rawSqlFee));
            rawSqlVendor = `SELECT count(s.ApprovalID) as vendorRequestCount
            FROM signers_approval AS s
            inner join signer r on s.SignerId = r.SignerId
            inner join `
                + "`order`" +
                ` o on s.OrderId=o.OrderId
            inner JOIN users AS u ON u.UsersId = s.RequestBy
            inner join user_roles role on u.UsersId=role.UsersId
            inner join roles per on role.RoleId=per.RoleId
            where per.RoleName='Agent' and s.status='Pending' and (o.brokerid=${brokerId}
            or o.brokerId in (select brokerId from broker where gid=${brokerId})) ;`;
            getApprovalRequestVendor = Promise.resolve(Bookshelf.knex.raw(rawSqlVendor));
        } else {
            rawSqlFee = `select count( distinct f.feeApprovalId) as feeRequestCount
            from order_fee_approve AS f
            inner join (select orderid, sum(OriginalSignerFee) OriginalSignerFee from order_fee group by orderid) fee  on f.OrderId = fee.OrderID
            inner join order_fee_approve_reason r on f.ReasonCode = r.ReasonCode
            inner join `
                + "`order`" +
                ` as o on f.OrderId=o.OrderId
            inner join `
                + "`order`" +
                ` as o1 on o1.signerId = f.signerID
            where (o.IsSelfService = 0 OR o.IsSelfService is null)
            and f.FeeApproved = 'Pending' and ( f.usersId = ${userId} or o1.repId = ${userId} );`;

            getApprovalRequestFee = Promise.resolve(Bookshelf.knex.raw(rawSqlFee));
            rawSqlVendor = `SELECT count(s.ApprovalID) as vendorRequestCount
            FROM signers_approval AS s
            inner join signer r on s.SignerId = r.SignerId
            inner join `
                + "`order`" +
                ` o on s.OrderId=o.OrderId
            inner JOIN users AS u ON u.UsersId = s.RequestBy
            where (o.IsSelfService = 0 OR o.IsSelfService is null)
            AND s.status = 'Pending' ;`;
            getApprovalRequestVendor = Promise.resolve(Bookshelf.knex.raw(rawSqlVendor));
        }

        Promise.all([getApprovalRequestFee, getApprovalRequestVendor, getApprovalRequestClientFee]).then(values => {
            const data = {};
            if (values !== null) {
                values.forEach((item, index) => {
                    if (item !== null) {
                        switch (index) {
                            case 0:
                                data.feeRequestCount = item[0][0].feeRequestCount;
                                break;
                            case 1:
                                data.vendorRequestCount = item[0][0].vendorRequestCount;
                                break;
                            case 2:
                                data.clientFeeRequestCount = item[0][0].clientFeeRequestCount;
                                break;
                        }
                    }
                });
            }

            reply(data);
        }).catch(err => {
            reply(Boom.badRequest(err));
        });

        return reply;
    }

    async getInitDataForClientOrderAssignConfig(request, reply) {
        const { clientId, isCustomer } = request.query;

        const rawSqlSpecialty = `SELECT * FROM vendor_categories;`;
        const returnData = {};
        const mappingRating = (value) => {
            return RATINGID[value] || 0;
        };

        await new Promise(resolve => {
            Bookshelf.knex.raw(rawSqlSpecialty).then(result => {
                returnData.listVendorCategories = result[0];
                resolve();
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
        });

        const rawSqlTrainingCourses = `SELECT ProgramId as courseId, Title as description FROM training_programs where (Inactive is null or Inactive = 0) and IsPublished = true and ForVendor = true order by Title;`;

        await new Promise(resolve => {
            Bookshelf.knex.raw(rawSqlTrainingCourses).then(result => {
                returnData.listTrainingCourse = result[0];
                resolve();
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
        });

        let rawSqlGetBrokerInfo = `select b.ReqRating, b.ReqExperienceNumber from broker b where b.BrokerID = ${clientId};`;
        if (isCustomer === "true") {
            rawSqlGetBrokerInfo = `SELECT c.ReqRating, c.ReqExperienceNumber FROM customers c where c.CustomerId = ${clientId};`;
        }
        await new Promise(resolve => {
            Bookshelf.knex.raw(rawSqlGetBrokerInfo)
                .then((result) => {
                    if (result[0]) {
                        const tempData = result[0][0];
                        returnData.rating = [];
                        returnData.experience = "";
                        if (tempData) {
                            const rating = tempData.ReqRating;
                            if (hasStringValue(rating)) {
                                const temp = rating.split(",");
                                temp.forEach(item => returnData.rating.push({ id: mappingRating(item), label: mappingRating(item), value: mappingRating(item) }));
                            }
                            returnData.experience = tempData.ReqExperienceNumber;
                        }
                    }

                    resolve();
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                });
        });

        let rawSqlGetListSpecialy = `select bvs.*, v.catName from broker_vendor_specialty bvs join vendor_categories v on bvs.CatId = v.CatId where bvs.BrokerId = ${clientId};`;
        if (isCustomer === "true") {
            rawSqlGetListSpecialy = `Select bvs.CustomerId as BrokerId, bvs.CatId, v.catName  from customer_vendor_specialty bvs join vendor_categories v on bvs.CatId = v.CatId where CustomerId = ${clientId};`;
        }

        await new Promise(resolve => {
            Bookshelf.knex.raw(rawSqlGetListSpecialy)
                .then((result) => {
                    returnData.specialy = [];
                    if (result[0]) {
                        const temp = result[0];
                        temp.forEach(item => returnData.specialy.push({ id: item.CatId, value: item.CatId, label: `${item.catName}` }));
                    }

                    resolve();
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                });
        });

        let rawSqlGetListTraining = `SELECT b.*, t.title FROM broker_training_req b join training_programs t on b.ProgramId = t.ProgramId where (brokerId=${clientId}) and (t.Inactive is null or t.Inactive = 0);`;
        if (isCustomer === "true") {
            rawSqlGetListTraining = `SELECT c.Id, c.CustomerId as BrokerId, c.ProgramId, t.title FROM customer_training_req c join training_programs t on c.ProgramId = t.ProgramId  where (CustomerId=${clientId}) and (t.Inactive is null or t.Inactive = 0);`;
        }
        await new Promise(resolve => {
            Bookshelf.knex.raw(rawSqlGetListTraining)
                .then((result) => {
                    returnData.training = [];
                    if (result[0]) {
                        const temp = result[0];
                        temp.forEach(item => returnData.training.push({ id: item.ProgramId, value: item.ProgramId, label: `${item.title}` }));
                    }

                    resolve();
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                });
        });

        let rawSqlCheckPreferredVendor = `select count(Id) as totalRecords from broker_preferred_vendor where brokerId = ${clientId};`;
        if (isCustomer === "true") {
            rawSqlCheckPreferredVendor = `select count(Id) as totalRecords from customer_preferred_vendor where customerId = ${clientId};`;
        }

        await new Promise(resolve => {
            Bookshelf.knex.raw(rawSqlCheckPreferredVendor)
                .then((result) => {
                    returnData.hasPreferredVendor = false;
                    if (result[0]) {
                        returnData.hasPreferredVendor = result[0][0].totalRecords;
                    }

                    resolve();
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                });
        });

        reply(returnData);
    }

    getlistClientPreferred(request, reply) {
        const { clientId, sortColumn, sortDirection, page, itemPerPage, isCustomerPreferred } = request.query;

        const rawSql = `call getListClientPreferred(${clientId}, ${isCustomerPreferred || false}, '${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage});`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                const returnData = {};
                if (result[0]) {
                    returnData.listClientPreferred = result[0][0];
                    returnData.totalRecords = result[0][1][0].TotalRecords;
                }

                reply(returnData);
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    getClientOrderAssignConfigLog(request, reply) {
        const { clientId, sortColumn, sortDirection, page, itemPerPage, isCustomerPreferred } = request.query;

        const rawSql = `call getListClientOrderAssignConfigLog(${clientId}, ${isCustomerPreferred || false}, '${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage});`;


        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                const returnData = {};
                if (result[0]) {
                    returnData.listConfigLog = result[0][0];
                    returnData.totalRecords = result[0][1][0].TotalRecords;
                }

                reply(returnData);
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    async saveClientOrderAssignConfig(request, reply) {
        const { inputs, isCustomer, clientId } = request.payload;

        const idName = isCustomer === true ? "customerId" : "brokerId";
        let rating = ``;
        let ratingLog = ``;
        let specialty = ``;
        let trainingCourse = ``;

        const mappingRating = (value) => {
            return RATING[value] || 0;
        };

        inputs.performanceRating.data.forEach((item, index) => {
            rating = `${rating}${mappingRating(item.value)}`;
            ratingLog = `${ratingLog}${item.value}`;
            if (index < inputs.performanceRating.data.length - 1) {
                rating = `${rating},`;
                ratingLog = `${ratingLog}, `;
            }
        });

        //update rating and experience
        const rawSqlUpdateRatingAndExp = `update ${isCustomer === true ? "customers" : "broker"} set ReqRating = "${rating}", ReqExperienceNumber = ${inputs.experience.data === "" ? "null" : inputs.experience.data} 
                                            where ${idName} = ${clientId}`;

        await new Promise(resolve => {
            Bookshelf.knex.raw(rawSqlUpdateRatingAndExp)
                .then(() => {
                    resolve();
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                });
        });

        //update specialty
        const rawSqlRemoveSpecialty = `DELETE FROM ${isCustomer === true ? "customer_vendor_specialty" : "broker_vendor_specialty"} WHERE ${idName}=${clientId};`;
        await new Promise(resolve => {
            Bookshelf.knex.raw(rawSqlRemoveSpecialty)
                .then(() => {
                    if (inputs.specialty.isActive === true) {
                        let rawSqlInsertSpecialty = `INSERT INTO ${isCustomer === true ? "customer_vendor_specialty" : "broker_vendor_specialty"} (\`${idName}\`, \`catId\`) values`;
                        inputs.specialty.data.forEach((item, index) => {
                            rawSqlInsertSpecialty = `${rawSqlInsertSpecialty} (${clientId}, ${item.value})`;
                            specialty = `${specialty}${item.value}`;
                            if (index === inputs.specialty.data.length - 1) {
                                rawSqlInsertSpecialty = `${rawSqlInsertSpecialty};`;
                            } else {
                                rawSqlInsertSpecialty = `${rawSqlInsertSpecialty},`;
                                specialty = `${specialty},`;
                            }
                        });

                        Bookshelf.knex.raw(rawSqlInsertSpecialty)
                            .then(() => {
                                resolve();
                            }).catch((error) => {
                                reply(Boom.badRequest(error));
                                return;
                            });
                    } else {
                        resolve();
                    }
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                });
        });

        //update training req
        const rawSqlRemoveTraining = `DELETE FROM ${isCustomer === true ? "customer_training_req" : "broker_training_req"} WHERE ${idName}=${clientId};`;
        await new Promise(resolve => {
            Bookshelf.knex.raw(rawSqlRemoveTraining)
                .then(() => {
                    if (inputs.training.isActive === true) {
                        let rawSqlInsertTraining = `INSERT INTO ${isCustomer === true ? "customer_training_req" : "broker_training_req"} (\`${idName}\`, \`ProgramId\`) values`;
                        inputs.training.data.forEach((item, index) => {
                            rawSqlInsertTraining = `${rawSqlInsertTraining} (${clientId}, ${item.value})`;
                            trainingCourse = `${trainingCourse}${item.value}`;
                            if (index === inputs.training.data.length - 1) {
                                rawSqlInsertTraining = `${rawSqlInsertTraining};`;
                            } else {
                                rawSqlInsertTraining = `${rawSqlInsertTraining},`;
                                trainingCourse = `${trainingCourse},`;
                            }
                        });

                        Bookshelf.knex.raw(rawSqlInsertTraining)
                            .then(() => {
                                resolve();
                            }).catch((error) => {
                                reply(Boom.badRequest(error));
                                return;
                            });
                    } else {
                        resolve();
                    }
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                    return;
                });
        });

        let logPreferredVendor = ``;

        //remove preferred vendor if inactive option
        if (inputs.clientPreferred.isActive === false) {
            const rawSqlRemoveVendorPreferred = `DELETE FROM ${isCustomer === true ? "customer_preferred_vendor" : "broker_preferred_vendor"} WHERE ${idName}=${clientId};`;
            await new Promise(resolve => {
                Bookshelf.knex.raw(rawSqlRemoveVendorPreferred)
                    .then(() => {
                        resolve();
                    }).catch((error) => {
                        reply(Boom.badRequest(error));
                        return;
                    });
            });
        } else {
            const rawSqlGetListPreferred = `SELECT  concat(FirstName,' ',LastName) as fullName FROM ${isCustomer === true ? "customer_preferred_vendor" : "broker_preferred_vendor"} WHERE ${idName}=${clientId};`;

            await new Promise(resolve => {
                Bookshelf.knex.raw(rawSqlGetListPreferred)
                    .then((result) => {
                        if (result[0]) {
                            result[0].forEach((item, index) => {
                                logPreferredVendor = `${logPreferredVendor}${item.fullName}`;
                                if (index < result[0].length - 1) {
                                    logPreferredVendor = `${logPreferredVendor}, `;
                                }
                            });
                        }
                        resolve();
                    }).catch((error) => {
                        reply(Boom.badRequest(error));
                        return;
                    });
            });
        }

        reply({
            isSuccess: true
        });
    }

    getListClientAdmin(request, reply) {
        const rawSql = `SELECT b.company, b.brokerID, b.city, b.state FROM broker b 
        inner join \`users\` u on u.MappingUserId = b.BrokerID
        inner join \`user_roles\` ur on ur.UsersId = u.UsersId
        WHERE (b.GID IS NULL OR b.GID = 0) AND (b.Inactive IS NULL OR b.Inactive = FALSE) 
        AND (u.Inactive IS NULL OR u.Inactive = 0) AND (ur.RoleId = 5)
        ORDER BY b.Company;`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                let returnData = [];
                if (result[0]) returnData = result[0];

                reply(returnData);
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
}

export default new BrokerController();