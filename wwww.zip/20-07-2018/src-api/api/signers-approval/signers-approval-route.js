import SignersApprovalController from "./signers-approval-controller";

const routes = [{
        path: "/staffApprovalManagement/getSignersApproval",
        method: "GET",
        config: {
            auth: false
        },
        handler: SignersApprovalController.getSignersApproval
    },
    {
        path: "/staffApprovalManagement/getSignersApprovalRequest",
        method: "GET",
        config: {
            auth: false
        },
        handler: SignersApprovalController.getSignersApprovalRequest
    }, {
        path: "/staffApprovalManagement/updateSignerApproval",
        method: "POST",
        config: {
            auth: false
        },
        handler: SignersApprovalController.updateSignerApproval
    }, {
        path: "/staffApprovalManagement/isUpdatableSignerApproval",
        method: "GET",
        config: {
            auth: false
        },
        handler: SignersApprovalController.isUpdatableSignerApproval
    }, {
        path: "/staffApprovalManagement/getSignersApprovalById",
        method: "GET",
        config: {
            auth: false
        },
        handler: SignersApprovalController.getSignersApprovalById
    }, {
        path: "/staffApprovalManagement/addSignerApproval",
        method: "POST",
        config: {
            auth: false
        },
        handler: SignersApprovalController.addSignerApproval
    }, {
        path: "/staffApprovalManagement/addSignerApprovalAndComments",
        method: "POST",
        config: {
            auth: false
        },
        handler: SignersApprovalController.addSignerApprovalAndComments
    },
    {
        path: "/staffApprovalManagement/getSignersApprovalByBrokerId",
        method: "GET",
        config: {
            auth: false
        },
        handler: SignersApprovalController.getSignersApprovalByBrokerId
    },
    {
        path: "/staffApprovalManagement/getSignersApprovalBySignerId",
        method: "GET",
        config: {
            auth: false
        },
        handler: SignersApprovalController.getSignersApprovalBySignerId
    },
    {
        path: "/staffApprovalManagement/updateVendorApprovalRequest",
        method: "POST",
        config: {
            auth: false
        },
        handler: SignersApprovalController.updateVendorApprovalRequest
    }
];

export default routes;