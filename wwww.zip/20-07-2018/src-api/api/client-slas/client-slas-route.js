import ClientSlasController from "./client-slas-controller";
const routes = [{
    path: "/client-slas/getClientSlasById",
    method: "GET",
    handler: ClientSlasController.getClientSlasById
},
{
    path: "/client-slas/updateClientSlasById",
    method: "POST",
    handler: ClientSlasController.updateClientSlasById
}];

export default routes;