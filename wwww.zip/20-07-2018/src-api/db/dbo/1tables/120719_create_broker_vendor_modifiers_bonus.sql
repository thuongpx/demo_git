CREATE TABLE IF NOT EXISTS `broker_vendor_modifiers_bonus` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BrokerId` int(11) DEFAULT NULL,
  `BonusId` int(11) DEFAULT NULL,
  `PointBonus` int(11) DEFAULT NULL,
  `PointComplaint` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
)