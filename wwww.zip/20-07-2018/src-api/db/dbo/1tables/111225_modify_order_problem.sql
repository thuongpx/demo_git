ALTER TABLE `order_problem` 
DROP FOREIGN KEY `staffid_oder_problem_2`;
ALTER TABLE `order_problem`
DROP INDEX `staffid_oder_problem_2_idx` ;

