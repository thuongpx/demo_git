use tce_test;

DROP PROCEDURE IF EXISTS `alter_table_order_docs`;

DELIMITER $$
CREATE PROCEDURE `alter_table_order_docs` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_test' AND
						TABLE_NAME = 'order_docs' AND 
                            COLUMN_NAME = 'RejectReason') THEN
	BEGIN
		ALTER TABLE `order_docs` ADD COLUMN `RejectReason` VARCHAR(150) NULL;
	END;
    END IF;
    
END$$

DELIMITER ;

call alter_table_order_docs();

DROP PROCEDURE IF EXISTS `alter_table_order_docs`;





