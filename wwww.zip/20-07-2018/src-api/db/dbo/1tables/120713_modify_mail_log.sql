DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	-- Chage max length column
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'mail_log' AND 
                            COLUMN_NAME = 'MailTo') THEN
	BEGIN
		ALTER TABLE `mail_log` MODIFY COLUMN `MailTo` VARCHAR(1000);
	END;
    END IF;
    
END$$

DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;