CREATE TABLE IF NOT EXISTS `permissions` (
  `PermissionId` INT NOT NULL AUTO_INCREMENT,
  `Description` VARCHAR(150) NULL,
  `Url` VARCHAR(250) NULL,
  `ApplyFor` VARCHAR(10) NULL,
  PRIMARY KEY (`PermissionId`)
  );