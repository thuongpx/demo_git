-- Request by ThuanNH2
CREATE TABLE IF NOT EXISTS `manual_report_templates` (
  `ReportId` INT NOT NULL AUTO_INCREMENT,
  `ReportName` VARCHAR(50) NULL,
  `SearchBy` INT, /* 1: Date and Time Closing; 2: Date of Order */
  `FromDate` DATE NULL,
  `ToDate` DATE NULL,
  `SearchAll` BIT,
  `VendorStatus` VARCHAR(1), /* B: Both; A: Active; I: Inactive */
  `Columns` VARCHAR(1000),
  PRIMARY KEY (`ReportId`)
);
