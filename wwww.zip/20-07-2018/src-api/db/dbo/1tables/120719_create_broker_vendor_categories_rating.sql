CREATE TABLE IF NOT EXISTS `broker_vendor_categories_rating` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BrokerId` int(11) DEFAULT NULL,
  `Category` varchar(50) DEFAULT NULL,
  `Percent` int(11) DEFAULT NULL,
  `RatingId` int(11) DEFAULT NULL,
  `MaxPoint` int(11) DEFAULT NULL,
  `ThresholdFrom` int(11) DEFAULT NULL,
  `ThresholdTo` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
)