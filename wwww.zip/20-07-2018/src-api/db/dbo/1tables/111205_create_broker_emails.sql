-- Request from HoangNM
-- Add broker emails
CREATE TABLE IF NOT EXISTS `broker_emails` (
    `BrokerEmailId` INT(11) NOT NULL AUTO_INCREMENT,
    `BrokerID` INT(11),
    `EName` VARCHAR(75),
    `Email` VARCHAR(300),
    PRIMARY KEY (`BrokerEmailId`)
);