CREATE TABLE IF NOT EXISTS `slas` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `SLA` VARCHAR(50) NULL,
  `DefaultFrom` INT NULL,
  `DefaultTo` INT NULL,
  `From` INT NULL,
  `To` INT NULL,
  PRIMARY KEY (`Id`)
);
