import Boom from "boom";
import Bookshelf from "../../db/database";
import Zip from "../../db/model/zip";
import { handleSingleQuote } from "../../helper/common-helper";

class ZipController {
    getZipsByKeyword(request, reply) {
        const { searchText, selectedValues, limit } = request.query;

        const selectedValuesStr = selectedValues ? `AND Zip NOT IN (${selectedValues})` : "";

        const rawSql = `SELECT Zip, City, AreaCode FROM zip WHERE (City LIKE '%${handleSingleQuote(searchText)}%'
        OR Zip LIkE '%${handleSingleQuote(searchText)}%' OR AreaCode LIKE '%${handleSingleQuote(searchText)}%') ${selectedValuesStr} ORDER BY City LIMIT ${limit};`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({ isSuccess: true, sources: result[0] });
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

    getStateByZipCode(request, reply) {
        const { zipCode } = request.query;
        Zip.where({ ZipCode: zipCode }).fetchAll({ columns: ["State"] }).then((result) => {
            if (result !== null) {
                reply(result);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
        return;
    }

    getCitiesByStates(request, reply) {
        let { searchText } = request.payload;
        const { limit, additionalData } = request.payload;

        const { selectedStates: states } = additionalData;

        if (!Array.isArray(states) || states.length === 0) {
            reply({ isSuccess: true, sources: [] });
        }

        const statesString = states.map(state => `'${handleSingleQuote(state)}'`).join(",");
        searchText = handleSingleQuote(searchText);

        const rawSql = `SELECT DISTINCT City as name FROM zip WHERE State IN(${statesString}) AND City LIKE '%${searchText}%' ORDER BY City LIMIT ${limit};`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({ isSuccess: true, sources: result[0] });
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

    filterCitiesOfStates(request, reply) {
        let { cities, states } = request.payload;

        if (cities.trim().length === 0 || states.trim().length === 0) {
            reply({ isSuccess: true, cities: [] });
            return;
        }

        cities = handleSingleQuote(cities.trim());

        states = states.trim()
            .split(";")
            .map(state => `'${state}'`)
            .join(",");

        states = handleSingleQuote(states);

        const rawSql = `call FilterCitiesOfStates('${states}', '${cities}');`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({ isSuccess: true, cities: result[0][0] });
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });

    }

    getTimeZoneByZip(request, reply) {
        const { zip } = request.query;

        if (!zip) {
            reply(Boom.badRequest("Zip is not valid"));
        }

        const query = `SELECT CASE WHEN UTC > 0 THEN CONCAT('+', CAST(UTC AS CHAR(3))) ELSE CAST(UTC AS CHAR(3)) END AS utc FROM zip WHERE Zip=${zip} LIMIT 1;`;

        Bookshelf.knex.raw(query)
            .then(result => {
                if (result !== null && result[0][0]) {
                    reply({ utc: result[0][0].utc });
                } else {
                    reply({ utc: "" });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

}

export default new ZipController();