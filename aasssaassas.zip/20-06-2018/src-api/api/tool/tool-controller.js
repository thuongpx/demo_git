import Boom from "boom";
import appConfig from "../../config/config";
import fs from "fs";
import Bookshelf from "../../db/database";

class ToolController {
    constructor() { }
    getListResource(request, reply) {

        const sqlQuery = `SELECT * FROM resources;`;

        Bookshelf.knex.raw(sqlQuery)
            .then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        isNotFound: false,
                        listResource: result[0]
                    });
                } else {
                    reply({ isSuccess: false, isNotFound: true });
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
        return;
    }

    downloadResources(request, reply) {
        const {
            fileName
        } = request.query;

        const filePath = `${appConfig.file.serverPath}/upload/resources/${fileName}`;

        if (fs.existsSync(filePath)) {
            fs.readFile(filePath, (err, data) => {
                if (err) reply(Boom.badRequest(err.message));
                return reply(data).header("content-disposition", `attachment; filename=${fileName}`);
            });
        } else {
            reply(Boom.badRequest(`File ${filePath} is not exists.`));
        }
    }

    getListLink(request, reply) {
        const sqlQuery = `SELECT Id, LinkTitle, Link, Description, Type, Target
        FROM links `;
        Bookshelf.knex.raw(sqlQuery)
            .then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        links: result[0]
                    });
                    return;
                }
                reply({ isSuccess: false, isNotFound: true });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        return;
    }

    getFaqsByQuestion(request, reply) {
        const { question } = request.query;
        const sqlQuery = `SELECT Id, SectId, Question, Answer, Views
        FROM faq
        WHERE Question LIKE '%${question}%'`;

        Bookshelf.knex.raw(sqlQuery)
            .then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        faqs: result[0]
                    });
                    return;
                }
                reply({ isSuccess: false, isNotFound: true });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        return;
    }
}

export default new ToolController();