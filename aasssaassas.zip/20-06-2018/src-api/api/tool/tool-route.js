import ToolController from "./tool-controller";
const routes = [
    {
        path: "/tool/getListResource",
        method: "GET",
        handler: ToolController.getListResource
    },
    {
        path: "/tool/getListLink",
        method: "GET",
        handler: ToolController.getListLink
    },
    {
        path: "/tool/getFaqsByQuestion",
        method: "GET",
        handler: ToolController.getFaqsByQuestion
    },
    {
        path: "/tool/downloadResources",
        method: "GET",
        handler: ToolController.downloadResources
    }
];

export default routes;