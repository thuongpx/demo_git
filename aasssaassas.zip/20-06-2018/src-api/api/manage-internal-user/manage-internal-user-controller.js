import Boom from "boom";
import User from "../../db/model/users";
import UserRole from "../../db/model/user-roles";
import RolePermission from "../../db/model/role-permission";
import Bookshelf from "../../db/database";
import Jwt from "../../lib/jwt";
import moment from "moment";
import SalesReps from "../../db/model/sales-reps";
import Employees from "../../db/model/employees";
import { handleSingleQuote, hasStringValue } from "../../helper/common-helper";
import { isBuffer, bufferToBoolean, hasValue } from "../../helper/common-helper";
import { Buffer } from "buffer";
class ManagerInternalUserController {

    getAllManagerInternalUser(request, reply) {
        const {
            repId,
            repName,
            repEmail,
            sortColumn,
            sortDirection,
            page,
            itemPerPage
        } = request.query;

        const rawSql = `call GetAllManagerInternalUser(
			${repId ? `${repId}` : null},
			${repName ? `'${handleSingleQuote(repName)}'` : `''`},
            ${repEmail ? `'${handleSingleQuote(repEmail)}'` : `''`},
            '\`${sortColumn}\`',
            ${sortDirection},
            ${page},
            ${itemPerPage}
        );`;

        console.log(rawSql);

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    result[0][0].map((item) => {
                        if (isBuffer(item.Active)) {
                            item.Active = bufferToBoolean(item.Active);
                        }
                    });
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0]
                    });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
        return reply;
    }

    getUsersByRepId(request, reply) {
        const {
            repId
        } = request.query;
        const getEmployees = Promise.resolve(Bookshelf.knex.raw(`call GetEmployeesByRepId(${repId})`));
        const getRoleInUser = Promise.resolve(Bookshelf.knex.raw(`call GetUsersByRepId(${repId})`));

        Promise.all([getEmployees, getRoleInUser])
            .then(values => {
                const data = {};

                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {

                            const rawData = item[0][0][0];
                            if (isBuffer(rawData.Active) || isBuffer(rawData.SRepOrder) || rawData.ProfilePicture) {
                                rawData.Active = bufferToBoolean(rawData.Active);
                                rawData.SRepOrder = bufferToBoolean(rawData.SRepOrder);
                                rawData.ProfilePicture = hasValue(rawData.ProfilePicture) ? rawData.ProfilePicture.toString() : "";
                            }
                            switch (index) {
                                case 0:
                                    data.employees = {
                                        employees: rawData
                                    };
                                    break;
                                case 1:
                                    data.roleInUser = {
                                        roleInUser: item[0][0]
                                    };
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
    }


    getManagerInternalUser(request, reply) {
        const {
            repId,
            repName,
            repEmail
        } = request.query;

        const rawSql = `call GetManageInternalUsers(${repId === "" ? null : `${repId}`},'${repName}','${repEmail}');`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    const rawData = [];
                    result[0][0].map(item => {
                        const rawItem = item;
                        rawItem.Active = bufferToBoolean(item.Active);
                        rawItem.Dnd = bufferToBoolean(item.Dnd);
                        rawItem.OutOfOffice = bufferToBoolean(item.OutOfOffice);
                        rawItem.LoggedIn = bufferToBoolean(item.LoggedIn);
                        rawData.push(rawItem);
                    });
                    reply({ data: rawData, totalRecords: result[0][1][0].TotalRecords });
                }
                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return reply;
            });
    }

    getRoleName(request, reply) {
        const rawSql = `call GetAllRolePermission()`;
        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({ data: result[0][0] });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        return reply;
    }

    // Add MySQL
    addManagerInternalUser(request, reply) {
        const input = request.payload;
        let isSuccess = false;
        new Employees().save({
            FirstName: input.FirstName,
            Email: input.Email,
            LastName: input.LastName,
            TenantId: input.TenantId,
            MaxNumOrders: input.MaxNumOrders,
            Ext: input.Ext ? input.Ext : null,
            Active: input.Active,
            SRepOrder: input.SRepOrder,
            IsDeleted: false,
            ProfilePicture: Buffer.from(input.Img ? input.Img : "", "utf8")
        }, { method: "insert" }).then((result) => {
            if (result && result.attributes) {

                const newRepId = result.attributes.id;
                const roleIdArray = input.RoleId;
                new SalesReps().save({
                    FirstName: input.FirstName,
                    LastName: input.LastName,
                    CommissionPercent: hasStringValue(input.CommissionPercent) ? input.CommissionPercent : null,
                    CommissionAmount: hasStringValue(input.CommissionAmount) ? input.CommissionAmount : null,
                    RepID: newRepId
                }, { method: "insert" }).then(isSuccess = true).catch(error => reply(Boom.badRequest(error)));

                const addUserSuccess = (user) => {
                    const usersId = user.get("id");
                    roleIdArray.forEach(roleId => {
                        new UserRole().save({
                            UsersId: usersId,
                            RoleId: roleId
                        }, { method: "insert" }).then(isSuccess = true).catch(error => reply(Boom.badRequest(error)));
                    }
                    );
                };
                reply(isSuccess);

                RolePermission.where({ Type: "Staff" }).fetch().then(() => {
                    const salt = Jwt.generateSalt();
                    const hashedPassword = Jwt.hash(input.Password, salt);

                    new User().save({
                        UserName: input.UserName,
                        Password: hashedPassword,
                        MappingUserId: newRepId,
                        HashSalt: salt,
                        DateCreated: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                        TenantId: 1
                    },
                        { method: "insert" })
                        .then(addUserSuccess).catch((error) => {
                            return reply(Boom.badRequest(error));
                        });
                }).catch((error) => {
                    return reply(Boom.badRequest(error));
                });
            }
        }).catch((error) => {
            return reply(Boom.badRequest(error));
        });
    }

    updateEmployees(request, reply) {
        const input = request.payload;

        Employees.where({ RepId: input.RepId }).save({
            FirstName: input.FirstName,
            Email: input.Email,
            LastName: input.LastName,
            TenantId: input.TenantId,
            MaxNumOrders: input.MaxNumOrders,
            ProfilePicture: Buffer.from(input.ProfilePicture ? input.ProfilePicture : "", "utf8"),
            Ext: input.Ext ? input.Ext : null,
            Active: input.Active,
            SRepOrder: input.SRepOrder
        }, { method: "update" }).then((result) => {
            if (result === null) {
                reply(Boom.badRequest(`Data is null`));
                return;
            }

            //const SRepOrder = input.SRepOrder;
            const UsersId = input.UsersId;
            const roleIdArray = input.RoleId;

            new UserRole().where({ UsersId }).destroy().then(() => {
                const insertRoles = [];
                roleIdArray.forEach(roleId => {
                    insertRoles.push({
                        UsersId: input.UsersId,
                        RoleId: roleId.RoleId
                    });
                });
                const UserRoles = Bookshelf.Collection.extend({
                    model: UserRole
                });

                UserRoles.forge(insertRoles).invokeThen("save")
                    .then(() => {
                        // save successfully
                        new SalesReps().where({ RepID: input.RepId }).save({
                            FirstName: input.FirstName,
                            LastName: input.LastName,
                            CommissionPercent: hasStringValue(input.CommissionPercent) ? input.CommissionPercent : null,
                            CommissionAmount: hasStringValue(input.CommissionAmount) ? input.CommissionAmount : null
                        }, { method: "update" })
                            .then(
                            () => {
                                reply({ isSuccess: true });
                            })
                            .catch(
                            error => {
                                reply(Boom.badRequest(error));
                            });

                    })
                    .catch(
                    error => reply(Boom.badRequest(error)));
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }


    updateActive(request, reply) {
        const input = request.payload;
        Employees.where({ RepId: input.RepId }).save({
            Active: input.Active
        }, { method: "update" }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    deleteManagerInternalUser(request, reply) {
        const { RepId } = request.payload;
        Employees.where({ RepId }).save({
            IsDeleted: true,
            Active: false
        }, { method: "update" }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getUserIdByRepId(request, reply) {
        const { repId } = request.query;
        const rawSql = `select distinct \`users\`.UsersId FROM \`employees\` INNER JOIN \`users\` on \`employees\`.RepId = \`users\`.MappingUserId
                                                        INNER JOIN \`user_roles\` on \`users\`.UsersId = \`user_roles\`.UsersId
                                                        INNER JOIN \`role_permission\` on \`user_roles\`.RoleId = \`role_permission\`.RoleId
                        where \`role_permission\`.Type = "Staff" and \`employees\`.RepId='${repId}'`;
        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({ data: result[0][0] });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        return reply;
    }
}


export default new ManagerInternalUserController();