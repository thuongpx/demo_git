DROP FUNCTION IF EXISTS `GetUserType`;

DELIMITER $$

CREATE FUNCTION `GetUserType`(user_Id int(11)) RETURNS varchar(15) CHARSET utf8
BEGIN
	DECLARE userType VARCHAR(15);    
	SET userType = '';
    
	IF user_Id IS NOT NULL THEN
    BEGIN
        SELECT r.Type
        INTO userType
        FROM user_roles AS u
		INNER JOIN role_permission AS r ON u.RoleId = r.RoleId
		WHERE u.UsersId = user_Id
        LIMIT 1;			
    END;
    END IF;
    
	RETURN userType;
END