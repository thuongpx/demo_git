DROP PROCEDURE IF EXISTS `getDataInitForViewOrders`;
DELIMITER $$
CREATE PROCEDURE `getDataInitForViewOrders`()
BEGIN
	select b.Company from broker b;
	select p.ProgressId, p.ProgressDescription from progress p;
END$$
DELIMITER ;