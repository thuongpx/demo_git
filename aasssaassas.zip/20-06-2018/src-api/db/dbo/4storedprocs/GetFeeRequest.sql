DROP PROCEDURE IF EXISTS `GetFeeRequest`;

DELIMITER $$

CREATE PROCEDURE `GetFeeRequest`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN repId int,
IN statusId int,
IN qCId int,
IN orderId int,
IN feeApproved varchar(100)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = 'WHERE fd.Active = 1 ';
    
    IF (repId IS NOT NULL AND repId <> '') 
		THEN SET whereQuery = CONCAT(whereQuery ,'AND o.RepId = ', repId);
	END IF;
    
    IF (statusId IS NOT NULL AND statusId <> '') 
		THEN SET whereQuery = CONCAT(whereQuery ,' AND o.StatusID = ', statusId);
	END IF;
    
    IF (qCId IS NOT NULL AND qCId <> '') 
		THEN SET whereQuery = CONCAT(whereQuery ,' AND o.QCID = ', qCId);
	END IF;
    
	IF (orderId IS NOT NULL AND orderId <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND f.OrderId LIKE ''%', orderId, '%''');
	END IF;
    
    IF (feeApproved IS NOT NULL AND feeApproved <>'All')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND f.FeeApproved = ''', feeApproved, '''');
	END IF;

	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS 
			f.FeeApprovalId,
			f.DateStamp AS RequestDate,
			u.UserName,
            u.UsersId,
            u.MappingUserId AS SignerId,
			f.OriginalAmount AS OriginalFee,
			f.FeeAmount AS ProposedFee,
			r.ReasonDescription,
			f.FeeApproved as Status,
			f.FeeDescripId,
			f.OrderId,
			f.FeeReason,
            o.ProgressId,
            CASE WHEN IsUserVendor(u.UsersId) = 1 THEN \'Vendor\' ELSE \'\' END AS Type,
			fd.Description AS FeeDescription,
			of.BrokerFee AS ClientFee
		FROM `order_fee_approve` AS f
		INNER JOIN `fee_description` AS fd ON fd.FeeDescriptionId = f.FeeDescripId
        LEFT JOIN `order` o ON f.OrderId = o.OrderId
		LEFT JOIN `order_fee` AS of ON of.OrderID=f.OrderId AND of.FeeDescripID=f.FeeDescripId
		LEFT JOIN `order_fee_approve_reason` AS r ON f.ReasonCode = r.ReasonCode
		LEFT JOIN `users` AS u ON u.UsersId = f.UsersId
            ', whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$
DELIMITER ;
