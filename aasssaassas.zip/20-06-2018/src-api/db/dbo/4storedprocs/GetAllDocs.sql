DROP PROCEDURE IF EXISTS `GetAllDocs`;

DELIMITER $$
CREATE PROCEDURE `GetAllDocs`(	
	IN orderId int(11)
)
BEGIN
    DECLARE whereQuery varchar(255);
    DECLARE orderQuery varchar(255);
    
    SET whereQuery = ' WHERE 1=1 ';
    SET orderQuery = ' ORDER BY UploadedDate ASC';
    SET whereQuery = CONCAT(whereQuery, ' AND (od.Archive is null or od.Archive <> 1)');
     
	IF(orderId IS NOT NULL AND orderId <> 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND od.OrderId= ', orderId);
	END IF;
     
	set @querySql = CONCAT('select od.DocId as `DocId`,
									od.Description as `Description`,
									od.UploadedDate as `UploadedDate`,
                                    od.DownloadDate as `DownloadDate`,
                                    od.DocumentType as `DocumentType`,
									if(o.DocumentCompletedDate is null, true, false) as `DocumentCompleted`
							FROM (order_docs as od
                            INNER JOIN `order` as o ON od.OrderId = o.OrderId)', whereQuery, orderQuery );


    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    
    
    SELECT FOUND_ROWS() as TotalRecords;
END