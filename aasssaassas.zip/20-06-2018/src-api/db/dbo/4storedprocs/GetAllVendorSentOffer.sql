CREATE DEFINER=`tce`@`%` PROCEDURE `GetAllVendorSentOffer`(
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN orderId int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY OfferID ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE 1=1 ');
     
	IF(orderId IS NOT NULL AND orderId >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `OrderId` = ', orderId);
	END IF;
     
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS t1.* from (select
									`signer_offer`.OfferID as `OfferID`,
                                    `signer_offer`.OfferAmount as `OfferAmount`,
                                    `signer`.LastName as `LastName`,
                                    `signer_offer`.OrderId,
									`signer`.FirstName as `FirstName`,
                                    CASE WHEN OfferStatus = "A" THEN \'Accepted\' ELSE 
										CASE WHEN OfferStatus = "D" THEN \'Declined\' ELSE 
											CASE WHEN OfferStatus = "N" THEN \'No Response\' ELSE 
												CASE WHEN OfferStatus = "M" THEN \'Missed\' ELSE \'\' 
												END 
                                            END
										END 
									END as `OfferStatus`,
                                    `users`.UserName as `RepId`,
                                    `signer_offer`.SentDate as `SentDate`,
                                    `signer_offer`.ResponseDate as `ResponseDate`,
									if(`signer_offer`.Sent = true, "Y", "N") as `Sent`
							FROM `signer_offer`  
                            left join `signer` on `signer_offer`.SignerId = `signer`.SignerId
                            left join `users` on `signer_offer`.RepId = `users`.UsersId
                            ) t1, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    END