DROP procedure IF EXISTS `CheckExistVendorOffer`;

DELIMITER $$
CREATE PROCEDURE `CheckExistVendorOffer`(
	IN aptDateTime datetime,
    IN signerId int,
    IN orderId int
)
BEGIN
	DECLARE IsValid int;
	DECLARE countOffer int;
    DECLARE getSignerID int;

    SET isValid = 0;

	SET getSignerID = (SELECT `order`.`signerId` AS count
	FROM `order`
	WHERE `order`.`OrderId` = orderId);

	IF getSignerID is null
	THEN IF aptDateTime IS NOT NULL 
		 THEN SET countOffer = (SELECT COUNT(`order`.`OrderId`) AS count
							FROM `order`
							WHERE `order`.`SignerId` = signerId	
							AND DATE_FORMAT(`order`.`AptDateTime`, "%Y%m%d%H%i") = DATE_FORMAT(aptDateTime, "%Y%m%d%H%i"));
		 
			 IF countOffer > 0 THEN SET isValid = 1;
             END IF;
		END IF;
	ELSE IF getSignerID = signerId
		 THEN SET isValid = 3;
		 ELSE SET isValid = 2;
		 END IF;
	END IF;

    SELECT isValid;
END$$

DELIMITER ;