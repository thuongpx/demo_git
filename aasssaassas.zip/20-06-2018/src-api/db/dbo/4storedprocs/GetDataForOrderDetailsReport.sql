DROP PROCEDURE IF EXISTS `GetDataForOrderDetailsReport`;

DELIMITER $$

CREATE PROCEDURE `GetDataForOrderDetailsReport`(
IN orderId int
)
BEGIN

    select concat(e.FirstName, " ", e.LastName) as employeeName
		, e.Ext as employeeExt
        , e.Email as employeeEmail
        , o.AptDateTime as aptDateTime
        , lt.LoanType as loanType
        , b.Company as brokerCompanyName
        , b.Phone as brokerPhone
        , o.DocDelMethod as docDelMethod
        , o.FaxBackReq as faxBackRequired
		, a.FullName as agentName
        , a.Direct as agentDirect
        , a.Ext as agentExt
        , a.FullName as agentAfterHoursContact
        , a.AfterhoursPhone as agentAfterHoursPhone
        , b.LenderSpecific as importantCompanyInstruction
        , concat(o.DocsToBorr, "/", o.DocsToNot) as returnPackageTo
        , o.DocstoSignerDate as docsToSignerDate
        , c.Courier as courier
        , o.CourierAcntNumber as courierAcntNumber
        , concat(o.FirstName, " ", o.LastName) as borrowerName
        , o.HomePhone as borrowerHomePhone
        , o.CellPhone as borrowerCellPhone
        , o.WorkPhone as borrowerWorkPhone
        , o.BoWrkext as borrowerExt
        , concat(o.CoFirstName, " ", o.CoLastName) as coBorrowerName
        , o.CoHomePhone as coBorrowerHomePhone
        , o.CoCellPhone as coBorrowerCellPhone
        , o.CoWorkPhone as coBorrowerWorkPhone
        , o.CoBoWrkext as coBorrowerExt
        , o.Address as borrowerAddress
        , concat(o.City, " ", o.State, " ", o.Zip) as borrowerCityStateZip
        , br.County as borrowerCounty
        , o.Collect1 as orderCollect1
        , o.Collect2 as orderCollect2
        , o.Collect3 as orderCollect3
        , o.Collect4 as orderCollect4
        , o.Collect5 as orderCollect5
        , o.Collect6 as orderCollect6
        , o.Collect7 as orderCollect7
        , o.Collect8 as orderCollect8
        , o.Collect9 as orderCollect9
        , o.Collect10 as orderCollect10
        , osi.Instructions1 as orderSpecialInstructions1
        , osi.Instructions2 as orderSpecialInstructions2
        , osi.Instructions3 as orderSpecialInstructions3
        , osi.Instructions4 as orderSpecialInstructions4
        , osi.Instructions5 as orderSpecialInstructions5
        , osi.Instructions6 as orderSpecialInstructions6
        , osi.Instructions7 as orderSpecialInstructions7
        , osi.Instructions8 as orderSpecialInstructions8
        , osi.Instructions9 as orderSpecialInstructions9
        , osi.Instructions10 as orderSpecialInstructions10
    from `order` as o
    inner join employees as e on o.Repid = e.Repid
    inner join agent as a on o.agentId = a.agentId
    inner join broker as b on o.brokerid = b.brokerid
    inner join courier as c on b.DefaultCourierID = c.CourierID
    inner join loan_type as lt on o.LoanType = lt.LoanTypeId
    inner join borrower as br on o.BorrowerId = br.BorrowerId
    inner join order_special_instructions as osi on osi.orderid = o.orderid
    where o.orderId = orderId;

END$$
DELIMITER ;