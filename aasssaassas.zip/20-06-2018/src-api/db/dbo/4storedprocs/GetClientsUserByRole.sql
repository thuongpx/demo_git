DROP procedure IF EXISTS `GetClientStatus`;

DELIMITER $$
CREATE PROCEDURE `GetClientsUserByRole`(
IN role varchar(255),
IN clientId int
)
BEGIN
	IF (role = 'Client') 
		THEN SET @strQuery = CONCAT('select u.UsersId, b.Company, a.FullName, ur.RoleId, u.Status
			from `users` u
			left join `agent` a on a.AgentId = u.MappingUserId
			left join `broker` b on b.BrokerID = u.MappingUserId
			inner join `user_roles` ur on ur.UsersId = u.UsersId
			where (ur.RoleId=6 or ur.RoleId=7) and (a.BrokerId=',clientId, ' or b.GID=',clientId, ');');
	ELSE IF (role = 'Branch') 
		THEN SET @strQuery = CONCAT('select u.UsersId, a.FullName, "" as Company, ur.RoleId, u.Status
			from `agent` a 
			inner join `users` u on a.AgentId = u.MappingUserId
			inner join `user_roles` ur on ur.UsersId = u.UsersId
			where a.BrokerID=',clientId, ' and ur.RoleId=7');
	ELSE IF (role = 'Agent') 
		THEN SET @strQuery = CONCAT('select u.UsersId, a.FullName, "" as Company, ur.RoleId, u.Status
			from `agent` a 
			inner join `users` u on a.AgentId = u.MappingUserId
			inner join `user_roles` ur on ur.UsersId = u.UsersId
			where a.BrokerID=',clientId, ' and ur.RoleId=7');
		END IF;
    END IF;
    END IF;
    
    PREPARE stmt FROM @strQuery;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
END