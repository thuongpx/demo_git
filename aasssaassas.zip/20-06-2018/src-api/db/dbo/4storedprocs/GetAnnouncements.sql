DROP procedure IF EXISTS `GetAnnouncements`;

DELIMITER $$

CREATE PROCEDURE `GetAnnouncements`(
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN status varchar(255),
	IN audience varchar(50),
    IN title varchar(255)
)
BEGIN	
   DECLARE orderQuery varchar(255) DEFAULT '';
	DECLARE sortDirectionQuery varchar(255);
    DECLARE limitQuery varchar(255) DEFAULT '';  
    DECLARE whereQuery varchar(255) DEFAULT ' WHERE 1 ';
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    SET orderQuery = CONCAT(' ORDER BY announcements.AnnouncementID ',sortDirectionQuery);
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

	IF (status IS NOT NULL AND status!='' ) 
		THEN  SET whereQuery = CONCAT(whereQuery, ' AND announcements.Status = \'', status,'\'');
    END IF;
    
	IF (audience IS NOT NULL AND audience!='') 
		THEN  SET whereQuery = CONCAT(whereQuery, ' AND announcements.Audience = \'', audience,'\'');
    END IF;
    
    IF (title IS NOT NULL AND title!='') 
		THEN  SET whereQuery = CONCAT(whereQuery, ' AND announcements.Title LIKE ''%',title, '%''');
    END IF;
    
	IF (whereQuery=' WHERE 1 ' ) 
		THEN  SET whereQuery = ' ';
    END IF;
       
	SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
    t1.* FROM (
		select AnnouncementID,CreatedDate,Title,Content,Status,Audience,NumOfAppearance 
        from announcements ',
        whereQuery,orderQuery,
        ') AS t1, (SELECT @rownum := 0) r ' ,limitQuery);
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$

DELIMITER ;