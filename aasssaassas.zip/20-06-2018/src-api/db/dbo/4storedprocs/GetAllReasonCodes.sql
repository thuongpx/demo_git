DROP PROCEDURE IF EXISTS `GetAllReasonCodes`;

DELIMITER $$
CREATE PROCEDURE `GetAllReasonCodes` (
)
BEGIN  
	SELECT 
		ReasonCode,
        ReasonDescription
    FROM order_fee_approve_reason
    WHERE `Type` = 'S';
END$$

DELIMITER ;