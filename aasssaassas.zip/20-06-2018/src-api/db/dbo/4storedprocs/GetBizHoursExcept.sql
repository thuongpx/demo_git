DROP PROCEDURE IF EXISTS `GetBizHoursExcept`;

DELIMITER $$
CREATE PROCEDURE `GetBizHoursExcept`(
    IN sortBy varchar(255),
    IN sortDirection bit,
    IN pageNumber int,
    IN pageSize int
)

BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255); 
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '' OR sortBy='index')
       THEN SET orderQuery = ' ORDER BY exceptId ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	   
	SET @querySql= concat('
    SELECT SQL_CALC_FOUND_ROWS
		ExceptID AS exceptId, Description AS description, OpenTime AS openTime, CloseTime AS closeTime, ExceptDate AS startDate, ExceptDate AS endDate, Closed AS closed FROM biz_hours_except ',
		orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END
