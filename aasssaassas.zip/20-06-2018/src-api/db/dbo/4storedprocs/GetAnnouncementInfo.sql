DROP procedure IF EXISTS `GetAnnouncementInfo`;

DELIMITER $$

CREATE DEFINER=`tce`@`%` PROCEDURE `GetAnnouncementInfo`(
IN announcement_id int
)
BEGIN
    select annt.State as Code,st.Description from `announcements_state` annt join `state` st on annt.State=st.Code where AnnouncementID=announcement_id;
	select annlt.LoanTypeId, loan_type.LoanType from `announcements_loan_type` annlt join `loan_type` on annlt.LoanTypeId= loan_type.LoanTypeId where AnnouncementID=announcement_id;
	select AnnouncementID,CreatedDate,Title,Content,Audience,`Status`,NumOfAppearance from `announcements` where announcementID=announcement_id;
END $$
DELIMITER ;