DROP PROCEDURE IF EXISTS `GetClientAdditionalInformation`;

DELIMITER $$
CREATE PROCEDURE `GetClientAdditionalInformation`(IN UserId int)
BEGIN
	SELECT 
		b.BrokerID,
		b.DefaultCourierID,
        b.AssignOrdersDirectly,
        b.TceFullFill,
		bd.HowHear,
		bd.HowHearShow,
		bd.SocialMedia,
		bd.SigningService,
		bd.SigningServiceUse,
		bd.isMultiCustomer,
		bd.DocDelivery,
		bd.MorningDelivery,
		bd.OtherCourier,
		bd.SignReleased,
		bd.ReturnLabel,
		bd.EmailDelivery,
		bd.DownloadFormat,
		bd.DownloadPassword,
		bd.DownloadSupport,
		bd.DownloadPrint,
		bd.EmailDocsReceived,
		bd.CopyPackage,
		bd.DownloadSite,
		bd.RegisContact,
		bd.PortalPrint,
		bd.TimeReceivedDocs,
		bd.PortalCopyPackage,
		bd.InkColor,
		bd.DocsSpecialInstructions,
		bd.SetApptTime,
		bd.TimeFlexible,
		bd.TimeWindowApp,
		bd.TimeWindow,
		bd.NoConfirmTravel,
		bd.IssueContact,
		bd.AfterHoursPhone,
		bd.DownloadHardware,
        bd.OvernightDelivery,
        bd.SecureEmailDelivery,
        bd.UploadDocDelivery,
        bd.DocLocationDelivery,
        bd.SpecialInstruction1,
		bd.SpecialInstruction2,
		bd.SpecialInstruction3,
		bd.SpecialInstruction4,
        bd.SpecialInstruction5,
        bd.SpecialInstruction6,
        bd.SpecialInstruction7,
        bd.SpecialInstruction8,
        bd.SpecialInstruction9,
        bd.SpecialInstruction10,
        bd.Collect1,
        bd.Collect2,
        bd.Collect3,
        bd.Collect4,
        bd.Collect5,
        bd.Collect6,
		bd.Collect7,
        bd.Collect8,
        bd.Collect9,
        bd.Collect10
		FROM broker b
		LEFT JOIN broker_detail bd ON b.BrokerID = bd.BrokerId
		WHERE b.BrokerID = UserId;
					
	SELECT Courier, CourierID FROM courier;
    
    SELECT tp.ProgramId, tp.Title from `training_programs` tp;
    
    SELECT b.ReqExperienceNumber, b.ReqRating from broker b where b.BrokerId = UserId;
    
    SELECT distinct btr.ProgramId from broker_training_req btr where btr.BrokerId = UserId;

	SELECT * FROM rating;
END$$

DELIMITER ;