DROP procedure IF EXISTS `GetNotificationManagement`;

DELIMITER $$
CREATE DEFINER=`tce`@`%` PROCEDURE `GetNotificationManagement`(
    IN notificationType varchar(255),
    IN purpose varchar(255),
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY NotifID ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE 1=1 ');
    
    IF (notificationType IS NOT NULL AND notificationType <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `NotificationType` LIKE ''%', notificationType, '%''');
	END IF;
    
    IF(purpose IS NOT NULL AND purpose <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Purpose LIKE ''%', purpose, '%''');
	END IF;
     set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from (select distinct 
									`notification_templates`.NotifID as `NotificationId`,
									`notification_templates`.Type as `NotificationType`,  
									`notification_templates`.Receiver as `Receiver`,
                                    `notification_templates`.Purpose as `Purpose`
							FROM `notification_templates`
                            ) t1, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
    END