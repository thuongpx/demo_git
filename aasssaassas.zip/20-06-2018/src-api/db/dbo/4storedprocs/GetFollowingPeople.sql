DROP PROCEDURE IF EXISTS `GetFollowingPeople`;

DELIMITER $$
CREATE DEFINER=`tce`@`%` PROCEDURE `GetFollowingPeople`(
IN role varchar(255),
IN clientId int,
IN gid int
)
BEGIN
	IF (role = 'Client') 
	THEN 
        select u.UsersId, b.Company, a.FullName, ur.RoleId, u.Status
		from `users` u
		left join `agent` a on a.AgentId = u.MappingUserId
		left join `broker` b on b.BrokerID = u.MappingUserId
		inner join `user_roles` ur on ur.UsersId = u.UsersId
		where (ur.RoleId=6 or ur.RoleId=7) and (a.BrokerId=clientId or b.GID=clientId);
	ELSE IF (role = 'Branch')
    THEN
		(select u.UsersId, a.FullName, "" as Company, ur.RoleId, u.Status
		from `agent` a 
		inner join `users` u on a.AgentId = u.MappingUserId
		inner join `user_roles` ur on ur.UsersId = u.UsersId
		where a.BrokerID=clientId and ur.RoleId=7) 
        union
		(select u.UsersId, "" as FullName, b.Company, ur.RoleId, u.Status
		from `broker` b 
		inner join `users` u on b.BrokerID = u.MappingUserId
		inner join `user_roles` ur on ur.UsersId = u.UsersId
		where b.BrokerID=gid and ur.RoleId=5);
	ELSE IF (role = 'Agent') 
	THEN 
        SET @branchId = (select 
			case when c.BrokerID IS NULL THEN NULL ELSE b.BrokerID END AS BranchId
			from `agent` a
			inner join `broker` b on a.BrokerId = b.BrokerID
			left join `broker` c on c.BrokerID = b.GID
			WHERE a.AgentId = clientId);
            
		SET @clientId = (select 
			case when c.BrokerID IS NULL THEN b.BrokerID ELSE c.BrokerID END AS ClientId
			from `agent` a
			inner join `broker` b on a.BrokerId = b.BrokerID
			left join `broker` c on c.BrokerID = b.GID
			WHERE a.AgentId = clientId);
            
        SELECT u.UsersId, "" as FullName, b.Company, ur.RoleId, u.Status
			FROM `broker` b
			INNER JOIN `users` u ON b.BrokerID = u.MappingUserId
			INNER JOIN `user_roles` ur ON ur.UsersId = u.UsersId 
			WHERE (b.BrokerID = @branchId OR b.BrokerID = @clientId) AND (ur.RoleId = 5 OR ur.RoleId = 6);
	END IF;
    END IF;
    END IF;
END$$
DELIMITER ;