DROP PROCEDURE IF EXISTS `GetAgentsByBrokerId`;

DELIMITER $$
CREATE PROCEDURE `GetAgentsByBrokerId`(
IN brokerId int,
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE a.BrokerId = ', brokerId, ' OR br.gId= ', brokerId);
   
	SET @querySql= concat('
    SELECT 
    SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			a.AgentId,
			a.FullName,
            a.Direct,
            a.Ext,
            a.Fax,
            a.Email,
            a.AfterhoursPhone,
			(CASE WHEN tbl.isDisabled IS NULL THEN FALSE
            ELSE TRUE END) as isDisabled,
            CAST(a.InActive AS unsigned) AS InActive 
            FROM agent a
            LEFT JOIN broker br ON a.brokerId = br.brokerId 
            LEFT JOIN (SELECT  COUNT(*) as isDisabled , ord.agentId FROM `order` ord 
            WHERE ord.progressId NOT IN (10,12)
            GROUP BY ord.agentId) tbl ON tbl.agentId = a.AgentId
            , (SELECT @rownum := 0) r ',
            whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END
