DROP PROCEDURE IF EXISTS `GetClientServicesConfigLog`;

DELIMITER $$
CREATE PROCEDURE `GetClientServicesConfigLog`(
	IN id int
)
BEGIN
	SELECT
        cscl.UpdatedDate,
        DATE_ADD(cscl.UpdatedDate, INTERVAL 30 DAY) as EstimatedEffectiveDate,
        u.UserName as ChangedBy,
        cscl.EffecttiveDate,
        csc.ApprovedBy,
		cscl.OrderPerDay,
        CONCAT('1 - ', cscl.CutoffDate) AS DateRange,
        cscl.State1,
        cscl.MSA1
	FROM client_services_config_log cscl
		LEFT JOIN users u ON cscl.UpdatedBy = u.UsersId
        LEFT JOIN client_services_config csc ON cscl.ConfigId = csc.ConfigId
    WHERE cscl.ConfigId = id
    ORDER BY cscl.UpdatedDate DESC
    ;
END$$
DELIMITER ;