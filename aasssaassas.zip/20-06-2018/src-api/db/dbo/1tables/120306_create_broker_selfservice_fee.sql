CREATE TABLE IF NOT EXISTS `broker_selfservice_fee` (
  `FeeId` int(11) NOT NULL AUTO_INCREMENT,
  `BrokerId` int(11) NOT NULL,
  `VendorFee` decimal(19,4) DEFAULT NULL,
  `TenantId` int(11) NOT NULL,
  `FeeDescription` varchar(100) DEFAULT NULL,
  `LoanTypeId` int(11) DEFAULT NULL,
  `IsAdditionalFee` bit(1) DEFAULT NULL,
  `SystemFee` int(11) DEFAULT NULL,
  PRIMARY KEY (`FeeId`),
  KEY `tenantId_broker_selfservice_fee_idx` (`TenantId`),
  KEY `brokerId_broker_selfservice_fee_idx` (`BrokerId`),
  KEY `loantpyeId_broker_selfservice_fee_idx` (`LoanTypeId`),
  CONSTRAINT `brokerId_broker_selfservice_fee` FOREIGN KEY (`BrokerId`) REFERENCES `broker` (`BrokerID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `loantpyeId_broker_selfservice_fee` FOREIGN KEY (`LoanTypeId`) REFERENCES `loan_type` (`LoanTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tenantId_broker_selfservice_fee` FOREIGN KEY (`TenantId`) REFERENCES `tenant` (`TenantId`) ON DELETE NO ACTION ON UPDATE NO ACTION
);
