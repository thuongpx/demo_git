export default {
	production: {
		host: "10.133.28.217",
		user: "tce",
		password: "12345678",
		database: "tce"
	},
	development: {
		host: "10.133.28.217",
		user: "tce",
		password: "12345678",
		database: "tce_dev2"
	},
	test: {
		host: "10.133.28.217",
		user: "tce",
		password: "12345678",
		database: "tce"
	}
};