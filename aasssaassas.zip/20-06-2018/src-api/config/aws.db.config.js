export default {
	production: {
		host: "10.133.28.217",
		user: "tce",
		password: "12345678",
		database: "tce"
	},
	development: {
		host: "172.31.50.20",
		user: "fpt-admin",
		password: "ictG7eYfwEvEtctseJ",
		database: "tce_staging"
	},
	test: {
		host: "10.133.28.217",
		user: "tce",
		password: "12345678",
		database: "tce"
	}
};