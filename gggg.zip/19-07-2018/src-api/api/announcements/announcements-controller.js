import Boom from "boom";
import Bookshelf from "../../db/database";
import UserAnnouncement from "../../db/model/user_announcement";
import Announcement from "../../db/model/announcement";
import { getRoleNamesByUsersId, handleSingleQuote } from "../../helper/common-helper";
import { isBuffer, bufferToBoolean } from "../../helper/common-helper";
import moment from "moment";

class AnnouncementsControler {
    async getAnnouncementsByUserId(request, reply) {
        const {
            userId
        } = request.query;

        const roleNames = await getRoleNamesByUsersId(userId);

        let audience = "";
        let isFound = false;
        for (const roleName of roleNames) {
            switch (roleName.roleName) {
                case "Client":
                case "Branch":
                    audience = "Client Admins/Managers";
                    isFound = true;
                    break;
                case "Agent":
                    audience = "Client Agents";
                    isFound = true;
                    break;
                case "Vendor":
                    audience = "Vendors";
                    isFound = true;
                    break;
                case "Admin":
                case "Operational Manager":
                case "Content Manager":
                case "Training Manager":
                case "Accounting Manager":
                    audience = "TCE Admins/Managers";
                    isFound = true;
                    break;
                case "Quality Control":
                case "Scheduler":
                case "Status Rep":
                    audience = "TCE Agents";
                    isFound = true;
                    break;
            }

            if (isFound) {
                break;
            }
        }

        await new Promise((resolve) => Announcement.where({ audience, status: "published" }).fetchAll({ columns: ["announcementId", "content", "numOfAppearance"] }).then(async (announcements) => {
            const addAnnouncement = async (announcement) => {
                await new Promise(resolveChild => UserAnnouncement.where({ announcementId: announcement.get("announcementId"), userId }).count("*").then(count => {
                    if (count === 0) {
                        new UserAnnouncement({ userId, announcementId: announcement.get("announcementId"), inActive: false, numOfAppearance: 0 }).save(null, { method: "insert" }).then(() => resolveChild());
                    } else {
                        resolveChild();
                    }
                }).catch(error => Boom.badRequest(error)));
            };
            for (const announcement of announcements.models) {
                await addAnnouncement(announcement);
            }

            resolve();

        }).catch(error => Boom.badRequest(error)));
        const rawSQL = `SELECT
                            an.AnnouncementID AS announcementId, an.Content AS content,
                            uan.NumOfAppearance AS numOfAppearance, uan.UserId AS userId, uan.UaId AS uaId
                        FROM announcements an LEFT JOIN user_announcement uan ON an.AnnouncementID = uan.AnnouncementID
                        WHERE 
                            an.Audience = '${audience}'
                            AND an.Status = 'published'
                            AND(uan.NumOfAppearance IS NULL OR uan.NumOfAppearance < an.NumOfAppearance)
                            AND(uan.UserId IS NULL OR uan.UserId = ${userId}) AND (uan.inActive IS NULL OR uan.inActive = 0)`;

        Bookshelf.knex.raw(rawSQL).then(result => {
            if (result !== null && result[0] !== null) {
                reply(result[0]);
            }
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }

    addUpdateUserAnnouncements(request, reply) {
        const { announcements } = request.payload;
        announcements.forEach(announcement => {
            if (announcement.uaId > 0) {
                UserAnnouncement.where({ uaId: announcement.uaId }).save(announcement, { method: "update" }).then(() => {
                    reply({ isSuccess: true });
                }).catch(error => Boom.badRequest(error));
            }
        });
    }

    getVendorAnnouncements(request, reply) {
        const { sortColumn,
            sortDirection,
            page,
            itemPerPage,
            signerId } = request.query;

        const rawSql = `call GetVendorAnnouncements('${sortColumn}',${sortDirection},${page}, ${itemPerPage}, ${signerId})`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    Object.keys(result[0][0]).forEach((key) => {
                        const value = result[0][0][key].Viewed;
                        if (isBuffer(value)) {
                            result[0][0][key].Viewed = bufferToBoolean(value);
                        }
                    });
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getUserUnreadAnnouncements(request, reply) {
        const { sortColumn,
            sortDirection,
            page,
            itemPerPage,
            userId } = request.query;

        const rawSql = `call GetUserUnreadAnnouncements('${sortColumn}',${sortDirection},${page}, ${itemPerPage}, ${userId})`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    Object.keys(result[0][0]).forEach((key) => {
                        const value = result[0][0][key].Viewed;
                        if (isBuffer(value)) {
                            result[0][0][key].Viewed = bufferToBoolean(value);
                        }
                    });
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getUserReadAnnouncements(request, reply) {
        const { sortColumn,
            sortDirection,
            page,
            itemPerPage,
            userId,
            fromDate,
            toDate,
            title } = request.query;

        const strFromDate = (fromDate === undefined || fromDate === null || fromDate === "invalid date") ? null : `'${fromDate}'`;
        const strToDate = (toDate === undefined || toDate === null || toDate === "invalid date") ? null : `'${toDate}'`;

        const rawSql = `call GetUserReadAnnouncements('${sortColumn}',${sortDirection},${page}, ${itemPerPage}, ${userId},${strFromDate},${strToDate},'${handleSingleQuote(title)}')`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    Object.keys(result[0][0]).forEach((key) => {
                        const value = result[0][0][key].Viewed;
                        if (isBuffer(value)) {
                            result[0][0][key].Viewed = bufferToBoolean(value);
                        }
                    });
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
    updateReadUserAnnouncement(request, reply) {
        const announcementData = request.payload;
        new UserAnnouncement().save({
            UserId: announcementData.userId,
            AnnouncementID: announcementData.AnnouncementID,
            NumOfAppearance: 1,
            InActive: 0,
            SendDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            Viewed: 1

        }, { method: "insert" }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getTotalUnreadAnnouncement(request, reply) {
        const { userId } = request.query;
        const rawSql = `SELECT count(an.AnnouncementID) as count 
                        FROM announcements AS an
                        INNER JOIN
                        (SELECT CASE
                                    WHEN rp.RoleId = 1 THEN "TCE Admins/Managers"
                                    WHEN rp.RoleId = 2 THEN "TCE Admins/Managers"
                                    WHEN rp.RoleId = 3 THEN "TCE Agents"
                                    WHEN rp.RoleId = 4 THEN "TCE Agents"
                                    WHEN rp.RoleId = 5 THEN "Client Admins/Managers"
                                    WHEN rp.RoleId = 6 THEN "Client Admins/Managers"
                                    WHEN rp.RoleId = 7 THEN "Client Agents"
                                    WHEN rp.RoleId = 8 THEN "Vendors"
                                    WHEN rp.RoleId = 9 THEN "TCE Admins/Managers"
                                    WHEN rp.RoleId = 10 THEN "TCE Admins/Managers"
                                    WHEN rp.RoleId = 11 THEN "TCE Admins/Managers"
                                    WHEN rp.RoleId = 12 THEN "TCE Agents"
                                END as Audience,
                            u.UsersId as UsersId
                        FROM users u 
                        INNER JOIN user_roles ur ON u.UsersId = ur.UsersId
                        INNER JOIN roles rp ON ur.RoleId = rp.RoleId
                        WHERE u.UsersId = ${userId}) AS userRole ON an.Audience = userRole.Audience
                        LEFT JOIN user_announcement AS uan ON an.AnnouncementID = uan.AnnouncementID AND uan.UserId = ${userId}
                        WHERE (uan.Viewed = 0 OR uan.Viewed IS NULL) AND Status = 'Published' ;`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                reply({
                    totalUnreadAnnouncement: result[0][0].count
                });
                return;
            }
            reply({ isSuccess: false, message: "No record found!" });
            return;
        }).catch(error => {
            reply(Boom.badRequest(error));
            return;
        });
    }
}

export default new AnnouncementsControler();