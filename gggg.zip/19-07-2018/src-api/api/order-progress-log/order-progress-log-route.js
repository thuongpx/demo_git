import OrderProgressLogController from "./order-progress-log-controller";

const routes = [{
        path: "/orderprogress/addProgressLog",
        method: "POST",

        handler: OrderProgressLogController.addProgressLog
    },
    {
        path: "/orderprogress/addMultiProgressLog",
        method: "POST",

        handler: OrderProgressLogController.addMultiProgressLog
    },
    {
        path: "/orderprogress/getOrderProgressLogById",
        method: "GET",

        handler: OrderProgressLogController.getOrderProgressLogById
    },
    {
        path: "/orderprogress/getDataAlert",
        method: "GET",
        handler: OrderProgressLogController.getDataAlert
    },
    {
        path: "/orderprogress/updateMaskAsReadOrUnread",
        method: "POST",
        handler: OrderProgressLogController.updateMaskAsReadOrUnread
    },
    {
        path: "/orderprogress/markAsRead",
        method: "POST",
        handler: OrderProgressLogController.markAsRead
    },
    {
        path: "/orderprogress/getAllDataAlert",
        method: "GET",
        handler: OrderProgressLogController.getAllDataAlert
    },
    {
        path: "/orderprogress/getPositionAlert",
        method: "GET",
        handler: OrderProgressLogController.getPositionAlert
    }
];

export default routes;