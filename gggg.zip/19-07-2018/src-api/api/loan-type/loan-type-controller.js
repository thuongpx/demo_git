import Boom from "boom";
import Bookshelf from "../../db/database";
import LoanType from "../../db/model/loan-type";

class LoanTypeController {
    getLoanTypes(request, reply) {
        LoanType.forge().orderBy("LoanType").fetchAll().then((result) => {
            if (result !== null) {
                reply({ isSuccess: true, loanTypes: result });
                return;
            }

            reply({ isSuccess: false, message: "No record found!" });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
        return;
    }

    getLoanTypeByIndustryId(request, reply) {
        const { industryId } = request.query;
        const rawSql = `SELECT L.LoanTypeId, l.LoanType from industry_transaction_fees i inner join loan_type l on i.LoanTypeId=l.LoanTypeId where i.industryId =${industryId} and i.IsAdditionalFee = 0 order by loantype`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply(result[0]);
                }
            }).catch((error) => {
                Boom.badRequest(error);
            });
    }
}

export default new LoanTypeController();