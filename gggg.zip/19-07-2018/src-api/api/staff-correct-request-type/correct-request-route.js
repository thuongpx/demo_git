import CorrectRequestController from "./correct-request-controller";
const routes = [{
        path: "/problem/getCorrectionRequestType",
        method: "GET",
        handler: CorrectRequestController.getCorrectionRequestType
    },
    {
        path: "/problem/deleteCorrectionRequestType",
        method: "POST",
        handler: CorrectRequestController.deleteCorrectionRequestType
    },
    {
        path: "/problem/getCorretionRequestById",
        method: "GET",
        handler: CorrectRequestController.getCorretionRequestById
    },
    {
        path: "/problem/checkExistCorrectionRequest",
        method: "POST",
        handler: CorrectRequestController.checkExistCorrectionRequest
    },
    {
        path: "/problem/addCorrectionRequest",
        method: "POST",
        handler: CorrectRequestController.addCorrectionRequest
    },
    {
        path: "/problem/updateCorrectionRequest",
        method: "POST",
        handler: CorrectRequestController.updateCorrectionRequest
    }
];

export default routes;