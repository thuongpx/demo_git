import Boom from "boom";
import Bookshelf from "../../db/database";
import Industry from "../../db/model/industry";
import LoanType from "../../db/model/loan-type";
import IndustryTransactionFees from "../../db/model/industry_transaction_fees";
class FeeConfiguration {
    constructor() { }

    getInitDataForMatrix(request, reply) {
        const getIndustryList = Promise.resolve(Industry.forge().orderBy("Description").fetchAll());
        const apiGetProductList = Promise.resolve(LoanType.forge().orderBy("LoanType").fetchAll());
        const apiGetFeeDescriptionList = Promise.resolve(Bookshelf.knex.raw(`select distinct itf.FeeDescription from industry_transaction_fees itf where itf.IsAdditionalFee = 1 order by itf.FeeDescription`));
        const apiGetFeeTransactionList = Promise.resolve(Bookshelf.knex.raw(`Select itf.FeeDescription,itf.ClientFee,itf.VendorFee, itf.Feeid,itf.LoanTypeId,itf.IndustryId,
        (case when itf.IsAdditionalFee = 0 then 0 else 1 end) as IsAdditionalFee
        from industry_transaction_fees itf
                order by itf.FeeDescription;`));
        Promise.all([apiGetFeeTransactionList, apiGetFeeDescriptionList, apiGetProductList, getIndustryList])
            .then(value => {
                const data = {};
                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.feeTransactions = item[0];
                                    break;
                                case 1:
                                    data.feeDescriptions = item[0];
                                    break;
                                case 2:
                                    data.products = item;
                                    break;
                                case 3:
                                    data.industries = item;
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
        return reply;
    }

    saveFee(request, reply) {
        const { industryId, remove, save } = request.payload;
        //save
        const subTaskSave = Promise.resolve(
            save.forEach(s => {
                if (!remove.includes(s.LoanTypeId)) {
                    if (s.Feeid === null) {
                        new IndustryTransactionFees().save({
                            IndustryId: industryId,
                            LoanTypeId: s.LoanTypeId,
                            FeeDescription: s.FeeDescription,
                            ClientFee: s.ClientFee,
                            VendorFee: s.VendorFee,
                            IsAdditionalFee: s.IsAdditionalFee
                        }, {
                                method: "insert"
                            }).then(() => {
                            }).catch((error) => {
                                return error;
                            });
                    } else {
                        IndustryTransactionFees.where({
                            FeeId: s.Feeid
                        }).save(s, {
                            method: "update"
                        }).then(() => {
                        }).catch((error) => {
                            return error;
                        });
                    }
                }
            })
        );
        //remove
        const subTaskRemove = Promise.resolve(
            remove.forEach(r => {
                IndustryTransactionFees.where({
                    LoanTypeId: r
                }).destroy().then(() => {
                }).catch((error) => {
                    return error;
                });
            })
        );

        //promiseall
        Promise.all([subTaskSave, subTaskRemove])
            .then(value => {
                if (value !== null) {
                    reply({
                        isSuccess: true
                    });
                } else {
                    reply({
                        isSuccess: false
                    });
                }
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

}

export default new FeeConfiguration();