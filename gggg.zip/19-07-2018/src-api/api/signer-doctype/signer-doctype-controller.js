import Signer from "../../db/model/signers";
import SignerDocType from "../../db/model/signer-doctype";
import Boom from "boom";

class SignerDocTypeController {
	constructor() { }

	getDocTypeBySignerId(request, reply) {
		const { signerId } = request.query;
		Signer.where({ signerId }).fetch({ columns: ["weekDayState"] }).then(signer => {
			const weekDayState = signer.attributes.weekDayState;
			SignerDocType.query((qb) => {
				qb.where("states", "LIKE", `%${weekDayState}%`).orWhere("states", "=", "US");
			}).fetchAll({ columns: ["docTypeId", "expires", "docType", "fileName"] }).then(doctypes => reply(doctypes));
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}
}

export default new SignerDocTypeController();