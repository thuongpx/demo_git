import OrderRequestApprovalController from "./order-request-approval-controller";

const routes = [
    {
        path: "/orderRequestApproval/checkVendorAssignConditionsOfOrder",
        method: "GET",
        handler: OrderRequestApprovalController.checkVendorAssignConditionsOfOrder
    }, {
        path: "/orderRequestApproval/approveFeeRequest",
        method: "POST",
        handler: OrderRequestApprovalController.approveFeeRequest
    }, {
        path: "/orderRequestApproval/submitFeeRequestToMgr",
        method: "POST",
        handler: OrderRequestApprovalController.submitFeeRequestToMgr
    },
    {
        path: "/orderRequestApproval/getOrderFeeApprovalReasonStaff",
        method: "GET",
        handler: OrderRequestApprovalController.getOrderFeeApprovalReasonStaff
    },
    {
        path: "/orderRequestApproval/sendMailWhenSubmitToManager",
        method: "POST",
        handler: OrderRequestApprovalController.sendMailWhenSubmitToManager
    },
    {
        path: "/orderRequestApproval/processClientFeeRequest",
        method: "POST",
        handler: OrderRequestApprovalController.processClientFeeRequest
    },
    {
        path: "/orderRequestApproval/sendEmailClientFeeRequestToTceManager",
        method: "POST",
        handler: OrderRequestApprovalController.sendEmailClientFeeRequestToTceManager
    }

];

export default routes;