export default {
	host: "10.133.28.217",
	user: "tce",
	password: "12345678",
	database: "tce_dev"
};