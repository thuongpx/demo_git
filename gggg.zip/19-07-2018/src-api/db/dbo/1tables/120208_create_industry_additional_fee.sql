CREATE TABLE IF NOT EXISTS `industry_additional_fee` (
	`Id` INT(11) NOT NULL AUTO_INCREMENT,
    `IndustryId` INT(11) NOT NULL,
    `FeeDescriptionId` INT(11) NOT NULL,
    `ClientFee` DECIMAL(19, 4),
    `VendorFee` DECIMAL(19, 4),
    PRIMARY KEY (`Id`),
    KEY `industryId_industry_additional_fee_idx` (`IndustryId`),
    CONSTRAINT `industryId_industry_additional_fee` FOREIGN KEY(`IndustryId`) 
		REFERENCES `industry` (`IndustryId`) ON UPDATE NO ACTION ON DELETE NO ACTION,
	KEY `feeDescriptionId_industry_additional_fee_idx` (`FeeDescriptionId`),
    CONSTRAINT `feeDescriptionId_industry_additional_fee` FOREIGN KEY(`FeeDescriptionId`)
		REFERENCES `fee_descriptions` (`FeeDescriptionId`) ON UPDATE NO ACTION ON DELETE NO ACTION
);