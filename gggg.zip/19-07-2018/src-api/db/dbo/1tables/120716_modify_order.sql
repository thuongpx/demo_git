DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	-- Drop Constraint
    IF EXISTS (SELECT 1 FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'tce_staging' AND CONSTRAINT_NAME = 'StaffId') THEN
	BEGIN
		ALTER TABLE `order` 
		DROP FOREIGN KEY `StaffId`;
		ALTER TABLE `order` 
		DROP INDEX `StaffId_idx`;
	END;
    END IF;      
END$$

DELIMITER ;

CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;