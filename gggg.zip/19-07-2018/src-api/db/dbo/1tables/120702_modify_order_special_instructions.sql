DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN    
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Permanently1') THEN
	BEGIN
		ALTER TABLE `order_special_instructions` DROP COLUMN `Permanently1`;
	END;
    END IF;
    
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Permanently2') THEN
	BEGIN
		ALTER TABLE `order_special_instructions` DROP COLUMN `Permanently2`;
	END;
    END IF;
    
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Permanently3') THEN
	BEGIN
		ALTER TABLE `order_special_instructions` DROP COLUMN `Permanently3`;
	END;
    END IF;
    
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Permanently4') THEN
	BEGIN
		ALTER TABLE `order_special_instructions` DROP COLUMN `Permanently4`;
	END;
    END IF;
    
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Permanently5') THEN
	BEGIN
		ALTER TABLE `order_special_instructions` DROP COLUMN `Permanently5`;
	END;
    END IF;
    
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Permanently6') THEN
	BEGIN
		ALTER TABLE `order_special_instructions` DROP COLUMN `Permanently6`;
	END;
    END IF;
    
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Permanently7') THEN
	BEGIN
		ALTER TABLE `order_special_instructions` DROP COLUMN `Permanently7`;
	END;
    END IF;
    
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Permanently8') THEN
	BEGIN
		ALTER TABLE `order_special_instructions` DROP COLUMN `Permanently8`;
	END;
    END IF;
    
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Permanently9') THEN
	BEGIN
		ALTER TABLE `order_special_instructions` DROP COLUMN `Permanently9`;
	END;
    END IF;
    
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_special_instructions' AND 
                            COLUMN_NAME = 'Permanently10') THEN
	BEGIN
		ALTER TABLE `order_special_instructions` DROP COLUMN `Permanently10`;
	END;
    END IF;
END$$

DELIMITER ;
CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;