
DELIMITER $$
CREATE PROCEDURE `alter_table_signer_offer` ()
BEGIN
	-- IsEliteVendor
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'signer_offer' AND 
                            COLUMN_NAME = 'IsEliteVendor') THEN
	BEGIN
		ALTER TABLE `signer_offer` 
		ADD COLUMN `IsEliteVendor` BIT NULL DEFAULT b'0';
	END;
    END IF;
    
    -- Distance
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'signer_offer' AND 
                            COLUMN_NAME = 'Distance') THEN
	BEGIN
		ALTER TABLE `signer_offer` 
		ADD COLUMN `Distance` FLOAT NULL;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_signer_offer();

DROP PROCEDURE IF EXISTS `alter_table_signer_offer`;





