import Boom from "boom";
import { paginate, generateCommonQuickBook, deleteCommonQuickBookFile, downloadCommonQuickBookFile, getCommonQuickBookFiles, getInvoiceReports } from "../../helper/quickbook-helper";
import { INVOICE_REPORT_TEMPLATE } from "../../constant/quickbook-invoice";
class QuickbookInvoiceController {
    constructor() { }
    async exporQuickBook(request, reply) {
        const { fromDate, toDate, quickBookType } = request.payload;
        await generateCommonQuickBook(fromDate, toDate, quickBookType, (error) => {
            if (error === "no-records-found") {
                reply({ isNoRecordFound: true });
            } else if (error) reply(Boom.badRequest(error));
            else reply({ isSuccess: true });
        });
    }

    async getQuickBooks(request, reply) {
        const { quickBookType, page, itemPerPage, sortDirection, sortColumn } = request.payload;
        const files = await getCommonQuickBookFiles(quickBookType);

        reply({ data: paginate(files, itemPerPage, page, sortDirection, sortColumn), totalRecords: files.length });
    }

    deleteQuickBookInvoice(request, reply) {
        const { fileName, quickBookType } = request.payload;
        deleteCommonQuickBookFile(fileName, quickBookType, (error) => {
            if (error) reply(Boom.badRequest(error));
            else {
                reply({ isSuccess: true });
            }
        });
    }

    downloadQuickBookInvoice(request, reply) {
        const { fileName, quickBookType } = request.query;
        downloadCommonQuickBookFile(reply, fileName, quickBookType);
    }

    getInvoiceReports(request, reply) {
        const { brokerId, isIncludeBranchs, state, startMonth, endMonth, inYear } = request.payload;
        getInvoiceReports(brokerId, isIncludeBranchs, state, startMonth, endMonth, inYear, (data, error) => {
            if (error === "no-records-found") {
                reply({ isNoRecordFound: true });
            } else if (error) reply(Boom.badRequest(error));
            reply(data);
        });
    }
}
export default new QuickbookInvoiceController();