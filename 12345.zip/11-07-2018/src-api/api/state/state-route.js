import StateListController from "./state-controller";

const routes = [{
    path: "/state/getAllState",
    method: "GET",
    config: {
        auth: false
    },
    handler: StateListController.getAllState
}];

export default routes;