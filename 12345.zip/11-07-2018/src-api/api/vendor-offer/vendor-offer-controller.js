import Boom from "boom";
import Bookshelf from "../../db/database";
import SignerOffer from "../../db/model/signer-offer";
import Users from "../../db/model/users";
import Order from "../../db/model/order";
import SignerHistory from "../../db/model/signer-history";
import OrderProgressLog from "../../db/model/order-progress-log";
import moment from "moment";
import sendMailCore from "../../mail/mail-helper";
import { bufferToBoolean } from "../../helper/common-helper";
import {
    mergeDataField,
    hasStringValue,
    getUTCName,
    replaceAll,
    logNotificationAndSendToVendor
} from "../../helper/common-helper";
import {
    getMergeFieldMappingVendorOffer
} from "../../merge-engine/vendor-offer/vendor-decline-offer";
import { ORDER_PROGRESS_ID } from "../../constant/progress-constant";

class VendorOfferController {

    getVendorOffer(request, reply) {

        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            orderID,
            daysBack,
            offerStatus,
            signerId
        } = request.query;
        const rawSql = `call GetVendorOffer(${signerId},'${sortColumn}',${sortDirection},${page}, ${itemPerPage},${orderID},${daysBack},'${offerStatus}')`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

    }

    addVendorOffer(request, reply) {
        const {
            data
        } = request.payload;
        const signersOffer = [];

        data.forEach((item) => {
            signersOffer.push({
                SignerId: item.signerId,
                TenantId: 1,
                OfferAmount: item.offerAmount,
                GUID: item.GUID,
                OrderId: item.orderId,
                RepId: item.userId,
                SentDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                OfferStatus: "O",
                Distance: item.distance
            });
        });

        const customSingerOffer = Bookshelf.Collection.extend({
            model: SignerOffer
        });

        const signerOfferAdd = customSingerOffer.forge(signersOffer);

        signerOfferAdd.invokeThen("save").then(result => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });
            }
        }).catch(error => {
            reply(Boom.badRequest(`${error.code}: ${error.sqlMessage}`));
        });
    }

    updateStatusVendorOffer(request, reply) {
        const signerOffer = request.payload;
        SignerOffer.where({
            OrderID: signerOffer.orderId,
            SignerId: signerOffer.signerId
        }).save({
            OfferStatus: signerOffer.offerStatus
        }, {
                method: "update"
            }).then(async result => {
                if (result !== null) {
                    if (signerOffer.offerStatus === "A") {
                        await new Promise((resolve) => Order.where({
                            OrderID: signerOffer.orderId
                        }).save({
                            SignerId: signerOffer.signerId,
                            ProgressId: ORDER_PROGRESS_ID.ASSIGNED_TO_VENDOR,
                            FilledDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
                        }, {
                                method: "update"
                            }).then(() => resolve()).catch((error) => {
                                reply(Boom.badRequest(error));
                            }));
                        await new Promise((resolve) => new OrderProgressLog().save({
                            OrderId: signerOffer.orderId,
                            UsersId: signerOffer.userId,
                            Activity: `${signerOffer.userName} is assigned to order #${signerOffer.orderId}`,
                            DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                            IsPrivate: 0,
                            ProgressType: 1
                        }, {
                                method: "insert"
                            }).then(() => resolve()).catch((error) => {
                                reply(Boom.badRequest(error));
                            }));
                        //log vendor notification
                        await logNotificationAndSendToVendor(signerOffer.orderId, signerOffer.signerId, false);

                        await new Promise((resolve) => new SignerHistory().save({
                            OrderId: signerOffer.orderId,
                            SignerId: signerOffer.signerId,
                            Status: "Assigned",
                            HistoryDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
                        }, {
                                method: "insert"
                            }).then(() => resolve()).catch((error) => {
                                reply(Boom.badRequest(error));
                            }));

                        const rawSqlEmploy = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor has been asign schedulers';`));
                        const rawSqlVendor = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor offer accept success';`));
                        const rawSqlAgent = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor has been asign agent';`));

                        Promise.all([rawSqlEmploy, rawSqlVendor, rawSqlAgent])
                            .then(values => {
                                if (values !== null) {
                                    let subject = "";
                                    let to = "";

                                    values.forEach((item, index) => {
                                        if (item !== null) {
                                            switch (index) {
                                                case 0:
                                                    {
                                                        subject = replaceAll(item[0][0].subject, "[orderID]", signerOffer.orderId);
                                                        to = signerOffer.employeesEmail;
                                                        break;
                                                    }
                                                case 1:
                                                    {
                                                        subject = item[0][0].subject;
                                                        to = signerOffer.vendorEmail;
                                                        break;
                                                    }
                                                case 2:
                                                    {
                                                        subject = replaceAll(item[0][0].subject, "[orderID]", signerOffer.orderId);
                                                        to = signerOffer.agentEmail;
                                                        break;
                                                    }
                                            }

                                            const mailtHtml = mergeDataField(item[0][0].message, getMergeFieldMappingVendorOffer(signerOffer));
                                            const mailOptions = {
                                                from: item[0][0].fromEmail,
                                                to,
                                                subject,
                                                text: `Send Email`,
                                                html: mailtHtml
                                            };

                                            sendMailCore(mailOptions);
                                        }
                                    });
                                }
                            });
                        reply({
                            isSuccess: true
                        });
                    } else {
                        if (signerOffer.valueExistVendorOffer === 2 || signerOffer.valueExistVendorOffer === 3) {
                            const rawSql = `select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor accept missing vendor';`;

                            Bookshelf.knex.raw(rawSql)
                                .then((message) => {
                                    const mailVendorHtml = mergeDataField(message[0][0].message, getMergeFieldMappingVendorOffer(signerOffer));
                                    const mailVendorOptions = {
                                        from: message[0][0].fromEmail,
                                        to: signerOffer.vendorEmail,
                                        subject: message[0][0].subject,
                                        text: `Send Email`,
                                        html: mailVendorHtml
                                    };
                                    sendMailCore(mailVendorOptions);
                                });
                        }
                        reply({
                            isSuccess: true
                        });
                    }
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getReasonDeclined(request, reply) {
        const rawSql = `select DenialReasonID, DenialReason from offer_denial_reason order by DenialReasonID;`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0]
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    sendRequestFeedback(request, reply) {
        const feedback = request.payload;
        const stringAltTime = feedback.altTime === null ? null : `'${feedback.altTime}'`;
        const rawSql = `call DeclinedVendorOffer(${feedback.offerID},${feedback.orderId},${feedback.userId},${feedback.signerId},${feedback.selectedReasonOptions},${stringAltTime},${feedback.typeID}, ${feedback.offerAmount}, ${feedback.feeAmount},'${feedback.additionalInfo}')`;
        // let templateDeclineOfferEmployment = "";
        let templateDeclineOfferAgent = "";

        switch (feedback.selectedReasonOptions) {
            case 0:
                {
                    templateDeclineOfferAgent = "vendor declined no reason agent";
                    break;
                }
            case 1:
                {
                    // templateDeclineOfferEmployment = "vendor decline offer not available schedulers";
                    templateDeclineOfferAgent = "vendor decline offer not available agent";
                    break;
                }
            case 2:
                {
                    // templateDeclineOfferEmployment = "vendor decline offer location schedulers";
                    templateDeclineOfferAgent = "vendor decline offer location agent";
                    break;
                }
            case 3:
                {
                    // templateDeclineOfferEmployment = "vendor decline offer pay low schedulers";
                    templateDeclineOfferAgent = "vendor decline offer pay low agent";
                    break;
                }
            case 4:
                {
                    // templateDeclineOfferEmployment = "vendor decline offer no longer schedulers";
                    templateDeclineOfferAgent = "vendor decline offer no longer agent";
                    break;
                }
            case 5:
                {
                    // templateDeclineOfferEmployment = "vendor decline offer other schedulers";
                    templateDeclineOfferAgent = "vendor decline offer other agent";
                    break;
                }
        }

        if (feedback.selectedReasonOptions === 2 || feedback.selectedReasonOptions === 3) {
            new OrderProgressLog().save({
                orderId: feedback.orderId,
                activity: `${feedback.userName} submitted a fee request`,
                dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                usersId: feedback.userId,
                progressType: 1
            }, { method: "insert" }).then(() => {
            }).catch((error) => reply(Boom.badRequest(error)));
        }

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    // let rawSqlEmploy = "";
                    let rawSqlVendor = "";
                    let rawSqlAgent = "";
                    let queue = [];

                    if (feedback.selectedReasonOptions === 2 || feedback.selectedReasonOptions === 3) {
                        // rawSqlEmploy = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = '${templateDeclineOfferEmployment}';`));
                        rawSqlAgent = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = '${templateDeclineOfferAgent}';`));
                        queue = [rawSqlAgent];
                    } else {
                        // rawSqlEmploy = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = '${templateDeclineOfferEmployment}';`));
                        rawSqlVendor = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor decline offer confirm vendor';`));
                        rawSqlAgent = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = '${templateDeclineOfferAgent}';`));
                        queue = [rawSqlAgent, rawSqlVendor];
                    }

                    Promise.all(queue)
                        .then(values => {
                            if (values !== null) {
                                values.forEach((item, index) => {
                                    if (item !== null) {
                                        let to = "";
                                        switch (index) {
                                            case 0:
                                                {
                                                    to = feedback.agentEmail;
                                                    break;
                                                }
                                            case 1:
                                                {
                                                    to = feedback.vendorEmail;
                                                    break;
                                                }
                                            // case 2:
                                            //     {
                                            //         to = feedback.employeesEmail;
                                            //         break;
                                            //     }
                                        }
                                        const mailHtml = mergeDataField(item[0][0].message, getMergeFieldMappingVendorOffer(feedback));
                                        const mailOptions = {
                                            from: item[0][0].fromEmail,
                                            to,
                                            subject: replaceAll(item[0][0].subject, "[OrderID]", feedback.orderId),
                                            text: `Send Email`,
                                            html: mailHtml
                                        };
                                        sendMailCore(mailOptions);
                                    }
                                });
                            }
                        });
                    reply({
                        data: result
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    inactivatedUser(request, reply) {
        const {
            UsersId
        } = request.payload;

        Users.where({
            UsersId
        }).save({
            InActive: true
        }, {
                method: "update"
            }).then((result) => {
                if (result !== null) {
                    reply({
                        isSuccess: true
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    checkExistVendorOffer(request, reply) {
        const {
            aptDateTime,
            signerId,
            orderId
        } = request.query;

        const appt = (aptDateTime === null || aptDateTime === undefined) ? null : `'${moment(aptDateTime).format("YYYY-MM-DD HH:mm:ss")}'`;
        const rawSql = `call CheckExistVendorOffer(${appt},${signerId}, ${orderId})`;
        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0][0].isValid
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getVendorOfferByGUID(request, reply) {
        const {
            paramGUID
        } = request.query;
        const rawSql = `call GetVendorOfferByGUID('${paramGUID}')`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getAccountbyGUID(request, reply) {
        const {
            paramGUID
        } = request.query;
        const rawSql = `select users.UsersId as usersId, users.UserName as userName, signer_offer.SignerId as signerId from users
        inner join signer_offer on users.MappingUserId = signer_offer.SignerId
        inner join user_roles on users.UsersId = user_roles.UsersId
        inner join roles on user_roles.RoleId = roles.RoleId
        where roles.RoleId = 8
        and signer_offer.GUID = '${paramGUID}';`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0]
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    mobileGetOffers(request, reply) {
        const {
            orderId,
            signerId,
            offerStatus,
            daysback,
            sortBy,
            sortDirection,
            page,
            itemPerPage
        } = request.query;

        Bookshelf.knex.raw(`call mobileGetOffers(${orderId},${signerId},'${daysback}','${offerStatus}','${sortBy}',${sortDirection},${page},
        ${itemPerPage})`)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        return reply;
    }

    mobileSendRequestFeedback(request, reply) {
        const feedback = request.payload;
        const stringAltTime = feedback.altTime === null ? null : `'${feedback.altTime}'`;
        const rawSql = `call DeclinedVendorOffer(${feedback.offerID},${feedback.orderId},${feedback.userId},${feedback.signerId},${feedback.selectedReasonOptions},${stringAltTime},${feedback.typeID}, ${feedback.offerAmount}, ${feedback.feeAmount},'${feedback.additionalInfo}')`;
        // let templateDeclineOfferEmployment = "";
        let templateDeclineOfferAgent = "";

        const getEmailDataSql = `
        SELECT 	signer_offer.OfferID AS offerID,
            signer_offer.OrderID AS orderId,
            employees.Email AS employeesEmail,
            loan_type.LoanType AS loanType,
            \`order\`.AptDateTime AS aptDateTime,
            \`order\`.City AS city,
            \`order\`.Zip AS zip,
            \`order\`.BrokerIdNum AS brokerIdNum,
            \`order\`.LastName AS borrowerLastName,
             69.1*sqrt(POWER((signer.Lat - \`order\`.Lat), 2) + 0.6*POWER((signer.\`Long\` - \`order\`.\`Long\`), 2)) AS distance,
            signer.Mobile AS vendorMobile,
            signer.Email AS vendorEmail,
            signer.FirstName AS vendorFirstName,
            signer.LastName AS vendorLastName,
            agent.Email AS agentEmail,
            agent.FullName AS agentFullName,
            signer_offer.OfferAmount AS offerAmount,
            signer_offer.OfferStatus AS offerStatus
        FROM signer_offer
        INNER JOIN \`order\` ON signer_offer.OrderID = \`order\`.OrderID AND signer_offer.OfferID = ${feedback.offerID}
        INNER JOIN loan_type ON \`order\`.LoanType = loan_type.LoanTypeID
        INNER JOIN signer ON signer_offer.SignerId = signer.SignerId
        LEFT JOIN employees ON signer_offer.RepId = employees.RepId
        LEFT JOIN agent ON \`order\`.AgentId = agent.AgentId;`;

        let emailData = {};
        Bookshelf.knex.raw(getEmailDataSql)
            .then((getEmailDataResult) => {
                if (getEmailDataResult !== undefined) {
                    emailData = getEmailDataResult[0][0];
                }
            });

        switch (feedback.selectedReasonOptions) {
            case 0:
                {
                    templateDeclineOfferAgent = "vendor declined no reason agent";
                    break;
                }
            case 1:
                {
                    // templateDeclineOfferEmployment = "vendor decline offer not available schedulers";
                    templateDeclineOfferAgent = "vendor decline offer not available agent";
                    break;
                }
            case 2:
                {
                    // templateDeclineOfferEmployment = "vendor decline offer location schedulers";
                    templateDeclineOfferAgent = "vendor decline offer location agent";
                    break;
                }
            case 3:
                {
                    // templateDeclineOfferEmployment = "vendor decline offer pay low schedulers";
                    templateDeclineOfferAgent = "vendor decline offer pay low agent";
                    break;
                }
            case 4:
                {
                    // templateDeclineOfferEmployment = "vendor decline offer no longer schedulers";
                    templateDeclineOfferAgent = "vendor decline offer no longer agent";
                    break;
                }
            case 5:
                {
                    // templateDeclineOfferEmployment = "vendor decline offer other schedulers";
                    templateDeclineOfferAgent = "vendor decline offer other agent";
                    break;
                }
        }

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    // let rawSqlEmploy = "";
                    let rawSqlVendor = "";
                    let rawSqlAgent = "";
                    let queue = [];

                    if (feedback.selectedReasonOptions === 2 || feedback.selectedReasonOptions === 3) {
                        rawSqlVendor = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor decline offer confirm vendor';`));
                        rawSqlAgent = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = '${templateDeclineOfferAgent}';`));
                        queue = [rawSqlAgent];
                    } else {
                        // rawSqlEmploy = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = '${templateDeclineOfferEmployment}';`));
                        rawSqlVendor = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor decline offer confirm vendor';`));
                        rawSqlAgent = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = '${templateDeclineOfferAgent}';`));
                        queue = [rawSqlAgent, rawSqlVendor];
                    }

                    Promise.all(queue)
                        .then(values => {
                            if (values !== null) {
                                values.forEach((item, index) => {
                                    if (item !== null) {
                                        let to = "";
                                        switch (index) {
                                            case 0:
                                                {
                                                    to = emailData.agentEmail;
                                                    break;
                                                }
                                            case 1:
                                                {
                                                    to = emailData.vendorEmail;
                                                    break;
                                                }
                                            // case 2:
                                            //     {
                                            //         to = emailData.employeesEmail;
                                            //         break;
                                            //     }
                                        }
                                        const mailHtml = mergeDataField(item[0][0].message, getMergeFieldMappingVendorOffer(emailData));
                                        const mailOptions = {
                                            from: item[0][0].fromEmail,
                                            to,
                                            subject: replaceAll(item[0][0].subject, "[OrderID]", emailData.orderId),
                                            text: `Send Email`,
                                            html: mailHtml
                                        };
                                        sendMailCore(mailOptions);
                                    }
                                });
                            }
                        });
                    reply({
                        data: result
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    mobileAcceptOffers(request, reply) {
        const signerOffer = request.payload;
        const getEmailDataSql = `
            SELECT 	signer_offer.OfferID AS offerID,
				signer_offer.OrderID AS orderId,
                employees.Email AS employeesEmail,
				loan_type.LoanType AS loanType,
                \`order\`.AptDateTime AS aptDateTime,
                \`order\`.AptUTC AS aptUTC,
				\`order\`.City AS city,
				\`order\`.Zip AS zip,
                \`order\`.BrokerIdNum AS brokerIdNum,
                \`order\`.LastName AS borrowerLastName,
                 69.1*sqrt(POWER((signer.Lat - \`order\`.Lat), 2) + 0.6*POWER((signer.\`Long\` - \`order\`.\`Long\`), 2)) AS distance,
				signer.Mobile AS vendorMobile,
				signer.Email AS vendorEmail,
				signer.FirstName AS vendorFirstName,
				signer.LastName AS vendorLastName,
                agent.Email AS agentEmail,
                agent.FullName AS agentFullName,
                signer_offer.OfferAmount AS offerAmount,
				signer_offer.OfferStatus AS offerStatus
            FROM signer_offer
		    INNER JOIN \`order\` ON signer_offer.OrderID = \`order\`.OrderID AND signer_offer.OfferID = ${signerOffer.offerID}
            INNER JOIN loan_type ON \`order\`.LoanType = loan_type.LoanTypeID
		    INNER JOIN signer ON signer_offer.SignerId = signer.SignerId
            LEFT JOIN employees ON signer_offer.RepId = employees.RepId
            LEFT JOIN agent ON \`order\`.AgentId = agent.AgentId;`;

        SignerOffer
            .where({
                OrderID: signerOffer.orderId,
                SignerId: signerOffer.signerId
            })
            .save({
                OfferStatus: signerOffer.offerStatus
            }, {
                    method: "update"
                })
            .then(async result => {
                if (result !== null) {
                    //aceppt offer
                    if (signerOffer.offerStatus === "A") {
                        //assign vendor to Order
                        await new Promise((resolve) =>
                            Order
                                .where({
                                    OrderID: signerOffer.orderId
                                })
                                .save({
                                    SignerId: signerOffer.signerId,
                                    ProgressId: ORDER_PROGRESS_ID.ASSIGNED_TO_VENDOR,
                                    FilledDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
                                }, {
                                        method: "update"
                                    })
                                .then(() => {
                                    resolve();
                                })
                                .catch((error) => {
                                    reply(Boom.badRequest(error));
                                })
                        );
                        //save progress log
                        await new Promise((resolve) =>
                            new OrderProgressLog()
                                .save({
                                    OrderId: signerOffer.orderId,
                                    UsersId: signerOffer.userId,
                                    Activity: `${signerOffer.userName} is assigned to order #${signerOffer.orderId}`,
                                    DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                                    IsPrivate: 0,
                                    ProgressType: 1
                                }, {
                                        method: "insert"
                                    })
                                .then(() => {
                                    resolve();
                                })
                                .catch((error) => {
                                    reply(Boom.badRequest(error));
                                })
                        );
                        //save vendor history
                        await new Promise((resolve) =>
                            new SignerHistory()
                                .save({
                                    OrderId: signerOffer.orderId,
                                    SignerId: signerOffer.signerId,
                                    Status: "Assigned",
                                    HistoryDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
                                }, {
                                        method: "insert"
                                    })
                                .then(() => {
                                    resolve();
                                })
                                .catch((error) => {
                                    reply(Boom.badRequest(error));
                                })
                        );
                        //send mail
                        let emailData = {};
                        await new Promise((resolve) =>
                            Bookshelf.knex.raw(getEmailDataSql)
                                .then((getEmailDataResult) => {
                                    if (getEmailDataResult !== undefined) {
                                        emailData = getEmailDataResult[0][0];
                                    }
                                    resolve();
                                })
                        );

                        const rawSqlEmploy = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor has been asign schedulers';`));
                        const rawSqlVendor = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor offer accept success';`));
                        const rawSqlAgent = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor has been asign agent';`));

                        Promise.all([rawSqlEmploy, rawSqlVendor, rawSqlAgent])
                            .then(values => {
                                if (values !== null) {
                                    let subject = "";
                                    let to = "";

                                    values.forEach((item, index) => {
                                        if (item !== null) {
                                            switch (index) {
                                                case 0:
                                                    {
                                                        subject = replaceAll(item[0][0].subject, "[orderID]", emailData.orderId);
                                                        to = emailData.employeesEmail;
                                                        break;
                                                    }
                                                case 1:
                                                    {
                                                        subject = item[0][0].subject;
                                                        to = emailData.vendorEmail;
                                                        break;
                                                    }
                                                case 2:
                                                    {
                                                        subject = replaceAll(item[0][0].subject, "[orderID]", emailData.orderId);
                                                        to = emailData.agentEmail;
                                                        break;
                                                    }
                                            }
                                            let html = item[0][0].message;

                                            html = replaceAll(html, `[aptDateTime]`, hasStringValue(emailData.aptDateTime) ? `${moment(emailData.aptDateTime).utc().format("MM-DD-YYYY h:mm A")} ${getUTCName(emailData.aptUTC)}` : "");

                                            const mailtHtml = mergeDataField(html, getMergeFieldMappingVendorOffer(emailData));
                                            const mailOptions = {
                                                from: item[0][0].fromEmail,
                                                to,
                                                subject,
                                                text: `Send Email`,
                                                html: mailtHtml
                                            };

                                            sendMailCore(mailOptions);
                                        }
                                    });
                                }
                            });
                        reply({
                            isSuccess: true
                        });
                    } else {
                        //missing offer
                        if (signerOffer.valueExistVendorOffer === 2 || signerOffer.valueExistVendorOffer === 3) {
                            //send mail
                            let emailData = {};
                            await new Promise((resolve) =>
                                Bookshelf.knex.raw(getEmailDataSql)
                                    .then((getEmailDataResult) => {
                                        if (getEmailDataResult !== undefined) {
                                            emailData = getEmailDataResult[0][0];
                                        }
                                        resolve();
                                    })
                            );
                            const rawSql = `select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor accept missing vendor';`;

                            Bookshelf.knex.raw(rawSql)
                                .then((message) => {
                                    let html = message[0][0].message;

                                    html = replaceAll(html, `[aptDateTime]`, hasStringValue(emailData.aptDateTime) ? `${moment(emailData.aptDateTime).utc().format("MM-DD-YYYY h:mm A")} ${getUTCName(emailData.aptUTC)}` : "");

                                    const mailVendorHtml = mergeDataField(html, getMergeFieldMappingVendorOffer(emailData));
                                    const mailVendorOptions = {
                                        from: message[0][0].fromEmail,
                                        to: emailData.vendorEmail,
                                        subject: message[0][0].subject,
                                        text: `Send Email`,
                                        html: mailVendorHtml
                                    };
                                    sendMailCore(mailVendorOptions);
                                });
                        }
                        reply({
                            isSuccess: true
                        });
                    }
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getVendorFeeByOrderId(request, reply) {
        const { orderId } = request.query;
        const rawSql = `SELECT of.FeeDescripID, of.SignerFee,bf.FeeDescription,bf.IsAdditionalFee FROM order_fee of
		INNER JOIN broker_fee bf ON bf.FeeId = of.FeeDescripID 	WHERE of.OrderID = ${orderId};`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                result[0].map((item) => {
                    item.IsAdditionalFee = bufferToBoolean(item.IsAdditionalFee);
                });
                reply({
                    data: result[0]
                });
                return;
            }
            reply({ isSuccess: false, message: "No record found!" });
            return;
        }).catch(error => {
            reply(Boom.badRequest(error));
            return;
        });
    }
}

export default new VendorOfferController();