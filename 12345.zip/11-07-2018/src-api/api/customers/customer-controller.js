import Bookshelf from "../../db/database";
import Boom from "boom";
import Customer from "../../db/model/customer";
import LoanType from "../../db/model/loan-type";
import SubLoanType from "../../db/model/sub-loan-types";
import CustomerProductType from "../../db/model/customer-product-type";
import CustomerSubProductType from "../../db/model/customer-subproduct-type";
import TrainingPrograms from "../../db/model/training-programs";
import CustomerTrainingReq from "../../db/model/customer-training-req";
import CustomerDonotuse from "../../db/model/customer-donotuse";
import { handleSingleQuote } from "../../helper/common-helper";

class CustomerController {
	constructor() { }

	getCustomerById(request, reply) {
		const { customerId, brokerId, industryId } = request.query;
		const rawSqlIndustry = `select industryId, description from industry order by description`;
		const getIndustry = Promise.resolve(Bookshelf.knex.raw(rawSqlIndustry));
		const getTraining = TrainingPrograms.query({ where: { Inactive: false }, orWhere: { Inactive: null } }).orderBy("Title").fetchAll();
		let promiseData;

		if (customerId !== 0 || customerId !== undefined) {
			const getCustomer = Promise.resolve(Customer.where({ customerId, brokerId }).fetch(
				{
					columns: ["CustomerId", "Name", "Email", "BrokerId", "ReqRating", "ReqExperienceNumber", "industryId"]
				}
			));
			const rawSqlProductType = `select ProductType from customer_product_type cpt inner join loan_type l on cpt.ProductType=l.LoanTypeId where CustomerId =${customerId};`;
			const getProductTypeByCustomerId = Promise.resolve(Bookshelf.knex.raw(rawSqlProductType));
			const rawSql = `select SubProductType from customer_subproduct_type cpt inner join loan_type_sub l on cpt.SubProductType=l.LoanTypeId where CustomerId =${customerId};`;
			const getSubProductTypeByCustomerId = Promise.resolve(Bookshelf.knex.raw(rawSql));
			const rawSqlProgram = `SELECT c.ProgramId FROM customer_training_req c inner join training_programs t on c.ProgramId=t.ProgramId where c.CustomerId=${customerId};`;
			const getProgramByCustomerId = Promise.resolve(Bookshelf.knex.raw(rawSqlProgram));
			const rawSqlLoanTypes = `SELECT l.LoanTypeId, l.LoanType from industry_transaction_fees i inner join loan_type l on i.LoanTypeId=l.LoanTypeId where i.industryId =${industryId} and i.IsAdditionalFee = 0 order by LoanType`;
			const getLoanTypes = Promise.resolve(Bookshelf.knex.raw(rawSqlLoanTypes));

			promiseData = Promise.all([getIndustry, getTraining, getCustomer, getProductTypeByCustomerId, getSubProductTypeByCustomerId, getProgramByCustomerId, getLoanTypes]);
		} else {
			promiseData = Promise.all([getIndustry, getTraining]);
		}

		promiseData
			.then(values => {
				const data = {};

				if (values !== null) {
					values.forEach((item, index) => {
						if (item !== null) {
							switch (index) {
								case 0:
									data.industryList = item[0];
									break;
								case 1:
									data.trainingPrograms = item;
									break;
								case 2:
									data.customer = item;
									break;
								case 3:
									data.productType = item[0];
									break;
								case 4:
									data.subProductType = item[0];
									break;
								case 5:
									data.programs = item[0];
									break;
								case 6:
									data.loanType = item[0];
									break;
							}
						}
					});

					let loanTypes = "";

					data.productType.map((item) => {
						if (loanTypes === "") {
							loanTypes = item.ProductType;
						} else {
							loanTypes = `${loanTypes},${item.ProductType}`;
						}
					});
					if (loanTypes !== "") {
						const rawSql = `SELECT lts.SubTypeId, lts.SubLoanType FROM loan_type_sub lts inner join loan_type lt on lts.LoanTypeId=lt.LoanTypeId where lt.LoanTypeId in (${loanTypes})`;

						Bookshelf.knex.raw(rawSql)
							.then((result) => {
								if (result !== null) {
									data.subLoanType = result[0];

									reply(data);
								}
							}).catch((error) => {
								Boom.badRequest(error);
							});
					} else {
						reply(data);
					}
				}
			}).catch(err => {
				reply(Boom.badRequest(err));
			});
	}

	getSubLoanTypes(request, reply) {
		const loanTypeId = request.query;
		SubLoanType.where(loanTypeId).fetchAll().then().catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getCustomers(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			customerID,
			customerName,
			brokerId
		} = request.query;

		Bookshelf.knex.raw(`call GetCustomers('${sortColumn}',${sortDirection},${page},
		${itemPerPage},'${customerID}','${handleSingleQuote(customerName)}','${brokerId}')`)
			.then((result) => {
				if (result !== null) {
					const data = {
						customer: result[0][0],
						totalRecords: result[0][1][0].TotalRecords
					};

					reply(data);
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	deleteCustomer(request, reply) {
		const { customerId } = request.query;

		Customer.where({ CustomerId: customerId }).save({ Inactive: true }, { method: "update" }).then((result) => {
			if (result !== null) {
				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	addCustomer(request, reply) {
		const customerGeneral = request.payload;
		new Customer().save(customerGeneral.customer, { method: "insert" }).then((result) => {
			if (result !== null) {
				CustomerProductType.where({ CustomerId: result.attributes.id }).destroy().then(() => {
					customerGeneral.productType.map((item) => {
						item.CustomerId = result.attributes.id;
						new CustomerProductType().save(item, { method: "insert" }).then();
					});
				});
				CustomerSubProductType.where({ CustomerId: result.attributes.id }).destroy().then(() => {
					customerGeneral.subProductType.map((item) => {
						item.CustomerId = result.attributes.id;
						new CustomerSubProductType().save(item, { method: "insert" }).then();
					});
				});
				CustomerTrainingReq.where({ CustomerId: result.attributes.id }).destroy().then(() => {
					customerGeneral.programs.map((item) => {
						item.CustomerId = result.attributes.id;
						new CustomerTrainingReq().save(item, { method: "insert" }).then();
					});
				});

				reply(result.attributes.id);
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	updateCustomer(request, reply) {
		const customerGeneral = request.payload;
		Customer.where({ CustomerId: customerGeneral.customer.CustomerId }).save(customerGeneral.customer, { method: "update" }).then((result) => {
			if (result !== null) {
				const customerId = customerGeneral.customer.CustomerId;
				CustomerProductType.where({ CustomerId: customerId }).destroy().then(() => {
					customerGeneral.productType.map((item) => {
						item.CustomerId = customerId;
						new CustomerProductType().save(item, { method: "insert" }).then();
					});
				});
				CustomerSubProductType.where({ CustomerId: customerId }).destroy().then(() => {
					customerGeneral.subProductType.map((item) => {
						item.CustomerId = customerId;
						new CustomerSubProductType().save(item, { method: "insert" }).then();
					});
				});
				CustomerTrainingReq.where({ CustomerId: customerId }).destroy().then(() => {
					customerGeneral.programs.map((item) => {
						item.CustomerId = customerId;
						new CustomerTrainingReq().save(item, { method: "insert" }).then();
					});
				});

				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getAvailableSigner(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			whereText,
			brokerId,
			customerId
		} = request.query;
		Bookshelf.knex.raw(`call GetAvailableVendorCustomer('${sortColumn}',${sortDirection},${page},
			${itemPerPage},'${handleSingleQuote(whereText)}',${brokerId},${customerId})`)
			.then((result) => {
				if (result !== null) {
					reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	getBlackListSigner(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			customerId
		} = request.query;
		Bookshelf.knex.raw(`call GetBlackListSignerCustomer('${sortColumn}',${sortDirection},${page},
			${itemPerPage},${customerId})`)
			.then((result) => {
				if (result !== null) {
					reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	updateBlackListSigner(request, reply) {
		const data = request.payload;
		const dateTimeNow = (new Date((new Date((new Date(new Date())).toISOString())).getTime() - ((new Date()).getTimezoneOffset() * 60000))).toISOString().slice(0, 19).replace("T", " ");
		const blackList = data.blackList;
		let count = 0;
		blackList.forEach(element => {
			const newDoNotUse = new CustomerDonotuse({ Timestamp: dateTimeNow, Comment: element.Comment, SignerId: element.SignerId, CustomerId: element.CustomerId });
			newDoNotUse.save(null, { method: "insert" }).then((result) => {
				count++;
				if (result !== null && count === blackList.length) {
					reply({ isSuccess: true });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		});
	}

	updateWhiteListSigner(request, reply) {
		const data = request.payload;
		const whiteList = data.whiteList;
		CustomerDonotuse.where("Id", "in", whiteList).destroy().then((result) => {
			if (result !== null) {
				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	checkExistOrderAssociated(request, reply) {
		const { customerId } = request.query;

		const rawSql = "select count(c.CustomerId) as orders from customers c inner join `order` o on c.CustomerId = o.CustomerId where c.CustomerId=";

		Bookshelf.knex.raw(rawSql.concat(customerId)).then((result) => {
			if (result !== null) {
				const isExist = result[0][0].orders > 0;
				reply({ isExist });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}
}

export default new CustomerController();