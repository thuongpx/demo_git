import Boom from "boom";
import Bookshelf from "../../db/database";

class ClientServicesConfigLogController {
    getConfigLogByConfigId(request, reply) {
        const { configId } = request.query;

        const rawSql = `call GetClientServicesConfigLog(${+configId})`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        configLogs: result[0][0]
                    });
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }
}

export default new ClientServicesConfigLogController();