import ManagerInternalUserController from "../manage-internal-user/manage-internal-user-controller";

const routes = [{
    path: "/managerinternaluser/getAllManagerInternalUser",
    method: "GET",
    handler: ManagerInternalUserController.getAllManagerInternalUser
},
{
    path: "/managerinternaluser/getManagerInternalUser",
    method: "GET",
    handler: ManagerInternalUserController.getManagerInternalUser
},
{
    path: "/managerinternaluser/getUsersByRepId",
    method: "GET",
    handler: ManagerInternalUserController.getUsersByRepId
},
{
    path: "/managerinternaluser/getRoleName",
    method: "GET",
    handler: ManagerInternalUserController.getRoleName
},
{
    path: "/managerinternaluser/addManagerInternalUser",
    method: "POST",
    handler: ManagerInternalUserController.addManagerInternalUser
},
{
    path: "/managerinternaluser/updateEmployees",
    method: "POST",
    handler: ManagerInternalUserController.updateEmployees
},
{
    path: "/managerinternaluser/updateActive",
    method: "POST",
    handler: ManagerInternalUserController.updateActive
},
{
    path: "/managerinternaluser/deleteManagerInternalUser",
    method: "POST",
    handler: ManagerInternalUserController.deleteManagerInternalUser
},
{
    path: "/managerinternaluser/getUserIdByRepId",
    method: "GET",
    handler: ManagerInternalUserController.getUserIdByRepId
}];
export default routes;
