import SmsController from "./sms-controller";

const routes = [{
    path: "/sms/sendSms",
    method: "POST",
    handler: SmsController.sendSms
}];

export default routes;