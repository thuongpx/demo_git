import Boom from "boom";
import Payment from "../../db/model/payments";
import Gateway from "../../lib/braintree-gateway";
import moment from "moment";

import { hasStringValue } from "../../helper/common-helper";

class PaymentController {
    constructor() { }

    async removeBraintreeCustomer(request, reply) {
        const {
            customerId
        } = request.payload;

        await Gateway.customer.delete(customerId);

        reply({
            isSuccess: true
        });
    }

    removePaymentMethod(request, reply) {
        const {
            paymentId
        } = request.payload;

        if (!hasStringValue(paymentId)) {
            reply({ isSuccess: false, error: "Invalid payment id" });
            return;
        }

        // retrieve customer id from payment id
        Payment.where({ paymentId }).fetch({
            columns: ["CustomerId"]
        }).then(async (payment) => {
            // payment is existing
            const { CustomerId } = payment.attributes;

            // remove from braintree
            await Gateway.customer.delete(CustomerId);

            // remove from database
            await Payment.where({ paymentId }).destroy();

            reply({
                isSuccess: true
            });
        }).catch(err => {
            reply(Boom.badRequest(err));
        });
    }

    requestPaymentToken(request, reply) {
        const {
            nonce,
            description,
            cardType,
            type
        } = request.payload;

        Gateway.customer
            .create({ paymentMethodNonce: nonce })
            .then((result) => {
                if (result && result.success) {
                    const customerId = result.customer.id;
                    const { token, uniqueNumberIdentifier, imageUrl, expirationDate } = result.customer.paymentMethods[0];

                    // save token to database
                    new Payment().save({
                        CustomerId: customerId,
                        Token: token,
                        UniqueNumberIdentifier: uniqueNumberIdentifier,
                        Description: description,
                        CardType: cardType,
                        Type: type,
                        ImageUrl: imageUrl,
                        ExpirationDate: expirationDate,
                        DateCreated: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                        DateModified: moment().utc().format("YYYY-MM-DD HH:mm:ss")
                    }, { method: "insert" }).then((data) => {
                        if (data) {
                            const { Description, CardType, ImageUrl, ExpirationDate, id } = data.attributes;

                            reply({
                                isSuccess: true,
                                payment: {
                                    cardType: CardType,
                                    description: Description,
                                    imageUrl: ImageUrl,
                                    expirationDate: ExpirationDate,
                                    paymentId: id
                                }
                            });
                            return;
                        }

                        reply({ isSuccess: false });
                        return;
                    }).catch((error) => {
                        reply(Boom.badRequest(error));
                        return;
                    });
                }
            })
            .catch(err => {
                console.log(JSON.stringify(err));
                reply(Boom.badRequest(`Braintree: ${err.name}`));
                return;
            });
    }
}

export default new PaymentController();