DROP PROCEDURE IF EXISTS `alter_table_broker_fee`;

DELIMITER $$
CREATE PROCEDURE `alter_table_broker_fee` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_fee' AND 
                            COLUMN_NAME = 'IndustryId') THEN
	BEGIN
		ALTER TABLE `broker_fee` 
		ADD COLUMN `IndustryId` INT NULL;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_broker_fee();

DROP PROCEDURE IF EXISTS `alter_table_broker_fee`;
