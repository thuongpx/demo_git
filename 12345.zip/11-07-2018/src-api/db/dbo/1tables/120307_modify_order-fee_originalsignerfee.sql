DROP PROCEDURE IF EXISTS `alter_table_order_fee`;

DELIMITER $$
CREATE PROCEDURE `alter_table_order_fee` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'order_fee' AND 
                            COLUMN_NAME = 'OriginalSignerFee') THEN
	BEGIN
		ALTER TABLE `order_fee` 
		ADD COLUMN `OriginalSignerFee` DECIMAL(19,4) NULL AFTER `TenantId`;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_order_fee();

DROP PROCEDURE IF EXISTS `alter_table_order_fee`;