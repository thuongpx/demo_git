CREATE TABLE IF NOT EXISTS `customer_vendor_specialty` (
  `CustomerId` INT NOT NULL,
  `CatId` INT NOT NULL
  );