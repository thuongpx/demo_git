DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_detail' AND 
                            COLUMN_NAME = 'DownloadFormat') THEN
	BEGIN
		ALTER TABLE `broker_detail` 
		MODIFY COLUMN `DownloadFormat` VARCHAR(100);
	END;
    END IF;    
END$$

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;