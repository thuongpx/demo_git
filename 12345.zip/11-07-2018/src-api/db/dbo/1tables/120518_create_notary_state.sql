-- created by AnNV2

CREATE TABLE IF NOT EXISTS `notary_state` (
    `SignerId` INT NULL,
    `State` VARCHAR(2) NULL
)