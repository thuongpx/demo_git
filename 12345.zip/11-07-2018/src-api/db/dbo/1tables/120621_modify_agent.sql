DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'agent' AND 
                            COLUMN_NAME = 'ProfilePicture') THEN
	BEGIN
		ALTER TABLE `agent` 
		ADD COLUMN `ProfilePicture` longblob DEFAULT NULL;
	END;
    END IF;
    
    SET SQL_SAFE_UPDATES = 0;
        
    SET SQL_SAFE_UPDATES = 1;
END$$

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;