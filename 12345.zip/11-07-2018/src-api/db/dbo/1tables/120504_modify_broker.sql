DROP PROCEDURE IF EXISTS `alter_table_broker`;

DELIMITER $$
CREATE PROCEDURE `alter_table_broker` ()
BEGIN
	-- Additional Contact FirstName
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'AdditionalContactFirstName') THEN
	BEGIN
		ALTER TABLE `broker` 
		ADD COLUMN `AdditionalContactFirstName` VARCHAR(50);
	END;
    END IF;
    
    -- Additional Contact Last Name
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'AdditionalContactLastName') THEN
	BEGIN
		ALTER TABLE `broker` 
		ADD COLUMN `AdditionalContactLastName` VARCHAR(50);
	END;
    END IF;
    
    -- Team Name
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'TeamName') THEN
	BEGIN
		ALTER TABLE `broker` 
		ADD COLUMN `TeamName` VARCHAR(50);
	END;
    END IF;
    
    -- How many transactions do you do monthly
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'TransactionOfMonth') THEN
	BEGIN
		ALTER TABLE `broker` 
		ADD COLUMN `TransactionOfMonth` INT;
	END;
    END IF;
    
    -- How many transactions a month do you plan on sending to The Closing Exchange
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker' AND 
                            COLUMN_NAME = 'TransactionToTCE') THEN
	BEGIN
		ALTER TABLE `broker` 
		ADD COLUMN `TransactionToTCE` INT;
	END;
    END IF;
END$$

DELIMITER ;

call alter_table_broker();

DROP PROCEDURE IF EXISTS `alter_table_broker`;

