CREATE TABLE IF NOT EXISTS `industry_transaction` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `IndustryId` INT NULL,
  `LoanTypeId` INT NULL,
  PRIMARY KEY (`Id`));
