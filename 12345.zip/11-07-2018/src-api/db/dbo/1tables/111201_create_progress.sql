CREATE TABLE IF NOT EXISTS `progress` (
    `ProgressId` INT(11) NOT NULL AUTO_INCREMENT,
    `ProgressDescription` VARCHAR(40),
    PRIMARY KEY (`ProgressId`)
)