CREATE TABLE IF NOT EXISTS `tbltokens` (
	`Token` VARCHAR(50),
	`Expires` DATETIME
);
