DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable` ()
BEGIN
	-- Change column Name
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_detail' AND 
                            COLUMN_NAME = 'Inv') THEN
	BEGIN
		ALTER TABLE `broker_detail` 
		CHANGE COLUMN `Inv` `APInv` VARCHAR(20);
	END;
    END IF;
    
	-- drop column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_detail' AND 
                            COLUMN_NAME = 'APCellPhone') THEN
	BEGIN
		ALTER TABLE `broker_detail` 
		ADD COLUMN `APCellPhone` VARCHAR(15);
	END;
    END IF;

	-- drop column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_detail' AND 
                            COLUMN_NAME = 'APAfterHourPhone') THEN
	BEGIN
		ALTER TABLE `broker_detail` 
		ADD COLUMN `APAfterHourPhone` VARCHAR(15);
	END;
    END IF;

	-- drop column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_detail' AND 
                            COLUMN_NAME = 'APAfterHourExt') THEN
	BEGIN
		ALTER TABLE `broker_detail` 
		ADD COLUMN `APAfterHourExt` VARCHAR(10);
	END;
    END IF;

	-- drop column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_detail' AND 
                            COLUMN_NAME = 'APAddress') THEN
	BEGIN
		ALTER TABLE `broker_detail` 
		ADD COLUMN `APAddress` VARCHAR(50);
	END;
    END IF;

	-- drop column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_detail' AND 
                            COLUMN_NAME = 'APSuite') THEN
	BEGIN
		ALTER TABLE `broker_detail` 
		ADD COLUMN `APSuite` VARCHAR(50);
	END;
    END IF;

	-- drop column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_detail' AND 
                            COLUMN_NAME = 'APCity') THEN
	BEGIN
		ALTER TABLE `broker_detail` 
		ADD COLUMN `APCity` VARCHAR(50);
	END;
    END IF;

	-- drop column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_detail' AND 
                            COLUMN_NAME = 'APZip') THEN
	BEGIN
		ALTER TABLE `broker_detail` 
		ADD COLUMN `APZip` VARCHAR(5);
	END;
    END IF;

	-- drop column
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'broker_detail' AND 
                            COLUMN_NAME = 'APState') THEN
	BEGIN
		ALTER TABLE `broker_detail` 
		ADD COLUMN `APState` VARCHAR(15);
	END;
    END IF;
END$$

DELIMITER ;

call AlterTable();

DROP PROCEDURE IF EXISTS `AlterTable`;