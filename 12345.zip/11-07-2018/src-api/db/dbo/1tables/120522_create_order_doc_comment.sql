CREATE TABLE IF NOT EXISTS `order_doc_comment` (
  `CommentId` INT NOT NULL AUTO_INCREMENT,
  `DocId` INT NOT NULL,
  `CommentBy` INT NOT NULL,
  `Comment` VARCHAR(250) NULL,
  `CommentDate` DATETIME NULL,
  PRIMARY KEY (`CommentId`)
);