DROP function IF EXISTS `IsPublishedProgram`;

DELIMITER $$
CREATE FUNCTION `IsPublishedProgram`(courseId int(11)) RETURNS bit(1)
BEGIN
DECLARE isPublished BIT;    
	SET isPublished = 0;
    
	IF courseId IS NOT NULL THEN
    BEGIN
        IF EXISTS (SELECT c.CourseId FROM training_courses AS c
					INNER JOIN training_program_courses AS pc ON c.CourseId = pc.CourseId
                    inner join training_programs p on pc.ProgramId = p.ProgramId
					WHERE c.CourseId = courseId and p.IsPublished = 1) THEN
			SET isPublished = 1;
		END IF;
    END;
    END IF;
    
	RETURN isPublished;
END$$

DELIMITER ;