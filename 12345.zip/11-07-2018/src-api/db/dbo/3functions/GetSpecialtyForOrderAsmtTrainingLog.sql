DROP FUNCTION IF EXISTS `GetSpecialtyForOrderAsmtTrainingLog`;

DELIMITER $$

CREATE FUNCTION `GetSpecialtyForOrderAsmtTrainingLog`(listId VARCHAR(1000)) RETURNS VARCHAR(5000)
BEGIN
    DECLARE returnData VARCHAR(5000);
    
    -- sum of additional fee
    select group_concat(vc.CatName) into returnData from vendor_categories vc where FIND_IN_SET(vc.CatId, listId) > 0;
    
    
    RETURN returnData;
END$$

DELIMITER ;