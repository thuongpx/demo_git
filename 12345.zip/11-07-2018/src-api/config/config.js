/* eslint-disable no-console */
import dbConfig from "./db.config";
import envConfig from "./env.config";
import mailConfig from "./mail.config";
import braintreeConfig from "./braintree.config";
import fileConfig from "./file.config";
import awsConfig from "./prod.config";
import tawkToConfig from "./tawkto.config";

console.log(`>> database configurations`);
console.log(`--- host: ${dbConfig.host}`);
console.log(`--- user: ${dbConfig.user}`);
console.log(`--- database: ${dbConfig.database}`);

console.log(`>> mail configurations`);
console.log(`--- host: ${mailConfig.host}`);
console.log(`--- port: ${mailConfig.port}`);
console.log(`--- timeout: ${mailConfig.timeout}`);

module.exports = {
    application: {
        host: envConfig.host,
        port: envConfig.port,
        secretKey: envConfig.secretKey
    },
    database: {
        host: dbConfig.host,
        user: dbConfig.user,
        password: dbConfig.password,
        database: dbConfig.database
    },
    mail: {
        host: mailConfig.host,
        port: mailConfig.port,
        timeout: mailConfig.timeout,
        user: mailConfig.user,
        pass: mailConfig.pass,
        form: mailConfig.form,
        webOrders: mailConfig.webOrders,
        faxBacks: mailConfig.faxBacks
    },
    braintree: braintreeConfig,
    file: {
        serverPath: fileConfig.serverPath,
        fileExtensions: fileConfig.fileExtensions,
        maxBytes: fileConfig.maxBytes,
        maxBytesSignerDoc: fileConfig.maxBytesSignerDoc
    },
    aws: {
        apiAccessKey: awsConfig.apiAccessKey,
        apiSecretKey: awsConfig.apiSecretKey,
        snsArn: awsConfig.snsArn,
        snsArnEnv: awsConfig.snsArnEnv
    },
    tawkTo: tawkToConfig
};