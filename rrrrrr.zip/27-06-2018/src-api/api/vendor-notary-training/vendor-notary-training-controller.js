import Bookshelf from "../../db/database";
import Boom from "boom";
import {
    handleSingleQuote,
    bufferToBoolean
} from "../../helper/common-helper";

class NotaryTraning {
    constructor() {}
    getlistRegisteredPrograms(request, reply) {
        const {
            searchValue,
            userId
        } = request.query;
        const newSearchValue = (searchValue === "" || searchValue === undefined) ? "" : handleSingleQuote(searchValue);
        const rawSql = `SELECT distinct vp.ProgramId, tp.Title, tp.Description, vp.IsComplete
        FROM vendor_registered_programs vp, training_programs tp
        WHERE vp.VendorId = ${userId} and tp.ProgramId = vp.ProgramId and (Title LIKE '%${newSearchValue}%' or Description LIKE '%${newSearchValue}%') order by Title`;
        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    const data = result[0];
                    data.map(item => {
                        item.IsComplete = bufferToBoolean(item.IsComplete);
                    });
                    reply({
                        isSuccess: true,
                        listRegisteredProgram: result[0]
                    });
                    return;
                }
                reply({
                    isSuccess: false,
                    isNotFound: true
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
    getlistAllPrograms(request, reply) {
        const {
            searchValue,
            userId
        } = request.query;
        const newSearchValue = (searchValue === "" || searchValue === undefined) ? "" : handleSingleQuote(searchValue);
        const rawSql = `SELECT ProgramId, Title, Description
        FROM  training_programs 
        WHERE ForVendor = 1 and Inactive = 0 and (Title LIKE '%${newSearchValue}%' or Description LIKE '%${newSearchValue}%') and ProgramId NOT IN (select ProgramId from vendor_registered_programs where vendorId=${userId}) 
        group by ProgramId
        order by Title;`;
        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true,
                        listAllProgram: result[0]
                    });
                    return;
                }
                reply({
                    isSuccess: false,
                    isNotFound: true
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
    getListCourseandTestbyProgramId(request, reply) {
        const {
            programId
        } = request.query;
        const rawSql = `SELECT distinct tc.CourseId, ti.TestId, vcr.StartDate as courcestartdate, vcr.EndDate as courseenddate, vcr.IsComplete as coursestatus,
        vtr.StartDate as teststartdate, vtr.EndDate as testenddate, vtr.Passed as teststatus
        FROM tce_dev2.vendor_registered_programs vr
        INNER JOIN training_program_courses tpc on vr.ProgramId = tpc.ProgramId
        INNER JOIN training_program_test tpt on vr.ProgramId = tpt.ProgramId
        INNER JOIN training_courses tc on tc.CourseId = tpc.CourseId
        INNER JOIN vendor_courses_result vcr on vcr.CourseId = tc.CourseId
        INNER JOIN vendor_test_result vtr on vtr.TestId = tpt.TestId
        INNER JOIN test_info ti on ti.TestId = tpt.TestId
        WHERE vr.ProgramId = ${programId}`;
        Bookshelf.knex.raw(rawSql)
            .then(result => {
                reply({
                    listCourseandTestinProgram: result[0]
                });
            }).catch((error) => {
                reply(`"Not found record: " + ${error}`);
            });
    }

    getListRecentCourses(request, reply) {
        const {
            vendorId
        } = request.query;
        const rawSql = `select c.CourseId, c.Title, cr.StartDate, cr.EndDate, cr.LastViewedDate, cr.IsComplete from training_courses c
                        inner join vendor_courses_result cr on c.CourseId = cr.CourseId
                        where cr.VendorId = ${vendorId} and c.Inactive = 0
                        ORDER BY cr.LastViewedDate desc
                        limit 10;`;
        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                const data = result[0];
                data.map((item) => {
                    item.IsComplete = bufferToBoolean(item.IsComplete);
                });
                reply({
                    isSuccess: true,
                    isNotFound: false,
                    listRecentCourses: result[0]
                });
            }
            reply({
                isSuccess: false,
                isNotFound: true
            });
        }).catch((error) => {
            reply(`"Not found record : " + ${error}`);
        });
    }

    getListLearningPath(request, reply) {
        const rawSql = `SELECT lp.LPID learningPathId, lp.LPName learningPathName, p.Title, p.ForVendor, p.Inactive, p.IsPublished FROM training_learning_path lp 
        inner join training_lp_programs lpp on lp.LPID = lpp.LPID
        inner join training_programs p on lpp.ProgramId = p.ProgramId
        where p.ForVendor = 1 and p.Inactive = 0 and p.IsPublished = 1;`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                const data = result[0];
                data.map((item) => {
                    item.ForVendor = bufferToBoolean(item.ForVendor);
                    item.Inactive = bufferToBoolean(item.Inactive);
                    item.IsPublished = bufferToBoolean(item.IsPublished);
                });
                reply({
                    isSuccess: true,
                    isNotFound: false,
                    listLearningPath: result[0]
                });
            }
            reply({
                isSuccess: false,
                isNotFound: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getListOfPopularPrograms(request, reply) {
        const rawSql = `select v.VendorId, v.ProgramId, tp.Title, tp.Description 
                        from vendor_registered_programs v, training_programs tp
                        where v.ProgramId = tp.ProgramId and tp.Inactive = 0
                        group by ProgramId 
                        ORDER BY COUNT(v.ProgramId) DESC
                        limit 10;`;
        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                reply({
                    isSuccess: true,
                    isNotFound: false,
                    listPopularProgram: result[0]
                });
            }
            reply({
                isSuccess: false,
                isNotFound: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    registerPopularProgram(request, reply) {
        const {
            vendorId,
            programId
        } = request.payload;
        const rawSql = `INSERT INTO vendor_registered_programs
                        ( VendorId, ProgramId, IsComplete, RegisteredDate)
                        VALUES ( ${vendorId}, ${programId}, 0, NOW());`;
        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });

            }
            reply({
                isSuccess: false,
                isNotFound: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
    getCurrentRegisteredProgram(request, reply) {
        const {
            program,
            userId
        } = request.query;
        const rawSql = `SELECT tp.Title as title, tp.Description as description, vrp.VendorId as vendorId, IsComplete as iscomplete
        FROM training_programs tp, vendor_registered_programs vrp
        where tp.ProgramId = vrp.ProgramId and VendorId = ${userId} and tp.Inactive = 0 and ForVendor = 1 and vrp.ProgramId = ${program}
        group by tp.ProgramId order by Title`;
        Bookshelf.knex.raw(rawSql)
            .then(result => {
                const data = result[0];
                data[0].iscomplete = bufferToBoolean(data[0].iscomplete);
                if (data[0]) {
                    reply({
                        isSuccess: true,
                        currentRegisteredProgram: data[0]
                    });

                    return;
                }
                reply({
                    isSuccess: false,
                    isNotFound: true
                });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
    getCourseandTestbyProgramId(request, reply) {
        const {
            programId
        } = request.query;
        const getCourses = Promise.resolve(Bookshelf.knex.raw(`select distinct tc.CourseId, tc.Title, vcr.IsComplete, vcr.StartDate, vcr.EndDate 
        from training_courses tc, vendor_courses_result vcr 
        where tc.CourseId= vcr.CourseId 
        and tc.CourseId in 
        (SELECT CourseId FROM tce_dev2.training_program_courses where ProgramId = ${programId});`));
        const getTests = Promise.resolve(Bookshelf.knex.raw(`select distinct ti.TestId, ti.TestName, vtr.Passed, vtr.StartDate, vtr.EndDate, vtr.TestedNum, vtr.LastTesting
        from test_info ti, vendor_test_result vtr 
        where ti.TestId= vtr.TestId
        and ti.TestId in 
        (SELECT TestId FROM tce_dev2.training_program_test where ProgramId = ${programId});`));

        Promise.all([getCourses, getTests]).then(values => {
            const dataresult = {};
            if (values !== null) {
                values.forEach((item, index) => {
                    if (item !== null) {
                        switch (index) {
                            case 0:
                                dataresult.courses = item[0];
                                break;
                            case 1:
                                dataresult.tests = item[0];
                                break;
                        }
                    }

                });
                dataresult.courses.map(item => {
                    item.IsComplete = bufferToBoolean(item.IsComplete);
                });
                dataresult.isSuccess = true;
                reply(dataresult);
                return;
            } else {
                reply({
                    isSuccess: false,
                    isNotFound: true
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }
}
export default new NotaryTraning();