import QuickbookInvoiceController from "./quickbook-invoice-controller";

const routes = [{
    path: "/quickbook-invoice/exporQuickBook",
    method: "POST",
    handler: QuickbookInvoiceController.exporQuickBook
}, {
    path: "/quickbook-invoice/getQuickBooks",
    method: "POST",
    handler: QuickbookInvoiceController.getQuickBooks
}, {
    path: "/quickbook-invoice/deleteQuickBookInvoice",
    method: "POST",
    handler: QuickbookInvoiceController.deleteQuickBookInvoice
}, {
    path: "/quickbook-invoice/downloadQuickBookInvoice",
    method: "GET",
    config: { auth: false },
    handler: QuickbookInvoiceController.downloadQuickBookInvoice
}];

export default routes;