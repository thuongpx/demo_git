import Boom from "boom";
import Bookshelf from "../../db/database";

class IndustryController {
    constructor() {}

    getAllIndustry(request, reply) {
        const ralSqlGetAllIndustry = "select industryId, description, ParentId AS parentId from industry;";

        Bookshelf.knex.raw(ralSqlGetAllIndustry)
            .then(value => {
                let returnData = [];
                if (value !== null) {
                    returnData = value[0];
                }

                reply(returnData);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }
}

export default new IndustryController();