import industryController from "./industry-controller";

const routes = [{
    path: "/industry/getAllIndustry",
    method: "GET",
    config: {
        auth: false
    },
    handler: industryController.getAllIndustry
}];


export default routes;