import ClientDashboardController from "./client-dashboard-controller";

const routes = [{
    path: "/client-dashboard/getUnfilledOrderDashboard",
    method: "GET",
    handler: ClientDashboardController.getUnfilledOrderDashboard
},
{
    path: "/client-dashboard/getPendingOrderDashboard",
    method: "GET",
    handler: ClientDashboardController.getPendingOrderDashboard
},
{
    path: "/client-dashboard/getFaxbacksOrderDashboard",
    method: "GET",
    handler: ClientDashboardController.getFaxbacksOrderDashboard
}
];

export default routes;