CREATE TABLE IF NOT EXISTS `user_devices` (
	`UserDeviceId` INT(11) NOT NULL AUTO_INCREMENT,
    `UsersId` INT NOT NULL,
    `DeviceId` VARCHAR(200) NOT NULL,
    `EndpointArn` VARCHAR(1000) NULL,
    `IsSignedIn` BIT(1) NULL,
    PRIMARY KEY (`UserDeviceId`)
);