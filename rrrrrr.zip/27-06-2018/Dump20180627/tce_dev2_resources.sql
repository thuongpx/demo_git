-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `resources`
--

DROP TABLE IF EXISTS `resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resources` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Resource` varchar(50) DEFAULT NULL,
  `Title` varchar(50) DEFAULT NULL,
  `Description` varchar(2000) DEFAULT NULL,
  `Lender` bit(1) DEFAULT b'0',
  `Notary` bit(1) DEFAULT b'0',
  `MemOnly` bit(1) DEFAULT b'0',
  `Views` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resources`
--

LOCK TABLES `resources` WRITE;
/*!40000 ALTER TABLE `resources` DISABLE KEYS */;
INSERT INTO `resources` VALUES (1,'CommonAbbreviations062013.pdf','Common Abbreviations','A list of common abbreviations you may see or hear when working with mortgage documents.','\0','','',NULL),(2,'SampleDocs.pdf','Bluegreen Vacations Sample Package','Sample package for Bluegreen Vacation signings.','\0','','',NULL),(3,'LoanSigning062013.pdf','Loan Signing Process','A high level overview of the Notary Direct Loan Signing process.','\0','','',NULL),(4,'WitnessRequirements062013.pdf','Witness Requirements by state','A list of states that require witnesses for mortgage document signings. ','\0','','',NULL),(5,'StateHomePages07022013.pdf','Notary Sites by State','Links to each state\'s notary resource page.','\0','','',NULL),(6,'CommonMtgDotsWithAppendices07152013.pdf','Common Mortgage Documents (Updated)','A description of some of the more common mortgage docs found in signing packages, with signing instructions and samples. ','\0','','',NULL),(7,'Acknowledgement and Jurats.pdf','Acknowledgments and Jurats','A description of these certificates, and when and how to use them. ','\0','','',NULL),(8,'fw9.pdf','Independent Contractor W9','Notary Direct requires all of our notaries to complete and provide a copy of IRS Document W-9.  ','\0','','',NULL),(9,'AdobeUpdate.pdf','Keeping Adobe Current','Short description of steps to keep Adobe current. ','\0','','',NULL),(10,'CodeofConduct.pdf','Signing Agent Code of Conduct','Certified Signing Agent Code of Conduct, used with the permission of the Signing Professionals Workgroup.','\0','','\0',NULL),(11,'SigningAgentMemo.pdf','July 2016 Technology and Operational updates','Explanation of updates to the website profile, operational changes regarding errors, training opportunities and increased communication channels. ','\0','','',NULL),(12,'RESCISSIONCALENDAR2017.pdf','2017 Rescission Calendar','For use with Right to Cancel ','\0','','',NULL),(13,'ManualOrderForm.pdf','New Order Form','Manual Order Form','','\0','\0',NULL);
/*!40000 ALTER TABLE `resources` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-27 18:23:50
