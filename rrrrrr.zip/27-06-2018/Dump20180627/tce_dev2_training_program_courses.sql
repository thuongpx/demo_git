-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `training_program_courses`
--

DROP TABLE IF EXISTS `training_program_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_program_courses` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ProgramId` int(11) DEFAULT NULL,
  `CourseId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `programId_training_program_courses_idx` (`ProgramId`),
  KEY `courseId_training_program_courses_idx` (`CourseId`),
  CONSTRAINT `courseId_training_program_courses` FOREIGN KEY (`CourseId`) REFERENCES `training_courses` (`CourseId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `programId_training_program_courses` FOREIGN KEY (`ProgramId`) REFERENCES `training_programs` (`ProgramId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_program_courses`
--

LOCK TABLES `training_program_courses` WRITE;
/*!40000 ALTER TABLE `training_program_courses` DISABLE KEYS */;
INSERT INTO `training_program_courses` VALUES (1,101,1),(2,102,1),(3,103,1),(4,104,1),(5,105,1),(6,106,1),(7,107,1),(8,108,1),(9,101,1),(85,101,2),(86,102,2),(87,103,2),(88,104,2),(89,105,2),(90,106,2),(91,107,2),(92,108,2),(93,101,3),(94,102,3),(95,103,3),(96,104,3),(97,105,3),(98,106,3),(99,107,3),(100,108,3),(101,109,3),(102,101,4),(103,102,4),(104,103,4),(105,104,4),(106,105,4),(107,106,4),(108,107,4),(109,108,4),(110,114,1);
/*!40000 ALTER TABLE `training_program_courses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-27 18:23:53
