-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_dev2
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `biz_hours_except`
--

DROP TABLE IF EXISTS `biz_hours_except`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biz_hours_except` (
  `ExceptID` int(11) NOT NULL AUTO_INCREMENT,
  `Description` varchar(100) DEFAULT NULL,
  `ExceptDate` date DEFAULT NULL,
  `OpenTime` datetime DEFAULT NULL,
  `CloseTime` datetime DEFAULT NULL,
  `Closed` bit(1) DEFAULT NULL,
  PRIMARY KEY (`ExceptID`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biz_hours_except`
--

LOCK TABLES `biz_hours_except` WRITE;
/*!40000 ALTER TABLE `biz_hours_except` DISABLE KEYS */;
INSERT INTO `biz_hours_except` VALUES (17,'Memorial Day','2016-05-30','2016-05-30 07:00:00','2016-05-30 17:00:00',''),(18,'4th of July','2016-07-04','2016-05-30 07:00:00','2016-05-30 17:00:00',''),(19,'Labor Day','2016-09-05','2016-05-30 07:00:00','2016-05-30 17:00:00',''),(20,'Thanksgiving','2016-11-24','2016-05-30 07:00:00','2016-05-30 17:00:00',''),(21,'Christmas','2016-12-26','2016-05-30 07:00:00','2016-05-30 17:00:00',''),(30,'New Years Day','2017-01-02','2016-05-30 07:00:00','2016-05-30 17:00:00',''),(31,'Memorial Day','2017-05-29','2016-05-30 07:00:00','2016-05-30 17:00:00',''),(32,'4th of July','2017-07-04','2016-05-30 07:00:00','2016-05-30 17:00:00',''),(33,'Labor Day','2017-09-04','2016-05-30 07:00:00','2016-05-30 17:00:00',''),(34,'Thanksgiving','2017-11-23','2016-05-30 07:00:00','2016-05-30 17:00:00',''),(35,'Christmas','2017-12-25','2016-05-30 07:00:00','2016-05-30 17:00:00',''),(54,'1',NULL,NULL,NULL,'');
/*!40000 ALTER TABLE `biz_hours_except` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-27 18:24:22
