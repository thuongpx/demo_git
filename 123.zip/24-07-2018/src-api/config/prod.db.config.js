export default {
		host: "172.31.50.20",
		user: "fpt-admin",
		password: "ictG7eYfwEvEtctseJ",
		database: "tce_staging"
};