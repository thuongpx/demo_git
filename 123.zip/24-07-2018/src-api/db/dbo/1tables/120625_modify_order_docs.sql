DROP PROCEDURE IF EXISTS `AlterTable`;

DELIMITER $$
CREATE PROCEDURE `AlterTable`()
BEGIN
	set @var=if((SELECT true FROM information_schema.TABLE_CONSTRAINTS WHERE
            CONSTRAINT_SCHEMA = DATABASE() AND
            TABLE_NAME        = 'order_docs' AND
            CONSTRAINT_NAME   = 'TeanantId_order_docs' AND
            CONSTRAINT_TYPE   = 'FOREIGN KEY') = true, 'ALTER TABLE order_docs
            drop foreign key TeanantId_order_docs','select 1');

	prepare stmt from @var;
	execute stmt;
	deallocate prepare stmt;
    
    IF EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_staging' AND
						TABLE_NAME = 'order_docs' AND 
                            COLUMN_NAME = 'TenantId') THEN
	BEGIN
		ALTER TABLE `order_docs` 
		CHANGE COLUMN `TenantId` `TenantId` INT(11) NULL ;
	END;
    END IF;
END$$

DELIMITER ;
CALL AlterTable();
DROP PROCEDURE IF EXISTS `AlterTable`;