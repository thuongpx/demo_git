ALTER TABLE `signer_docs` ADD COLUMN `ReferenceName` VARCHAR(50) NULL AFTER `Number`;
ALTER TABLE `signer_docs` ADD COLUMN `ReferencePhoneNumber` VARCHAR(10) NULL AFTER `ReferenceName`;
