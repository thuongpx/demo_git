CREATE TABLE IF NOT EXISTS `client_mtd_config` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `Period` VARCHAR(50) NULL,
  `FromDate` DATE NULL,
  `ToDate` DATE NULL,
  `UserId` INT NULL,
  PRIMARY KEY (`Id`)
);
