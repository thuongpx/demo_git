CREATE TABLE IF NOT EXISTS `vendor_courses_result` (
  `ResultId` INT NOT NULL AUTO_INCREMENT,
  `VendorId` INT NOT NULL,
  `ProgramId` INT NOT NULL,
  `CourseId` INT NOT NULL,
  `IsComplete` BIT NULL,
  `StartDate` DATETIME NULL,
  `EndDate` DATETIME NULL,
  PRIMARY KEY (`ResultId`)
);