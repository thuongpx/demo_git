use tce_dev;

DROP TABLE IF EXISTS `industry_additional_fee`;
DROP TABLE IF EXISTS `industry_transaction`;

CREATE TABLE IF NOT EXISTS `industry_transaction_fees` (
	`FeeId` INT(11) NOT NULL AUTO_INCREMENT,
    `IndustryId` INT(11) NOT NULL,
    `LoanTypeId` INT(11) NULL,
    `FeeDescription` VARCHAR(100) NULL,
    `ClientFee` DECIMAL(19, 4),
    `VendorFee` DECIMAL(19, 4),
    `IsAdditionalFee` BIT NULL,
    PRIMARY KEY (`FeeId`),
    KEY `industryId_industry_transaction_fees_idx` (`IndustryId`),
    CONSTRAINT `industryId_industry_transaction_fees` FOREIGN KEY(`IndustryId`) 
		REFERENCES `industry` (`IndustryId`) ON UPDATE NO ACTION ON DELETE NO ACTION,
    KEY `loanTypeId_industry_transaction_fees_idx` (`LoanTypeId`),
    CONSTRAINT `loanTypeId_industry_transaction_fees` FOREIGN KEY(`LoanTypeId`)
		REFERENCES `loan_type` (`LoanTypeId`) ON UPDATE NO ACTION ON DELETE NO ACTION
);