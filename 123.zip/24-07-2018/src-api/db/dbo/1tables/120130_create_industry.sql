CREATE TABLE IF NOT EXISTS `industry` (
	`IndustryId` INT(11) NOT NULL AUTO_INCREMENT,
    `Description` VARCHAR(150),
    PRIMARY KEY (`IndustryId`)
);