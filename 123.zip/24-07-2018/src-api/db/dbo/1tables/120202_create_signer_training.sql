CREATE TABLE IF NOT EXISTS  `signer_training` (
  `TraningId` INT NOT NULL AUTO_INCREMENT,
  `SignerId` INT NULL,
  `CourseId` INT NULL,
  `TenantId` INT NULL,
  `CompleteDate` DATETIME NULL,
  PRIMARY KEY (`TraningId`),
  INDEX `signerId_signer_training_idx` (`SignerId` ASC),
  INDEX `courseId_signer_training_idx` (`CourseId` ASC),
  INDEX `teanantId_signer_training_idx` (`TenantId` ASC),
  CONSTRAINT `signerId_signer_training`
    FOREIGN KEY (`SignerId`)
    REFERENCES `signer` (`SignerId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `courseId_signer_training`
    FOREIGN KEY (`CourseId`)
    REFERENCES `training_courses` (`CourseId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `teanantId_signer_training`
    FOREIGN KEY (`TenantId`)
    REFERENCES `tenant` (`TenantId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


