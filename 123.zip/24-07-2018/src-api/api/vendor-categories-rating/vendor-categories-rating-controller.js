import Boom from "boom";
import Bookshelf from "../../db/database";
import { Promise } from "bluebird";
import Rating from "../../db/model/rating";
import VendorCategoriesRating from "../../db/model/vendor-categories-rating";
import VendorModifiersBonus from "../../db/model/vendor-modifiers-bonus";
import BrokerVendorCategoriesRating from "../../db/model/broker-vendor-categories-rating";
import BrokerVendorModifiersBonus from "../../db/model/broker-vendor-modifiers-bonus";

class VendorCategoriesRatingController {
    getVendorCategoriesRating(request, reply) {
        const { clientId, roleType } = request.query;
        let rawSqlVendorCategoriesRating = "";
        let rawSqlVendorModifierBonus = "";
        if (roleType === "Client") {
            rawSqlVendorCategoriesRating = Promise.resolve(Bookshelf.knex.raw(`select vcr.Id, vcr.Category, vcr.Percent, vcr.RatingId, vcr.MaxPoint, vcr.ThresholdFrom, vcr.ThresholdTo, cr.Unit, cr.Description from broker_vendor_categories_rating vcr
                                                        inner join categories_rating cr on vcr.RatingId = cr.Id where vcr.BrokerId = ${clientId}`));
            rawSqlVendorModifierBonus = Promise.resolve(Bookshelf.knex.raw(`select vmb.Id, vmb.BonusId, vmb.PointBonus, vmb.PointComplaint, mb.Description from broker_vendor_modifiers_bonus vmb
                                                        inner join modifiers_bonus mb on vmb.bonusId = mb.Id where vmb.BrokerId = ${clientId}`));
        } else {
            rawSqlVendorCategoriesRating = Promise.resolve(Bookshelf.knex.raw(`select vcr.Id, vcr.Category, vcr.Percent, vcr.RatingId, vcr.MaxPoint, vcr.ThresholdFrom, vcr.ThresholdTo, cr.Unit, cr.Description from vendor_categories_rating vcr
            inner join categories_rating cr on vcr.RatingId = cr.Id`));

            rawSqlVendorModifierBonus = Promise.resolve(Bookshelf.knex.raw(`select vmb.Id, vmb.BonusId, vmb.PointBonus, vmb.PointComplaint, mb.Description from vendor_modifiers_bonus vmb
            inner join modifiers_bonus mb on vmb.bonusId = mb.Id`));
        }

        const rawSQLCategoriesRating = Promise.resolve(Bookshelf.knex.raw(`select Id as value , Description as label, Unit as unit from categories_rating where Id not in (select RatingId from vendor_categories_rating)`));

        const rawSqlModifierBonus = Promise.resolve(Bookshelf.knex.raw(`select  Id as value , Description as label from modifiers_bonus where Id not in (select BonusId from vendor_modifiers_bonus)`));
        const rawSqlRating = Promise.resolve(Bookshelf.knex.raw(`select RatingID, Rating, PointPercentTo from rating`));

        Promise.all([rawSqlVendorCategoriesRating, rawSQLCategoriesRating, rawSqlVendorModifierBonus, rawSqlModifierBonus, rawSqlRating])
            .then(result => {
                if (result !== null) {
                    let listVendorCategoryRating = [];
                    let listCategoriesRating = [];
                    let listVendorModifierBonus = [];
                    let listModifierBonus = [];
                    let listRating = [];
                    result.forEach((item, index) => {
                        switch (index) {
                            case 0:
                                {
                                    listVendorCategoryRating = item[0];
                                    break;
                                }
                            case 1:
                                {
                                    listCategoriesRating = item[0];
                                    break;
                                }
                            case 2:
                                {
                                    listVendorModifierBonus = item[0];
                                    break;
                                }
                            case 3:
                                {
                                    listModifierBonus = item[0];
                                    break;
                                }
                            case 4:
                                {
                                    listRating = item[0];
                                    break;
                                }
                        }
                    });
                    reply({
                        listVendorCategoryRating,
                        listCategoriesRating,
                        listVendorModifierBonus,
                        listModifierBonus,
                        listRating
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    updateVendorRatingSetting(request, reply) {
        const { listVendorCategoryRating, listVendorModifierBonus, listRating, clientId, roleType } = request.payload;
        let isSuccess = false;
        const listVendorCategoryRatingId = listVendorCategoryRating.map(item => item.Id);
        const listVendorModifierBonusId = listVendorModifierBonus.map(item => item.Id);
        let delVendorCategoryRating = "";
        let delVendorModifierBonus = "";
        if (roleType === "Client") {
            delVendorCategoryRating = `DELETE FROM broker_vendor_categories_rating WHERE BrokerId = ${clientId} AND Id NOT IN (${listVendorCategoryRatingId})`;
            Bookshelf.knex.raw(delVendorCategoryRating)
                .then(() => {
                    isSuccess = true;
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
            listVendorCategoryRating.forEach(async item => {
                if (item.Id > 0) {
                    BrokerVendorCategoriesRating.where({ Id: item.Id }).save({
                        BrokerId: clientId,
                        Category: item.Category,
                        Percent: item.Percent,
                        RatingId: item.RatingId,
                        MaxPoint: item.MaxPoint,
                        ThresholdFrom: item.ThresholdFrom,
                        ThresholdTo: item.ThresholdTo
                    }, { method: "update" }).then(() => {
                        isSuccess = true;
                    }).catch(error => Boom.badRequest(error));
                } else {
                    new BrokerVendorCategoriesRating().save({
                        BrokerId: clientId,
                        Category: item.Category,
                        Percent: item.Percent,
                        RatingId: item.RatingId,
                        MaxPoint: item.MaxPoint,
                        ThresholdFrom: item.ThresholdFrom,
                        ThresholdTo: item.ThresholdTo
                    },
                        { method: "insert" }).then(() => {
                            isSuccess = true;
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                            return;
                        });
                }
            });

            delVendorModifierBonus = `DELETE FROM broker_vendor_modifiers_bonus WHERE BrokerId = ${clientId} AND Id NOT IN (${listVendorModifierBonusId})`;
            Bookshelf.knex.raw(delVendorModifierBonus)
                .then(() => {
                    isSuccess = true;
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
            listVendorModifierBonus.forEach(item => {
                if (item.Id > 0) {
                    BrokerVendorModifiersBonus.where({ Id: item.Id }).save({
                        BrokerId: clientId,
                        BonusId: item.BonusId,
                        PointBonus: item.PointBonus,
                        PointComplaint: item.PointComplaint
                    }, { method: "update" }).then(() => {
                        isSuccess = true;
                    }).catch(error => Boom.badRequest(error));
                } else {
                    new BrokerVendorModifiersBonus().save({
                        BrokerId: clientId,
                        BonusId: item.BonusId,
                        PointBonus: item.PointBonus,
                        PointComplaint: item.PointComplaint
                    },
                        { method: "insert" }).then(() => {
                            isSuccess = true;
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                            return;
                        });
                }
            });
        } else {
            delVendorCategoryRating = `DELETE FROM vendor_categories_rating WHERE Id NOT IN (${listVendorCategoryRatingId})`;
            Bookshelf.knex.raw(delVendorCategoryRating)
                .then(() => {
                    isSuccess = true;
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
            listVendorCategoryRating.forEach(async item => {
                if (item.Id > 0) {
                    VendorCategoriesRating.where({ Id: item.Id }).save({
                        Category: item.Category,
                        Percent: item.Percent,
                        RatingId: item.RatingId,
                        MaxPoint: item.MaxPoint,
                        ThresholdFrom: item.ThresholdFrom,
                        ThresholdTo: item.ThresholdTo
                    }, { method: "update" }).then(() => {
                        isSuccess = true;
                    }).catch(error => Boom.badRequest(error));
                } else {
                    new VendorCategoriesRating().save({
                        Category: item.Category,
                        Percent: item.Percent,
                        RatingId: item.RatingId,
                        MaxPoint: item.MaxPoint,
                        ThresholdFrom: item.ThresholdFrom,
                        ThresholdTo: item.ThresholdTo
                    },
                        { method: "insert" }).then(() => {
                            isSuccess = true;
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                            return;
                        });
                }
            });

            delVendorModifierBonus = `DELETE FROM vendor_modifiers_bonus WHERE Id NOT IN (${listVendorModifierBonusId})`;
            Bookshelf.knex.raw(delVendorModifierBonus)
                .then(() => {
                    isSuccess = true;
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
            listVendorModifierBonus.forEach(item => {
                if (item.Id > 0) {
                    VendorModifiersBonus.where({ Id: item.Id }).save({
                        BonusId: item.BonusId,
                        PointBonus: item.PointBonus,
                        PointComplaint: item.PointComplaint
                    }, { method: "update" }).then(() => {
                        isSuccess = true;
                    }).catch(error => Boom.badRequest(error));
                } else {
                    new VendorModifiersBonus().save({
                        BonusId: item.BonusId,
                        PointBonus: item.PointBonus,
                        PointComplaint: item.PointComplaint
                    },
                        { method: "insert" }).then(() => {
                            isSuccess = true;
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                            return;
                        });
                }
            });
        }

        listRating.forEach(item => {
            Rating.where({ RatingID: item.RatingID }).save({
                PointPercentTo: item.PointPercentTo
            }, { method: "update" }).then(() => {
                isSuccess = true;
            }).catch(error => Boom.badRequest(error));

        });

        reply({ isSuccess });
    }
}
export default new VendorCategoriesRatingController();