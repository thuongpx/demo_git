import Boom from "boom";
import Bookshelf from "../../db/database";
import BrokerFee from "../../db/model/broker-fee";
import { handleSingleQuote } from "../../helper/common-helper";

class BrokerFeeController {
    constructor() { }

    getBrokerFeeByBrokerId(request, reply) {
        const { brokerId, sortColumn, sortDirection, page, itemPerPage } = request.query;

        const rawSqlGetIndustry = `SELECT IndustryId from broker where BrokerId = ${brokerId};`;
        Bookshelf.knex.raw(rawSqlGetIndustry).then((industry) => {
            let industryId = 0;
            if (industry[0] && industry[0][0]) {
                industryId = industry[0][0].IndustryId;
            }

            const rawSql = `call GetClientFees(${brokerId}, ${industryId}, '${handleSingleQuote(sortColumn)}', ${sortDirection}, ${page}, ${itemPerPage});`;


            Bookshelf.knex.raw(rawSql).then((result) => {
                const returnData = {};
                returnData.listData = result[0][0] || [];
                returnData.totalRecords = result[0][1][0].TotalRecords;
                reply(returnData);
            }).catch(error => reply(Boom.badRequest(error)));
        }).catch(error => reply(Boom.badRequest(error)));

    }

    updateBrokerFee(request, reply) {
        const brokerFee = request.payload;
        BrokerFee.where({ feeId: brokerFee.feeId }).save(brokerFee, { method: "update" })
            .then(() => {
                reply({ isSuccess: true });
            }).catch(error => reply(Boom.badRequest(error)));
    }

}

export default new BrokerFeeController();