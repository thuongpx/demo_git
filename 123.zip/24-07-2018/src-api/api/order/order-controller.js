import Boom from "boom";
import Bookshelf from "./../../db/database";
import Order from "./../../db/model/order";
import moment from "moment";
import {
    handleSingleQuote,
    isBuffer,
    bufferToBoolean,
    replaceAll,
    hasStringValue,
    mergeDataField,
    logNotificationAndSendToVendor,
    getUsersIdByMappingUserIdAndRoleName
} from "./../../helper/common-helper";

import NotificationTemplate from "./../../db/model/notification-management";

import sendMailCore from "../../mail/mail-helper";
import {
    getMergeFieldMappingVendorOffer
} from "../../merge-engine/vendor-offer/vendor-decline-offer";
import OrderDocs from "./../../db/model/order-docs";
import OrderFee from "./../../db/model/order-fee";
import OrderFeeApprove from "./../../db/model/order-fee-approve";
import OrderLog from "./../../db/model/order-log";
import OrderProblem from "./../../db/model/order-problem";
import OrderProgressLog from "./../../db/model/order-progress-log";
import OrderRefund from "./../../db/model/order-refund";
import OrderStats from "./../../db/model/order-stats";
import SignersApproval from "./../../db/model/signers-approval";
import Broker from "../../db/model/brokers";
import SignerOffer from "../../db/model/signer-offer";
import SignerHistory from "../../db/model/signer-history";
import {
    getAllProgresses
} from "../../db/model/progress";
import {
    getLoanTypesByCustomerIdBrokerId,
    getAdditionalFees,
    getTotalOrderFees,
    getOrderMainFee,
    getOrderMainBrokerFee
} from "../../db/model/order";
import {
    getAllCouriers
} from "../../db/model/courier";

import {
    sendSNSMessage
} from "./../../helper/sns-helper";

import {
    ORDER_OWNER_TYPE,
    UPDATE_VENDOR_FEE_TYPE,
    NOTIFICATION_TEMPLATE_PURPOSE
} from "../../constant/common-constant";
import {
    ORDER_PROGRESS_ID
} from "../../constant/progress-constant";

import OrderCustomerFeedback from "../../db/model/order-customer-feedback";

class OrderController {
    constructor() { }

    getInitDataForViewOrders(request, reply) {
        const getInitDataDrop = Promise.resolve(Bookshelf.knex.raw(`call getDataInitForViewOrders();`));
        const getDataSearch = Promise.resolve(Bookshelf.knex.raw(`call ViewOrders(null,'','','',null,null,null,'','','\`Order Date\`',false,1,25);`));

        Promise.all([getInitDataDrop, getDataSearch])
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.companyBranch = item[0][0];
                                    data.progress = item[0][1];
                                    break;
                                case 1:
                                    data.data = item[0][0];
                                    data.totalRecords = item[0][1][0].TotalRecords;
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
        return reply;
    }

    // getOrders(request, reply) {
    //     const {
    //         orderID,
    //         vendorLastName,
    //         borrLastName,
    //         companyBranch,
    //         apptDate,
    //         fromDate,
    //         toDate,
    //         loanAgent,
    //         statusOrder,
    //         sortColumn,
    //         sortDirection,
    //         page,
    //         itemPerPage
    //     } = request.query;

    //     const rawSql = `call ViewOrders(
    //         ${orderID === undefined ? null : `${orderID}`},
    //         '${handleSingleQuote(vendorLastName)}',
    //         '${handleSingleQuote(borrLastName)}',
    //         '${companyBranch}',
    //         ${apptDate === undefined ? null : `'${apptDate}'`},
    //         ${fromDate === undefined ? null : `'${fromDate}'`},
    //         ${toDate === undefined ? null : `'${toDate}'`},
    //         '${handleSingleQuote(loanAgent)}',
    //         ${statusOrder === undefined ? null : `'${statusOrder}'`},
    //         '\`${sortColumn}\`',
    //         ${sortDirection},
    //         ${page},
    //         ${itemPerPage}
    //     );`;

    //     Bookshelf.knex.raw(rawSql)
    //         .then((result) => {
    //             if (result !== null) {
    //                 reply({
    //                     data: result[0][0],
    //                     totalRecords: result[0][1][0].TotalRecords
    //                 });
    //             }
    //             return reply;
    //         }).catch((error) => {
    //             reply(Boom.badRequest(error));
    //             return reply;
    //         });
    // }
    getOrders(request, reply) {
        const {
            sortColumn,
            groupStatus,
            sortDirection,
            page,
            itemPerPage,
            orderId,
            vendorLastName,
            customerLastName,
            companyBranch,
            agentName,
            statusOrder,
            AptDateFrom,
            AptDateTo,
            OrderDateFrom,
            OrderDateTo
        } = request.query;
        const newOrderId = (orderId === "" || orderId === undefined) ? null : parseInt(orderId);
        const newVendorLastName = (vendorLastName === "" || vendorLastName === undefined) ? "" : handleSingleQuote(vendorLastName);
        const newCustomerLastName = (customerLastName === "" || customerLastName === undefined) ? "" : handleSingleQuote(customerLastName);
        const newCompanyBranch = (companyBranch === "" || companyBranch === undefined) ? null : parseInt(companyBranch);
        const newAgentName = (agentName === "" || agentName === undefined) ? "" : handleSingleQuote(agentName);
        const newStatusOrder = (statusOrder === "" || statusOrder === undefined) ? null : parseInt(statusOrder);
        const newAptDateFrom = (AptDateFrom === "" || AptDateFrom === undefined) ? "" : moment(handleSingleQuote(AptDateFrom)).format("YYYY-MM-DD").toString();
        const newAptDateTo = (AptDateTo === "" || AptDateTo === undefined) ? "" : moment(handleSingleQuote(AptDateTo)).format("YYYY-MM-DD").toString();
        const newOrderDateFrom = (OrderDateFrom === "" || OrderDateFrom === undefined) ? "" : moment(handleSingleQuote(OrderDateFrom)).format("YYYY-MM-DD").toString();
        const newOrderDateTo = (OrderDateTo === "" || OrderDateTo === undefined) ? "" : moment(handleSingleQuote(OrderDateTo)).format("YYYY-MM-DD").toString();
        let andWhere = "AND (1=1";

        andWhere += ")";

        let groupsQuery = "";
        switch (groupStatus) {
            case "Open":
                groupsQuery = `"Open"`;
                break;
            case "Assigned":
                groupsQuery = `"Assigned to Vendor", "Appt Confirmed Pending Docs", "Pending Pre-call"`;
                break;
            case "Appt Ready":
                groupsQuery = `"Appt Ready"`;
                break;
            case "Closed Pending":
                groupsQuery = `"Closed Pending Review/PC Resolution", "Closed Pending QC Review"`;
                break;
            case "Closing Complete":
                groupsQuery = `"Closing Completed", "Post Close"`;
                break;
            case "Did Not Close":
                groupsQuery = `"Hold", "Canceled", "Unsuccessful signing attempt"`;
                break;
            default:
                groupsQuery = "";
                break;
        }

        Bookshelf.knex.raw(`call GetOrders(
            ${(sortColumn === undefined || sortColumn === "") ? null : `'${sortColumn}'`},
            ${(sortDirection === undefined || sortDirection === "") ? null : `${sortDirection}`},
            '${andWhere}',
            ${(page === undefined || page === "") ? null : `${page}`},
            ${(itemPerPage === undefined || itemPerPage === "") ? null : `${itemPerPage}`},
            ${(groupsQuery === "") ? null : `'${groupsQuery}'`},
            ${newOrderId},
            '${newVendorLastName}',
            '${newCustomerLastName}',
            ${newCompanyBranch},
            '${newAgentName}',
            ${newStatusOrder},
            '${newAptDateFrom}',
            '${newAptDateTo}',
            '${newOrderDateFrom}',
            '${newOrderDateTo}'
        );`).then(value => {
                const data = {};

                if (value !== null) {
                    data.groupStatus = value[0][0];
                    data.data = value[0][1];
                    data.totalRecords = value[0][2][0].TotalRecords;
                }
                reply(data);
                return reply;
            }).catch(err => {
                reply(Boom.badRequest(err));
                return reply;
            });
    }

    // add new order and return orderid
    addOrder(request, reply) {
        const newOrder = new Order();

        newOrder.save({
            OrderDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            Inactive: true
        }, {
                method: "insert"
            }).then((result) => {
                if (result && result.attributes) {
                    const orderId = result.attributes.id;
                    reply({
                        orderId,
                        isSuccess: true
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        return reply;
    }

    async getInitRequiredTabForOrderDetail(request, reply) {
        const {
            orderId,
            isClientPlaceOrder
        } = request.query;
        let rawSql = `SELECT o.BrokerId, o.AgentId, o.Zip from \`order\` o where o.OrderId = ${orderId};`;

        if (isClientPlaceOrder) {
            rawSql = `SELECT o.BrokerId, o.FirstName as AgentId, o.Zip from \`order\` o where o.OrderId = ${orderId};`;
        }

        const data = {
            isValidStatusTab: false,
            isValidClientTab: false,
            isValidCustomerTab: false
        };

        await new Promise(resolve => Bookshelf.knex.raw(rawSql)
            .then(result => {

                if (result[0][0]) {
                    if (result[0][0].BrokerId) data.isValidStatusTab = true;
                    if (result[0][0].AgentId) data.isValidClientTab = true;
                    if (result[0][0].Zip) data.isValidCustomerTab = true;
                }

                resolve();
            }).catch(err => {
                reply(Boom.badRequest(err));
            })
        );

        if (isClientPlaceOrder) {
            const rawSqlGetDataToSendMail = `SELECT b.Company as clientCompanyName, DATE(o.AptDateTime) as aptDate, TIME(o.AptDateTime) as aptTime,
                                            o.FirstName as primaryFirstName, o.LastName as primaryLastName, o.CoFirstName as coFirstName, o.CoLastName as coLastName,
                                            o.Address as aptAddress, o.PropertyAddress as propAptAddress, o.Email as primaryCustomerEmail, o.CoEmail as coCustomerEmail,
                                            o.IsCoBasicAccess as isSendConfirmToCoCustomer, o.IsPrimaryBasicAccess as isSendConfirmToPrimaryCustomer
                                    FROM \`order\` o LEFT JOIN broker b on o.BrokerId = b.BrokerID where o.OrderId = ${orderId};`;
            await new Promise(resolve => Bookshelf.knex.raw(rawSqlGetDataToSendMail)
                .then(result => {
                    data.defaultDataToSendMail = result[0][0];
                    data.defaultDataToSendMail.isSendConfirmToPrimaryCustomer = bufferToBoolean(result[0][0].isSendConfirmToPrimaryCustomer);
                    data.defaultDataToSendMail.isSendConfirmToCoCustomer = bufferToBoolean(result[0][0].isSendConfirmToCoCustomer);
                    resolve();
                }).catch(err => {
                    reply(Boom.badRequest(err));
                })
            );
        }

        reply(data);
    }

    getDefaultDataForOrderDetailHeader(request, reply) {
        const {
            orderId
        } = request.query;
        const getClientData = Promise.resolve(Bookshelf.knex.raw(`select a.AgentId, b.Company, a.FullName, a.Direct, a.Ext, a.AfterhoursPhone, a.Email 
            from \`order\` o left join broker b on o.BrokerId = b.BrokerID left join agent a on a.AgentId = o.AgentId
            where o.OrderId = ${orderId};`));
        const getCustomerData = Promise.resolve(Bookshelf.knex.raw(`select o.FirstName, o.LastName, o.City, o.State, o.HomePhone, o.AptDateTime, o.Email from \`order\` o where o.OrderId = ${orderId};`));
        const getSignerData = Promise.resolve(Bookshelf.knex.raw(`select s.FirstName, s.HomePhone, s.WorkPhone, s.Ext, s.Mobile, s.Email from \`order\` o left join signer s on o.SignerId = s.SignerId where o.OrderId = ${orderId};`));

        Promise.all([getClientData, getCustomerData, getSignerData])
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.client = item[0];
                                    break;
                                case 1:
                                    data.customer = item[0];
                                    break;
                                case 2:
                                    data.signer = item[0];
                                    break;
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    checkInCompleteOrder(request, reply) {
        const {
            userId
        } = request.query;
        const rawSql = `select distinct o.OrderId, o.CurrentTab from \`order\` o where o.Inactive = true and o.CreatedBy = ${userId};`;

        Bookshelf.knex.raw(rawSql)
            .then(value => {
                if (value !== null) {
                    const result = value[0];
                    if (result.length === 0) {
                        reply({
                            hasInCompleteOrder: false
                        });
                    } else {
                        reply({
                            hasInCompleteOrder: true,
                            orderData: result[0]
                        });
                    }
                } else {
                    reply({
                        hasInCompleteOrder: false
                    });
                }
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    removeInCompleteOrder(request, reply) {
        const {
            orderId
        } = request.query;
        const removeOrderDocs = Promise.resolve(OrderDocs.where({
            OrderId: orderId
        }).destroy());
        const removeOrderFee = Promise.resolve(OrderFee.where({
            OrderId: orderId
        }).destroy());
        const removeOrderFeeApprove = Promise.resolve(OrderFeeApprove.where({
            OrderId: orderId
        }).destroy());
        const removeOrderLog = Promise.resolve(OrderLog.where({
            OrderId: orderId
        }).destroy());
        const removeOrderProblem = Promise.resolve(OrderProblem.where({
            OrderId: orderId
        }).destroy());
        const removeOrderProgressLog = Promise.resolve(OrderProgressLog.where({
            OrderId: orderId
        }).destroy());
        const removeOrderRefund = Promise.resolve(OrderRefund.where({
            OrderId: orderId
        }).destroy());
        const removeOrderStats = Promise.resolve(OrderStats.where({
            OrderId: orderId
        }).destroy());
        const removeSignerApprove = Promise.resolve(SignersApproval.where({
            OrderId: orderId
        }).destroy());

        Promise.all([
            removeOrderDocs,
            removeOrderFee,
            removeOrderFeeApprove,
            removeOrderLog,
            removeOrderProblem,
            removeOrderProgressLog,
            removeOrderRefund,
            removeOrderStats,
            removeSignerApprove
        ]).then(() => {
            Order.where({
                OrderId: orderId
            }).destroy()
                .then(() => {
                    reply({
                        isSucces: true
                    });
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    setActiveOrder(request, reply) {
        const {
            orderId
        } = request.query;

        Order.where({
            OrderId: orderId
        }).save({
            Inactive: false
        }, {
                method: "update"
            })
            .then(() => {
                reply({
                    isSuccess: true
                });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    setCurrentTabOfInCompleteOrder(request, reply) {
        const {
            orderId,
            currentTab
        } = request.query;

        Order.where({
            OrderId: orderId
        }).save({
            CurrentTab: currentTab
        }, {
                method: "update"
            })
            .then(() => {
                reply({
                    isSuccess: true
                });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    async getVendorLog(request, reply) {
        const {
            orderId
        } = request.query;
        const vendorLog = {
            sentOffer: 0,
            request: 0,
            history: 0
        };

        await new Promise((resolve) => SignerOffer.query((qb) => {
            qb.where("orderId", "=", `${orderId}`);
        }).count("*").then((count) => {
            vendorLog.sentOffer = count;
            resolve();
        }).catch(err => {
            reply(Boom.badRequest(err));
        }));

        await new Promise((resolve) => SignersApproval.where({
            orderId
        }).count("*").then((count) => {
            vendorLog.request = count;
            resolve();
        }).catch(err => {
            reply(Boom.badRequest(err));
        }));

        await new Promise((resolve) => SignerHistory.where({
            orderId
        }).count("*").then((count) => {
            vendorLog.history = count;
            resolve();
        }).catch(err => {
            reply(Boom.badRequest(err));
        }));

        reply(vendorLog);
    }

    async assignVendor(request, reply) {
        const {
            order
        } = request.payload;
        const assignVendor = Promise.resolve(Order.where({
            OrderId: order.orderId
        }).save({
            OrderId: order.orderId,
            SignerId: order.signerId,
            ProgressId: ORDER_PROGRESS_ID.ASSIGNED_TO_VENDOR,
            FilledDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
            FilledBy: order.userId
        }, {
                method: "update"
            }));
        const addSignerHistory = Promise.resolve(new SignerHistory().save({
            OrderId: order.orderId,
            SignerId: order.signerId,
            Status: "Assigned",
            HistoryDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
        }, {
                method: "insert"
            }));

        //update order fee when assign approved vendor
        let feeAmount = null;
        let feeDescripId = null;
        const getFeeApproval = `Select feeAmount,feeDescripId from order_fee_approve where orderId = ${order.orderId} and signerId = ${order.signerId} and feeApproved='Approved'
        order by FeeApprovalDate desc limit 0,1;`;
        await new Promise(resolve => Bookshelf.knex.raw(getFeeApproval).then(result => {
            if (result[0][0]) {
                feeAmount = result[0][0].feeAmount;
                feeDescripId = result[0][0].feeDescripId;
            }
            resolve();
        }).catch((error) => {
            reply(Boom.badRequest(error));
        }));

        if (feeAmount) {
            await new Promise(resolve => Bookshelf.knex.raw(`update order_fee set signerFee = ${feeAmount} where feeDescripId =${feeDescripId}`).then(() => {
                resolve();
            }).catch((error) => {
                reply(Boom.badRequest(error));
            }));
        }

        //log vendor notification
        await logNotificationAndSendToVendor(order.orderId, order.signerId, false);

        Promise.all([assignVendor, addSignerHistory]).then(result => {
            if (result !== null) {
                const rawSqlVendor = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor offer accept success';`));
                const rawSqlAgent = Promise.resolve(Bookshelf.knex.raw(`select FromEmail as fromEmail, Subject as subject, Message as message from notification_templates where Purpose = 'vendor has been asign agent';`));

                Promise.all([rawSqlVendor, rawSqlAgent])
                    .then(values => {
                        if (values !== null) {
                            values.forEach((item, index) => {
                                if (item !== null) {
                                    let subject = "";

                                    switch (index) {
                                        case 0:
                                            {
                                                subject = item[0][0].subject;
                                                break;
                                            }
                                        case 1:
                                            {
                                                subject = replaceAll(item[0][0].subject, "[orderID]", order.orderId);
                                                break;
                                            }
                                    }

                                    const mailHtml = mergeDataField(item[0][0].message, getMergeFieldMappingVendorOffer(order));
                                    const mailOptions = {
                                        from: item[0][0].fromEmail,
                                        to: order.agentEmail,
                                        subject,
                                        text: `Send Email`,
                                        html: mailHtml
                                    };

                                    sendMailCore(mailOptions);
                                }
                            });
                        }
                        reply({
                            isSuccess: true
                        });
                    });
            }
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }

    getOrderProgressLogByOrderId(request, reply) {
        const {
            orderId
        } = request.query;

        Bookshelf.knex.raw(`select distinct opl.*, ur.RoleId, u.MappingUserId
                            from order_progress_log opl, user_roles ur, users u, \`order\` o
                            where opl.OrderId = (${orderId}) AND opl.UsersId = ur.UsersId AND u.UsersId = ur.UsersId and opl.OrderId = o.OrderId
                            AND (opl.ProgressType <> 5 OR opl.ProgressType IS NULL)
                            AND opl.DateLog >= o.FilledDate ORDER BY DateLog DESC`)
            .then((result) => {
                if (result !== null) {
                    reply({
                        dataProgressLog: result[0]
                    });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    autoAssign(request, reply) {
        const {
            orderId,
            userId
        } = request.payload;
        const excludedState = ["MD", "GA", "SC", "MA", "IN", "MN", "WV", "DC"];
        Order.where({
            orderId
        }).fetch({
            columns: ["autoProgress", "state", "aptDateTime"]
        }).then(async order => {
            let isValidToAutoAssign = true;
            const autoProgress = order.get("autoProgress");


            const state = order.get("state");
            // const aptDateTime = moment(order.get("aptDateTime"));
            // const nowAfter3Hours = moment().add(3, "hours");

            if (excludedState.includes(state)) {
                isValidToAutoAssign = false;
            }

            // if (nowAfter3Hours >= aptDateTime) {
            //     isValidToAutoAssign = false;
            // }

            // await new Promise((resolve) => BizHoursExcept.where({
            //     exceptDate: moment().format("YYYY-MM-DD")
            // }).count("*").then((count) => {
            //     isValidToAutoAssign = isValidToAutoAssign && count === 0;
            //     resolve();
            // }).catch(err => {
            //     reply(Boom.badRequest(err));
            // }));

            if (isValidToAutoAssign) {
                if (!autoProgress || autoProgress === "D") {
                    await new Promise((resolve) => Order.where({
                        orderId
                    }).save({
                        autoProgress: "P",
                        progressId: ORDER_PROGRESS_ID.OPEN,
                        autoDateStamp: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                        FilledDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                        FilledBy: userId
                    }, {
                            method: "update"
                        }).then(() => resolve()).catch(err => {
                            reply(Boom.badRequest(err));
                        }));
                }
            }

            reply({
                isValidToAutoAssign
            });
        });
    }

    cancelAutoAssign(request, reply) {
        const {
            orderId
        } = request.payload;
        Order.where({
            orderId
        }).save({
            autoProgress: null,
            progressId: ORDER_PROGRESS_ID.OPEN
        }, {
                method: "update"
            }).then(() => {
                reply({
                    isSuccess: true
                });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    removeVendorFromOrder(request, reply) {
        const {
            orderId,
            userName,
            usersId,
            vendorName
        } = request.payload;
        Order.where({
            orderId
        }).fetch({
            columns: ["signerId"]
        }).then((order) => {
            const signerId = order.get("signerId");
            Order.where({
                orderId
            }).save({
                signerId: null,
                progressId: ORDER_PROGRESS_ID.OPEN
            }, {
                    method: "update"
                }).then(() => {

                    const replySuccess = () => {
                        reply({
                            isSuccess: true
                        });
                    };

                    new SignerHistory({
                        orderId,
                        signerId,
                        status: "Removed",
                        historyDate: moment().utc().format("YYYY-MM-DD HH:mm:ss")
                    }).save(null, {
                        method: "insert"
                    }).then(() => {
                        new OrderProgressLog().save({
                            orderId,
                            activity: `${userName} removed ${vendorName} from this order`,
                            dateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                            usersId,
                            progressType: ORDER_PROGRESS_ID.OPEN
                        }, {
                                method: "insert"
                            }).then(async () => {
                                // log and send vendor notif
                                await logNotificationAndSendToVendor(orderId, signerId, true);
                                replySuccess();
                            }).catch((error) => reply(Boom.badRequest(error)));
                    }).catch(err => {
                        reply(Boom.badRequest(err));
                    });
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        });
    }

    getOrderAutoProgress(request, reply) {
        const {
            orderId
        } = request.query;
        Order.where({
            orderId
        }).fetch({
            columns: ["autoProgress", "signerId", "progressId"]
        }).then((order) => {
            reply({
                order
            });
        }).catch(err => {
            reply(Boom.badRequest(err));
        });
    }

    updateAppointmentDetailsData(request, reply) {
        const inputsData = request.payload;
        const rawData = {};
        const appDateValue = (inputsData.aptDate !== null && inputsData.aptTime !== null) ? moment(`${inputsData.aptDate} ${inputsData.aptTime}`).format("YYYY-MM-DD HH:mm:ss") : null;
        rawData.AptDateTime = inputsData.isVenOrCEDefineADT ? null : appDateValue;
        rawData.Address = inputsData.address;
        rawData.Suite = inputsData.suite;
        rawData.City = inputsData.city;
        rawData.State = inputsData.state;
        rawData.Zip = inputsData.zip;
        rawData.PropertyAddress = inputsData.propAddress;
        rawData.PropertySuite = inputsData.propSuite;
        rawData.PropertyCity = inputsData.propCity;
        rawData.PropertyState = inputsData.propState;
        rawData.PropertyZip = inputsData.propZip;
        rawData.IsVenOrCEDefineADT = inputsData.isVenOrCEDefineADT;
        rawData.AptUTC = !inputsData.timezone || inputsData.isVenOrCEDefineADT ? null : inputsData.timezone;
        rawData.IsCreatedByClient = true;
        rawData.IsPropAddressSameApt = inputsData.isPropAddress || false;

        if (inputsData.CreatedBy) rawData.CreatedBy = inputsData.CreatedBy;

        Order.where({
            OrderId: inputsData.orderId
        }).save(rawData, {
            method: "update"
        })
            .then(() => {
                reply({
                    isSuccess: true
                });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    checkGeneralInfoOfClientWhenPlaceOrder(request, reply) {
        const {
            brokerId
        } = request.query;

        const rawSqlCheckDetailsInfo = `select b.PrimaryContactFirst, b.PrimaryContactLast, b.Email, b.Phone, b.EmailOpt, b.TextOpt, 
                                        bd.APRep, bd.APRepPhone, bd.APEmail, bd.APFirst, bd.APLast, bd.APContactPhone, bd.APContactEmail
                                        from broker b left join broker_detail bd on b.BrokerID = bd.BrokerId 
                                        where b.BrokerId = (SELECT IF(b1.GID IS NOT NULL AND b1.GID <> 0, b1.GID, ${brokerId}) from broker b1 where b1.BrokerID = ${brokerId});`;
        const rawSqlCheckReturnAddr = `select count(r.BrokerId) as checkReturnAddress from return_addr r where r.BrokerId = (SELECT IF(b.GID IS NOT NULL AND b.GID <> 0, b.GID, ${brokerId}) from broker b where b.BrokerID = ${brokerId});`;
        const getDetailsInfo = Promise.resolve(Bookshelf.knex.raw(rawSqlCheckDetailsInfo));
        const getReturnAddr = Promise.resolve(Bookshelf.knex.raw(rawSqlCheckReturnAddr));

        Promise.all([getDetailsInfo, getReturnAddr])
            .then(value => {
                const data = {};
                let rawData = {};

                if (value) {
                    value.forEach((item, index) => {
                        switch (index) {
                            case 0:
                                data.isValidContactInfo = true;
                                data.isValidBilling = true;
                                if (item[0][0]) {
                                    rawData = item[0][0];
                                    if (!rawData.PrimaryContactFirst ||
                                        !rawData.PrimaryContactLast ||
                                        !rawData.Email ||
                                        !rawData.Phone
                                    ) data.isValidContactInfo = false;
                                    if (!rawData.APRep ||
                                        !rawData.APRepPhone ||
                                        !rawData.APEmail ||
                                        !rawData.APFirst ||
                                        !rawData.APLast ||
                                        !rawData.APContactPhone ||
                                        !rawData.APContactEmail
                                    ) data.isValidBilling = false;
                                } else {
                                    data.isValidContactInfo = false;
                                    data.isValidBilling = false;
                                }
                                break;
                            case 1:
                                data.isValidReturnAddr = item[0][0].checkReturnAddress > 0;
                                break;
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getAppointmentDetailsInitData(request, reply) {
        const {
            orderId
        } = request.query;
        const rawSqlGetDefaultData = `select o.AptDateTime, o.Address, o.Suite,o.City, o.State, o.PropertyAddress, o.PropertySuite, o.PropertyCity, o.PropertyState, o.IsVenOrCEDefineADT, o.Zip, o.PropertyZip, o.AptUTC, o.IsPropAddressSameApt
                                        from \`order\`o
                                        where o.OrderId = ${orderId};`;
        const rawSqlGetState = `select * from state;`;
        const getDefaultData = Promise.resolve(Bookshelf.knex.raw(rawSqlGetDefaultData));
        const getState = Promise.resolve(Bookshelf.knex.raw(rawSqlGetState));

        Promise.all([getDefaultData, getState])
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        let rawData = {};
                        if (item) {
                            switch (index) {
                                case 0:
                                    data.defaultData = {};
                                    rawData = item[0][0] || {};
                                    data.defaultData.aptDateTime = rawData.AptDateTime;
                                    data.defaultData.address = rawData.Address;
                                    data.defaultData.suite = rawData.Suite;
                                    data.defaultData.city = rawData.City;
                                    data.defaultData.state = rawData.State;
                                    data.defaultData.propAddress = rawData.PropertyAddress;
                                    data.defaultData.propSuite = rawData.PropertySuite;
                                    data.defaultData.propCity = rawData.PropertyCity;
                                    data.defaultData.propState = rawData.PropertyState;
                                    data.defaultData.zip = rawData.Zip;
                                    data.defaultData.propZip = rawData.PropertyZip;
                                    data.defaultData.isVenOrCEDefineADT = bufferToBoolean(rawData.IsVenOrCEDefineADT);
                                    data.defaultData.timezone = rawData.AptUTC;
                                    data.defaultData.isPropAddress = bufferToBoolean(rawData.IsPropAddressSameApt);
                                    break;
                                case 1:
                                    data.listStates = item[0];
                                    break;
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getOrderDetailLeftPanelInitData(request, reply) {
        const {
            orderId,
            portal
        } = request.query;

        const getOwnerTypes = (id, cb, err) => {
            const rolesSql = `CALL GetUserRoles(${id});`;

            Bookshelf.knex.raw(rolesSql)
                .then((result) => {
                    const roles = result[0][0];

                    if (roles && roles.length > 0) {
                        roles.filter((e) => {
                            return e.Type === "Client";
                        });

                        if (roles.length === 0) {
                            return err("This order is not created by a Client.");
                        }

                        // client admin
                        let rs = roles.find((e) => {
                            return e.RoleName === "Client";
                        });

                        if (rs) return cb(ORDER_OWNER_TYPE.CLIENT_ADMIN);

                        // client manager
                        rs = roles.find((e) => {
                            return e.RoleName === "Branch";
                        });

                        if (rs) return cb(ORDER_OWNER_TYPE.CLIENT_MANAGER);

                        // client agent
                        rs = roles.find((e) => {
                            return e.RoleName === "Agent";
                        });

                        if (rs) return cb(ORDER_OWNER_TYPE.CLIENT_AGENT);
                    }

                    return err("This user has no roles");
                });
        };

        const getOwnerBroker = (id, cb, fail) => {

            Broker.where({
                BrokerID: id
            })
                .fetch({
                    columns: ["PrimaryContactFirst", "PrimaryContactLast", "BrokerID"]
                }).then((rs) => {
                    cb(rs.attributes);
                }).catch((err) => {
                    fail(err);
                });
        };

        const getAssociatedAgents = (info, cb, fail) => {
            let query;
            let isBroker = false;

            switch (info.type) {
                case ORDER_OWNER_TYPE.CLIENT_ADMIN:
                    isBroker = true;
                    query = `BrokerID IN (SELECT BrokerID FROM \`broker\` WHERE (Inactive is null OR Inactive = false) AND IsAvailable = true AND (brokerId = ${info.id} OR gid = ${info.id}) ORDER BY Company)`;
                    break;
                case ORDER_OWNER_TYPE.CLIENT_MANAGER:
                    isBroker = true;
                    query = `BrokerID = ${info.id}`;
                    break;
                case ORDER_OWNER_TYPE.CLIENT_AGENT:
                    query = `AgentId = ${info.id}`;
                    break;
            }

            const rawSql = `SELECT * FROM \`agent\` WHERE ${query} and (Inactive is null or Inactive=0) ORDER BY FullName`;

            Bookshelf.knex.raw(rawSql)
                .then(result => {
                    const agents = result[0];

                    if (isBroker) {
                        // need to get information of this broker
                        getOwnerBroker(info.id, (broker) => {
                            cb({
                                owner: broker,
                                agents
                            });
                        }, fail);
                    } else {
                        cb({
                            agents,
                            owner: agents[0]
                        });
                    }
                })
                .catch((err) => {
                    fail(err);
                });
        };

        const getOrderAssociatedAgents = (order, resolve, reject) => {
            const {
                CreatedBy,
                MappingUserId,
                GID
            } = order;

            // identify user's type: Client Admin, Client Manager, Client Agent
            getOwnerTypes(CreatedBy, (result) => {
                getAssociatedAgents({
                    id: MappingUserId,
                    gid: GID,
                    type: result
                }, (data) => {
                    resolve(data);
                }, (err) => {
                    reject(err);
                });
            }, (err) => {
                reject(err);
            });
        };

        const getEmployees = (roleName, cb, fail) => {
            const rawEmployeesSql = `select e.RepId, CONCAT(e.FirstName, ' ', e.LastName) as FullName from employees as e 
            inner join users as u on e.RepId=u.MappingUserId
            left join user_roles as ur on u.UsersId=ur.UsersId
            left join roles as r on ur.RoleId=r.RoleId
            where r.RoleName='${roleName}';`;
            Bookshelf.knex.raw(rawEmployeesSql)
                .then(result => {
                    const employees = result[0];

                    if (employees) {
                        cb(employees);
                    } else {
                        cb({});
                    }
                })
                .catch((err) => {
                    fail(err);
                });
        };

        const getOrderCustomers = (order) => {
            const {
                FirstName,
                LastName,
                LanguageID,
                Language,
                WorkPhone,
                HomePhone,
                Email,
                CoFirstName,
                CoLastName,
                CoLanguageId,
                CoLanguage,
                CoWorkPhone,
                CoHomePhone,
                CoEmail
            } = order;

            return {
                customer: {
                    FirstName,
                    LastName,
                    LanguageID,
                    Language,
                    WorkPhone,
                    HomePhone,
                    Email
                },
                coCustomer: {
                    CoFirstName,
                    CoLastName,
                    CoLanguageId,
                    CoLanguage,
                    CoWorkPhone,
                    CoHomePhone,
                    CoEmail
                }
            };
        };

        const getOrderInfo = (order) => {
            return {
                orderInfo: {
                    orderId: order.OrderId,
                    agentId: order.AgentId,
                    repId: order.RepId,
                    referenceNumber: order.BrokerIdNum,
                    progressId: order.ProgressId,
                    loanTypeId: order.LoanType,
                    courierId: order.CourierID,
                    courier: order.Courier,
                    courierAccountNumber: order.CourierAcntNumber,
                    trackingNumber: order.TrackingNumber,
                    trackingNumber2: order.TrackingNumber2,
                    customerId: order.CustomerId || 0,
                    customerName: order.CustomerName,
                    brokerId: order.BrokerId || 0,
                    gidCompanyName: order.GidCompanyName,
                    brokerCompanyName: order.BrokerCompanyName,
                    needReviewPCResolution: bufferToBoolean(order.NeedReviewPCResolution),
                    filledBy: order.FilledBy,
                    gid: order.GID,
                    statusId: order.StatusID,
                    qcId: order.QCID,
                    orderDate: order.OrderDate,
                    filledDate: order.FilledDate,
                    aptDateTime: order.AptDateTime,
                    localAptDate: order.LocalAptDate,
                    aptUTC: order.AptUTC,
                    originalOrderDate: order.OriginalOrderDate,
                    closedDate: order.ClosedDate,
                    dropDate: order.DropDate,
                    lastComment: order.LastComment,
                    signerFee: order.SignerFee,
                    brokerFee: order.BrokerFee,
                    requiredPreCall: bufferToBoolean(order.IsNeedPreCall),
                    requiredEdoc: bufferToBoolean(order.RequiredEdoc)
                }
            };
        };

        const getFilledBy = (cb, fail) => {
            const sqlFilledBy = `SELECT GetFullNameByUserId(UsersId) FullName FROM order_progress_log where Activity like '% is assigned to order ${orderId}' order by DateLog desc limit 1`;
            Bookshelf.knex.raw(sqlFilledBy)
                .then(result => {
                    if (result[0].length > 0) {
                        const FullName = result[0][0].FullName;
                        cb({
                            FullName
                        });
                    } else {
                        cb({
                            FullName: ""
                        });
                    }
                })
                .catch((err) => {
                    fail(err);
                });
        };
        const getAgentInfo = (order) => {
            return {
                agentInfo: {
                    AgentId: order.AgentId,
                    Email: order.AgentEmail,
                    Phone: order.AgentDirect,
                    AfterhoursPhone: order.AgentAfterhoursPhone,
                    FullName: order.AgentFullName,
                    Fax: order.AgentFax,
                    Ext: order.AgentExt
                }
            };
        };

        // from order id, get the user who created this order
        const rawSql = `SELECT 
                            o.AgentId, o.CourierID, c.Courier, o.CourierAcntNumber, o.TrackingNumber, o.TrackingNumber2,
                            o.BrokerIdNum, o.ProgressId, o.SignerFee, o.LoanType, o.NeedReviewPCResolution, o.BrokerFee,
                            o.OrderId, o.CreatedBy, u.MappingUserId, GetFullNameByUserId(o.Filledby) as FilledBy,
                            o.CustomerId, cu.Name as CustomerName, o.StatusID, o.QCID, o.RepId,
                            o.OrderDate, o.FilledDate, o.AptUTC, o.AptDateTime, DATE_ADD(o.AptDateTime, Interval z.UTC Hour)as LocalAptDate, o.OriginalOrderDate, o.ClosedDate, o.DropDate, cm.CreatedDate as LastComment,
                            o.BrokerId, b2.Company as BrokerCompanyName, b2.GID,
                            b3.Company as GidCompanyName,
                            a.Direct as AgentDirect, a.Fax as AgentFax, a.Ext as AgentExt, a.Email as AgentEmail, a.AfterhoursPhone as AgentAfterhoursPhone, a.FullName as AgentFullName,
                            o.FirstName, o.LastName, o.LanguageID, l1.Language as Language, o.WorkPhone, o.HomePhone, o.Email, 
                            o.CoFirstName, o.CoLastName, o.CoLanguageId, l2.Language as CoLanguage, o.CoWorkPhone, o.CoHomePhone, o.CoEmail,
                            o.IsNeedPreCall, IsOrderRequiredFee(o.OrderId, 'Edocs') AS RequiredEdoc                       
                        FROM \`order\` o
                        LEFT JOIN \`users\` u ON o.CreatedBy = u.UsersId
                        LEFT JOIN \`broker\` b ON u.MappingUserId = b.BrokerID
                        LEFT JOIN \`broker\` b2 ON o.BrokerId = b2.BrokerID
                        LEFT JOIN \`broker\` b3 ON b2.GID = b3.BrokerID
                        LEFT JOIN \`language\` l1 ON l1.LanguageID = o.LanguageId
                        LEFT JOIN \`language\` l2 ON l2.LanguageID = o.CoLanguageId
                        LEFT JOIN \`agent\` a ON o.AgentId = a.AgentId
                        LEFT JOIN \`courier\` c ON o.CourierID = c.CourierID
                        LEFT JOIN \`customers\` cu ON o.CustomerId = cu.CustomerId
                        LEFT JOIN (SELECT OwnerId, CreatedDate FROM \`comment\` where OwnerID=${orderId} and TypeID=1 order by CreatedDate desc Limit 1) cm ON (o.OrderId=cm.OwnerId)
                        LEFT JOIN \`zip\` z on o.Zip = z.Zip 
                        WHERE o.OrderId = ${orderId};`;

        Bookshelf.knex.raw(rawSql).then((rs) => {
            if (!rs) reply(Boom.badRequest("Order is not found"));

            const order = rs[0][0];

            const getAgentsPromise = new Promise((resolve, reject) => {
                if (portal === "Staff") {
                    resolve(null);
                } else {
                    getOrderAssociatedAgents(order, resolve, reject);
                }
            });

            const getProgressesPromise = new Promise((resolve, reject) => {
                getAllProgresses(data => resolve(data), err => reject(err));
            });

            const getCouriersPromise = new Promise((resolve, reject) => {
                getAllCouriers(data => resolve(data), err => reject(err));
            });

            const getStatusRepresentative = new Promise((resolve, reject) => {
                if (portal === "Staff") {
                    getEmployees("Status Rep", resolve, reject);
                } else {
                    resolve(null);
                }
            });

            const getQualityControl = new Promise((resolve, reject) => {
                if (portal === "Staff") {
                    getEmployees("Quality Control", resolve, reject);
                } else {
                    resolve(null);
                }
            });

            const getTCESchedulers = new Promise((resolve, reject) => {
                if (portal === "Staff") {
                    getEmployees("Scheduler", resolve, reject);
                } else {
                    resolve(null);
                }
            });

            Promise.all([
                getAgentsPromise,
                getOrderCustomers(order),
                getOrderInfo(order),
                getProgressesPromise,
                // getProductTypePromise,
                // getOrderFeesPromise,
                getCouriersPromise,
                getStatusRepresentative,
                getQualityControl,
                getTCESchedulers,
                getAgentInfo(order)
            ]).then((values) => {
                const data = {};

                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.agents = item.agents;
                                    data.owner = item.owner;
                                    break;
                                case 1:
                                    data.customer = item.customer;
                                    data.coCustomer = item.coCustomer;
                                    break;
                                case 2:
                                    data.orderInfo = item.orderInfo;
                                    break;
                                case 3:
                                    if (!data.orderInfo) data.orderInfo = {};

                                    data.orderInfo.listProgresses = item;
                                    break;
                                case 4:
                                    if (!data.orderInfo) data.orderInfo = {};

                                    data.orderInfo.listCouriers = item;
                                    break;
                                case 5:
                                    data.orderInfo.listStatusRepresentative = item;
                                    break;
                                case 6:
                                    data.orderInfo.listQualityControl = item;
                                    break;
                                case 7:
                                    data.orderInfo.listTCESchedulers = item;
                                    break;
                                case 8:
                                    data.agentInfo = item.agentInfo;
                                    break;
                            }
                        }
                    });

                    // find the default progress id
                    if (!data.orderInfo.progressId || data.orderInfo.progressId === 0) {
                        // make it default as "Open"
                        const openProgress = data.orderInfo.listProgresses.find((i) => {
                            return i.ProgressDescription === "Open";
                        });

                        if (openProgress) {
                            data.orderInfo.progressId = openProgress.ProgressId;
                        }
                    }

                    reply(data);
                } else {
                    reply(Boom.badRequest({
                        message: "Error!"
                    }));
                }
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    getOrderDetailLeftPanelFeeInitData(request, reply) {
        const {
            orderId
        } = request.query;

        const getOrderInfo = (order) => {
            return {
                orderId: order.OrderId,
                customerId: order.CustomerId || 0,
                brokerId: order.BrokerId || 0,
                gid: order.GID,
                isSelfService: bufferToBoolean(order.IsSelfService)
            };
        };

        // from order id, get the user who created this order
        const rawSql = `SELECT 
                            o.OrderId,
                            o.CustomerId,
                            o.BrokerId, b2.GID,
                            o.IsSelfService
                        FROM \`order\` o
                        LEFT JOIN \`broker\` b2 ON o.BrokerId = b2.BrokerID
                        WHERE o.OrderId = ${orderId};`;

        Bookshelf.knex.raw(rawSql).then((rs) => {
            const orderInfo = getOrderInfo(rs[0][0]);

            const {
                customerId,
                gid,
                brokerId,
                isSelfService
            } = orderInfo;

            const getOrderInfoPromise = new Promise((resolve, reject) => {
                const sql = `SELECT o.OrderId, o.LoanType as LoanTypeId, lt.LoanType, of.SignerFee,of.BrokerFee,
                o.AgentId, a.Email as AgentEmail, a.FullName as AgentFullName,
                e.FirstName as TCEFirstName, e.LastName as TCELastName, e.Email as TCEEmail, b.Company as BrokerCompany,
                o.SignerId, CONCAT(s.FirstName,' ', s.LastName) as VendorName, s.FirstName as VendorFirstName, s.LastName as VendorLastName, s.Email as VendorEmail
                FROM \`order\` o
                LEFT JOIN \`order_fee\` of ON o.OrderId = of.OrderID
                LEFT JOIN \`loan_type\` lt ON o.LoanType = lt.LoanTypeId
                LEFT JOIN \`signer\` s ON o.SignerId = s.SignerId
                LEFT JOIN \`agent\` a ON o.AgentId = a.AgentId
                LEFT JOIN \`employees\` as e ON o.RepId=e.RepId
                LEFT JOIN \`broker\` b ON b.BrokerID = o.BrokerId
                WHERE o.OrderID=${orderId}`;

                Bookshelf.knex.raw(sql).then((data) => {

                    // let totalFee = 0;
                    let totalSignerFee = 0;
                    let totalVendorFee = 0;

                    // get total fee
                    data[0].forEach(ele => {
                        totalSignerFee += ele.SignerFee;
                        totalVendorFee += ele.BrokerFee;
                    });

                    resolve({
                        signerFee: totalSignerFee,
                        vendorFee: totalVendorFee,
                        agentId: data[0][0].AgentId,
                        loanTypeId: data[0][0].LoanTypeId,
                        loanType: data[0][0].LoanType,
                        signerId: data[0][0].SignerId,
                        vendorName: data[0][0].VendorName,
                        VendorFirstName: data[0][0].VendorFirstName,
                        VendorLastName: data[0][0].VendorLastName,
                        VendorEmail: data[0][0].VendorEmail,
                        AgentFullName: data[0][0].AgentFullName,
                        AgentEmail: data[0][0].AgentEmail,
                        TCEFirstName: data[0][0].TCEFirstName,
                        TCELastName: data[0][0].TCELastName,
                        TCEEmail: data[0][0].TCEEmail,
                        isSelfService,
                        //
                        BrokerFee: data[0][0].BrokerFee,
                        BrokerCompany: data[0][0].BrokerCompany
                    });
                }).catch((err) => {
                    reject(err);
                });
            });

            const getLoanTypePromise = new Promise((resolve, reject) => {
                getLoanTypesByCustomerIdBrokerId({
                    customerId,
                    brokerId: gid && gid > 0 ? gid : brokerId
                }, data => {
                    if (!data || !data.listProductType) reject("Not Found");

                    const listLoanTypes = data.listProductType.map((i) => {
                        return {
                            LoanType: i.LoanType,
                            LoanTypeId: i.LoanTypeId,
                            VendorFee: i.VendorFee
                        };
                    });

                    resolve({
                        listLoanTypes
                    });
                }, err => reject(err));
            });

            const getAdditionalRequestPromise = new Promise((resolve, reject) => {
                getAdditionalFees({
                    orderId,
                    brokerId: gid && gid > 0 ? gid : brokerId
                }, data => {
                    if (!data) reject("Not Found");

                    const listSelectedAdditionalRequest = data.defaultAdditionalFee.map((i) => {
                        return {
                            FeeDescripID: i.FeeDescripID,
                            FeeDescription: i.FeeDescription,
                            SignerFee: i.SignerFee,
                            BrokerFee: i.BrokerFee
                        };
                    });

                    const listAdditionalRequest = data.listAdditionalFee.map((i) => {
                        return {
                            FeeId: i.FeeId,
                            ClientFee: i.ClientFee,
                            FeeDescription: i.FeeDescription,
                            LoanTypeId: i.LoanTypeId,
                            VendorFee: i.VendorFee
                        };
                    });

                    resolve({
                        listAdditionalRequest,
                        listSelectedAdditionalRequest
                    });
                }, err => reject(err));
            });

            const getMainFeeDesciptionId = new Promise((resolve, reject) => {
                const sql = `SELECT of.FeeDescripID FROM \`order_fee\` of
                            LEFT JOIN \`broker_fee\` bf ON of.FeeDescripID = bf.FeeId
                            WHERE of.OrderId = ${orderId} AND bf.IsAdditionalFee = 0`;

                Bookshelf.knex.raw(sql)
                    .then(data => {
                        const mainFeeDescripId = data[0][0] ? data[0][0].FeeDescripID : null;

                        resolve(mainFeeDescripId);
                    })
                    .catch(err => reject(err));
            });

            const getTotalFees = new Promise((resolve, reject) => {
                getTotalOrderFees(orderId, (data) => resolve(data), error => reject(error));
            });

            Promise.all([
                getLoanTypePromise,
                getAdditionalRequestPromise,
                getOrderInfoPromise,
                getMainFeeDesciptionId,
                getTotalFees
            ])
                .then(async (values) => {
                    const data = {};

                    if (values !== null) {
                        let index = 0;
                        for (const item of values) {
                            if (item !== null) {
                                switch (index) {
                                    case 0:
                                        data.listLoanTypes = item.listLoanTypes;
                                        break;
                                    case 1:
                                        data.listAdditionalRequest = item.listAdditionalRequest;
                                        data.listSelectedAdditionalRequest = item.listSelectedAdditionalRequest;
                                        break;
                                    case 2:
                                        data.order = item;
                                        data.order.brokerId = brokerId;
                                        data.order.customerId = customerId;
                                        data.order.gid = gid;
                                        data.order.orderId = orderId;
                                        break;
                                    case 3:
                                        data.order.mainFeeDescripId = item;
                                        break;
                                    case 4:
                                        data.order.signerFee = item.signerFee;
                                        data.order.brokerFee = item.brokerFee;
                                        data.order.originalSignerFee = item.originalSignerFee;
                                        data.order.mainFee = await getOrderMainFee(orderId);
                                        data.order.mainBrokerFee = await getOrderMainBrokerFee(orderId);
                                }
                            }
                            index++;
                        }

                        reply(data);
                    } else {
                        reply(Boom.badRequest({
                            message: "Error!"
                        }));
                    }
                }).catch((err) => {
                    reply(Boom.badRequest(err));
                });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    getOrderDetailLeftPanelShippingInitData(request, reply) {
        const {
            orderId
        } = request.query;

        const getCouriersPromise = new Promise((resolve, reject) => {
            getAllCouriers(dataCourier => resolve(dataCourier), err => reject(err));
        });

        const getShippingInit = new Promise((resolve, reject) => {
            Order.where({
                OrderId: orderId
            }).fetch({
                columns: ["CourierID", "CourierAcntNumber", "TrackingNumber", "TrackingNumber2"]
            }).then((result) => {
                if (result !== null) {
                    // data.shipping = result;
                    resolve(result);
                }
            }).catch((error) => {
                // reply(Boom.badRequest(error));
                reject(error);
            });
        });

        Promise.all([
            getShippingInit,
            getCouriersPromise
        ]).then((values) => {
            const data = {};
            if (values !== null) {
                values.forEach((item, index) => {
                    if (item !== null) {
                        switch (index) {
                            case 0:
                                data.shipping = item;
                                break;
                            case 1:
                                data.listCouriers = item;
                                break;
                        }
                    }
                });
                reply(data);
            } else {
                reply(Boom.badRequest({
                    message: "Error!"
                }));
            }
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    saveLeftPanelFees(request, reply) {
        const { inputs } = request.payload;
        const {
            fees,
            loanTypeId,
            vendorFee,
            clientFee,
            brokerId,
            gid,
            orderId,
            type,
            roleNames
        } = inputs;

        // const addOrderLog = (activity) => {
        //     const logData = {
        //         OrderId: log.OrderId,
        //         Activity: activity,
        //         UsersId: log.UsersId,
        //         DateLog: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
        //         ProgressType: log.ProgressType
        //     };

        //     const newLog = new OrderProgressLog();
        //     // add a log to db
        //     newLog.save(logData, {
        //         method: "insert"
        //     });
        // }

        const updateOrderFee = () => {
            // get list of fees
            const sql = `SELECT bf.BrokerId, bf.FeeId, bf.FeeDescription, bf.VendorFee, bf.BrokerFee, bf.IsAdditionalFee 
                        FROM \`broker_fee\` bf
                        WHERE bf.BrokerId =${gid && gid > 0 ? gid : brokerId} AND bf.LoanTypeId=${loanTypeId}`;

            Bookshelf.knex.raw(sql)
                .then(data => {
                    // build records
                    const insertFees = [];
                    const brokerFees = data[0];

                    // loan type
                    const loanTypeFee = brokerFees.find(i => !bufferToBoolean(i.IsAdditionalFee));

                    if (loanTypeFee) {
                        insertFees.push({
                            OrderID: orderId,
                            FeeDescripID: loanTypeFee.FeeId,
                            BrokerFee: loanTypeFee.BrokerFee,
                            SignerFee: loanTypeFee.VendorFee,
                            OriginalSignerFee: loanTypeFee.VendorFee
                        });
                    }

                    // additional requests
                    brokerFees.forEach(i => {
                        const foundFee = fees.find(f => f.FeeDescription === i.FeeDescription);
                        if (foundFee) {
                            insertFees.push({
                                OrderID: orderId,
                                FeeDescripID: i.FeeId,
                                BrokerFee: i.BrokerFee,
                                SignerFee: i.FeeDescription.includes("Room Rental") ? foundFee.SignerFee : i.VendorFee,
                                OriginalSignerFee: i.FeeDescription.includes("Room Rental") ? foundFee.SignerFee : i.VendorFee
                            });
                        }
                    });

                    // remove all old fee
                    OrderFee.where({
                        OrderId: orderId
                    }).destroy()
                        .then((result) => {
                            if (result !== null) {
                                // add new fees
                                const OrderFeeObj = Bookshelf.Collection.extend({
                                    model: OrderFee
                                });

                                const returnAddress = OrderFeeObj.forge(insertFees);

                                returnAddress.invokeThen("save").then(() => {
                                    reply({
                                        isSuccess: true
                                    });
                                }).catch(error => {
                                    reply(Boom.badRequest(error));
                                });
                            }
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        };

        const updateLoanType = () => {
            // update field loanType in order
            Order.where({
                OrderId: orderId
            }).save({
                LoanType: loanTypeId
            }, {
                    method: "update"
                })
                .then(() => {
                    // add an order progress log
                    try {
                        // addOrderLog(`${log.UserName} changed product type.`);
                    } catch (err) {
                        console.log(err);
                    }

                    updateOrderFee();
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        };

        const updateTotalVendorFee = () => {
            const getFeeDifference = new Promise((resolve, reject) => {
                getTotalOrderFees(orderId,
                    totalFee => {
                        const {
                            originalSignerFee,
                            signerFee
                        } = totalFee;
                        const diffWithCurrent = vendorFee - signerFee;
                        const diffWithOriginal = vendorFee - originalSignerFee;

                        if (diffWithOriginal > 0) {
                            const diffPercent = diffWithOriginal / originalSignerFee * 100;

                            // identify user's role
                            let isAdminManager = false;

                            // if self service: client admin/manager can change vendor fee without a request.
                            // if full service: Tce admin/manager can change vendor fee without a request.
                            const adminRole = roleNames.find(i => {
                                return (i.toLowerCase() === "client" || i.toLowerCase() === "branch") || i.toLowerCase() === "admin" || i.toLowerCase() === "operational manager";
                            });

                            if (adminRole) isAdminManager = true;

                            // if user is admin/manager then go ahead and save
                            // if user is agent/scheduler then exceed
                            if (diffPercent > 10 && !isAdminManager) {
                                resolve({
                                    status: UPDATE_VENDOR_FEE_TYPE.EXCEED
                                });
                            }
                        } else if (diffWithOriginal === 0) {
                            resolve({
                                status: UPDATE_VENDOR_FEE_TYPE.IGNORE
                            });
                        }

                        // save total fee
                        resolve({
                            status: UPDATE_VENDOR_FEE_TYPE.UPDATE,
                            diff: diffWithCurrent
                        });
                    },
                    err => reject(err));
            });

            const getLoanTypeFeeRecordPromise = new Promise((resolve, reject) => {
                const sql = `SELECT of.FeeId, of.OrderID, of.FeeDescripID, of.SignerFee FROM \`order_fee\` of
                            LEFT JOIN \`broker_fee\` bf ON of.FeeDescripID = bf.FeeId
                            WHERE of.OrderId = ${orderId} AND bf.IsAdditionalFee = 0`;

                Bookshelf.knex.raw(sql)
                    .then(data => {
                        const orderFees = data[0];

                        resolve(orderFees.map(i => {
                            return {
                                feeId: i.FeeId,
                                orderId: i.OrderID,
                                feeDescripId: i.FeeDescripID,
                                signerFee: i.SignerFee
                            };
                        }));
                    })
                    .catch(err => reject(err));
            });

            Promise.all([
                getFeeDifference,
                getLoanTypeFeeRecordPromise
            ]).then((values) => {
                const data = {};

                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.status = item.status;
                                    data.diff = item.diff;
                                    break;
                                case 1:
                                    if (item && item.length > 0) {
                                        data.loanTypeFeeRecord = item[0];
                                    }
                                    break;
                            }
                        }
                    });

                    switch (data.status) {
                        case UPDATE_VENDOR_FEE_TYPE.EXCEED:
                            reply({
                                isSuccess: false,
                                status: data.status
                            });
                            break;
                        case UPDATE_VENDOR_FEE_TYPE.UPDATE:
                            Bookshelf.knex.raw(
                                `UPDATE order_fee SET
                                    OriginalSignerFee = IF(OriginalSignerFee IS NULL, SignerFee, OriginalSignerFee),
                                    SignerFee = ${data.loanTypeFeeRecord.signerFee + data.diff}
                                WHERE OrderId = ${data.loanTypeFeeRecord.orderId}
                                    AND FeeId = ${data.loanTypeFeeRecord.feeId}
                                    AND FeeDescripID = ${data.loanTypeFeeRecord.feeDescripId}
                            `)
                                .then(() => {
                                    // add an order progress log
                                    try {
                                        // addOrderLog(`${log.UserName} changed vendor fee.`);
                                    } catch (err) {
                                        console.log(err);
                                    }

                                    reply({
                                        isSuccess: true,
                                        status: data.status
                                    })
                                })
                                .catch((err) => reply(Boom.badRequest(err)));

                            break;
                        case UPDATE_VENDOR_FEE_TYPE.IGNORE:
                            reply({
                                isSuccess: true,
                                status: data.status
                            });
                            break;
                    }
                } else {
                    reply(Boom.badRequest({
                        message: "Error!"
                    }));
                }
            });
        };

        const updateTotalClientFee = () => {
            const getFeeDifference = new Promise((resolve, reject) => {
                getTotalOrderFees(orderId,
                    totalFee => {
                        const {
                            brokerFee
                        } = totalFee;
                        const diffWithCurrent = clientFee - brokerFee;

                        // save total fee
                        resolve({
                            status: "UPDATE",
                            diff: diffWithCurrent
                        });
                    },
                    err => reject(err));
            });

            const getLoanTypeFeeRecordPromise = new Promise((resolve, reject) => {
                const sql = `SELECT of.FeeId, of.OrderID, of.FeeDescripID, of.BrokerFee FROM \`order_fee\` of
                            LEFT JOIN \`broker_fee\` bf ON of.FeeDescripID = bf.FeeId
                            WHERE of.OrderId = ${orderId} AND bf.IsAdditionalFee = 0`;

                Bookshelf.knex.raw(sql)
                    .then(data => {
                        const orderFees = data[0];

                        resolve(orderFees.map(i => {
                            return {
                                feeId: i.FeeId,
                                orderId: i.OrderID,
                                feeDescripId: i.FeeDescripID,
                                brokerFee: i.BrokerFee
                            };
                        }));
                    })
                    .catch(err => reject(err));
            });

            Promise.all([
                getFeeDifference,
                getLoanTypeFeeRecordPromise
            ]).then((values) => {
                const data = {};

                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.status = item.status;
                                    data.diff = item.diff;
                                    break;
                                case 1:
                                    if (item && item.length > 0) {
                                        data.loanTypeFeeRecord = item[0];
                                    }
                                    break;
                            }
                        }
                    });

                    Bookshelf.knex.raw(
                        `UPDATE order_fee SET
                            BrokerFee = ${data.loanTypeFeeRecord.brokerFee + data.diff}
                        WHERE OrderId = ${data.loanTypeFeeRecord.orderId}
                            AND FeeId = ${data.loanTypeFeeRecord.feeId}
                            AND FeeDescripID = ${data.loanTypeFeeRecord.feeDescripId}
                    `)
                        .then(() => {
                            // add an order progress log
                            try {
                                // addOrderLog(`${log.UserName} changed client fee.`);
                            } catch (err) {
                                console.log(err);
                            }

                            reply({
                                isSuccess: true,
                                status: data.status
                            })
                        })
                        .catch((err) => reply(Boom.badRequest(err)));

                } else {
                    reply(Boom.badRequest({
                        message: "Error!"
                    }));
                }
            });
        };

        switch (type) {
            case "loanType":
                updateLoanType();
                break;
            case "additionalRequest":
                updateOrderFee();
                break;
            case "vendorFees":
                updateTotalVendorFee();
                break;
            case "clientFees":
                updateTotalClientFee();
                break;
        }
    }

    updateLeftPanel(request, reply) {
        const {
            OrderId,
            type,
            BrokerIdNum,
            CourierID,
            CourierAcntNumber,
            TrackingNumber,
            TrackingNumber2,
            StatusID,
            QCID,
            clientId,
            branchId,
            customerId,
            agentId,
            repId
        } = request.payload;

        const updateRefNumber = () => {
            // update field BrokerIdNum in order
            Order.where({
                OrderId
            }).save({
                BrokerIdNum
            }, {
                    method: "update"
                }).then(() => {
                    reply({
                        isSuccess: true,
                        referenceNumber: BrokerIdNum
                    });
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });

            const rawSql = `Select OrderId From \`order\` WHERE OrderId <> ${OrderId} AND BrokerIdNum='${BrokerIdNum}'`;
            Bookshelf.knex.raw(rawSql).then((result) => {
                if (result !== null) {
                    if (result[0].length > 0) {
                        reply({
                            isSuccess: false,
                            error: {
                                response: {
                                    status: 500,
                                    data: {
                                        message: `A File No: ${BrokerIdNum} already exists. Please re-enter`
                                    }
                                }
                            }
                        });
                    } else {
                        // update field BrokerIdNum in order
                        Order.where({
                            OrderId
                        }).save({
                            BrokerIdNum
                        }, {
                                method: "update"
                            }).then(() => {
                                reply({
                                    isSuccess: true,
                                    referenceNumber: BrokerIdNum
                                });
                            }).catch(err => {
                                reply(Boom.badRequest(err));
                            });
                    }
                } else {
                    reply({
                        isSuccess: false
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        };

        const updateCourier = () => {
            Order.where({
                OrderId
            }).save({
                CourierID
            }, {
                    method: "update"
                }).then(() => {
                    reply({
                        isSuccess: true,
                        CourierID
                    });
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        };

        const updateCourierAcntNumber = () => {
            Order.where({
                OrderId
            }).save({
                CourierAcntNumber
            }, {
                    method: "update"
                }).then(() => {
                    reply({
                        isSuccess: true,
                        CourierAcntNumber
                    });
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        };

        const updateTrackingNumber = () => {
            Order.where({
                OrderId
            }).save({
                TrackingNumber
            }, {
                    method: "update"
                }).then(() => {
                    reply({
                        isSuccess: true,
                        TrackingNumber
                    });
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        };

        const updateTrackingNumber2 = () => {
            Order.where({
                OrderId
            }).save({
                TrackingNumber2
            }, {
                    method: "update"
                }).then(() => {
                    reply({
                        isSuccess: true,
                        TrackingNumber2
                    });
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        };

        const updateStatusID = () => {
            Order.where({
                OrderId
            }).save({
                StatusID
            }, {
                    method: "update"
                }).then(() => {
                    reply({
                        isSuccess: true,
                        StatusID
                    });
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        };

        const updateQCID = () => {
            Order.where({
                OrderId
            }).save({
                QCID
            }, {
                    method: "update"
                }).then(() => {
                    reply({
                        isSuccess: true,
                        QCID
                    });
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        };

        const updateRepId = () => {
            Order.where({
                OrderId
            }).save({
                repId
            }, {
                    method: "update"
                }).then(() => {
                    reply({
                        isSucces: true,
                        repId
                    });
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        };

        const updateClientBranchAgent = () => {
            Order.where({
                OrderId
            }).save({
                AgentId: agentId !== "" ? agentId : null,
                CustomerId: customerId !== "" ? customerId : null,
                BrokerID: branchId !== "" ? branchId : clientId
            }, {
                    method: "update"
                }).then(() => {
                    reply({
                        isSuccess: true,
                        AgentId: agentId,
                        CustomerId: customerId,
                        BrokerID: clientId
                    });
                }).catch(err => {
                    reply(Boom.badRequest(err));
                });
        };

        switch (type) {
            case "refNumber":
                updateRefNumber();
                break;
            case "courier":
                updateCourier();
                break;
            case "CourierAcntNumber":
                updateCourierAcntNumber();
                break;
            case "TrackingNumber":
                updateTrackingNumber();
                break;
            case "TrackingNumber2":
                updateTrackingNumber2();
                break;
            case "Status Representative":
                updateStatusID();
                break;
            case "Quality Control":
                updateQCID();
                break;
            case "UpdateScheduler":
                updateRepId();
                break;
            case "UpdateClient":
                updateClientBranchAgent();
                break;
        }
    }

    updateAppointment(request, reply) {
        const inputsData = request.payload;
        const rawData = {};
        const appDateValue = (inputsData.aptDate !== null && inputsData.aptTime !== null) ? moment(`${inputsData.aptDate} ${inputsData.aptTime}`).format("YYYY-MM-DD HH:mm:ss") : null;
        rawData.AptDateTime = inputsData.isVenOrCEDefineADT ? null : appDateValue;
        rawData.IsVenOrCEDefineADT = inputsData.isVenOrCEDefineADT;

        Order.where({
            OrderId: inputsData.OrderId
        }).save(rawData, {
            method: "update"
        })
            .then(() => {
                reply({
                    isSuccess: true
                });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getVendorOrderDetailLeftPanelInitData(request, reply) {
        const {
            orderId
        } = request.query;

        const getOrderCustomers = (order) => {
            const {
                FirstName,
                LastName,
                LanguageID,
                Language,
                WorkPhone,
                HomePhone,
                Email,
                CoFirstName,
                CoLastName,
                CoLanguageId,
                CoLanguage,
                CoWorkPhone,
                CoHomePhone,
                CoEmail
            } = order;

            return {
                customer: {
                    FirstName,
                    LastName,
                    LanguageID,
                    Language,
                    WorkPhone,
                    HomePhone,
                    Email
                },
                coCustomer: {
                    CoFirstName,
                    CoLastName,
                    CoLanguageId,
                    CoLanguage,
                    CoWorkPhone,
                    CoHomePhone,
                    CoEmail
                }
            };
        };

        const getOrderInfo = (order) => {
            return {
                orderInfo: {
                    orderId: order.OrderId,
                    agentId: order.AgentId,
                    referenceNumber: order.BrokerIdNum,
                    progressId: order.ProgressId,
                    loanTypeId: order.LoanType,
                    courierId: order.CourierID,
                    isSelfService: bufferToBoolean(order.IsSelfService),
                    aptDateTime: order.aptDateTime,
                    timezone: order.AptUTC,
                    courier: order.Courier,
                    courierAccountNumber: order.CourierAcntNumber,
                    trackingNumber: order.TrackingNumber,
                    trackingNumber2: order.TrackingNumber2,
                    customerId: order.CustomerId || 0,
                    customerName: order.CustomerName,
                    brokerId: order.BrokerId || 0,
                    gidCompanyName: order.GidCompanyName,
                    brokerCompanyName: order.BrokerCompanyName,
                    gid: order.gid,
                    collect1: order.Collect1,
                    collect2: order.Collect2,
                    collect3: order.Collect3,
                    collect4: order.Collect4,
                    collect5: order.Collect5,
                    collect6: order.Collect6,
                    collect7: order.Collect7,
                    collect8: order.Collect8,
                    collect9: order.Collect9,
                    collect10: order.Collect10,
                    needReviewPCResolution: bufferToBoolean(order.NeedReviewPCResolution),
                    isPrimaryDocReview: bufferToBoolean(order.IsPrimaryDocReview),
                    SpecialInstructions: order.SpecialInstructions,
                    DocumentCompletedDate: order.DocumentCompletedDate,
                    TurnAroundDate: order.TurnAroundDate,
                    EmployeeEmail: order.EmployeeEmail,
                    repId: order.RepId,
                    requiredPreCall: bufferToBoolean(order.IsNeedPreCall),
                    requiredEdoc: bufferToBoolean(order.RequiredEdoc)
                }
            };
        };

        const getAgentInfo = (order) => {
            return {
                agentInfo: {
                    Email: order.AgentEmail,
                    AfterhoursPhone: order.AgentAfterhoursPhone,
                    FullName: order.AgentFullName,
                    Company: order.ClientCompanyName,
                    Address: order.ClientAddress,
                    Suite: order.ClientSuite,
                    City: order.ClientCity,
                    State: order.ClientState,
                    Zip: order.ClientZip,
                    Phone: order.AgentPhone
                }
            };
        };

        const getTCEInfo = (order, resolve, reject) => {
            if (order.RepId !== null) {
                const rawSql = `SELECT e.FirstName, e.LastName, e.Email FROM \`employees\` as e
                WHERE e.RepId=${order.RepId}`;
                Bookshelf.knex.raw(rawSql)
                    .then(result => {
                        resolve(result[0][0]);
                    })
                    .catch(() => {
                        reject({});
                    });
            } else {
                resolve({
                    FirstName: "",
                    LastName: ""
                });
            }
        };

        const getOrderMainFeeInfo = async (theOrderId) => {

            let response = 0;
            let loanTypeId = 0;
            await new Promise(resolve => Order.where({
                orderId: theOrderId
            }).fetch({
                columns: ["loanType"]
            }).then((order) => {
                loanTypeId = order.get("loanType");
                resolve();
            }));

            const sql = `select of.signerFee, lt.LoanType, of.brokerFee from order_fee of
            left join broker_fee bf on of.FeeDescripID = bf.FeeId
            left join loan_type lt on lt.LoanTypeId=bf.LoanTypeId
            where bf.loanTypeId = ${loanTypeId} and of.OrderID = ${theOrderId} and(bf.IsAdditionalFee = 0 or bf.IsAdditionalFee is null) `;

            await new Promise(resolve => Bookshelf.knex.raw(sql).then(result => {
                response = {
                    signerFee: result[0][0].signerFee,
                    LoanType: result[0][0].LoanType,
                    brokerFee: result[0][0].brokerFee
                };
                resolve();
            }));
            return response;
        };

        // from order id, get the user who created this order
        const rawSql = `SELECT 
                            o.AgentId, o.BrokerId, o.CourierID, c.Courier, o.CourierAcntNumber, o.TrackingNumber, o.TrackingNumber2,
                            o.BrokerIdNum, o.ProgressId, o.SignerFee, o.LoanType, o.aptDateTime, o.AptUTC,
                            o.OrderId, o.CreatedBy, u.MappingUserId, o.RepId, o.IsSelfService,
                            o.CustomerId, cu.Name as CustomerName, o.NeedReviewPCResolution, o.IsPrimaryDocReview,
                            o.SpecialInstructions, o.Collect1, o.Collect2, o.Collect3, o.Collect4, o.Collect5, o.Collect6, o.Collect7, o.Collect8, o.Collect9, o.Collect10,
                            o.DocumentCompletedDate, o.TurnAroundDate,
                            o.BrokerId, b2.Company as BrokerCompanyName, b2.GID as gid,
                            b3.Company as GidCompanyName,
                            e.Email as EmployeeEmail,
                            a.Email as AgentEmail, a.Direct as AgentPhone, a.AfterhoursPhone as AgentAfterhoursPhone, a.FullName as AgentFullName,
                            ba.Company as ClientCompanyName, ba.Address as ClientAddress, ba.Suite as ClientSuite, ba.City as ClientCity, ba.State as ClientState, ba.Zip as ClientZip, ba.Phone as ClientPhone,
                            o.FirstName, o.LastName, o.LanguageID, l1.Language as Language, o.WorkPhone, o.HomePhone, o.Email, o.Suite,
                            o.CoFirstName, o.CoLastName, o.CoLanguageId, l2.Language as CoLanguage, o.CoWorkPhone, o.CoHomePhone, o.CoEmail,
                            o.IsNeedPreCall, IsOrderRequiredFee(o.OrderId, 'Edocs') AS RequiredEdoc                          
                        FROM \`order\` o
                        LEFT JOIN \`users\` u ON o.CreatedBy = u.UsersId
                        LEFT JOIN \`broker\` b ON u.MappingUserId = b.BrokerID
                        LEFT JOIN \`broker\` b2 ON o.BrokerId = b2.BrokerID
                        LEFT JOIN \`broker\` b3 ON b2.GID = b3.BrokerID
                        LEFT JOIN \`language\` l1 ON l1.LanguageID = o.LanguageId
                        LEFT JOIN \`language\` l2 ON l2.LanguageID = o.CoLanguageId
                        LEFT JOIN \`agent\` a ON o.AgentId = a.AgentId
                        LEFT JOIN \`broker\` ba ON a.BrokerId=ba.BrokerId
                        LEFT JOIN \`courier\` c ON o.CourierID = c.CourierID
                        LEFT JOIN \`customers\` cu ON o.CustomerId = cu.CustomerId
                        LEFT JOIN \`employees\` AS e ON o.RepId = e.RepId
                        WHERE o.OrderId = ${orderId};`;

        Bookshelf.knex.raw(rawSql).then((rs) => {
            if (!rs) reply(Boom.badRequest("Order is not found"));

            const order = rs[0][0];
            const {
                gid,
                BrokerId
            } = order;

            const getAdditionalRequestPromise = new Promise((resolve, reject) => {
                getAdditionalFees({
                    orderId,
                    brokerId: gid && gid > 0 ? gid : BrokerId
                }, data => {
                    if (!data) reject("Not Found");

                    const listSelectedAdditional = data.defaultAdditionalFee.map((i) => {
                        return {
                            FeeDescripID: i.FeeDescripID,
                            FeeDescription: i.FeeDescription,
                            SignerFee: i.SignerFee
                        };
                    });

                    resolve({
                        listSelectedAdditional
                    });
                }, err => reject(err));
            });

            const getTotalFees = new Promise((resolve, reject) => {
                getTotalOrderFees(orderId, (data) => resolve(data), error => reject(error));
            });

            const getMainFee = new Promise((resolve, reject) => {
                getOrderMainFeeInfo(orderId).then((data) => {
                    resolve(data);
                }).catch(() => {
                    reject();
                });
            });

            const getTCE = new Promise((resolve, reject) => {
                getTCEInfo(order, resolve, reject);
            });

            const getCouriersPromise = new Promise((resolve, reject) => {
                getAllCouriers(data => resolve(data), err => reject(err));
            });

            Promise.all([
                getOrderCustomers(order),
                getOrderInfo(order),
                getAgentInfo(order),
                getAdditionalRequestPromise,
                getTotalFees,
                getMainFee,
                getTCE,
                getCouriersPromise
            ]).then((values) => {
                const data = {};
                data.fee = {};

                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.customer = item.customer;
                                    data.coCustomer = item.coCustomer;
                                    break;
                                case 1:
                                    data.orderInfo = item.orderInfo;
                                    break;
                                case 2:
                                    data.agentInfo = item.agentInfo;
                                    break;
                                case 3:
                                    data.fee.listSelectedAdditional = item.listSelectedAdditional;
                                    break;
                                case 4:
                                    data.fee.totalFee = item;
                                    break;
                                case 5:
                                    data.fee.mainFee = item;
                                    break;
                                case 6:
                                    data.TCE = item || {};
                                    break;
                                case 7:
                                    data.listCouriers = item;
                            }
                        }
                    });

                    reply(data);
                } else {
                    reply(Boom.badRequest({
                        message: "Error!"
                    }));
                }
            });
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }

    getVendorOrderDetailMainPanelInitData(request, reply) {
        const {
            orderId
        } = request.query;

        const getSpecialIns = new Promise((resolve, reject) => {
            const rawSql = `SELECT * FROM order_special_instructions where OrderId=${orderId}`;
            Bookshelf.knex.raw(rawSql)
                .then(result => {
                    resolve(result[0][0]);
                })
                .catch(() => {
                    reject({});
                });
        });

        Promise.all([
            getSpecialIns
        ]).then((values) => {
            const data = {};

            if (values !== null) {
                values.forEach((item, index) => {
                    if (item !== null) {
                        switch (index) {
                            case 0:
                                data.specialInstruction = item;
                                break;
                        }
                    }
                });

                reply(data);
            } else {
                reply(Boom.badRequest({
                    message: "Error!"
                }));
            }
        });
    }
    //check order service when client place an order
    checkOrderService(request, reply) {
        const {
            brokerId,
            orderId
        } = request.query;

        const rawSqlGetClient = `SELECT IF(b.GID IS NOT NULL AND b.GID <> 0, b.GID, ${brokerId}) as ClientId, AssignOrdersDirectly, TceFullFill FROM broker b WHERE b.BrokerID = ${brokerId}`;
        const data = {};

        Bookshelf.knex.raw(rawSqlGetClient)
            .then(async returnClient => {
                data.clientId = returnClient[0][0].ClientId || 0;
                data.assignOrdersDirectly = bufferToBoolean(returnClient[0][0].AssignOrdersDirectly);
                data.tceFullFill = bufferToBoolean(returnClient[0][0].TceFullFill);

                // //check program of client
                // const rawSqlCheckClientProgram = `SELECT b.Program FROM broker b WHERE b.BrokerID = ${data.clientId};`;
                // let checkProgram = 0;

                // await new Promise((resolve) => Bookshelf.knex.raw(rawSqlCheckClientProgram)
                //     .then(value => {
                //         const rawData = value[0][0] || {};
                //         checkProgram = rawData.Program;
                //         resolve();
                //     }).catch(err => {
                //         reply(Boom.badRequest(err));
                //     }));

                // if (Number(checkProgram) !== 3) {
                //     reply({
                //         isSelfService: true,
                //         program: checkProgram || 1
                //     }); //it's seflservice if client's program is not elite
                //     return;
                // }

                // the new order will be full service if AssignOrdersDirectly flag is unchecked
                if (!data.assignOrdersDirectly) {
                    reply({
                        isSelfService: false
                    });

                    return;
                }

                // the new order be self service
                if (data.assignOrdersDirectly && !data.tceFullFill) {
                    reply({
                        isSelfService: true
                    });

                    return;
                }

                // new order is self or full service will depend on config

                //get client's order details data and total orders of client today
                const rawSqlGetOrderDetail = `SELECT o.City, o.State FROM \`order\` o WHERE o.OrderId = ${orderId};`;
                const rawSqlCountTotalOrderToDay = `SELECT COUNT(o.OrderId) as totalOrderToday FROM \`order\` o WHERE o.BrokerId = ${data.clientId} AND DATE(o.OrderDate) = DATE(UTC_TIMESTAMP());`;

                await new Promise((resolve) => Bookshelf.knex.raw(rawSqlGetOrderDetail)
                    .then(value => {
                        const rawData = value[0][0] || {};
                        data.city = rawData.City;
                        data.state = rawData.State;
                        resolve();
                    }).catch(err => {
                        reply(Boom.badRequest(err));
                    }));

                await new Promise((resolve) => Bookshelf.knex.raw(rawSqlCountTotalOrderToDay)
                    .then(value => {
                        const rawData = value[0][0] || {};
                        data.totalOrderToday = rawData.totalOrderToday;
                        resolve();
                    }).catch(err => {
                        reply(Boom.badRequest(err));
                    }));

                //get client's service configuration
                const rawSqlGetClientServiceConfig = `SELECT csc.UseCalendar,
                                                            csc.UseGeography,
                                                            csc.UseVolume,
                                                            DAY(UTC_TIMESTAMP()) <= csc.CutoffDate AS isValidUseCalendar,
                                                            ${data.totalOrderToday} < csc.OrderPerDay AS isValidUseVolume,
                                                            csc.State1 LIKE CONCAT('%','${data.state}','%') AND IF(csc.MSA1, csc.MSA1 LIKE CONCAT('%','${data.city}','%'), TRUE) AS isValidGeography
                                                FROM client_services_config csc WHERE csc.ClientID = ${data.clientId} AND csc.EffecttiveDate IS NOT NULL
                                                ORDER BY csc.EffecttiveDate DESC LIMIT 0,1;`;


                await new Promise((resolve) => Bookshelf.knex.raw(rawSqlGetClientServiceConfig)
                    .then(value => {
                        data.isUserCalendar = false;
                        data.isUseGeography = false;
                        data.isUseVolume = false;
                        data.isValidUseCalendar = false;
                        data.isValidUseVolume = false;
                        data.isValidGeography = false;

                        if (value[0][0]) {
                            const rawData = value[0][0];
                            data.isUserCalendar = bufferToBoolean(rawData.UseCalendar);
                            data.isUseGeography = bufferToBoolean(rawData.UseGeography);
                            data.isUseVolume = bufferToBoolean(rawData.UseVolume);
                            data.isValidUseCalendar = rawData.isValidUseCalendar;
                            data.isValidUseVolume = rawData.isValidUseVolume;
                            data.isValidGeography = rawData.isValidGeography;
                        }

                        resolve();
                    }).catch(err => {
                        reply(Boom.badRequest(err));
                    }));

                const isSelfService = (data.isUserCalendar || data.isUseGeography || data.isUseVolume ?
                    (data.isUserCalendar ? data.isValidUseCalendar === 1 : true) &&
                    (data.isUseGeography ? data.isValidGeography === 1 : true) &&
                    (data.isUseVolume ? data.isValidUseVolume === 1 : true) :
                    false);

                reply({
                    isSelfService
                });

            }).catch(error => {
                reply(Boom.badRequest(error));
            });
    }

    checkOrderStatusForApprove(request, reply) {
        const {
            orderId
        } = request.query;

        const rawSql = "SELECT count(o.orderId) as orders FROM `order` o inner join progress p on o.ProgressId=p.ProgressId where p.ProgressDescription not in ('Closed Pending Review/PC Resolution', 'Closed Pending QC Review', 'Closing Completed', 'Post Close', 'Canceled') and OrderId= ";

        Bookshelf.knex.raw(rawSql.concat(orderId)).then((result) => {
            if (result !== null) {
                reply(result[0][0].orders > 0);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    checkExistOrderOpenByBrokerId(request, reply) {
        const {
            brokerId
        } = request.query;
        Order.where({
            brokerId,
            ProgressId: 1
        }).count("*").then((count) => {
            if (count > 0) {
                reply(true);
            } else {
                reply(false);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getRightPanelDocsData(request, reply) {
        let {
            orderId
        } = request.query;

        if (isNaN(orderId)) {
            reply(Boom.badRequest("Invalid parameters"));
            return;
        }

        orderId = +orderId;

        const sqlGetOrderDetail = `SELECT docDelMethod FROM \`order\` WHERE orderId = ${orderId};`;
        const sqlGetOrderDocs = `SELECT docId, fileName, description, archive, status, userId, archive, shared FROM order_docs WHERE orderId = ${orderId} and documentType = 1;`;
        const getOrderDetail = Promise.resolve(Bookshelf.knex.raw(sqlGetOrderDetail));
        const getOrderDocs = Promise.resolve(Bookshelf.knex.raw(sqlGetOrderDocs));

        Promise.all([getOrderDetail, getOrderDocs])
            .then(results => {
                if (results === null) {
                    reply(Boom.badRequest("Order does not exist!"));
                    return;
                }
                const orderDetail = results[0][0][0] || {};
                const orderDocs = results[1][0];
                orderDocs.forEach(doc => {
                    if (isBuffer(doc.archive)) doc.archive = bufferToBoolean(doc.archive);
                    if (isBuffer(doc.shared)) doc.shared = bufferToBoolean(doc.shared);
                });

                reply({
                    isSuccess: true,
                    orderDetail,
                    orderDocs
                });
            }).catch(error => {
                reply(Boom.badRequest(error));
            });
    }
    async sendOrderConfirmAndBasicInfo(request, reply) {
        const info = request.payload;
        const replyData = {};
        const renderHtmlContent = (rawContent) => {
            let returnTemplate = rawContent;

            returnTemplate = replaceAll(returnTemplate, "[orderId]", `${info.orderId}`);
            returnTemplate = replaceAll(returnTemplate, "[primaryFirstName]", `${info.primaryFirstName}`);
            returnTemplate = replaceAll(returnTemplate, "[primaryLastName]", `${info.primaryLastName}`);
            returnTemplate = replaceAll(returnTemplate, "[coFirstName]", `${info.coFirstName || ""}`);
            returnTemplate = replaceAll(returnTemplate, "[coLastName]", `${info.coLastName || ""}`);
            returnTemplate = replaceAll(returnTemplate, "[clientCompanyName]", `${info.clientCompanyName}`);
            returnTemplate = replaceAll(returnTemplate, "[aptDate, aptTime]", `${info.aptDate || ""} ${info.aptTime || ""}`);
            returnTemplate = replaceAll(returnTemplate, "[aptAddress]", `${info.aptAddress}, ${info.aptSuite ? `${info.aptSuite}, ` : ""}${info.aptCity}, ${info.aptState}`);
            returnTemplate = replaceAll(returnTemplate, "[propAptAddress]", `${hasStringValue(info.propAptAddress) ? `${info.propAptAddress}, ` : ""}${hasStringValue(info.propAptSuite) ? `${info.propAptSuite}, ` : ""}${hasStringValue(info.propAptCity) ? `${info.propAptCity}, ` : ""}${hasStringValue(info.propAptState) ? `${info.propAptState}, ` : ""}`);
            returnTemplate = replaceAll(returnTemplate, "[fileNo]", `${info.fileNo}`);

            return returnTemplate;
        };

        const sendEmail = async (rawSqlForTemplate, sendTo, callBackResolve, replyInfoName) => {
            await new Promise(sendMailResolve => Bookshelf.knex.raw(rawSqlForTemplate)
                .then(value => {
                    const rawTemplate = value[0][0] || {};
                    const subject = rawTemplate.Subject ? rawTemplate.Subject.replace("[orderId]", `${info.orderId}`).replace("[primaryLastName]", `${info.primaryLastName}`) : "";
                    const mailOptions = {
                        from: rawTemplate.FromEmail || "orders@theclosingexchange.com",
                        to: sendTo,
                        subject,
                        html: renderHtmlContent(rawTemplate.Message || "")
                    };

                    sendMailCore(mailOptions, (result) => {
                        replyData[replyInfoName] = result;
                        sendMailResolve();
                    });
                }).catch(err => {
                    reply(Boom.badRequest(err));
                }));

            callBackResolve();
        };

        if (info.isSendConfirmToPrimaryCustomer) {
            const rawSqlGetTemplatePriCustomer = `SELECT * FROM notification_templates nt WHERE nt.Purpose = '${NOTIFICATION_TEMPLATE_PURPOSE.SEND_CONFIRM_AND_BASIC_INFORMATION_SHARED_TO_PRIMARY_CUSTOMER}';`;
            await new Promise(resolve => sendEmail(rawSqlGetTemplatePriCustomer, info.primaryCustomerEmail, () => resolve(), "sendToPrimaryCustomerReply"));
        }

        if (info.isSendConfirmToCoCustomer) {
            const rawSqlGetTemplateCoCustomer = `SELECT * FROM notification_templates nt WHERE nt.Purpose = '${NOTIFICATION_TEMPLATE_PURPOSE.SEND_CONFIRM_AND_BASIC_INFORMATION_SHARED_TO_CO_CUSTOMER}';`;
            await new Promise(resolve => sendEmail(rawSqlGetTemplateCoCustomer, info.coCustomerEmail, () => resolve(), "sendToCoCustomerReply"));
        }

        const rawSqlGetTemplateAgentEmail = `SELECT * FROM notification_templates nt WHERE nt.Purpose = '${NOTIFICATION_TEMPLATE_PURPOSE.PLACE_NEW_ORDER}';`;
        await new Promise(resolve => sendEmail(rawSqlGetTemplateAgentEmail, info.agentEmail, () => resolve(), "sendToAgentReply"));

        reply(replyData);
    }

    async sendEmailCloseRequestForOrder(request, reply) {
        const {
            orderId
        } = request.query;
        let data = {};
        let templateMail = {};

        //get data to send mail of Order by orderId
        const rawSqlGetOrderData = ` select o.OrderId, o.TrackingNumber, o.FirstName, o.LastName, o.AptDateTime, o.BrokerIdNum, b.Company, a.Email  from \`order\` o 
                                    left join broker b on b.BrokerID = o.BrokerId left join agent a on a.AgentId = o.AgentId where o.orderId = ${orderId};`;

        await new Promise(resolve => Bookshelf.knex.raw(rawSqlGetOrderData)
            .then(result => {
                if (result[0][0]) data = result[0][0];
                resolve();
            }).catch(err => {
                reply(Boom.badRequest(err));
            })
        );

        //get template mail to send
        const rawSqlGetTemplate = `SELECT * FROM notification_templates nt WHERE nt.Purpose = '${hasStringValue(data.TrackingNumber) ? NOTIFICATION_TEMPLATE_PURPOSE.CLOSE_ORDER_HAVING_TRACKING_NUMBER : NOTIFICATION_TEMPLATE_PURPOSE.CLOSE_ORDER_HAVE_NO_TRACKING_NUMBER}';`;
        await new Promise(resolve => Bookshelf.knex.raw(rawSqlGetTemplate)
            .then(result => {
                if (result[0][0]) templateMail = result[0][0];
                resolve();
            }).catch(err => {
                reply(Boom.badRequest(err));
            })
        );

        //render email content and subject
        const subject = templateMail.Subject.replace("[orderId]", orderId).replace("[fileNo]", data.BrokerIdNum);
        let htmlContent = templateMail.Message;

        htmlContent = replaceAll(htmlContent, "[orderId]", orderId);
        htmlContent = replaceAll(htmlContent, "[companyName]", data.Company);
        htmlContent = replaceAll(htmlContent, "[primaryCustomerLastName]", data.LastName);
        htmlContent = replaceAll(htmlContent, "[fileNo]", data.BrokerIdNum);
        htmlContent = replaceAll(htmlContent, "[aptDateTime]", data.AptDateTime);
        htmlContent = replaceAll(htmlContent, "[primaryCustomerFirstName]", data.FirstName);
        htmlContent = replaceAll(htmlContent, "[trackingNumber]", data.TrackingNumber);

        const mailOptions = {
            from: templateMail.FromEmail || "weborders@notarydirect.com",
            to: data.Email,
            subject,
            html: htmlContent
        };

        sendMailCore(mailOptions, (result) => {
            reply(result.error ? {
                error: result.error
            } : {
                    isSuccess: true
                });
        });
    }

    getOrdersProgressId(request, reply) {
        const {
            orderId
        } = request.query;

        const rawSql = `SELECT ProgressId AS progressId FROM \`order\` WHERE orderId=${orderId}`;

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                reply(result[0][0]);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    updateProgressManually(request, reply) {
        const orderProgressId = request.payload;

        Order.where({
            OrderId: orderProgressId.orderId
        }).save(orderProgressId, {
            method: "update"
        }).then((result) => {
            if (result !== null) {
                reply({
                    isSuccess: true
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    checkValidOrderId(request, reply) {
        const {
            orderId,
            roleName,
            userId
        } = request.query;

        const rawSql = `SELECT OrderId FROM \`order\` WHERE orderId=${orderId} AND Inactive = 0`;

        const clientSql = `SELECT OrderId FROM \`order\` WHERE (BrokerId=${userId} OR BrokerId IN (SELECT BrokerId FROM \`broker\` WHERE GID = ${userId}) OR AgentId IN (SELECT AgentId FROM \`agent\` WHERE BrokerId IN (SELECT BrokerId FROM \`broker\` WHERE GID = ${userId}))) AND orderId=${orderId}`;

        const branchSql = `SELECT OrderId FROM \`order\` WHERE (BrokerId=${userId} OR AgentId IN (SELECT AgentId FROM \`agent\` WHERE BrokerId = ${userId})) AND orderId=${orderId}`;

        const agentSql = `SELECT OrderId FROM \`order\` WHERE AgentId=${userId} AND orderId=${orderId}`;

        const vendorSql = `SELECT OrderId FROM \`order\` WHERE SignerId=${userId} AND orderId=${orderId}`;

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0][0] !== "" && result[0][0] !== null && result[0][0] !== undefined) {
                    switch (roleName) {
                        case "Client":
                            Bookshelf.knex.raw(clientSql).then((scopeResult) => {
                                if (scopeResult[0][0] === "" || scopeResult[0][0] === null || scopeResult[0][0] === undefined) {
                                    reply({
                                        isValid: false,
                                        scope: scopeResult[0][0]
                                    });
                                } else {
                                    reply({
                                        isValid: true,
                                        scope: scopeResult[0][0]
                                    });
                                }
                            }).catch((error) => {
                                reply(Boom.badRequest(error));
                            });
                            break;
                        case "Branch":
                            Bookshelf.knex.raw(branchSql).then((scopeResult) => {
                                if (scopeResult[0][0] === "" || scopeResult[0][0] === null || scopeResult[0][0] === undefined) {
                                    reply({
                                        isValid: false
                                    });
                                } else {
                                    reply({
                                        isValid: true
                                    });
                                }
                            }).catch((error) => {
                                reply(Boom.badRequest(error));
                            });
                            break;
                        case "Agent":
                            Bookshelf.knex.raw(agentSql).then((scopeResult) => {
                                if (scopeResult[0][0] === "" || scopeResult[0][0] === null || scopeResult[0][0] === undefined) {
                                    reply({
                                        isValid: false
                                    });
                                } else {
                                    reply({
                                        isValid: true
                                    });
                                }
                            }).catch((error) => {
                                reply(Boom.badRequest(error));
                            });
                            break;
                        case "Vendor":
                            Bookshelf.knex.raw(vendorSql).then((scopeResult) => {
                                if (scopeResult[0][0] === "" || scopeResult[0][0] === null || scopeResult[0][0] === undefined) {
                                    reply({
                                        isValid: false
                                    });
                                } else {
                                    reply({
                                        isValid: true
                                    });
                                }
                            }).catch((error) => {
                                reply(Boom.badRequest(error));
                            });
                            break;
                        default:
                            reply({
                                isValid: true
                            });
                            break;
                    }
                } else {
                    reply({
                        isValid: false,
                        hello: "hello"
                    });
                }
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
        return;
    }

    getAllProblemTypes(request, reply) {
        const rawSql = `SELECT * FROM problem_types`;

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                const data = result[0];
                reply(data);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    checkIsSelfService(request, reply) {
        const {
            orderId
        } = request.query;

        const rawSql = `SELECT IsSelfService FROM \`order\` WHERE orderId=${orderId}`;

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                reply({
                    isSelfService: bufferToBoolean(result[0][0].IsSelfService)
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    checkAssignVendor(request, reply) {
        const {
            orderId
        } = request.query;

        const rawSql = `SELECT FilledDate FROM \`order\` WHERE orderId=${orderId}`;

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0][0].FilledDate !== null) {
                    reply({
                        isAssignVendor: true
                    });
                } else {
                    reply({
                        isAssignVendor: false
                    });
                }
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    async setOrderProgress(request, reply) {
        const {
            orderId,
            progressId,
            cancellationReason,
            requiredPreCall
        } = request.payload;

        const currentDate = moment().utc().format("YYYY-MM-DD HH:mm:ss");

        const orderData = {
            progressId,
            cancellationReason: cancellationReason === undefined ? null : cancellationReason
        };

        let requiredEdoc = false;

        const orderObj = await Bookshelf.knex.raw(`SELECT IsOrderRequiredFee(${orderId}, 'Edocs') AS RequiredEdoc`);

        if (!orderObj || !orderObj[0] || !orderObj[0][0]) {
            reply(Boom.badRequest("Order not found"));
            return;
        }

        requiredEdoc = bufferToBoolean(orderObj[0][0].RequiredEdoc);

        /**AnNV2: Update UCC12, UCS3.1
         * Role to change order's status
         */
        const iProgressId = Number(progressId);

        if (iProgressId === ORDER_PROGRESS_ID.APPT_CONFIRMED_PENDING_DOCS) {
            orderData.turnAroundDate = currentDate
        }

        if (requiredEdoc && iProgressId === ORDER_PROGRESS_ID.PENDING_PRE_CALL) {
            orderData.documentCompletedDate = currentDate
        }

        if (!requiredEdoc && iProgressId === ORDER_PROGRESS_ID.PENDING_PRE_CALL) {
            orderData.turnAroundDate = currentDate
        }

        if (requiredEdoc && requiredPreCall && iProgressId === ORDER_PROGRESS_ID.APPT_READY) {
            orderData.aptReadyDate = currentDate
        }

        if (requiredEdoc && !requiredPreCall && iProgressId === ORDER_PROGRESS_ID.APPT_READY) {
            orderData.turnAroundDate = currentDate
        }

        if (!requiredEdoc && iProgressId === ORDER_PROGRESS_ID.APPT_READY) {
            orderData.turnAroundDate = currentDate
        }

        if (iProgressId === ORDER_PROGRESS_ID.UNSUCCESSFUL || iProgressId === ORDER_PROGRESS_ID.CLOSED_PENDING_QC_REVIEW || ORDER_PROGRESS_ID.CLOSED_PENDING_REVIEW_PC_RESOLUTION) {
            orderData.closingWorksheetDate = currentDate
        }

        if (iProgressId === ORDER_PROGRESS_ID.CLOSING_COMPLETED) {
            orderData.closedDate = currentDate;
        }

        if (iProgressId === ORDER_PROGRESS_ID.CANCELED) {
            orderData.canceledDate = currentDate;
        }

        Order.where({
            orderId
        }).save(orderData, {
            method: "update"
        }).then(async () => {
            let signerId = 0;
            await new Promise((resolve => Order.where({
                orderId
            }).fetch({
                columns: ["signerId"]
            }).then((model) => {
                signerId = model.get("signerId");
                resolve();
            })));
            if (signerId !== null) {
                const usersId = await getUsersIdByMappingUserIdAndRoleName(signerId, "Vendor");
                let progressDescription = "";
                const progressSql = `SELECT progressDescription FROM progress Where progressId= ${progressId}`;
                await new Promise((resolve => Bookshelf.knex.raw(progressSql).then((result) => {
                    progressDescription = result[0][0].progressDescription;
                    resolve();
                })));

                const activity = `Order ID ${orderId} has status changed to ${progressDescription}`;
                await new Promise((resolve => new OrderProgressLog().save({
                    orderId,
                    dateLog: currentDate,
                    progressType: 5,
                    activity,
                    usersId
                }, {
                        method: "insert"
                    }).then(() => {
                        resolve();
                    })));

                sendSNSMessage(usersId, `{\\"aps\\":{\\"alert\\":\\"${activity}\\",\\"type\\":\\"order\\",\\"orderId\\":\\"${orderId}\\"}}`);
            }

            reply({
                isSuccess: true
            });
        }).catch(error => reply(Boom.badRequest(error)));
    }

    setOrderAgent(request, reply) {
        const {
            orderId,
            agentId
        } = request.payload;
        Order.where({
            orderId
        }).save({
            agentId
        }, {
                method: "update"
            }).then(() => {
                reply({
                    isSuccess: true
                });
            }).catch(error => reply(Boom.badRequest(error)));
    }

    async mobileGetOrderDetail(request, reply) {
        const {
            orderId
        } = request.query;
        const replyObject = {};

        const orderDetailSql = `SELECT o.progressid, p.progressDescription, br.company,
        o.suite, o.address, o.city, o.state, o.zip, o.aptDateTime, o.firstName,
        o.lastName, o.homePhone, o.workPhone, o.email, o.coFirstName, o.coLastName,
        o.coHomePhone, o.coWorkPhone, o.coEmail, lt.loanType, z.utc as aptUTC,
        (SELECT SUM(of.signerFee) FROM order_fee of WHERE of.orderId= ${orderId}) as vendorFee
        FROM \`order\` o
        LEFT JOIN progress p on o.progressId = p.progressId
        LEFT JOIN broker br on br.brokerId = o.brokerId
        LEFT JOIN loan_type lt on lt.loanTypeId = o.loanType
        LEFT JOIN zip z on z.zip = o.zip
        Where o.orderId = ${orderId}`;

        const orderDocsSql = `SELECT od.description,
        od.fileSize, od.uploadedDate, od.\`viewed\`, od.docId, od.documentType
        FROM order_docs od
        WHERE (od.archive is null or od.archive = 0) AND od.orderId = ${orderId}`;

        const orderAdditionalFeeSql = `SELECT bf.feeDescription FROM order_fee of
        LEFT JOIN broker_fee bf on of.feeDescripId = bf.feeId
        WHERE of.orderId = ${orderId} AND bf.isAdditionalFee = 1`;

        await new Promise((resolve) => Bookshelf.knex.raw(orderDetailSql).then((result) => {
            if (result !== null) {
                replyObject.orderDetailSpecificDataModel = result[0][0];
                resolve();
            }
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Bookshelf.knex.raw(orderDocsSql).then((result) => {
            if (result !== null) {
                const resultData = result[0];
                resultData.forEach(data => {
                    Object.keys(data).forEach((key) => {
                        const value = data[key];
                        if (isBuffer(value)) {
                            data[key] = bufferToBoolean(value);
                        }
                    });
                });
                replyObject.listOrderDetailDocDataModel = resultData;
                resolve();
            }
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Bookshelf.knex.raw(orderAdditionalFeeSql).then((result) => {
            if (result !== null) {
                replyObject.orderAdditionalFeeModel = result[0];
                resolve();
            }
        }).catch(error => reply(Boom.badRequest(error))));

        reply(replyObject);
    }

    mobileSetSigningTime(request, reply) {
        const {
            orderId,
            aptDatetime
        } = request.payload;

        const aptDate = hasStringValue(aptDatetime) ? moment(aptDatetime).format("YYYY-MM-DD HH:mm:ss") : null;

        OrderDocs.query((qb) => {
            qb.where("orderId", "=", `${orderId}`).andWhere("archive", null);
        }).count("*").then(async (count) => {
            const isHasEDocs = count > 0;
            let progressId = ORDER_PROGRESS_ID.OPEN;
            if (isHasEDocs) {
                progressId = ORDER_PROGRESS_ID.APPT_CONFIRMED_PENDING_DOCS;
            } else {
                let isNeedPreCall = false;
                await new Promise((resolve) => Order.where({
                    orderId
                }).fetch({
                    columns: ["isNeedPreCall"]
                }).then((model) => {
                    isNeedPreCall = bufferToBoolean(model.get("isNeedPreCall"));
                    resolve();
                }).catch(error => reply(Boom.badRequest(error))));

                progressId = isNeedPreCall ? ORDER_PROGRESS_ID.PENDING_PRE_CALL : ORDER_PROGRESS_ID.APPT_READY;
            }

            Order.where({
                orderId
            }).save({
                aptDatetime: aptDate,
                turnAroundDate: moment().utc().format("YYYY-MM-DD HH:mm:ss"),
                progressId
            }, {
                    method: "update"
                }).then(() => {
                    reply({
                        isSuccess: true
                    });
                }).catch(error => reply(Boom.badRequest(error)));
        }).catch(error => reply(Boom.badRequest(error)));
    }

    mobileSetOrderStatus(request, reply) {
        const {
            orderId,
            progressId
        } = request.payload;
        Order.where({
            orderId
        }).save({
            progressId
        }, {
                method: "update"
            }).then(() => {
                if (progressId.toString() === `${ORDER_PROGRESS_ID.CLOSED_PENDING_REVIEW_PC_RESOLUTION}`) {
                    Order.where({
                        orderId
                    }).fetch({
                        columns: ["firstName", "lastName", "email", "progressId"]
                    }).then((order) => {
                        NotificationTemplate.where({
                            purpose: "Feedback"
                        }).fetch({
                            columns: ["message", "subject", "fromEmail"]
                        }).then((template) => {
                            let subject = template.get("subject");
                            let message = template.get("message");
                            subject = replaceAll(subject, ["[OrderID]"], `${orderId}`);
                            message = replaceAll(message, ["[OrderID]"], `${orderId}`);
                            message = replaceAll(message, ["[CustomerName]"], `${order.get("firstName")} ${order.get("lastName")}`);
                            const mailOptions = {
                                from: template.get("fromEmail"),
                                to: order.get("email"),
                                subject,
                                html: message
                            };
                            sendMailCore(mailOptions);
                        }).catch(error => reply(Boom.badRequest(error)));
                    }).catch(error => reply(Boom.badRequest(error)));
                }
                reply({
                    isSuccess: true
                });
            }).catch(error => reply(Boom.badRequest(error)));
    }

    getOrderProgressGroup(request, reply) {
        const {
            userId,
            clientId,
            role
        } = request.query;
        Bookshelf.knex.raw(`call GetOrdersProcessGroup(${userId},${clientId},'${role}');`)
            .then(value => {
                const data = {};
                if (value !== null) {
                    data.groupStatus = value[0][0];
                }
                reply(data);
                return reply;
            }).catch(err => {
                reply(Boom.badRequest(err));
                return reply;
            });
    }

    getOrderProgressClientDashboard(request, reply) {
        let {
            role,
            clientId
        } = request.query;

        role = handleSingleQuote(role);
        clientId = handleSingleQuote(clientId);

        Bookshelf.knex.raw(`call GetOrderProgressClientDashboard('${role}','${clientId}');`)
            .then(value => {
                const data = {};
                if (value !== null) {
                    data.Unassigned = value[0][0];
                    data.Unfilled = value[0][1];
                    data.Unconfirmed = value[0][2];
                    data.PendingDocs = value[0][3];
                    data.Incomplete = value[0][4];
                    data.FaxBacks = value[0][5];
                }
                reply(data);
                return reply;
            }).catch(err => {
                reply(Boom.badRequest(err));
                return reply;
            });
    }

    updateOrder(request, reply) {
        const order = request.payload;
        Order.where({
            orderId: order.orderId
        }).save(order, {
            method: "update"
        }).then(() => reply({
            isSuccess: true
        })).catch(err => {
            reply(Boom.badRequest(err));
            return reply;
        });
    }
    ///
    getUserNameScheduler(request, reply) {
        const {
            orderId
        } = request.query;

        const rawSql = `Select o.OrderId, o.RepId, e.Email, e.FirstName, e.LastName From \`order\` AS o
        INNER JOIN employees AS e ON o.RepId = e.RepId and OrderId= ${orderId} `;

        let nameScheduler = "";

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    const firstName = result[0][0].FirstName;
                    const lastName = result[0][0].LastName;
                    nameScheduler = `${firstName} ${lastName}`;
                }
                reply({
                    nameScheduler,
                    isSuccess: true
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getFaxBackReq(request, reply) {
        const {
            orderId
        } = request.query;
        Order.where({
            orderId
        }).fetch({
            columns: ["orderId", "faxBackReq"]
        }).then((result) => {
            const order = result.attributes;
            Object.keys(order).forEach((key) => {
                const value = order[key];
                if (isBuffer(value)) {
                    order[key] = bufferToBoolean(value);
                }
            });
            reply(order);
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    checkFileNoUnique(request, reply) {
        const {
            orderId,
            brokerIdNum
        } = request.query;

        const rawSql = `Select OrderId From \`order\` WHERE OrderId <> ${orderId} AND BrokerIdNum='${brokerIdNum}'`;

        Bookshelf.knex.raw(rawSql).then((result) => {
            reply({
                isDuplicate: result !== null && result[0].length > 0
            });

        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getOtherDetailsData(request, reply) {
        const {
            orderId
        } = request.query;
        const rawSql = `select IsNeedPreCall, NeedReviewPCResolution from \`order\` where OrderId = ${orderId};`;
        const otherDetailsData = {};

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    result[0].map((item) => {
                        otherDetailsData.IsNeedPreCall = bufferToBoolean(item.IsNeedPreCall);
                        otherDetailsData.NeedReviewPCResolution = bufferToBoolean(item.NeedReviewPCResolution);
                    });
                }
                reply(otherDetailsData);
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    updatePreCall(request, reply) {
        const data = request.payload;
        const rawSql = `update \`order\` set IsNeedPreCall = ${data.isNeedPreCall} where OrderId = ${data.orderID}`;
        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    updateDocsReview(request, reply) {
        const data = request.payload;
        const rawSql = `update \`order\` set NeedReviewPCResolution = ${data.NeedReviewPCResolution} where OrderId = ${data.orderID}`;
        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({
                        isSuccess: true
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    async validateOrderBeforeChangeStatus(request, reply) {
        const { orderId, newStatus } = request.query;

        const rawSql = `SELECT ValidateOrderBeforeChangeStatus(${orderId}, '${newStatus}') AS ErrorCode;`;

        const result = await Bookshelf.knex.raw(rawSql);

        if (result && result[0] && result[0][0]) {
            reply({
                errorCode: result[0][0].ErrorCode
            });

            return;
        }

        reply(Boom.badRequest(error));
    }

    async getOrderCustomerFeedback(request, reply) {
        const { orderId } = request.query;

        const orderDetailResult = Promise.resolve(Bookshelf.knex.raw(`SELECT CustomerFeedback FROM \`order\` WHERE OrderId=${orderId}`));
        const customerFeedBack = Promise.resolve(Bookshelf.knex.raw(`SELECT FbId as feedbackId, OrderId as orderId, Comment as comment, CreatedBy as createdBy, CreatedDate as createdDate, u.UserName as userName
                                                                        FROM \`order_customer_feedback\` c 
                                                                        INNER JOIN \`users\` u ON c.CreatedBy = u.UsersId
                                                                        WHERE OrderId=${orderId} ORDER BY c.CreatedDate`));
        const orderDetail = Promise.resolve(Bookshelf.knex.raw(`SELECT closingWorksheetDate, closedDate, CASE WHEN CustomerId IS NULL THEN 0 ELSE 1 END AS hasCustomer FROM \`order\` WHERE OrderId=${orderId}`));

        Promise.all([orderDetailResult, customerFeedBack, orderDetail])
            .then(value => {
                const data = {
                    feedbackOption: "E", // default
                    feedbackComments: [],
                    orderDetail: {
                        isClosingCompleted: false,
                        hasClosedByVendor: false,
                        hasCustomer: false
                    }
                };

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {

                            switch (index) {
                                case 0: {
                                    data.feedbackOption = item[0][0].CustomerFeedback;
                                    break;
                                }
                                case 1: {
                                    data.feedbackComments = item[0];
                                    break;
                                }
                                case 2: {
                                    data.orderDetail = {
                                        isClosingCompleted: item[0][0].closedDate !== null,
                                        hasClosedByVendor: item[0][0].closingWorksheetDate !== null,
                                        hasCustomer: item[0][0].hasCustomer === 1
                                    };
                                    break;
                                }
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    submitCustomerFeedback(request, reply) {
        const { feedbackOption, feedbackComments, orderId } = request.payload;

        Order.where({
            orderId: orderId
        }).save({ customerFeedback: feedbackOption }, {
            method: "update"
        }).then(() => {

            // save multi feedback
            if (feedbackComments) {
                feedbackComments.forEach(x => {
                    x.createdDate = moment(x.createdDate).utc().format("YYYY-MM-DD HH:mm:ss");
                });
            }

            const OrderCustomerFeedbacks = Bookshelf.Collection.extend({
                model: OrderCustomerFeedback
            });

            OrderCustomerFeedbacks.forge(feedbackComments).invokeThen("save").then((result) => {
                reply({
                    isSuccess: true
                });
            }).catch(error => {
                reply(Boom.badRequest(error));
            });
        }).catch(err => {
            reply(Boom.badRequest(err));
        });
    }
}

export default new OrderController();