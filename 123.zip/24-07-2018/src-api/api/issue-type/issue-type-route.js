import IssueTypeController from "./issue-type-controller";

const routes = [{
    path: "/issueType/getAllIssueType",
    method: "GET",
    handler: IssueTypeController.getAllIssueType
}];


export default routes;