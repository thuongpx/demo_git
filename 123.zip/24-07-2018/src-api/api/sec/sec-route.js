import SecController from "./sec-controller";

const routes = [
    {
        path: "/sec/getSecQuestionsForDropdown",
        method: "GET",
        config: {
            auth: false
        },
        handler: SecController.getSecQuestionsForDropdown
    },
    {
        path: "/sec/addSecAnswer",
        method: "POST",
        config: {
            auth: false
        },
        handler: SecController.addSecAnswer
    },
    {
        path: "/sec/deleteSecAnswers",
        method: "GET",
        handler: SecController.deleteSecAnswers
    },
    {
        path: "/sec/updateSecAnswers",
        method: "POST",
        handler: SecController.updateSecAnswers
    },
    {
        path: "/sec/getUserSecQuestion",
        method: "GET",
        config: { auth: false },
        handler: SecController.getUserSecQuestion
    },
    {
        path: "/sec/checkUserSecAnswer",
        method: "GET",
        config: { auth: false },
        handler: SecController.checkUserSecAnswer
    },
    {
        path: "/sec/getSecQuestionsOfUser",
        method: "GET",
        config: { auth: false },
        handler: SecController.getSecQuestionsOfUser
    },
    {
        path: "/sec/checkUserAnswer",
        method: "POST",
        config: { auth: false },
        handler: SecController.checkUserAnswer
    }
];

export default routes;