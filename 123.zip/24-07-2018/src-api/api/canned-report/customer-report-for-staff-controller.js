
import Bookshelf from "../../db/database";
import Boom from "boom";

import {
    distinctSingleValueArray,
    hasStringValue,
    replaceAll
} from "../../helper/common-helper";
import {
    buildSqlQuery,
    buildSqlCountQuery
} from "./canned-report";

class CustomerReportController {

    fetchClosedOrdersByCustomersChartData(request, reply) {
        const { searchObject } = request.payload;
        const { month } = searchObject;
        let { customer } = searchObject;

        const sqlResult = buildSqlQuery("closed_order_by_customer_chart_v", request.payload);
        const { sqlStr } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                const sortedMonth = month.sort((a, b) => {
                    return parseInt(a.value) - parseInt(b.value);
                });
                const monthLabel = distinctSingleValueArray(sortedMonth.map(item => item.label));
                const monthValue = distinctSingleValueArray(sortedMonth.map(item => item.value));
                let labels = distinctSingleValueArray(rawData.map(i => i.Name));
                const datasets = [];

                // get datasets
                if (customer === "All") {

                    for (let i = 0; i < monthLabel.length; i++) {
                        const tData = {
                            label: monthLabel[i],
                            data: []
                        };

                        const f = rawData.filter(r => (r.OrderMonth === parseInt(monthValue[i])));
                        tData.data.push(f ? f.length : 0);

                        datasets.push(tData);
                    }

                    labels = ["All Customers"];
                    // tData.data.push(orderId.length);
                    // datasets.push(tData);

                } else {
                    for (let i = 0; i < monthLabel.length; i++) {
                        const tData = {
                            label: monthLabel[i],
                            data: []
                        };
                        for (let j = 0; j < labels.length; j++) {
                            const f = rawData.filter(r => (r.Name === labels[j] && r.OrderMonth === parseInt(monthValue[i])));
                            tData.data.push(f ? f.length : 0);
                        }
                        datasets.push(tData);
                    }
                }

                // prepare temporary datasets to count total
                const totalDatasets = datasets[0].data.map(i => {
                    return {
                        value: i,
                        label: ""
                    };
                });

                // count total
                for (let i = 0; i < datasets.length; i++) {
                    for (let j = 0; j < totalDatasets.length; j++) {
                        if (i === 0) {
                            totalDatasets[j].label = labels[j];
                        } else {
                            totalDatasets[j].value += datasets[i].data[j];
                        }
                    }
                }

                // do sort
                totalDatasets.sort((a, b) => {
                    if (a.value > b.value) {
                        return -1;
                    }

                    if (a.value < b.value) {
                        return 1;
                    }

                    return 0;
                });

                const sortedLabels = totalDatasets.map(i => i.label);

                // sort data of datasets

                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];

                    for (let j = 0; j < sortedLabels.length; j++) {
                        const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                        newData.push(oldData[oldIndex]);
                    }
                    datasets[i].data = newData;
                }

                // get top of customers
                if (customer === "Top 10 And Others") {
                    customer = "Top10AndOthers";
                } else if (customer === "Top 20 And Others") {
                    customer = "Top20AndOthers";
                }
                let topNo = 0;

                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    default:
                        topNo = labels.length;
                        break;
                }

                labels = sortedLabels.filter((i, index) => index < topNo);

                if (customer !== "All" && hasStringValue(customer)) {
                    labels.push("Others");
                }

                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < labels.length; j++) {
                        if (labels[j] === "Others") {
                            // count other data
                            let otherData = 0;
                            for (let k = labels.length - 1; k < sortedLabels.length; k++) {
                                otherData += oldData[k];
                            }

                            newData.push(otherData);
                        } else {
                            newData.push(oldData[j]);
                        }
                    }
                    datasets[i].data = newData;
                }

                return reply({
                    labels,
                    datasets
                });

            }).catch(error => reply(Boom.badRequest(error)));
    }

}

export default new CustomerReportController();