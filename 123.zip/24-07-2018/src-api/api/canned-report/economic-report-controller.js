import Bookshelf from "../../db/database";
import Boom from "boom";
import {
    buildSqlQuery,
    buildSqlCountQuery
} from "./canned-report";

class EconomicReportController {
    constructor() { }

    fetchEconomicChartData(request, reply) {
        const sqlResult = buildSqlQuery("economic_chart_v", request.payload);
        const fetchStatus = request.payload.searchObject.status;
        const {
            sqlStr
        } = sqlResult;

        const execSql = `SELECT ofar.ReasonDescription, sum(ev.Approved + ev.Rejected + ev.Pending) as \`All\`,
        sum(ev.Approved) as Approved, sum(ev.Rejected) as Rejected, sum(ev.Pending) as Pending
        FROM \`order_fee_approve_reason\` \`ofar\` LEFT JOIN (${sqlStr}) ev on ofar.ReasonDescription = ev.ReasonDescription
        GROUP BY ofar.ReasonDescription;`;

        Bookshelf.knex.raw(execSql)
            .then(rs => {
                const rawData = rs[0];
                const labels = [];
                const listDataSets = {
                    All: {
                        label: "All Request",
                        data: []
                    },
                    Approved: {
                        label: "Approved",
                        data: []
                    },
                    Rejected: {
                        label: "Rejected",
                        data: []
                    },
                    Pending: {
                        label: "Pending",
                        data: []
                    }
                };

                rawData.map(item => {
                    labels.push(item.ReasonDescription);
                    listDataSets.All.data.push((item.Approved || 0) + (item.Rejected || 0) + (item.Pending || 0));
                    listDataSets.Approved.data.push((item.Approved || 0));
                    listDataSets.Rejected.data.push((item.Rejected || 0));
                    listDataSets.Pending.data.push((item.Pending || 0));
                });

                let datasets = [];

                if (Object.keys(fetchStatus).length === 0) {
                    datasets = [listDataSets.All, listDataSets.Approved, listDataSets.Rejected, listDataSets.Pending];
                } else {
                    Object.keys(fetchStatus).forEach(item => {
                        if (fetchStatus[item]) datasets.push(listDataSets[item]);
                    });
                }

                return reply({
                    labels,
                    datasets
                });
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countEconomicGridData(request, reply) {
        request.payload.searchObject.isGetDataForEconomicDrillDown = true;
        const sqlResult = buildSqlCountQuery("economic_drilldown_v", request.payload);

        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchEconomicGridData(request, reply) {
        request.payload.searchObject.isGetDataForEconomicDrillDown = true;
        const sqlResult = buildSqlQuery("economic_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];
                reply({
                    data
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    getDefaultEconomicAgent(request, reply) {
        const rawSql = `SELECT DISTINCT Agent as name, AgentId as id, count(agentId) as numOfRequest 
						FROM economic_drilldown_v GROUP BY agent, agentId 
						ORDER BY \`numOfRequest\` DESC;`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const defaultAgent = rs[0];
                const topTen = [];
                const replyData = [];
                let count = 0;

                defaultAgent.map(i => {
                    const data = { value: i.id, label: i.name };
                    replyData.push(data);
                    if (count < 10) {
                        topTen.push(data);
                        count++;
                    }
                });

                reply({
                    listAgent: replyData,
                    listToptenAgent: topTen
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }
}

export default new EconomicReportController();