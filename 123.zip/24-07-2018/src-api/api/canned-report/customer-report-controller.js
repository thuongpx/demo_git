import Bookshelf from "../../db/database";
import Boom from "boom";

import {
    distinctSingleValueArray,
    hasStringValue,
    replaceAll
} from "../../helper/common-helper";
import {
    buildSqlQuery,
    buildSqlCountQuery
} from "./canned-report";

class CustomerReportController {
    constructor() { }

    // Open order trend by customer
    fetchOpenOrderTrendByCustomersChartData(request, reply) {
        const { searchObject } = request.payload;
        const {
            month,
            customer
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_trend_chart_v", request.payload);

        const { sqlStr } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                const sortedMonth = month.sort((a, b) => {
                    return parseInt(a.value) - parseInt(b.value);
                });
                // console.log(sortedMonth, "month");
                // const monthData = distinctSingleValueArray(rawData.map(i => i.OrderMonth)); // build month
                const labelMonth = distinctSingleValueArray(sortedMonth.map(item => item.label));
                const labelValue = distinctSingleValueArray(sortedMonth.map(item => item.value));
                let labels = distinctSingleValueArray(rawData.map(i => i.customerName)); // build labels
                const datasets = [];

                if (customer === "All" || !customer) {

                    labels = ["All Customer"];
                    for (let i = 0; i < labelMonth.length; i++) {
                        const tData = {
                            label: labelMonth[i],
                            data: []
                        };
                        const f = rawData.filter(r => r.OrderMonth === parseInt(labelValue[i]));
                        tData.data.push(f ? f.length : 0);
                        datasets.push(tData);
                    }

                } else {
                    for (let a = 0; a < labelMonth.length; a++) {
                        const tData = {
                            label: labelMonth[a],
                            data: []
                        };
                        for (let j = 0; j < labels.length; j++) {
                            const f = rawData.filter(r => (r.customerName === labels[j] && r.OrderMonth === parseInt(labelValue[a])));
                            tData.data.push(f ? f.length : 0);
                        }
                        datasets.push(tData);
                    }
                }

                // prepare temporary datasets to count total
                const totalDatasets = datasets[0].data.map(i => {
                    return {
                        value: i,
                        label: ""
                    };
                });

                // count total
                for (let i = 0; i < datasets.length; i++) {
                    for (let j = 0; j < totalDatasets.length; j++) {
                        if (i === 0) {
                            totalDatasets[j].label = labels[j];
                        } else {
                            totalDatasets[j].value += datasets[i].data[j];
                        }
                    }
                }

                // do sort
                totalDatasets.sort((a, b) => {
                    if (a.value > b.value) {
                        return -1;
                    }

                    if (a.value < b.value) {
                        return 1;
                    }

                    return 0;
                });

                const sortedLabels = totalDatasets.map(i => i.label);
                // sort data of datasets
                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < sortedLabels.length; j++) {
                        const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                        newData.push(oldData[oldIndex]);
                    }
                    datasets[i].data = newData;
                }

                // get top of customers
                let topNo = 0;


                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    default:
                        topNo = labels.length;
                        break;
                }

                labels = sortedLabels.filter((i, index) => index < topNo);

                if (hasStringValue(customer) && customer !== "All") {
                    labels.push("Others");
                }

                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < labels.length; j++) {
                        if (labels[j] === "Others") {
                            // count other data
                            let otherData = 0;
                            for (let k = labels.length - 1; k < sortedLabels.length; k++) {
                                otherData += oldData[k];
                            }

                            newData.push(otherData);
                        } else {
                            newData.push(oldData[j]);
                        }
                    }
                    datasets[i].data = newData;
                }

                return reply({
                    labels,
                    datasets
                });
            }).catch(error => reply(Boom.badRequest(error)));
    }

    fetchOpenOrderTrendByCustomersGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            customer
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_customer_v", request.payload);
        const { sqlStr } = sqlResult;
        const rawSql = `SELECT c.Name as Customer
        , COUNT(OrderId) AS TotalOrder
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS Closed
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Pending') = 1 THEN 1 END) AS Pending    
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) AS Canceled   
        , CONCAT(ROUND(Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) / COUNT(OrderId) * 100, 2), " %") AS CancellationPercentage 
        FROM customers c 
        LEFT JOIN 
        (${sqlStr}) tbl ON c.CustomerId = tbl.CustomerId
        GROUP BY c.Name
        Order By TotalOrder desc`;
        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                let flag = false;
                const topData = [];
                let topNo = 0;
                let totalOrder = 0;
                let closed = 0;
                let pending = 0;
                let canceled = 0;
                let cancellationPercentage = 0;
                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = rs[0].length;
                        break;
                    default:
                        topNo = rs[0].length;
                        break;
                }
                if (topNo > rs[0].length) {
                    topNo = rs[0].length;
                    flag = true;
                }
                for (let i = 0; i < topNo; i++) {
                    topData.push(rs[0][i]);
                }
                for (let i = topNo; i < rs[0].length; i++) {
                    totalOrder += parseInt(rs[0][i].TotalOrder);
                    closed += parseInt(rs[0][i].Closed);
                    pending += parseInt(rs[0][i].Pending);
                    canceled += parseInt(rs[0][i].Canceled);
                    if (rs[0][i].CancellationPercentage) {
                        cancellationPercentage += replaceAll(rs[0][i].CancellationPercentage, " %", "") * 100;
                    }
                }

                if (hasStringValue(customer) && customer !== "All" && !flag) {
                    topData.push({ Customer: "Others", TotalOrder: totalOrder, Closed: closed, Pending: pending, Canceled: canceled, CancellationPercentage: `${(cancellationPercentage / 100).toFixed(2)} %` });
                }
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                reply({
                    data: topData
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countOpenOrderTrendByCustomersGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        const {
            customer
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_customer_v", request.payload);
        const { sqlStr } = sqlResult;

        const rawSql = `SELECT COUNT(*) AS Num FROM(SELECT c.Name as Customer   
            FROM customers c 
            LEFT JOIN
                                (${ sqlStr}) tbl ON c.CustomerId = tbl.CustomerId
            GROUP BY c.Name) a`;

        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }
                let data = 0;
                let topNo = 0;
                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = rs[0][0].Num;
                        break;
                    default:
                        topNo = rs[0][0].Num;
                        break;
                }
                if (topNo > rs[0][0].Num) {
                    topNo = rs[0][0].Num;
                }
                data = topNo;
                reply(data);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    // Milestones
    fetchMilestonesChartData(request, reply) {
        const sqlResult = buildSqlQuery("milestones_chart_v", request.payload);
        const { sqlStr } = sqlResult;
        const tData = {
            label: "All Data",
            data: []
        };

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                const labels = [1, 25, 50, 100, 250, 500];
                const datasets = [];

                for (let i = 0; i < labels.length; i++) {
                    const start = labels[i];
                    const end = (i === labels.length - 1) ? -1 : (labels[i + 1] - 1);
                    const f = rawData.filter(r => r.TotalClosedOrders >= start && (end === -1 || r.TotalClosedOrders < end));

                    tData.data.push(f.length);
                }

                datasets.push(tData);

                return reply({
                    labels,
                    datasets
                });

            }).catch(error => reply(Boom.badRequest(error)));
    }

    fetchMilestonesGridData(request, reply) {
        const sqlResult = buildSqlQuery("milestones_drilldown_v", request.payload);
        const { sqlStr } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }

                const data = rs[0];

                reply({ data });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countMilestonesGridData(request, reply) {
        const sqlResult = buildSqlCountQuery("milestones_drilldown_v", request.payload);
        const { sqlStr } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    // Closed order by customer
    fetchClosedOrdersByCustomersChartData(request, reply) {
        const { searchObject } = request.payload;
        const { month } = searchObject;
        let { customer } = searchObject;

        const sqlResult = buildSqlQuery("closed_order_by_customer_chart_v", request.payload);
        const { sqlStr } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                const rawData = rs[0];
                const sortedMonth = month.sort((a, b) => {
                    return parseInt(a.value) - parseInt(b.value);
                });
                const monthLabel = distinctSingleValueArray(sortedMonth.map(item => item.label));
                const monthValue = distinctSingleValueArray(sortedMonth.map(item => item.value));
                let labels = distinctSingleValueArray(rawData.map(i => i.Name));
                const datasets = [];

                // get datasets
                if (customer === "All") {

                    for (let i = 0; i < monthLabel.length; i++) {
                        const tData = {
                            label: monthLabel[i],
                            data: []
                        };

                        const f = rawData.filter(r => (r.OrderMonth === parseInt(monthValue[i])));
                        tData.data.push(f ? f.length : 0);

                        datasets.push(tData);
                    }

                    labels = ["All Customers"];
                    // tData.data.push(orderId.length);
                    // datasets.push(tData);

                } else {
                    for (let i = 0; i < monthLabel.length; i++) {
                        const tData = {
                            label: monthLabel[i],
                            data: []
                        };
                        for (let j = 0; j < labels.length; j++) {
                            const f = rawData.filter(r => (r.Name === labels[j] && r.OrderMonth === parseInt(monthValue[i])));
                            tData.data.push(f ? f.length : 0);
                        }
                        datasets.push(tData);
                    }
                }

                // prepare temporary datasets to count total
                const totalDatasets = datasets[0].data.map(i => {
                    return {
                        value: i,
                        label: ""
                    };
                });

                // count total
                for (let i = 0; i < datasets.length; i++) {
                    for (let j = 0; j < totalDatasets.length; j++) {
                        if (i === 0) {
                            totalDatasets[j].label = labels[j];
                        } else {
                            totalDatasets[j].value += datasets[i].data[j];
                        }
                    }
                }

                // do sort
                totalDatasets.sort((a, b) => {
                    if (a.value > b.value) {
                        return -1;
                    }

                    if (a.value < b.value) {
                        return 1;
                    }

                    return 0;
                });

                const sortedLabels = totalDatasets.map(i => i.label);

                // sort data of datasets

                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];

                    for (let j = 0; j < sortedLabels.length; j++) {
                        const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                        newData.push(oldData[oldIndex]);
                    }
                    datasets[i].data = newData;
                }

                // get top of customers
                if (customer === "Top 10 And Others") {
                    customer = "Top10AndOthers";
                } else if (customer === "Top 20 And Others") {
                    customer = "Top20AndOthers";
                }
                let topNo = 0;

                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    default:
                        topNo = labels.length;
                        break;
                }

                labels = sortedLabels.filter((i, index) => index < topNo);

                if (customer !== "All" && hasStringValue(customer)) {
                    labels.push("Others");
                }

                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < labels.length; j++) {
                        if (labels[j] === "Others") {
                            // count other data
                            let otherData = 0;
                            for (let k = labels.length - 1; k < sortedLabels.length; k++) {
                                otherData += oldData[k];
                            }

                            newData.push(otherData);
                        } else {
                            newData.push(oldData[j]);
                        }
                    }
                    datasets[i].data = newData;
                }

                return reply({
                    labels,
                    datasets
                });

            }).catch(error => reply(Boom.badRequest(error)));
    }

    fetchClosedOrdersByCustomersGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        let {
            customer
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_customer_v", request.payload);
        const { sqlStr } = sqlResult;

        const rawSql = `SELECT c.Name as Customer
                        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS Closed
                        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) AS Canceled
         FROM customers c 
        LEFT JOIN 
        (${sqlStr}) tbl ON c.CustomerId = tbl.CustomerId
        GROUP BY c.Name
        order by Closed DESC;`;
        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                let flag = false;
                const topData = [];
                let topNo = 0;

                let closed = 0;
                let canceled = 0;

                if (customer === "Top 10 And Others") {
                    customer = "Top10AndOthers";
                } else if (customer === "Top 20 And Others") {
                    customer = "Top20AndOthers";
                }
                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = rs[0].length;
                        break;
                    default:
                        topNo = rs[0].length;
                        break;
                }
                if (topNo > rs[0].length) {
                    topNo = rs[0].length;
                    flag = true;
                }
                for (let i = 0; i < topNo; i++) {
                    topData.push(rs[0][i]);
                }
                for (let i = topNo; i < rs[0].length; i++) {

                    closed += parseInt(rs[0][i].Closed);
                    canceled += parseInt(rs[0][i].Canceled);
                }
                if (hasStringValue(customer) && customer !== "All" && !flag) {
                    topData.push({ Customer: "Others", Closed: closed, Canceled: canceled });
                }

                const data = rs[0];

                let totalClosed = 0;
                let totalCanceled = 0;
                const closedOrders = data.map(i => i.Closed);
                const canceledOrders = data.map(i => i.Canceled);
                for (let i = 0; i < closedOrders.length; i++) {

                    totalClosed += closedOrders[i];
                }

                for (let i = 0; i < canceledOrders.length; i++) {

                    totalCanceled += canceledOrders[i];
                }
                topData.push({ Customer: `Total`, Closed: totalClosed, Canceled: totalCanceled });

                reply({
                    data: topData
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    countClosedOrdersByCustomersGridData(request, reply) {
        const {
            searchObject
        } = request.payload;
        let {
            customer
        } = searchObject;
        const sqlResult = buildSqlQuery("open_order_by_customer_v", request.payload);
        const { sqlStr } = sqlResult;

        const rawSql = `SELECT c.Name as Customer
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Closed') = 1 THEN 1 END) AS Closed
        , Count(CASE WHEN CheckOrderStatus(tbl.OrderStatus, 'Canceled') = 1 THEN 1 END) AS Canceled
         FROM customers c 
        LEFT JOIN 
        (${sqlStr}) tbl ON c.CustomerId = tbl.CustomerId
        GROUP BY c.Name
        order by Closed DESC;`;
        Bookshelf.knex.raw(rawSql)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                let flag = false;
                const topData = [];
                let topNo = 0;

                let closed = 0;
                let canceled = 0;

                if (customer === "Top 10 And Others") {
                    customer = "Top10AndOthers";
                } else if (customer === "Top 20 And Others") {
                    customer = "Top20AndOthers";
                }
                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    case "All":
                        topNo = rs[0].length;
                        break;
                    default:
                        topNo = rs[0].length;
                        break;
                }
                if (topNo > rs[0].length) {
                    topNo = rs[0].length;
                    flag = true;
                }
                for (let i = 0; i < topNo; i++) {
                    topData.push(rs[0][i]);
                }
                for (let i = topNo; i < rs[0].length; i++) {

                    closed += parseInt(rs[0][i].Closed);
                    canceled += parseInt(rs[0][i].Canceled);
                }
                if (hasStringValue(customer) && customer !== "All" && !flag) {
                    topData.push({ Customer: "Others", Closed: closed, Canceled: canceled });
                }

                reply(
                    topData.length
                );
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }
    fetchOrderByCustomerAndStatusCharData(request, reply) {
        const sqlResult = buildSqlQuery("open_order_by_customer_and_status_v", request.payload);
        const {
            sqlStr
        } = sqlResult;
        const { searchObject } = request.payload;
        const {
            orderStatus,
            customer
        } = searchObject;
        console.log("customer", customer);
        console.log("searchObject", searchObject);
        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                const datasets = [];

                const rawData = rs[0];
                let labels = distinctSingleValueArray(rawData.map(i => i.CustomerName));
                const labelOrderStatus = distinctSingleValueArray(orderStatus.map(item => item.label));

                if (customer === "All" || !customer) {

                    labels = ["All Customer"];
                    for (let i = 0; i < labelOrderStatus.length; i++) {
                        const tData = {
                            label: labelOrderStatus[i],
                            data: []
                        };
                        const f = rawData.filter(r => r.OrderStatus === labelOrderStatus[i]);
                        tData.data.push(f ? f.length : 0);
                        datasets.push(tData);
                    }
                } else {
                    for (let i = 0; i < labelOrderStatus.length; i++) {
                        const tData = {
                            label: labelOrderStatus[i],
                            data: []
                        };
                        for (let j = 0; j < labels.length; j++) {
                            const f = rawData.filter(r => ((r.CustomerName === labels[j]) && (r.OrderStatus === labelOrderStatus[i])));
                            tData.data.push(f ? f.length : 0);
                        }
                        datasets.push(tData);
                    }
                }
                // prepare temporary datasets to count total
                const totalDatasets = datasets[0].data.map(i => {
                    return {
                        value: i,
                        label: ""
                    };
                });

                // count total
                for (let i = 0; i < datasets.length; i++) {
                    for (let j = 0; j < totalDatasets.length; j++) {
                        if (i === 0) {
                            totalDatasets[j].label = labels[j];
                        } else {
                            totalDatasets[j].value += datasets[i].data[j];
                        }
                    }
                }

                // do sort
                totalDatasets.sort((a, b) => {
                    if (a.value > b.value) {
                        return -1;
                    }

                    if (a.value < b.value) {
                        return 1;
                    }

                    return 0;
                });

                const sortedLabels = totalDatasets.map(i => i.label);
                // sort data of datasets
                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < sortedLabels.length; j++) {
                        const oldIndex = labels.findIndex(f => f === sortedLabels[j]);
                        newData.push(oldData[oldIndex]);
                    }
                    datasets[i].data = newData;
                }

                // get top of customers
                let topNo = 0;

                switch (customer) {
                    case "Top10AndOthers":
                        topNo = 10;
                        break;
                    case "Top20AndOthers":
                        topNo = 20;
                        break;
                    default:
                        topNo = labels.length;
                        break;
                }

                labels = sortedLabels.filter((i, index) => index < topNo);

                if (hasStringValue(customer) && customer !== "All") {
                    labels.push("Others");
                }

                for (let i = 0; i < datasets.length; i++) {
                    const oldData = datasets[i].data;
                    const newData = [];
                    for (let j = 0; j < labels.length; j++) {
                        if (labels[j] === "Others") {
                            // count other data
                            let otherData = 0;
                            for (let k = labels.length - 1; k < sortedLabels.length; k++) {
                                otherData += oldData[k];
                            }

                            newData.push(otherData);
                        } else {
                            newData.push(oldData[j]);
                        }
                    }
                    datasets[i].data = newData;
                }
                reply({
                    labels,
                    datasets
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }

    fetchOrderByCustomerAndStatusGridData(request, reply) {
        const sqlResult = buildSqlQuery("open_order_by_customer_and_status_drilldown_v", request.payload);
        const {
            sqlStr
        } = sqlResult;
        const { searchObject } = request.payload;
        const {
            orderStatus,
            customer
        } = searchObject;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs) {
                    reply(Boom.badRequest("Empty response"));
                    return;
                }
                const dataMedium = rs[0];
                const data = [];
                const labels = distinctSingleValueArray(dataMedium.map(i => i.CustomerName));
                for (let i = 0; i < labels.length; i++) {
                    let countOpen = 0;
                    let countClose = 0;
                    let countCancel = 0;
                    let countPending = 0;
                    let cancellationPercentage = 0;
                    const f = dataMedium.filter(rd => rd.CustomerName === labels[i]);
                    for (let j = 0; j < f.length; j++) {
                        if (f[j].OrderStatus === "Open") {
                            countOpen += f[j].Count;
                        } else if (f[j].OrderStatus === "Closing Completed") {
                            countClose += f[j].Count;
                        } else if (f[j].OrderStatus === "Canceled") {
                            countCancel += f[j].Count;
                        } else {
                            countPending += f[j].Count;
                        }
                    }
                    (countOpen === 0 ? cancellationPercentage = countCancel * 100 : cancellationPercentage = countCancel / countOpen);
                    data.push({ Customer: labels[i], TotalOrder: countOpen, Closed: countClose, Pending: countPending, Canceled: countCancel, CancellationPercentage: cancellationPercentage });
                }
                reply({
                    data
                });
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }
    countOrderByCustomerAndStatusGridData(request, reply) {
        const sqlResult = buildSqlCountQuery("open_order_by_customer_and_status_drilldown_v", request.payload);

        const {
            sqlStr
        } = sqlResult;

        Bookshelf.knex.raw(sqlStr)
            .then(rs => {
                if (!rs || rs.length === 0) {
                    reply(0);
                    return;
                }

                const data = rs[0][0];

                reply(data.Num);
                return;
            })
            .catch(err => reply(Boom.badRequest(err)));
    }
}

export default new CustomerReportController();