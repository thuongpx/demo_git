import Bookshelf from "../../db/database";
import Boom from "boom";

import {
	distinctSingleValueArray,
	hasStringValue,
	bufferToBoolean
} from "../../helper/common-helper";
import {
	getOrderTypes,
	buildSqlQuery,
	buildSqlCountQuery,
	getAgents
} from "./canned-report";
//
import ManualReportTemplate from "../../db/model/manual-report-templates";
import moment from "moment";

class CannedReportController {
	constructor() { }

	async getInitDataForCannedReport(request, reply) {
		// get order types list
		const orderTypes = await getOrderTypes();
		const agents = await getAgents();

		reply({
			orderTypes: distinctSingleValueArray(orderTypes.map(i => i.LoanType)),
			agents: distinctSingleValueArray(agents.map(item => ({ value: item.AgentId, label: item.Agents })))
		});
	}

	fetchOrderByStatusChartData(request, reply) {
		const sqlResult = buildSqlQuery("open_order_chart_v", request.payload);
		const {
			sqlStr,
			isShowAll
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				const rawData = rs[0];
				const labels = distinctSingleValueArray(rawData.map(i => i.OrderStatus)); // build labels
				const orderTypes = distinctSingleValueArray(rawData.map(i => i.OrderType)); // build datasets

				const datasets = [];

				if (isShowAll) {
					const tData = {
						label: "All Data",
						data: []
					};

					for (let i = 0; i < labels.length; i++) {
						const f = rawData.filter(rd => rd.OrderStatus === labels[i]);
						const r = f.reduce((a, c) => {
							return {
								Count: a.Count + c.Count
							};
						});
						tData.data.push(r.Count);
					}

					datasets.push(tData);
				} else {
					for (let o = 0; o < orderTypes.length; o++) {
						const tData = {
							label: orderTypes[o],
							data: []
						};

						for (let i = 0; i < labels.length; i++) {
							const f = rawData.find(r => {
								return r.OrderType === orderTypes[o] && r.OrderStatus === labels[i];
							});

							tData.data.push(f ? f.Count : 0);
						}

						datasets.push(tData);
					}
				}
				return reply({
					labels,
					datasets
				});
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	fetchOrderComparisonByBussinessChartData(request, reply) {
		const {
			searchObject
		} = request.payload;
		const {
			month
		} = searchObject;

		const sqlResult = buildSqlQuery("open_order_comparison_by_business_day_chart_v", request.payload);
		const {
			sqlStr
		} = sqlResult;
		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				const rawData = rs[0];
				const sortedMonth = month.sort((a, b) => {
					return parseInt(a.value) - parseInt(b.value);
				});
				const labels = distinctSingleValueArray(sortedMonth.map(item => item.label));
				const labelValue = distinctSingleValueArray(sortedMonth.map(item => item.value));
				const datasets = [];
				const tData = {
					label: "All Data",
					data: []
				};
				for (let i = 0; i < labelValue.length; i++) {
					const f = rawData.filter(rd => (rd.OrderMonth === parseInt(labelValue[i])));

					tData.data.push(f.length);
				}
				datasets.push(tData);
				return reply({
					labels,
					datasets
				});
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	fetchOrderByStatusGridData(request, reply) {
		const sqlResult = buildSqlQuery("open_order_drilldown_v", request.payload);
		const {
			sqlStr
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs) {
					reply(Boom.badRequest("Empty response"));
					return;
				}

				const data = rs[0];
				reply({
					data
				});
				return;
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	countOrderByStatusGridData(request, reply) {
		const sqlResult = buildSqlCountQuery("open_order_drilldown_v", request.payload);

		const {
			sqlStr
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs || rs.length === 0) {
					reply(0);
					return;
				}

				const data = rs[0][0];

				reply(data.Num);
				return;
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	fetchDailyAutoAssignOrdersByStatusChartData(request, reply) {
		const sqlResult = buildSqlQuery("daily_counter_report_chart_v", request.payload);
		const {
			sqlStr
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				const rawData = rs[0].filter(rd => bufferToBoolean(rd.IsAutoAssign));
				const labels = distinctSingleValueArray(rawData.map(i => i.OrderStatus)); // build labels
				const datasets = [];
				const tData = {
					label: "All Data",
					data: []
				};

				for (let i = 0; i < labels.length; i++) {
					const f = rawData.filter(rd => rd.OrderStatus === labels[i]);
					const r = f.reduce((a, c) => {
						return {
							Count: a.Count + c.Count
						};
					});

					tData.data.push(r.Count);
				}
				datasets.push(tData);
				return reply({
					labels,
					datasets
				});
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	fetchDailyAutoAssignOrdersByStatusGridData(request, reply) {
		const sqlResult = buildSqlQuery("daily_counter_report_drilldown_v", request.payload);
		const {
			sqlStr
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs) {
					reply(Boom.badRequest("Empty response"));
					return;
				}
				const dataMedium = rs[0].filter(rd => bufferToBoolean(rd.IsAutoAssign));
				const data = [];
				const labels = distinctSingleValueArray(dataMedium.map(i => i.OrderStatus));
				for (let i = 0; i < labels.length; i++) {
					const f = dataMedium.filter(rd => rd.OrderStatus === labels[i]);
					if (f.length > 1) {
						const r = f.reduce((a, c) => {
							return {
								OrderStatus: a.OrderStatus,
								TotalOrder: a.TotalOrder + c.TotalOrder,
								SumOfAssignTime: a.SumOfAssignTime + c.SumOfAssignTime
							};
						});
						r.AverageOfAssignTime = r.SumOfAssignTime / r.TotalOrder;
						data.push(r);
					} else if (f.length === 1) {
						const r = {
							OrderStatus: f[0].OrderStatus,
							TotalOrder: f[0].TotalOrder,
							SumOfAssignTime: f[0].SumOfAssignTime,
							AverageOfAssignTime: f[0].AverageOfAssignTime
						};
						data.push(r);
					}
				}
				if (data.length > 1) {
					const r = data.reduce((a, c) => {
						return {
							OrderStatus: "Sub Total",
							TotalOrder: a.TotalOrder + c.TotalOrder,
							SumOfAssignTime: "",
							AverageOfAssignTime: ""
						};
					});
					data.push(r);
				} else if (data.length === 1) {
					const r = {
						OrderStatus: "Sub Total",
						TotalOrder: data[0].TotalOrder,
						SumOfAssignTime: "",
						AverageOfAssignTime: ""
					};
					data.push(r);
				}
				reply({
					data
				});
				return;
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	countDailyAutoAssignOrdersByStatusGridData(request, reply) {
		const sqlResult = buildSqlCountQuery("daily_counter_report_drilldown_v", request.payload);
		const {
			sqlStr
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs || rs.length === 0) {
					reply(0);
					return;
				}

				const data = rs[0][0];

				reply(data.Num);
				return;
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	fetchDailyManualAssignOrdersByStatusChartData(request, reply) {
		const sqlResult = buildSqlQuery("daily_counter_report_chart_v", request.payload);
		const {
			sqlStr
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				const rawData = rs[0].filter(rd => !bufferToBoolean(rd.IsAutoAssign));
				const labels = distinctSingleValueArray(rawData.map(i => i.OrderStatus)); // build labels
				const datasets = [];
				const tData = {
					label: "All Data",
					data: []
				};

				for (let i = 0; i < labels.length; i++) {
					const f = rawData.filter(rd => rd.OrderStatus === labels[i]);
					const r = f.reduce((a, c) => {
						return {
							Count: a.Count + c.Count
						};
					});

					tData.data.push(r.Count);
				}
				datasets.push(tData);
				return reply({
					labels,
					datasets
				});
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	fetchDailyManualAssignOrdersByStatusGridData(request, reply) {
		const sqlResult = buildSqlQuery("daily_counter_report_drilldown_v", request.payload);
		const {
			sqlStr
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs) {
					reply(Boom.badRequest("Empty response"));
					return;
				}
				const dataMedium = rs[0].filter(rd => !bufferToBoolean(rd.IsAutoAssign));
				const data = [];
				const labels = distinctSingleValueArray(dataMedium.map(i => i.OrderStatus));
				for (let i = 0; i < labels.length; i++) {
					const f = dataMedium.filter(rd => rd.OrderStatus === labels[i]);
					if (f.length > 1) {
						const r = f.reduce((a, c) => {
							return {
								OrderStatus: a.OrderStatus,
								TotalOrder: a.TotalOrder + c.TotalOrder,
								SumOfAssignTime: a.SumOfAssignTime + c.SumOfAssignTime
							};
						});
						r.AverageOfAssignTime = r.SumOfAssignTime / r.TotalOrder;
						data.push(r);
					} else if (f.length === 1) {
						const r = {
							OrderStatus: f[0].OrderStatus,
							TotalOrder: f[0].TotalOrder,
							SumOfAssignTime: f[0].SumOfAssignTime,
							AverageOfAssignTime: f[0].AverageOfAssignTime
						};
						data.push(r);
					}
				}
				if (data.length > 1) {
					const r = data.reduce((a, c) => {
						return {
							OrderStatus: "Sub Total",
							TotalOrder: a.TotalOrder + c.TotalOrder,
							SumOfAssignTime: "",
							AverageOfAssignTime: ""
						};
					});
					data.push(r);
				} else if (data.length === 1) {
					const r = {
						OrderStatus: "Sub Total",
						TotalOrder: data[0].TotalOrder,
						SumOfAssignTime: "",
						AverageOfAssignTime: ""
					};
					data.push(r);
				}
				reply({
					data
				});
				return;
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	countDailyManualAssignOrdersByStatusGridData(request, reply) {
		const sqlResult = buildSqlCountQuery("daily_counter_report_drilldown_v", request.payload);
		const {
			sqlStr
		} = sqlResult;

		Bookshelf.knex.raw(sqlStr)
			.then(rs => {
				if (!rs || rs.length === 0) {
					reply(0);
					return;
				}

				const data = rs[0][0];

				reply(data.Num);
				return;
			})
			.catch(err => reply(Boom.badRequest(err)));
	}

	addTemplateReport(request, reply) {
		const { reportName, searchBy, fromDate, toDate, searchAll, vendorStatus, columns } = request.payload;

		const reportObj = {
			ReportName: reportName,
			SearchBy: searchBy,
			FromDate: moment(fromDate).format("YYYY/MM/DD"),
			ToDate: moment(toDate).format("YYYY/MM/DD"),
			SearchAll: searchAll,
			VendorStatus: vendorStatus,
			Columns: columns
		};
		new ManualReportTemplate().save(
			reportObj
			,
			{ method: "insert" }).then((result) => {
				if (result !== null) {
					const data = result.attributes;
					const reportId = data.id;
					reply({
						reportId,
						isSuccess: true
					});
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));

			});
	}

	deleteTemplateReport(request, reply) {
		const { reportId } = request.payload;

		ManualReportTemplate.where({ reportId }).destroy().then((result) => {
			if (result !== null) {
				reply({
					isSuccess: true
				});

			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
    }
        
    getTemplateReport(request, reply) {
        const rawSql = "Select ReportName From manual_report_templates";

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null && result[0] !== null) {
                    const listReport = result[0];
                    reply({
                        listReport
                    });
                }
                return;
            }).catch(error => {
                reply(Boom.badRequest(error));
            });
    }
}
export default new CannedReportController();