import CannedReportController from "./canned-report-controller";
import CustomerReportController from "./customer-report-controller";
import StaffReportController from "./staff-report-controller";
import EconomicReportController from "./economic-report-controller";

const routes = [{
    path: "/cannedReport/fetchOrderByStatusChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchOrderByStatusChartData
},
{
    path: "/cannedReport/getInitDataForCannedReport",
    method: "GET",
    config: {
        auth: false
    },
    handler: CannedReportController.getInitDataForCannedReport
},
{
    path: "/cannedReport/fetchOrderByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchOrderByStatusGridData
},
{
    path: "/cannedReport/countOrderByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.countOrderByStatusGridData
},
{
    path: "/cannedReport/fetchOrderComparisonByBussinessChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchOrderComparisonByBussinessChartData
},
{
    path: "/cannedReport/fetchClosedOrdersByCustomersChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchClosedOrdersByCustomersChartData
},
{
    path: "/cannedReport/fetchOpenOrderTrendByCustomersChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchOpenOrderTrendByCustomersChartData
},
{
    path: "/cannedReport/fetchAssignedOrderByAgentsChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: StaffReportController.fetchAssignedOrderByAgentsChartData
},
{
    path: "/cannedReport/fetchMilestonesChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchMilestonesChartData
},
{
    path: "/cannedReport/fetchMilestonesGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchMilestonesGridData
},
{
    path: "/cannedReport/countMilestonesGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countMilestonesGridData
},
{
    path: "/cannedReport/fetchDailyAutoAssignOrdersByStatusChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchDailyAutoAssignOrdersByStatusChartData
},
{
    path: "/cannedReport/fetchDailyAutoAssignOrdersByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchDailyAutoAssignOrdersByStatusGridData
},
{
    path: "/cannedReport/countDailyAutoAssignOrdersByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.countDailyAutoAssignOrdersByStatusGridData
},
{
    path: "/cannedReport/fetchDailyManualAssignOrdersByStatusChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchDailyManualAssignOrdersByStatusChartData
},
{
    path: "/cannedReport/fetchDailyManualAssignOrdersByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.fetchDailyManualAssignOrdersByStatusGridData
},
{
    path: "/cannedReport/countDailyManualAssignOrdersByStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.countDailyManualAssignOrdersByStatusGridData
},
{
    path: "/cannedReport/fetchOpenOrderTrendByCustomersGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchOpenOrderTrendByCustomersGridData
},
{
    path: "/cannedReport/fetchEconomicChartData",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.fetchEconomicChartData
},

{
    path: "/cannedReport/countAssignedOrderBySchedulerGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: StaffReportController.countAssignedOrderBySchedulerGridData
},
{
    path: "/cannedReport/countOpenOrderTrendByCustomersGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countOpenOrderTrendByCustomersGridData
},
{
    path: "/cannedReport/fetchAssignedOrderBySchedulerGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: StaffReportController.fetchAssignedOrderBySchedulerGridData
},
{
    path: "/cannedReport/countEconomicGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.countEconomicGridData
},
{
    path: "/cannedReport/fetchClosedOrdersByCustomersGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchClosedOrdersByCustomersGridData
},
{
    path: "/cannedReport/fetchEconomicGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.fetchEconomicGridData
},
{
    path: "/cannedReport/getDefaultEconomicAgent",
    method: "POST",
    config: {
        auth: false
    },
    handler: EconomicReportController.getDefaultEconomicAgent
},
{
    path: "/cannedReport/countClosedOrdersByCustomersGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countClosedOrdersByCustomersGridData
},
// {
//     path: "/cannedReport/fetchOrderByClientsAndStatus",
//     method: "POST",
//     config: {
//         auth: false
//     },
//     handler: CustomerReportController.fetchOrderByClientsAndStatus
// },

{
    path: "/cannedReport/fetchOrderByCustomerAndStatusCharData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchOrderByCustomerAndStatusCharData
},
{
    path: "/cannedReport/fetchOrderByCustomerAndStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.fetchOrderByCustomerAndStatusGridData
},
{
    path: "/cannedReport/countOrderByCustomerAndStatusGridData",
    method: "POST",
    config: {
        auth: false
    },
    handler: CustomerReportController.countOrderByCustomerAndStatusGridData
},
{
    path: "/cannedReport/addTemplateReport",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.addTemplateReport

},
{
    path: "/cannedReport/deleteTemplateReport",
    method: "POST",
    config: {
        auth: false
    },
    handler: CannedReportController.deleteTemplateReport
},
{
    path: "/cannedReport/getTemplateReport",
    method: "GET",
    config: {
        auth: false
    },
    handler: CannedReportController.getTemplateReport
}
];

export default routes;