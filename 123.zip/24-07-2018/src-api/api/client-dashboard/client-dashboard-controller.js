import Boom from "boom";
import Bookshelf from "./../../db/database";

class ClientDashboardController {
    constructor() { }

    getUnfilledOrderDashboard(request, reply) {
        const {
            page,
            itemPerPage,
            role,
            clientId
        } = request.query;
        const rawSqlUnfilledOrder = `call GetUnfilledOrderDashboard(${page},${itemPerPage},'${role}',${clientId})`;

        Bookshelf.knex.raw(rawSqlUnfilledOrder)
            .then((result) => {
                if (result !== null) {
                    reply({
                        unfilledOrdersApproachingList: result[0][0],
                        unfilledOrdersApproachingTotalRecord: result[0][1][0].TotalRecordsUnfilledApproaching,
                        unfilledOrdersOutList: result[0][2],
                        unfilledOrdersOutTotalRecord: result[0][3][0].TotalRecordsUnfilledOut
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getPendingOrderDashboard(request, reply) {
        const {
            page,
            itemPerPage,
            role,
            clientId
        } = request.query;
        const rawSqlPendingOrder = `call GetPendingOrderDashboard(${page},${itemPerPage},'${role}',${clientId})`;

        Bookshelf.knex.raw(rawSqlPendingOrder)
            .then((result) => {
                if (result !== null) {
                    reply({
                        pendingOrdersApproachingList: result[0][0],
                        pendingOrdersApproachingTotalRecord: result[0][1][0].TotalRecordsPendingApproaching,
                        pendingOrdersOutList: result[0][2],
                        pendingOrdersOutTotalRecord: result[0][3][0].TotalRecordsPendingOut
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getFaxbacksOrderDashboard(request, reply) {
        const {
            page,
            itemPerPage,
            role,
            clientId
        } = request.query;
        const rawSqlFaxbacksOrder = `call GetFaxbacksOrderDashboard(${page},${itemPerPage},'${role}',${clientId})`;

        Bookshelf.knex.raw(rawSqlFaxbacksOrder)
            .then((result) => {
                if (result !== null) {
                    reply({
                        faxbacksOrdersList: result[0][0],
                        faxbacksOrdersTotalRecord: result[0][1][0].TotalRecordsFaxbacks
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getSLADashboard(request, reply) {
        const {
            clientId
        } = request.query;
        const getBrokerSLAs = new Promise((resolve, reject) => {
            const sql = `SELECT sla.SLA, CASE WHEN sla.From IS NOT NULL THEN sla.From ELSE sla.DefaultFrom END AS \`From\`, CASE WHEN sla.To IS NOT NULL THEN sla.To ELSE sla.DefaultTo END AS \`To\`  FROM \`broker_slas\` sla
                        WHERE sla.BrokerId = ${clientId}`;

            Bookshelf.knex.raw(sql)
                .then(data => {
                    if (data) resolve(data[0]);
                    else resolve({});
                })
                .catch(err => reject(err));
        });
        const getSLAs = new Promise((resolve, reject) => {
            const sql = `SELECT sla.SLA, CASE WHEN sla.From IS NOT NULL THEN sla.From ELSE sla.DefaultFrom END AS \`From\`, CASE WHEN sla.To IS NOT NULL THEN sla.To ELSE sla.DefaultTo END AS \`To\`  FROM \`slas\` sla`;

            Bookshelf.knex.raw(sql)
                .then(data => {
                    if (data) resolve(data[0]);
                    else resolve({});
                })
                .catch(err => reject(err));
        });

        Promise.all([
            getBrokerSLAs,
            getSLAs
        ]).then((values) => {
            const data = {};

            if (values !== null) {
                values.forEach((item, index) => {
                    if (item !== null) {
                        switch (index) {
                            case 0:
                                data.SLA_Broker = item;
                                break;
                            case 1:
                                data.SLA = item;
                                break;
                        }
                    }
                });
                reply(data);
            } else {
                reply(Boom.badRequest({
                    message: "Error!"
                }));
            }
        });
    }

    getOrdersInfoClientDashboard(request, reply) {
        const {
            role,
            clientId,
            timeZone
        } = request.query;
        const rawSqlFaxbacksOrder = `call GetOrdersInfoClientDashboard('${role}',${clientId},${timeZone})`;

        Bookshelf.knex.raw(rawSqlFaxbacksOrder)
            .then((result) => {
                if (result !== null) {
                    reply({
                        //self service
                        SelfService: {
                            //Open
                            OpenSelfService: result[0][0][0].OpenSelfService,
                            OpenSLAApproachingSelfService: result[0][1][0].OpenSLAApproachingSelfService,
                            OpenSLAOutOfSelfService: result[0][2][0].OpenSLAOutOfSelfService,
                            //Assigned
                            UnconfirmedSelfService: result[0][3][0].UnconfirmedSelfService,
                            UnconfirmedSLAApproachingSelfService: result[0][4][0].UnconfirmedSLAApproachingSelfService,
                            UnconfirmedSLAOutOfSelfService: result[0][5][0].UnconfirmedSLAOutOfSelfService,
                            PendingDocsSelfService: result[0][6][0].PendingDocsSelfService,
                            PendingDocsSLAApproachingSelfService: result[0][7][0].PendingDocsSLAApproachingSelfService,
                            PendingDocsSLAOutOfSelfService: result[0][8][0].PendingDocsSLAOutOfSelfService,
                            NeedingPreCallSelfService: result[0][9][0].NeedingPreCallSelfService,
                            NeedingPreCallSLAApproachingSelfService: result[0][10][0].NeedingPreCallSLAApproachingSelfService,
                            NeedingPreCallSLAOutOfSelfService: result[0][11][0].NeedingPreCallSLAOutOfSelfService,
                            //ApptReady
                            ApptReadySelfService: result[0][12][0].ApptReadySelfService,
                            ApptReadySLAApproachingSelfService: result[0][13][0].ApptReadySLAApproachingSelfService,
                            ApptReadySLAOutOfSelfService: result[0][14][0].ApptReadySLAOutOfSelfService,
                            //Closed pending
                            PendingReviewPCSelfService: result[0][15][0].PendingReviewPCSelfService,
                            PendingReviewPCSLAApproachingSelfService: result[0][16][0].PendingReviewPCSLAApproachingSelfService,
                            PendingReviewPCSLAOutOfSelfService: result[0][17][0].PendingReviewPCSLAOutOfSelfService,
                            AwaitingScanbacksSelfService: result[0][18][0].AwaitingScanbacksSelfService,
                            PendingQCReviewSelfService: result[0][19][0].PendingQCReviewSelfService,
                            PendingQCReviewSLAApproachingSelfService: result[0][20][0].PendingQCReviewSLAApproachingSelfService,
                            PendingQCReviewSLAOutOfSelfService: result[0][21][0].PendingQCReviewSLAOutOfSelfService,
                            //Closing Complete
                            ClosedMTDSelfService: result[0][22][0].ClosedMTDSelfService,
                            PostCloseIssueSelfService: result[0][23][0].PostCloseIssueSelfService,
                            PostCloseIssueSLAApproachingSelfService: result[0][24][0].PostCloseIssueSLAApproachingSelfService,
                            PostCloseIssueSLAOutOfSelfService: result[0][25][0].PostCloseIssueSLAOutOfSelfService,
                            //Did not close
                            CanceledByClientMTDSelfService: result[0][26][0].CanceledByClientMTDSelfService,
                            UnsuccessfulMTDSelfService: result[0][27][0].UnsuccessfulMTDSelfService,
                            PlacedOnHoldMTDSelfService: result[0][28][0].PlacedOnHoldMTDSelfService
                        },
                        //full service
                        FullService: {
                            //Open
                            OpenFullService: result[0][29][0].OpenFullService,
                            OpenSLAApproachingFullService: result[0][30][0].OpenSLAApproachingFullService,
                            OpenSLAOutOfFullService: result[0][31][0].OpenSLAOutOfFullService,
                            //Assigned
                            UnconfirmedFullService: result[0][32][0].UnconfirmedFullService,
                            UnconfirmedSLAApproachingFullService: result[0][33][0].UnconfirmedSLAApproachingFullService,
                            UnconfirmedSLAOutOfFullService: result[0][34][0].UnconfirmedSLAOutOfFullService,
                            PendingDocsFullService: result[0][35][0].PendingDocsFullService,
                            PendingDocsSLAApproachingFullService: result[0][36][0].PendingDocsSLAApproachingFullService,
                            PendingDocsSLAOutOfFullService: result[0][37][0].PendingDocsSLAOutOfFullService,
                            NeedingPreCallFullService: result[0][38][0].NeedingPreCallFullService,
                            NeedingPreCallSLAApproachingFullService: result[0][39][0].NeedingPreCallSLAApproachingFullService,
                            NeedingPreCallSLAOutOfFullService: result[0][40][0].NeedingPreCallSLAOutOfFullService,
                            //ApptReady
                            ApptReadyFullService: result[0][41][0].ApptReadyFullService,
                            ApptReadySLAApproachingFullService: result[0][42][0].ApptReadySLAApproachingFullService,
                            ApptReadySLAOutOfFullService: result[0][43][0].ApptReadySLAOutOfFullService,
                            PendingReviewPCFullService: result[0][44][0].PendingReviewPCFullService,
                            PendingReviewPCSLAApproachingFullService: result[0][45][0].PendingReviewPCSLAApproachingFullService,
                            PendingReviewPCSLAOutOfFullService: result[0][46][0].PendingReviewPCSLAOutOfFullService,
                            AwaitingScanbacksFullService: result[0][47][0].AwaitingScanbacksFullService,
                            PendingQCReviewFullService: result[0][48][0].PendingQCReviewFullService,
                            PendingQCReviewSLAApproachingFullService: result[0][49][0].PendingQCReviewSLAApproachingFullService,
                            PendingQCReviewSLAOutOfFullService: result[0][50][0].PendingQCReviewSLAOutOfFullService,
                            //Closing Complete
                            ClosedMTDFullService: result[0][51][0].ClosedMTDFullService,
                            PostCloseIssueFullService: result[0][52][0].PostCloseIssueFullService,
                            PostCloseIssueSLAApproachingFullService: result[0][53][0].PostCloseIssueSLAApproachingFullService,
                            PostCloseIssueSLAOutOfFullService: result[0][54][0].PostCloseIssueSLAOutOfFullService,
                            //Did not close
                            CanceledByClientMTDFullService: result[0][55][0].CanceledByClientMTDFullService,
                            UnsuccessfulMTDFullService: result[0][56][0].UnsuccessfulMTDFullService,
                            PlacedOnHoldMTDFullService: result[0][57][0].PlacedOnHoldMTDFullService
                        }
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getOrdersInfoDetailClientDashboard(request, reply) {
        const {
            role,
            clientId,
            service,
            statusGroup,
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            timeZone
        } = request.query;
        const rawSqlOrders = `call GetOrdersInfoDetailClientDashboard('${role}',${clientId}, '${service}', '${statusGroup}',
        '${sortColumn}',${sortDirection},${page},${itemPerPage},${timeZone})`;

        Bookshelf.knex.raw(rawSqlOrders)
            .then((result) => {
                if (result !== null) {
                    switch (service) {
                        case "Self": {
                            if (statusGroup === "OpenAll") {
                                reply({
                                    OpenOrders: result[0][0],
                                    OpenOrdersTotal: result[0][1][0].TotalRecords,
                                    OpenOrdersSLAApproaching: result[0][2],
                                    OpenOrdersSLAApproachingTotal: result[0][3][0].TotalRecords,
                                    OpenOrdersSLAOutOf: result[0][4],
                                    OpenOrdersSLAOutOfTotal: result[0][5][0].TotalRecords
                                });
                            }
                            if (statusGroup === "Open") {
                                reply({
                                    OpenOrders: result[0][0],
                                    OpenOrdersTotal: result[0][1][0].TotalRecords
                                });
                            }
                            if (statusGroup === "OpenSLAApproaching") {
                                reply({
                                    OpenOrdersSLAApproaching: result[0][0],
                                    OpenOrdersSLAApproachingTotal: result[0][1][0].TotalRecords
                                });
                            }
                            if (statusGroup === "OpenSLAOutOf") {
                                reply({
                                    OpenOrdersSLAOutOf: result[0][0],
                                    OpenOrdersSLAOutOfTotal: result[0][1][0].TotalRecords
                                });
                            }
                            break;
                        }
                        case "Full": {
                            if (statusGroup === "Open") {
                                reply({
                                    OpenOrders: result[0][0],
                                    OpenOrdersTotal: result[0][1][0].TotalRecords,
                                    OpenOrdersSLAApproaching: result[0][2],
                                    OpenOrdersSLAApproachingTotal: result[0][3][0].TotalRecords,
                                    OpenOrdersSLAOutOf: result[0][4],
                                    OpenOrdersSLAOutOfTotal: result[0][5][0].TotalRecords
                                });
                            }
                            break;
                        }
                        default: {
                            reply({
                                isSuccess: false
                            });
                            break;
                        }
                    }
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
}

export default new ClientDashboardController();