import Boom from "boom";
import Bookshelf from "../../db/database";

class BonusCalculationController {
    constructor() {}

    getBonusCalculationData(request, reply) {
        const rawSql = `select UnitGoal, FillOutDeduction, ErrorDeduction, ErrorDeduction, MaximunGP, MaximunGPBonus from system_settings`;

        Bookshelf.knex.raw(rawSql).then((result) => {
            const data = {};
            if (result !== null) {
                data.bonusCalculationData = result[0];
            }
            reply(data);
        }).catch((err) => {
            reply(Boom.badRequest(err));
        });
    }
}
export default new BonusCalculationController();