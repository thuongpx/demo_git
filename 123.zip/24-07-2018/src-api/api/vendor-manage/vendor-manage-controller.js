import Boom from "boom";
import Bookshelf from "../../db/database";
import moment from "moment";
import {
    handleSingleQuote,
    bufferToBoolean
} from "../../helper/common-helper";

class VendorManageController {
    getOrdersVendorList(request, reply) {
        const data = request.query.criteria;
        const criteria = JSON.parse(data);
        const vendorName = (criteria.vendorName === "" || criteria.vendorName === undefined || criteria.vendorName === null) ? "" : handleSingleQuote(criteria.vendorName);
        const numberOfClosedOrder = (criteria.numberOfClosedOrder === "" || criteria.numberOfClosedOrder === undefined || criteria.numberOfClosedOrder === null) ? null : handleSingleQuote(criteria.numberOfClosedOrder);
        const city = (criteria.city === "" || criteria.city === undefined || (!!criteria.city) === null) ? "" : handleSingleQuote(criteria.city);
        const rawQuery = `call GetOrdersVendorList('${criteria.sortColumn}', ${criteria.sortDirection}, ${criteria.page}, ${criteria.itemPerPage},
                                                    ${criteria.isShowAdvancedOptions}, ${criteria.orderId}, '${vendorName}', ${(criteria.distance === "") ? null : criteria.distance}, ${criteria.languageId}, ${numberOfClosedOrder || null},
                                                    ${criteria.ratingId || null}, '${city}', '${criteria.stateId}', '${criteria.zip}', '${criteria.phoneNumber}' , '${criteria.vendorCat}')`;

        Bookshelf.knex.raw(rawQuery).then((result) => {
            if (result === null || !result[0] || !result[0][0]) {
                reply({
                    isSuccess: false
                });
                return;
            }

            const datasources = result[0][0];
            datasources.map((item) => {
                item.orderId = criteria.orderId;
                return item;
            });

            reply({
                datasources,
                totalRecords: result[0][1][0].TotalRecords
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    checkClientSatisfiedVendor(request, reply) {
        const {
            orderId,
            signerId
        } = request.query;

        const rawQuery = `CALL CheckClientSatisfiedVendor(${orderId}, ${signerId})`;

        Bookshelf.knex.raw(rawQuery).then(result => {
            if (result === null || !result[0] || !result[0][0]) {
                reply({
                    isSuccess: false
                });
                return;
            }

            reply(result[0][0][0]);
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    getDataInit(request, reply) {
        const {
            orderId
        } = request.query;

        const languageSql = "select LanguageID, Language from language order by Language";
        const ratingSql = "select * from rating";
        const statesSql = "call GetAllState";
        const unacknowledgedSql = "SELECT DISTINCT SignerId as signerId FROM order_problem WHERE Acknowledged = 0 or Acknowledged is null";
        const offerAmountSql = `SELECT SUM(SignerFee) as offerAmount FROM order_fee where OrderID = ${orderId}`;
        const catSql = "select * From vendor_categories ORDER BY CatId";
        const orderDetailSql = `SELECT AptDateTime AS aptDateTime, LanguageId AS languageId, IsSelfService AS isSelfService FROM ` +
            "`order`" +
            ` WHERE OrderId = ${orderId}`;
        const agentSql = `SELECT a.FullName AS fullName, a.Email AS agentEmail FROM agent AS a where a.AgentId = (SELECT o.AgentId FROM ` +
            "`order`" +
            `AS o where o.OrderId = ${orderId})`;
        const loanTypeSql = `SELECT l.LoanType AS loantype FROM loan_type l WHERE l.LoanTypeId = (SELECT o.LoanType FROM ` +
            "`order`" +
            ` o WHERE o.OrderId = ${orderId})`;
        const feeDesIdSql = `SELECT of.FeeDescripID AS feeDescripId FROM order_fee of inner join broker_fee bf on of.FeeDescripID = bf.FeeId where bf.IsAdditionalFee = 0 and of.OrderID = ${orderId}`;

        const queue = [];
        queue.push(Promise.resolve(Bookshelf.knex.raw(languageSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(ratingSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(statesSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(unacknowledgedSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(offerAmountSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(catSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(orderDetailSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(agentSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(loanTypeSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(feeDesIdSql)));

        Promise.all(queue).then((result) => {
            if (result !== null) {
                const languages = result[0][0];
                const rating = result[1][0];
                const states = result[2][0][0];
                const signerUnAcknowledged = result[3][0];
                const {
                    offerAmount
                } = result[4][0][0];
                const vendorCategories = result[5][0];
                const dateTime = result[6][0][0].aptDateTime;
                const languageId = result[6][0][0].languageId;
                const isSelfService = bufferToBoolean(result[6][0][0].isSelfService);
                const aptDateTime = dateTime ? moment(dateTime).utc().format("YYYY-MM-DD HH:mm:ss") : null;
                const agent = result[7][0][0];
                const loanType = result[8][0][0] ? result[8][0][0].loantype : null;
                // const languageId = result[9][0][0] ? result[9][0][0].languageId : null;

                const feeDescripId = result[9][0][0] ? result[9][0][0].feeDescripId : null;
                reply({
                    languages,
                    rating,
                    states,
                    signerUnAcknowledged,
                    offerAmount,
                    vendorCategories,
                    aptDateTime,
                    agent,
                    loanType,
                    languageId,
                    feeDescripId,
                    isSelfService
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    checkVendorPassedExam(request, reply) {
        const { vendorId } = request.query;

        console.log(request.query);

        const rawSql = `SELECT (CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END) AS isVendorPassed FROM vendor_test_result vts WHERE vts.VendorId = ${vendorId} AND vts.Passed = 'N' AND vts.TestId = (SELECT DISTINCT ti.TestId FROM test_info ti WHERE ti.DefaultTest = 1);`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                reply({
                    isVendorPassed: result[0][0].isVendorPassed
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}

export default new VendorManageController();