import sendMailCore from "../../mail/mail-helper";
import Boom from "boom";
import config from "../../config/config";
import User from "../../db/model/users";
import Signer from "../../db/model/signers";
import {
    replaceAll
} from "./../../helper/common-helper";
import Bookshelf from "./../../db/database";
import { sendSms } from "./../../helper/sms-helper";
import {
    NOTIFICATION_TEMPLATE_PURPOSE
} from "../../constant/common-constant";
//
import Agent from "../../db/model/agents";
import Broker from "../../db/model/brokers";

class EmailController {
    constructor() { }

    sendMail(request, reply) {
        const options = request.payload;

        const mailOptions = {
            from: options.from || "pavaso01@adb.com",
            to: options.to,
            subject: options.subject,
            text: options.text || "",
            html: options.html
        };

        sendMailCore(mailOptions, (result) => {
            if (result.error) {
                return reply(Boom.badRequest(result.error));
            }
            return reply(result);
        });
    }

    async mobileVendorSendEmailToUs(request, reply) {
        const { message, subject, usersId } = request.payload;
        let signerId = 0;
        let signerEmail = "";

        await new Promise((resolve) => User.where({ usersId }).fetch({ columns: ["mappingUserId"] }).then((model) => {
            signerId = model.get("mappingUserId");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Signer.where({ signerId }).fetch({ columns: ["email"] }).then((model) => {
            signerEmail = model.get("email");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        const mailOptions = {
            from: signerEmail,
            to: config.mail.receiver,
            subject,
            html: `${replaceAll(message, "\n", "<br/>")}`
        };

        sendMailCore(mailOptions);
        reply({ isSuccess: true });
    }

    async mobileSendEmailToTCE(request, reply) {
        const { message, usersId, orderId } = request.payload;
        let signerId = 0;
        let signerEmail = "";
        let receiveEmail = "";

        const rawSql = `Select o.OrderId, o.RepId, e.Email From \`order\` AS o
        INNER JOIN employees AS e ON o.RepId = e.RepId and OrderId= ${orderId} `;

        await new Promise((resolve) => User.where({ usersId }).fetch({ columns: ["mappingUserId"] }).then((model) => {
            signerId = model.get("mappingUserId");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Signer.where({ signerId }).fetch({ columns: ["email"] }).then((model) => {
            signerEmail = model.get("email");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    receiveEmail = result[0][0].Email;
                    const mailOptions = {
                        from: signerEmail,
                        to: receiveEmail,
                        subject: `OrderID #${orderId} - Vendor Communication`,
                        html: `${replaceAll(message, "\n", "<br/>")}`
                    };

                    sendMailCore(mailOptions);
                    reply({ isSuccess: true });
                }
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

    }

    mobileArrivedAtAppt(request, reply) {
        const { orderId } = request.payload;
        const rawSql = `SELECT o.HomePhone, o.AgentId, a.FullName, a.Email FROM \`order\` AS o INNER JOIN agent AS a ON o.AgentId = a.AgentId AND OrderId = ${orderId}`;
        const rawSqlGetTemplate = `SELECT fromEmail, subject, message FROM notification_templates nt where nt.Purpose='${NOTIFICATION_TEMPLATE_PURPOSE.ARRIVED_AT_APPOINTMENT_AGENT}'`;
        let agentEmail = "";

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    const homePhone = result[0][0].HomePhone;
                    const message = `Please informed that the Vendor of Order – ${orderId} has arrived at appointment.`;
                    agentEmail = result[0][0].Email;

                    sendSms(message, homePhone);

                    Bookshelf.knex.raw(rawSqlGetTemplate)
                        .then(mailResult => {
                            if (mailResult[0][0]) {
                                const templateMail = mailResult[0][0];
                                templateMail.message = replaceAll(templateMail.message, "[OrderID]", orderId);
                                const mailOptions = {
                                    from: templateMail.fromEmail,
                                    to: agentEmail,
                                    subject: replaceAll(templateMail.subject, "[OrderID]", orderId),
                                    html: templateMail.message
                                };

                                sendMailCore(mailOptions, (rs) => {
                                    reply(rs.error ? { error: rs.error } : { isSuccess: true });
                                });
                            }
                        }).catch(err => {
                            reply(Boom.badRequest(err));
                        });
                }
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    // send mail to vendor communication
    async sendEmailToVendorCommunication(request, reply) {
        const { message, usersId, orderId } = request.payload;
        let agentId = 0;
        let agentEmail = "";
        let receiveEmail = "";

        const rawSql = `Select o.OrderId, o.SignerId, s.Email From \`order\` AS o
        INNER JOIN signer AS s ON o.SignerId = s.SignerId and OrderId= ${orderId} `;

        await new Promise((resolve) => User.where({ usersId }).fetch({ columns: ["mappingUserId"] }).then((model) => {
            agentId = model.get("mappingUserId");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Agent.where({ agentId }).fetch({ columns: ["email"] }).then((model) => {
            agentEmail = model.get("email");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    receiveEmail = result[0][0].Email;
                    const mailOptions = {
                        from: agentEmail,
                        to: receiveEmail,
                        subject: `The Closing Exchange – Message from Client #${orderId}.`,
                        html: `${replaceAll(message, "\n", "<br/>")}`
                    };

                    sendMailCore(mailOptions);
                    reply({ isSuccess: true });
                }
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
    // send sms to vendor communication
    sendSmsToVendorCommunication(request, reply) {
        const { orderId, message } = request.payload;
        const rawSql = `SELECT o.HomePhone, o.SignerId, a.Email FROM \`order\` AS o INNER JOIN agent AS a ON o.AgentId = a.AgentId AND OrderId = ${orderId}`;

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    const homePhone = result[0][0].HomePhone;
                    const content = `OrderID #${orderId} ${message}`;

                    sendSms(content, homePhone);
                }
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
    // send mail to TCE communication
    async sendEmailToTCECommunication(request, reply) {
        const { message, usersId, orderId } = request.payload;
        let signerId = 0;
        let signerEmail = "";
        let receiveEmail = "";

        const rawSql = `Select o.OrderId, o.RepId, e.Email, e.FirstName From \`order\` AS o
        INNER JOIN employees AS e ON o.RepId = e.RepId and OrderId= ${orderId} `;

        await new Promise((resolve) => User.where({ usersId }).fetch({ columns: ["mappingUserId"] }).then((model) => {
            signerId = model.get("mappingUserId");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Signer.where({ signerId }).fetch({ columns: ["email"] }).then((model) => {
            signerEmail = model.get("email");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    receiveEmail = result[0][0].Email;
                    const mailOptions = {
                        from: signerEmail,
                        to: receiveEmail,
                        subject: `The Closing Exchange – Message from Client – Order #${orderId}`,
                        html: `${replaceAll(message, "\n", "<br/>")}`
                    };

                    sendMailCore(mailOptions);
                    reply({ isSuccess: true });
                }
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    // send mail to TCE communication
    async sendEmailToClientCommunication(request, reply) {
        const { message, usersId, orderId } = request.payload;
        let brokerId = 0;
        let brokerEmail = "";
        let receiveEmail = "";

        const rawSql = `Select o.OrderId, b.BrokerId, b.Email From \`order\` AS o
        INNER JOIN broker AS b ON o.BrokerId = b.BrokerId and OrderId= ${orderId} `;

        await new Promise((resolve) => User.where({ usersId }).fetch({ columns: ["mappingUserId"] }).then((model) => {
            brokerId = model.get("mappingUserId");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        await new Promise((resolve) => Broker.where({ brokerId }).fetch({ columns: ["email"] }).then((model) => {
            brokerEmail = model.get("email");
            resolve();
        }).catch(error => reply(Boom.badRequest(error))));

        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                if (result[0].length > 0) {
                    receiveEmail = result[0][0].Email;
                    const mailOptions = {
                        from: brokerEmail,
                        to: receiveEmail,
                        subject: `The Closing Exchange – Message to Client – Order #${orderId}`,
                        html: `${replaceAll(message, "\n", "<br/>")}`
                    };

                    sendMailCore(mailOptions);
                    reply({ isSuccess: true });
                } else {
                    reply({ isSuccess: false });
                }
            } else {
                reply({ isSuccess: false });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    // send mail to Vendor Close Request, TCE Scheduler
    async sendSendCloseSuccessfully(request, reply) {
        const {
            orderId,
            courier,
            companyName,
            aptDateTime,
            courierAccountNumber,
            referenceNumber,
            trackingNumber,
            isTurnAroundDate,
            isDocumentCompletedDate,
            isDocumentRPSINcheck,
            isIssues,
            issuesResolveText,
            isCollected,
            collectedText,
            isRequiredScanbacks,
            scanbacksDate,
            scanbacksTime,
            generalComment,
            docDroppedDate,
            docDroppedTime,
            date,
            vendorName,
            vendorEmail,
            agentEmail,
            TCEEmail,
            customerLastName,
            nextStatus
        } = request.payload;
        // const rawSql = `SELECT o.HomePhone, o.AgentId, a.FullName, a.Email FROM \`order\` AS o INNER JOIN agent AS a ON o.AgentId = a.AgentId AND OrderId = ${orderId}`;
        //CLOSING_COMPLETED
        let rawSqlGetTemplate = `SELECT fromEmail, subject, message FROM notification_templates nt where nt.Purpose='Close Request - Vendor -'`;
        if (nextStatus === 6) { //CLOSED_PENDING_REVIEW_PC_RESOLUTION
            rawSqlGetTemplate = `SELECT fromEmail, subject, message FROM notification_templates nt where nt.Purpose='Close Request - Vendor - Scanbacks'`;
        }
        if (nextStatus === 7) { //CLOSED_PENDING_QC_REVIEW
            rawSqlGetTemplate = `SELECT fromEmail, subject, message FROM notification_templates nt where nt.Purpose='Close Request - Vendor - no Scanbacks'`;
        }

        const rawSqlGetAgentTemplate = `SELECT fromEmail, subject, message FROM notification_templates nt where nt.Purpose='Close Request - Agent'`;
        const rawSqlGetTCETemplate = `SELECT fromEmail, subject, message FROM notification_templates nt where nt.Purpose='Close Request - TCE'`;
        let theError = "";
        //mail to Vendor
        await new Promise((resolve, reject) => {
            Bookshelf.knex.raw(rawSqlGetTemplate)
                .then(mailResult => {
                    if (mailResult[0][0]) {
                        const templateMail = mailResult[0][0];
                        templateMail.message = replaceAll(templateMail.message, "[orderId]", orderId);
                        templateMail.message = replaceAll(templateMail.message, "[Company]", companyName);
                        templateMail.message = replaceAll(templateMail.message, "[aptDateTime]", aptDateTime);
                        templateMail.message = replaceAll(templateMail.message, "[courier]", courier);
                        templateMail.message = replaceAll(templateMail.message, "[courierAccountNumber]", courierAccountNumber);
                        templateMail.message = replaceAll(templateMail.message, "[referenceNumber]", referenceNumber);
                        templateMail.message = replaceAll(templateMail.message, "[trackingNumber]", trackingNumber);
                        templateMail.message = replaceAll(templateMail.message, "[isTurnAroundDate]", isTurnAroundDate);
                        templateMail.message = replaceAll(templateMail.message, "[isDocumentCompletedDate]", isDocumentCompletedDate);
                        templateMail.message = replaceAll(templateMail.message, "[isDocumentRPSINcheck]", isDocumentRPSINcheck);
                        templateMail.message = replaceAll(templateMail.message, "[isIssues]", isIssues);
                        templateMail.message = replaceAll(templateMail.message, "[issuesResolveText]", issuesResolveText);
                        templateMail.message = replaceAll(templateMail.message, "[isCollected]", isCollected);
                        templateMail.message = replaceAll(templateMail.message, "[collectedText]", collectedText);
                        templateMail.message = replaceAll(templateMail.message, "[isRequiredScanbacks]", isRequiredScanbacks);
                        templateMail.message = replaceAll(templateMail.message, "[scanbacksDate]", scanbacksDate);
                        templateMail.message = replaceAll(templateMail.message, "[scanbacksTime]", scanbacksTime);
                        templateMail.message = replaceAll(templateMail.message, "[generalComment]", generalComment);
                        templateMail.message = replaceAll(templateMail.message, "[docDroppedDate]", docDroppedDate);
                        templateMail.message = replaceAll(templateMail.message, "[docDroppedTime]", docDroppedTime);
                        templateMail.message = replaceAll(templateMail.message, "[date]", date);
                        templateMail.message = replaceAll(templateMail.message, "[vendorName]", vendorName);
                        templateMail.message = replaceAll(templateMail.message, "[customerLastName]", customerLastName);
                        const mailOptions = {
                            from: templateMail.fromEmail,
                            to: vendorEmail,
                            subject: replaceAll(templateMail.subject, "[orderId]", orderId),
                            html: templateMail.message
                        };

                        sendMailCore(mailOptions, (rs) => {
                            if (rs === undefined) {
                                reject();
                                // reply({ isSuccess: false, error: "Mail error" });
                            } else {
                                resolve();
                                // reply(rs.error ? { error: rs.error } : { isSuccess: true });
                            }
                        });
                    }
                }).catch(() => {
                    reject();
                    // reply(Boom.badRequest(err));
                });
        }).catch(error => { theError = error; });
        //mail to Agent
        if (agentEmail !== null && agentEmail !== undefined) {
            await new Promise((resolve, reject) => {
                Bookshelf.knex.raw(rawSqlGetAgentTemplate)
                    .then(mailResult => {
                        if (mailResult[0][0]) {
                            const templateMail = mailResult[0][0];
                            templateMail.subject = replaceAll(templateMail.subject, "[orderId]", orderId);
                            templateMail.subject = replaceAll(templateMail.subject, "[Reference]", referenceNumber);
                            templateMail.message = replaceAll(templateMail.message, "[orderId]", orderId);
                            templateMail.message = replaceAll(templateMail.message, "[vendorName]", vendorName);
                            const mailOptions = {
                                from: templateMail.fromEmail,
                                to: agentEmail,
                                subject: templateMail.subject,
                                html: templateMail.message
                            };

                            sendMailCore(mailOptions, (rs) => {
                                if (rs === undefined) {
                                    reject();
                                } else {
                                    resolve();
                                }
                            });
                        }
                    }).catch(() => {
                        reject();
                    });
            }).catch(error => { theError = error; });
        }
        //mail to TCE
        if (TCEEmail !== null && TCEEmail !== undefined) {
            await new Promise((resolve, reject) => {
                Bookshelf.knex.raw(rawSqlGetTCETemplate)
                    .then(mailResult => {
                        if (mailResult[0][0]) {
                            const templateMail = mailResult[0][0];
                            templateMail.subject = replaceAll(templateMail.subject, "[orderId]", orderId);
                            templateMail.subject = replaceAll(templateMail.subject, "[Reference]", referenceNumber);
                            templateMail.message = replaceAll(templateMail.message, "[orderId]", orderId);
                            templateMail.message = replaceAll(templateMail.message, "[Company]", companyName);
                            templateMail.message = replaceAll(templateMail.message, "[aptDateTime]", aptDateTime);
                            templateMail.message = replaceAll(templateMail.message, "[courier]", courier);
                            templateMail.message = replaceAll(templateMail.message, "[courierAccountNumber]", courierAccountNumber);
                            templateMail.message = replaceAll(templateMail.message, "[referenceNumber]", referenceNumber);
                            templateMail.message = replaceAll(templateMail.message, "[trackingNumber]", trackingNumber);
                            templateMail.message = replaceAll(templateMail.message, "[isTurnAroundDate]", isTurnAroundDate);
                            templateMail.message = replaceAll(templateMail.message, "[isDocumentCompletedDate]", isDocumentCompletedDate);
                            templateMail.message = replaceAll(templateMail.message, "[isDocumentRPSINcheck]", isDocumentRPSINcheck);
                            templateMail.message = replaceAll(templateMail.message, "[isIssues]", isIssues);
                            templateMail.message = replaceAll(templateMail.message, "[issuesResolveText]", issuesResolveText);
                            templateMail.message = replaceAll(templateMail.message, "[isCollected]", isCollected);
                            templateMail.message = replaceAll(templateMail.message, "[collectedText]", collectedText);
                            templateMail.message = replaceAll(templateMail.message, "[isRequiredScanbacks]", isRequiredScanbacks);
                            templateMail.message = replaceAll(templateMail.message, "[scanbacksDate]", scanbacksDate);
                            templateMail.message = replaceAll(templateMail.message, "[scanbacksTime]", scanbacksTime);
                            templateMail.message = replaceAll(templateMail.message, "[generalComment]", generalComment);
                            templateMail.message = replaceAll(templateMail.message, "[docDroppedDate]", docDroppedDate);
                            templateMail.message = replaceAll(templateMail.message, "[docDroppedTime]", docDroppedTime);
                            templateMail.message = replaceAll(templateMail.message, "[date]", date);
                            templateMail.message = replaceAll(templateMail.message, "[vendorName]", vendorName);
                            templateMail.message = replaceAll(templateMail.message, "[customerLastName]", customerLastName);
                            const mailOptions = {
                                from: templateMail.fromEmail,
                                to: TCEEmail,
                                subject: templateMail.subject,
                                html: templateMail.message
                            };

                            sendMailCore(mailOptions, (rs) => {
                                if (rs === undefined) {
                                    reject();
                                } else {
                                    resolve();
                                }
                            });
                        }
                    }).catch(() => {
                        reject();
                    });
            }).catch(error => { theError = error; });
        }
        if (theError !== "") {
            Boom.badRequest(theError);
        } else {
            reply({ isSuccess: true });
        }
    }

    async sendSendCloseUnsuccessfully(request, reply) {
        reply({ isSuccess: true });
    }
}

export default new EmailController();